"""Registry that lets feature modules add API routes without editing generation_app.py.

A module registers handlers at import time:
    extensions.POST["name"] = fn(payload: dict) -> JSON-serializable | (bytes, mime)
    extensions.GET["name"]  = fn(query: dict[str, list[str]]) -> JSON-serializable | (bytes, mime)
They are served at /api/x/<name>. Handlers raise ValueError for user-facing errors (HTTP 400).
"""

import csv
import re
from pathlib import Path

from version import PRODUCT, VERSION, BUILD_DATE, label as version_label

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / "Application Runs"
POST = {}
GET = {}
# Feature modules imported by the server; failures are logged, never fatal.
MODULES = ["sensitivity", "reliability", "power_flow", "datasources", "explain", "economic_metrics", "report", "design", "workflow", "solver_backend"]


def valid_run_id(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{32}", value) is not None


def run_folder(run_id):
    if not valid_run_id(run_id):
        raise ValueError("Invalid saved run ID.")
    folder = RUNS / run_id
    if not (folder / "status.json").is_file():
        raise ValueError("Saved run not found.")
    return folder


def inside(base, candidate):
    """True when candidate resolves to a location within base (after symlinks and '..')."""
    try:
        Path(candidate).resolve().relative_to(Path(base).resolve())
        return True
    except (ValueError, OSError):
        return False


_FORMULA_START = ("=", "+", "-", "@", "\t", "\r")
_NUMBER = re.compile(r"[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?")


def safe_cell(value):
    """Neutralise spreadsheet formula injection in an exported text cell.

    Text beginning with = + - @ is evaluated as a formula by Excel on CSV open, so it is prefixed with an
    apostrophe. Plain numbers written as text (e.g. '-5') are left unchanged.
    """
    if isinstance(value, str) and value.startswith(_FORMULA_START) and not _NUMBER.fullmatch(value):
        return "'" + value
    return value


class SafeCsvWriter:
    """csv.writer wrapper applying safe_cell to every cell."""

    def __init__(self, stream, **kwargs):
        self._writer = csv.writer(stream, **kwargs)

    def writerow(self, row):
        return self._writer.writerow([safe_cell(v) for v in row])

    def writerows(self, rows):
        for row in rows:
            self.writerow(row)


def protect_workbook(workbook):
    """Store text cells that start with '=' as strings so spreadsheet applications never evaluate them."""
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and cell.value.startswith("="):
                    cell.data_type = "s"
    return workbook


def safe_filename(name, default="file"):
    """Reduce an arbitrary user-supplied name to a safe single path component."""
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", str(name or "")).strip("._")
    return stem[:80] or default


def load_all():
    import importlib
    import logging
    log = logging.getLogger("genstudio")
    for name in MODULES:
        try:
            importlib.import_module(name)
        except ModuleNotFoundError as exc:
            if exc.name != name:
                log.exception("Feature module %s could not load (missing dependency %s)", name, exc.name)
        except Exception:
            log.exception("Feature module %s failed to load", name)
