import json
import shutil
import tempfile
import unittest
from pathlib import Path

import economic_metrics as em
import extensions
import workflow

USER_RUN = Path(__file__).resolve().parent / "Application Runs" / "7791be18470745f8af5ef34fa3d208f8"


def result(code, capex, costs, upgrade=0.0, unserved=0, discount=.1, name=None):
    annual = [dict(total_cash_cost=c, net_opex=c, served_mwh=100.0) for c in costs]
    npc = capex + upgrade + sum(c / (1 + discount) ** (i + 1) for i, c in enumerate(costs))
    return dict(code=code, name=name or code, adequacy=dict(unserved_hours=unserved, unserved_mwh=unserved * 1.5, stress_unserved_mwh=0),
                economics=dict(capex=capex, upgrade_pv=upgrade, npc=npc, annual=annual))


class CashflowMath(unittest.TestCase):
    def test_npv_irr_paybacks(self):
        m = em.metrics([-100, 60, 60], .06)
        self.assertAlmostEqual(m["npv"], -100 + 60 / 1.06 + 60 / 1.06 ** 2)  # 10.0035
        self.assertAlmostEqual(m["irr"], .1306623863, places=8)
        self.assertAlmostEqual(m["simple_payback_years"], 1 + 40 / 60)
        # discounted: -100 + 56.60377 = -43.39623; year 2 adds 53.39978
        self.assertAlmostEqual(m["discounted_payback_years"], 1 + 43.396226 / 53.399786, places=5)
        self.assertEqual(m["irr_note"], "")

    def test_no_sign_change_gives_reason(self):
        m = em.metrics([-100, -5, -5], .06)
        self.assertIsNone(m["irr"])
        self.assertIn("No sign change", m["irr_note"])
        self.assertIsNone(m["simple_payback_years"])
        self.assertIn("Not within the 2-year horizon", m["simple_payback_note"])

    def test_no_investment_is_immediate_with_reason(self):
        m = em.metrics([70, 5, 5], .06)
        self.assertIsNone(m["irr"])
        self.assertIn("No additional investment", m["irr_note"])
        self.assertEqual(m["simple_payback_years"], 0.0)
        self.assertEqual(m["discounted_payback_years"], 0.0)

    def test_payback_beyond_horizon_and_multiple_roots(self):
        self.assertIsNone(em.payback([-100, 5, 5])[0])
        irr, note = em.solve_irr([-100, 230, -132])  # NPV(r)=0 at 10% and 20%
        self.assertAlmostEqual(irr, .10, places=6)
        self.assertIn("Multiple IRRs", note)

    def test_irr_high_return(self):
        irr, _ = em.solve_irr([-1, 11])
        self.assertAlmostEqual(irr, 10.0, places=8)


class Incremental(unittest.TestCase):
    values = dict(discount=.1, inflation=.02, start_year=2027)

    def setUp(self):
        self.ref = result("R0", 100, [20, 20, 20, 20])
        self.alt = result("A", 25, [10, 10, 10, 10])

    def test_missing_grid_only_reference_falls_back_with_a_note(self):
        out = em.evaluate([result("A", 25, [10] * 4), result("B", 30, [9] * 4)], dict(discount=.1, start_year=2027), None)
        self.assertEqual(out["reference"], "A")
        self.assertTrue(any("No grid-only reference" in w for w in out["warnings"]))
        out = em.evaluate([result("R0", 100, [20] * 4), result("A", 25, [10] * 4)], dict(discount=.1, start_year=2027), None)
        self.assertEqual(out["reference"], "R0")
        self.assertFalse(any("No grid-only reference" in w for w in out["warnings"]))

    def test_net_and_operating_basis(self):
        out = em.evaluate([self.ref, self.alt], self.values, "R0")
        alt = out["scenarios"][1]
        self.assertEqual(out["scenarios"][0]["status"], "reference")
        self.assertEqual(alt["investment"], -75)
        self.assertEqual(alt["net"]["cashflows"], [75, 10, 10, 10, 10])
        self.assertAlmostEqual(alt["net"]["npv"], 75 + 10 * 3.169865, places=4)
        self.assertAlmostEqual(alt["net"]["npv"], self.ref["economics"]["npc"] - self.alt["economics"]["npc"], places=6)
        self.assertIsNone(alt["net"]["irr"])
        self.assertEqual(alt["net"]["simple_payback_years"], 0.0)
        op = alt["operating"]
        self.assertEqual(op["cashflows"], [-25, 10, 10, 10, 10])
        self.assertAlmostEqual(op["npv"], -25 + 31.69865, places=4)
        self.assertAlmostEqual(op["simple_payback_years"], 2.5)
        self.assertAlmostEqual(op["discounted_payback_years"], 3 + 0.131476 / 6.830135, places=4)
        self.assertAlmostEqual(sum(10 / (1 + op["irr"]) ** t for t in range(1, 5)), 25, places=6)
        self.assertEqual(out["calendar_years"], [2026, 2027, 2028, 2029, 2030])
        self.assertAlmostEqual(op["cumulative_discounted"][-1], op["npv"])

    def test_not_within_horizon_and_unserved_flag(self):
        slow = result("B", 60, [10, 10, 10, 10])
        shortage = result("C", 10, [5, 5, 5, 5], unserved=3)
        out = em.evaluate([self.ref, slow, shortage], self.values, "R0")
        b, c = out["scenarios"][1], out["scenarios"][2]
        self.assertIsNone(b["operating"]["simple_payback_years"])  # 4 x 10 < 60
        self.assertIn("Not within", b["operating"]["simple_payback_note"])
        self.assertFalse(c["adequate"])
        self.assertTrue(any("Not equivalent service" in w for w in c["warnings"]))
        self.assertIsNotNone(c["net"]["npv"])

    def test_alternative_reference_and_residual(self):
        out = em.evaluate([self.ref, self.alt], self.values, "A")
        self.assertEqual(out["reference"], "A")
        self.assertEqual(out["scenarios"][0]["net"]["cashflows"], [-75, -10, -10, -10, -10])
        self.assertIn("never pays back", out["scenarios"][0]["net"]["irr_note"])
        self.alt["economics"]["residual_value_pv"] = 14.641 / 1.1 ** 4 * 1.0
        withres = em.evaluate([self.ref, self.alt], self.values, "R0", include_residual=True)
        self.assertAlmostEqual(withres["scenarios"][1]["net"]["cashflows"][-1], 10 + 14.641 / 1.1 ** 4 * 1.1 ** 4)


    def test_carbon_avoided_against_reference(self):
        ref, alt = self.ref, self.alt
        for r, tonnes in ((ref, 1000.0), (alt, 600.0)):
            for a in r["economics"]["annual"]:
                a["net_co2e_after_heat_credit_t"] = tonnes / 4
        out = em.evaluate([ref, alt], dict(self.values, grid_emissions_t_mwh=.2), "R0")
        self.assertTrue(out["carbon_available"])
        self.assertAlmostEqual(out["scenarios"][0]["co2e_t"], 1000)
        self.assertAlmostEqual(out["scenarios"][1]["co2e_avoided_t"], 400)
        self.assertIsNone(out["scenarios"][0]["co2e_avoided_t"])
        self.assertAlmostEqual(em.flat_rows(out)[1]["co2e_avoided_t"], 400)

    def test_carbon_unavailable_when_factors_unconfirmed(self):
        for a in self.alt["economics"]["annual"]:
            a["net_co2e_after_heat_credit_t"] = None
        out = em.evaluate([self.ref, self.alt], self.values, "R0")
        self.assertIsNone(out["scenarios"][1]["co2e_t"])
        self.assertIsNone(out["scenarios"][1]["co2e_avoided_t"])

    def test_payback_requires_cumulative_to_stay_positive(self):
        # replacement outlay in year 3 pushes the cumulative back below zero; payback is the last crossing
        years, note = em.payback([-100, 120, -50, 120])
        self.assertAlmostEqual(years, 2 + 30 / 120)
        self.assertEqual(note, "")


@unittest.skipUnless(USER_RUN.is_dir(), "user run not available")
class UserRunApi(unittest.TestCase):
    def test_every_scenario_has_metrics_on_copy_of_user_run(self):
        run_id = USER_RUN.name
        with tempfile.TemporaryDirectory() as tmp:
            copy = Path(tmp) / run_id
            copy.mkdir()
            for name in ["status.json", "summary.json", "run_configuration.json"]:
                shutil.copy(USER_RUN / name, copy / name)
            for path in USER_RUN.glob("result_*.json"):
                shutil.copy(path, copy / path.name)
            original = extensions.RUNS
            extensions.RUNS = Path(tmp)
            try:
                data = extensions.GET["economics"]({"run_id": [run_id]})
                json.dumps(data)
                alt = extensions.GET["economics"]({"run_id": [run_id], "reference": ["P1"], "residual": ["1"]})
            finally:
                extensions.RUNS = original
        self.assertEqual(data["reference"], "R0")
        by = {s["code"]: s for s in data["scenarios"]}
        self.assertEqual(by["R0"]["status"], "reference")
        for code in ("P1", "H2", "NG", "S1", "S2"):
            s = by[code]
            self.assertAlmostEqual(s["net"]["npv"], by["R0"]["npc"] - s["npc"], delta=1)
            self.assertIsNone(s["net"]["irr"])
            self.assertEqual(s["net"]["simple_payback_years"], 0.0)
            self.assertTrue(s["net"]["irr_note"])
            self.assertEqual(len(s["operating"]["cashflows"]), data["horizon_years"] + 1)
            self.assertTrue(s["operating"]["irr"] is not None or s["operating"]["irr_note"])
        self.assertFalse(by["S1"]["adequate"])
        self.assertTrue(by["S1"]["warnings"])
        self.assertEqual(alt["reference"], "P1")
        self.assertIsNone({s["code"]: s for s in alt["scenarios"]}["P1"].get("net"))
        self.assertEqual(data["recommended_code"], workflow.get(run_id)["recommended"]["code"])
        self.assertIn(data["recommended_code"], by)


class WorkedExample(unittest.TestCase):
    """Reference costs 100 up front and 20/yr; the alternative costs 25 up front and 10/yr (4 years, 10%)."""

    def test_cheaper_alternative_reports_upfront_saving(self):
        out = em.evaluate([result("R0", 100, [20] * 4), result("A", 25, [10] * 4)], dict(discount=.1, start_year=2027))
        a = next(s for s in out["scenarios"] if s["code"] == "A")
        annuity = sum(10 / 1.1 ** t for t in range(1, 5))  # 31.6987
        self.assertAlmostEqual(a["net"]["npv"], 75 + annuity, places=6)  # 106.6987
        self.assertAlmostEqual(a["upfront_saving"], 75)
        self.assertIsNone(a["net"]["irr"])
        self.assertIn("No additional investment", a["net"]["irr_note"])
        self.assertEqual(a["net"]["simple_payback_years"], 0.0)
        self.assertAlmostEqual(a["operating"]["npv"], -25 + annuity, places=6)  # 6.6987
        self.assertAlmostEqual(a["operating"]["simple_payback_years"], 2.5)

    def test_more_expensive_alternative_has_normal_irr(self):
        out = em.evaluate([result("R0", 100, [20] * 4), result("A", 160, [5] * 4)], dict(discount=.1, start_year=2027))
        a = next(s for s in out["scenarios"] if s["code"] == "A")
        self.assertEqual(a["upfront_saving"], 0.0)
        self.assertAlmostEqual(a["net"]["npv"], -60 + 15 * sum(1 / 1.1 ** t for t in range(1, 5)), places=6)
        self.assertAlmostEqual(sum(c / (1 + a["net"]["irr"]) ** t for t, c in enumerate(a["net"]["cashflows"])), 0, places=6)
        self.assertAlmostEqual(a["net"]["simple_payback_years"], 4.0)


if __name__ == "__main__":
    unittest.main()
