import json
import shutil
import unittest
from pathlib import Path

import explain
import summary_data as S
import summary_pdf

HERE = Path(__file__).parent
USER_RUN = HERE / "Application Runs" / "7791be18470745f8af5ef34fa3d208f8"


def result(npc, capex=0, upgrade=0, annual=None, caps=None):
    return dict(code="X", name="X", caps=caps or {}, economics=dict(npc=npc, capex=capex, upgrade_pv=upgrade, annual=annual or []))


class FormatTests(unittest.TestCase):
    def test_money_and_numbers_use_separators_and_at_most_four_decimals(self):
        self.assertEqual(S.usd(149669439.3), "$149.67M")
        self.assertEqual(S.usd(-2192377.9), "-$2.19M")
        self.assertEqual(S.usd(52000), "$52.00k")
        self.assertEqual(S.num(26630.94, 0), "26,631")
        self.assertEqual(S.num(None), "n/a")
        self.assertEqual(S.pct(0.14024), "14.0%")


class MetricTests(unittest.TestCase):
    def test_upfront_includes_the_grid_upgrade(self):
        self.assertEqual(explain.upfront(dict(capex=0, upgrade_pv=70e6)), 70e6)
        self.assertEqual(explain.upfront(dict(capex=11.9e6)), 11.9e6)

    def test_renewable_share_counts_solar_wind_and_planned_over_demand(self):
        rows = [dict(demand_mwh=100, optimized_solar_mwh=10, wind_generation_mwh=5, planned_renewable_mwh=5),
                dict(demand_mwh=100, optimized_solar_mwh=20, planned_renewable_mwh=0)]
        self.assertAlmostEqual(S.renewable_share(result(1, annual=rows)), 40 / 200)
        self.assertIsNone(S.renewable_share(result(1, annual=[])))

    def test_average_annual_saving_is_reference_minus_option(self):
        ref = result(1, annual=[dict(total_cash_cost=10), dict(total_cash_cost=12)])
        opt = result(1, annual=[dict(total_cash_cost=7), dict(total_cash_cost=8)])
        self.assertEqual(S.avg_annual_saving(opt, ref), 3.5)

    def test_peak_grid_import_uses_the_larger_of_quarter_hour_and_hourly(self):
        r = result(1, annual=[dict(grid_peak_mw=30), dict(grid_peak_mw=35)])
        r["validation"] = dict(max_quarter_hour_grid_mw=36)
        self.assertEqual(S.peak_grid_import(r), 36)
        self.assertEqual(S.peak_grid_import(result(1, annual=[dict(grid_peak_mw=30)])), 30)

    def test_battery_use_reports_cycles_from_dispatch(self):
        use = explain.battery_use(dict(annual=[dict(bess_discharge_mwh=100), dict(bess_discharge_mwh=140)]), dict(bess_mwh=10))
        self.assertEqual(use, (120, 12))
        self.assertIsNone(explain.battery_use(dict(annual=[]), dict(bess_mwh=10)))


class ReferenceTests(unittest.TestCase):
    def test_explain_uses_the_run_comparison_reference(self):
        folder = HERE / "_test_summary_ref"
        folder.mkdir(exist_ok=True)
        try:
            (folder / "result_R1.json").write_text("{}", encoding="utf-8")
            (folder / "request.json").write_text(json.dumps({"comparison_reference": "R1"}), encoding="utf-8")
            self.assertEqual(explain.reference_code(folder), "R1")
            (folder / "request.json").write_text(json.dumps({}), encoding="utf-8")
            self.assertIsNone(explain.reference_code(folder))
        finally:
            shutil.rmtree(folder, ignore_errors=True)


@unittest.skipUnless(USER_RUN.is_dir(), "user run not available")
class UserRunTests(unittest.TestCase):
    def setUp(self):
        self.data = S.build(USER_RUN.name)
        self.kpi = {k["key"]: k for k in self.data["kpis"]}

    def test_dashboard_matches_independently_computed_numbers(self):
        n = json.loads((USER_RUN / "result_NG.json").read_text(encoding="utf-8"))
        r = json.loads((USER_RUN / "result_R0.json").read_text(encoding="utf-8"))
        saving = sum(b["total_cash_cost"] - a["total_cash_cost"] for a, b in zip(n["economics"]["annual"], r["economics"]["annual"])) / 10
        self.assertEqual(self.data["recommended"]["code"], "NG")
        self.assertEqual(self.kpi["saving"]["value"], S.usd(saving))
        self.assertEqual(self.kpi["upfront"]["value"], S.usd(n["economics"]["capex"] + n["economics"]["upgrade_pv"]))
        self.assertEqual(self.kpi["unserved"]["value"], "0.00 MWh")

    def test_every_analysis_has_a_status_and_the_shortage_scenario_is_excluded(self):
        self.assertEqual([a["key"] for a in self.data["analyses"]], ["economic", "technical", "sensitivity", "reliability"])
        s1 = next(row for row in self.data["table"] if row["code"] == "S1")
        self.assertIsNone(s1["rank"])
        self.assertTrue(any("S1" in w["text"] for w in self.data["warnings"]))
        self.assertEqual(self.data["table"][0]["rank"], 1)

    def test_detail_carries_economic_sensitivity_and_reliability_results(self):
        detail = self.data["detail"]
        npc = {r["code"]: r["npc"] for r in detail["economic"]["rows"]}
        n = json.loads((USER_RUN / "result_NG.json").read_text(encoding="utf-8"))
        self.assertAlmostEqual(npc["NG"], n["economics"]["npc"] / 1e6, places=6)
        self.assertTrue(detail["sensitivity"]["swings"])
        self.assertTrue(detail["reliability"])

    def test_why_text_is_conditional_and_states_ranking_basis(self):
        text = " ".join(self.data["recommended"]["why"])
        self.assertNotIn("pays for the new equipment", text)
        self.assertNotIn("shave peak", text)
        self.assertIn("remark only", text)

    def test_summary_pdf_has_at_most_three_pages(self):
        import re
        pdf = summary_pdf.build(USER_RUN.name)
        pages = len(re.findall(rb"/Type\s*/Page(?![a-z])", pdf))
        self.assertTrue(1 <= pages <= 3, pages)


if __name__ == "__main__":
    unittest.main()
