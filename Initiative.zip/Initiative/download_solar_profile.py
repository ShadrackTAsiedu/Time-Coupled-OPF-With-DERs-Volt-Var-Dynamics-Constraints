"""Download public JRC TMY radiation and export a Los Angeles fixed-PST POA profile."""

import csv
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import sys
from urllib.request import urlopen

import numpy as np
import pandas as pd
import pvlib


def main():
    directory = Path(__file__).resolve().parent / "Solar Profile Inputs"
    directory.mkdir(exist_ok=True)
    url = "https://re.jrc.ec.europa.eu/api/v5_3/tmy?lat=34.0522&lon=-118.2437&outputformat=json"
    cached = directory / "los_angeles_pvgis_tmy_source.json"
    if cached.is_file() and "--refresh" not in sys.argv:
        raw = cached.read_bytes()
    else:
        with urlopen(url, timeout=120) as response:
            raw = response.read()
    data = json.loads(raw)
    cached.write_bytes(raw)
    rows = data["outputs"]["tmy_hourly"]
    utc = pd.date_range("2001-01-01", periods=len(rows), freq="h", tz="UTC")
    local = utc.tz_convert("Etc/GMT+8")
    # PVGIS ERA5 irradiance is offset from its hourly label, as disclosed by the API.
    offset = data["inputs"]["location"]["irradiance_time_offset"]
    position = pvlib.solarposition.get_solarposition(
        utc + pd.Timedelta(hours=offset), 34.0522, -118.2437, altitude=89)
    poa = pvlib.irradiance.get_total_irradiance(
        surface_tilt=30, surface_azimuth=180, solar_zenith=position["apparent_zenith"].to_numpy(),
        solar_azimuth=position["azimuth"].to_numpy(),
        dni=np.array([r["Gb(n)"] for r in rows]), ghi=np.array([r["G(h)"] for r in rows]),
        dhi=np.array([r["Gd(h)"] for r in rows]), albedo=.2, model="isotropic")["poa_global"]
    if not np.all(np.isfinite(poa)) or len(poa) != 8760:
        raise ValueError("The downloaded TMY did not produce a finite complete hourly POA profile.")
    template = {(d.month, d.day, d.hour): (max(0, float(p)), r)
                for d, p, r in zip(local, poa, rows)}
    output = directory / "los_angeles_solar_hourly_2025_2026.csv"
    with output.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow(["timestamp", "poa_irradiance_w_m2", "ghi_w_m2", "dni_w_m2", "dhi_w_m2",
                         "temperature_c", "wind_speed_ms", "source_type", "time_basis"])
        start = datetime(2025, 9, 1)
        for hour in range(8760):
            date = start + timedelta(hours=hour)
            irradiance, row = template[(date.month, date.day, date.hour)]
            writer.writerow([date.isoformat(sep=" "), f"{irradiance:.6f}", row["G(h)"],
                             row["Gb(n)"], row["Gd(h)"], row["T2m"], row["WS10m"],
                             "PVGIS-ERA5 TMY; not observed 2025-2026", "fixed PST UTC-08; no DST"])
    metadata = dict(source_url=url, source_sha256=hashlib.sha256(raw).hexdigest(),
                    inputs=data["inputs"], months_selected=data["outputs"]["months_selected"],
                    tilt_degrees=30, azimuth_degrees=180, albedo=.2, transposition="pvlib isotropic",
                    pvlib_version=pvlib.__version__, time_basis="fixed PST UTC-08; no DST",
                    period="2025-09-01 00:00 to 2026-08-31 23:00", rows=8760,
                    warning="Typical meteorological year, not measured radiation in the labeled year. "
                            "The file is a weather resource (irradiance W/m2, air temperature C, 10 m wind speed m/s); "
                            "PV output is computed in the model (cell temperature, losses, inverter limit). "
                            "Generic fixed tilt, not a site survey.",
                    csv_sha256=hashlib.sha256(output.read_bytes()).hexdigest())
    (directory / "los_angeles_solar_provenance.json").write_text(json.dumps(metadata, indent=2))
    print(output)
    print("POA mean W/m2:", np.mean(poa))


if __name__ == "__main__":
    main()
