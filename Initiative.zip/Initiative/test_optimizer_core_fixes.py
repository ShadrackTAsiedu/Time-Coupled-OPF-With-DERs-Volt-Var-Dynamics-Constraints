"""Regression tests for optimization-core fixes: tariff windows, residual value, capacity-limit handling."""

import unittest
from datetime import datetime

import numpy as np

import lifecycle_costs
import optimize_generation_mix as model
import planning_tariffs
import test_decomposition_reference as reference


def tariff_values(**overrides):
    values = dict(summer_start_month=6, summer_end_month=9, peak_start_hour=16, peak_end_hour=21,
                  mid_start_hour=7, mid_end_hour=16, weekend_mid_peak=False, tariff_mode="tou",
                  blended_kwh=0.1, summer_same=False, winter_same=False, reactive_enabled=False,
                  reactive_rate=0, reactive_ratio=0)
    for season, base in (("summer", 0.2), ("winter", 0.1)):
        values.update({f"{season}_off_kwh": base, f"{season}_mid_kwh": base * 2, f"{season}_peak_kwh": base * 3})
    values.update(overrides)
    return values


class TariffWindows(unittest.TestCase):
    def test_overnight_peak_and_wrapping_summer(self):
        dates = [datetime(2027, m, 1, h) for m in (1, 7, 11) for h in (3, 12, 23)]
        result = planning_tariffs.tariffs(dates, tariff_values(
            peak_start_hour=22, peak_end_hour=6, mid_start_hour=6, mid_end_hour=22,
            summer_start_month=11, summer_end_month=3))
        bands = list(result["tariff_band"])
        self.assertEqual(bands, ["peak", "mid", "peak"] * 3)
        energy = result["grid_energy"]
        self.assertAlmostEqual(energy[0], 0.2 * 3 * 1000)
        self.assertAlmostEqual(energy[3], 0.1 * 3 * 1000)
        self.assertAlmostEqual(energy[4], 0.1 * 2 * 1000)
        self.assertAlmostEqual(energy[7], 0.2 * 2 * 1000)
        self.assertAlmostEqual(energy[8], 0.2 * 3 * 1000)

    def test_ordinary_windows_unchanged(self):
        dates = [datetime(2027, 7, 1, h) for h in (6, 7, 15, 16, 20, 21)]
        bands = list(planning_tariffs.tariffs(dates, tariff_values())["tariff_band"])
        self.assertEqual(bands, ["off", "mid", "mid", "peak", "peak", "off"])


class ResidualValue(unittest.TestCase):
    def setUp(self):
        self.cfg = model.default_settings()
        self.caps = dict(pv_dc_mw=10.0, bess_mw=0.0, bess_mwh=0.0, generator_mw=0.0, generators_mw={})

    def test_uses_configured_life_without_replacements(self):
        self.cfg.update(include_replacements=False, pv_life=20)
        value = lifecycle_costs.residual_value(self.caps, self.cfg, 10)
        self.assertAlmostEqual(value, 10 * self.cfg["pv_capex"] * 10 / 20)

    def test_replaced_asset_keeps_remaining_life_at_escalated_cost(self):
        self.cfg.update(include_replacements=True, pv_life=15, replacement_fraction=0.5, inflation=0.02)
        value = lifecycle_costs.residual_value(self.caps, self.cfg, 20)
        expected = 10 * self.cfg["pv_capex"] * 0.5 * 1.02**15 * (15 - 5) / 15
        self.assertAlmostEqual(value, expected, places=4)

    def test_fully_used_asset_has_no_residual(self):
        self.cfg.update(include_replacements=False, pv_life=10)
        self.assertEqual(lifecycle_costs.residual_value(self.caps, self.cfg, 10), 0.0)


class CapacityLimits(unittest.TestCase):
    def setUp(self):
        self.data = reference.short_data()
        self.case = reference.DecompositionAgainstMonolithic()

    def test_microgrid_minimum_is_enforced_without_a_maximum(self):
        cfg, names = self.case.settings(["grid", "pv", "bess"])
        cfg.update(microgrid_min_mw=6.0, microgrid_max_mw=None)
        result = model.solve_decomposed(self.data, "X", "min only", names, settings=cfg)
        self.assertGreaterEqual(result["caps"]["microgrid_total_ac_mw"], 6.0 - 1e-6)

    def test_pv_connection_big_m_allows_dc_oversizing(self):
        cfg, names = self.case.settings(["grid", "pv"], cheap=True)
        cfg.update(microgrid_min_mw=0.0, microgrid_max_mw=5.0, pv_max=100.0, dc_ac=1.4, allow_unserved=True)
        cfg["connection_charge_by_technology"] = {}
        result = model.solve_decomposed(self.data, "X", "dc oversize", names, settings=cfg)
        self.assertLessEqual(result["caps"]["microgrid_total_ac_mw"], 5.0 + 1e-6)
        self.assertGreater(result["caps"]["pv_dc_mw"], 5.0)

    def test_inconsistent_limits_message(self):
        cfg, names = self.case.settings(["grid", "pv"])
        cfg.update(microgrid_min_mw=500.0, microgrid_max_mw=600.0)
        with self.assertRaisesRegex(ValueError, "capacity limits are inconsistent"):
            model.solve_decomposed(self.data, "X", "infeasible", names, settings=cfg)


if __name__ == "__main__":
    unittest.main()
