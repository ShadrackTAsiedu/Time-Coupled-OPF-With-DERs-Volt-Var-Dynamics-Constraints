"""One recommended scenario and one NPC per scenario for every consumer (charts, tables, summary, reports)."""
import tempfile
import unittest
from pathlib import Path

import dispatch_view
import economic_metrics
import generation_app
import report
import summary_data
import workflow

REAL_RUN = "9938f7b4c8024c379e9f4196f52c9be3"  # re-solve where NG looked cheaper before its applied corrections were counted


def result(code, npc, applied=0.0):
    return dict(code=code, name=code, case="Reference" if code == "R0" else "Scenario", eligible_technologies=["grid"], caps={},
                economics=dict(npc=npc), adequacy=dict(unserved_hours=0, stress_unserved_mwh=0, unserved_mwh=0),
                applied_corrections=dict(total_usd=applied, items=[]))


class SyntheticRun(unittest.TestCase):
    def test_applied_corrections_decide_the_winner_everywhere(self):
        results = [result("R0", 217.9e6), result("P1", 145.398e6), result("NG", 145.32e6, applied=1.969e6)]
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            rec = workflow.recommendation(folder, results)
            self.assertEqual(rec["code"], "P1")
            self.assertAlmostEqual(rec["totals"]["NG"], 147.289e6, places=0)
            by_code = {r["code"]: r for r in results}
            self.assertEqual(report.pick_best(by_code, folder), ("P1", True))
            self.assertEqual(dispatch_view.recommended_code(folder, results), "P1")
            self.assertEqual(economic_metrics.recommended_code(folder, results), "P1")
            status = dict(state="complete", summary=dict(results=results))
            tagged = generation_app.with_recommendation(status, folder)["summary"]
            self.assertEqual(tagged["recommended_code"], "P1")
            self.assertEqual([r["code"] for r in tagged["results"] if r["is_recommended"]], ["P1"])
            self.assertAlmostEqual(next(r for r in tagged["results"] if r["code"] == "NG")["total_npc"], 147.289e6, places=0)
            self.assertEqual(report.total_npc(by_code["NG"]), workflow.total_npc(by_code["NG"]))

    def test_unfinished_status_is_not_tagged(self):
        status = dict(state="running", summary=dict(results=[result("P1", 1.0)]))
        self.assertIs(generation_app.with_recommendation(status, Path(".")), status)


@unittest.skipUnless((generation_app.RUNS / REAL_RUN / "workflow.json").is_file(), "saved user run not available")
class UserRerun(unittest.TestCase):
    def test_every_consumer_agrees_after_the_resolve(self):
        folder = generation_app.RUNS / REAL_RUN
        run = report.load_run(REAL_RUN)
        wf = workflow.get(REAL_RUN)
        expected = wf["recommended"]["code"]
        self.assertEqual(expected, "P1")
        results = list(run["results"].values())
        self.assertEqual(report.pick_best(run["results"], folder)[0], expected)
        self.assertEqual(dispatch_view.recommended_code(folder, results), expected)
        self.assertEqual(economic_metrics.for_run(folder)["recommended_code"], expected)
        self.assertEqual(summary_data.build(REAL_RUN)["recommended"]["code"], expected)
        totals = {e["code"]: e["total_npc"] for e in wf["scenarios"]}
        for r in results:
            self.assertAlmostEqual(workflow.total_npc(r), totals[r["code"]], places=0)
        status = generation_app.read_json_retry(folder / "status.json")
        tagged = generation_app.with_recommendation(status, folder)["summary"]
        self.assertEqual(tagged["recommended_code"], expected)
        self.assertAlmostEqual(next(r for r in tagged["results"] if r["code"] == "NG")["total_npc"] / 1e6, 147.289, places=3)


if __name__ == "__main__":
    unittest.main()
