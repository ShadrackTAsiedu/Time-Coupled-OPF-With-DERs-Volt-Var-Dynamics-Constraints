import json
import shutil
import socket
import subprocess
import sys
import time
import unittest
import uuid
from pathlib import Path
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / "Application Runs"


def source_run():
    """Newest finished run that has per-scenario dispatch data; read-only source for the copy."""
    candidates = []
    for folder in RUNS.iterdir() if RUNS.exists() else []:
        status = folder / "status.json"
        if status.exists() and list(folder.glob("dispatch_*.csv")) and (folder / "cost_comparison.png").exists():
            candidates.append((status.stat().st_mtime, folder))
    return max(candidates)[1] if candidates else None


class InteractiveChartsTest(unittest.TestCase):
    def test_result_charts_are_interactive_and_export(self):
        source = source_run()
        if source is None:
            self.skipTest("no finished run available")
        run_id = uuid.uuid4().hex
        target = RUNS / run_id
        shutil.copytree(source, target)
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        self.assertNotEqual(port, 8765)
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)], cwd=ROOT,
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(60):
                try:
                    urlopen(base + "/", timeout=2).read()
                    break
                except Exception:
                    time.sleep(0.5)
            with sync_playwright() as p:
                browser = p.chromium.launch(channel="msedge", headless=True)
                context = browser.new_context(viewport={"width": 1500, "height": 1000}, accept_downloads=True)
                page = context.new_page()
                errors = []
                page.on("pageerror", lambda e: errors.append(str(e)))
                page.goto(f"{base}/?run={run_id}")
                page.wait_for_timeout(3000)
                page.get_by_role("button", name="SOLVE", exact=True).click()
                page.wait_for_function("() => document.querySelectorAll('#result-charts .gs-chart svg').length >= 4", timeout=60000)
                charts = page.locator("#result-charts .gs-chart")
                self.assertGreaterEqual(charts.count(), 4)
                for action in ["png", "svg", "csv", "reset", "fullscreen"]:
                    self.assertGreater(charts.first.locator(f"[data-gs-action='{action}']").count(), 0, action)
                self.assertGreater(page.locator("#result-charts .gs-chart svg rect, #result-charts .gs-chart svg path").count(), 10)
                page.wait_for_function("() => document.querySelectorAll('#dispatch-full svg path').length > 0", timeout=60000)
                self.assertGreater(page.locator("#dispatch-full [data-gs-action='png']").count(), 0)
                with page.expect_download() as info:
                    charts.first.locator("[data-gs-action='png']").click()
                path = info.value.path()
                Path(ROOT / "Application Runs" / run_id / "export.png").write_bytes(Path(path).read_bytes())
                data = Path(path).read_bytes()
                self.assertGreater(len(data), 5000)
                self.assertEqual(data[:8], b"\x89PNG\r\n\x1a\n")
                width = int.from_bytes(data[16:20], "big")
                self.assertGreaterEqual(width, 3000)
                with page.expect_download() as info:
                    charts.first.locator("[data-gs-action='csv']").click()
                self.assertGreater(Path(info.value.path()).stat().st_size, 20)
                with page.expect_download() as info:
                    charts.first.locator("[data-gs-action='svg']").click()
                self.assertIn(b"<svg", Path(info.value.path()).read_bytes())
                self.assertEqual(errors, [])
                browser.close()
        finally:
            server.terminate()
            server.wait(timeout=10)
            shutil.rmtree(target, ignore_errors=True)


class ChartLibraryEdgeCaseTest(unittest.TestCase):
    def test_empty_single_point_legend_keyboard_and_favicon(self):
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)], cwd=ROOT,
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(60):
                try:
                    urlopen(base + "/", timeout=2).read()
                    break
                except Exception:
                    time.sleep(0.5)
            self.assertIn(b"<svg", urlopen(base + "/favicon.svg", timeout=5).read())
            with sync_playwright() as p:
                browser = p.chromium.launch(channel="msedge", headless=True)
                page = browser.new_page(viewport={"width": 1200, "height": 800})
                errors = []
                page.on("pageerror", lambda e: errors.append(str(e)))
                page.goto(base + "/")
                page.wait_for_function("() => window.GS && window.GS.chart")
                result = page.evaluate("""() => {
                    const host = document.createElement('div'); host.style.width = '900px'; document.body.append(host);
                    const mk = spec => { const c = GS.chart(spec); host.append(c.el); return c; };
                    const empty = mk({kind: 'time', title: 'Empty', xKind: 'time', x: [], series: []});
                    const single = mk({kind: 'time', title: 'Single', xKind: 'time', x: [Date.UTC(2030, 0, 1)],
                        series: [{key: 'a', label: 'A', values: [5], color: '#0a7'}, {key: 'b', label: 'B', values: [2], color: '#a70'}]});
                    const item = single.el.querySelector('g[role=button]');
                    const before = item.getAttribute('aria-pressed');
                    item.dispatchEvent(new KeyboardEvent('keydown', {key: 'Enter', bubbles: true}));
                    const after = single.el.querySelector('g[role=button]').getAttribute('aria-pressed');
                    return {emptyText: empty.el.textContent.includes('No data to display'), before, after,
                            paths: single.el.querySelectorAll('svg path').length};
                }""")
                self.assertTrue(result["emptyText"])
                self.assertEqual((result["before"], result["after"]), ("true", "false"))
                self.assertEqual(errors, [])
                browser.close()
        finally:
            server.terminate()
            server.wait(timeout=10)


if __name__ == "__main__":
    unittest.main()
