import json
import unittest
import xml.dom.minidom
from pathlib import Path

import design
import extensions

RUN = "25253846a35d4d2583767b43da6bd098"
HAS_RUN = (Path(__file__).parent / "Application Runs" / RUN / "status.json").is_file()


class StandardRatings(unittest.TestCase):
    def test_std_rating(self):
        self.assertEqual(design.std_rating(8.1, design.STD_MAIN_MVA), 10)
        self.assertEqual(design.std_rating(12, design.STD_MAIN_MVA), 12)
        self.assertIsNone(design.std_rating(500, design.STD_MAIN_MVA))

    def test_main_transformer_plan(self):
        self.assertEqual(design.main_transformer_plan(18), (1, 20))
        n, each = design.main_transformer_plan(150)
        self.assertGreaterEqual(n * each, 150)
        self.assertLessEqual(each, 100)

    def test_block_plan_covers_requirement(self):
        for s in (0.5, 3.0, 9.7, 25.0):
            plan = design.block_plan(s)
            self.assertGreaterEqual(plan["s_total"], s - 1e-9)
            self.assertLess(plan["s_total"], s + max(design.BLOCKS_INV) * 1.01)

    def test_frame_plan(self):
        plan = design.frame_plan(0.763)
        self.assertGreaterEqual(plan["total_mw"], 0.763)
        self.assertEqual(design.frame_plan(9.0)["unit_mw"], 9.0)


class CableChecks(unittest.TestCase):
    def test_voltage_drop_formula(self):
        vd = design.voltage_drop_pct(200, 1.0, 0.2, 0.1, 11.0)
        self.assertAlmostEqual(vd, 3 ** 0.5 * 200 * (0.2 * 0.95 + 0.1 * (1 - 0.95 ** 2) ** 0.5) / 11000 * 100, places=6)

    def test_size_cable_meets_limits(self):
        c = design.size_cable(400, 11.0, 2.0)
        self.assertLessEqual(c["loading_pct"], 100.0)
        self.assertLessEqual(c["vd_pct"], design.CABLE_VD_LIMIT_PCT)
        self.assertLessEqual(c["circuits"], 10)

    def test_short_circuit_minimum_area(self):
        c = design.size_cable(100, 11.0, 0.1, min_area=250)
        self.assertGreaterEqual(c["area"], 300)


@unittest.skipUnless(HAS_RUN, "example run not available")
class ExampleRun(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.d = design.build_design(RUN, "NG")

    def test_best_scenario_is_default(self):
        d = design.build_design(RUN)
        self.assertEqual(d["meta"]["scenario"], d["meta"]["best_scenario"])

    def test_equipment_totals_match_caps(self):
        d = self.d
        caps = json.loads((Path(__file__).parent / "Application Runs" / RUN / "result_NG.json").read_text(encoding="utf-8"))["caps"]
        t = d["totals"]
        pv = t["pv_inverter_mva_installed"]
        self.assertGreaterEqual(pv * design.PF_CAP, t["pv_ac_mw_total"] - 1e-6)
        self.assertLess(pv * design.PF_CAP, t["pv_ac_mw_total"] + 4.2)
        self.assertAlmostEqual(t["pv_dc_mw_new"], caps["pv_dc_mw"], places=3)
        self.assertGreaterEqual(t["bess_pcs_mva_installed"] * design.PF_CAP, caps["bess_mw"] - 1e-6)
        self.assertGreaterEqual(t["bess_containers"] * design.CONTAINER_MWH, caps["bess_mwh"] - 1e-6)
        self.assertGreaterEqual(t["generators_mw_installed"]["ng"], caps["generators_mw"]["ng"] - 1e-6)
        self.assertAlmostEqual(t["bess_mwh_new"], caps["bess_mwh"], places=3)

    def test_feasibility_and_sections(self):
        self.assertIn(self.d["checks"]["status"], ("PASS", "WARN"))
        self.assertFalse(self.d["checks"]["violations"])
        ids = {e["id"] for e in self.d["equipment"]}
        for need in ("UTIL-01", "TR-MAIN", "SWG-MV-01", "PV-INV", "BESS-CONT", "AUX-TR", "PROT-PANELS"):
            self.assertIn(need, ids)
        self.assertTrue(all(r["source"] in ("assumed", "from model", "n/a") for r in self.d["basis"]))

    def test_sld_is_wellformed(self):
        svg = design.sld_svg(self.d)
        xml.dom.minidom.parseString(svg)
        self.assertNotIn("<style", svg)
        self.assertNotIn("<script", svg)

    def test_raw_structure(self):
        raw = design.raw_text(self.d)
        self.assertTrue(raw.endswith("Q\r\n"))
        lines = raw.split("\r\n")
        ends = [i for i, l in enumerate(lines) if l.startswith("0 /")]
        self.assertGreaterEqual(len(ends), 11)
        head = lines[0].split("/")[0].split(",")
        self.assertEqual(int(head[2]), 33)
        sections = {}
        start = 3
        for i in ends:
            sections[lines[i].split("END OF ")[1].split(",")[0]] = lines[start:i]
            start = i + 1
        self.assertTrue(all(len(l.split(",")) == 13 for l in sections["BUS DATA"]))
        self.assertTrue(all(len(l.split(",")) == 14 for l in sections["LOAD DATA"]))
        self.assertTrue(all(len(l.split(",")) == 20 for l in sections["GENERATOR DATA"]))
        self.assertTrue(all(len(l.split(",")) == 18 for l in sections["BRANCH DATA"]))
        tr = sections["TRANSFORMER DATA"]
        self.assertEqual(len(tr) % 4, 0)
        for k in range(0, len(tr), 4):
            self.assertEqual([len(x.split(",")) for x in tr[k:k + 4]], [14, 3, 17, 2])
        nbus = {l.split(",")[0].strip() for l in sections["BUS DATA"]}
        for l in sections["GENERATOR DATA"] + sections["LOAD DATA"]:
            self.assertIn(l.split(",")[0].strip(), nbus)
        names = " ".join(sections["BUS DATA"])
        for n in ("GRID_HV", "SUB_MV", "LOAD_BUS"):
            self.assertIn(n, names)

    def test_api_handlers(self):
        q = {"run_id": [RUN], "scenario": ["NG"]}
        self.assertEqual(extensions.GET["design"](q)["meta"]["scenario"], "NG")
        data, mime = extensions.GET["design_raw"](q)
        self.assertTrue(data.startswith(b"0, 100.00, 33"))
        data, mime = extensions.GET["design_sld"](q)
        self.assertIn("svg", mime)
        with self.assertRaises(ValueError):
            extensions.GET["design"]({})


if __name__ == "__main__":
    unittest.main()
