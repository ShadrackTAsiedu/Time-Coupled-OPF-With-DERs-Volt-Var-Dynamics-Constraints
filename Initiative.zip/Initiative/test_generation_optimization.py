"""Small chronological regression tests; no customer inputs or result files modified."""

import unittest
from datetime import datetime

import numpy as np

import optimize_generation_mix as model


def small_inputs():
    dates = [datetime(y, m, 1, h) for y in range(2027, 2037)
             for m in range(1, 13) for h in range(24)]
    n = len(dates)
    years = np.array([d.year - 2027 for d in dates])
    months = np.array([d.month for d in dates])
    hour = np.array([d.hour for d in dates])
    load = np.where((hour >= 17) & (hour < 21), 44.0, 26.0)
    return dict(
        dates=dates, years=years, months=months,
        mi=years * 12 + months - 1, di=np.arange(n) // 24,
        peak_window=(hour >= 16) & (hour < 21), load=load,
        qmax=load + 0.5, qmin=load - 0.5,
        solar=np.maximum(0, np.sin(np.pi * (hour - 6) / 12)) *
        ((hour >= 6) & (hour <= 18)) * 0.7,
        heat=np.full(n, 5.0), grid_energy=np.full(n, 125.0),
        facility=np.full(120, 13000.0), tou=np.full(120, 9000.0),
        fixed=np.full(120, 5500.0),
    )


class OptimizationTests(unittest.TestCase):
    def setUp(self):
        self.data = small_inputs()

    def test_reference_and_battery_feasibility_and_accounting(self):
        reference = model.solve_decomposed(self.data, "TEST_R", "Test reference", "none", reference=True)
        battery = model.solve_decomposed(self.data, "TEST_P", "Test battery", "none")
        self.assertAlmostEqual(reference["caps"]["pv_dc_mw"], 8)
        self.assertEqual(reference["caps"]["bess_mw"], 0)
        self.assertGreater(battery["caps"]["bess_mw"], 0)
        self.assertLessEqual(battery["validation"]["max_quarter_hour_grid_mw"], 40.00005)
        self.assertLess(battery["validation"]["hourly_balance_error_mw"], 5e-5)
        self.assertEqual(reference["economics"]["upgrade_pv"], 70e6)
        self.assertEqual(battery["economics"]["upgrade_pv"], 0)
        self.assertGreaterEqual(battery["economics"]["npc_zero_heat_credit"],
                                battery["economics"]["npc"] - 1)

    def test_forced_hydrogen_and_chp_heat_limits(self):
        for tech in ("h2", "h2_chp", "ng", "ng_chp"):
            with self.subTest(tech=tech):
                result = model.solve_decomposed(self.data, "TEST_G", "Forced technology", tech, force=True)
                self.assertGreaterEqual(result["caps"]["generator_mw"], 4.99995)
                d = result["dispatch"]
                ratio = model.TECH[tech]["ratio"]
                self.assertTrue(np.all(d["heat"] <= self.data["heat"] + 5e-5))
                self.assertTrue(np.all(d["heat"] <= ratio * d["gen"] + 5e-5))
                self.assertLessEqual(result["validation"]["max_quarter_hour_grid_mw"], 40.00005)

    def test_decomposition_and_shadow_price_supporting_cut(self):
        caps = np.array([10.0, 12.0, 60.0, 0.0])
        sub = model.MonthlyDispatch(self.data, 0, "none", False, self.data["solar"])
        value, gradient = sub.evaluate(caps)
        for trial in (np.array([9.0, 10.0, 50.0, 0.0]),
                      np.array([10.0, 14.0, 70.0, 0.0])):
            trial_value, _ = sub.evaluate(trial)
            self.assertGreaterEqual(trial_value + 1e-7, value + gradient @ (trial - caps))
        result = model.solve_decomposed(self.data, "TEST_D", "Decomposed PV+BESS", "none")
        self.assertLess(result["validation"]["master_gap_usd"], 1000)
        self.assertLess(result["validation"]["max_unserved_load_mw"], 5e-5)
        self.assertLessEqual(result["validation"]["max_quarter_hour_grid_mw"], 40.00005)


if __name__ == "__main__":
    unittest.main()
