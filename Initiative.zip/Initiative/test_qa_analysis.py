"""Regression tests from the analysis-module QA pass."""
import json
import math
import tempfile
import unittest
from pathlib import Path

import data_prep
import explain
import extensions
import reliability
import sensitivity


def rec(label, changes, npc):
    return dict(label=label, changes=changes, ok=True, npc=npc, pv_mw=1, bess_mw=0, bess_mwh=0,
                generators={}, unserved_mwh=0)


class DataPrepNumbers(unittest.TestCase):
    def test_european_thousands(self):
        self.assertAlmostEqual(data_prep.parse_number("1.234,56")[0], 1234.56)
        self.assertAlmostEqual(data_prep.parse_number("1,234.56")[0], 1234.56)
        self.assertAlmostEqual(data_prep.parse_number("12,5")[0], 12.5)


class SensitivityReport(unittest.TestCase):
    def test_tornado_order_and_p10_p90(self):
        ids = [c["id"] for c in sensitivity.CATALOG][:2]
        params = [dict(id=ids[0], low=-10, high=10), dict(id=ids[1], low=-10, high=10)]
        base = dict(npc=100.0, pv_mw=1, bess_mw=0, bess_mwh=0, generators={}, unserved_mwh=0)
        records = [rec("a lo", {ids[0]: -10}, 99), rec("a hi", {ids[0]: 10}, 101),
                   rec("b lo", {ids[1]: -10}, 90), rec("b hi", {ids[1]: 10}, 110),
                   dict(label="bad", changes={}, ok=False, error="x")]
        out = sensitivity.report(base, records, params, "S")
        self.assertEqual([s["id"] for s in out["swings"]], [ids[1], ids[0]])
        z = sensitivity.Z90
        sd = math.sqrt((20 / (2 * z)) ** 2 + (2 / (2 * z)) ** 2)
        self.assertAlmostEqual(out["risk"]["sd"], sd)
        self.assertAlmostEqual(out["risk"]["p90"], 100 + z * sd)
        self.assertAlmostEqual(out["risk"]["p10"], 100 - z * sd)
        self.assertEqual(len(out["failed"]), 1)

    def test_status_race_does_not_report_failure_for_finished_worker(self):
        class Done:
            def poll(self):
                return 0
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            real = extensions.run_folder
            folder = Path(tmp)
            (folder / "sensitivity").mkdir()
            (folder / "sensitivity" / "report.json").write_text("{}", encoding="utf-8")
            path = folder / "sensitivity" / "status.json"
            path.write_text(json.dumps(dict(state="complete")), encoding="utf-8")
            extensions.run_folder = lambda _id: folder
            sensitivity.PROCS[folder.name] = Done()
            try:
                self.assertEqual(sensitivity.status({"run_id": ["x"]})["state"], "complete")
            finally:
                extensions.run_folder = real
                sensitivity.PROCS.pop(folder.name, None)


class ExplainWaterfall(unittest.TestCase):
    def test_steps_sum_to_difference_including_small_items(self):
        src = explain.__file__
        text = Path(src).read_text(encoding="utf-8")
        self.assertIn('"small"', text)
        self.assertIn("re.fullmatch", text)


class ReliabilityGuards(unittest.TestCase):
    def test_missing_dispatch_columns_raise(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            (Path(tmp) / "dispatch_R0.csv").write_text("timestamp,load_mw\n2025-01-01 00:00,1\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                reliability.load_dispatch(Path(tmp), "R0")


if __name__ == "__main__":
    unittest.main()
