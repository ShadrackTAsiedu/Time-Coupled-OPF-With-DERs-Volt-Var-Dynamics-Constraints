"""Detailed microgrid design for ONE selected GenStudio option (the Design tab).

What it does
  build_design(run_id, scenario)  -> structured design dict (design basis, equipment schedule, protection, BOM, checks)
  sld_svg(design)                 -> print-ready single-line diagram (SVG with title block and RAW bus numbers)
  raw_text(design, case)          -> PSS/E v33 RAW of the FINAL design (equivalent plant model by default; detail=detailed gives every
                                     inverter/transformer/feeder as a physical element)
  Routes: GET /api/x/design?run_id=&scenario=&detail=, /api/x/design_raw?...&case=, /api/x/design_sld?...  (detail = equivalent | detailed)

How the design is derived (be clear about what is engineering and what is screening)
  1. Capacities (PV, BESS MW/MWh, generators, wind, planned PV, mobile trailers) come from the solved result_<code>.json and
     the saved request ("from model").  Everything else (voltage levels, ratings, impedances, cable data, protection) is a typical
     value chosen here and tagged "assumed" with a reason.
  2. Equipment is sized with standard ratings (transformers, inverter blocks, containers, switchgear, cables).
  3. The sized network is checked with power_flow.py's Newton-Raphson solver at the critical dispatch hours (peak, minimum load,
     high PV, BESS extremes, genset peak).  An OLTC tap scan, capacitor stages and cable/transformer upsizing are iterated until
     no voltage/loading violation remains (or the remaining violation is reported).
  Limits: positive-sequence steady state, aggregated technologies in the solver (RAW and SLD show every physical unit), typical
  (not OEM) data, no protection coordination, harmonics, transients, earthing grid or civil design.  Not a stamped design.
"""

import datetime
import json
import math
import re
import textwrap
import threading
from pathlib import Path

import numpy as np

import extensions
import power_flow as pf
import unit_pf
SQ3 = math.sqrt(3.0)
TAP_STEP = 0.0125  # +/-10 % in 16 steps (17 positions)
TAP_MAX_POS = 8
PF_CAP = 0.95  # inverter apparent power is sized so full MW is available at this pf

STD_MAIN_MVA = [5, 7.5, 10, 12, 15, 20, 25, 30, 40, 50, 60, 80, 100]  # IEEE C57.12.00 (60 Hz)
STD_MAIN_MVA_IEC = [5, 6.3, 8, 10, 12.5, 16, 20, 25, 31.5, 40, 50, 63, 80, 100]  # IEC 60076 R10 (50 Hz)
STD_SKID_MVA = [1.0, 1.25, 1.6, 2.0, 2.5, 3.15, 4.2, 5.0, 6.3, 8.0, 10.0, 12.5, 16.0]
STD_ISC_KA = [12.5, 16, 20, 25, 31.5, 40, 50, 63]
STD_AMPS = [630, 800, 1000, 1250, 1600, 2000, 2500, 3150, 4000]
STD_AUX_KVA = [100, 160, 250, 400, 630, 800, 1000, 1250, 1600, 2000]
STD_CAP_STAGE = [0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0]
STD_REACTOR = [1.0, 2.0, 3.0, 5.0, 8.0, 10.0, 15.0, 20.0]
STD_NGR_A = [100, 200, 400, 600, 800, 1000]
BLOCKS_INV = [4.2, 3.15, 2.1, 1.0]  # inverter / PCS blocks in MVA
BLOCKS_WIND = [4.5, 3.45, 2.0]  # turbine MW
FRAMES_GEN = [0.5, 1.0, 1.5, 2.0, 3.0, 4.5, 6.0, 9.0, 16.0, 30.0]  # genset / turbine frame MW
CONTAINER_MWH = 3.35  # 20 ft DC block
# (mm2 Al, A buried 20C, r ohm/km AC 90C, x ohm/km) typical 3-core XLPE; see disclaimers
CABLES = [(95, 205, 0.411, 0.113), (150, 260, 0.265, 0.106), (185, 295, 0.211, 0.102), (240, 340, 0.161, 0.099),
          (300, 385, 0.130, 0.097), (400, 440, 0.101, 0.094), (500, 500, 0.081, 0.092), (630, 570, 0.066, 0.090)]
CABLE_DERATE = 0.85
CABLE_VD_LIMIT_PCT = 2.0
CABLE_K_AL = 94.0  # A s^0.5 / mm2, Al XLPE 90C -> 250C
CLEARING_S = 0.5
# Installed cost of a parallel circuit (trench, terminations, bay) expressed as equivalent conductor mm2: a few large cables beat
# many small ones, as in practice.
CIRCUIT_OVERHEAD_MM2 = 300.0
DEFAULT_LEN_KM = dict(incoming=1.0, pv=1.5, bess=0.3, gen=0.3, wind=3.0, load=0.8, trailer=0.4)
LV_KV = 0.69
ACRES_PER_PV_MWAC = 5.0
ACRES_PER_BESS_MWH = 0.05  # 20 MWh/acre incl. PCS/transformer skids, fire clearances and access
ACRES_PER_WIND_MW = 0.75  # permanent pads, roads and substation share
IDS = dict(grid="GRID", hv="SUB_HV", mv="SUB_MV", load="LOAD")
MODELLED = ("pv", "bess", "wind")
DETAILS = ("equivalent", "detailed")
DEFAULT_DETAIL = "equivalent"
DETAIL_LABEL = {"equivalent": "Equivalent (PSS/E study)", "detailed": "Detailed (per-block, for construction)"}


def norm_detail(value):
    """'equivalent' (default) or 'detailed'; anything else is an error so a typo never silently picks a model."""
    if value in (None, ""):
        return DEFAULT_DETAIL
    value = str(value).strip().lower()
    if value not in DETAILS:
        raise ValueError(f"Design detail must be one of {', '.join(DETAILS)}.")
    return value


LIMITATIONS = [
    "Screening-level design: standard ratings and typical impedances are used, not OEM or site-surveyed data.",
    "Balanced positive-sequence steady state: no protection coordination, arc-flash, harmonics, flicker, transients or dynamics.",
    "Grid short-circuit level, utility connection voltage, cable lengths and soil/ambient data are assumptions unless tagged 'from model'; "
    "replace them with the utility's connection offer and a site survey.",
    "The solver aggregates each technology. The default 'Equivalent' RAW/SLD model represents each PV/BESS/wind/generator plant as one "
    "generator and one equivalent step-up transformer (same total MVA and parallel impedance); the 'Detailed' model shows every block with "
    "identical per-unit loading.",
    "Earthing grid, civil/structural, fire protection, cable routing and equipment lead-times are outside this tool.",
    "The RAW has no dynamic (.dyr) data and no short-circuit sequence data; add both before a PSS/E dynamic or fault study.",
]

SHUNT_NOTE = ("Shunt capacitor banks are NOT an input of the optimiser and their cost is NOT in the technology cost or the NPC. They are "
              "sized here from the reactive requirement: the bank must hold the reactive power drawn from the grid at or below the tariff/"
              "power-factor target (Q/P) in the worst operating case (stage size = standard rating >= requirement / 4, stages = "
              "requirement / stage) and a further stage is added if a bus voltage stays below the low limit; a shunt reactor (10 % of "
              "peak load, standard size) is added only for high voltage. Shunts set on the SLD / Power Flow page (bus 'shunt_mvar') or "
              "edited on this page replace the automatic size. Cost is an extra, shown indicatively in the BOQ.")

# --------------------------------------------------------------------------- editable (assumed) design parameters
# Saved per run + scenario in <run>\design_overrides_<code>.json; every key maps to an engine input, and to the SLD / power-flow
# input ("maps") where the drawing has an equivalent.  Model-derived capacities are NOT here (change them in the scenario setup).

OV_VERSION = 1
PER_KIND = ("inv_unit_mva", "unit_mw", "skid_mva", "skid_z_pct", "skid_tap_pct", "length_km", "area_mm2")
_N = "num"
PARAMS = {
    "v_hv_kv": dict(label="Grid connection voltage", group="Voltage levels", unit="kV", lo=1, hi=765, maps="SLD grid node: kV"),
    "v_mv_kv": dict(label="Medium-voltage plant bus", group="Voltage levels", unit="kV", lo=1, hi=100,
                    maps="SLD bus / load / substation nodes: kV"),
    "lv_kv": dict(label="Inverter / LV terminal voltage", group="Voltage levels", unit="kV", lo=0.2, hi=1.5,
                  maps="SLD PV / BESS / wind nodes: kV"),
    "frequency_hz": dict(label="Nominal frequency", group="Voltage levels", unit="Hz", kind="choice", choices=[50.0, 60.0],
                         maps="Design only (RAW case header)"),
    "load_pf": dict(label="Load power factor", group="Grid and limits", unit="lag", lo=0.5, hi=1.0, maps="Power-flow setting: load_pf"),
    "grid_sc_mva": dict(label="Grid short-circuit level", group="Grid and limits", unit="MVA", lo=10, hi=100000,
                        maps="SLD grid node: sc_mva"),
    "grid_xr": dict(label="Grid X/R", group="Grid and limits", unit="", lo=0.5, hi=100, maps="SLD grid node: xr"),
    "vmin_pu": dict(label="Normal minimum voltage", group="Grid and limits", unit="pu", lo=0.8, hi=1.0, maps="Power-flow setting: vmin_pu"),
    "vmax_pu": dict(label="Normal maximum voltage", group="Grid and limits", unit="pu", lo=1.0, hi=1.2, maps="Power-flow setting: vmax_pu"),
    "thermal_limit_pct": dict(label="Equipment loading limit", group="Grid and limits", unit="% of rating", lo=50, hi=200,
                              maps="Power-flow setting: thermal_limit_pct"),
    "main_tr_n": dict(label="Main transformers (count)", group="Main transformer", unit="no.", lo=1, hi=8, integer=True,
                      maps="Design only (SLD draws one wire)"),
    "main_tr_mva": dict(label="Main transformer rating (each)", group="Main transformer", unit="MVA", lo=1, hi=300,
                        maps="SLD grid-bus wire: mva (total)"),
    "main_tr_z_pct": dict(label="Main transformer impedance", group="Main transformer", unit="% Z", lo=2, hi=25,
                          maps="SLD grid-bus wire: z_pct"),
    "main_tr_xr": dict(label="Main transformer X/R", group="Main transformer", unit="", lo=1, hi=60, maps="SLD grid-bus wire: xr"),
    "tap_step_pct": dict(label="OLTC tap step", group="Main transformer", unit="%", lo=0.5, hi=3.0, maps="Design only"),
    "tap_max_pos": dict(label="OLTC positions each side of nominal", group="Main transformer", unit="steps", lo=0, hi=16, integer=True,
                        maps="Design only"),
    "shunt_stages": dict(label="Capacitor bank stages", group="Reactive compensation", unit="no.", lo=0, hi=20, integer=True,
                         maps="SLD bus node: shunt_steps / shunt_mvar"),
    "shunt_stage_mvar": dict(label="Capacitor stage size", group="Reactive compensation", unit="Mvar", lo=0.1, hi=50,
                             maps="SLD bus node: shunt_step_mvar / shunt_mvar"),
    "reactor_mvar": dict(label="Shunt reactor", group="Reactive compensation", unit="Mvar", lo=0, hi=100,
                         maps="SLD bus node: shunt_mvar (negative)"),
    "aux_load_kw": dict(label="Station auxiliary load", group="Station services", unit="kW", lo=1, hi=20000, maps="Design only"),
    "aux_tr_kva": dict(label="Auxiliary transformer rating", group="Station services", unit="kVA", lo=25, hi=5000, maps="Design only"),
    "cable_derate": dict(label="Cable derating factor", group="Cables", unit="factor", lo=0.4, hi=1.0, maps="Design only"),
    "cable_vd_limit_pct": dict(label="Cable voltage-drop limit", group="Cables", unit="%", lo=0.5, hi=10, maps="Design only"),
    "incoming_type": dict(label="Incoming connection type", group="Cables", unit="", kind="choice", choices=["overhead", "cable"],
                          maps="SLD grid wire: type"),
    "clearing_s": dict(label="Fault clearing time", group="Protection", unit="s", lo=0.1, hi=3.0, maps="Design only"),
    "ngr_a": dict(label="Neutral earthing resistor current", group="Protection", unit="A", lo=10, hi=2000, maps="Design only"),
    "mv_breaker_ka": dict(label="MV breaker / busbar short-circuit rating", group="Protection", unit="kA", lo=6.3, hi=100,
                          maps="Design only"),
    "pv_module_w": dict(label="PV module size", group="Unit sizes (for counts)", unit="W", lo=100, hi=1000, maps="Design only"),
    "pv_modules_per_string": dict(label="PV modules per string", group="Unit sizes (for counts)", unit="no.", lo=10, hi=60, integer=True,
                                  maps="Design only"),
    "container_mwh": dict(label="BESS container energy", group="Unit sizes (for counts)", unit="MWh", lo=0.5, hi=10, maps="Design only"),
    "mv_spare_panels": dict(label="Spare MV switchgear panels", group="Unit sizes (for counts)", unit="no.", lo=0, hi=10, integer=True,
                            maps="Design only"),
    "inv_unit_mva": dict(label="Inverter / PCS unit size", group="Unit sizes (for counts)", unit="MVA", lo=0.25, hi=10, maps="Design only"),
    "unit_mw": dict(label="Generator / turbine unit size", group="Unit sizes (for counts)", unit="MW", lo=0.1, hi=100, maps="Design only"),
    "skid_mva": dict(label="Step-up transformer rating (each)", group="Plant transformers", unit="MVA", lo=0.25, hi=100,
                     maps="SLD plant-bus wire: mva (total)"),
    "skid_z_pct": dict(label="Step-up transformer impedance", group="Plant transformers", unit="% Z", lo=2, hi=25,
                       maps="SLD plant-bus wire: z_pct"),
    "skid_tap_pct": dict(label="Step-up transformer off-load tap", group="Plant transformers", unit="%", lo=-10, hi=10,
                         maps="Design only"),
    "length_km": dict(label="Cable / line length", group="Cable lengths and types", unit="km", lo=0.01, hi=200,
                      maps="SLD wire: length_km"),
    "area_mm2": dict(label="Cable conductor area", group="Cable lengths and types", unit="mm2", lo=95, hi=630,
                     maps="SLD wire: type, circuits, r/x/b, ampacity_a"),
}


def validate_overrides(values):
    """Clean {key: number|str}; blank values are dropped, unknown keys or out-of-range numbers raise ValueError."""
    out = {}
    for key, raw in (values or {}).items():
        base, dot, suffix = str(key).partition(".")
        d = PARAMS.get(base)
        if d is None or (base in PER_KIND) != bool(dot) or (dot and not re.fullmatch(r"[a-z0-9_]{1,24}", suffix)):
            raise ValueError(f"Unknown design parameter '{key}'.")
        if raw is None or (isinstance(raw, str) and not raw.strip()):
            continue
        if d.get("kind") == "choice":
            hit = next((c for c in d["choices"] if str(c) == str(raw).strip() or (not isinstance(c, str) and _num(raw, None) == c)), None)
            if hit is None:
                raise ValueError(f"{d['label']}: choose one of {', '.join(str(c) for c in d['choices'])}.")
            out[key] = hit
            continue
        if isinstance(raw, bool):
            raise ValueError(f"{d['label']} must be a number.")
        value = _num(raw, None)
        if value is None:
            raise ValueError(f"{d['label']} must be a number.")
        if not d["lo"] <= value <= d["hi"]:
            raise ValueError(f"{d['label']} must be between {d['lo']:g} and {d['hi']:g} {d['unit']}.")
        out[key] = int(round(value)) if d.get("integer") else round(value, 4)
    return out


def param_label(key):
    base, _, suffix = key.partition(".")
    d = PARAMS[base]
    return d["label"] + (f" - {suffix.upper()}" if suffix else "")


def overrides_path(folder, code):
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,32}", str(code or "")):
        raise ValueError("Invalid scenario code.")
    return Path(folder) / f"design_overrides_{code}.json"


def _atomic_write(path, data):
    path = Path(path)
    tmp = path.with_name(path.name + f".{threading.get_ident()}.tmp")
    tmp.write_text(json.dumps(data, indent=2, allow_nan=False), encoding="utf-8")
    import os
    import time
    for attempt in range(40):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            # Windows briefly locks a file that another process (or thread) is reading.
            if attempt == 39:
                raise
            time.sleep(0.05)


def load_overrides(run_id, code):
    """Saved record {version, values, written, updated}; values is {} when nothing was edited (or the file is unreadable)."""
    path = overrides_path(extensions.run_folder(run_id), code)
    try:
        rec = json.loads(path.read_text(encoding="utf-8"))
        rec["values"] = validate_overrides(rec.get("values"))
        if not isinstance(rec.get("written"), dict):
            rec["written"] = {}
        return rec
    except (OSError, ValueError, TypeError, AttributeError):
        return dict(version=OV_VERSION, values={}, written={}, updated=None)


# --------------------------------------------------------------------------- standard-rating helpers

def std_rating(value, series):
    """Smallest standard rating >= value, or None when the value exceeds the series."""
    return next((s for s in series if s >= value - 1e-9), None)


STD_UM_KV = [3.6, 7.2, 12, 17.5, 24, 36, 52, 72.5, 100, 123, 145, 170, 245, 300, 362, 420, 550, 800]  # IEC 60038 / 62271-1 highest voltage Um


def highest_voltage_kv(kv):
    """Equipment highest voltage Um (IEC 60038 series) for a nominal system voltage."""
    return std_rating(kv, STD_UM_KV) or STD_UM_KV[-1]


def arrester_rating_kv(kv):
    """Rated voltage Ur of a metal-oxide arrester for an effectively earthed system (Ur ~ 0.8 Um, IEC 60099-5), rounded up to 3 kV."""
    return math.ceil(0.8 * highest_voltage_kv(kv) / 3.0 - 1e-9) * 3.0


def detuning_hz(reactor_pct, freq_hz):
    """Series-resonance frequency of a capacitor bank detuned with a reactor of reactor_pct % of the capacitor reactance."""
    return freq_hz / math.sqrt(reactor_pct / 100.0)


def main_transformer_plan(required_mva):
    """Number of equal units and standard ONAF MVA each so that n * rating >= required (largest unit 100 MVA)."""
    required = max(float(required_mva), STD_MAIN_MVA[0])
    for n in range(1, 9):
        each = std_rating(required / n, STD_MAIN_MVA)
        if each is not None:
            return n, each
    return 8, STD_MAIN_MVA[-1]


def block_plan(s_required, blocks=BLOCKS_INV):
    """Inverter/PCS count and block (MVA) minimising excess, preferring fewer larger units."""
    if s_required <= 1e-9:
        return None
    best = None
    for b in blocks:
        if b > max(s_required, min(blocks)) + 1e-9 and b != min(blocks):
            continue
        n = max(1, math.ceil(s_required / b - 1e-9))
        score = (n * b - s_required) / s_required + 0.02 * n
        if best is None or score < best[0] - 1e-12:
            best = (score, b, n)
    return dict(unit_mva=best[1], n=best[2], s_total=round(best[1] * best[2], 4))


def frame_plan(mw, frames=FRAMES_GEN):
    """Generator frame and count: minimum installed excess, ties to fewer units."""
    best = None
    for f in frames:
        n = max(1, math.ceil(mw / f - 1e-9))
        if n > 12:
            continue
        key = (round(n * f - mw, 6), n)
        if best is None or key < best[0]:
            best = (key, f, n)
    return dict(unit_mw=best[1], n=best[2], total_mw=round(best[1] * best[2], 4))


def cable_params(kv, area_mm2):
    row = next(r for r in CABLES if r[0] == area_mm2)
    return dict(area=row[0], amps=row[1], r=row[2], x=row[3], b=pf.line_class(kv, "cable")["b"])


def voltage_drop_pct(i_amps, length_km, r, x, kv, pf_load=0.95):
    sin = math.sqrt(1 - pf_load ** 2)
    return SQ3 * i_amps * length_km * (r * pf_load + x * sin) / (kv * 1000.0) * 100.0


def size_cable(i_amps, kv, length_km, min_area=0.0, max_circuits=10):
    """Smallest conductor set (by total copper proxy) meeting derated ampacity, voltage drop and short-circuit withstand."""
    best = None
    for n in range(1, max_circuits + 1):
        per = i_amps / n
        for row in CABLES:
            area, amps, r, x = row
            if area < min_area or per > CABLE_DERATE * amps:
                continue
            vd = voltage_drop_pct(per, length_km, r, x, kv)
            if vd > CABLE_VD_LIMIT_PCT:
                continue
            cost = n * (area + CIRCUIT_OVERHEAD_MM2)
            if best is None or cost < best[0]:
                best = (cost, n, row, vd)
            break
    if best is None:
        n, row = max_circuits, CABLES[-1]
        vd = voltage_drop_pct(i_amps / n, length_km, row[2], row[3], kv)
        best = (0, n, row, vd)
    _, n, row, vd = best
    per = i_amps / n
    return dict(circuits=n, area=row[0], ampacity_a=row[1], derated_a=round(CABLE_DERATE * row[1], 1), r=row[2], x=row[3],
                b=pf.line_class(kv, "cable")["b"], length_km=length_km, i_per_circuit=round(per, 1),
                vd_pct=round(voltage_drop_pct(per, length_km, row[2], row[3], kv), 3),
                loading_pct=round(per / (CABLE_DERATE * row[1]) * 100.0, 1), sc_ok=row[0] >= min_area)


def transformer_losses(mva, z_pct, xr):
    """(no-load kW, load kW at rated) from typical class values; load loss = R pu * rating (consistent with the model R)."""
    r_pu = z_pct / 100.0 / math.sqrt(1 + xr ** 2)
    p0 = mva * (1.2 if mva < 5 else 0.7 if mva < 20 else 0.5)
    return round(p0, 2), round(r_pu * mva * 1000.0, 2)


def short_circuit(sc_mva_grid, z_t_pu_each, n_t, mva_t_total, sources_mva):
    """Max symmetrical fault MVA at the MV bus: grid through the transformer(s) plus local sources (arithmetic sum)."""
    z_tr = z_t_pu_each
    grid_part = 1.0 / (1.0 / sc_mva_grid + z_tr / mva_t_total) if sc_mva_grid else 0.0
    return grid_part + sources_mva


def _num(value, default=0.0):
    try:
        out = float(value)
    except (TypeError, ValueError):
        return default
    return out if math.isfinite(out) else default


def _r(value, digits=3):
    return None if value is None else round(float(value), digits)


MAX_DECIMALS = 4


def clean(obj, digits=MAX_DECIMALS):
    """JSON-safe copy: numpy -> python, NaN/inf -> None, floats rounded to at most `digits` decimals (tables and exports)."""
    if isinstance(obj, dict):
        return {str(k): clean(v, digits) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [clean(v, digits) for v in obj]
    if isinstance(obj, (np.bool_, bool)):
        return bool(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (float, np.floating)):
        value = float(obj)
        if not math.isfinite(value):
            return None
        value = round(value, digits)
        return 0.0 if value == 0 else value
    if isinstance(obj, str):
        return trim_text(obj, digits)
    return obj


_DEC_RE = re.compile(r"(?<![\w.])(\d+\.\d{5,})(?![\w])")


def trim_text(text, digits=MAX_DECIMALS):
    """Round any number with more than `digits` decimals inside a text value."""
    return _DEC_RE.sub(lambda m: f"{round(float(m.group(1)), digits):.{digits}f}".rstrip("0").rstrip("."), str(text))


# --------------------------------------------------------------------------- run inputs

def best_scenario(summary):
    """Lowest cash NPC among non-reference scenarios that serve all load; falls back to the first solved scenario."""
    columns, rows = summary.get("columns") or [], summary.get("rows") or []
    try:
        i_id, i_npc, i_adq = columns.index("ID"), columns.index("10-year cash NPC $m"), columns.index("Supply adequacy")
    except ValueError:
        return (summary.get("results") or [{}])[0].get("code")
    reference = {r.get("code") for r in summary.get("results") or [] if r.get("case") == "Reference"}
    good = [r for r in rows if r[i_id] not in reference and r[i_npc] is not None and "ALL LOAD SERVED" in str(r[i_adq]).upper()]
    pool = good or [r for r in rows if r[i_npc] is not None] or rows
    if not pool:
        return None
    return min(pool, key=lambda r: r[i_npc] if r[i_npc] is not None else 1e18)[i_id]


def _find_key(obj, key):
    if isinstance(obj, dict):
        if key in obj and not isinstance(obj[key], (dict, list)):
            return obj[key]
        for v in obj.values():
            hit = _find_key(v, key)
            if hit is not None:
                return hit
    return None


def _node_over(diagram, kind):
    for n in diagram["nodes"]:
        if n["kind"] == kind and n.get("electrical"):
            return dict(n["electrical"])
    return {}


def _sld_length(diagram, kinds):
    """Longest SLD wire incident to a node of one of the kinds (km), 0 when the wires have no length."""
    ids = {n["id"] for n in diagram["nodes"] if n["kind"] in kinds}
    lengths = [float(e.get("length_km") or 0) for e in diagram["lines"] if e["source"] in ids or e["target"] in ids]
    return max(lengths) if lengths else 0.0


def _planned_items(request):
    out = dict(pv=[], bess=[], wind=[], trailers=[])
    for item in (request or {}).get("planned_generation") or []:
        tech, status = item.get("technology"), item.get("status", "planned")
        name = item.get("name") or tech
        if tech == "Solar" and _num(item.get("capacity_mw")) > 0:
            out["pv"].append(dict(name=name, status=status, mw=_num(item["capacity_mw"]), year=item.get("start_year"), pf=_num(item.get("pf"), unit_pf.DEFAULT_PF)))
        elif tech == "BESS" and _num(item.get("capacity_mw")) > 0:
            out["bess"].append(dict(name=name, status=status, mw=_num(item["capacity_mw"]), mwh=_num(item.get("energy_mwh")),
                                    year=item.get("start_year"), pf=_num(item.get("pf"), unit_pf.DEFAULT_PF)))
        elif tech == "Wind" and _num(item.get("capacity_mw")) > 0:
            out["wind"].append(dict(name=name, status=status, mw=_num(item["capacity_mw"]), year=item.get("start_year"), pf=_num(item.get("pf"), unit_pf.DEFAULT_PF)))
        elif tech == "Mobile Trailers":
            out["trailers"].append(dict(name=name, status=status, pv_mw=_num(item.get("pv_kw")) / 1000.0,
                                        bess_mw=_num(item.get("bess_kw")) / 1000.0, bess_mwh=_num(item.get("bess_kwh")) / 1000.0,
                                        avail=_num(item.get("availability"), 0.4), year=item.get("start_year")))
    return out


# --------------------------------------------------------------------------- sizing

class Spec(dict):
    """Mutable bag of design knobs shared by the network builder and the sizing loop."""


def _gen_groups(ctx, values, planned, obs, eligible):
    """Technology groups: dict(kind, label, p_mw (model), parts, plan).  Only eligible technologies are designed."""
    caps = ctx["caps"]
    dc_ac = max(_num(values.get("_dc_ac"), 1.0), 0.5)
    groups = []
    pv_new_dc = _num(caps.get("pv"))
    pv_plan = sum(p["mw"] for p in planned["pv"])
    trailer_pv = sum(t["pv_mw"] * t["avail"] for t in planned["trailers"])
    if "pv" in eligible and (pv_new_dc > 1e-6 or pv_plan > 1e-6 or trailer_pv > 1e-6 or obs["pv"] > 1e-6):
        parts = []
        if pv_new_dc > 1e-6:
            parts.append(dict(name="Optimised new PV", status="new", dc_mw=pv_new_dc, ac_mw=pv_new_dc / dc_ac, basis="model"))
        for p in planned["pv"]:
            parts.append(dict(name=p["name"], status=p["status"], dc_mw=p["mw"] * dc_ac, ac_mw=p["mw"], basis="model"))
        groups.append(dict(kind="pv", label="Solar PV", parts=parts, dc_ac=dc_ac,
                           p_mw=sum(x["ac_mw"] for x in parts) + trailer_pv))
    bess_mw = _num(caps.get("bess"))
    bess_mwh = _num(ctx["bess_mwh"])
    planned_b = planned["bess"]
    trailer_b = sum(t["bess_mw"] * t["avail"] for t in planned["trailers"])
    if "bess" in eligible and (bess_mw > 1e-6 or planned_b or trailer_b > 1e-6 or obs["bess"] > 1e-6):
        parts = []
        if bess_mw > 1e-6:
            parts.append(dict(name="Optimised new BESS", status="new", mw=bess_mw, mwh=bess_mwh, basis="model"))
        for p in planned_b:
            parts.append(dict(name=p["name"], status=p["status"], mw=p["mw"], mwh=p["mwh"] or p["mw"] * 2, basis="model"))
        groups.append(dict(kind="bess", label="BESS", parts=parts, p_mw=sum(x["mw"] for x in parts) + trailer_b))
    wind_mw = _num(caps.get("wind")) + sum(p["mw"] for p in planned["wind"])
    if "wind" in eligible and (wind_mw > 1e-6 or obs["wind"] > 1e-6):
        groups.append(dict(kind="wind", label="Wind", parts=[dict(name="Wind", status="new", mw=wind_mw, basis="model")], p_mw=wind_mw))
    for tech in sorted(pf.GENSETS):
        mw = _num(caps.get(tech))
        if tech in eligible and mw > 1e-6:
            groups.append(dict(kind=tech, label=GEN_LABEL.get(tech, tech), parts=[dict(name=tech, status="new", mw=mw, basis="model")],
                               p_mw=mw))
    for g in groups:
        spec = unit_pf.for_tech(values, g["kind"])
        g["pf"], g["pf_lead"] = spec["pf"], spec["pf_lead"]
        extra = [(x["mw"], x["pf"]) for x in planned.get({"pv": "pv", "bess": "bess", "wind": "wind"}.get(g["kind"], ""), []) if x.get("pf")]
        if extra:
            # new plant at the technology pf plus planned entries at their own pf: one equivalent pf = total MW / total MVA
            new_mw = max(g["p_mw"] - sum(m for m, _ in extra), 0.0)
            mw_all = new_mw + sum(m for m, _ in extra)
            mva_all = new_mw / g["pf"] + sum(m / p for m, p in extra)
            if mva_all > 0:
                g["pf"] = min(max(mw_all / mva_all, unit_pf.PF_MIN), unit_pf.PF_MAX)
    return groups


GEN_LABEL = {"ng": "Natural gas turbine/engine", "ng_chp": "Natural gas CHP", "h2": "Hydrogen turbine", "h2_chp": "Hydrogen CHP",
             "diesel": "Diesel generator", "biogas": "Biogas generator", "biomass": "Biomass generator"}


def _plan_group(group, v_mv, ov=None):
    """Physical units of one technology group (inverter/PCS blocks, containers, genset frames, skid transformers).

    ov: user overrides; unit sizes (inv_unit_mva / unit_mw) fix the unit and the count follows, skid_mva fixes the transformer."""
    ov = ov or {}
    plan = _plan_group_auto(group, v_mv, ov)
    skid = ov.get(f"skid_mva.{group['kind']}")
    if skid and plan.get("has_gsu"):
        plan["skid_mva"] = float(skid)
    return plan


def _plan_group_auto(group, v_mv, ov):
    kind, p = group["kind"], group["p_mw"]
    pfg = group.get("pf", PF_CAP)  # MW is the active rating at this operating power factor; units are sized in MVA = MW / pf
    unit = ov.get(f"inv_unit_mva.{kind}") if kind in ("pv", "bess") else ov.get(f"unit_mw.{kind}")
    if kind in ("pv", "bess"):
        plan = block_plan(max(p, 1e-6) / pfg)
        if unit:
            n = max(1, math.ceil(max(p, 1e-6) / pfg / unit - 1e-9))
            plan = dict(unit_mva=float(unit), n=n, s_total=round(unit * n, 4))
        skid = std_rating(plan["unit_mva"], STD_SKID_MVA)
        plan.update(skid_mva=skid, v_lv=LV_KV, p_unity_mw=round(plan["s_total"] * pfg, 3), has_gsu=True, pf=pfg,
                    pf_lead=group.get("pf_lead", pfg))
        if kind == "bess":
            mwh = sum(x["mwh"] for x in group["parts"]) + 0.0
            plan.update(mwh=mwh, containers=max(1, math.ceil(mwh / CONTAINER_MWH - 1e-9)))
            plan["containers_per_pcs"] = math.ceil(plan["containers"] / plan["n"])
        return plan
    if kind == "wind":
        best = None
        for unit in ([float(unit)] if unit else BLOCKS_WIND):
            n = max(1, math.ceil(p / unit - 1e-9))
            key = (round(n * unit - p, 6), n)
            if best is None or key < best[0]:
                best = (key, unit, n)
        _, unit, n = best
        s_unit = unit / pfg
        return dict(unit_mw=unit, n=n, unit_mva=round(s_unit, 3), s_total=round(s_unit * n, 3), skid_mva=std_rating(s_unit, STD_SKID_MVA),
                    v_lv=LV_KV, p_unity_mw=round(unit * n * pfg, 3), has_gsu=True, pf=pfg, pf_lead=group.get("pf_lead", pfg))
    plan = frame_plan(p) if not unit else dict(unit_mw=float(unit), n=max(1, math.ceil(p / float(unit) - 1e-9)),
                                                total_mw=round(float(unit) * max(1, math.ceil(p / float(unit) - 1e-9)), 4))
    s_unit = plan["unit_mw"] / pfg
    direct = plan["unit_mw"] >= 3.0 and v_mv <= 13.8
    plan.update(unit_mva=round(s_unit, 3), s_total=round(s_unit * plan["n"], 3), has_gsu=not direct,
                v_lv=v_mv if direct else LV_KV, skid_mva=None if direct else std_rating(s_unit, STD_SKID_MVA),
                xd2=0.15, xd1=0.25, xd=1.8, min_load_pct=40, voltage_kv=v_mv if direct else LV_KV, pf=pfg,
                pf_lead=group.get("pf_lead", pfg))
    return plan


def _initial_spec(ctx, diagram, values, data, groups, obs, planned, has_grid, ov=None):
    ov = ov or {}
    spec = Spec(has_grid=has_grid, notes=[], iterations=[])
    gridz = _node_over(diagram, "grid")
    peak_load = float(max(pf._series(data, "net_served_load_mw" if "net_served_load_mw" in data else "net_load_mw")))
    load_pf = 0.95
    import_mw, export_mw = max(obs["grid_import"], 0.0), max(obs["grid_export"], 0.0)
    peak_poi_s = max(import_mw, export_mw, 0.0) / load_pf if has_grid else peak_load / load_pf
    spec["peak_load_mw"], spec["load_pf"] = peak_load, load_pf
    # Voltage levels: user overrides in the SLD win; otherwise the lowest MV level keeping the MV bus <= 2.5 kA.
    kv_user = {}
    for n in diagram["nodes"]:
        if n.get("electrical", {}).get("kv") is not None:
            kv_user.setdefault(n["kind"], float(n["electrical"]["kv"]))
    s_design = max(peak_poi_s, peak_load / load_pf, 1.0)
    if has_grid:
        v_hv = kv_user.get("grid") or (33.0 if s_design <= 50 else 66.0 if s_design <= 100 else 132.0)
        spec["v_hv_source"] = "model" if "grid" in kv_user else "assumed"
        if "v_hv_kv" in ov:
            v_hv, spec["v_hv_source"] = float(ov["v_hv_kv"]), "user-set"
    else:
        v_hv, spec["v_hv_source"] = None, "n/a"
    mv_user = kv_user.get("load") or kv_user.get("bus") or kv_user.get("substation")
    if mv_user:
        v_mv, spec["v_mv_source"] = float(mv_user), "model"
    else:
        v_mv = next((v for v in (11.0, 22.0, 33.0) if s_design / (SQ3 * v) * 1000 <= 2500 and (v_hv is None or v < v_hv)), None)
        if v_mv is None:
            v_mv = 33.0 if v_hv is None or v_hv > 33.0 else v_hv
        spec["v_mv_source"] = "assumed"
    if "v_mv_kv" in ov:
        v_mv, spec["v_mv_source"] = float(ov["v_mv_kv"]), "user-set"
    spec["v_hv"], spec["v_mv"] = v_hv, v_mv
    spec["main_tr"] = has_grid and v_hv is not None and abs(v_hv - v_mv) > 1e-9
    sc_default = pf.DEFAULTS["grid_short_circuit"]["value"]
    spec["sc_mva"] = float(gridz.get("sc_mva", sc_default["mva_le_33kv"] if (v_hv or 0) <= 33 else sc_default["mva_gt_33kv"]))
    spec["sc_xr"] = float(gridz.get("xr", sc_default["xr"]))
    spec["sc_source"] = "model" if "sc_mva" in gridz else "assumed"
    spec["xr_source"] = "model" if "xr" in gridz else "assumed"
    if "grid_sc_mva" in ov:
        spec["sc_mva"], spec["sc_source"] = float(ov["grid_sc_mva"]), "user-set"
    if "grid_xr" in ov:
        spec["sc_xr"], spec["xr_source"] = float(ov["grid_xr"]), "user-set"
    settings = diagram.get("pf_settings") or {}
    spec["limits"] = dict(
        vmin_pu=(float(ov.get("vmin_pu", settings.get("vmin_pu", 0.95))), "user-set" if "vmin_pu" in ov else "model" if "vmin_pu" in settings else "assumed"),
        vmax_pu=(float(ov.get("vmax_pu", settings.get("vmax_pu", 1.05))), "user-set" if "vmax_pu" in ov else "model" if "vmax_pu" in settings else "assumed"),
        thermal_limit_pct=(float(ov.get("thermal_limit_pct", settings.get("thermal_limit_pct", 100.0))),
                           "user-set" if "thermal_limit_pct" in ov else "model" if "thermal_limit_pct" in settings else "assumed"))
    spec["pf_settings"] = {k: v[0] for k, v in spec["limits"].items() if v[1] != "assumed"}
    if "load_pf" in ov:
        spec["load_pf"], spec["load_pf_source"] = float(ov["load_pf"]), "user-set"
    elif "load_pf" in settings:
        spec["load_pf"], spec["load_pf_source"] = float(settings["load_pf"]), "model"
    else:
        spec["load_pf_source"] = "assumed"
    spec["s_poi_mva"] = s_design
    spec["groups"] = groups
    spec["plans"] = {g["kind"]: _plan_group(g, v_mv, ov) for g in groups}
    spec["main_n"], spec["main_mva"] = main_transformer_plan(s_design / 0.90) if spec["main_tr"] else (0, 0)
    spec["main_lock"] = False
    if spec["main_tr"] and ("main_tr_n" in ov or "main_tr_mva" in ov):
        n_user, each_user = ov.get("main_tr_n"), ov.get("main_tr_mva")
        if each_user is None:
            each_user = std_rating(s_design / 0.90 / n_user, STD_MAIN_MVA) or STD_MAIN_MVA[-1]
        if n_user is None:
            n_user = max(1, math.ceil(s_design / 0.90 / each_user - 1e-9))
        spec["main_n"], spec["main_mva"], spec["main_lock"] = int(n_user), float(each_user), True
    spec["tap_pos"] = {}
    spec["margin"] = {}
    spec["skid_tap"] = {}
    spec["tap_lock"] = set()
    for g in groups:
        k = g["kind"]
        if f"skid_tap_pct.{k}" in ov:
            spec["skid_tap"][k] = float(ov[f"skid_tap_pct.{k}"]) / 100.0
            spec["tap_lock"].add(k)
    spec["skid_lock"] = {g["kind"] for g in groups if f"skid_mva.{g['kind']}" in ov}
    spec["stages"], spec["stage_mvar"], spec["reactor_mvar"] = 0, 0.0, 0.0
    spec["shunt_source"], spec["reactor_source"] = "assumed", "assumed"
    spec["shunt_lock"] = spec["reactor_lock"] = False
    spec["shunt_pending"] = None
    cap_sld = sum(max(float((n.get("electrical") or {}).get("shunt_mvar") or 0.0), 0.0) for n in diagram["nodes"])
    rea_sld = sum(max(-float((n.get("electrical") or {}).get("shunt_mvar") or 0.0), 0.0) for n in diagram["nodes"])
    if cap_sld > 1e-9:
        node = next(n["electrical"] for n in diagram["nodes"] if (n.get("electrical") or {}).get("shunt_mvar", 0) > 0)
        steps = int(node.get("shunt_steps") or (1 if cap_sld <= 1.0 else 4))
        spec["stages"], spec["stage_mvar"] = steps, cap_sld / steps if not node.get("shunt_step_mvar") else float(node["shunt_step_mvar"])
        spec["shunt_source"], spec["shunt_lock"] = "model", True
    if rea_sld > 1e-9:
        spec["reactor_mvar"], spec["reactor_source"], spec["reactor_lock"] = rea_sld, "model", True
    if "shunt_stages" in ov or "shunt_stage_mvar" in ov:
        n_user, s_user = ov.get("shunt_stages"), ov.get("shunt_stage_mvar")
        spec["shunt_source"], spec["shunt_lock"] = "user-set", True
        if n_user == 0:
            spec["stages"], spec["stage_mvar"] = 0, 0.0
        elif n_user is not None and s_user is not None:
            spec["stages"], spec["stage_mvar"] = int(n_user), float(s_user)
        else:
            spec["shunt_pending"] = (n_user, s_user)
    if "reactor_mvar" in ov:
        spec["reactor_mvar"], spec["reactor_source"], spec["reactor_lock"] = float(ov["reactor_mvar"]), "user-set", True
    lengths = dict(
        incoming=_sld_length(diagram, {"grid"}), load=_sld_length(diagram, {"load"}),
        **{g["kind"]: _sld_length(diagram, {g["kind"]}) for g in groups})
    spec["length_km"], spec["length_source"] = {}, {}
    for key, default in (("incoming", DEFAULT_LEN_KM["incoming"]), ("load", DEFAULT_LEN_KM["load"])):
        spec["length_km"][key] = lengths[key] if lengths[key] > 0 else default
        spec["length_source"][key] = "model" if lengths[key] > 0 else "assumed"
    for g in groups:
        k = g["kind"]
        default = DEFAULT_LEN_KM["gen" if k in pf.GENSETS else k]
        spec["length_km"][k] = lengths[k] if lengths[k] > 0 else default
        spec["length_source"][k] = "model" if lengths[k] > 0 else "assumed"
    for key in list(spec["length_km"]):
        if f"length_km.{key}" in ov:
            spec["length_km"][key], spec["length_source"][key] = float(ov[f"length_km.{key}"]), "user-set"
    n_load = len([n for n in diagram["nodes"] if n["kind"] == "load"]) or 1
    spec["n_load_nodes"] = n_load
    spec["trailers"] = planned["trailers"]
    spec["isc_ka_mv"] = 0.0
    return spec


def _feeder_current(spec, key):
    kv = spec["v_mv"]
    if key == "incoming":
        return spec["s_poi_mva"] / (SQ3 * spec["v_hv"]) * 1000.0
    if key == "load":
        return spec["peak_load_mw"] / spec["load_pf"] / (SQ3 * kv) * 1000.0
    return spec["plans"][key]["s_total"] / (SQ3 * kv) * 1000.0


def _tz(spec, key, mva):
    """Transformer z% and X/R: user override when set, else the power-flow default for the rating."""
    ov = spec.get("ov") or {}
    z, xr = pf.transformer_defaults(mva)
    if key == "main":
        return float(ov.get("main_tr_z_pct", z)), float(ov.get("main_tr_xr", xr))
    return float(ov.get(f"skid_z_pct.{key}", z)), xr


def _size_feeders(spec):
    """(Re)size every cable run from current margins and the present MV fault level."""
    feeders = {}
    for key in ["incoming", "load"] + [g["kind"] for g in spec["groups"]]:
        if key == "incoming" and not spec["has_grid"]:
            continue
        kv = spec["v_hv"] if key == "incoming" else spec["v_mv"]
        i_amps = _feeder_current(spec, key) * spec["margin"].get(key, 1.0)
        isc = spec["isc_ka_mv"] if key != "incoming" else spec.get("isc_hv_ka", 0.0)
        min_area = isc * 1000.0 * math.sqrt(CLEARING_S) / CABLE_K_AL if isc else 0.0
        user_area = (spec.get("ov") or {}).get(f"area_mm2.{key}")
        if user_area:
            min_area = max(min_area, float(user_area))
        kind = "overhead" if key == "incoming" and spec["length_km"]["incoming"] > 1.0 else "cable"
        if key == "incoming" and (spec.get("ov") or {}).get("incoming_type"):
            kind = (spec["ov"]["incoming_type"])
        if kind == "overhead":
            row = pf.line_class(kv, "overhead")
            n = max(1, math.ceil(i_amps / row["amps"] - 1e-9))
            feeders[key] = dict(circuits=n, area=None, ampacity_a=row["amps"], derated_a=row["amps"], r=row["r"], x=row["x"], b=row["b"],
                                length_km=spec["length_km"][key], i_per_circuit=round(i_amps / n, 1), basis=row["basis"], type="overhead",
                                vd_pct=round(voltage_drop_pct(i_amps / n, spec["length_km"][key], row["r"], row["x"], kv), 3),
                                loading_pct=round(i_amps / n / row["amps"] * 100, 1), sc_ok=True)
            continue
        cab = size_cable(i_amps, kv, spec["length_km"][key], min_area=min_area)
        cab.update(type="cable", basis="3-core Al XLPE", kv=kv)
        feeders[key] = cab
    spec["feeders"] = feeders


def _fault_levels(spec):
    """Fault MVA/kA at the MV (and HV) bus."""
    plans = spec["plans"]
    local = 0.0
    for g in spec["groups"]:
        pl = plans[g["kind"]]
        if g["kind"] in ("pv", "bess", "wind"):
            local += 1.1 * pl["s_total"]
        else:
            local += pl["s_total"] / pl["xd2"]
    if spec["main_tr"]:
        z_pct, _xr = _tz(spec, "main", spec["main_mva"])
        z = z_pct / 100.0
        total = spec["main_n"] * spec["main_mva"]
        mv_mva = short_circuit(spec["sc_mva"], z, spec["main_n"], total, local)
        hv_mva = spec["sc_mva"] + (1.0 / (1.0 / max(local, 1e-6) + z / total) if local else 0.0)
    else:
        mv_mva = (spec["sc_mva"] if spec["has_grid"] else 0.0) + local
        hv_mva = mv_mva
    spec["isc_mv_mva"], spec["isc_hv_mva"] = mv_mva, hv_mva
    spec["isc_mv_ka"] = mv_mva / (SQ3 * spec["v_mv"])
    spec["isc_hv_ka"] = hv_mva / (SQ3 * spec["v_hv"]) if spec["v_hv"] else 0.0
    spec["isc_ka_mv"] = spec["isc_mv_ka"]


# --------------------------------------------------------------------------- network for the solver

def _network(spec, peak_load_mw, eligible, islanded):
    nodes, lines = [], []

    def node(ident, kind, label, kv, **el):
        nodes.append(dict(id=ident, kind=kind, label=label, x=0, y=0, owner="shared", electrical=dict(kv=kv, **el)))

    def line(ident, a, b, length, **el):
        lines.append(dict(id=ident, source=a, target=b, owner="shared", length_km=length, electrical=el))

    def cable_el(f):
        el = dict(kind="line", type=f["type"], circuits=f["circuits"], r_ohm_km=f["r"], x_ohm_km=f["x"], b_us_km=f["b"],
                  ampacity_a=f["derated_a"])
        return el

    v_mv = spec["v_mv"]
    root = IDS["mv"]
    if spec["has_grid"]:
        node(IDS["grid"], "grid", "Utility grid", spec["v_hv"], sc_mva=spec["sc_mva"], xr=spec["sc_xr"])
        line("L_INC", IDS["grid"], IDS["hv"], spec["length_km"]["incoming"], **cable_el(spec["feeders"]["incoming"]))
        node(IDS["hv"], "substation", "Substation HV bus", spec["v_hv"])
        if spec["main_tr"]:
            z, xr = _tz(spec, "main", spec["main_mva"])
            node(IDS["mv"], "substation", "Substation MV bus", v_mv)
            line("MAIN_TR", IDS["hv"], IDS["mv"], 0, kind="transformer", mva=spec["main_n"] * spec["main_mva"], z_pct=z, xr=xr,
                 tap=1.0 - TAP_STEP * spec["tap_pos"].get("main", 0))
        else:
            root = IDS["hv"]
    else:
        node(IDS["mv"], "substation", "Substation MV bus", v_mv)
    node(IDS["load"], "load", "Load", v_mv, pf=spec["load_pf"], weight=1.0)
    line("F_LOAD", root, IDS["load"], spec["length_km"]["load"], **cable_el(spec["feeders"]["load"]))
    for g in spec["groups"]:
        k, pl = g["kind"], spec["plans"][g["kind"]]
        if k in pf.GENSETS:
            cap = pl["total_mw"]
        elif k == "wind":
            cap = pl["unit_mw"] * pl["n"] * pl.get("pf", PF_CAP)
        else:
            cap = pl["s_total"] * pl.get("pf", PF_CAP)
        coll = f"{k.upper()}_C"
        node(coll, "bus", f"{g['label']} collector", v_mv)
        extra = dict(control="voltage", vset=1.0, rated_pf=pl.get("pf", PF_CAP), rated_pf_lead=pl.get("pf_lead", PF_CAP))
        if pl["has_gsu"]:
            node(k, k, g["label"], pl["v_lv"], cap_mw=cap, **extra)
            z, xr = _tz(spec, k, pl["skid_mva"] if pl["skid_mva"] and pl["skid_mva"] >= 2.5 else 2.5)
            n_skid = pl["n"]
            line(f"T_{k.upper()}", coll, k, 0, kind="transformer", mva=pl["skid_mva"] * n_skid, z_pct=z, xr=xr,
                 tap=1.0 + spec["skid_tap"].get(k, 0.0))
        else:
            node(k, k, g["label"], v_mv, cap_mw=cap, **extra)
            line(f"T_{k.upper()}", coll, k, 0, kind="tie")
        line(f"F_{k.upper()}", root, coll, spec["length_km"][k], **cable_el(spec["feeders"][k]))
    diagram = dict(nodes=nodes, lines=lines, pf_settings=dict(spec.get("pf_settings") or {}))
    net = pf.build_network(diagram, caps={}, assumptions=None, eligible=eligible, islanded=islanded, peak_load_mw=peak_load_mw)
    return net, diagram


# --------------------------------------------------------------------------- operating cases with controls

def _grid_pq(case):
    bus = next((b for b in case["buses"] if b["id"] == IDS["grid"]), None)
    return (bus["gen_mw"], bus["gen_mvar"]) if bus else (0.0, 0.0)


def _solve_controlled(net, spec, inj, label, ratio_target):
    """Choose OLTC position and capacitor stages like an AVR/PF controller would, then solve and evaluate."""
    mv_id = IDS["mv"] if IDS["mv"] in net.index else IDS["hv"]  # no main transformer: HV bus is the plant bus
    mv = net.index[mv_id]
    main = next((b for b in net.branches if b["id"] == "MAIN_TR"), None)
    stage, stages, react = spec["stage_mvar"], spec["stages"], spec["reactor_mvar"]

    def run(k, r, pos):
        if main is not None:
            main["tap"] = 1.0 - TAP_STEP * pos
        net.buses[mv]["shunt_mvar"] = k * stage - (react if r else 0.0)
        return pf.solve_case(net, inj, label=label)

    def tuned(k, r):
        pos, case = 0, run(k, r, 0)
        for _ in range(4):
            if main is None or not case["converged"]:
                break
            vm = next(b["vm"] for b in case["buses"] if b["id"] == mv_id)
            new = max(-TAP_MAX_POS, min(TAP_MAX_POS, pos + int(round((1.0 - vm) / TAP_STEP))))
            if new == pos:
                break
            pos = new
            case = run(k, r, pos)
        return pos, case

    k, r = 0, False
    pos, case = tuned(k, r)
    q_excess = 0.0
    p0, q0 = _grid_pq(case)
    if spec["has_grid"] and p0 > 1e-3:
        q_excess = max(q0 - ratio_target * p0, 0.0)
    while k < stages:
        p, q = _grid_pq(case)
        low_v = any(b["vm"] < net.limits["voltage"][0] for b in case["buses"] if b["energized"])
        if not (spec["has_grid"] and p > 1e-3 and q > ratio_target * p) and not low_v:
            break
        k += 1
        pos, case = tuned(k, r)
    viol = pf.evaluate(net, case)
    if spec["reactor_mvar"] > 0 and any(v["type"] == "voltage_high" for v in viol):
        r = True
        pos, case = tuned(k, r)
        viol = pf.evaluate(net, case)
    return dict(case=case, violations=viol, tap_pos=pos, stages_in=k, reactor_in=r, q_excess=q_excess)


def _case_summary(res, label, hour, inj, net):
    case = res["case"]
    p, q = _grid_pq(case)
    loaded = [b for b in case["branches"] if b["rating_mva"] and b["energized"]]
    skid_v = [b for b in case["buses"] if b["energized"] and b["kv"] < 1.0]
    return dict(label=label, hour_index=hour, timestamp=inj["timestamp"], converged=case["converged"], load_mw=case["load_mw"],
                gen_mw={k: _r(v, 3) for k, v in case["gen_mw"].items()}, grid_mw=_r(p, 3), grid_mvar=_r(q, 3),
                grid_pf=_r(abs(p) / math.hypot(p, q), 4) if math.hypot(p, q) > 1e-6 else None,
                vmin=case["vmin"], vmin_bus=case["vmin_bus"], vmax=case["vmax"], vmax_bus=case["vmax_bus"],
                max_loading_pct=case["max_loading_pct"], max_loading_branch=case["max_loading_branch"], losses_mw=case["losses_mw"],
                tap_pos=res["tap_pos"], tap_ratio=_r(1.0 - TAP_STEP * res["tap_pos"], 5), cap_stages_in=res["stages_in"],
                reactor_in=bool(res["reactor_in"]), violations=[dict(type=v["type"], severity=v["severity"], component=v["component"],
                                                                      value=_r(v["value"], 4), limit=_r(v["limit"], 4), message=v["message"])
                                                                 for v in res["violations"]],
                lv_vmax=max([b["vm"] for b in skid_v], default=None), lv_vmin=min([b["vm"] for b in skid_v], default=None),
                branches=[dict(id=b["id"], loading_pct=b["loading_pct"], p_mw=b["p_from_mw"], q_mvar=b["q_from_mvar"], loss_mw=b["loss_mw"])
                          for b in case["branches"]])


def _run_cases(net, spec, data, picks, ratio_target):
    out = []
    for label, hour in picks:
        inj = pf._hour_inputs(data, hour)
        pf._assign_genset_total(net, data, inj, hour)
        res = _solve_controlled(net, spec, inj, label, ratio_target)
        out.append((label, hour, inj, res))
    return out


def _dedupe_picks(picks):
    seen, out = {}, []
    for label, hour in picks:
        if hour in seen:
            out[seen[hour]] = (out[seen[hour]][0] + " / " + label, hour)
        else:
            seen[hour] = len(out)
            out.append((label, hour))
    return out


def _next_std(value, series):
    return std_rating(value * 1.0001, series) or series[-1]


def _iterate(spec, ctx, data, picks, ratio_target, eligible, islanded, values):
    """Size -> solve -> fix, until the normal cases have no 'fail' violations (max 14 rounds)."""
    log = spec["iterations"]
    final = None
    for it in range(1, 15):
        _fault_levels(spec)
        _size_feeders(spec)
        net, _diagram_used = _network(spec, spec["peak_load_mw"], eligible, islanded)
        results = _run_cases(net, spec, data, picks, ratio_target)
        fails = [(label, v) for label, _h, _i, r in results for v in r["violations"] if v["severity"] == "fail"]
        need_q = max([r["q_excess"] for *_x, r in results] + [0.0])
        pending = spec.get("shunt_pending")
        if need_q > 0.05 and (pending or (spec["stages"] == 0 and not spec["shunt_lock"])) and spec["has_grid"]:
            n_user, s_user = pending or (None, None)
            stage = float(s_user) if s_user else std_rating(need_q / float(n_user or 4), STD_CAP_STAGE) or STD_CAP_STAGE[-1]
            spec["stage_mvar"] = stage
            spec["stages"] = int(n_user) if n_user else max(1, math.ceil(need_q / stage - 1e-9))
            spec["shunt_pending"] = None
            log.append(f"Round {it}: reactive demand at the POI exceeds the tariff/pf target by {need_q:.2f} Mvar -> "
                       f"capacitor bank {spec['stages']} x {stage:g} Mvar at the MV bus.")
            continue
        changed = False
        for label, v in fails:
            comp, typ = v["component"], v["type"]
            if typ == "thermal" and comp == "MAIN_TR" and not spec["main_lock"]:
                need = spec["main_n"] * spec["main_mva"] * v["value"] / 100.0 / 0.95
                n, each = main_transformer_plan(need)
                if (n, each) != (spec["main_n"], spec["main_mva"]):
                    log.append(f"Round {it}: main transformer loaded {v['value']:.0f} % in '{label}' -> {n} x {each:g} MVA.")
                    spec["main_n"], spec["main_mva"] = n, each
                    changed = True
            elif typ == "thermal" and comp and comp.startswith("F_") or typ == "thermal" and comp == "L_INC":
                key = "incoming" if comp == "L_INC" else comp[2:].lower()
                key = {"load": "load"}.get(key, key)
                spec["margin"][key] = spec["margin"].get(key, 1.0) * max(1.1, v["value"] / 100.0 * 1.05)
                log.append(f"Round {it}: {comp} loaded {v['value']:.0f} % in '{label}' -> cable/line margin raised.")
                changed = True
            elif typ == "thermal" and comp and comp.startswith("T_"):
                key = comp[2:].lower()
                pl = spec["plans"].get(key)
                if pl and pl.get("skid_mva") and key not in spec["skid_lock"]:
                    pl["skid_mva"] = _next_std(pl["skid_mva"] * v["value"] / 100.0 / 0.95, STD_SKID_MVA)
                    log.append(f"Round {it}: {comp} loaded {v['value']:.0f} % -> skid transformer {pl['skid_mva']:g} MVA.")
                    changed = True
            elif typ in ("voltage_high", "voltage_low"):
                bus = next((b for b in results[0][3]["case"]["buses"] if b["id"] == comp), None)
                if bus and bus["kv"] < 1.0:
                    key = comp.lower()
                    delta = 0.025 if typ == "voltage_high" else -0.025
                    new = max(-0.05, min(0.05, spec["skid_tap"].get(key, 0.0) + delta))
                    if new != spec["skid_tap"].get(key, 0.0) and key not in spec["tap_lock"]:
                        spec["skid_tap"][key] = new
                        log.append(f"Round {it}: {comp} LV voltage {v['value']:.3f} pu in '{label}' -> off-load tap {new * 100:+.1f} %.")
                        changed = True
                elif typ == "voltage_low" and spec["has_grid"] and spec["stages"] < 12 and not spec["shunt_lock"]:
                    spec["stage_mvar"] = spec["stage_mvar"] or 2.0
                    spec["stages"] += 1
                    log.append(f"Round {it}: voltage {v['value']:.3f} pu low at {comp} in '{label}' -> capacitor stage added "
                               f"({spec['stages']} x {spec['stage_mvar']:g} Mvar).")
                    changed = True
                elif typ == "voltage_high" and spec["reactor_mvar"] == 0 and not spec["reactor_lock"]:
                    spec["reactor_mvar"] = std_rating(max(1.0, spec["peak_load_mw"] * 0.1), STD_REACTOR) or STD_REACTOR[-1]
                    log.append(f"Round {it}: voltage {v['value']:.3f} pu high at {comp} in '{label}' -> {spec['reactor_mvar']:g} Mvar "
                               "shunt reactor at the MV bus.")
                    changed = True
            elif typ == "non_convergence":
                spec["margin"]["load"] = spec["margin"].get("load", 1.0) * 1.1
                if spec["main_tr"] and not spec["main_lock"]:
                    spec["main_n"], spec["main_mva"] = main_transformer_plan(spec["main_n"] * spec["main_mva"] * 1.25)
                log.append(f"Round {it}: case '{label}' did not converge -> transformer/feeder capacity raised 10-25 %.")
                changed = True
        final = (net, results, fails)
        if not fails:
            log.append(f"Round {it}: all {len(results)} cases pass without violations.")
            break
        if not changed:
            log.append(f"Round {it}: {len(fails)} violation(s) remain that automatic sizing cannot clear; see the checks table.")
            break
    return final


def _n1_cases(spec, ctx, data, peak_hour, eligible, islanded, ratio_target):
    out = []
    if not spec["has_grid"]:
        return out
    inj = pf._hour_inputs(data, peak_hour)
    inj_label = "Peak load"
    if spec["main_tr"]:
        saved = spec["main_n"]
        if saved > 1:
            spec["main_n"] = saved - 1
            net, _ = _network(spec, spec["peak_load_mw"], eligible, islanded)
            pf._assign_genset_total(net, data, inj, peak_hour)
            res = _solve_controlled(net, spec, inj, inj_label, ratio_target)
            spec["main_n"] = saved
            out.append(dict(label=f"N-1: one of {saved} main transformers out ({inj_label})", mode="transformer",
                            converged=res["case"]["converged"], max_loading_pct=res["case"]["max_loading_pct"],
                            vmin=res["case"]["vmin"], vmax=res["case"]["vmax"],
                            status="PASS" if not [v for v in res["violations"] if v["severity"] == "fail"] and res["case"]["max_loading_pct"] <= 100 else "FAIL"))
        else:
            out.append(dict(label="N-1: loss of the main transformer", mode="transformer", status="NOT MET",
                            note="Single main transformer: the microgrid loses the grid connection (islanding on BESS/gensets if "
                                 "capable). Add a second unit if grid-connected N-1 is required."))
    return out


# --------------------------------------------------------------------------- the design document

def _tag(value, unit, source, note=""):
    return dict(value=value, unit=unit, source=source, note=note)


def _basis_rows(spec, values, obs, ctx, scen, ratio_target):
    rows = []

    def add(group, name, value, unit, source, note=""):
        rows.append(dict(group=group, name=name, value=value if not isinstance(value, float) else round(value, 4), unit=unit,
                         source=source, note=note))

    add("Demand", "Peak served demand (dispatch horizon)", _r(obs["peak_load"], 2), "MW", "from model", "max net served load in dispatch CSV")
    add("Demand", "Minimum served demand", _r(obs["min_load"], 2), "MW", "from model")
    if obs.get("forecast_peak") is not None:
        add("Demand", "Forecast peak (last year)", _r(obs["forecast_peak"], 2), "MW", "from model", "result economics")
    add("Demand", "Peak grid import / export in dispatch", f"{obs['grid_import']:.2f} / {obs['grid_export']:.2f}", "MW", "from model")
    add("Demand", "Design power factor of load", spec["load_pf"], "lag", spec["load_pf_source"], "typical distribution demand pf")
    add("Voltage", "Grid connection voltage", spec["v_hv"] if spec["has_grid"] else "islanded", "kV" if spec["has_grid"] else "",
        spec["v_hv_source"] if spec["has_grid"] else "from model", "IEC 60038 level chosen from POI MVA unless the SLD grid node sets kV")
    add("Voltage", "Medium-voltage (plant) bus", spec["v_mv"], "kV", spec["v_mv_source"], "lowest IEC level keeping the MV bus <= 2.5 kA")
    ov = spec.get("ov") or {}
    us = lambda key, base="assumed": "user-set" if key in ov else base
    add("Voltage", "Inverter / LV terminal voltage", LV_KV, "kV", us("lv_kv"), "confirm against selected inverter/PCS/WTG OEM")
    add("Voltage", "Nominal frequency", ov.get("frequency_hz", 60.0), "Hz", us("frequency_hz"), "PSS/E case header; change for 50 Hz systems")
    if spec["has_grid"]:
        add("Grid", "Grid short-circuit level (max)", spec["sc_mva"], "MVA", spec["sc_source"], "replace with the utility's stated value")
        add("Grid", "Grid short-circuit current", spec["sc_mva"] / (SQ3 * spec["v_hv"]), "kA", spec["sc_source"], "at the connection voltage")
        add("Grid", "Grid X/R", spec["sc_xr"], "", spec["xr_source"])
        add("Grid", "Power-factor criterion at the POI", f"Q/P <= {ratio_target:.3f}" if values.get("reactive_enabled") else "pf >= 0.95",
            "", "from model" if values.get("reactive_enabled") else "assumed", "reactive tariff ratio from the inputs" if values.get("reactive_enabled") else "")
        add("Grid", "Grid import limit", values.get("grid_limit"), "MW", "from model")
    lim = spec["limits"]
    add("Limits", "Normal voltage range", f"{lim['vmin_pu'][0]:g} - {lim['vmax_pu'][0]:g}", "pu",
        "user-set" if "vmin_pu" in ov or "vmax_pu" in ov else lim["vmin_pu"][1], "ANSI C84.1 Range A")
    add("Limits", "N-1 check criteria", "normal voltage range, loading <= 100 %", "", "assumed", "N-1 cases are held to the normal limits (conservative)")
    add("Limits", "Equipment loading limit", lim["thermal_limit_pct"][0], "% of rating", lim["thermal_limit_pct"][1], "planning alert at 90 %")
    add("Limits", "Cable voltage-drop limit", CABLE_VD_LIMIT_PCT, "%", us("cable_vd_limit_pct"), "at full load, pf 0.95")
    add("Limits", "Cable derating (burial, grouping, ambient)", CABLE_DERATE, "factor", us("cable_derate"), "40 C ambient, 1.0 K.m/W soil, direct burial")
    add("Ambient", "Design ambient temperature", 40, "C", "assumed", "transformer, switchgear, inverter derate; confirm with site data")
    add("Ambient", "Altitude", "<= 1000", "m", "assumed", "no altitude derating applied")
    add("Ambient", "Soil thermal resistivity", 1.0, "K.m/W", "assumed")
    add("Technology", "PV DC/AC ratio", ctx.get("dc_ac", 1.0), "", "from model", "resolved run configuration")
    add("Technology", "BESS round-trip efficiency", values.get("round_trip_efficiency"), "", "from model")
    add("Technology", "BESS SOC window", f"{values.get('soc_min')} - {values.get('soc_max')}", "", "from model")
    add("Technology", "Inverter / unit operating power factor", ", ".join(f"{unit_pf.LABELS.get(k, k)} {s['pf']:g}" for k, s in
        sorted(unit_pf.from_values(values).items()) if k in ("pv", "bess", "wind")), "pf", "from model",
        unit_pf.NOTE + " Reactive capability Qmax = MW x tan(acos(pf)).")
    add("Technology", "Generator operating power factor", ", ".join(f"{unit_pf.LABELS.get(k, k)} {s['pf']:g}" for k, s in
        sorted(unit_pf.from_values(values).items()) if k not in ("pv", "bess", "wind")), "lag", "from model",
        "genset MVA = MW / pf")
    add("Cost basis", "Generation $/MW inputs", dict(unit_pf.COST_BASES)[unit_pf.basis_of(values)],
        "", "from model", unit_pf.BASIS_NOTE)
    add("Study", "System base", pf.BASE_MVA, "MVA", "assumed")
    sz = f"{spec['stages']} x {spec['stage_mvar']:g} Mvar" if spec["stages"] else "none required"
    add("Reactive compensation", "Shunt capacitor bank", sz, "", spec["shunt_source"],
        "sized from the reactive requirement at the POI (stage = std rating >= requirement/4); shunts on the SLD/power-flow page are used as given"
        if spec["shunt_source"] == "assumed" else "set on the SLD / power-flow page or by the user")
    add("Reactive compensation", "Shunt capacitor cost", "extra - not in technology cost or NPC", "", "assumed",
        "the optimiser has no shunt input; indicative cost is in the BOQ (" + str(int(pf.UNIT_COSTS["capacitor_usd_per_kvar"])) + " USD/kvar installed)")
    if spec["reactor_mvar"]:
        add("Reactive compensation", "Shunt reactor", spec["reactor_mvar"], "Mvar", spec["reactor_source"])
    if spec["main_tr"]:
        z, xr = _tz(spec, "main", spec["main_mva"])
        add("Main transformer", "Rating", f"{spec['main_n']} x {spec['main_mva']:g}", "MVA", "user-set" if spec.get("main_lock") else "assumed",
            "standard rating >= POI MVA / 0.9")
        add("Main transformer", "Impedance", z, "% Z", us("main_tr_z_pct"), "typical for the rating")
        add("Main transformer", "X/R", xr, "", us("main_tr_xr"))
        add("Main transformer", "OLTC", f"+/-{TAP_MAX_POS} x {TAP_STEP * 100:g} %", "", "user-set" if "tap_step_pct" in ov or "tap_max_pos" in ov else "assumed")
    add("Station services", "Auxiliary load", spec.get("aux_kw"), "kW", us("aux_load_kw"), "building + HVAC + inverters + gensets + OLTC")
    add("Station services", "Auxiliary transformer", spec.get("aux_kva"), "kVA", us("aux_tr_kva"))
    add("Protection", "Fault clearing time", CLEARING_S, "s", us("clearing_s"), "cable short-circuit withstand check")
    add("Protection", "Neutral earthing resistor current", spec.get("ngr"), "A", us("ngr_a"))
    add("Protection", "MV breaker rating", ov.get("mv_breaker_ka", "next standard above fault duty"), "kA" if "mv_breaker_ka" in ov else "",
        us("mv_breaker_ka"))
    add("Unit sizes", "PV module", ov.get("pv_module_w", 600), "W", us("pv_module_w"), "for module and string counts")
    add("Unit sizes", "Modules per string", ov.get("pv_modules_per_string", 28), "no.", us("pv_modules_per_string"))
    add("Unit sizes", "BESS container", CONTAINER_MWH, "MWh", us("container_mwh"))
    add("Unit sizes", "Spare MV panels", ov.get("mv_spare_panels", 1), "no.", us("mv_spare_panels"))
    for key, plan in spec["plans"].items():
        label = next(g["label"] for g in spec["groups"] if g["kind"] == key)
        add("Unit sizes", f"{label} unit", f"{plan['unit_mva'] if key in ('pv', 'bess') else plan['unit_mw']:g}", "MVA" if key in ("pv", "bess") else "MW",
            us(f"inv_unit_mva.{key}") if key in ("pv", "bess") else us(f"unit_mw.{key}"), "inverter / PCS / turbine / genset frame")
    for key, val in spec["length_km"].items():
        add("Cables", f"Length - {key}", val, "km", spec["length_source"][key])
    add("Study", "Scenario / option", scen, "", "from model")
    detail = spec.get("detail", DEFAULT_DETAIL)
    add("Model detail", "RAW / SLD / report model", DETAIL_LABEL[detail], "", "assumed",
        "Equivalent: each PV/BESS/wind/generator plant is one generator + one equivalent step-up transformer on its collector bus (power-flow "
        "studies). Detailed: every block, transformer and 0.69 kV bus is modelled. BOQ unit counts are per block in both." if detail == "equivalent"
        else "Every block, step-up transformer and 0.69 kV bus is modelled separately (construction layout). Switch to Equivalent for PSS/E studies.")
    f4 = lambda x: f"{round(float(x), 4):g}"
    for e in _equivalence(spec):
        if detail != "equivalent" or (e["blocks"] <= 1 and e["circuits"] <= 1):
            continue
        txt = f"{e['blocks']} x {f4(e['unit_mva'])} MVA blocks -> 1 x {f4(e['equivalent_gen_mva'])} MVA generator"
        if e.get("block_mva"):
            txt += (f"; {e['blocks']} x {f4(e['block_mva'])} MVA step-up transformers (Z {f4(e['z_pct'])} %) -> 1 x {f4(e['equivalent_mva'])} MVA "
                    f"(Z {f4(e['z_pct'])} % on its own base = {f4(e['z_pu_equiv'])} pu on 100 MVA, parallel of {f4(e['z_pu_block'])} pu / {e['blocks']})")
        if e["circuits"] > 1:
            txt += f"; {e['circuits']} collector circuits -> 1 equivalent circuit (Z/{e['circuits']}, rating x {e['circuits']})"
        add("Model detail", f"Equivalent {e['label']} plant", txt, "", "assumed",
            "total MW/MVA and parallel impedance preserved; identical blocks assumed (same loading); no per-block bus voltages")
    for x in ctx.get("excluded_techs") or []:
        add("Technologies", x["label"], x["reason"], "", "from model", x["note"])
    return rows


def _equivalence(spec):
    """Per technology: block count, block and equivalent MVA/impedance (pu on the 100 MVA system base) for the equivalent RAW model."""
    out = []
    for g in spec["groups"]:
        k, pl = g["kind"], spec["plans"][g["kind"]]
        n = int(pl["n"])
        row = dict(tech=k, label=g["label"], blocks=n, circuits=int(spec["feeders"][k]["circuits"]), unit_mva=float(pl["unit_mva"]),
                   equivalent_gen_mva=round(float(pl["unit_mva"]) * n, 4), has_gsu=bool(pl["has_gsu"]))
        if pl["has_gsu"]:
            z, xr = _tz(spec, k, max(pl["skid_mva"], 2.5))
            s = float(pl["skid_mva"])
            row.update(block_mva=s, equivalent_mva=round(s * n, 4), z_pct=z, xr=xr, z_pu_block=round(z / s, 4), z_pu_equiv=round(z / (s * n), 4))
        out.append(row)
    return out


class Equip:
    def __init__(self):
        self.rows = []

    def add(self, ident, category, type_, desc, rating, voltage, qty, params=None, basis="assumed", flag=None, status="new"):
        self.rows.append(dict(id=ident, category=category, type=type_, description=desc, rating=rating, voltage=voltage, quantity=qty,
                              params=params or {}, basis=basis, flag=flag, status=status))


def _breaker_rating(i_amps, isc_ka):
    return std_rating(i_amps, STD_AMPS) or STD_AMPS[-1], std_rating(isc_ka, STD_ISC_KA) or STD_ISC_KA[-1]


def _brk_mv(spec, i_amps, isc_ka):
    """MV breaker/busbar rating; a user short-circuit rating replaces the standard one chosen from the fault duty."""
    a, ka = _breaker_rating(i_amps, isc_ka)
    user = (spec.get("ov") or {}).get("mv_breaker_ka")
    return a, (float(user) if user else ka)


def recommended_scenario(run_id, summary=None):
    """The option the rest of the app recommends (workflow ranking) with the cost-based best as the fallback."""
    try:
        import workflow
        code = (workflow.get(run_id).get("recommended") or {}).get("code")
        if code:
            return code
    except Exception:
        pass
    return best_scenario(summary or {})


def _signature(folder, code):
    parts = []
    for path in sorted(folder.glob("*.json")) + sorted(folder.glob(f"*{code}*.csv")):
        try:
            s = path.stat()
            parts.append((path.name, s.st_size, s.st_mtime_ns))
        except OSError:
            pass
    return tuple(parts)


def scenario_options(run_id):
    folder = extensions.run_folder(run_id)
    summary = (json.loads((folder / "status.json").read_text(encoding="utf-8")).get("summary") or {})
    best = recommended_scenario(run_id, summary)
    out = [dict(code=r.get("code"), name=r.get("name") or r.get("code"), recommended=r.get("code") == best)
           for r in summary.get("results") or [] if r.get("code")]
    if not out:
        raise ValueError("The saved run has no solved scenario to design.")
    return dict(run_id=run_id, recommended=best, options=out)


_LOCK = threading.Lock()
LOCK_TIMEOUT_S = 180


def build_design(run_id, scenario=None, overrides=None, detail=None):
    """Design dict for one saved-run scenario (None = the recommended option); cached, thread-safe, JSON-safe, <= 4 decimals.

    detail: 'equivalent' (default; one generator + one equivalent step-up transformer per plant in the RAW/SLD) or 'detailed'
    (every block).  Both variants come from one solve and are cached together.

    Builds are serialised: the Newton solver and the shared cache are not safe to run from several request threads at once, and a
    second request for the same option then reuses the first result instead of recomputing it."""
    detail = norm_detail(detail)
    folder = extensions.run_folder(run_id)
    summary = (json.loads((folder / "status.json").read_text(encoding="utf-8")).get("summary") or {})
    code = scenario or recommended_scenario(run_id, summary)
    if not code:
        raise ValueError("The saved run has no solved scenario to design.")
    if code not in {r.get("code") for r in summary.get("results") or []} or not (folder / f"result_{code}.json").is_file():
        raise ValueError(f"Scenario {code} is not in this saved run.")
    if overrides is None:
        overrides = load_overrides(run_id, code)["values"]
    base_key = (str(folder), code, _signature(folder, code), json.dumps(overrides or {}, sort_keys=True))
    key = base_key + (detail,)
    with _CACHE_LOCK:
        if key in _CACHE:
            return _CACHE[key]
    if not _LOCK.acquire(timeout=LOCK_TIMEOUT_S):
        raise ValueError("The design engine is busy with another request; try again in a moment.")
    try:
        with _CACHE_LOCK:
            if key in _CACHE:
                return _CACHE[key]
        variants = _build_design(folder, run_id, code, summary, overrides)
        with _CACHE_LOCK:
            for name, design in variants.items():
                design = {k: (v if k == "raw_model" else clean(v)) for k, v in design.items()}
                variants[name] = design
                while len(_CACHE) >= CACHE_SIZE:
                    _CACHE.pop(next(iter(_CACHE)))
                _CACHE[base_key + (name,)] = design
        return variants[detail]
    finally:
        _LOCK.release()


def _effective_techs(result, data, planned, eligible, folder=None):
    """Technologies that are actually built AND dispatched: (set of keys, excluded rows [{tech, label, reason, note}]).

    Uses workflow.effective_technologies(result) when the workflow module provides it; otherwise built capacity (result caps, or
    existing/planned capacity) and dispatch energy from the saved hourly dispatch decide.  A technology the optimiser did not build
    (0 MW) or that never dispatches is excluded from the design (SLD, RAW, equipment, BOQ) and listed as a note instead."""
    caps = result.get("caps") or {}
    built = {"pv": _num(caps.get("pv_dc_mw")), "bess": _num(caps.get("bess_mw")), "wind": _num(caps.get("wind_mw"))}
    for key, value in (caps.get("generators_mw") or {}).items():
        built[key] = _num(value)
    if _num(caps.get("generator_mw")) > 0 and not any(k in pf.GENSETS and v > 0 for k, v in built.items()):
        built["ng"] = _num(caps.get("generator_mw"))
    existing = {"pv": sum(p["mw"] for p in planned["pv"]) + sum(t["pv_mw"] for t in planned["trailers"]),
                "bess": sum(p["mw"] for p in planned["bess"]) + sum(t["bess_mw"] for t in planned["trailers"]),
                "wind": sum(p["mw"] for p in planned["wind"])}
    energy = {"pv": float(pf._series(data, "solar_output").sum() + pf._series(data, "planned_solar_used").sum() + pf._series(data, "pv").sum()),
              "bess": float(pf._series(data, "charge").sum() + pf._series(data, "discharge").sum()),
              "wind": float(pf._series(data, "planned_wind_used").sum() + pf._series(data, "wind").sum())}
    has_col = lambda c: c in data
    used = set()
    for tech in pf.TECH_GEN:
        if tech in pf.GENSETS:
            col = f"gen_{tech}"
            dispatched = float(pf._series(data, col).sum()) > 1e-6 if has_col(col) else True
        else:
            dispatched = energy[tech] > 1e-6
        if (built.get(tech, 0.0) > 1e-6 and dispatched) or existing.get(tech, 0.0) > 1e-6:
            used.add(tech)
    wf = getattr(_workflow(), "effective_technologies", None)
    if callable(wf):
        try:
            alias = {"solar": "pv", "solar_pv": "pv", "battery": "bess", "storage": "bess"}
            got = wf(result, folder) if folder is not None else wf(result)
            if isinstance(got, dict):
                got = got.get("effective") if "effective" in got else [k for k, v in got.items() if v]
            got = {alias.get(str(k).lower(), str(k).lower()) for k in got}
            if got & set(pf.TECH_GEN) or not got:
                used = got & set(pf.TECH_GEN) | {t for t in used if existing.get(t, 0.0) > 1e-6}
        except Exception:
            pass
    excluded = []
    for tech in sorted(set(eligible or ()) - {"grid"}):
        if tech in used or tech not in pf.TECH_GEN:
            continue
        label = GEN_LABEL.get(tech) or {"pv": "Solar PV", "bess": "BESS", "wind": "Wind"}.get(tech, tech)
        if built.get(tech, 0.0) > 1e-6:
            reason, note = "not dispatched", f"{label} built but never dispatches (0 MWh): not designed"
        else:
            reason, note = "not built", f"{label} eligible but not built (0 MW)"
        excluded.append(dict(tech=tech, label=label, reason=reason, note=note))
    return used, excluded


def _workflow():
    try:
        import workflow
        return workflow
    except Exception:
        return object()


def _build_design(folder, run_id, code, summary, overrides=None):
    best = recommended_scenario(run_id, summary)
    ctx = pf._run_context(folder, code)
    written = load_overrides(run_id, code)["written"]
    if written and ctx.get("topology"):
        ctx["topology"] = _restore_topology(ctx["topology"], code, written)
    result = json.loads((folder / f"result_{code}.json").read_text(encoding="utf-8"))
    request = ctx["request"] or {}
    values = dict(request.get("values") or {})
    cfg = {}
    if (folder / "run_configuration.json").is_file():
        cfg = json.loads((folder / "run_configuration.json").read_text(encoding="utf-8"))
    ctx["dc_ac"] = _num(_find_key(cfg.get("resolved") or {}, "dc_ac"), 1.0) or 1.0
    values["_dc_ac"] = ctx["dc_ac"]
    ctx["bess_mwh"] = (result.get("caps") or {}).get("bess_mwh") or 0.0
    data = pf._read_dispatch(ctx["path"])
    diagram = pf._diagram(ctx["topology"], code)
    eligible = result.get("eligible_technologies")
    elig_set = set(eligible) if eligible is not None else set(pf.TECH_GEN) | {"grid"}
    planned = _planned_items(request)
    used, excluded = _effective_techs(result, data, planned, elig_set, folder)
    elig_set = {t for t in elig_set if t == "grid" or t in used or t not in pf.TECH_GEN}
    has_grid = "grid" in elig_set and not ctx["islanded"]
    load_key = "net_served_load_mw" if "net_served_load_mw" in data else "net_load_mw"
    grid = pf._series(data, "grid")
    pv_series = (data["solar_output"] + pf._series(data, "planned_solar_used")) if "solar_output" in data else pf._series(data, "pv")
    obs = dict(peak_load=float(pf._series(data, load_key).max()), min_load=float(pf._series(data, load_key).min()),
               grid_import=float(grid.max()), grid_export=float(max(-grid.min(), 0.0)), pv=float(pv_series.max()),
               bess=float(max(pf._series(data, "discharge").max(), pf._series(data, "charge").max())),
               wind=float(pf._series(data, "planned_wind_used").max()))
    annual = (result.get("economics") or {}).get("annual") or []
    obs["forecast_peak"] = max([a.get("forecast_peak_mw") or 0.0 for a in annual], default=None) or None
    ov = validate_overrides(overrides) if overrides is not None else {}
    groups = _gen_groups(ctx, values, planned, obs, elig_set)
    ctx["excluded_techs"] = excluded
    patched = _patch_constants(ov)
    try:
        return _build_design_ov(folder, run_id, code, summary, best, ctx, result, values, data, diagram, elig_set, has_grid, obs, groups,
                                planned, ov)
    finally:
        _patch_constants(None, patched)


def _patch_constants(ov, restore=None):
    """Temporarily swap the module-level design constants for user values (the caller holds _LOCK)."""
    names = dict(lv_kv="LV_KV", tap_step_pct="TAP_STEP", tap_max_pos="TAP_MAX_POS", container_mwh="CONTAINER_MWH", cable_derate="CABLE_DERATE",
                 cable_vd_limit_pct="CABLE_VD_LIMIT_PCT", clearing_s="CLEARING_S")
    g = globals()
    if restore is not None:
        g.update(restore)
        return None
    saved = {n: g[n] for n in list(names.values()) + ["STD_MAIN_MVA"] if n in g}
    if float(ov.get("frequency_hz", 60.0)) == 50.0:
        g["STD_MAIN_MVA"] = STD_MAIN_MVA_IEC
    for key, name in names.items():
        if key in ov and name in g:
            g[name] = float(ov[key]) / (100.0 if key == "tap_step_pct" else 1.0)
            if key == "tap_max_pos":
                g[name] = int(ov[key])
    return saved


def _build_design_ov(folder, run_id, code, summary, best, ctx, result, values, data, diagram, elig_set, has_grid, obs, groups, planned, ov):
    spec = _initial_spec(ctx, diagram, values, data, groups, obs, planned, has_grid, ov)
    spec["ov"] = ov
    spec["excluded"] = ctx.get("excluded_techs") or []
    ratio_target = _num(values.get("reactive_ratio"), 0.329) if values.get("reactive_enabled") else 0.329
    picks, peak_hour = pf._hour_selection(data)
    picks = _dedupe_picks(picks)
    islanded = not has_grid
    final = _iterate(spec, ctx, data, picks, ratio_target, elig_set, islanded, values)
    net, case_results, fails = final
    n1 = _n1_cases(spec, ctx, data, peak_hour, elig_set, islanded, ratio_target)
    _fault_levels(spec)
    spec["names"] = display_names(spec, diagram, planned)
    variants = {}
    for detail in DETAILS:
        spec["detail"] = detail
        design = _assemble(folder, run_id, code, best, result, summary, values, spec, ctx, obs, planned, case_results, fails, n1,
                           ratio_target, data, net)
        design["effective"] = _effective(spec)
        design["topo_map"] = _topo_map(spec)
        design["effective_technologies"] = dict(
            used=[g["kind"] for g in spec["groups"]], excluded=ctx.get("excluded_techs") or [],
            notes=[x["note"] for x in ctx.get("excluded_techs") or []])
        variants[detail] = design
    return variants


_CACHE = {}
_CACHE_LOCK = threading.Lock()
CACHE_SIZE = 24


def _tag_plants(rows, spec):
    """Attach the plant name and PSS/E bus number/name to the equipment of each technology."""
    N, NM, L = spec["names"]["bus"], spec["names"]["name"], spec["names"]["label"]
    prefixes = {"load": ("CB-LOAD", "CAB-LOAD")}
    for g in spec["groups"]:
        k = g["kind"]
        K = k.upper()
        prefixes[k] = {"pv": ("PV-",), "bess": ("BESS-",), "wind": ("WTG",)}.get(k, (f"GEN-{K}", f"GSU-{K}")) + (f"CAB-{K}", f"CB-{K}")
    for key, pre in prefixes.items():
        for r in rows:
            if r["id"].startswith(pre):
                r["params"] = dict(r["params"], plant=L[key], bus_number=N[key], bus_name=NM[key])
    for r in rows:
        if r["id"].startswith("TR-MAIN"):
            r["params"] = dict(r["params"], hv_bus=f"{N['hv']} {NM['hv']}", lv_bus=f"{N['main']} {NM['main']}")
        elif r["id"].startswith(("SWG-MV", "CAP-", "REAC")):
            r["params"] = dict(r["params"], bus_number=N["main"], bus_name=NM["main"])


def _assemble(folder, run_id, code, best, result, summary, values, spec, ctx, obs, planned, case_results, fails, n1, ratio_target, data, net):
    eq = Equip()
    ov = spec.get("ov") or {}
    v_mv, v_hv = spec["v_mv"], spec["v_hv"]
    plans, feeders = spec["plans"], spec["feeders"]
    isc_mv, isc_hv = spec["isc_mv_ka"], spec["isc_hv_ka"]
    flags = []
    totals = {}
    # ---- utility interconnection and substation
    if spec["has_grid"]:
        inc = feeders["incoming"]
        i_poi = spec["s_poi_mva"] / (SQ3 * v_hv) * 1000.0
        cb_a, cb_ka = _breaker_rating(i_poi * 1.25, isc_hv)
        eq.add("UTIL-01", "Utility interconnection", "Point of interconnection", "Utility connection point / revenue metering boundary",
               f"{spec['sc_mva']:.0f} MVA short-circuit", v_hv, 1,
               dict(sc_mva=spec["sc_mva"], sc_ka=_r(spec["sc_mva"] / (SQ3 * v_hv), 2), xr=spec["sc_xr"], nominal_hz=60),
               basis=spec["sc_source"], flag="Confirm short-circuit level, voltage and protection requirements in the utility connection offer.")
        eq.add("LN-01", "Utility interconnection", "Incoming line" if inc["type"] == "overhead" else "Incoming cable",
               f"{inc['basis']} x {inc['circuits']} circuit(s), {inc['length_km']:.2f} km ({spec['length_source']['incoming']} length)",
               f"{inc['derated_a'] * inc['circuits']:.0f} A", v_hv, inc["circuits"],
               dict(area_mm2=inc["area"], r_ohm_km=inc["r"], x_ohm_km=inc["x"], b_us_km=inc["b"], length_km=inc["length_km"],
                    loading_pct=inc["loading_pct"], voltage_drop_pct=inc["vd_pct"]), basis="assumed",
               flag=None if spec["length_source"]["incoming"] == "model" else "Line length is a default; survey the route.")
        eq.add("CB-HV-01", "Utility interconnection", "HV circuit breaker (SF6/vacuum)", "Incoming line breaker with disconnectors and earth switches",
               f"{cb_a} A / {cb_ka} kA 3 s", v_hv, 1, dict(rated_current_a=cb_a, short_circuit_ka=cb_ka, fault_duty_ka=_r(isc_hv, 2),
                                                          insulation="per IEC 62271-1 for the system voltage"), basis="assumed")
        eq.add("BUS-HV-01", "Utility interconnection", "HV busbar", "Substation HV busbar (single bus)", f"{cb_a} A / {cb_ka} kA", v_hv, 1,
               dict(rated_current_a=cb_a, short_circuit_ka=cb_ka), basis="assumed")
        eq.add("CT-VT-HV", "Metering", "Revenue metering CT/VT set", "Class 0.2S CT and 0.2 VT at the POI (utility approval needed)",
               "0.2S / 0.2", v_hv, 1, dict(ct_ratio_a=f"{std_rating(i_poi, STD_AMPS)}/1", vt_ratio=f"{v_hv * 1000:.0f}/110 V"), basis="assumed",
               flag="Metering class and location per utility rules.")
        eq.add("SA-HV", "Utility interconnection", "Surge arresters", "Metal-oxide arresters at line entry and transformer",
               f"Ur {arrester_rating_kv(v_hv):g} kV", v_hv, 6, dict(duty="station class, metal-oxide, effectively earthed system",
                                                                    rated_voltage_kv=arrester_rating_kv(v_hv), um_kv=highest_voltage_kv(v_hv)), basis="assumed")
    # ---- main transformers
    if spec["main_tr"]:
        z, xr = _tz(spec, "main", spec["main_mva"])
        p0, pk = transformer_losses(spec["main_mva"], z, xr)
        onan = spec["main_mva"] * 0.8 if spec["main_mva"] >= 10 else spec["main_mva"]
        cooling = "ONAN/ONAF" if spec["main_mva"] >= 10 else "ONAN"
        pos = [r["tap_pos"] for r in case_results_iter(case_results)]
        eq.add("TR-MAIN", "Transformers", "Main power transformer (step-down)",
               f"{v_hv:g}/{v_mv:g} kV, {cooling}, OLTC +/-10 % in 16 steps, ONAF rating shown",
               f"{onan:.1f}/{spec['main_mva']:g} MVA" if cooling == "ONAN/ONAF" else f"{spec['main_mva']:g} MVA", f"{v_hv:g}/{v_mv:g}", spec["main_n"],
               dict(mva_onaf=spec["main_mva"], mva_onan=round(onan, 2), z_pct=z, xr=xr, vector_group="Dyn11" if v_hv >= v_mv else "Yd11",
                    cooling=cooling, tap_changer="OLTC on HV winding, +/-10 % in 16 x 1.25 % steps (17 positions), AVR on MV bus",
                    tap_range_used=[min(pos), max(pos)] if pos else None, no_load_loss_kw=p0, load_loss_kw=pk,
                    efficiency_pct=round(100 * (1 - (p0 + pk) / (spec["main_mva"] * 1000 * 0.95 + p0 + pk)), 3),
                    neutral="MV neutral earthed through NGR; HV delta", bil_kv="per IEC 60076-3 for the voltage class",
                    loading_peak_pct=_max_loading(case_results, "MAIN_TR")),
               basis="assumed", flag="Confirm %Z, vector group and OLTC with the utility/OEM; rating sized from the largest POI flow / 0.90.")
        totals["main_transformer_mva"] = spec["main_n"] * spec["main_mva"]
    # ---- MV switchgear and busbar
    s_mv_a = max(spec["main_n"] * spec["main_mva"] if spec["main_tr"] else spec["s_poi_mva"], 1.0) / (SQ3 * v_mv) * 1000.0
    bus_a, bus_ka = _brk_mv(spec, s_mv_a, isc_mv)
    eq.add("SWG-MV-01", "MV switchgear", "MV metal-clad switchgear", f"Single busbar, {len(spec['groups']) + 4} bays, arc-resistant (IAC AFLR), "
           "vacuum circuit breakers", f"{bus_a} A / {bus_ka} kA 3 s", v_mv, 1,
           dict(busbar_a=bus_a, short_circuit_ka=bus_ka, fault_duty_ka=_r(isc_mv, 2), duty_margin_pct=_r((bus_ka / isc_mv - 1) * 100, 1),
                insulation_kv=f"{highest_voltage_kv(v_mv):g} kV class", ip="IP4X"), basis="assumed",
           flag="Fault duty = grid source through the main transformer + local sources (inverters 1.1 pu, generators 1/Xd'') summed arithmetically, no IEC 60909 c-factor or K_T; confirm with a short-circuit study.")
    bays = [("CB-LOAD", "Load feeder breaker", "load", feeders["load"], spec["peak_load_mw"] / spec["load_pf"])]
    for g in spec["groups"]:
        bays.append((f"CB-{g['kind'].upper()}", f"{g['label']} feeder breaker", g["kind"], feeders[g["kind"]], plans[g["kind"]]["s_total"]))
    for ident, desc, kind, cab, s_mva in bays:
        i_a = s_mva / (SQ3 * v_mv) * 1000.0
        a, ka = _brk_mv(spec, i_a, isc_mv)
        eq.add(ident, "MV switchgear", "MV feeder breaker", desc, f"{a} A / {ka} kA", v_mv, 1,
               dict(load_current_a=_r(i_a, 0), relays="50/51, 50N/51N, 67/67N" if kind == "load" else "50/51, 50N/51N, 27/59, 81, 25"),
               basis="assumed")
    if spec["main_tr"]:
        a, ka = _brk_mv(spec, s_mv_a, isc_mv)
        eq.add("CB-MAIN-MV", "MV switchgear", "MV incomer breaker", "Main transformer MV incomer with 87T/REF interface",
               f"{a} A / {ka} kA", v_mv, spec["main_n"], dict(relays="50/51, 50N/51N, 87T, 64REF, 27/59, 81, 25"), basis="assumed")
    # ---- feeders / cables
    for key, f in feeders.items():
        if key == "incoming":
            continue
        name = "Load" if key == "load" else dict((g["kind"], g["label"]) for g in spec["groups"])[key]
        n = f["circuits"]
        eq.add(f"CAB-{key.upper()}", "Feeders and cables", "MV power cable (3-core Al XLPE)",
               f"{name} feeder: {n} x {f['area']} mm2, {f['length_km']:.2f} km ({spec['length_source'][key]} length)",
               f"{f['derated_a'] * n:.0f} A derated", v_mv, n,
               dict(area_mm2=f["area"], r_ohm_km=f["r"], x_ohm_km=f["x"], b_us_km=f["b"], length_km=f["length_km"], circuits=n,
                    load_current_a=f["i_per_circuit"] * n, loading_pct=f["loading_pct"], voltage_drop_pct=f["vd_pct"],
                    sc_withstand=f"{CABLE_K_AL * f['area'] / math.sqrt(CLEARING_S) / 1000:.1f} kA / {CLEARING_S:g} s"),
               basis="assumed", flag=None if spec["length_source"][key] == "model" else "Length is a default; confirm routing and installation.")
    # ---- technologies
    land = []
    for g in spec["groups"]:
        k, pl = g["kind"], plans[g["kind"]]
        if k in ("pv", "bess", "wind") or pl["has_gsu"]:
            z, xr = _tz(spec, k, max(pl["skid_mva"], 2.5))
            p0, pk = transformer_losses(pl["skid_mva"], z, xr)
        if k == "pv":
            new = [x for x in g["parts"] if x["status"] == "new"]
            dc_total = sum(x["dc_mw"] for x in g["parts"])
            eq.add("PV-INV", "Solar PV", "Central/skid PV inverter", f"{pl['n']} x {pl['unit_mva']:g} MVA inverter blocks (DC/AC {g['dc_ac']:.2f})",
                   f"{pl['unit_mva']:g} MVA each", f"{LV_KV:g} kV AC", pl["n"],
                   dict(total_mva=pl["s_total"], p_at_unity_mw=_r(pl["s_total"], 2), p_at_pf095_mw=pl["p_unity_mw"],
                        operating_pf=pl["pf"], p_at_operating_pf_mw=pl["p_unity_mw"],
                        q_range_mvar=f"+{_r(pl['p_unity_mw'] * unit_pf.tan_phi(pl['pf']), 2)} / -{_r(pl['p_unity_mw'] * unit_pf.tan_phi(pl['pf_lead']), 2)}",
                        dc_mw=_r(dc_total, 3), dc_ac_ratio=g["dc_ac"], modules=f"DC array of utility-scale modules ({ov.get('pv_module_w', 600):g} W class, {'user-set' if 'pv_module_w' in ov else 'assumed'})",
                        ppc_modes="Q/V, pf, Q setpoint, ramp-rate, curtailment (via plant controller)"), basis="model",
                   flag=f"Inverter ratings assume {pl['pf']:g} pf capability at full MW (MVA = MW / pf); confirm with OEM thermal derating at 40 C.")
            eq.add("PV-TR", "Transformers", "PV step-up skid transformer", f"{v_mv:g}/{LV_KV:g} kV, ONAN/KNAN (liquid-filled), Dyn11",
                   f"{pl['skid_mva']:g} MVA each", f"{v_mv:g}/{LV_KV:g}", pl["n"],
                   dict(mva=pl["skid_mva"], z_pct=z, xr=xr, vector_group="Dyn11", no_load_loss_kw=p0, load_loss_kw=pk,
                        taps="+/-2 x 2.5 % off-circuit", tap_selected_pct=round(spec["skid_tap"].get("pv", 0.0) * 100, 1),
                        loading_peak_pct=_max_loading(case_results, "T_PV")), basis="assumed")
            for part in g["parts"]:
                totals.setdefault("pv_parts", []).append(dict(name=part["name"], status=part["status"], dc_mw=_r(part["dc_mw"], 4), ac_mw=_r(part["ac_mw"], 4)))
            totals["pv_dc_mw_new"] = _r(sum(x["dc_mw"] for x in new), 6)
            totals["pv_ac_mw_total"] = _r(g["p_mw"], 4)
            totals["pv_inverter_mva_installed"] = pl["s_total"]
            if values.get("solar_land_enabled") and values.get("solar_acres_per_mw"):
                land.append(("PV array", dc_total * float(values["solar_acres_per_mw"]), "acres", "from model (land input, acres per MWdc)"))
            else:
                land.append(("PV array", g["p_mw"] * ACRES_PER_PV_MWAC, "acres", f"assumed {ACRES_PER_PV_MWAC:g} acres/MWac"))
        elif k == "bess":
            nm = sum(x["mw"] for x in g["parts"])
            mwh = pl["mwh"]
            soc_w = (values.get("soc_max", 0.9) - values.get("soc_min", 0.1))
            rte = values.get("round_trip_efficiency", 0.85)
            eq.add("BESS-PCS", "BESS", "Battery PCS (inverter)", f"{pl['n']} x {pl['unit_mva']:g} MVA bi-directional PCS, grid-following with grid-forming capability",
                   f"{pl['unit_mva']:g} MVA each", f"{LV_KV:g} kV AC", pl["n"],
                   dict(total_mva=pl["s_total"], operating_pf=pl["pf"], p_discharge_mw=_r(nm, 3), q_range_mvar=f"+/-{_r(math.sqrt(max(pl['s_total'] ** 2 - nm ** 2, 0)), 2)} at rated MW",
                        efficiency_rt=rte, modes="PQ, Vf (black start/island) option"), basis="model")
            eq.add("BESS-CONT", "BESS", "Battery container (DC block, 20 ft)", f"{pl['containers']} x {CONTAINER_MWH:g} MWh LFP containers ({pl['containers_per_pcs']} per PCS)",
                   f"{CONTAINER_MWH:g} MWh each", "DC", pl["containers"],
                   dict(nameplate_mwh=_r(mwh, 3), installed_mwh=_r(pl["containers"] * CONTAINER_MWH, 2), duration_h=_r(mwh / nm, 2) if nm else None,
                        soc_window=f"{values.get('soc_min')}-{values.get('soc_max')}", usable_mwh=_r(mwh * soc_w, 3), round_trip_eff=rte,
                        aux_load_kw_each=25, fire="gas detection, deflagration vents, per NFPA 855", chemistry="LFP (assumed)"), basis="model",
                   flag="Containers are a typical 3.35 MWh unit; confirm vendor block size, degradation margin and augmentation.")
            eq.add("BESS-TR", "Transformers", "BESS step-up skid transformer", f"{v_mv:g}/{LV_KV:g} kV, Dyn11", f"{pl['skid_mva']:g} MVA each",
                   f"{v_mv:g}/{LV_KV:g}", pl["n"], dict(mva=pl["skid_mva"], z_pct=z, xr=xr, vector_group="Dyn11", no_load_loss_kw=p0,
                                                       load_loss_kw=pk, loading_peak_pct=_max_loading(case_results, "T_BESS")), basis="assumed")
            totals.update(bess_mw_new=_r(sum(x["mw"] for x in g["parts"] if x["status"] == "new"), 6),
                          bess_mwh_new=_r(sum(x["mwh"] for x in g["parts"] if x["status"] == "new"), 6),
                          bess_pcs_mva_installed=pl["s_total"], bess_containers=pl["containers"])
            if values.get("bess_land_enabled") and (values.get("bess_acres_per_mw") or values.get("bess_acres_per_mwh")):
                land.append(("BESS site", nm * _num(values.get("bess_acres_per_mw")) + mwh * _num(values.get("bess_acres_per_mwh")), "acres",
                             "from model (land inputs, acres per MW and per MWh)"))
            else:
                land.append(("BESS containers, PCS skids and clearances", mwh * ACRES_PER_BESS_MWH, "acres",
                             f"assumed {ACRES_PER_BESS_MWH:g} acre/MWh (~{1 / ACRES_PER_BESS_MWH:.0f} MWh/acre) incl. fire clearances and access"))
        elif k == "wind":
            eq.add("WTG", "Wind", "Wind turbine generator", f"{pl['n']} x {pl['unit_mw']:g} MW WTG", f"{pl['unit_mw']:g} MW each", f"{LV_KV:g} kV", pl["n"],
                   dict(total_mw=_r(pl["unit_mw"] * pl["n"], 2), total_mva=pl["s_total"], operating_pf=pl["pf"],
                        q_range=f"pf {pl['pf']:g} at rated MW (+{_r(pl['unit_mw'] * pl['n'] * unit_pf.tan_phi(pl['pf']), 2)} / -{_r(pl['unit_mw'] * pl['n'] * unit_pf.tan_phi(pl['pf_lead']), 2)} Mvar)"), basis="model")
            eq.add("WTG-TR", "Transformers", "WTG pad-mount transformer", f"{v_mv:g}/{LV_KV:g} kV", f"{pl['skid_mva']:g} MVA each", f"{v_mv:g}/{LV_KV:g}",
                   pl["n"], dict(mva=pl["skid_mva"], z_pct=z, xr=xr, vector_group="Dyn11", no_load_loss_kw=p0, load_loss_kw=pk), basis="assumed")
            totals["wind_mw"] = _r(pl["unit_mw"] * pl["n"], 3)
            if values.get("wind_land_enabled") and values.get("wind_acres_per_mw"):
                land.append(("Wind site", pl["unit_mw"] * pl["n"] * float(values["wind_acres_per_mw"]), "acres", "from model (land input, acres per MW)"))
            else:
                land.append(("Wind turbine pads and access roads (permanent)", pl["unit_mw"] * pl["n"] * ACRES_PER_WIND_MW, "acres",
                             f"assumed {ACRES_PER_WIND_MW:g} acre/MW permanent footprint; spacing area excluded"))
        else:
            totals.setdefault("generators_mw_required", {})[k] = _r(g["p_mw"], 6)
            totals.setdefault("generators_mw_installed", {})[k] = pl["total_mw"]
            eff = values.get(f"{k}_efficiency")
            eq.add(f"GEN-{k.upper()}", "Generators", g["label"], f"{pl['n']} x {pl['unit_mw']:g} MW unit(s), {v_mv if not pl['has_gsu'] else LV_KV:g} kV generator terminals",
                   f"{pl['unit_mw']:g} MW ({pl['unit_mva']:.2f} MVA) each", pl["voltage_kv"], pl["n"],
                   dict(total_mw=pl["total_mw"], required_mw=_r(g["p_mw"], 3), xd2_pu=pl["xd2"], xd1_pu=pl["xd1"], xd_pu=pl["xd"],
                        power_factor=f"{pl['pf']:g} lag / {pl['pf_lead']:g} lead", total_mva=pl["s_total"], min_stable_load_pct=pl["min_load_pct"], fuel_efficiency=eff,
                        heat_rate_btu_kwh=_r(3412.14 / eff, 0) if eff else None, avr="static exciter + AVR (voltage control)",
                        governor="isochronous/droop selectable", sync="auto-synchroniser (25)"), basis="model",
                   flag="Frame sizes are typical; confirm with OEM site rating (altitude, ambient, fuel).")
            if pl["has_gsu"]:
                eq.add(f"GSU-{k.upper()}", "Transformers", "Generator step-up transformer", f"{v_mv:g}/{LV_KV:g} kV, Dyn11", f"{pl['skid_mva']:g} MVA each",
                       f"{v_mv:g}/{LV_KV:g}", pl["n"], dict(mva=pl["skid_mva"], z_pct=z, xr=xr, vector_group="Dyn11", no_load_loss_kw=p0,
                                                           load_loss_kw=pk), basis="assumed")
            land.append((f"{g['label']} plant", pl["total_mw"] * 0.3, "acres", "assumed 0.3 acre/MW incl. fuel skid/laydown"))
    # ---- mobile trailers (not separate in the solver)
    for t in planned["trailers"]:
        gross = max(t["pv_mw"], t["bess_mw"], 0.1)
        s = std_rating(gross / PF_CAP, STD_SKID_MVA) or STD_SKID_MVA[-1]
        eq.add("TRL-" + str(planned["trailers"].index(t) + 1), "Mobile trailers", "Mobile PV/BESS trailer interconnection",
               f"{t['name']}: gross PV {t['pv_mw']:.2f} MW, BESS {t['bess_mw']:.2f} MW / {t['bess_mwh']:.2f} MWh; {t['avail'] * 100:.0f} % daily availability",
               f"{s:g} MVA connection", f"{LV_KV:g}/{v_mv:g}", 1,
               dict(pv_mw_gross=_r(t["pv_mw"], 3), bess_mw_gross=_r(t["bess_mw"], 3), bess_mwh_gross=_r(t["bess_mwh"], 3), availability=t["avail"],
                    connection="plug-in MV ring-main unit + transformer at a fixed trailer pad"), basis="model", status=t["status"],
               flag="Availability-weighted capacity is included in the PV/BESS nodes of the power-flow check; trailers are not separately modelled.")
    # ---- reactive compensation
    if spec["stages"] > 0:
        total = spec["stages"] * spec["stage_mvar"]
        eq.add("CAP-01", "Reactive compensation", "Switched shunt capacitor bank (detuned, 7 %)", f"{spec['stages']} stages x {spec['stage_mvar']:g} Mvar at the MV bus, vacuum-switched",
               f"{total:g} Mvar", v_mv, 1, dict(stages=spec["stages"], stage_mvar=spec["stage_mvar"], total_mvar=total, detuning=f"7 % reactor (series resonance {detuning_hz(7, float(ov.get('frequency_hz', 60.0))):.0f} Hz)",
                                                control="PF/voltage controller, stages switched per case", protection="50/51, 59, 60 (unbalance)",
                                                stages_in_service={r["label"]: r["cap_stages_in"] for r in case_results_iter(case_results)},
                                                sizing=SHUNT_NOTE, cost_in_technology_cost=False,
                                                indicative_cost_usd=round(total * 1000.0 * pf.UNIT_COSTS["capacitor_usd_per_kvar"], 0)),
               basis=spec["shunt_source"], flag="Confirm harmonic resonance (detuning) with a harmonic study. " + (
                   "Size comes from the SLD / power-flow shunt." if spec["shunt_source"] == "model" else
                   "Size set by the user." if spec["shunt_source"] == "user-set" else "Size is computed from the reactive requirement."))
        totals["capacitor_mvar"] = total
    if spec["reactor_mvar"] > 0:
        eq.add("REA-01", "Reactive compensation", "Shunt reactor", f"{spec['reactor_mvar']:g} Mvar at the MV bus", f"{spec['reactor_mvar']:g} Mvar",
               v_mv, 1, dict(mvar=spec["reactor_mvar"], type="dry-type / oil-immersed", sizing=SHUNT_NOTE, cost_in_technology_cost=False,
                             indicative_cost_usd=round(spec["reactor_mvar"] * 1000.0 * pf.UNIT_COSTS["reactor_usd_per_kvar"], 0)),
               basis=spec["reactor_source"])
        totals["reactor_mvar"] = spec["reactor_mvar"]
    # ---- station services, earthing, protection
    aux_kw = 60.0 + 25.0 * plans.get("bess", {}).get("containers", 0) + 10.0 * sum(plans[g["kind"]]["n"] for g in spec["groups"] if g["kind"] in ("pv", "bess", "wind")) \
        + 30.0 * sum(plans[g["kind"]]["n"] for g in spec["groups"] if g["kind"] in pf.GENSETS) + 15.0 * (spec["main_n"] or 0)
    aux_kw = float(ov.get("aux_load_kw", aux_kw))
    spec["aux_kw"] = aux_kw
    aux_kva = float(ov["aux_tr_kva"]) if "aux_tr_kva" in ov else (std_rating(aux_kw / 0.85 * 1.25, STD_AUX_KVA) or STD_AUX_KVA[-1])
    eq.add("AUX-TR", "Station services", "Auxiliary transformer", f"{v_mv:g}/0.4 kV, Dyn11, supplies substation building, BESS HVAC, controls",
           f"{aux_kva} kVA", f"{v_mv:g}/0.4", 1, dict(aux_load_kw=_r(aux_kw, 0), basis="60 kW building + 25 kW/container + 10 kW/inverter + 30 kW/generator + 15 kW/OLTC"), basis="assumed")
    eq.add("DC-SYS", "Station services", "110 V DC system", "2 x 100 % chargers, VRLA/Ni-Cd battery 8 h autonomy, 10 kVA UPS for SCADA/PPC",
           "110 V DC / 10 kVA UPS", "110 VDC", 1, dict(autonomy_h=8), basis="assumed")
    ngr = ov["ngr_a"] if "ngr_a" in ov else std_rating(400, STD_NGR_A)
    spec["aux_kva"], spec["ngr"] = aux_kva, ngr
    eq.add("NGR-01", "Grounding", "Neutral earthing resistor", f"MV neutral earthing: {v_mv / SQ3 * 1000 / ngr:.1f} ohm, {ngr} A, 10 s rating",
           f"{ngr} A / 10 s", v_mv, 1, dict(resistance_ohm=_r(v_mv / SQ3 * 1000 / ngr, 2), ground_fault_a=ngr, earthing_transformer="zig-zag if the MV side of the main transformer is delta"),
           basis="assumed", flag="Earth-fault current limit to be coordinated with feeder protection.")
    eq.add("GRID-EARTH", "Grounding", "Earth grid", "Substation and plant earth grid per IEEE 80; step/touch voltages to be calculated",
           "< 1 ohm target", "-", 1, dict(target_ohm=1.0, conductor="copper 120 mm2 bare", rods="copper-clad 3 m"), basis="assumed",
           flag="Needs soil resistivity survey and IEEE 80 design.")
    eq.add("SCADA", "Control and protection", "Plant controller (PPC) + SCADA/EMS", "Power-plant controller, RTU, IEC 61850/DNP3 to utility, time sync (GPS), cybersecurity firewalls",
           "1 system", "-", 1, dict(functions="voltage/Q control, active-power curtailment, ramp-rate, BESS dispatch, genset start/stop, load shedding",
                                    protocols="IEC 61850, DNP3, Modbus"), basis="assumed")
    protection = _protection(spec)
    eq.add("PROT-PANELS", "Control and protection", "Protection & control relays", f"{sum(r['quantity'] for r in protection)} numerical relays (see protection summary)",
           "numerical IEDs", "-", sum(r["quantity"] for r in protection), dict(), basis="assumed")
    # ---- land and BOM
    land.append(("Substation yard + control building", 0.5 + 0.02 * (spec["main_n"] * spec["main_mva"] if spec["main_tr"] else 5), "acres", "assumed"))
    _mark_user_set(eq.rows, ov)
    units = _unit_counts(spec, eq.rows, totals, ov)
    bom = _bom(eq.rows, feeders, spec)
    _tag_plants(eq.rows, spec)
    checks = _checks(spec, case_results, fails, n1, feeders, ratio_target, isc_mv)
    flags.extend(_flags(spec, eq.rows, planned, fails, obs))
    for x in ctx.get("excluded_techs") or []:
        flags.append(dict(id="TECH-" + x["tech"].upper(), item=x["label"], note=x["note"]))
    detail = spec.get("detail", DEFAULT_DETAIL)
    raw = _raw_model(spec, case_results, planned, aux_kw, aux_kva, values)
    node_label = {IDS["grid"]: "Utility grid", "GRID__src": "Utility source", IDS["hv"]: "Substation HV bus", IDS["mv"]: "Substation MV bus",
                  IDS["load"]: spec["names"]["label"]["load"], "AUX": "Station service"}
    node_label.update({f"{k.upper()}_C": f"{spec['names']['label'][k]} collector" for k in spec["names"]["unit_base"]})
    node_label.update({k: f"{spec['names']['label'][k]} units" for k in spec["names"]["unit_base"]})
    buses = [dict(number=b["num"], name=b["name"], kv=b["kv"], description=node_label.get(b["node"], b["node"])) for b in raw["buses"]]
    raw["freq"], raw["tap_step"], raw["tap_max"] = float(ov.get("frequency_hz", 60.0)), TAP_STEP, TAP_MAX_POS
    raw["skid_tap"] = dict(spec["skid_tap"])
    return dict(
        meta=dict(run_id=run_id, scenario=code, scenario_name=result.get("name"), is_best=(code == best), best_scenario=best,
                  generated=datetime.datetime.now().isoformat(timespec="seconds"), revision="A", drawing_no=f"GS-{code}-SLD-001",
                  application="GenStudio Design", status=checks["status"], islanded=not spec["has_grid"],
                  detail=detail, detail_label=DETAIL_LABEL[detail]),
        equivalence=raw["equivalence"],
        basis=_basis_rows(spec, values, obs, ctx, code, ratio_target), equipment=eq.rows, protection=protection, bom=bom, unit_counts=units, overrides=dict(values=ov),
        land=[dict(item=a, quantity=_r(b, 2), unit=c, basis=d) for a, b, c, d in land],
        checks=checks, flags=flags, totals=_totals(totals, spec, result), limitations=LIMITATIONS,
        iterations=spec["iterations"], sld_model=_sld_model(spec, eq.rows, values, code, result, bom), raw_model=raw, buses=buses,
        tap_changer=dict(step_pct=TAP_STEP * 100, positions=2 * TAP_MAX_POS + 1, range_pct=TAP_STEP * TAP_MAX_POS * 100),
        voltages=dict(hv_kv=v_hv, mv_kv=v_mv, lv_kv=LV_KV), shunt_note=SHUNT_NOTE,
        shunt=dict(stages=spec["stages"], stage_mvar=spec["stage_mvar"], total_mvar=_r(spec["stages"] * spec["stage_mvar"], 4),
                   reactor_mvar=spec["reactor_mvar"], source=spec["shunt_source"], reactor_source=spec["reactor_source"],
                   cost_in_technology_cost=False,
                   indicative_cost_usd=_r(spec["stages"] * spec["stage_mvar"] * 1000.0 * pf.UNIT_COSTS["capacitor_usd_per_kvar"]
                                          + spec["reactor_mvar"] * 1000.0 * pf.UNIT_COSTS["reactor_usd_per_kvar"], 0)),
        short_circuit=dict(mv_ka=_r(isc_mv, 2), mv_mva=_r(spec["isc_mv_mva"], 1), hv_ka=_r(isc_hv, 2), hv_mva=_r(spec["isc_hv_mva"], 1)),
        assumed_count=sum(1 for r in _basis_rows(spec, values, obs, ctx, code, ratio_target) if r["source"] == "assumed"))


def case_results_iter(case_results):
    for label, hour, inj, res in case_results:
        yield dict(label=label, tap_pos=res["tap_pos"], cap_stages_in=res["stages_in"])


def _max_loading(case_results, branch_id):
    best = 0.0
    for _l, _h, _i, res in case_results:
        for b in res["case"]["branches"]:
            if b["id"] == branch_id and b["loading_pct"] > best:
                best = b["loading_pct"]
    return _r(best, 1)


def _totals(t, spec, result):
    caps = result.get("caps") or {}
    t = dict(t)
    t["model_caps"] = dict(pv_dc_mw=caps.get("pv_dc_mw"), bess_mw=caps.get("bess_mw"), bess_mwh=caps.get("bess_mwh"),
                           generators_mw=caps.get("generators_mw"))
    t["peak_load_mw"] = _r(spec["peak_load_mw"], 3)
    return t


def _protection(spec):
    rows = []
    v_mv, v_hv = spec["v_mv"], spec["v_hv"]
    if spec["has_grid"]:
        rows += [dict(zone="Incoming line", device="Line protection IED (distance or line differential per utility)", functions="21/21N or 87L, 67/67N, 50BF, 79 (if overhead), 25",
                      quantity=1, note="Utility to specify scheme and teleprotection"),
                 dict(zone="Main transformer", device="Transformer differential IED", functions="87T, 64REF, 50/51, 50N/51N, 49, 50BF", quantity=spec["main_n"] or 1, note="Plus Buchholz 63, PRV, WTI/OTI 26/49, OLTC 63"),
                 dict(zone="Grid interconnection", device="Interconnection protection (POI)", functions="27/59, 81O/U, 59N, 47, 32 (reverse power), 25", quantity=1,
                      note="Per utility interconnection requirements (IEEE 1547 / grid code)")]
    rows += [dict(zone="MV busbar", device="Bus arc-flash / busbar protection", functions="50 (arc flash), 87B (optional), 27/59", quantity=1, note="IAC-rated switchgear"),
             dict(zone="Load feeders", device="Feeder protection IED", functions="50/51, 50N/51N, 67/67N, 27/59, 81", quantity=2, note="Directional if the feeder can back-feed")]
    for g in spec["groups"]:
        k = g["kind"]
        if k in ("pv", "bess", "wind"):
            rows.append(dict(zone=g["label"], device="Collector feeder IED + inverter protection", functions="50/51, 50N/51N, 27/59, 81, 25 (BESS/PV sync), anti-islanding 78/81R",
                             quantity=1, note="IEEE 1547 ride-through settings to be confirmed"))
        else:
            rows.append(dict(zone=g["label"], device="Generator protection IED", functions="87G, 40, 46, 32, 51V, 59/27, 81, 25, 64S, 49", quantity=max(spec["plans"][k]["n"], 1), note="Per unit"))
    if spec["stages"]:
        rows.append(dict(zone="Capacitor bank", device="Capacitor protection IED", functions="50/51, 59, 60 (unbalance), 27", quantity=1, note="Detuned bank"))
    rows.append(dict(zone="Plant", device="Plant controller / SCADA / EMS", functions="PPC, Q/V and P control, BESS dispatch, load shedding, SCADA, sequence of events", quantity=1, note="IEC 61850 / DNP3"))
    return rows


def _mark_user_set(rows, ov):
    """Flag every equipment row whose inputs include a user override ('user-set') and list the edited parameters on the row."""
    if not ov:
        return
    fixed = {"TR-MAIN": ("main_tr_n", "main_tr_mva", "main_tr_z_pct", "main_tr_xr", "tap_step_pct", "tap_max_pos", "v_hv_kv", "v_mv_kv"),
             "UTIL-01": ("grid_sc_mva", "grid_xr", "v_hv_kv"), "CAP-01": ("shunt_stages", "shunt_stage_mvar"), "REA-01": ("reactor_mvar",),
             "AUX-TR": ("aux_load_kw", "aux_tr_kva"), "NGR-01": ("ngr_a",), "SWG-MV-01": ("mv_breaker_ka",),
             "BESS-CONT": ("container_mwh",), "PV-INV": ("pv_module_w",), "LN-01": ("incoming_type", "cable_derate", "cable_vd_limit_pct"),
             "CB-HV-01": ("v_hv_kv",)}
    hits = {rid: [k for k in keys if k in ov] for rid, keys in fixed.items()}
    for key in ov:
        base, _, kind = key.partition(".")
        if not kind:
            continue
        K = kind.upper()
        ids = {"inv_unit_mva": [f"{K}-INV", "BESS-PCS"] if kind in ("pv", "bess") else [],
               "unit_mw": ["WTG"] if kind == "wind" else [f"GEN-{K}"],
               "length_km": ["LN-01"] if kind == "incoming" else [f"CAB-{K}"], "area_mm2": ["LN-01"] if kind == "incoming" else [f"CAB-{K}"],
               "skid_mva": [f"{K}-TR", f"GSU-{K}", "WTG-TR" if kind == "wind" else ""], "skid_z_pct": [f"{K}-TR", f"GSU-{K}", "WTG-TR"],
               "skid_tap_pct": [f"{K}-TR", f"GSU-{K}", "WTG-TR"]}.get(base, [])
        if base == "inv_unit_mva" and kind == "pv":
            ids = ["PV-INV"]
        if base == "inv_unit_mva" and kind == "bess":
            ids = ["BESS-PCS"]
        if base in ("skid_mva", "skid_z_pct", "skid_tap_pct") and kind == "bess":
            ids = ["BESS-TR"]
        for rid in ids:
            if rid:
                hits.setdefault(rid, []).append(key)
    for r in rows:
        keys = hits.get(r["id"])
        if keys:
            r["basis"] = "user-set"
            r["params"] = dict(r["params"], user_set=[param_label(k) for k in keys])


def _unit_counts(spec, rows, totals, ov):
    """Estimated unit counts for the BOQ: count, the unit size used and whether that size is assumed, user-set or from the model."""
    by = {r["id"]: r for r in rows}
    out = []

    def add(item, count, unit_size, unit, basis, note=""):
        out.append(dict(item=item, count=int(count), unit_size=unit_size, unit=unit, basis=basis, note=note))

    us = lambda key, base="assumed": "user-set" if key in ov else base
    if "PV-INV" in by:
        pv = by["PV-INV"]
        dc = pv["params"].get("dc_mw") or 0.0
        w, per = float(ov.get("pv_module_w", 600)), int(ov.get("pv_modules_per_string", 28))
        modules = math.ceil(dc * 1e6 / w - 1e-9)
        add("PV modules", modules, w, "W per module", us("pv_module_w"), f"{dc:.4f} MWdc / module size")
        add("PV strings", math.ceil(modules / per), per, "modules per string", us("pv_modules_per_string"), "modules / string length")
        add("PV inverters", pv["quantity"], float(pv["rating"].split()[0]), "MVA per inverter", us("inv_unit_mva.pv", "assumed"),
            "standard block size chosen from the inverter MVA")
    if "BESS-CONT" in by:
        add("BESS containers", by["BESS-CONT"]["quantity"], CONTAINER_MWH, "MWh per container", us("container_mwh"),
            "nameplate MWh / container size")
        add("BESS PCS units", by["BESS-PCS"]["quantity"], float(by["BESS-PCS"]["rating"].split()[0]), "MVA per PCS", us("inv_unit_mva.bess"))
    if "WTG" in by:
        add("Wind turbines", by["WTG"]["quantity"], float(by["WTG"]["rating"].split()[0]), "MW per turbine", us("unit_mw.wind"))
    for r in rows:
        if r["id"].startswith("GEN-"):
            add(f"{r['type']} units", r["quantity"], float(r["rating"].split()[0]), "MW per unit", us(f"unit_mw.{r['id'][4:].lower()}"))
    if "TR-MAIN" in by:
        t = by["TR-MAIN"]
        add("Main transformers", t["quantity"], t["params"]["mva_onaf"], "MVA each", "user-set" if "main_tr_n" in ov or "main_tr_mva" in ov else "assumed")
    for rid in ("PV-TR", "BESS-TR", "WTG-TR"):
        if rid in by:
            add(by[rid]["type"].replace("step-up skid ", "").replace("pad-mount ", "") + "s", by[rid]["quantity"], by[rid]["params"]["mva"],
                "MVA each", us(f"skid_mva.{rid[:-3].lower()}"))
    for r in rows:
        if r["id"].startswith("GSU-"):
            add("Generator step-up transformers", r["quantity"], r["params"]["mva"], "MVA each", us(f"skid_mva.{r['id'][4:].lower()}"))
    if "AUX-TR" in by:
        add("Auxiliary transformers", 1, float(by["AUX-TR"]["rating"].split()[0]), "kVA", us("aux_tr_kva"))
    if "CAP-01" in by:
        add("Capacitor bank stages", by["CAP-01"]["params"]["stages"], by["CAP-01"]["params"]["stage_mvar"], "Mvar per stage",
            spec["shunt_source"], "extra to the technology cost")
    if "REA-01" in by:
        add("Shunt reactors", 1, by["REA-01"]["params"]["mvar"], "Mvar", spec["reactor_source"])
    panels = sum(r["quantity"] for r in rows if r["id"].startswith("CB-") and r["id"] != "CB-HV-01")
    panels += (1 if "CAP-01" in by else 0) + (1 if "REA-01" in by else 0) + 1 + int(ov.get("mv_spare_panels", 1))
    add("MV switchgear panels", panels, "1 breaker panel", "per panel", us("mv_spare_panels"),
        "feeder + incomer breakers, shunt bay(s), auxiliary transformer feeder and spare panels")
    circuits = sum(r["params"].get("circuits", 1) for r in rows if r["id"].startswith("CAB-")) + (by["LN-01"]["quantity"] if "LN-01" in by else 0)
    km = sum(r["params"].get("length_km", 0) * r["params"].get("circuits", 1) for r in rows if r["id"].startswith("CAB-"))
    km += by["LN-01"]["params"]["length_km"] * by["LN-01"]["quantity"] if "LN-01" in by else 0
    add("Cable / line circuits", circuits, round(km / max(circuits, 1), 4), "km average per circuit", "assumed" if not any(
        k.startswith("length_km") for k in ov) else "user-set", f"{km:.4f} circuit-km before slack")
    if "PROT-PANELS" in by:
        add("Protection relays (IEDs)", by["PROT-PANELS"]["quantity"], 1, "relay", "assumed")
    return out


def _bom(rows, feeders, spec):
    bom = []
    for r in rows:
        if r["status"] == "existing":
            continue
        qty = r["quantity"]
        unit = "no."
        if r["category"] == "Feeders and cables":
            length = r["params"].get("length_km", 0) * r["params"].get("circuits", 1) * 1.05
            bom.append(dict(item=f"{r['type']} {r['params']['area_mm2']} mm2 ({r['id']})", quantity=_r(length, 2), unit="circuit-km", note="route length x circuits +5 % slack"))
            continue
        if r["id"] == "LN-01":
            bom.append(dict(item=f"{r['type']} ({r['id']})", quantity=_r(r["params"]["length_km"] * r["quantity"] * 1.05, 2), unit="circuit-km", note="+5 % slack"))
            continue
        bom.append(dict(item=f"{r['type']} - {r['rating']} ({r['id']})", quantity=qty, unit=unit, note=r["voltage"] if isinstance(r["voltage"], str) else f"{r['voltage']} kV"))
    for r in rows:
        if r["id"] in ("CAP-01", "REA-01") and r["status"] != "existing":
            bom.append(dict(item=f"{r['type']} - indicative installed cost, EXTRA (not in technology cost or NPC)",
                            quantity=_r(r["params"]["indicative_cost_usd"], 0), unit="USD", note="power_flow UNIT_COSTS per kvar"))
    return bom


def _checks(spec, case_results, fails, n1, feeders, ratio_target, isc_mv):
    cases = []
    for label, hour, inj, res in case_results:
        cases.append(_case_summary(res, label, hour, inj, None))
    hard = [v for c in cases for v in c["violations"] if v["severity"] == "fail"]
    warns = [v for c in cases for v in c["violations"] if v["severity"] != "fail"]
    cables = [dict(id=k, size=f"{f['circuits']} x {f['area'] or f['basis']}", length_km=f["length_km"], i_per_circuit_a=f["i_per_circuit"],
                   derated_ampacity_a=f["derated_a"], loading_pct=f["loading_pct"], voltage_drop_pct=f["vd_pct"],
                   vd_ok=f["vd_pct"] <= CABLE_VD_LIMIT_PCT, ampacity_ok=f["loading_pct"] <= 100.0, sc_ok=bool(f.get("sc_ok", True)))
              for k, f in feeders.items()]
    pf_ok = all(c["grid_pf"] is None or c["grid_mw"] is None or c["grid_mw"] <= 0 or abs(c["grid_mvar"]) <= ratio_target * c["grid_mw"] + 0.05 for c in cases)
    status = "FAIL" if hard else ("WARN" if warns or not pf_ok or any(not (c["vd_ok"] and c["ampacity_ok"] and c["sc_ok"]) for c in cables) else "PASS")
    return dict(status=status, cases=cases, n1=n1, cables=cables, power_factor_ok=pf_ok, pf_target=_r(ratio_target, 3),
                violations=hard, warnings=warns[:40],
                summary=dict(cases=len(cases), vmin=min([c["vmin"] for c in cases if c["converged"]], default=None),
                             vmax=max([c["vmax"] for c in cases if c["converged"]], default=None),
                             max_loading_pct=max([c["max_loading_pct"] for c in cases], default=None),
                             max_losses_mw=max([c["losses_mw"] for c in cases], default=None)),
                short_circuit_ka=_r(isc_mv, 2))


def _flags(spec, rows, planned, fails, obs):
    flags = []
    for r in rows:
        if r.get("flag"):
            flags.append(dict(id=r["id"], item=r["type"], note=r["flag"]))
    if fails:
        flags.append(dict(id="CHECK", item="Power-flow check", note=f"{len(fails)} violation(s) remain after automatic sizing."))
    if spec["has_grid"] and spec["main_n"] == 1:
        flags.append(dict(id="N-1", item="Main transformer", note="Single main transformer: N-1 transformer outage is not covered."))
    for r in rows:
        rating, duty = r["params"].get("short_circuit_ka"), r["params"].get("fault_duty_ka")
        if rating is not None and duty is not None and rating < duty:
            flags.append(dict(id=r["id"], item=r["type"], note=f"Fault duty {duty:g} kA exceeds the {rating:g} kA short-circuit rating: "
                                                                "raise the rating, add series reactors or split the bus."))
    return flags


# --------------------------------------------------------------------------- SLD model and drawing

def _sld_model(spec, rows, values, code, result, bom):
    by = {r["id"]: r for r in rows}
    N, NM = spec["names"]["bus"], spec["names"]["name"]
    v_hv, v_mv = spec["v_hv"], spec["v_mv"]
    equiv = spec.get("detail", DEFAULT_DETAIL) == "equivalent"
    feeder_prot = "50/51 50N/51N 67"
    inverter_prot = "50/51 50N/51N 27/59 81"
    bays = []

    def cable_text(f):
        return f"{f['circuits']} x {f['area']} mm2 Al XLPE, {f['length_km']:.2f} km"

    def bay(kind, title, cb, cable, bus, lines, prot, trafo=None, lv=None, collector=True, switch="Switching device"):
        bays.append(dict(kind=kind, title=title, cb=cb, cable=cable, trafo=trafo, lines=lines, bus=bus, bus_name=NM.get(next((x for x in N if N[x] == bus), ""), ""),
                         prot=prot, lv=lv, collector=collector, switch=switch))

    bay("load", spec["names"]["label"]["load"].upper()[:22], by["CB-LOAD"]["rating"], cable_text(spec["feeders"]["load"]), N["load"],
        [f"Peak {spec['peak_load_mw']:.1f} MW", f"{spec['n_load_nodes']} load node(s)"], feeder_prot)
    for g in spec["groups"]:
        k, pl = g["kind"], spec["plans"][g["kind"]]
        n = pl["n"]
        base = spec["names"]["unit_base"][k]
        unit = NM[k + "_unit"]
        trafo = lv = None
        if pl.get("has_gsu"):
            z, _xr = _tz(spec, k, max(pl["skid_mva"], 2.5))
            ratio = f"{v_mv:g}/{pl['v_lv']:g} kV  Z = {z:g} %"
            if equiv:
                trafo = f"1 x {round(pl['skid_mva'] * n, 4):g} MVA {ratio}" + (f" (equivalent of {n} x {pl['skid_mva']:g} MVA)" if n > 1 else "")
                lv = dict(bus=str(base + 1), name=f"{unit}_EQ"[:12], kv=pl["v_lv"])
            else:
                trafo = f"{n} x {pl['skid_mva']:g} MVA {ratio}"
                lv = dict(bus=f"{base + 1}" if n == 1 else f"{base + 1}-{base + n}", name=f"{unit}_01"[:12] if n == 1 else f"{unit}_01..{n:02d}"[:14], kv=pl["v_lv"])
        blocks = f"Equivalent of {n} x {{}}" if equiv and n > 1 else f"{n} x {{}}"
        plants = [p[:30] for p in spec["names"]["parts"].get(k, []) if p and not p.lower().startswith("optimised")][:2]
        common = dict(cb=by[f"CB-{k.upper()}"]["rating"], cable=cable_text(spec["feeders"][k]), bus=N[k], trafo=trafo, lv=lv)
        title = spec["names"]["label"][k].upper()[:22]
        if k == "pv":
            bay("pv", title, lines=[blocks.format(f"{pl['unit_mva']:g} MVA inverters"), f"{g['p_mw']:.2f} MWac / {sum(x['dc_mw'] for x in g['parts']):.2f} MWdc"] + plants,
                prot=inverter_prot, **common)
        elif k == "bess":
            bay("bess", title, lines=[blocks.format(f"{pl['unit_mva']:g} MVA PCS"), f"{pl['containers']} x {CONTAINER_MWH:g} MWh containers",
                                      f"{pl['mwh']:.1f} MWh / {g['p_mw']:.2f} MW"] + plants, prot=inverter_prot, **common)
        elif k == "wind":
            bay("wind", title, lines=[blocks.format(f"{pl['unit_mw']:g} MW WTG")] + plants, prot=inverter_prot, **common)
        else:
            bay("gen", title, lines=[blocks.format(f"{pl['unit_mw']:g} MW ({pl['unit_mva']:.2f} MVA)"), f"Xd\" = {pl['xd2']:g} pu"] + plants, prot="50/51 87G 40 32 81", **common)
    if spec["stages"]:
        bay("cap", "CAPACITOR BANK", "", "", N["main"], [f"{spec['stages']} x {spec['stage_mvar']:g} Mvar", "7 % detuned"] + ([spec["shunt_source"]] if spec["shunt_source"] != "assumed" else []),
            "50/51 59 60", collector=False, switch="Capacitor switching device")
    if spec["reactor_mvar"]:
        bay("reactor", "SHUNT REACTOR", "", "", N["main"], [f"{spec['reactor_mvar']:g} Mvar"] + ([spec["reactor_source"]] if spec["reactor_source"] != "assumed" else []),
            "50/51 50N/51N", collector=False, switch="Reactor switching device")
    aux = by["AUX-TR"]
    bay("aux", "STATION SERVICE", "", "", N["aux"], ["Auxiliary load", "110 V DC / UPS"], "50/51 fuse", trafo=f"{aux['rating']} {v_mv:g}/0.4 kV",
        lv=dict(bus=str(N["aux"]), name=NM["aux"], kv=0.4), collector=False, switch="Fused switch")
    for t in spec["trailers"]:
        bay("trailer", (t.get("name") or "MOBILE TRAILERS").upper()[:22], "", "", N["trailer"],
            [f"PV {t['pv_mw']:.2f} MW", f"BESS {t['bess_mw']:.2f} MW / {t['bess_mwh']:.2f} MWh", t["status"]], "50/51 27/59", switch="Trailer connection")
    model = dict(has_grid=spec["has_grid"], v_hv=v_hv, v_mv=v_mv, lv_kv=LV_KV, sc_mva=spec["sc_mva"], sc_xr=spec["sc_xr"], title=result.get("name") or code, code=code, bays=bays,
                 detail=spec.get("detail", DEFAULT_DETAIL), not_built=[x["note"] for x in (spec.get("excluded") or [])],
                 bus=N, names=NM, bus_names={str(N[k]): NM[k] for k in N if k in NM})
    if spec["has_grid"]:
        inc = spec["feeders"]["incoming"]
        model["incoming"] = f"{inc['circuits']} x {inc['basis']}, {inc['length_km']:.2f} km"
        model["cb_hv"] = by["CB-HV-01"]["rating"]
        model["prot_in"] = "21/87L 67 50BF 25"
    if spec["main_tr"]:
        t = by["TR-MAIN"]
        model["main"] = dict(n=spec["main_n"], rating=t["rating"], z=t["params"]["z_pct"], vg=t["params"]["vector_group"],
                             oltc=f"OLTC +/-{TAP_STEP * TAP_MAX_POS * 100:g} % ({2 * TAP_MAX_POS} steps)")
        model["prot_main"] = "87T 50/51 50N/51N 63"
    model["swg"] = by["SWG-MV-01"]["rating"]
    model["ngr"] = by["NGR-01"]["rating"]
    return model

GENERIC_LABELS = {"bus", "grid", "load", "substation", "solar", "solar pv", "pv", "bess", "battery", "wind", "natural gas turbine"}


def _abbr(text, width):
    """Upper-case, underscore-joined abbreviation of at most `width` characters (PSS/E bus names are 12 characters)."""
    words = re.findall(r"[A-Za-z0-9]+", str(text or "").upper())
    if not words:
        return ""
    joined = "_".join(words)
    if len(joined) <= width:
        return joined
    k = max(2, (width - (len(words) - 1)) // len(words))
    return "_".join(w[:k] for w in words)[:width].rstrip("_")


def display_names(spec, diagram=None, planned=None):
    """Industry-style bus numbers (voltage-level blocks) and names built from the plant names on the SLD.

    1001-1099 HV / utility, 2001-2099 MV substation, 2101+ one MV collector per technology, 3101+ LV generator buses
    (3000 + 100 x technology index + unit), 4001 station service, 2901 mobile trailers.  A node's own electrical `bus_number` /
    `bus_name` (user-set in the topology) takes precedence over the generated one.
    Returns dict(bus={key: number}, unit_base={tech: base}, name={key: str}, label={key: plant name}, parts={tech: [names]})."""
    nodes = {}
    for n in (diagram or {}).get("nodes") or []:
        nodes.setdefault(n.get("kind"), n)

    def node_label(kind, default):
        n = nodes.get(kind)
        return (n or {}).get("label") or default

    def user(kind, key):
        return ((nodes.get(kind) or {}).get("electrical") or {}).get(key)

    def pick(kind, number, name):
        num = user(kind, "bus_number")
        nm = user(kind, "bus_name")
        return (int(num) if isinstance(num, (int, float)) and num > 0 else number), (str(nm)[:12].upper() if nm else name)

    bus, names, labels = {}, {}, {}
    grid_label = node_label("grid", "Utility grid")
    g = _abbr(grid_label, 8) or "GRID"
    bus["grid"], names["grid"] = pick("grid", 1001, f"{g}_SRC"[:12])
    bus["pcc"], names["pcc"] = 1002, f"{g}_PCC"[:12]
    bus["hv"], names["hv"] = 1003, f"{g}_HV"[:12]
    sub_label = node_label("bus", "Substation")
    sub = "SUB" if sub_label.strip().lower() in GENERIC_LABELS else (_abbr(sub_label, 9) or "SUB")
    bus["main"], names["main"] = pick("bus", 2001, f"{sub}_MV"[:12])
    load_label = node_label("load", "Load")
    bus["load"], names["load"] = pick("load", 2002, f"{_abbr(load_label, 8) or 'LOAD'}_BUS"[:12])
    labels.update(grid=grid_label, main=sub_label, load=load_label)
    unit_base, parts = {}, {}
    for i, grp in enumerate(spec["groups"], start=1):
        k = grp["kind"]
        label = node_label(k, grp["label"])
        short = _abbr(label, 8) or k.upper()[:8]
        bus[k], names[k] = pick(k, 2100 + i, f"{short}_COL"[:12])
        unit_base[k] = 3000 + 100 * i
        names[k + "_unit"] = short
        labels[k] = label
        parts[k] = [p["name"] for p in grp["parts"] if p.get("name")]
    bus["aux"], names["aux"] = 4001, "AUX_LV"
    bus["trailer"], names["trailer"] = 2901, "TRAILERS"
    used = list(bus.values()) + [unit_base[k] + 1 + u for k in unit_base for u in range(spec["plans"][k]["n"])]
    if len(used) != len(set(used)):
        raise ValueError("Bus numbering collision; check user-set bus numbers on the SLD.")
    return dict(bus=bus, unit_base=unit_base, name=names, label=labels, parts=parts)


def _x(text):
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


SLD_W, SLD_H = 1587, 1122
SLD_COLORS = dict(hv="#b3261e", mv="#1a4fa0", lv="#2e7d32", ink="#111111", mute="#555555")


def sld_svg(design):
    """Print-ready A3 landscape (420 x 297 mm) single-line diagram of the final design.

    IEC-style symbols, one colour per voltage level, ratings, ANSI/IEEE C37.2 protection device numbers, the PSS/E RAW bus numbers and names,
    a legend, notes and a title block.  Only presentation attributes are used (no style, script or external references)."""
    m, meta, raw = design["sld_model"], design["meta"], design["raw_model"]
    col = SLD_COLORS
    W, H = SLD_W, SLD_H
    out = []
    a = out.append

    def line(x1, y1, x2, y2, w=2.0, c=col["ink"], dash=None):
        a(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{c}" stroke-width="{w}"' + (f' stroke-dasharray="{dash}"' if dash else "") + "/>")

    def text(x, y, s, size=10, anchor="start", weight="normal", c=col["ink"]):
        a(f'<text x="{x:.1f}" y="{y:.1f}" font-family="Arial, Helvetica, sans-serif" font-size="{size}" text-anchor="{anchor}" font-weight="{weight}" fill="{c}">{_x(s)}</text>')

    def block(x, y, items, size=10, anchor="start", weight="normal", c=col["ink"], chars=24, max_lines=None):
        """Word-wrapped lines starting at baseline y; returns the baseline of the next free line."""
        rows = []
        for item in ([items] if isinstance(items, str) else items):
            rows += textwrap.wrap(str(item), width=max(int(chars), 8), break_long_words=True) or [""]
        for row in rows[:max_lines]:
            text(x, y, row, size, anchor, weight, c)
            y += size + 3
        return y

    def rect(x, y, w, h, fill="#fff", c=col["ink"], sw=1.6):
        a(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" fill="{fill}" stroke="{c}" stroke-width="{sw}"/>')

    def circle(x, y, r, c=col["ink"], fill="none", sw=1.8):
        a(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r:.1f}" fill="{fill}" stroke="{c}" stroke-width="{sw}"/>')

    def breaker(x, y, s=12):
        rect(x - s / 2, y - s / 2, s, s)
        line(x - s / 2, y - s / 2, x + s / 2, y + s / 2, 1.4)
        line(x - s / 2, y + s / 2, x + s / 2, y - s / 2, 1.4)

    def ct(x, y):
        circle(x, y, 5, sw=1.4, fill="#fff")

    def trafo(x, y, top, bottom, r=13):
        circle(x, y - r / 2, r, top)
        circle(x, y + r / 2, r, bottom)

    def source(x, y, symbol, r=20):
        circle(x, y, r, fill="#fff")
        text(x, y + 6, symbol, 18, "middle", "bold")

    def ground(x, y):
        for k, half in enumerate((9, 6, 3)):
            line(x - half, y + 4 * k, x + half, y + 4 * k, 1.8)

    def resistor(x, y, h=22):
        rect(x - 5, y, 10, h)

    def coil(x, y, r=4.5, turns=3):
        for k in range(turns):
            a(f'<path d="M {x:.1f} {y + 2 * r * k:.1f} a {r} {r} 0 0 1 0 {2 * r}" fill="none" stroke="{col["ink"]}" stroke-width="1.8"/>')

    def inverter(x, y, w=54, h=34):
        rect(x - w / 2, y, w, h, "#fff4d6")
        line(x - w / 2, y + h, x + w / 2, y, 1.4)
        text(x - w / 2 + 4, y + 11, "=", 11, "start", "bold")
        text(x + w / 2 - 4, y + h - 4, "~", 12, "end", "bold")

    def pv_array(x, y, w=54, h=26):
        rect(x - w / 2, y, w, h, "#dbe9ff")
        for k in (1, 2):
            line(x - w / 2 + k * w / 3, y, x - w / 2 + k * w / 3, y + h, 0.9)
        line(x - w / 2, y + h / 2, x + w / 2, y + h / 2, 0.9)

    def battery(x, y, w=54, h=34):
        rect(x - w / 2, y, w, h, "#d9f2ee")
        for k, tall in enumerate((True, False, True, False)):
            bx = x - 15 + k * 10
            line(bx, y + (8 if tall else 12), bx, y + h - (8 if tall else 12), 2.4 if tall else 1.6)
        text(x - w / 2 + 4, y + 9, "+", 9, "start", "bold")
        text(x + w / 2 - 4, y + 9, "-", 9, "end", "bold")

    def capacitor(x, y):
        line(x - 14, y, x + 14, y, 2.2)
        line(x - 14, y + 7, x + 14, y + 7, 2.2)

    def load_arrow(x, y):
        a(f'<polygon points="{x - 12:.1f},{y:.1f} {x + 12:.1f},{y:.1f} {x:.1f},{y + 24:.1f}" fill="{col["ink"]}"/>')

    def bar(x1, x2, y, c, w=6):
        line(x1, y, x2, y, w, c)

    a(f'<svg xmlns="http://www.w3.org/2000/svg" width="420mm" height="297mm" viewBox="0 0 {W} {H}">')
    a(f'<rect x="0" y="0" width="{W}" height="{H}" fill="#fff"/>')
    a(f'<rect x="20" y="20" width="{W - 40}" height="{H - 40}" fill="none" stroke="{col["ink"]}" stroke-width="3"/>')
    volts = " / ".join(f"{v:g}" for v in ([m["v_hv"]] if m["has_grid"] else []) + [m["v_mv"], m["lv_kv"]])
    text(W / 2, 54, "SINGLE LINE DIAGRAM", 22, "middle", "bold")
    text(W / 2, 74, f"Option {m['code']}: {m['title']}  |  {volts} kV  |  {raw.get('freq', 60.0):g} Hz", 13, "middle", c=col["mute"])

    x_mid = W / 2
    if m["has_grid"]:
        source(x_mid, 112, "~")
        block(x_mid + 30, 104, [f"UTILITY GRID {m['v_hv']:g} kV", f"Sk\" {m['sc_mva']:,.0f} MVA  X/R {m['sc_xr']:g}"], 11, weight="bold", chars=40)
        text(x_mid + 30, 134, f"bus {m['bus']['grid']} {m['names']['grid']} / {m['bus']['pcc']} {m['names']['pcc']}", 9, c=col["mute"])
        line(x_mid, 132, x_mid, 232, 2.2, col["hv"])
        text(x_mid + 12, 160, m.get("incoming", ""), 10)
        breaker(x_mid, 186)
        text(x_mid + 14, 190, f"CB {m['cb_hv']}", 10)
        ct(x_mid, 210)
        text(x_mid + 14, 214, f"CT  {m['prot_in']}", 9, c=col["mute"])
        n_main = m["main"]["n"] if "main" in m else 0
        xs = [x_mid] if n_main <= 1 else [x_mid - 55 * (n_main - 1) + 110 * i for i in range(n_main)]
        hv_y, mv_y = 244, 440
        bar(xs[0] - 60, xs[-1] + 60, hv_y, col["hv"])
        text(xs[0] - 68, hv_y + 4, f"HV BUS {m['v_hv']:g} kV  |  bus {m['bus']['hv']} {m['names']['hv']}", 11, "end", "bold", col["hv"])
        line(x_mid, 232, x_mid, hv_y, 2.2, col["hv"])
        if "main" in m:
            mt = m["main"]
            for x in xs:
                line(x, hv_y, x, 290, 2.2, col["hv"])
                trafo(x, 310, col["hv"], col["mv"])
                line(x, 329.5, x, mv_y, 2.2, col["mv"])
                breaker(x, 366)
                ct(x, 392)
            xr = xs[-1]
            block(xr + 30, 296, [(f"{n_main} x " if n_main > 1 else "") + f"{mt['rating']}", f"{m['v_hv']:g}/{m['v_mv']:g} kV  Z = {mt['z']:g} %  {mt['vg']}", mt["oltc"]], 10, weight="bold", chars=44)
            text(xr + 14, 370, "CB " + m["swg"].split("/")[0].strip() + (" each" if n_main > 1 else ""), 10)
            text(xr + 14, 396, f"CT  {m['prot_main']}", 9, c=col["mute"])
            nx = xs[0] - 58
            line(xs[0], 338, nx, 338, 1.6, col["mv"])
            line(nx, 338, nx, 350, 1.6, col["mv"])
            resistor(nx, 350)
            line(nx, 372, nx, 384, 1.6)
            ground(nx, 384)
            text(nx - 10, 366, f"NGR {m['ngr']}", 10, "end")
        else:
            line(x_mid, hv_y, x_mid, mv_y, 2.2, col["hv"])
    else:
        mv_y = 270
        text(x_mid, 160, "ISLANDED MICROGRID - no utility connection", 15, "middle", "bold")
        text(x_mid, 180, "Grid-forming capability is provided by the BESS and/or generators", 11, "middle", c=col["mute"])

    bays = m["bays"]
    left, right = 60, W - 60
    span = (right - left) / max(len(bays), 1)
    bar(left, right, mv_y, col["mv"], 7)
    text(left, mv_y - 12, f"MV BUS {m['v_mv']:g} kV  |  bus {m['bus']['main']} {m['names']['main']}  |  switchgear {m['swg']}", 11, weight="bold", c=col["mv"])
    chars = int((span - 26) / 5.6)
    for i, b in enumerate(bays):
        x = left + span * (i + 0.5)
        ty = mv_y + 26
        line(x, mv_y, x, mv_y + 24, 2, col["mv"])
        breaker(x, mv_y + 30)
        ty = block(x + 10, ty, "CB " + b["cb"] if b["cb"] else b["switch"], 9.5, chars=chars, max_lines=2)
        line(x, mv_y + 36, x, mv_y + 56, 2, col["mv"])
        ct(x, mv_y + 61)
        ty = block(x + 10, max(ty, mv_y + 66), f"CT  {b['prot']}", 9, c=col["mute"], chars=chars, max_lines=2)
        y_cur = mv_y + 66
        if b["cable"]:
            ty = block(x + 10, max(ty + 2, mv_y + 90), b["cable"], 9, chars=chars, max_lines=2)
        y_bus = mv_y + 128
        if b["collector"]:
            line(x, y_cur, x, y_bus, 2, col["mv"])
            half = min(30, span / 2 - 14)
            bar(x - half, x + half, y_bus, col["mv"], 5)
            block(x + half + 4, y_bus - 2, [f"bus {b['bus']}", b["bus_name"]], 8.5, c=col["mute"], chars=max(int((span / 2 - half - 10) / 5), 8))
            y_cur = y_bus
        y_eq = mv_y + 262
        if b["trafo"]:
            y_tr = mv_y + 190
            line(x, y_cur, x, y_tr - 19.5, 2, col["mv"])
            trafo(x, y_tr, col["mv"], col["lv"], 12)
            block(x + 22, y_tr - 12, b["trafo"], 9.5, chars=max(int((span / 2 - 28) / 5.4), 10), max_lines=3)
            y_lv = mv_y + 236
            line(x, y_tr + 18, x, y_lv, 2, col["lv"])
            half = min(30, span / 2 - 14)
            bar(x - half, x + half, y_lv, col["lv"], 5)
            if b.get("lv"):
                block(x + half + 4, y_lv - 2, [f"{b['lv']['bus']} {b['lv']['kv']:g} kV", b["lv"]["name"]], 8.5, c=col["mute"], chars=max(int((span / 2 - half - 10) / 5), 8))
            line(x, y_lv, x, y_eq, 2, col["lv"])
        else:
            line(x, y_cur, x, y_eq, 2, col["mv"])
        kind = b["kind"]
        eq_bottom = y_eq
        if kind == "pv":
            inverter(x, y_eq)
            line(x, y_eq + 34, x, y_eq + 46, 2)
            pv_array(x, y_eq + 46)
            eq_bottom = y_eq + 72
        elif kind == "bess":
            battery(x, y_eq)
            eq_bottom = y_eq + 34
        elif kind in ("gen", "wind"):
            circle(x, y_eq + 20, 20, fill="#fff")
            text(x, y_eq + 26, "G" if kind == "gen" else "WT", 15, "middle", "bold")
            eq_bottom = y_eq + 40
        elif kind in ("load", "aux"):
            load_arrow(x, y_eq)
            eq_bottom = y_eq + 24
        elif kind == "cap":
            capacitor(x, y_eq)
            line(x, y_eq + 7, x, y_eq + 22, 2)
            ground(x, y_eq + 22)
            eq_bottom = y_eq + 32
        elif kind == "reactor":
            coil(x, y_eq)
            line(x, y_eq + 27, x, y_eq + 36, 2)
            ground(x, y_eq + 36)
            eq_bottom = y_eq + 46
        else:
            rect(x - 30, y_eq, 60, 30, "#eef")
            text(x, y_eq + 19, "TRAILER", 9, "middle", "bold")
            eq_bottom = y_eq + 30
        yy = block(x, eq_bottom + 18, b["title"], 11, "middle", "bold", chars=max(int((span - 10) / 6.4), 8), max_lines=2)
        block(x, yy + 1, b["lines"], 9.5, "middle", chars=max(int((span - 8) / 5.4), 10), max_lines=7)

    ev = raw["states"][raw["case_labels"][0]]
    notes = ["1. Ratings are screening-level typical values, not OEM data; verify with detailed engineering.",
             "2. Bus numbers and names match the PSS/E v33 RAW export of this design.",
             f"3. Operating point shown: peak-load case, OLTC position {ev['tap_pos']:+d} (tap {1 - raw.get('tap_step', TAP_STEP) * ev['tap_pos']:.4f} pu), "
             f"{ev['stages_in']} capacitor stage(s) in service.",
             "4. Protection device numbers per IEEE C37.2; full schedule in the design basis protection summary.",
             "5. " + ("Equivalent model: each plant is one generator and one equivalent step-up transformer (same MVA, same parallel impedance); BOQ counts are per block."
                      if m.get("detail") == "equivalent" else "Detailed model: every block and step-up transformer is modelled and listed in the BOQ.")]
    notes += [f"{len(notes) + 1}. {extra}." for extra in m.get("not_built") or []]
    top = H - 215
    text(40, top, "NOTES", 11, weight="bold")
    ny = top + 15
    for note in notes:
        ny = block(40, ny, note, 9.5, chars=96, max_lines=3)

    lx, ly = 700, top - 14
    rect(lx - 10, ly - 4, 380, 192, "#fff", col["ink"], 1.2)
    text(lx, ly + 12, "LEGEND", 11, weight="bold")
    items = [("breaker", "Circuit breaker"), ("ct", "Current transformer"), ("trafo", "Power transformer"), ("gen", "Generator / wind turbine"),
             ("inv", "Inverter (DC/AC)"), ("bat", "Battery storage"), ("cap", "Capacitor bank (detuned)"), ("coil", "Shunt reactor"),
             ("ngr", "Neutral earthing resistor"), ("load", "Load"), ("pv", "PV array"), ("src", "Utility source")]
    for k, (kind, label) in enumerate(items):
        cx = lx + 18 + 188 * (k // 6)
        cy = ly + 36 + 24 * (k % 6)
        if kind == "breaker":
            breaker(cx, cy, 10)
        elif kind == "ct":
            ct(cx, cy)
        elif kind == "trafo":
            trafo(cx, cy, col["mv"], col["lv"], 7)
        elif kind == "gen":
            circle(cx, cy, 9, fill="#fff")
            text(cx, cy + 4, "G", 10, "middle", "bold")
        elif kind == "inv":
            inverter(cx, cy - 8, 26, 16)
        elif kind == "bat":
            battery(cx, cy - 8, 26, 16)
        elif kind == "cap":
            capacitor(cx, cy - 4)
        elif kind == "coil":
            coil(cx, cy - 9, 3, 3)
        elif kind == "ngr":
            resistor(cx, cy - 8, 12)
        elif kind == "load":
            load_arrow(cx, cy - 10)
        elif kind == "pv":
            pv_array(cx, cy - 8, 26, 16)
        else:
            circle(cx, cy, 9, fill="#fff")
            text(cx, cy + 5, "~", 13, "middle", "bold")
        text(cx + 26, cy + 4, label, 9.5)
    for k, (key, label) in enumerate((("hv", "HV"), ("mv", "MV"), ("lv", "LV"))):
        if key == "hv" and not m["has_grid"]:
            continue
        kv = {"hv": m["v_hv"], "mv": m["v_mv"], "lv": m["lv_kv"]}[key]
        line(lx + 6 + 118 * k, ly + 176, lx + 30 + 118 * k, ly + 176, 5, col[key])
        text(lx + 36 + 118 * k, ly + 180, f"{label} {kv:g} kV", 9.5)

    tb_w, tb_h = 440, 176
    tb_x, tb_y = W - 40 - tb_w, H - 40 - tb_h
    rect(tb_x, tb_y, tb_w, tb_h, "#fff", col["ink"], 2)
    rows = [("PROJECT", "GenStudio microgrid"), ("DRAWING", "Single line diagram - final design"), ("OPTION", f"{m['code']} - {m['title']}"),
            ("DRAWING NO.", meta["drawing_no"]), ("REV / DATE", f"{meta['revision']} / {meta['generated'][:10]}"),
            ("DRAWN BY", f"{meta.get('application', 'GenStudio Design')} (automated)"), ("STATUS", f"Preliminary - design check {meta['status']}"),
            ("SCALE / SHEET", "NTS / 1 of 1")]
    row_h = tb_h / len(rows)
    for k, (label, value) in enumerate(rows):
        yy = tb_y + row_h * k
        if k:
            line(tb_x, yy, tb_x + tb_w, yy, 1)
        text(tb_x + 8, yy + row_h - 7, label, 8.5, c=col["mute"])
        text(tb_x + 110, yy + row_h - 7, value, 10.5, weight="bold")
    line(tb_x + 104, tb_y, tb_x + 104, tb_y + tb_h, 1)
    a("</svg>")
    return "\n".join(out)


# --------------------------------------------------------------------------- PSS/E RAW model + writer

def _raw_model(spec, case_results, planned, aux_kw, aux_kva, values):
    """Physical bus/branch/transformer/generator lists plus per-case operating states for the RAW writer."""
    v_mv, v_hv = spec["v_mv"], spec["v_hv"]
    buses, branches, trafos, gens, loads, shunts, switched = [], [], [], [], [], [], []

    def bus(num, name, kv, zone, node, ide=1):
        buses.append(dict(num=num, name=name[:12], kv=kv, zone=zone, node=node, ide=ide))

    def zr(mva, z, xr):
        r = z / 100.0 / math.sqrt(1 + xr ** 2)
        return r, math.sqrt(max((z / 100.0) ** 2 - r ** 2, 0.0))

    N, NM = spec["names"]["bus"], spec["names"]["name"]
    BUS = N

    if spec["has_grid"]:
        bus(N["grid"], NM["grid"], v_hv, 1, "GRID__src", ide=3)
        bus(N["pcc"], NM["pcc"], v_hv, 1, IDS["grid"])
        z_pu = pf.BASE_MVA / spec["sc_mva"]
        r = z_pu / math.sqrt(1 + spec["sc_xr"] ** 2)
        branches.append(dict(f=BUS["grid"], t=BUS["pcc"], ckt="1", r=r, x=r * spec["sc_xr"], b=0.0, rate=round(spec["sc_mva"], 1), len=0.0, name="GRID EQUIV"))
        bus(BUS["hv"], NM["hv"], v_hv, 2, IDS["hv"])
        inc = spec["feeders"]["incoming"]
        zbase = v_hv ** 2 / pf.BASE_MVA
        rate = round(SQ3 * v_hv * inc["derated_a"] / 1000.0, 2)
        for c in range(inc["circuits"]):
            branches.append(dict(f=BUS["pcc"], t=BUS["hv"], ckt=str(c + 1), r=inc["r"] * inc["length_km"] / zbase, x=inc["x"] * inc["length_km"] / zbase,
                                 b=inc["b"] * 1e-6 * inc["length_km"] * zbase, rate=rate, len=inc["length_km"], name="INCOMING"))
    if spec["main_tr"]:
        bus(BUS["main"], NM["main"], v_mv, 2, IDS["mv"])
        z, xr = _tz(spec, "main", spec["main_mva"])
        r, x = zr(spec["main_mva"], z, xr)
        p0, pk = transformer_losses(spec["main_mva"], z, xr)
        for u in range(spec["main_n"]):
            trafos.append(dict(hv=BUS["hv"], lv=BUS["main"], ckt=str(u + 1), name=f"MAIN TR{u + 1}", r=r, x=x, mva=spec["main_mva"], nomv1=v_hv, nomv2=v_mv,
                               tap_key="main", rate=spec["main_mva"], ntp=2 * TAP_MAX_POS + 1, rma=1 + TAP_STEP * TAP_MAX_POS, rmi=1 - TAP_STEP * TAP_MAX_POS,
                               p0_w=p0 * 1000.0, mag=0.003, bus_ctrl=BUS["main"]))
    else:
        bus(BUS["main"], NM["main"], v_mv, 2, IDS["hv"] if spec["has_grid"] else IDS["mv"])
    root = BUS["main"]
    # load
    bus(BUS["load"], NM["load"], v_mv, 2, IDS["load"])
    f = spec["feeders"]["load"]
    zbase_mv = v_mv ** 2 / pf.BASE_MVA
    for c in range(f["circuits"]):
        branches.append(dict(f=root, t=BUS["load"], ckt=str(c + 1), r=f["r"] * f["length_km"] / zbase_mv, x=f["x"] * f["length_km"] / zbase_mv,
                             b=f["b"] * 1e-6 * f["length_km"] * zbase_mv, rate=round(SQ3 * v_mv * f["derated_a"] / 1000.0, 2), len=f["length_km"], name="LOAD FDR"))
    loads.append(dict(bus=BUS["load"], id="1", node=IDS["load"]))
    gen_index = []
    equiv = spec.get("detail", DEFAULT_DETAIL) == "equivalent"
    for g in spec["groups"]:
        k, pl = g["kind"], spec["plans"][g["kind"]]
        base = spec["names"]["unit_base"][k]
        coll = N[k]
        bus(coll, f"{NM[k]}", v_mv, 2, f"{k.upper()}_C")
        fd = spec["feeders"][k]
        n_ckt = fd["circuits"]
        # the equivalent collector feeder is the parallel of its circuits: Z/c, B*c, rating*c
        for c in range(1 if equiv else n_ckt):
            m_c = n_ckt if equiv else 1
            branches.append(dict(f=root, t=coll, ckt=str(c + 1), r=fd["r"] * fd["length_km"] / zbase_mv / m_c, x=fd["x"] * fd["length_km"] / zbase_mv / m_c,
                                 b=fd["b"] * 1e-6 * fd["length_km"] * zbase_mv * m_c, rate=round(SQ3 * v_mv * fd["derated_a"] * m_c / 1000.0, 2),
                                 len=fd["length_km"], name=f"{k.upper()[:6]} FDR{' EQ' if equiv and n_ckt > 1 else ''}"))
        n = pl["n"]
        scale = n if equiv else 1
        units = [0] if equiv else range(n)
        if pl["has_gsu"]:
            z, xr = _tz(spec, k, max(pl["skid_mva"], 2.5))
            r, x = zr(pl["skid_mva"], z, xr)
            p0, _pk = transformer_losses(pl["skid_mva"], z, xr)
            if k in pf.GENSETS or k == "wind":
                pmax_unit = pl["unit_mw"]
            else:
                pmax_unit = pl["unit_mva"] * pl.get("pf", PF_CAP)
            for u in units:
                num = base + 1 + u
                bus(num, f"{NM[k + '_unit']}_EQ"[:12] if equiv else f"{NM[k + '_unit']}_{u + 1:02d}"[:12], pl["v_lv"], 2, k)
                trafos.append(dict(hv=coll, lv=num, ckt="1", name=f"{k.upper()[:6]} TR EQ" if equiv else f"{k.upper()[:6]} TR{u + 1}", r=r, x=x,
                                   mva=pl["skid_mva"] * scale, nomv1=v_mv, nomv2=pl["v_lv"], tap_key=k, rate=pl["skid_mva"] * scale, ntp=5,
                                   rma=1.05, rmi=0.95, p0_w=p0 * 1000.0 * scale, mag=0.004, bus_ctrl=0))
                gen_index.append(dict(bus=num, tech=k, id="1", n=1 if equiv else n, unit=u, mbase=pl["unit_mva"] * scale, pmax=pmax_unit * scale,
                                      pf=pl.get("pf"), pf_lead=pl.get("pf_lead")))
        else:
            if equiv:
                gen_index.append(dict(bus=coll, tech=k, id="1", n=1, unit=0, mbase=pl["unit_mva"] * n, pmax=pl["unit_mw"] * n))
            else:
                for u in range(n):
                    gen_index.append(dict(bus=coll, tech=k, id=str(u + 1), n=n, unit=u, mbase=pl["unit_mva"], pmax=pl["unit_mw"]))
    # reactive and auxiliary
    if spec["stages"]:
        switched.append(dict(bus=BUS["main"], stage=spec["stage_mvar"], stages=spec["stages"]))
    if spec["reactor_mvar"]:
        shunts.append(dict(bus=BUS["main"], id="R1", mvar=-spec["reactor_mvar"], key="reactor"))
    bus(BUS["aux"], NM["aux"], 0.4, 2, "AUX")
    aux_z, aux_xr = 5.0, 6.0
    r, x = zr(aux_kva / 1000.0, aux_z, aux_xr)
    trafos.append(dict(hv=BUS["main"], lv=BUS["aux"], ckt="1", name="AUX TR", r=r, x=x, mva=aux_kva / 1000.0, nomv1=v_mv, nomv2=0.4, tap_key="aux",
                       rate=aux_kva / 1000.0, ntp=5, rma=1.05, rmi=0.95, p0_w=aux_kva * 1.0, mag=0.01, bus_ctrl=0))
    loads.append(dict(bus=BUS["aux"], id="1", node="AUX", fixed_mw=aux_kw / 1000.0, fixed_mvar=aux_kw / 1000.0 * 0.484))
    states = {}
    for label, hour, inj, res in case_results:
        case = res["case"]
        states[label] = dict(
            timestamp=inj["timestamp"], tap_pos=res["tap_pos"], stages_in=res["stages_in"], reactor_in=bool(res["reactor_in"]),
            volt={b["id"]: (b["vm"], b["va_deg"]) for b in case["buses"]},
            internal={b["id"]: (b["vm"], b["va_deg"]) for b in case["internal"]},
            load={b["id"]: (b["load_mw"], b["load_mvar"]) for b in case["buses"] if b["load_mw"] or b["load_mvar"]},
            gen={g["id"] + "|" + g["tech"]: (g["p_mw"], g["q_mvar"], g["q_min"], g["q_max"], g.get("src_p_mw"), g.get("src_q_mvar")) for g in case["gens"]},
            gen_tech={g["tech"]: (g["p_mw"], g["q_mvar"], g["q_min"], g["q_max"], g["slack"], g["cap_mw"]) for g in case["gens"]},
            converged=bool(case["converged"]))
    return dict(buses=buses, branches=branches, trafos=trafos, gens=gen_index, loads=loads, shunts=shunts, switched=switched, states=states,
                swing=BUS["grid"] if spec["has_grid"] else None, base_mva=pf.BASE_MVA, v_hv=v_hv, v_mv=v_mv, has_grid=spec["has_grid"],
                name=f"GenStudio design {len(buses)} buses", case_labels=list(states), detail=spec.get("detail", DEFAULT_DETAIL),
                equivalence=_equivalence(spec))


def raw_text(design, case=None):
    """PSS/E v33 RAW for the final design at the named operating case (default: first case, the peak-load hour)."""
    m = design["raw_model"]
    labels = m["case_labels"]
    case = next((l for l in labels if l == case or (case and l.startswith(case))), labels[0])
    st = m["states"][case]
    bus_node = {b["num"]: b["node"] for b in m["buses"]}
    swing = m["swing"]
    if swing is None:
        forming = next((g for g in m["gens"] if g["tech"] == "bess"), None) or (m["gens"][0] if m["gens"] else None)
        swing = forming["bus"] if forming else m["buses"][0]["num"]
    lines = [f"0, {m['base_mva']:.2f}, 33, 0, 0, {m.get('freq', 60.0):.2f}     / GenStudio final design - PSS/E v33 RAW",
             f"Design {design['meta']['scenario']} ({design['meta'].get('scenario_name') or ''}) - {m.get('detail', 'detailed')} model - operating case: {case}"[:120],
             f"Revision {design['meta']['revision']} {design['meta']['generated']} - screening-level data, verify before use"]
    vmap = dict(st["volt"])

    def volts(num):
        node = bus_node[num]
        if node == "GRID__src":
            return st["internal"].get("GRID__src", (1.0, 0.0))
        if node in vmap:
            return vmap[node]
        return (1.0, 0.0)

    lo, hi = 0.95, 1.05
    for b in m["buses"]:
        vm, va = volts(b["num"])
        ide = 3 if b["num"] == swing else 2 if any(g["bus"] == b["num"] for g in m["gens"]) else 1
        lines.append(f"{b['num']}, '{b['name']}', {b['kv']:.4f}, {ide}, 1, {b['zone']}, {1 if b['zone'] == 1 else 2}, {vm if vm else 1.0:.4f}, {va:.4f}, "
                     f"{hi:.4f}, {lo:.4f}, 1.1000, 0.9000")
    lines.append(pf.raw_terminator(0))
    for ld in m["loads"]:
        if "fixed_mw" in ld:
            p, q = ld["fixed_mw"], ld["fixed_mvar"]
        else:
            p, q = st["load"].get(ld["node"], (0.0, 0.0))
        zone = next(b["zone"] for b in m["buses"] if b["num"] == ld["bus"])
        lines.append(f"{ld['bus']}, '{ld['id']}', 1, 1, {zone}, {p:.4f}, {q:.4f}, 0.0, 0.0, 0.0, 0.0, 2, 1, 0")
    lines.append(pf.raw_terminator(1))
    for s in m["shunts"]:
        on = st["reactor_in"]
        lines.append(f"{s['bus']}, '{s['id']}', {1 if on else 0}, 0.0, {s['mvar']:.4f}")
    lines.append(pf.raw_terminator(2))
    for g in m["gens"]:
        tech = g["tech"]
        row = st["gen_tech"].get(tech)
        if not row:
            continue
        p, q, qmin, qmax, slack, cap = row
        n = g["n"]
        pu, qu = p / n, q / n
        qmin_u = (qmin if qmin is not None else -abs(qu) - 0.1) / n
        qmax_u = (qmax if qmax is not None else abs(qu) + 0.1) / n
        pmax = g["pmax"]
        pmin = -pmax if tech == "bess" else 0.0
        inv = tech in ("pv", "bess", "wind")
        zx = 0.909 if inv else 0.15
        vs = (volts(g["bus"])[0]) or 1.0
        if inv and not (g["bus"] == swing):
            # reactive capability from the operating power factor at rated MW (MBASE = MVA, PMAX = MW)
            ql = unit_pf.q_limits(pmax, g.get("pf") or unit_pf.DEFAULT_PF, g.get("pf_lead") or unit_pf.DEFAULT_PF)
            qmax_u, qmin_u = ql[1] / n, ql[0] / n
        lines.append(f"{g['bus']}, '{g['id']}', {pu:.4f}, {qu:.4f}, {qmax_u:.4f}, {qmin_u:.4f}, {vs:.4f}, 0, {g['mbase']:.3f}, 0.0, {zx:.4f}, 0.0, 0.0, 1.0, 1, 100.0, "
                     f"{pmax:.4f}, {pmin:.4f}, 1, 1.0")
    # utility equivalent generator (swing)
    if m["has_grid"]:
        row_src = st["internal"].get("GRID__src", (1.0, 0.0))
        p_grid, q_grid = _src_flow(st)
        lines.append(f"{m['swing']}, '1', {p_grid:.4f}, {q_grid:.4f}, 9999.0, -9999.0, {row_src[0]:.4f}, 0, 1000.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1, 100.0, 9999.0, -9999.0, 1, 1.0")
    lines.append(pf.raw_terminator(3))
    for br in m["branches"]:
        lines.append(f"{br['f']}, {br['t']}, '{br['ckt']}', {br['r']:.7f}, {br['x']:.7f}, {br['b']:.7f}, {br['rate']:.2f}, {br['rate']:.2f}, {br['rate']:.2f}, "
                     f"0.0, 0.0, 0.0, 0.0, 1, 1, {br['len']:.3f}, 1, 1.0")
    lines.append(pf.raw_terminator(4))
    for tr in m["trafos"]:
        key = tr["tap_key"]
        if key == "main":
            tap = 1.0 - m.get("tap_step", TAP_STEP) * st["tap_pos"]
        else:
            tap = 1.0 + (m.get("skid_tap") or {}).get(key, 0.0) if key != "aux" else 1.0
        ctrl = 0
        lines.append(f"{tr['hv']}, {tr['lv']}, 0, '{tr['ckt']}', 1, 2, 2, 0.0, {tr['mag']:.4f}, 2, '{tr['name'][:12]}', 1, 1, 1.0")
        lines.append(f"{tr['r']:.7f}, {tr['x']:.7f}, {tr['mva']:.3f}")
        lines.append(f"{tap:.4f}, {tr['nomv1']:.4f}, 0.0, {tr['rate']:.3f}, {tr['rate']:.3f}, {tr['rate']:.3f}, {ctrl}, 0, {tr['rma']:.4f}, {tr['rmi']:.4f}, "
                     f"{tr['rma']:.4f}, {tr['rmi']:.4f}, {tr['ntp']}, 0, 0.0, 0.0, 0.0")
        lines.append(f"1.0, {tr['nomv2']:.4f}")
    lines.append(pf.raw_terminator(5))
    lines.append(f"1, {swing}, 0.0, 10.0, 'MICROGRID'")
    for k in range(6, len(pf.RAW_SECTIONS)):
        name = pf.RAW_SECTIONS[k]
        if name == "ZONE":
            lines.append("1, 'UTILITY'")
            lines.append("2, 'MICROGRID'")
        elif name == "OWNER":
            lines.append("1, 'UTILITY'")
            lines.append("2, 'MICROGRID'")
        elif name == "SWITCHED SHUNT":
            for s in m["switched"]:
                binit = st["stages_in"] * s["stage"]
                lines.append(f"{s['bus']}, 0, 0, 1, 1.05000, 0.95000, 0, 100.0, '', {binit:.4f}, {s['stages']}, {s['stage']:.4f}")
        lines.append(pf.raw_terminator(k))
    lines.append("Q")
    return "\r\n".join(lines) + "\r\n"


def _src_flow(st):
    g = st["gen"]
    for key, row in g.items():
        if key.startswith("GRID|") and row[4] is not None:
            return row[4], row[5]
    return 0.0, 0.0


# --------------------------------------------------------------------------- user edits: effective values, topology write-back, save / reset / power flow

def _effective(spec):
    """The value in force for every editable parameter ({key: value}) with its source ({key: assumed|model|user-set})."""
    ov = spec.get("ov") or {}
    vals, src = {}, {}

    def put(key, value, source=None):
        if value is None:
            return
        vals[key] = round(float(value), 4) if isinstance(value, (int, float)) and not isinstance(value, bool) else value
        src[key] = "user-set" if key in ov else (source or "assumed")

    put("v_hv_kv", spec["v_hv"], spec.get("v_hv_source"))
    put("v_mv_kv", spec["v_mv"], spec.get("v_mv_source"))
    put("lv_kv", LV_KV)
    put("frequency_hz", float(ov.get("frequency_hz", 60.0)))
    put("load_pf", spec["load_pf"], spec.get("load_pf_source"))
    if spec["has_grid"]:
        put("grid_sc_mva", spec["sc_mva"], spec.get("sc_source"))
        put("grid_xr", spec["sc_xr"], spec.get("xr_source"))
    for k, (v, s) in spec["limits"].items():
        put(k, v, s)
    if spec.get("main_tr"):
        z, xr = _tz(spec, "main", spec["main_mva"])
        put("main_tr_n", spec["main_n"])
        put("main_tr_mva", spec["main_mva"])
        put("main_tr_z_pct", z)
        put("main_tr_xr", xr)
        put("tap_step_pct", TAP_STEP * 100.0)
        put("tap_max_pos", TAP_MAX_POS)
    put("shunt_stages", spec["stages"], spec.get("shunt_source"))
    put("shunt_stage_mvar", spec["stage_mvar"] if spec["stages"] else (ov.get("shunt_stage_mvar", 0.0)), spec.get("shunt_source"))
    put("reactor_mvar", spec["reactor_mvar"], spec.get("reactor_source"))
    put("aux_load_kw", spec.get("aux_kw"))
    put("aux_tr_kva", spec.get("aux_kva"))
    put("cable_derate", CABLE_DERATE)
    put("cable_vd_limit_pct", CABLE_VD_LIMIT_PCT)
    if spec["has_grid"] and "incoming" in spec["feeders"]:
        put("incoming_type", spec["feeders"]["incoming"].get("type", "cable"))
    put("clearing_s", CLEARING_S)
    put("ngr_a", spec.get("ngr"))
    if "mv_breaker_ka" in ov:
        put("mv_breaker_ka", ov["mv_breaker_ka"])
    put("pv_module_w", ov.get("pv_module_w", 600))
    put("pv_modules_per_string", ov.get("pv_modules_per_string", 28))
    put("container_mwh", CONTAINER_MWH)
    put("mv_spare_panels", ov.get("mv_spare_panels", 1))
    for g in spec["groups"]:
        k, pl = g["kind"], spec["plans"][g["kind"]]
        if k in ("pv", "bess"):
            put(f"inv_unit_mva.{k}", pl.get("unit_mva"))
        else:
            put(f"unit_mw.{k}", pl.get("unit_mw"))
        if pl.get("skid_mva"):
            z, _xr = _tz(spec, k, max(pl["skid_mva"], 2.5))
            put(f"skid_mva.{k}", pl["skid_mva"])
            put(f"skid_z_pct.{k}", z)
            put(f"skid_tap_pct.{k}", spec["skid_tap"].get(k, 0.0) * 100.0)
    for k, length in spec["length_km"].items():
        put(f"length_km.{k}", length, spec["length_source"].get(k))
        f = spec["feeders"].get(k)
        if f and f.get("area"):
            put(f"area_mm2.{k}", f["area"])
    return dict(values=vals, sources=src)


def _topo_map(spec):
    """What the SLD wires/nodes need to carry for the design in force (used by the topology write-back)."""
    plans, feeders = spec["plans"], spec["feeders"]
    skids = {}
    for g in spec["groups"]:
        k, pl = g["kind"], plans[g["kind"]]
        if pl.get("has_gsu") and pl.get("skid_mva"):
            z, xr = _tz(spec, k, max(pl["skid_mva"], 2.5))
            skids[k] = dict(mva=round(pl["skid_mva"] * pl["n"], 4), z_pct=z, xr=xr, tap=round(1.0 + spec["skid_tap"].get(k, 0.0), 4))
    main = None
    if spec.get("main_tr"):
        z, xr = _tz(spec, "main", spec["main_mva"])
        main = dict(mva=round(spec["main_n"] * spec["main_mva"], 4), z_pct=z, xr=xr)
    cab = {k: dict(type=f.get("type", "cable"), circuits=f.get("circuits", 1), r_ohm_km=f["r"], x_ohm_km=f["x"], b_us_km=f["b"],
                   ampacity_a=f["derated_a"]) for k, f in feeders.items()}
    model = [dict(label=g["label"], value=round(float(g.get("p_mw") or 0.0), 4), unit="MW",
                  note="optimizer capacity (read-only)") for g in spec["groups"]]
    for g in spec["groups"]:
        if g["kind"] == "bess" and plans["bess"].get("mwh"):
            model.append(dict(label=f"{g['label']} energy", value=round(float(plans["bess"]["mwh"]), 4), unit="MWh", note="optimizer capacity (read-only)"))
    model.append(dict(label="Peak served load", value=round(float(spec["peak_load_mw"]), 4), unit="MW", note="from the dispatch (read-only)"))
    return dict(plans={k: plans[k]["n"] for k in plans}, skids=skids, main=main, feeders=cab, model=model,
                shunt=dict(stages=spec["stages"], stage_mvar=spec["stage_mvar"], reactor_mvar=spec["reactor_mvar"]))


def _topo_diagram(topology, code):
    if isinstance(topology, dict) and isinstance(topology.get("diagrams"), dict):
        found = topology["diagrams"].get(code)
        return found if isinstance(found, dict) else None
    return topology if isinstance(topology, dict) and isinstance(topology.get("nodes"), list) else None


def _put(box, key, value):
    if value is None:
        box.pop(key, None)
    else:
        box[key] = value


def _undo(d, written):
    """Put back the original value of every key this module wrote (only when it still holds the value we wrote)."""
    nodes = {n.get("id"): n for n in d.get("nodes", [])}
    lines = {e.get("id"): e for e in d.get("lines", [])}
    for rows, index, top in ((written.get("nodes") or {}, nodes, False), (written.get("lines") or {}, lines, True)):
        for ident, keys in rows.items():
            row = index.get(ident)
            if row is None:
                continue
            for tag, pair in keys.items():
                orig, new = pair
                if tag.startswith("top:"):
                    if row.get(tag[4:]) == new:
                        _put(row, tag[4:], orig)
                    continue
                key = tag[2:] if tag.startswith("e:") else tag
                el = row.get("electrical")
                if isinstance(el, dict) and el.get(key) == new:
                    _put(el, key, orig)
            if isinstance(row.get("electrical"), dict) and not row["electrical"]:
                del row["electrical"]
    pfs = d.get("pf_settings")
    for key, (orig, new) in (written.get("pf") or {}).items():
        if isinstance(pfs, dict) and pfs.get(key) == new:
            _put(pfs, key, orig)
    if isinstance(pfs, dict) and not pfs:
        del d["pf_settings"]


def _restore_topology(topology, code, written):
    topo = json.loads(json.dumps(topology))
    d = _topo_diagram(topo, code)
    if d is not None:
        _undo(d, written)
    return topo


def _apply_ops(d, ops):
    written = dict(nodes={}, lines={}, pf={})
    nodes = {n.get("id"): n for n in d.get("nodes", [])}
    lines = {e.get("id"): e for e in d.get("lines", [])}
    for kind, ident, key, value in ops:
        if kind == "pf":
            box, rec, slot = d.setdefault("pf_settings", {}), written["pf"], key
        elif kind == "node":
            box, rec, slot = nodes[ident].setdefault("electrical", {}), written["nodes"].setdefault(ident, {}), key
        elif kind == "line_e":
            box, rec, slot = lines[ident].setdefault("electrical", {}), written["lines"].setdefault(ident, {}), "e:" + key
        else:
            box, rec, slot = lines[ident], written["lines"].setdefault(ident, {}), "top:" + key
        if slot not in rec:
            rec[slot] = [box.get(key), None]
        box[key] = value
        rec[slot][1] = value
    return {k: v for k, v in written.items() if v}


def _topology_ops(d, tm, ov):
    """Edits to write on the stored SLD for the values the user set (and the design they produced)."""
    nodes, lines = d.get("nodes", []), d.get("lines", [])
    kind_of = {n.get("id"): n.get("kind") for n in nodes}

    def nodes_of(*kinds):
        return [n["id"] for n in nodes if n.get("kind") in kinds]

    def wires_at(kind):
        return [e["id"] for e in lines if kind_of.get(e.get("source")) == kind or kind_of.get(e.get("target")) == kind]

    ops = []
    techs = set(tm.get("plans") or {})
    for key, node_key in (("v_hv_kv", "kv"),):
        if key in ov:
            ops += [("node", i, node_key, ov[key]) for i in nodes_of("grid")]
    for key, node_key in (("grid_sc_mva", "sc_mva"), ("grid_xr", "xr")):
        if key in ov:
            ops += [("node", i, node_key, ov[key]) for i in nodes_of("grid")]
    if "v_mv_kv" in ov:
        ops += [("node", i, "kv", ov["v_mv_kv"]) for i in nodes_of("bus", "load", "substation")]
    if "lv_kv" in ov:
        ops += [("node", i, "kv", ov["lv_kv"]) for i in nodes_of("pv", "bess", "wind") if i]
    for key in ("vmin_pu", "vmax_pu", "thermal_limit_pct", "load_pf"):
        if key in ov:
            ops.append(("pf", None, key, ov[key]))
    if any(k in ov for k in ("shunt_stages", "shunt_stage_mvar", "reactor_mvar")):
        sh = tm["shunt"]
        bus = (nodes_of("bus") or nodes_of("substation") or nodes_of("load") or [None])[0]
        if bus:
            cap = sh["stages"] * sh["stage_mvar"]
            ops.append(("node", bus, "shunt_mvar", round(cap - sh["reactor_mvar"], 4)))
            if sh["stages"] and cap >= sh["reactor_mvar"]:
                ops += [("node", bus, "shunt_steps", int(sh["stages"])), ("node", bus, "shunt_step_mvar", round(sh["stage_mvar"], 4))]
    for key, value in ov.items():
        base, _, k = key.partition(".")
        if base == "length_km":
            wanted = "grid" if k == "incoming" else k
            ops += [("line_top", i, "length_km", value) for i in wires_at(wanted)]
    cables = tm.get("feeders") or {}
    for key, el in cables.items():
        if key == "incoming":
            touched = "incoming_type" in ov or "area_mm2.incoming" in ov or "cable_derate" in ov
        else:
            touched = f"area_mm2.{key}" in ov or "cable_derate" in ov
        if touched:
            for i in wires_at("grid" if key == "incoming" else key):
                ops += [("line_e", i, k2, v) for k2, v in el.items()]
    if tm.get("main") and any(k in ov for k in ("main_tr_n", "main_tr_mva", "main_tr_z_pct", "main_tr_xr")):
        for i in wires_at("grid"):
            ops += [("line_e", i, "kind", "transformer"), ("line_e", i, "mva", tm["main"]["mva"]),
                    ("line_e", i, "z_pct", tm["main"]["z_pct"]), ("line_e", i, "xr", tm["main"]["xr"])]
    for k, sk in (tm.get("skids") or {}).items():
        if any(f"{b}.{k}" in ov for b in ("skid_mva", "skid_z_pct", "skid_tap_pct", "inv_unit_mva", "unit_mw")):
            for i in wires_at(k):
                ops += [("line_e", i, "kind", "transformer"), ("line_e", i, "mva", sk["mva"]), ("line_e", i, "z_pct", sk["z_pct"]),
                        ("line_e", i, "xr", sk["xr"]), ("line_e", i, "tap", sk["tap"])]
    return ops


def _read_request(folder):
    return json.loads((Path(folder) / "request.json").read_text(encoding="utf-8"))


def _write_topology(folder, code, prior, design, ov):
    """Restore what an earlier save wrote, then write the mapped edits into the stored SLD of this scenario ({} when none stored)."""
    try:
        req = _read_request(folder)
    except (OSError, ValueError):
        return {}
    d = _topo_diagram(req.get("topology"), code)
    if d is None:
        return {}
    _undo(d, prior or {})
    written = _apply_ops(d, _topology_ops(d, design["topo_map"], ov)) if ov else {}
    if written or prior:
        _atomic_write(Path(folder) / "request.json", req)
    return written


def _resolve_code(run_id, scenario):
    folder = extensions.run_folder(run_id)
    summary = (json.loads((folder / "status.json").read_text(encoding="utf-8")).get("summary") or {})
    code = scenario or recommended_scenario(run_id, summary)
    if not code or code not in {r.get("code") for r in summary.get("results") or []}:
        raise ValueError(f"Scenario {code} is not in this saved run.")
    return folder, code


def save_overrides(run_id, scenario, values):
    """Replace the user-set design values of one scenario: validate, rebuild, map into the stored SLD, write atomically."""
    folder, code = _resolve_code(run_id, scenario)
    vals = validate_overrides(values)
    design = build_design(run_id, code, overrides=vals)
    prior = load_overrides(run_id, code)
    written = _write_topology(folder, code, prior["written"], design, vals)
    path = overrides_path(folder, code)
    if not vals and not written:
        try:
            path.unlink()
        except OSError:
            pass
        return dict(version=OV_VERSION, values={}, written={}, updated=None)
    rec = dict(version=OV_VERSION, scenario=code, values=vals, written=written,
               updated=datetime.datetime.now().isoformat(timespec="seconds"))
    _atomic_write(path, rec)
    return rec


def reset_overrides(run_id, scenario, keys=None):
    """Drop the named user-set values (all when keys is None/empty) and restore the stored SLD for them."""
    folder, code = _resolve_code(run_id, scenario)
    current = load_overrides(run_id, code)["values"]
    drop = set(keys or current)
    return save_overrides(run_id, code, {k: v for k, v in current.items() if k not in drop})


def design_params(run_id, scenario=None):
    """Everything the editable-assumptions panel needs: fields with value/default/source/limits, read-only model rows, shunt note."""
    folder, code = _resolve_code(run_id, scenario)
    cur = build_design(run_id, code)
    base = build_design(run_id, code, overrides={})
    rec = load_overrides(run_id, code)
    eff, eff0 = cur["effective"], base["effective"]
    fields = []
    for key, value in eff["values"].items():
        d = PARAMS[key.partition(".")[0]]
        fields.append(dict(key=key, label=param_label(key), group=d["group"], unit=d["unit"], value=value, default=eff0["values"].get(key),
                           source=eff["sources"].get(key, "assumed"), user_set=key in rec["values"], min=d.get("lo"), max=d.get("hi"),
                           choices=d.get("choices"), integer=bool(d.get("integer")), maps=d["maps"]))
    saved_pf = None
    try:
        saved_pf = json.loads((folder / f"design_pf_{code}.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    return dict(run_id=run_id, scenario=code, fields=fields, model=cur["topo_map"]["model"], overrides=rec["values"], updated=rec.get("updated"),
                mapped_to_topology=bool(rec["written"]), shunt_note=SHUNT_NOTE, power_flow=saved_pf,
                note="Optimizer capacities are read-only: change them in the scenario setup and re-run the optimization.")


def run_power_flow(run_id, scenario, values=None):
    """Optionally save values, then screen the scenario on the stored SLD (with the design edits written into it)."""
    folder, code = _resolve_code(run_id, scenario)
    if values is not None:
        save_overrides(run_id, code, values)
    ov = load_overrides(run_id, code)["values"]
    topology = None
    try:
        req = _read_request(folder)
        if _topo_diagram(req.get("topology"), code) is not None:
            topology = req["topology"]
    except (OSError, ValueError):
        pass
    if topology is not None:
        overrides = dict(topology=topology)
    else:
        overrides = dict(pf_settings={k: v for k, v in ov.items() if k in ("vmin_pu", "vmax_pu", "thermal_limit_pct", "load_pf")})
    out = pf.screen_scenario(run_id, code, overrides=overrides)
    rec = dict(scenario=code, status=out["status"], normal_status=out["normal_status"], n1_status=out["n1_status"], summary=out["summary"],
               violations=out["violations"][:60], n_violations=len(out["violations"]), warnings=(out.get("warnings") or [])[:10],
               suggestions=[{k: v for k, v in s.items() if not isinstance(v, (dict, list))} for s in (out.get("suggestions") or [])[:6]],
               screened=out.get("screened"), worst_case=out.get("worst_case"), on_saved_topology=topology is not None,
               user_set=sorted(ov), ran=datetime.datetime.now().isoformat(timespec="seconds"))
    rec = clean(rec)
    _atomic_write(folder / f"design_pf_{code}.json", rec)
    return rec


# --------------------------------------------------------------------------- API

def _args(query):
    run_id = (query.get("run_id") or [None])[0]
    scenario = (query.get("scenario") or [None])[0] or None
    if not run_id:
        raise ValueError("Select a saved run.")
    return run_id, scenario


def _detail(query):
    return norm_detail((query.get("detail") or [None])[0])


def _get_design(query):
    run_id, scenario = _args(query)
    d = build_design(run_id, scenario, detail=_detail(query))
    return {k: v for k, v in d.items() if k != "raw_model"}


def _get_options(query):
    run_id = (query.get("run_id") or [None])[0]
    if not run_id:
        raise ValueError("Select a saved run.")
    return scenario_options(run_id)


def _param_text(params):
    return "; ".join(f"{k.replace('_', ' ')}: {v}" for k, v in (params or {}).items() if v is not None and not isinstance(v, (dict, list)))


def equipment_csv(design):
    import csv
    import io
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow(["ID", "Category", "Type", "Description", "Rating", "Voltage", "Quantity", "Parameters", "Basis", "Status", "Engineering flag"])
    for e in design["equipment"]:
        w.writerow([e["id"], e["category"], e["type"], e["description"], e["rating"], e["voltage"], e["quantity"], _param_text(e["params"]),
                    e["basis"], e["status"], e.get("flag") or ""])
    return "\ufeff" + buf.getvalue()


def design_json(design):
    return json.dumps({k: v for k, v in design.items() if k != "raw_model"}, indent=2, allow_nan=False)


def _get_json(query):
    run_id, scenario = _args(query)
    return design_json(build_design(run_id, scenario, detail=_detail(query))).encode("utf-8"), "application/json; charset=utf-8"


def _get_csv(query):
    run_id, scenario = _args(query)
    return equipment_csv(build_design(run_id, scenario, detail=_detail(query))).encode("utf-8"), "text/csv; charset=utf-8"


def _get_raw(query):
    run_id, scenario = _args(query)
    case = (query.get("case") or [None])[0]
    return raw_text(build_design(run_id, scenario, detail=_detail(query)), case).encode("utf-8"), "text/plain; charset=utf-8"


def _get_sld(query):
    run_id, scenario = _args(query)
    return sld_svg(build_design(run_id, scenario, detail=_detail(query))).encode("utf-8"), "image/svg+xml; charset=utf-8"


extensions.GET["design"] = _get_design
extensions.GET["design_options"] = _get_options
extensions.GET["design_raw"] = _get_raw
extensions.GET["design_sld"] = _get_sld
extensions.GET["design_json"] = _get_json
extensions.GET["design_csv"] = _get_csv


def _get_params(query):
    run_id, scenario = _args(query)
    return design_params(run_id, scenario)


def _post_body(payload):
    run_id = payload.get("run_id")
    if not run_id:
        raise ValueError("Select a saved run.")
    return run_id, payload.get("scenario") or None


def _post_save(payload):
    run_id, scenario = _post_body(payload)
    if not isinstance(payload.get("values"), dict):
        raise ValueError("values must be an object of design parameters.")
    save_overrides(run_id, scenario, payload["values"])
    return design_params(run_id, scenario)


def _post_reset(payload):
    run_id, scenario = _post_body(payload)
    keys = payload.get("keys")
    if keys is not None and not (isinstance(keys, list) and all(isinstance(k, str) for k in keys)):
        raise ValueError("keys must be a list of parameter keys.")
    reset_overrides(run_id, scenario, keys or None)
    return design_params(run_id, scenario)


def _post_pf(payload):
    run_id, scenario = _post_body(payload)
    values = payload.get("values")
    if values is not None and not isinstance(values, dict):
        raise ValueError("values must be an object of design parameters.")
    return run_power_flow(run_id, scenario, values)


extensions.GET["design_params"] = _get_params
extensions.POST["design_save"] = _post_save
extensions.POST["design_reset"] = _post_reset
extensions.POST["design_pf"] = _post_pf
