"""Test helper: runs the real GenStudio server with every public-data network call answered locally.

Usage: py -3 datasources_mock_server.py --port 8792   (same arguments as generation_app.py)
Nothing leaves the machine and the Data Cache of the real app is not touched.
"""

import runpy
import shutil
import sys
import tempfile
from pathlib import Path

import datasources
import test_datasources as fixtures

ROOT = Path(__file__).resolve().parent
net = fixtures.Net()
net.add(r"power\.larc\.nasa\.gov", fixtures.nasa_body)
net.add(r"re\.jrc\.ec\.europa\.eu/api/v5_3/seriescalc", fixtures.pvgis_body)
net.add(r"re\.jrc\.ec\.europa\.eu/api/v5_3/tmy", fixtures.tmy_body)
net.add(r"geo\.fcc\.gov", {"County": {"FIPS": "06037", "name": "Los Angeles County"}, "State": {"code": "CA", "name": "California"}})
net.add(r"nominatim\.openstreetmap\.org", [{"lat": "34.0537", "lon": "-118.2428", "display_name": "Los Angeles, California, United States",
                                           "type": "city", "boundingbox": ["33.7", "34.3", "-118.7", "-118.1"], "address": {"state": "California"}}])
net.add(r"tile\.openstreetmap\.org", fixtures.PNG)

cache = Path(tempfile.mkdtemp(dir=ROOT, prefix="_ds_mock_cache_"))
datasources._urlopen = net
datasources.CACHE = cache
try:
    sys.argv = [str(ROOT / "generation_app.py")] + sys.argv[1:]
    runpy.run_path(str(ROOT / "generation_app.py"), run_name="__main__")
finally:
    shutil.rmtree(cache, ignore_errors=True)
