"""Export canonical gross-load inputs independently of generation assumptions."""

import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import plot_style; plot_style.apply()
import numpy as np

import demand_forecasting as forecasting
import generation_app as app


def export():
    folder = app.ROOT / "Load Profile Inputs"
    folder.mkdir(exist_ok=True)
    request = app.validate_request(dict(values={}, scenarios=["R0"], planned_generation=[], solve=False))
    data, _ = app.make_data(request)
    historical = data["historical"]
    header = ["timestamp", "load_mw", "load_max_mw", "load_min_mw"]
    history_rows = [[str(date), *[float(historical[key][i]) for key in ("load", "qmax", "qmin")]]
                    for i, date in enumerate(historical["dates"])]
    future_rows = [[str(date), *[float(data[key][i]) for key in ("load", "qmax", "qmin")]]
                   for i, date in enumerate(data["dates"])]
    for name, rows in (("historical_hourly_2026.csv", history_rows),
                       ("customer_forecast_hourly_2027_2036.csv", future_rows)):
        with (folder / name).open("w", newline="", encoding="utf-8-sig") as stream:
            writer = csv.writer(stream)
            writer.writerow(header)
            writer.writerows(rows)
    with (folder / "combined_hourly_2026_2036.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow(header + ["profile_type"])
        writer.writerows(row + ["historical"] for row in history_rows)
        writer.writerows(row + ["forecast"] for row in future_rows)
    with (folder / "customer_annual_targets.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow(["year", "peak_mw", "growth_percent", "description"])
        for point in data["annual_trajectory"]:
            writer.writerow([point["year"], point["peak_mw"], "", point["description"]])
    fig, axes = plt.subplots(2, 1, figsize=(13, 7))
    axes[0].plot(historical["dates"], historical["load"], lw=.4, color="#bd802f")
    axes[0].set(title="2026 historical comparison: source observations reordered, no growth",
                ylabel="Hourly mean MW", ylim=(0, 48))
    axes[1].plot(data["dates"], data["load"], lw=.3, color="#087e8b")
    axes[1].plot(data["dates"], data["qmax"], lw=.2, alpha=.4, color="#b63e3e")
    axes[1].set(title="Customer-defined gross forecast: hourly mean and within-hour maximum",
                ylabel="MW", ylim=(0, 48))
    for ax in axes:
        ax.grid(alpha=.2)
    fig.tight_layout()
    fig.savefig(folder / "historical_and_forecast.png", dpi=200)
    plt.close(fig)
    annual = data["annual_trajectory"]
    summary = "".join(f"<tr><td>{p['year']}</td><td>{p['peak_mw']:.2f}</td></tr>" for p in annual)
    (folder / "load_profiles.html").write_text(
        '<!doctype html><html lang="en"><meta charset="utf-8"><title>Hourly load inputs</title>'
        '<style>body{font:16px Segoe UI,sans-serif;max-width:1200px;margin:30px auto}img{width:100%}'
        'td,th{padding:6px 20px;border-bottom:1px solid #ddd}table{border-collapse:collapse}</style>'
        '<h1>Hourly historical and customer-defined forecast loads</h1>'
        '<p>Upload the separate historical and forecast CSVs, or the combined file. '
        'All values are gross demand before planned generation or efficiency. '
        'Historical observations from September 2025-August 2026 are reordered onto the 2026 calendar, '
        'without growth or normalization; this is not a measured calendar-2026 record. '
        'Hourly means retain measured energy; load_max_mw retains the within-hour interval peak '
        '(33.34421 MW). Forecast annual targets constrain load_max_mw, not the hourly mean. '
        'The forecast uses the last agreed annual guide, learned month/weekday/hour shapes and '
        'concave within-year interpolation. Intermediate annual points are approximate chart readings, '
        'not newly measured or tabulated client data.</p>'
        '<p><a href="historical_hourly_2026.csv">Historical CSV (8,760 hours)</a> | '
        '<a href="customer_forecast_hourly_2027_2036.csv">Forecast CSV (87,672 hours)</a> | '
        '<a href="combined_hourly_2026_2036.csv">Combined CSV (96,432 hours)</a></p>'
        '<img src="historical_and_forecast.png" alt="Historical and forecast load profiles">'
        '<table><tr><th>Year</th><th>Gross annual interval peak MW</th></tr>' + summary + '</table></html>',
        encoding="utf-8")
    # Validate the actual deliverables with the same importer used by the app.
    history, _ = forecasting.imported_rows("", [dict(content=(folder / "historical_hourly_2026.csv").read_text(
        encoding="utf-8-sig"))], "historical", 2027, 10)
    future, _ = forecasting.imported_rows("", [dict(content=(folder / "customer_forecast_hourly_2027_2036.csv").read_text(
        encoding="utf-8-sig"))], "projected", 2027, 10)
    assert len(history) == 8760 and len(future) == 87672
    np.testing.assert_allclose(sum(r["load_mw"] for _, r in history), 143958.7480525)
    for point in annual[1:]:
        peak = max(row["load_max_mw"] for date, row in future if date.year == point["year"])
        np.testing.assert_allclose(peak, point["peak_mw"], atol=1e-9)
    print(folder)


if __name__ == "__main__":
    export()
