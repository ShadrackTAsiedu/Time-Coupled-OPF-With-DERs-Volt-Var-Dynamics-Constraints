"""Local-only generation planning application. Run with py -3 generation_app.py."""

from __future__ import annotations

import importlib.util
import sys

# Check third-party packages before importing them so a missing one gives an actionable message.
_REQUIRED = {"numpy": "numpy", "docx": "python-docx", "openpyxl": "openpyxl", "highspy": "highspy",
             "scipy": "scipy", "matplotlib": "matplotlib"}
_missing = [pip for module, pip in _REQUIRED.items() if importlib.util.find_spec(module) is None]
if _missing:
    sys.exit("GenStudio cannot start: missing Python package(s): " + ", ".join(_missing) +
             ".\nInstall them with:  py -3 -m pip install " + " ".join(_missing))

import argparse
import calendar
import csv
import hashlib
import json
import logging
import logging.handlers
import math
import os
import re
import shutil
import signal
import socket
from pathlib import Path
import subprocess
import threading
import time
import traceback
import webbrowser
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from uuid import uuid4

os.environ.setdefault("MPLBACKEND", "Agg")  # worker threads render figures; never open a GUI backend
import numpy as np
from docx import Document
from docx.shared import Inches
from openpyxl import Workbook

import optimize_generation_mix as model
import demand_forecasting as forecasting
import planning_inputs as planning_inputs
import scenario_analysis
import scenario_inputs
import planning_tariffs
import resource_profiles
import pv_model
import network_topology
import extensions
import currency
import unit_pf
import version

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / "Application Runs"
LOG_DIR = ROOT / "logs"
SOURCE = ROOT / "Generation Optimization Results" / "forecast_hourly_inputs.csv"
log = logging.getLogger("genstudio")
log.addHandler(logging.NullHandler())
STARTED = time.time()


def configure_logging():
    """Rotating UTF-8 log under logs\\; request details and tracebacks go here, never to the browser."""
    if any(isinstance(h, logging.handlers.RotatingFileHandler) for h in log.handlers):
        return
    LOG_DIR.mkdir(exist_ok=True)
    handler = logging.handlers.RotatingFileHandler(LOG_DIR / "genstudio.log", maxBytes=2_000_000,
                                                   backupCount=5, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.addHandler(handler)
    log.setLevel(logging.INFO)
    log.propagate = False

# Defaults reproduce the existing, disclosed screening assumptions, not site designs.
FIELDS = []


def field(group, key, label, default, low=0, high=1e12, unit="", note="", kind="number", options=None):
    FIELDS.append(dict(group=group, key=key, label=label, default=default,
                       min=low, max=high, unit=unit, note=note, kind=kind, options=options))


def pf_fields(group, tech):
    """Operating power factor (lagging = exporting Mvar) and optional leading limit of one technology."""
    field(group, unit_pf.pf_key(tech), "Operating power factor (lagging)", unit_pf.DEFAULT_PF, unit_pf.PF_MIN, unit_pf.PF_MAX, "pf",
          unit_pf.NOTE + " Reactive capability: Qmax = MW x tan(acos(pf)). Range 0.8-1.0; 1.0 = no reactive capability.")
    field(group, unit_pf.lead_key(tech), "Leading power factor limit (absorbing Mvar)", unit_pf.DEFAULT_PF, unit_pf.PF_MIN, unit_pf.PF_MAX, "pf",
          "Reactive capability mode: how much Mvar the unit can absorb (Qmin = -MW x tan(acos(pf_lead))). Defaults to the same value as the lagging limit.")


field("Solver", "solver_method", "Solving method", "dual_simplex", kind="select",
      options=[(key, spec[0]) for key, spec in model.SOLVERS.items()],
      note="Choose a HiGHS algorithm for both capacity and hourly dispatch LPs. These are three methods of the same solver engine, not three independent software packages. Confirm or change this choice after clicking SOLVE.")

field("Scenarios", "solver", "Solver", "highs", kind="select",
      options=[("highs", "HiGHS (default, bundled)"), ("gurobi", "Gurobi (requires gurobipy and a licence)")],
      note="Gurobi needs your own licence (free academic licences exist). If it is unavailable the run falls back to HiGHS with a warning.")

field("Demand", "horizon_years", "Economic horizon", 10, 1, 30, "years",
      "Number of years used for NPC (1-30). Independent of how much load data you upload; data of any length (24 hours or more) is accepted. If extended appraisal is enabled, tail years repeat final-year gross demand and are physically redispatched for lifecycle costs.")
field("Demand", "start_year", "First forecast operating year", 2027, 2020, 2100, "year",
      "Choose the first forecast year; the preceding year is the historical comparison. Use this year in uploaded timestamps and commissioning dates.")
field("Demand", "forecast_mode", "Forecast mode", "grow", kind="select",
      options=[("grow", "Grow to the economic horizon (growth assumptions)"),
               ("none", "None - use the data as-is (no growth)")],
      note="None uses your load data as the representative profile and repeats it over the economic years (optionally with the flat growth below), so you can size supply for today's load only. Grow applies the growth assumptions below.")
field("Demand", "economic_growth", "Load growth for economics (no-forecast mode)", 0, -.5, 1, "fraction/year",
      note="Used only when Forecast mode is None and the horizon exceeds one year: year n load = data x (1+g)^(n-1). Leave 0 for no growth.")
field("Demand", "annualize_partial", "Annualize data shorter than one year", True, kind="checkbox",
      note="Treat a short load period (24 hours, a week, a month) as representative: it is repeated to fill the year so energy and demand charges are annualized. Uncheck to model only the period itself (the economic years then repeat just that period). Sizing from under a year of data can miss seasons.")
field("Demand", "forecast_method", "Load growth model", "concave", kind="select", options=forecasting.METHODS,
      note="The selected growth factor multiplies EVERY hourly mean, minimum and maximum, not only annual peaks.")
field("Demand", "shape_method", "Historical shape learning", "learned", kind="select", options=forecasting.SHAPES,
      note="Learned mode fits month/weekday/hour means from historical data, aligns future weekdays and normalizes the fitted yearly peak. Replay preserves month/day/hour patterns. A single year cannot establish a long-term trend.")
field("Demand", "trajectory_mode", "Annual trajectory source", "milestones", kind="select",
      options=[("milestones", "Client annual milestones (controlling targets)"), ("model", "Baseline / target growth model")])
field("Demand", "milestone_interpolation", "Missing annual milestone interpolation", "linear",
      kind="select", options=planning_inputs.INTERPOLATIONS)
field("Demand", "baseline", "Growth-model baseline peak", 33.34, 0.001, 10000, "MW",
      "Enter the starting peak for the baseline/future-value method. For annual milestone mode, enter it in the first milestone row.")
field("Demand", "target", "Growth-model target peak", 45, 0.001, 10000, "MW",
      "Baseline/target model mode only. In client milestone mode edit the annual table instead.")
field("Demand", "target_years", "Years to target", 10, 1, 30, "years",
      "Baseline/target model mode only. Independent of the optimization horizon. Client milestone mode uses its annual table.")
field("Grid and tariff", "grid_limit", "Existing import limit", 40, 0, 10000, "MW")
field("Grid and tariff", "reference_grid_limit", "Minimum upgraded reference capacity", 50, 0, 10000, "MW",
      "Grid-only reference is automatically sized to at least the maximum projected load, regardless of the alternative grid limit.")
field("Grid and tariff", "upgrade_cost", "Reference upgrade investment", 70000000, unit="$")
field("Grid and tariff", "upgrade_fom_fraction", "Upgrade annual maintenance fraction", .005, 0, 1, "fraction")
field("Grid and tariff", "tariff_mode", "Energy pricing", "blended", kind="select",
      options=[("blended", "Blended all-inclusive $/kWh"), ("tou", "Seasonal TOU all-inclusive $/kWh")])
field("Grid and tariff", "blended_kwh", "Blended energy rate including tax", .0798, unit="$/kWh",
      note="Enter the total base-year energy price. Do not add delivery, energy taxes or demand components again. Annual inflation is applied once.")
for season in ("summer", "winter"):
    field("Grid and tariff", season + "_same", season.title() + ": use the same rate for all periods",
          True, kind="checkbox", note="Enter the shared price in Off peak; uncheck to enter separate Mid peak and Peak prices.")
    for band, label in (("off", "Off peak"), ("mid", "Mid peak"), ("peak", "Peak")):
        field("Grid and tariff", f"{season}_{band}_kwh", f"{season.title()} {label}: total including tax",
              .0798, unit="$/kWh", note="Enter your complete contracted price; prefilled 0.0798 is the project blended rate, not a verified TOU quote.")
field("Grid and tariff", "summer_start_month", "Summer first month", 6, 1, 12, "month number")
field("Grid and tariff", "summer_end_month", "Summer last month", 9, 1, 12, "month number")
field("Grid and tariff", "peak_start_hour", "Peak period starts", 16, 0, 23, "hour")
field("Grid and tariff", "peak_end_hour", "Peak period ends (exclusive)", 21, 1, 24, "hour")
field("Grid and tariff", "mid_start_hour", "Mid-peak period starts", 21, 0, 23, "hour")
field("Grid and tariff", "mid_end_hour", "Mid-peak period ends (exclusive)", 24, 1, 24, "hour")
field("Grid and tariff", "weekend_mid_peak", "Classify weekend peak hours as Mid peak", True, kind="checkbox",
      note="Set the hour bands and weekend rule to match your tariff. Remaining hours are Off peak; holidays are not automatically classified.")
field("Grid and tariff", "reactive_enabled", "Add reactive-demand charge separately", True, kind="checkbox",
      note="Enable only when the blended or TOU prices exclude this charge.")
field("Grid and tariff", "reactive_rate", "Reactive-demand charge including tax", .66 * 1.045, unit="$/kVar-month",
      note="Enter the billed rate including applicable tax. Project bill: $0.66/kVar-month before 4.5% tax, $0.6897 including tax; this is not an energy $/kWh charge.")
field("Grid and tariff", "reactive_ratio", "Reactive demand / real peak", .37, 0, 10, "kVar/kW")
field("Grid and tariff", "export_enabled", "Allow export to grid", False, kind="checkbox",
      note="Exports come only from on-site generation (PV, wind, generators), never from grid imports.")
field("Grid and tariff", "export_limit_mw", "Export limit", 0, 0, 10000, "MW")
field("Grid and tariff", "export_price", "Export price", 40, 0, 10000, "$/MWh",
      note="Net-metering or avoided-cost rate; confirm with the utility.")
TC_DEFAULTS = dict(ng=(.40, 1.0, 60), ng_chp=(.50, .60, 80), diesel=(.30, 1.0, 15), biogas=(.40, 1.0, 25),
                   biomass=(.50, .30, 120), h2=(.40, 1.0, 70), h2_chp=(.50, .60, 90))
field("BESS", "bess_fade_per_year", "Capacity fade", 0, 0, .1, "fraction/year",
      note="Linear usable-capacity loss until replacement (0 = off). Typical Li-ion 1.5-3%/yr; replacement resets it when replacements are enabled.")
field("Microgrid", "microgrid_min_mw", "Minimum optimized microgrid", 8, unit="MW AC",
      note=      "Enter the combined rating of additional solar, wind, battery discharge power and generators. Exclude grid and planned assets. This is not firm continuous output.")
field("Microgrid", "microgrid_max_mw", "Maximum optimized microgrid", 10, unit="MW AC")
field("Solar PV", "pv_capex", "Installed capital cost", 2500000, unit="$/MW AC",
      note="Screening default for a commercial-scale installation; compare NREL ATB (atb.nlr.gov) commercial and utility PV cases and replace with a supplier quote.")
field("Solar PV", "pv_fom_fraction", "Annual fixed maintenance", .01, 0, 1, "fraction of installed CAPEX")
pf_fields("Solar PV", "pv")
field("Solar PV", "solar_profile_enabled", "Use uploaded hourly solar resource (irradiance or unit PV profile)", False, kind="checkbox",
      note="Preferred: irradiance in W/m2 (poa_irradiance_w_m2, or ghi_w_m2 with optional dni_w_m2/dhi_w_m2) plus temperature_c and wind_speed_ms; PV output is computed from it with the parameters below. "
           "Alternative: a unit PV profile (solar_per_mw, MW per MW) is used as uploaded with no conversion. If off, retain the synthetic/embedded resource.")
field("Solar PV", "solar_derate", "System losses: retained output fraction", .85, .001, 1, "fraction retained",
      "Soiling, wiring, mismatch, availability and inverter losses combined (0.85 retains 85%; industry range 0.77-0.90). Applied once to DC output; annual degradation is applied separately.")
field("Solar PV", "solar_degradation", "Annual PV degradation", .005, 0, .1, "fraction")
field("Solar PV", "pv_dc_ac_ratio", "DC/AC ratio (inverter loading)", 1.0, .5, 2, "MWdc per MWac",
      note="PV capacity in this tool is MW AC (inverter rating). Modules installed = MW AC x this ratio. Output is clipped at the AC rating; 1.0 = no clipping, utility scale is typically 1.2-1.35.")
field("Solar PV", "pv_temp_coefficient", "Power temperature coefficient", -0.35, -1, 0, "% per C",
      note="Crystalline silicon is typically -0.30 to -0.40 %/C above 25 C cell temperature.")
field("Solar PV", "pv_temp_model", "Cell-temperature model", "faiman", kind="select",
      options=[("faiman", "Faiman (uses wind speed)"), ("noct", "NOCT (wind-independent)")],
      note="Applied only when the irradiance file includes air temperature.")
field("Solar PV", "pv_noct", "Nominal operating cell temperature", 45, 30, 60, "C",
      note="Used by the NOCT model: cell temperature = air + (NOCT - 20)/800 x irradiance. Typical 42-48 C.")
field("Solar PV", "pv_tilt", "Array tilt (GHI uploads)", 30, 0, 90, "degrees",
      note="Only used to transpose GHI to plane of array. Ignored for POA files and unit PV profiles.")
field("Solar PV", "pv_azimuth", "Array azimuth (GHI uploads)", 180, 0, 360, "degrees from north",
      note="180 = south-facing (northern hemisphere). Only used when transposing GHI.")
field("Solar PV", "pv_latitude", "Site latitude (GHI uploads)", 34.0522, -90, 90, "degrees",
      note="Los Angeles by default. Only used to transpose GHI.")
field("Solar PV", "pv_longitude", "Site longitude (GHI uploads)", -118.2437, -180, 180, "degrees")
field("Solar PV", "pv_utc_offset", "Timestamp UTC offset (GHI uploads)", -8, -12, 14, "hours",
      note="Local standard time of the file (no daylight saving), e.g. -8 for Pacific.")
field("Solar PV", "solar_land_enabled", "Enforce solar land limit", False, kind="checkbox")
field("Solar PV", "solar_acres", "Land available for solar", 0, unit="acres")
field("Solar PV", "solar_acres_per_mw", "Solar total site footprint", 0, unit="acres/MW",
      note="Enter a site layout factor including spacing and setbacks when enforcing land.")
field("BESS", "bess_power_capex", "Power-component capital cost", 400000, unit="$/MW",
      note="Enter inverter/power-system cost per MW of charge/discharge power. Do not include costs already assigned to the energy component.")
field("BESS", "bess_energy_capex", "Energy-component capital cost", 250000, unit="$/MWh",
      note="Enter battery-cell/module and energy-storage cost per nameplate MWh, not the price of charging electricity. Total BESS CAPEX = MW times power cost + MWh times energy cost. Avoid double-counting an all-in vendor quote.")
field("BESS", "bess_fom_fraction", "Annual maintenance incl. augmentation", .025, 0, 1, "fraction of CAPEX")
pf_fields("BESS", "bess")
field("BESS", "bess_throughput_cost", "Cycling/degradation cost", 5, 0, 1000, "$/MWh discharged",
      note="Enter the battery wear cost per MWh discharged (replacement cost spread over lifetime throughput). It is escalated with inflation, added to OPEX and discourages cycling for negligible savings. Enter 0 to disable.")
field("BESS", "round_trip_efficiency", "Round-trip efficiency", .85, .01, 1, "fraction",
      note="Charging is an additional hourly load. Its grid energy/tariff or generator fuel, variable maintenance and carbon costs are paid by the supplying source, including storage losses. Do not add the same charging bill again as separate OPEX.")
field("BESS", "duration_min", "Minimum nameplate duration", 2, .1, 100, "hours")
field("BESS", "duration_max", "Maximum nameplate duration", 8, .1, 100, "hours")
field("BESS", "soc_min", "Minimum state of charge", .1, 0, .5, "fraction")
field("BESS", "soc_max", "Maximum state of charge", .9, .5, 1, "fraction")
field("BESS", "daily_cycles", "Maximum usable equivalent cycles/day", 1, 0, 10, "cycles")
field("BESS", "bess_land_enabled", "Enforce BESS land limit", False, kind="checkbox")
field("BESS", "bess_acres", "Land available for BESS", 0, unit="acres")
field("BESS", "bess_acres_per_mw", "Additional power-system footprint", 0, unit="acres/MW",
      note="Land >= acres/MW * power + acres/MWh * energy. Include all site allowances without double counting.")
field("BESS", "bess_acres_per_mwh", "Battery site footprint per energy", 0, unit="acres/MWh",
      note="At least one BESS footprint must be positive when enabled. Use vendor/site layout; no footprint is assumed.")
for label, tech in model.PATHWAYS[1:]:
    defaults = model.TECH[tech]
    new_fuel = tech in ("diesel", "biogas", "biomass")
    field(label, tech + "_capex", "Installed capital cost", defaults["capex"], unit="$/MW",
          note="" if new_fuel else "Screening default; replace with a vendor quote (EPA CHP catalog and NREL ATB give reference ranges).")
    field(label, tech + "_fom_fraction", "Annual fixed maintenance",
          defaults["fom"] / defaults["capex"] if defaults["capex"] else 0, 0, 1, "fraction of installed CAPEX")
    field(label, tech + "_vom", "Variable maintenance", defaults["vom"], unit="$/MWh")
    pf_fields(label, tech)
    field(label, tech + "_fuel_price", "Delivered fuel price", 0 if new_fuel else 6 if tech.startswith("h2") else 8,
          unit="$/kg H2" if tech.startswith("h2") else "$/MMBtu HHV")
    electric = .35 if tech.startswith("h2") else (.28 if tech.endswith("chp") else .30)
    field(label, tech + "_efficiency", "Net electrical efficiency", 0 if new_fuel else electric,
          0 if new_fuel else .01, 1, "fraction",
          "Enter project data on the same HHV basis as fuel pricing." if new_fuel else
          "Net electrical efficiency on a hydrogen lower-heating-value (LHV) basis." if tech.startswith("h2") else
          "Net electrical efficiency on a natural gas higher-heating-value (HHV) basis.")
    if new_fuel:
        field(label, tech + "_confirmed", "Confirm project-specific cost, efficiency and emissions inputs", False,
              kind="checkbox", note="No engineering defaults are assumed for this fuel. Enter installed CAPEX, maintenance, delivered $/MMBtu HHV, net efficiency, and an emissions factor under Carbon emissions. Zero-filled inputs are not approved estimates. Biomass/biogas are not automatically carbon-neutral; enter the inventory boundary you intend to model.")
    if tech.endswith("chp"):
        field(label, tech + "_heat_efficiency", "Recoverable thermal efficiency",
              .40 if tech.startswith("h2") else .41, 0, 1, "fraction")
    tc_min, tc_ramp, tc_start = TC_DEFAULTS[tech]
    field(label, tech + "_tc_enabled", "Enable operating constraints (min load, ramp, start-up)", False, kind="checkbox",
          note="Off by default. When on, the optimizer applies a relaxed unit commitment for this technology (solves slower). Defaults are typical screening values (NREL cycling-cost studies, OEM datasheets); replace with vendor data.")
    field(label, tech + "_min_load", "Minimum stable load", tc_min, 0, 1, "fraction of rating")
    field(label, tech + "_ramp", "Ramp limit", tc_ramp, .01, 1, "fraction of rating/hour")
    field(label, tech + "_startup", "Start-up cost", tc_start, 0, 100000, "$/MW per start")
field("Wind", "wind_capex", "Installed capital cost", 1800000, unit="$/MW",
      note="Screening input, not a supplier quote. Enter turbine and installation cost excluding separately modeled connection costs.")
field("Wind", "wind_fom_fraction", "Annual fixed maintenance", .025, 0, 1, "fraction of CAPEX")
pf_fields("Wind", "wind")
field("Wind", "wind_vom", "Variable maintenance", 0, unit="$/MWh")
field("Wind", "wind_derate", "Wind retained-output derate", 1, .001, 1, "fraction")
field("Wind", "wind_degradation", "Annual output degradation", 0, 0, .1, "fraction")
field("Wind", "wind_land_enabled", "Enforce wind land limit", False, kind="checkbox")
field("Wind", "wind_acres", "Land available for wind", 0, unit="acres")
field("Wind", "wind_acres_per_mw", "Total wind site footprint", 0, unit="acres/MW")
field("Thermal load", "thermal_enabled", "Include thermal demand and CHP heat benefit", False, kind="checkbox",
      note="Keep off when there is no verified useful thermal demand. Off forces heat and heat credit to zero, including embedded heat columns.")
field("Thermal load", "thermal_profile_enabled", "Upload hourly useful thermal load", False, kind="checkbox")
field("Thermal load", "heat_mean", "Constant useful thermal demand when no profile is used", 5, unit="MW thermal")
field("Thermal load", "boiler_efficiency", "Displaced boiler efficiency", .8, .01, 1, "fraction")
field("Thermal load", "boiler_fuel_price", "Displaced boiler fuel price", 8, unit="$/MMBtu HHV")
field("Financial", "inflation", "Annual nominal escalation", .03, 0, .5, "fraction")
field("Financial", "discount", "Annual nominal discount", .06, 0, .5, "fraction")
field("Financial", "extended_appraisal", "Appraise beyond the load forecast horizon", True, kind="checkbox",
      note="Repeat the final forecast-year gross load by calendar, reapply planned commissioning and solar aging, and redispatch tail years. These modeled tail years enter the optimized NPC, not just the financial report.")
field("Financial", "appraisal_years", "Financial appraisal period", 25, 1, 40, "years")
field("Financial", "include_replacements", "Include scheduled equipment replacements", True, kind="checkbox")
for key, label, default in (("pv_life", "Solar economic replacement life", 30),
                            ("wind_life", "Wind economic replacement life", 25),
                            ("bess_life", "BESS economic replacement life", 15),
                            ("generator_life", "Generator economic replacement life", 25),
                            ("grid_life", "Grid upgrade replacement life", 40)):
    field("Financial", key, label, default, 1, 100, "years",
          "Screening service life, not a vendor warranty. Replace with project specifications.")
field("Financial", "cost_basis", "Cost basis of generation $/MW inputs", unit_pf.DEFAULT_BASIS, kind="select", options=unit_pf.COST_BASES,
      note=unit_pf.BASIS_NOTE + " Applies to PV, wind, generator and BESS power capex, fixed maintenance and replacement; BESS $/MWh energy cost is unchanged.")
field("Financial", "replacement_fraction", "Replacement cost / original equipment CAPEX", 1, 0, 2, "fraction",
      "Conservative like-for-like equipment replacement, escalated at inflation at each service-life boundary. No invented tax credits, financing, incentives or resale revenue.")
field("Financial", "currency_code", "Currency for entering and reading costs", currency.DEFAULT_CODE, kind="select", options=currency.options(),
      note="The model always solves in US dollars. Costs are typed and shown in this currency and converted to USD with the exchange rate below before solving. NPV scales with the rate; IRR and payback do not.")
field("Financial", "currency_rate", "Exchange rate (selected currency per 1 USD)", 1, 1e-6, 1e9, "per USD",
      "Indicative rate, update before use. Changing the currency loads an approximate rate; type your own to override it. Correcting the rate keeps the amounts you typed and changes their USD equivalent.")
field("Carbon emissions", "carbon_price", "Direct combustion CO2 price", 100, unit="$/tonne CO2",
      note="Paid allowance costs do not reduce physical emissions. Grid and upstream H2 emissions are reported but not charged again here.")
field("Carbon emissions", "grid_emissions_t_mwh", "Grid supply emissions factor", .20, 0, 5, "t CO2e/MWh",
      "Analyst screening placeholder 0.20, NOT a verified SCE/Constellation or eGRID value. Replace with supplier/eGRID factor; delivery losses and future decarbonization not assumed. Method: https://www.epa.gov/egrid")
field("Carbon emissions", "h2_emissions_kgco2_kg", "Hydrogen upstream emissions", 11, 0, 100, "kg CO2e/kg H2",
      "Screening unabated natural-gas H2: midpoint of IEA 10-12 kg CO2e/kg H2 cradle-to-gate range, not green-H2 certification; delivery beyond plant gate excluded. https://www.iea.org/reports/global-hydrogen-review-2024/ghg-emissions-of-hydrogen-and-its-derivatives")
field("Carbon emissions", "emission_factors_confirmed", "Use entered screening factors for supply totals", True, kind="checkbox",
      note="Totals are conditional estimates, not measured site emissions. Uncheck if factors are unknown: supply totals become unavailable, direct gas CO2 remains visible.")
field("Carbon emissions", "ng_emissions_t_mmbtu", "Natural gas direct emissions", model.CO2_PER_MMBTU, 0, 1, "t CO2e/MMBtu HHV")
for key, label in (("diesel", "Diesel"), ("biogas", "Biogas"), ("biomass", "Biomass")):
    field("Carbon emissions", key + "_emissions_t_mmbtu", label + " fuel emissions", 0, 0, 5, "t CO2e/MMBtu HHV",
          "Required project-specific boundary. Enter gross or inventory-adjusted combustion CO2e explicitly. Biogenic neutrality and upstream leakage are not inferred.")
for key, label in (("pv", "Solar PV operational"), ("bess", "BESS discharge operational"),
                   ("wind", "Wind operational / committed wind")):
    field("Carbon emissions", key + "_emissions_t_mwh", label + " emissions", 0, 0, 5, "t CO2e/MWh",
          "Operational factor only. Do not assign charging-source emissions again to BESS; embodied lifecycle inventories are outside this dispatch boundary.")
field("Carbon emissions", "emissions_limit_enabled", "Enforce annual net-emissions limit", False, kind="checkbox",
      note="Hard annual limit across the entire appraisal dispatch, including grid, fuel, upstream H2 and committed renewable supply, less useful boiler heat displacement. Unserved demand remains reported; the limit does not itself guarantee adequate service.")
field("Carbon emissions", "emissions_limit_t_year", "Maximum annual net emissions", 0, 0, 1e10, "t CO2e/year")

LIMITATIONS = (
    "Use for chronological screening, not electrical design or investment certification. Upload gross demand "
    "and a unit solar profile when available. Wind requires an uploaded hourly per-MW electrical output profile. "
    "Topology allocates one-time line/substation costs; it does not enforce power-flow, losses or line ratings. "
    "Technology-owned connection costs activate with positive capacity via a mixed-integer capacity master; "
    "dispatch remains linear. Otherwise solar uses a seeded seasonal/daylight proxy, not measured "
    "site weather. Enter all-inclusive energy $/kWh and add reactive demand only when excluded from that price. "
    "Confirm month/hour bands against your contract; holidays are not classified automatically. "
    "Define eligible technologies in each scenario; zero capacity is allowed for every technology. "
    "The microgrid lower/upper bound constrains the combined rating, not every component. "
    "Enter remaining land allocations after reserving space for committed assets. Planned costs are excluded. "
    "BESS is modeled physically with monthly cyclic 50% SOC and no inter-month transfer. "
    "Islanded cases require local headroom for within-hour peaks and quarter-hour battery reserve energy; "
    "this is not a probabilistic reliability assessment. Grid-connected cases assume continuous grid availability. "
    "Unit commitment, ramping, forced outages, tax incentives, financing and primary terminal salvage are excluded. "
    "Review unserved MW/MWh before comparing costs: shortage cases are not equivalent service. "
    "The numerical shortage priority is not a cash expenditure. Confirm thermal loads before using CHP heat credits."
    " If net hourly demand is zero but a within-hour peak remains, peak-only shortages are reported separately "
    "and assigned a conservative quarter-hour energy equivalent; hourly mean balances remain unchanged."
)


def describe_range(f):
    """Human-readable allowed range of a numeric field, e.g. 'between 0 and 1 fraction' or 'at least 0 $/MW'."""
    unit = f' {f["unit"]}' if f["unit"] else ""
    if f["max"] >= 1e12:
        return f'at least {f["min"]:,.10g}{unit}'
    return f'between {f["min"]:,.10g} and {f["max"]:,.10g}{unit}'


def merge_base(request, definitions, scenarios):
    """Validate an optional base run whose other scenarios are carried into a partial re-run."""
    base = request.get("merge_from")
    if base in (None, ""):
        return None, []
    if not isinstance(base, str) or len(base) != 32 or any(c not in "0123456789abcdef" for c in base):
        raise ValueError("Invalid base run ID for merging scenario results.")
    folder = RUNS / base
    try:
        saved = read_json_retry(folder / "status.json")
    except (OSError, ValueError):
        raise ValueError("The base run to merge with was not found.") from None
    known = {d["id"] for d in definitions}
    carry = []
    for r in (saved.get("summary") or {}).get("results") or []:
        code = r.get("code")
        if (code in known and code not in scenarios and code not in carry and
                (folder / f"result_{code}.json").is_file() and (folder / f"dispatch_{code}.csv").is_file()):
            carry.append(code)
    return base, carry


def load_carried(base, code, rows):
    """Reload a saved scenario (result plus hourly dispatch) from the base run; None if it does not match this run's horizon."""
    folder = RUNS / base
    result = json.loads((folder / f"result_{code}.json").read_text(encoding="utf-8"))
    with (folder / f"dispatch_{code}.csv").open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.reader(stream)
        header = next(reader)
        table = [row for row in reader]
    if len(table) != rows:
        return None
    keys = header[6:]
    result["dispatch"] = {k: np.array([float(row[6 + i]) for row in table]) for i, k in enumerate(keys)}
    return result


import workflow


def clean_overrides(values, scenario):
    """Validated per-scenario input overrides; returns the merged values for that scenario's optimizer settings."""
    raw = scenario.get("overrides") or {}
    fields = {f["key"]: f for f in FIELDS}
    clean = {}
    for key, v in raw.items():
        f = fields.get(key)
        if f is None or not workflow.overridable(key):
            raise ValueError(f'{scenario["id"]}: input "{key}" cannot be overridden per scenario; it is shared by all scenarios.')
        if f["kind"] == "checkbox":
            if type(v) is not bool:
                raise ValueError(f'{scenario["id"]}: {f["label"]} must be true or false.')
        elif isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or not f["min"] <= v <= f["max"]:
            raise ValueError(f'{scenario["id"]}: {f["label"]} must be a number {describe_range(f)}.')
        clean[key] = v
    merged = {**values, **clean}
    if merged["microgrid_min_mw"] > merged["microgrid_max_mw"]:
        raise ValueError(f'{scenario["id"]}: microgrid minimum ({merged["microgrid_min_mw"]:g} MW) cannot exceed '
                         f'maximum ({merged["microgrid_max_mw"]:g} MW).')
    if merged["duration_min"] > merged["duration_max"] or merged["soc_min"] >= merged["soc_max"]:
        raise ValueError(f'{scenario["id"]}: check duration and state-of-charge ordering in the overrides.')
    scenario["overrides"] = clean
    return merged


def clean_workflow(raw):
    """Informational rerun context (base run, iteration, applied changes); never trusted for paths."""
    if not isinstance(raw, dict):
        return None
    base = raw.get("base_run")
    changes = raw.get("changes")
    return dict(base_run=base if isinstance(base, str) and len(base) == 32 and all(c in "0123456789abcdef" for c in base) else None,
                iteration=min(max(int(raw.get("iteration", 0)) if isinstance(raw.get("iteration", 0), (int, float)) else 0, 0), 20),
                max_iterations=3, mode="powerflow" if raw.get("mode") == "powerflow" else "apply" if raw.get("mode") == "apply" else "",
                applied_costs=clean_applied_costs(raw.get("applied_costs")),
                changes=json.loads(json.dumps(changes)) if isinstance(changes, dict) and len(json.dumps(changes)) < 20000 else {})


def clean_applied_costs(raw):
    """{scenario code: {items: [{label, cost_usd}]}} of corrections applied for this solve (charged to total NPC)."""
    out = {}
    if not isinstance(raw, dict):
        return out
    for code, entry in list(raw.items())[:50]:
        items = (entry or {}).get("items") if isinstance(entry, dict) else None
        rows = []
        for it in (items if isinstance(items, list) else [])[:40]:
            cost = it.get("cost_usd") if isinstance(it, dict) else None
            if isinstance(cost, (int, float)) and not isinstance(cost, bool) and 0 <= cost < 1e10:
                rows.append(dict(label=str(it.get("label", ""))[:120], cost_usd=float(cost)))
        if rows:
            out[str(code)[:40]] = dict(items=rows)
    return out


def validate_request(request):
    if not isinstance(request, dict) or not isinstance(request.get("values"), dict):
        raise ValueError("A values object is required.")
    supplied = dict(request["values"])
    if "pv_fom" in supplied:
        capex = supplied.get("pv_capex", 2500000)
        maintenance = supplied.pop("pv_fom")
        if capex == 0 and maintenance != 0:
            raise ValueError("Cannot convert legacy positive solar maintenance to a CAPEX fraction with zero CAPEX.")
        supplied.setdefault("pv_fom_fraction", maintenance / capex if capex else 0)
    for _, tech in model.PATHWAYS[1:]:
        if tech + "_fom" in supplied:
            supplied.setdefault(tech + "_fom_fraction", supplied.pop(tech + "_fom") /
                                max(supplied.get(tech + "_capex", model.TECH[tech]["capex"]), 1e-12))
    for old, technologies in (("gas_price", ("ng", "ng_chp")), ("hydrogen_price", ("h2", "h2_chp"))):
        if old in supplied:
            price = supplied.pop(old)
            for tech in technologies:
                supplied.setdefault(tech + "_fuel_price", price)
    known = {f["key"] for f in FIELDS}
    if set(supplied) - known - {"reference_pv"}:
        raise ValueError("Unknown input fields: " + ", ".join(sorted(set(supplied) - known - {"reference_pv"})))
    values = {}
    for f in FIELDS:
        v = supplied.get(f["key"], f["default"])
        if f["kind"] == "checkbox":
            if type(v) is not bool:
                raise ValueError(f'{f["label"]} must be true or false.')
        elif f["kind"] == "select":
            if v not in {x[0] for x in f["options"]}:
                raise ValueError(f'Invalid selection for {f["label"]}.')
        else:
            if isinstance(v, bool) or not isinstance(v, (float, int)) or not math.isfinite(v):
                raise ValueError(f'{f["label"]} must be a finite number.')
            if not f["min"] <= v <= f["max"]:
                raise ValueError(f'{f["label"]} must be {describe_range(f)}.')
        values[f["key"]] = v
    if values["target_years"] != int(values["target_years"]):
        raise ValueError("Years to target must be an integer.")
    if values["horizon_years"] != int(values["horizon_years"]):
        raise ValueError("Economic horizon (horizon_years) must be a whole number of years between 1 and 30.")
    if values["start_year"] != int(values["start_year"]):
        raise ValueError("First operating year must be an integer.")
    for key in ("appraisal_years", "pv_life", "wind_life", "bess_life", "generator_life", "grid_life"):
        if values[key] != int(values[key]):
            raise ValueError(f"{key} must be an integer.")
    if values["extended_appraisal"] and values["appraisal_years"] < values["horizon_years"]:
        raise ValueError("Financial appraisal must cover at least the load forecast horizon.")
    if values["emissions_limit_enabled"] and not values["emission_factors_confirmed"]:
        raise ValueError("Confirm emissions factors before enforcing an annual emissions limit.")
    if values["target"] < values["baseline"]:
        raise ValueError("Target must be at least baseline for this load-growth model.")
    if values["duration_min"] > values["duration_max"] or values["soc_min"] >= values["soc_max"]:
        raise ValueError("Check duration and state-of-charge minimum/maximum ordering.")
    if values["microgrid_min_mw"] > values["microgrid_max_mw"]:
        raise ValueError(
            f'Microgrid minimum ({values["microgrid_min_mw"]:g} MW) cannot exceed maximum ({values["microgrid_max_mw"]:g} MW). '
            "Raise the maximum or lower the minimum under Model inputs > Microgrid.")
    for tech in ("h2_chp", "ng_chp"):
        if values[tech + "_efficiency"] + values[tech + "_heat_efficiency"] > 1:
            raise ValueError(f"{tech}: electrical plus recovered heat efficiency cannot exceed 100%.")
    if values["solar_land_enabled"] and values["solar_acres_per_mw"] <= 0:
        raise ValueError("Supply a positive solar footprint in acres/MW to enable its land limit.")
    if values["bess_land_enabled"] and values["bess_acres_per_mw"] + values["bess_acres_per_mwh"] <= 0:
        raise ValueError("Supply a positive BESS power and/or energy footprint to enable its land limit.")
    for key in ("summer_start_month", "summer_end_month", "peak_start_hour", "peak_end_hour", "mid_start_hour", "mid_end_hour"):
        if values[key] != int(values[key]):
            raise ValueError("Tariff months and hours must be integers.")
    if values["summer_start_month"] > values["summer_end_month"]:
        raise ValueError("Summer first month must not exceed the last month.")
    if values["peak_start_hour"] >= values["peak_end_hour"] or values["mid_start_hour"] >= values["mid_end_hour"]:
        raise ValueError("Each tariff period needs a start hour before its end hour.")
    if max(values["peak_start_hour"], values["mid_start_hour"]) < min(values["peak_end_hour"], values["mid_end_hour"]):
        raise ValueError("Peak and Mid-peak hour bands cannot overlap.")
    if values["export_enabled"] and values["export_limit_mw"] <= 0:
        raise ValueError("Exports are allowed but the export limit is 0 MW. Enter a positive export limit under "
                         "Model inputs > Grid and tariff, or untick 'Allow export to grid'.")
    if values["wind_land_enabled"] and values["wind_acres_per_mw"] <= 0:
        raise ValueError("Enter a positive wind footprint when enforcing wind land.")
    definitions = scenario_inputs.validate(request.get("scenario_definitions", scenario_inputs.DEFAULTS))
    scenarios = request.get("scenarios", ["R0", "P1"])
    if not isinstance(scenarios, list) or not scenarios or any(
            s not in {x["id"] for x in definitions} for s in scenarios):
        raise ValueError("Select at least one valid scenario.")
    for technology in ("diesel", "biogas", "biomass"):
        if request.get("solve", True) and any(s["id"] in scenarios and technology in s["technologies"] for s in definitions):
            if not values[technology + "_confirmed"] or values[technology + "_capex"] <= 0 or values[technology + "_efficiency"] <= 0:
                raise ValueError(f"{technology}: enter positive equipment CAPEX and efficiency, then confirm project-specific fuel, maintenance and emissions assumptions.")
    mode = request.get("import_mode", "historical")
    if mode not in ("historical", "projected"):
        raise ValueError("Import mode must be historical or projected.")
    upload = request.get("upload_csv", "")
    if not isinstance(upload, str) or len(upload.encode("utf-8")) > 24_000_000:
        raise ValueError("CSV upload must be text no larger than 24 MB.")
    files = request.get("upload_files", [])
    if not isinstance(files, list) or any(not isinstance(f, dict) or
            not isinstance(f.get("name"), str) or not isinstance(f.get("content"), str) for f in files):
        raise ValueError("Uploaded files need name and text content.")
    if sum(len(f["content"].encode("utf-8")) for f in files) + len(upload.encode("utf-8")) > 24_000_000:
        raise ValueError("Combined CSV uploads must not exceed 24 MB.")
    if files and upload:
        raise ValueError("Use uploaded files or a CSV text input, not both.")
    profile_files = {}
    total_size = sum(len(f["content"].encode()) for f in files) + len(upload.encode())
    for key in ("historical_files", "forecast_files", "combined_files"):
        items = request.get(key, [])
        if not isinstance(items, list) or any(not isinstance(f, dict) or
                not isinstance(f.get("name"), str) or not isinstance(f.get("content"), str) for f in items):
            raise ValueError(f"{key}: files require name and text content.")
        total_size += sum(len(f["content"].encode()) for f in items)
        profile_files[key] = items
    if total_size > 24_000_000:
        raise ValueError("Combined demand uploads must not exceed 24 MB.")
    if any(profile_files.values()) and (files or upload):
        raise ValueError("Clear legacy CSV input before using separate/combined load profiles.")
    has_forecast = bool(profile_files["forecast_files"] or profile_files["combined_files"] or
                        ((files or upload) and mode == "projected"))
    milestones = (planning_inputs.validate_points(request.get("milestones", planning_inputs.ANNUAL_POINTS),
                                                  int(values["start_year"]) - 1)
                  if not has_forecast and values["trajectory_mode"] == "milestones" and values["forecast_mode"] == "grow"
                  else request.get("milestones", planning_inputs.ANNUAL_POINTS))
    planned = planning_inputs.validate_projects(request.get("planned_generation", planning_inputs.PROJECTS))
    comparison_reference = request.get("comparison_reference", "R0")
    if comparison_reference not in (None, "") and comparison_reference not in {s["id"] for s in definitions}:
        if comparison_reference == "R0":
            comparison_reference = None
        else:
            raise ValueError("Select a defined scenario as the financial comparison baseline.")
    if type(request.get("solve", True)) is not bool:
        raise ValueError("solve must be true or false.")
    demand_source = request.get("demand_source", "generate")
    if demand_source not in ("upload", "generate"):
        raise ValueError("Choose uploaded forecast or generate forecast.")
    if demand_source == "upload" and not has_forecast:
        raise ValueError("Load a forecast/combined CSV under Demand, or select Generate a forecast.")
    resources = {}
    for key in ("solar_file", "planned_solar_file", "thermal_file", "wind_file"):
        item = request.get(key)
        if item is not None and (not isinstance(item, dict) or not isinstance(item.get("name"), str)
                                 or not isinstance(item.get("content"), str)):
            raise ValueError(f"{key}: upload a CSV with name and text content.")
        if item is not None:
            total_size += len(item["content"].encode())
        resources[key] = item
    if total_size > 24_000_000:
        raise ValueError("Combined demand and resource uploads must not exceed 24 MB.")
    planned_profile_enabled = request.get("planned_solar_profile_enabled", False)
    if type(planned_profile_enabled) is not bool:
        raise ValueError("Planned solar upload selection must be true or false.")
    for enabled, key in ((values["solar_profile_enabled"], "solar_file"),
                         (request.get("solve", True) and any("wind" in s["technologies"] and
                          s["id"] in scenarios for s in definitions), "wind_file"),
                         (planned_profile_enabled, "planned_solar_file"),
                         (values["thermal_enabled"] and values["thermal_profile_enabled"], "thermal_file")):
        if enabled and resources[key] is None:
            raise ValueError(f"Upload {key} or disable its profile checkbox.")
    merge_from, carry = merge_base(request, definitions, scenarios)
    for d in definitions:
        if d.get("overrides") is not None:
            clean_overrides(values, d)
    technical_check = request.get("technical_check", True)
    if type(technical_check) is not bool:
        raise ValueError("technical_check must be true or false.")
    technical_islanded = request.get("technical_islanded", False)
    if type(technical_islanded) is not bool:
        raise ValueError("technical_islanded must be true or false.")
    topology = network_topology.validate(request.get("topology"),
        [s for s in definitions if s["id"] in scenarios or s["id"] in carry])
    return dict(values=values, scenarios=list(dict.fromkeys(scenarios)), demand_source=demand_source,
                merge_from=merge_from, carry_codes=carry, technical_check=technical_check,
                technical_islanded=technical_islanded,
                workflow=clean_workflow(request.get("workflow")),
                import_mode=mode, upload_csv=upload, upload_files=files, solve=request.get("solve", True),
                milestones=milestones, planned_generation=planned, scenario_definitions=definitions,
                comparison_reference=comparison_reference or None,
                application_version=7, topology=topology, planned_solar_profile_enabled=planned_profile_enabled,
                **resources, **profile_files)


def pv_preview(payload):
    """Unit PV capacity-factor curves for an uploaded solar resource, so the irradiance-to-PV conversion is visible."""
    file = payload.get("solar_file") if isinstance(payload, dict) else None
    if not isinstance(file, dict) or not isinstance(file.get("name"), str) or not isinstance(file.get("content"), str):
        raise ValueError("Upload a solar resource CSV first.")
    given = payload.get("values") if isinstance(payload.get("values"), dict) else {}
    values = {f["key"]: f["default"] for f in FIELDS if f["group"] == "Solar PV"}
    limits = {f["key"]: (f["min"], f["max"]) for f in FIELDS if f["group"] == "Solar PV"}
    for key in values:
        if key in given and not isinstance(values[key], str):
            values[key] = planning_inputs.finite(given[key], key, *limits[key])
        elif key in given:
            values[key] = given[key]
    dates = forecasting.planning_dates(int(given.get("start_year", 2027)), 1)
    resource, audit, converted = resource_profiles.read_solar(file, dates, values)
    ratio = float(values["pv_dc_ac_ratio"]) if converted else 1.0
    retained = float(values["solar_derate"])
    out = pv_model.summary(dates, resource, retained, ratio)
    out.update(converted=converted, basis=audit["basis"], conversion=audit["conversion"], file=file["name"],
               ac_basis=(out["basis"] if converted else "Uploaded unit PV profile: MW per MW as given"))
    return out


def settings_for(v):
    cfg = model.default_settings()
    cfg["allow_unserved"] = True
    cfg["grid_only_reference"] = True
    cfg["reference_pv"] = 0
    cfg["battery_regularization_cash"] = False
    for key in cfg.keys() & v.keys():
        cfg[key] = v[key]
    cfg["solver"] = v.get("solver", "highs")
    cfg.update(pv_min=0, pv_max=v["microgrid_max_mw"], bess_power_max=v["microgrid_max_mw"],
               bess_energy_max=v["microgrid_max_mw"] * v["duration_max"],
               generator_max=v["microgrid_max_mw"], forced_generator_min=0, dc_ac=1,
               planned_netted=True)
    cfg["pv_fom"] = v["pv_capex"] * v["pv_fom_fraction"]
    if v["solar_land_enabled"]:
        cfg["pv_max"] = min(cfg["pv_max"], v["solar_acres"] / v["solar_acres_per_mw"])
    if v["bess_land_enabled"]:
        cfg["bess_land_acres"] = v["bess_acres"]
    cfg["boiler_credit"] = model.MMBTU_PER_MWH / v["boiler_efficiency"] * (
        v["boiler_fuel_price"] + v["carbon_price"] * v["ng_emissions_t_mmbtu"]) if v["thermal_enabled"] else 0
    cfg["boiler_emissions_t_mwhth"] = (
        model.MMBTU_PER_MWH / v["boiler_efficiency"] * v["ng_emissions_t_mmbtu"] if v["thermal_enabled"] else 0)
    cfg["ng_turbine_efficiency"] = v["ng_efficiency"]
    cfg["ng_chp_efficiency"] = v["ng_chp_efficiency"]
    cfg["h2_efficiency"] = v["h2_efficiency"]
    cfg["h2_chp_efficiency"] = v["h2_chp_efficiency"]
    for _, tech in model.PATHWAYS[1:]:
        spec = cfg["technology_parameters"][tech]
        for key in ("capex", "vom"):
            spec[key] = v[tech + "_" + key]
        spec["fom"] = spec["capex"] * v[tech + "_fom_fraction"]
        efficiency = v[tech + "_efficiency"]
        if efficiency == 0 and tech in ("diesel", "biogas", "biomass"):
            spec.update(fuel=0, carbon=0, emissions_t_mwh=0, ratio=0)
            continue
        gas_input = model.MMBTU_PER_MWH / efficiency
        spec["fuel"] = (v[tech + "_fuel_price"] * 1000 / (33.33 * efficiency)
                        if tech.startswith("h2") else v[tech + "_fuel_price"] * gas_input)
        factor = v[(tech if tech in ("diesel", "biogas", "biomass") else "ng") + "_emissions_t_mmbtu"]
        spec["carbon"] = 0 if tech.startswith("h2") else v["carbon_price"] * factor * gas_input
        spec["emissions_t_mwh"] = (v["h2_emissions_kgco2_kg"] / (33.33 * efficiency)
                                  if tech.startswith("h2") else factor * gas_input)
        spec["ratio"] = v[tech + "_heat_efficiency"] / efficiency if tech.endswith("chp") else 0
    tc_units = {tech: dict(min_load=v[tech + "_min_load"], ramp=v[tech + "_ramp"], startup=v[tech + "_startup"])
                for tech in TC_DEFAULTS if v.get(tech + "_tc_enabled")}
    cfg["tech_constraints"] = dict(enabled=bool(tc_units), units=tc_units)
    cfg["technology_parameters"]["wind"] = dict(capex=v["wind_capex"],
        fom=v["wind_capex"] * v["wind_fom_fraction"], vom=v["wind_vom"], fuel=0, carbon=0,
        ratio=0, emissions_t_mwh=v["wind_emissions_t_mwh"])
    cfg["wind_max"] = (min(v["microgrid_max_mw"], v["wind_acres"] / v["wind_acres_per_mw"])
                       if v["wind_land_enabled"] else v["microgrid_max_mw"])
    scale_cost_basis(cfg, v)
    return cfg


def scale_cost_basis(cfg, v):
    """Per-MVA basis: effective $/MW = entered $/MVA / pf for capex and fixed O&M (hence replacement); vom stays per MWh."""
    basis = unit_pf.basis_of(v)
    pfs = unit_pf.from_values(v)
    cfg["cost_basis"] = basis
    cfg["unit_pf"] = {t: s["pf"] for t, s in pfs.items()}
    if basis != "per_mva":
        return
    f = 1 / pfs["pv"]["pf"]
    cfg["pv_capex"] *= f
    cfg["pv_fom"] *= f
    cfg["bess_power_capex"] *= 1 / pfs["bess"]["pf"]
    for tech in [t for _, t in model.PATHWAYS[1:]] + ["wind"]:
        spec = cfg["technology_parameters"][tech]
        spec["capex"] *= 1 / pfs[tech]["pf"]
        spec["fom"] *= 1 / pfs[tech]["pf"]


def read_import(text, mode, horizon=10):
    return forecasting.imported_rows(text, [], mode, 2027, horizon)[0]


def period_calendar(rows, start_year, horizon):
    """Dates/rows for a short period modelled as-is: shifted into start_year and repeated each economic year."""
    first = rows[0][0]
    day = min(first.day, 28) if first.month == 2 else first.day
    shift = datetime(start_year, first.month, day, first.hour) - first
    base = [date + shift for date, _ in rows]
    if base[-1].year != start_year:
        raise ValueError("Data period crosses a calendar year-end. Trim the load data to one calendar year, "
                         "or tick 'Annualize data shorter than one year'.")
    dates, chosen = [], []
    for yi in range(horizon):
        for date, (_, nums) in zip(base, rows):
            try:
                dates.append(date.replace(year=start_year + yi))
            except ValueError:  # Feb 29 in a non-leap economic year
                continue
            chosen.append(nums)
    return dates, chosen


def make_data(request):
    v = request["values"]
    horizon = int(v["horizon_years"])
    start_year = int(v["start_year"])
    no_forecast = v["forecast_mode"] == "none"
    history_input, forecast_input, source_audit = planning_inputs.profile_sources(request, horizon, start_year)
    if forecast_input is not None and source_audit["forecast"].get("partial_projection"):
        if history_input is not None:
            raise ValueError("Forecast file: it must hold full calendar years starting 1 January (hourly). Upload "
                             "it as historical/representative data instead, or supply a full-year forecast.")
        history_input, history_audit = forecasting.hourly_history(forecast_input, allow_partial=True)
        forecast_input = None
        source_audit = dict(source_audit, historical=dict(source_audit.pop("forecast"), **history_audit))
        source_audit["historical"]["notes"] = ["Forecast file is not whole calendar years, so it is used as "
                                               "representative load data rather than a projection."]
    new_import = history_input is not None or forecast_input is not None
    imported = bool(request["upload_csv"] or request.get("upload_files") or new_import)
    source_hashes = {}
    history_rows = history_input
    if new_import:
        rows = forecast_input if forecast_input is not None else history_input
        audit = source_audit
        source_kind = "Separate/combined uploaded"
    elif imported:
        rows, audit = forecasting.imported_rows(request["upload_csv"], request.get("upload_files", []),
                                               request["import_mode"], start_year, horizon)
        source_kind = "Uploaded"
        if audit.get("partial_projection"):
            audit = dict(audit, projected_load_used_directly=False)
    else:
        raw = []
        for path in sorted(ROOT.glob("*Consumption*.csv")):
            raw.extend(forecasting.parse_csv(path.read_text(encoding="utf-8-sig")))
            source_hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
        if not raw:
            raise ValueError("Original historical demand files are missing. Upload a complete historical profile.")
        rows, audit = forecasting.hourly_history(raw)
        source_kind = "Original audited historical"
    projected = forecast_input is not None or (
        imported and not new_import and request["import_mode"] == "projected"
        and audit.get("projected_load_used_directly", False))
    stats_audit = (audit.get("historical") or audit.get("forecast") or audit) if new_import else audit
    full_year = bool(stats_audit.get("full_year_coverage", True))
    period_mode = no_forecast and not projected and not full_year and not v["annualize_partial"]
    if period_mode:
        if v["emissions_limit_enabled"]:
            raise ValueError("Annual emissions limit (emissions_limit_enabled) needs at least a full year of dispatch: "
                             "tick 'Annualize data shorter than one year' or switch the limit off.")
        dates, period_chosen = period_calendar(rows, start_year, horizon)
        rows = [(d, nums) for d, nums in zip(dates, period_chosen)]
    else:
        dates = forecasting.planning_dates(start_year, horizon)
    years = np.array([d.year - start_year for d in dates])
    months = np.array([d.month for d in dates])
    solar_resource = planning_inputs.synthetic_solar(dates)
    solar_age = years % int(v["pv_life"]) if v["include_replacements"] else years
    solar = solar_resource * v["solar_derate"] * (1 - v["solar_degradation"])**solar_age
    heat = np.full(len(dates), v["heat_mean"])
    trajectory = (planning_inputs.annual_trajectory(
        request.get("milestones", planning_inputs.ANNUAL_POINTS), horizon, v["milestone_interpolation"], start_year)
        if not projected and not no_forecast and v["trajectory_mode"] == "milestones" else [])
    if projected:
        chosen = [nums for _, nums in rows]
        reference_load = np.array([r["load_mw"] for r in chosen])
        scale = np.ones(len(dates))
        source_kind += " full projected hourly load used directly; growth and shape controls bypassed."
    elif no_forecast:
        if period_mode:
            chosen = [nums for _, nums in rows]
        else:
            chosen, fit_audit = forecasting.learn_shape(rows, dates, "replay")
            audit.update(fit_audit)
        reference_load = np.array([r["load_mw"] for r in chosen])
        growth = float(v["economic_growth"])
        scale = (1 + growth)**years.astype(float)
        source_kind += (" data used as-is (forecast mode: none); no growth model or peak normalization applied"
                        + (f"; economic years grow at {growth:.2%}/year." if growth else "; economic years repeat the data."))
        audit.update(growth_formula="none", economic_growth=growth)
    else:
        chosen, fit_audit = forecasting.learn_shape(rows, dates, v["shape_method"])
        audit.update(fit_audit)
        raw_max = np.array([r["load_max_mw"] for r in chosen])
        yearly_normalizer = np.array([raw_max[years == yi].max() for yi in range(horizon)])
        baseline = trajectory[0]["peak_mw"] if v["trajectory_mode"] == "milestones" else v["baseline"]
        reference_load = np.array([r["load_mw"] for r in chosen]) * baseline / yearly_normalizer[years]
        if v["trajectory_mode"] == "milestones":
            targets = np.array([p["peak_mw"] for p in trajectory])
            scale = np.zeros(len(dates))
            for yi in range(horizon):
                ids = np.flatnonzero(years == yi)
                elapsed = np.arange(1, len(ids) + 1) / len(ids)
                envelope = forecasting.forecast_peaks(elapsed, targets[yi], targets[yi + 1], 1,
                                                     v["forecast_method"])
                unnormalized = raw_max[ids] * envelope
                scale[ids] = envelope * targets[yi + 1] / unnormalized.max()
            source_kind += (" Client annual points control GROSS peaks; selected growth curve shapes the "
                            "within-year envelope, then every hourly value is normalized to its annual target. "
                            "Intermediate default red-curve readings are approximate, not client tabulated data.")
        else:
            peak = forecasting.forecast_peaks(years + 1, v["baseline"], v["target"],
                                             v["target_years"], v["forecast_method"])
            scale = peak / yearly_normalizer[years]
        source_kind += (f" data; {dict(forecasting.SHAPES)[v['shape_method']]}. "
                        f"{dict(forecasting.METHODS)[v['forecast_method']]} growth scales every hourly "
                        "mean, within-hour minimum and maximum together; not peak-only adjustment.")
        audit.update(growth_formula=forecasting.FORMULAS[v["forecast_method"]],
                     baseline_peak_mw=baseline, target_peak_mw=v["target"],
                     target_years=v["target_years"],
                     fitted_peak_normalizer_by_year=yearly_normalizer.tolist())
    load = np.array([r["load_mw"] for r in chosen]) * scale
    qmax = np.array([r.get("load_max_mw", r["load_mw"]) for r in chosen]) * scale
    qmin = np.array([r.get("load_min_mw", r["load_mw"]) for r in chosen]) * scale
    if imported:
        if "solar_per_mwdc" in chosen[0]:
            solar_resource = np.array([r["solar_per_mwdc"] for r in chosen])
            solar = solar_resource * v["solar_derate"] * (1 - v["solar_degradation"])**solar_age
            source_kind += " Imported unit solar resource is multiplied by output derate and annual degradation."
        if "heat_mwth" in chosen[0] and v["thermal_enabled"]:
            heat = np.array([r["heat_mwth"] for r in chosen])
            source_kind += " Imported thermal profile used directly; mean-heat setting bypassed."
    resource_audit = {}
    pv_converted, ratio = False, 1.0
    wind_resource = np.zeros(len(dates))
    if request.get("wind_file") is not None:
        wind_resource, resource_audit["wind"] = resource_profiles.read_wind(request["wind_file"], dates)
    wind_age = years % int(v["wind_life"]) if v["include_replacements"] else years
    wind = wind_resource * v["wind_derate"] * (1-v["wind_degradation"])**wind_age
    if v["solar_profile_enabled"]:
        solar_resource, resource_audit["solar"], pv_converted = resource_profiles.read_solar(
            request["solar_file"], dates, v)
        degradation = (1 - v["solar_degradation"])**solar_age
        if pv_converted:
            ratio = float(v.get("pv_dc_ac_ratio", 1.0))
            solar = pv_model.unit_ac(solar_resource, v["solar_derate"], degradation, ratio)
            resource_audit["solar"]["pv_summary"] = pv_model.summary(dates, solar_resource, v["solar_derate"], ratio)
        else:
            solar = solar_resource * v["solar_derate"] * degradation
        source_kind += " Separate solar resource upload applied to additional PV."
    planned_solar_resource = solar_resource.copy()
    if request.get("planned_solar_profile_enabled"):
        planned_solar_resource, resource_audit["planned_solar"], _ = resource_profiles.read_solar(
            request["planned_solar_file"], dates, v)
        source_kind += " Separate planned-solar resource applied before net-load calculation."
    if not v["thermal_enabled"]:
        heat = np.zeros(len(dates))
    elif v["thermal_profile_enabled"]:
        heat, resource_audit["thermal"] = resource_profiles.read_profile(request["thermal_file"], dates, "thermal")
    if request.get("sensitivity"):
        import sensitivity
        load, qmax, qmin, solar, solar_resource, planned_solar_resource, wind, wind_resource = sensitivity.apply_data(
            request["sensitivity"], years, horizon, load, qmax, qmin, solar, solar_resource,
            planned_solar_resource, wind, wind_resource)
    audit["resources"] = resource_audit
    audit.update(source_hashes=source_hashes)
    historical_rows = history_rows if history_rows is not None else rows
    if projected and history_rows is None:
        historical_raw = []
        for path in sorted(ROOT.glob("*Consumption*.csv")):
            historical_raw.extend(forecasting.parse_csv(path.read_text(encoding="utf-8-sig")))
        if historical_raw:
            historical_rows, _ = forecasting.hourly_history(historical_raw, allow_partial=True)
    historical_dates = forecasting.planning_dates(start_year - 1, 1)
    historical_shape, _ = forecasting.learn_shape(historical_rows, historical_dates, "replay")
    historical = dict(dates=historical_dates,
                      load=np.array([r["load_mw"] for r in historical_shape]),
                      qmax=np.array([r["load_max_mw"] for r in historical_shape]),
                      qmin=np.array([r["load_min_mw"] for r in historical_shape]),
                      note=(f"{start_year - 1} historical starting case: supplied observations reordered by month/day/hour "
                            f"onto the {start_year - 1} planning calendar, without forecast growth or peak normalization. "
                            f"Source dates: {historical_rows[0][0].date()} to {historical_rows[-1][0].date()}. "
                            "This is a calendar-mapped comparison, not a claim of measured observations on those dates. Multiple observations of "
                            "the same month/day/hour, if present, are averaged."
                            + ("" if full_year else " The supplied data cover less than a year, so uncovered "
                               "hours repeat the average weekday/hour pattern of the supplied period.")))
    tariff = planning_tariffs.tariffs(dates, v)
    data = dict(dates=dates, years=years, months=months, mi=years * 12 + months - 1,
                di=np.array([(d - dates[0]).days for d in dates]),
                load=load, qmax=qmax, qmin=qmin, solar=solar, heat=heat, wind=wind, wind_resource=wind_resource,
                solar_resource=solar_resource, planned_solar_resource=planned_solar_resource,
                pv_dc_ac_ratio=ratio if pv_converted else None,
                **tariff,
                baseline_load=reference_load, forecast_audit=audit, historical=historical)
    if v["tariff_mode"] == "blended" and v["blended_kwh"] == 0:
        source_kind += (" WARNING: blended grid energy price is $0/kWh; charging and other imports have zero "
                        "energy cost. Enabled reactive-demand charges still apply. Confirm the tariff before "
                        "using financial results; the entered zero has not been replaced.")
    data["gross_qmax"] = qmax.copy()
    if projected:
        trajectory = [dict(year=start_year - 1, peak_mw=float(historical["qmax"].max()),
                           description="Historical baseline; forecasts imported directly")] + [
            dict(year=start_year + yi, peak_mw=float(qmax[years == yi].max()),
                 description="Imported forecast (overrides annual targets)") for yi in range(horizon)]
    elif no_forecast:
        trajectory = [dict(year=start_year - 1, peak_mw=float(historical["qmax"].max()),
                           description="Data peak (no forecast)")] + [
            dict(year=start_year + yi, peak_mw=float(qmax[years == yi].max()),
                 description="Data as-is" + (f", grown {v['economic_growth']:.2%}/yr" if v["economic_growth"] else ""))
            for yi in range(horizon)]
    elif v["trajectory_mode"] == "model":
        trajectory = [dict(year=start_year - 1, peak_mw=v["baseline"], description="Model baseline")] + [
            dict(year=start_year + yi, peak_mw=float(qmax[years == yi].max()), description="Selected growth model")
            for yi in range(horizon)]
    data["annual_trajectory"] = trajectory
    warnings = []
    if not full_year:
        warnings.append(f"Load data cover {stats_audit.get('data_hours', len(rows)):,} hours (less than one year): "
                        "sizing may miss seasonal peaks and tariff seasons.")
        if period_mode:
            warnings.append("Only the data period is dispatched (not annualized); economic years repeat that period.")
        else:
            warnings.append("The short period is treated as representative and annualized by repeating its "
                            "weekday/hour pattern across the year.")
    for note in dict.fromkeys(stats_audit.get("notes", []) + audit.get("notes", [])):
        warnings.append(note)
    drive_audit = (audit.get("forecast") or stats_audit) if projected and new_import else stats_audit
    audit["data_period"] = dict(
        start=drive_audit.get("data_start", str(rows[0][0])), end=drive_audit.get("data_end", str(rows[-1][0])),
        hours=int(drive_audit.get("data_hours", len(rows))), full_year=full_year,
        resolution_minutes=int(drive_audit.get("interval_minutes", 60)),
        economic_horizon_years=horizon, forecast_mode=v["forecast_mode"] if not projected else "projected_file",
        annualized=bool(not full_year and not period_mode), dispatch_hours=len(dates), warnings=warnings)
    audit.update(annual_trajectory=trajectory, planned_generation=request.get("planned_generation", []))
    data["gross_qmin"] = qmin.copy()
    planning_inputs.planned_profiles(data, request.get("planned_generation", []), v["solar_degradation"])
    planning_inputs.apply_planned_net_load(data)
    audit["demand_audit"] = planning_inputs.audit_demand(data, reference_load if projected else None)
    source_kind += (" Planned projects have ZERO modeled costs in every scenario. Equal "
                    "January commissioning tranches across inclusive year ranges. EE scales the whole load shape; "
                    "pre-forecast EE is already in historical metering, so only incremental EE is deducted. "
                    "Planned wind uses an explicit constant capacity-factor screening profile (not firm wind). "
                    "Planned generation is deducted from gross demand before grid/microgrid dispatch; excess is "
                    "available for storage charging or curtailed. Planned BESS is physically dispatched, not a constant deduction.")
    return data, source_kind


HOURLY_COLUMNS = ["timestamp", "load_mw", "load_max_mw", "load_min_mw", "solar_per_mw", "heat_mwth",
                  "gross_load_mw", "gross_load_max_mw", "gross_load_min_mw", "efficiency_reduction_mw",
                  "planned_solar_available_mw", "planned_wind_available_mw", "planned_bess_mw", "planned_bess_mwh"]


def profile_row(data, i):
    zeros = np.zeros(1)
    def value(key):
        if key in data:
            return float(data[key][i])
        if key == "gross_load":
            return float(data["load"][i])
        if key == "gross_qmax":
            return float(data["qmax"][i])
        if key == "gross_qmin":
            return float(data["qmin"][i])
        return float(zeros[0])
    return [str(data["dates"][i])] + [float(data[k][i]) for k in (
        "load", "qmax", "qmin")] + [float(data.get("solar_resource", data["solar"])[i]), float(data["heat"][i])] + [value(k) for k in (
        "gross_load", "gross_qmax", "gross_qmin", "efficiency_reduction",
        "planned_solar_available", "planned_wind", "planned_bess_mw", "planned_bess_mwh")]


def write_historical_sheet(workbook, historical, name=None):
    name = name or f"Historical {historical['dates'][0].year}"
    sheet = workbook.create_sheet(name)
    sheet.append(["timestamp", "load_mw", "load_max_mw", "load_min_mw"])
    for i, date in enumerate(historical["dates"]):
        sheet.append([str(date)] + [float(historical[k][i]) for k in ("load", "qmax", "qmin")])
    sheet.freeze_panes = "A2"
    sheet.column_dimensions["A"].width = 23
    return sheet


def write_profile(folder, data):
    """Export every hour, plus a complete time-series plot for each operating year."""
    import matplotlib.pyplot as plt
    import plot_style; plot_style.apply()
    workbook = Workbook()
    workbook.remove(workbook.active)
    charts = []
    year_list = sorted({d.year for d in data["dates"]})
    summary = workbook.create_sheet("Annual forecast audit")
    trajectory_sheet = workbook.create_sheet("Client annual gross targets")
    trajectory_sheet.append(["Year", "Gross peak MW", "Annual increase MW", "Annual growth %", "Basis"])
    prev = None
    for point in data["annual_trajectory"]:
        peak = point["peak_mw"]
        trajectory_sheet.append([point["year"], peak, peak - prev if prev is not None else None,
                                 (peak / prev - 1) * 100 if prev else None, point["description"]])
        prev = peak
    with (folder / "client_annual_trajectory.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        extensions.SafeCsvWriter(stream).writerows(trajectory_sheet.values)
    fig, ax = plt.subplots(figsize=(11, 4))
    target_points = data["annual_trajectory"]
    ax.plot([p["year"] for p in target_points], [p["peak_mw"] for p in target_points], "o-", color="#b63e3e")
    for i, point in enumerate(target_points):
        text = f'{point["peak_mw"]:.2f} MW'
        if i:
            text += f'\n{100*(point["peak_mw"]/target_points[i-1]["peak_mw"]-1):.2f}%'
        ax.annotate(text, (point["year"], point["peak_mw"]), xytext=(0, 10), textcoords="offset points",
                    ha="center", fontsize=8)
    ax.set(title="Annual gross-demand guide (default intermediate points approximate)",
           xlabel="Year", ylabel="Annual gross peak MW")
    ax.margins(y=.3)
    ax.grid(alpha=.2)
    fig.tight_layout()
    fig.savefig(folder / "annual_gross_forecast.png", dpi=200)
    plt.close(fig)
    planned_sheet = workbook.create_sheet("Planned asset commissioning")
    if data["planned_annual"]:
        planned_sheet.append(list(data["planned_annual"][0]))
        for row in data["planned_annual"]:
            planned_sheet.append(list(row.values()))
    audit_columns = ["Year", "Hours", "Net min MW", "Net mean MW", "Net max MW",
                     "Net energy MWh", "Baseline-shape mean MW", "Mean / baseline-shape mean"]
    summary.append(audit_columns)
    historical = data["historical"]
    base_year = historical["dates"][0].year
    first_year = data["dates"][0].year
    plot_limit = max(float(data["gross_qmax"].max()), float(data["baseline_load"].max()),
                     float(historical["qmax"].max())) * 1.06
    history_sheet = write_historical_sheet(workbook, historical)
    with (folder / f"historical_load_{base_year}.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        csv.writer(stream).writerows(history_sheet.values)
    fig, ax = plt.subplots(figsize=(11, 2.9))
    ax.plot(historical["dates"], historical["qmax"], lw=.45, color="#8babc4", label="Within-hour maximum")
    ax.plot(historical["dates"], historical["load"], lw=.45, color="#c88531", label="Historical hourly mean")
    ax.set(title=f"{base_year}: historical starting case (source calendar mapped; no growth)",
           ylabel="Load (MW)", ylim=(0, plot_limit))
    ax.grid(alpha=.2)
    ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    fig.savefig(folder / f"load_{base_year}.png", dpi=200)
    plt.close(fig)
    historical_mean = float(historical["load"].mean())
    charts.append(dict(year=base_year, image=f"load_{base_year}.png", hours=len(historical["dates"]),
                       mean_mw=historical_mean, min_mw=float(historical["qmin"].min()),
                       peak_mw=float(historical["qmax"].max()), energy_mwh=float(historical["load"].sum()),
                       growth_factor=1.0, historical=True, note=historical["note"]))
    summary.append([base_year, len(historical["dates"]), float(historical["qmin"].min()),
                    historical_mean, float(historical["qmax"].max()), float(historical["load"].sum()),
                    historical_mean, 1.0])
    with (folder / "hourly_projected_load.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow(HOURLY_COLUMNS)
        for year in year_list:
            ids = np.flatnonzero(data["years"] == year - first_year)
            sheet = workbook.create_sheet(str(year))
            sheet.append(HOURLY_COLUMNS)
            for i in ids:
                row = profile_row(data, i)
                writer.writerow(row)
                sheet.append(row)
            sheet.freeze_panes = "A2"
            sheet.auto_filter.ref = sheet.dimensions
            sheet.column_dimensions["A"].width = 23
            fig, ax = plt.subplots(figsize=(11, 2.9))
            ax.plot([data["dates"][i] for i in ids], data["qmax"][ids], lw=.45,
                    color="#8babc4", label="Within-hour maximum")
            ax.plot([data["dates"][i] for i in ids], data["load"][ids], lw=.45,
                    color="#036b87", label="Net hourly mean after EE (before generation)")
            ax.plot([data["dates"][i] for i in ids], data["gross_load"][ids], lw=.35,
                    color="#b63e3e", alpha=.6, label="Gross hourly mean")
            ax.plot([data["dates"][i] for i in ids], data["baseline_load"][ids], lw=.35,
                    color="#c88531", alpha=.65, label="Baseline-year hourly shape")
            ax.set_ylim(0, plot_limit)
            ax.set(title=f"{year}: all {len(ids):,} projected planning hours", ylabel="Load (MW)")
            ax.grid(alpha=.2)
            ax.legend(loc="upper right", fontsize=8)
            fig.tight_layout()
            name = f"load_{year}.png"
            fig.savefig(folder / name, dpi=200)
            plt.close(fig)
            baseline_mean = float(data["baseline_load"][ids].mean())
            mean = float(data["load"][ids].mean())
            summary.append([year, len(ids), float(data["qmin"][ids].min()), mean,
                            float(data["qmax"][ids].max()), float(data["load"][ids].sum()),
                            baseline_mean, mean / baseline_mean if baseline_mean else None])
            charts.append(dict(year=year, image=name, hours=len(ids), mean_mw=mean,
                               min_mw=float(data["qmin"][ids].min()),
                               growth_factor=mean / baseline_mean if baseline_mean else None,
                               peak_mw=float(data["qmax"][ids].max()),
                               energy_mwh=float(data["load"][ids].sum())))
    with (folder / "annual_load_forecast.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow(audit_columns)
        writer.writerows(list(summary.values)[1:])
    extensions.protect_workbook(workbook).save(folder / "hourly_projected_load.xlsx")
    return charts


def export_results(folder, data, request, cfg, results, failures, charts, source_kind):
    import matplotlib.pyplot as plt
    import plot_style; plot_style.apply()
    forecast_horizon = int(request["values"]["horizon_years"])
    currency.activate(request["values"])
    horizon = int(data["years"].max()) + 1
    first_year = data["dates"][0].year
    year_list = range(first_year, first_year + horizon)
    generators = scenario_inputs.selected_generators(results)
    selected = set(t for r in results for t in r.get("eligible_technologies",
                   ["grid", "pv", "bess"] + list(r["caps"].get("generators_mw", {}))))
    columns = ["ID", "Scenario", "Solar MW", "BESS MW", "BESS MWh"] + [
        name + unit for _, name in generators for unit in (" MW", " MWh")] + [
               "Grid peak import MW",
               "Connection CAPEX $m", "Upfront investment $m", f"{horizon}-year cash NPC $m", "Comparable savings vs reference $m",
               "Supply adequacy", "Unserved energy MWh", "Hours with unserved load",
               "Peak hourly unserved MW", "Stress unserved MWh", "Served demand %",
               "Additional microgrid MW", "Maximum annual net emissions t CO2e", "Annual emissions limit t CO2e"]
    reference = next((r["economics"]["npc"] for r in results
                      if r["code"] == request.get("comparison_reference", "R0") and
                      r["adequacy"]["unserved_hours"] == 0), None)
    rows = [[r["code"], r["name"], *[r["caps"][k] for k in (
        "pv_dc_mw", "bess_mw", "bess_mwh")],
        *[value for tech, _ in generators for value in (
            r["caps"].get("generators_mw", {}).get(tech,
                r["caps"]["generator_mw"] if r.get("tech") == tech else 0),
            sum(a.get(tech + "_generation_mwh", a.get("gen_mwh", 0) if r.get("tech") == tech else 0)
                for a in r["economics"]["annual"]))],
        r["validation"]["max_quarter_hour_grid_mw"],
        r["economics"].get("connection_capex", 0) / 1e6,
        (r["economics"]["capex"] + r["economics"]["upgrade_pv"]) / 1e6,
        r["economics"]["npc"] / 1e6,
        (reference - r["economics"]["npc"]) / 1e6 if reference is not None and
        r["adequacy"]["unserved_hours"] == 0 and r["adequacy"]["stress_unserved_mwh"] <= 5e-5 else None,
        r["adequacy"]["status"], r["adequacy"]["unserved_mwh"], r["adequacy"]["unserved_hours"],
        r["adequacy"]["peak_unserved_mw"], r["adequacy"]["stress_unserved_mwh"],
        r["economics"]["served_fraction"] * 100, r["caps"]["microgrid_total_ac_mw"],
        max(a["net_co2e_after_heat_credit_t"] for a in r["economics"]["annual"])
        if request["values"]["emission_factors_confirmed"] else None,
        cfg["emissions_limit_t_year"] if cfg["emissions_limit_enabled"] else None] for r in results]
    excluded = {name for technology, names in (("pv", ["Solar MW"]), ("bess", ["BESS MW", "BESS MWh"]),
                                              ("grid", ["Grid peak import MW"]))
                if technology not in selected for name in names}
    retained = [i for i, name in enumerate(columns) if name not in excluded]
    columns, rows = [columns[i] for i in retained], [[row[i] for i in retained] for row in rows]
    out_columns, out_rows = currency.scale_table(columns, rows)
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Costs and capacities"
    sheet.append(out_columns)
    for row in out_rows:
        sheet.append(row)
    if not currency.is_usd():
        sheet.append([])
        sheet.append([currency.statement()])
    annual = workbook.create_sheet("Annual cashflows and energy")
    if results:
        keys = list(dict.fromkeys(k for r in results for a in r["economics"]["annual"] for k in a))
        annual.append(["Scenario"] + keys)
        for r in results:
            for a in r["economics"]["annual"]:
                annual.append([r["code"]] + [a.get(k, 0) for k in keys])
    breakdown = workbook.create_sheet("Additional generator mix")
    breakdown.append(["Scenario", "Eligible technology", "Optimized MW", "Supplied MWh"])
    for r in results:
        for tech, name in generators:
            if tech in r.get("eligible_technologies", r["caps"].get("generators_mw", {})):
                breakdown.append([r["code"], name, r["caps"].get("generators_mw", {}).get(tech, 0),
                                  sum(a.get(tech + "_generation_mwh", 0) for a in r["economics"]["annual"])])
    inputs = workbook.create_sheet("Inputs and provenance")
    inputs.append(["Category", "Input", "Value", "Unit", "Origin", "Basis"])
    for f in FIELDS:
        value = request["values"][f["key"]]
        inputs.append([f["group"], f["label"], value, f["unit"],
                       "Explicit override" if value != f["default"] else "Preloaded screening assumption",
                       f["note"] or "Existing study screening default or explicit user override; see run configuration."])
    for key in ("milestones", "planned_generation"):
        inputs.append(["Client planning", key, json.dumps(request.get(key, [])), "", "User inputs / approximate defaults",
                       "Gross targets control demand. All planned project costs excluded."])
    inputs.append(["Microgrid", "Topology", json.dumps(request.get("topology", {})), "", "User input",
                   "Connectivity and owned one-time connection CAPEX; no electrical network constraints."])
    connections = workbook.create_sheet("Connection investment")
    connections.append([currency.label("Scenario"), "Cost owner", currency.label("One-time installed cost $")])
    for result in results:
        for owner, cost in result["economics"].get("connection_cost_by_technology", {}).items():
            connections.append([result["code"], owner, currency.scaled(cost)])
    if data.get("annual_trajectory"):
        guide = workbook.create_sheet("Annual gross guide")
        guide.append(["Year", "Gross peak MW", "Basis"])
        for row in data["annual_trajectory"]:
            guide.append([row["year"], row["peak_mw"], row["description"]])
    if data.get("planned_annual"):
        plan_sheet = workbook.create_sheet("Common planned assets")
        plan_sheet.append(list(data["planned_annual"][0]))
        for row in data["planned_annual"]:
            plan_sheet.append(list(row.values()))
    resolved = workbook.create_sheet("Resolved numeric model")
    resolved.append(["Setting", "Value"])
    for key, value in cfg.items():
        resolved.append([key, json.dumps(value)])
    findings = workbook.create_sheet("Validation and failures")
    findings.append(["ID", "Status / detail"])
    for r in results:
        findings.append([r["code"], json.dumps(r["validation"])])
    for f in failures:
        findings.append([f["code"], f["error"]])
    # Keep complete demand profiles in the result workbook as well as the dedicated file.
    forecast = workbook.create_sheet("Forecast audit")
    forecast.append(["Year", "Hours", "Net minimum MW", "Net mean MW", "Net peak MW", "Net energy MWh", "Mean / baseline mean"])
    for c in charts:
        forecast.append([c["year"], c["hours"], c["min_mw"], c["mean_mw"], c["peak_mw"],
                         c["energy_mwh"], c["growth_factor"]])
    if "historical" in data:
        write_historical_sheet(workbook, data["historical"])
    for year in range(first_year, first_year + forecast_horizon):
        sheet = workbook.create_sheet(f"Load {year}")
        sheet.append(HOURLY_COLUMNS)
        for i in np.flatnonzero(data["years"] == year - first_year):
            sheet.append(profile_row(data, i))
        sheet.freeze_panes = "A2"
        sheet.column_dimensions["A"].width = 23
    with (folder / "scenario_summary.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = extensions.SafeCsvWriter(stream)
        writer.writerow(out_columns)
        writer.writerows(out_rows)
    if results:
        fig, ax = plt.subplots(figsize=(10, max(3.4, len(results) * .4)))
        ax.barh([r["code"] + (" *" if r["adequacy"]["status"] != "ALL LOAD SERVED" else "") for r in results],
                [r["economics"]["npc"] / 1e6 for r in results],
                color=["#c66b40" if r["adequacy"]["status"] != "ALL LOAD SERVED" else "#087e8b" for r in results])
        ax.invert_yaxis()
        ax.set(xlabel=f"{horizon}-year cash NPC ({first_year - 1} $million), excluding numerical shortage priority",
               title="Optimized costs (* unserved demand: not equivalent service)")
        fig.tight_layout()
        fig.savefig(folder / "cost_comparison.png", dpi=200)
        plt.close(fig)
        fig, ax = plt.subplots(figsize=(10, 4))
        for r in results:
            ax.plot(year_list, [a["net_opex"] / 1e6 for a in r["economics"]["annual"]],
                    label=r["code"])
        ax.set(xlabel="Year", ylabel="Nominal annual operating cost ($million)")
        ax.legend(ncol=4)
        ax.grid(alpha=.2)
        fig.tight_layout()
        fig.savefig(folder / "annual_costs.png", dpi=200)
        plt.close(fig)
        fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
        positions = np.arange(len(results))
        bottom = np.zeros(len(results))
        for key, label, color in (("pv_dc_mw", "Additional solar", "#e0ab32"),
                                  ("bess_mw", "BESS power", "#218ea1")):
            if ("pv" if key == "pv_dc_mw" else "bess") not in selected:
                continue
            heights = np.array([r["caps"][key] / cfg["dc_ac"] if key == "pv_dc_mw" else r["caps"][key] for r in results])
            axes[0].bar(positions, heights, bottom=bottom, label=label, color=color)
            bottom += heights
        generator_colors = dict(wind="#38a58d", h2="#77659b", h2_chp="#bd79b3", ng="#c66b40", ng_chp="#536a9b",
                                diesel="#b5893d", biogas="#34824d", biomass="#647b37")
        for tech, label in generators:
            heights = np.array([r["caps"].get("generators_mw", {}).get(tech, 0) for r in results])
            axes[0].bar(positions, heights, bottom=bottom, label=label, color=generator_colors[tech])
            bottom += heights
        axes[0].set(title="Additional optimized microgrid (common plans excluded)", ylabel="MW AC",
                    xticks=positions, xticklabels=[r["code"] for r in results])
        axes[0].legend(fontsize=8)
        bottom = np.zeros(len(results))
        for key, label, color in (("grid_mwh", "Grid", "#889fa9"),
                                  ("planned_renewable_mwh", "Planned renewables", "#53a183"),
                                  ("optimized_solar_mwh", "Microgrid solar", "#e0ab32")):
            if (key == "grid_mwh" and "grid" not in selected) or (
                    key == "optimized_solar_mwh" and "pv" not in selected):
                continue
            if key == "planned_renewable_mwh" and not np.any(data.get("planned_direct_supply", [])):
                continue
            energy = np.array([sum(a.get(key, 0) for a in r["economics"]["annual"]) / 1000 for r in results])
            axes[1].bar(positions, energy, bottom=bottom, label=label, color=color)
            bottom += energy
        for tech, label in generators:
            energy = np.array([sum(a.get(tech + "_generation_mwh", 0)
                                   for a in r["economics"]["annual"]) / 1000 for r in results])
            axes[1].bar(positions, energy, bottom=bottom, label=label, color=generator_colors[tech])
            bottom += energy
        axes[1].set(title=f"{horizon}-year supply before storage losses", ylabel="GWh",
                    xticks=positions, xticklabels=[r["code"] for r in results])
        axes[1].legend(fontsize=8)
        for ax in axes:
            ax.tick_params(axis="x", labelrotation=45)
        fig.tight_layout()
        fig.savefig(folder / "generation_mix.png", dpi=200)
        plt.close(fig)
        reliable = [r for r in results if not r["adequacy"]["unserved_hours"] and
                    r["adequacy"]["stress_unserved_mwh"] <= 5e-5]
        best = min(reliable or results, key=lambda r: (
            r["adequacy"]["unserved_mwh"] if not reliable else 0, r["economics"]["npc"]))
        last = np.flatnonzero(data["years"] == forecast_horizon - 1)
        center = last[np.argmax(data["qmax"][last])]
        ids = np.arange(max(last[0], center - 72), min(last[-1] + 1, center + 96))
        fig, ax = plt.subplots(figsize=(11, 4))
        for key, label in [("grid", "Grid"), ("pv", "Additional solar + planned surplus"),
                           *[("gen_" + tech, label) for tech, label in generators
                             if "gen_" + tech in best["dispatch"]],
                           ("discharge", "BESS discharge"), ("charge", "BESS charging"),
                           ("shortfall", "Unserved load")]:
            eligible = set(best.get("eligible_technologies", selected))
            if key == "grid" and "grid" not in eligible:
                continue
            if key in ("discharge", "charge") and "bess" not in eligible and not np.any(data.get("planned_bess_mw", [])):
                continue
            if key == "pv" and "pv" not in eligible and not np.any(data.get("planned_surplus", [])):
                continue
            ax.plot([data["dates"][i] for i in ids], best["dispatch"][key][ids], label=label)
        ax.plot([data["dates"][i] for i in ids], data["load"][ids], color="black", ls=":", label="Residual demand")
        ax.plot([data["dates"][i] for i in ids], data.get("service_load", data["load"])[ids],
                color="#8babc4", ls="--", label="Demand after efficiency (before planned supply)")
        if np.any(data.get("planned_direct_supply", [])):
            ax.plot([data["dates"][i] for i in ids], data["planned_direct_supply"][ids], label="Planned direct supply")
        ax.set(title=f"{'Lowest NPC fully supplied' if reliable else 'Lowest shortfall'} case "
               f"{best['code']}: final forecast-year peak week", ylabel="Power (MW)")
        ax.legend(ncol=3, fontsize=8)
        fig.autofmt_xdate()
        fig.tight_layout()
        fig.savefig(folder / "peak_dispatch.png", dpi=200)
        plt.close(fig)
        fig, axes = plt.subplots(2, 1, figsize=(11, 6))
        axes[0].bar([r["code"] for r in results],
                    [r["adequacy"]["unserved_mwh"] for r in results], color="#c66b40")
        axes[0].set(ylabel="Unserved energy (MWh)", title="Supply adequacy: zero means all modeled normal-profile load served")
        for r in results:
            axes[1].plot(data["dates"], np.maximum(r["dispatch"]["shortfall"],
                r["dispatch"]["peak_only_shortfall"]), lw=.6, label=r["code"])
        axes[1].set(ylabel="Hourly unserved demand (MW)", xlabel="Planning date")
        axes[1].legend(ncol=6, fontsize=8)
        fig.tight_layout()
        fig.savefig(folder / "unserved_load.png", dpi=200)
        plt.close(fig)
    shortages = workbook.create_sheet("Hourly unserved load")
    shortage_columns = ["timestamp", "net_load_mw"] + [
        r["code"] + suffix for r in results for suffix in ("_mean_unserved_mw", "_peak_only_unserved_mw")]
    shortages.append(shortage_columns)
    with (folder / "hourly_unserved_load.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow(shortage_columns)
        for i, date in enumerate(data["dates"]):
            row = [str(date), float(data["load"][i])] + [
                float(r["dispatch"][key][i]) for r in results for key in ("shortfall","peak_only_shortfall")]
            writer.writerow(row)
            if date.year < first_year + forecast_horizon:
                shortages.append(row)
    extensions.protect_workbook(workbook).save(folder / "generation_results.xlsx")
    doc = Document()
    doc.add_heading("Generation mix optimization", 0)
    doc.add_paragraph(f"Generated by {version.label()}.")
    doc.add_paragraph(f"Run {folder.name}; {first_year}-{first_year + horizon - 1}; {horizon} operating years; "
                      f"{len(data['load']):,} planning hours; cost base end-{first_year - 1}. {source_kind}")
    doc.add_paragraph(
        f"Explicit load forecast: {forecast_horizon} years. Lifecycle appraisal dispatch: {horizon} years. "
        "Any years beyond the forecast repeat its final calendar-year gross-load/resource/thermal pattern, "
        "then physically redispatch after commissioning and degradation. This is an extrapolation, not "
        "an extended customer forecast. All fixed maintenance escalates annually with inflation. "
        "Configured equipment replacements are discounted cash expenses in the optimized NPC.")
    doc.add_paragraph("The workbook's hourly load and unserved sheets cover the explicit forecast. "
                      "Dispatch CSVs and hourly_unserved_load.csv cover every appraisal dispatch hour.")
    doc.add_paragraph(LIMITATIONS)
    doc.add_heading("Client annual guide and planned generation", 1)
    doc.add_paragraph(
        "Client gross target is not the sum of project additions. Default intermediate points are approximate "
        "chart readings, not measured or tabulated forecasts. Hourly shapes follow each controlling annual peak; "
        "the selected growth model shapes a within-year envelope and all mean/min/max values are normalized together. "
        "Historical observations remain unscaled. Imported forecasts override annual targets and are treated as gross. "
        "EE reduces demand proportionally; pre-forecast tranches are assumed embedded in the metered baseline. "
        "Planned projects commission in equal January tranches across the inclusive year range and persist. "
        "Planned solar uses unit hourly resource times its own derate and degradation by commissioning vintage. Planned wind is an "
        "explicit constant-CF sensitivity, not validated hourly weather or firm wind capacity. Planned BESS is "
        "pooled with optimized BESS using the same operational parameters, and is not a constant load offset. "
        "All planned costs are excluded, including the parking solar PPA; this is not a full-site investment analysis. "
        "Planned renewable generation supplies gross load first; its surplus is available for battery charging or "
        "curtailment. The remaining net load is supplied by the grid and additional microgrid. "
        "Only additional microgrid and upgrade/import decisions are costed. Optimized assets are available in "
        "the first operating year. Land limits cover additional assets only.")
    doc.add_paragraph(
        "Enter all-inclusive energy prices in $/kWh. Select blended or seasonal TOU. No delivery, fixed-customer, "
        "real-power demand or additional energy tax is added to these prices. Only the enabled reactive-demand "
        "charge is separately added. All operating prices escalate once with the selected inflation rate.")
    for key in ("milestones", "planned_generation"):
        doc.add_paragraph(f"{key}: {json.dumps(request.get(key, []))}")
    if (folder / "annual_gross_forecast.png").exists():
        doc.add_picture(str(folder / "annual_gross_forecast.png"), width=Inches(6.3))
    doc.add_paragraph("Cash NPC does not include the numerical shortage priority. A lower-cost case with "
                      "unserved demand is not an equivalent-service saving. Savings are withheld for such cases.")
    doc.add_heading("Optimized scenarios", 1)
    word_columns = [name for name in ["ID", "Solar MW", "BESS MW", "BESS MWh",
                    "Grid peak import MW", f"{horizon}-year cash NPC $m", "Supply adequacy"] if name in columns]
    word_indices = [columns.index(name) for name in word_columns]
    table = doc.add_table(rows=1, cols=len(word_columns))
    table.style = "Light Shading Accent 1"
    for cell, text in zip(table.rows[0].cells, word_columns):
        cell.text = text
    for row in rows:
        for cell, value in zip(table.add_row().cells, [row[i] for i in word_indices]):
            cell.text = f"{value:.3f}" if isinstance(value, float) else str(value if value is not None else "N/A")
    if generators:
        doc.add_heading("Named generator contributions", 2)
        names = ["ID"] + [name + unit for _, name in generators for unit in (" MW", " MWh")]
        generator_table = doc.add_table(rows=1, cols=len(names))
        generator_table.style = "Light Shading Accent 1"
        for cell, name in zip(generator_table.rows[0].cells, names):
            cell.text = name
        for row in rows:
            for cell, name in zip(generator_table.add_row().cells, names):
                value = row[columns.index(name)]
                cell.text = f"{value:.3f}" if isinstance(value, float) else str(value)
    doc.add_paragraph("BESS charging is an additional hourly load. Charging energy and losses are already "
                      "paid in grid purchases or the supplying generator's fuel, variable maintenance and carbon "
                      "costs; renewable capital/maintenance is also included for additional assets. Adding this "
                      "same charging expenditure again to BESS OPEX would double-count it. Planned-asset costs "
                      "remain excluded. Battery energy-component CAPEX buys nameplate MWh, not charging electricity.")
    doc.add_paragraph("Grid peak import MW is the maximum modeled within-hour grid import over the "
                      "normal planning horizon, including the demand variation margin. It is actual "
                      "modeled usage, not the interconnection rating or average grid supply.")
    for r in results:
        a = r["adequacy"]
        if r.get("solver"):
            doc.add_paragraph(f"{r['code']} solving method and numerical settings: {json.dumps(r['solver'])}")
        doc.add_paragraph(f"{r['code']} additional generator capacities MW: "
                          f"{json.dumps(r['caps'].get('generators_mw', {}))}. "
                          "Eligible technologies can receive zero investment if uneconomic.")
        doc.add_paragraph(f"{r['code']}: {a['status']}; {a['unserved_mwh']:,.3f} MWh unserved; "
                          f"{a['unserved_hours']:,} affected hours; peak hourly shortfall {a['peak_unserved_mw']:.3f} MW; "
                          f"stress-month unserved energy {a['stress_unserved_mwh']:.3f} MWh.")
        if r["code"] == "R0":
            doc.add_paragraph(f"Grid upgrade capacity automatically resolved to "
                              f"{a['reference_grid_limit_mw']:.3f} MW. No additional microgrid; common planned projects still apply. Upgrade cost "
                              "is the supplied lump-sum screening estimate, not an engineering cost curve.")
    for f in failures:
        doc.add_paragraph(f"{f['code']} did not produce a validated feasible solution: {f['error']}")
    for image in ("cost_comparison.png", "generation_mix.png", "annual_costs.png", "peak_dispatch.png",
                  "unserved_load.png"):
        if (folder / image).exists():
            doc.add_picture(str(folder / image), width=Inches(6.3))
    doc.add_heading("Formulation and solution", 1)
    for text in [
        f"Demand trajectory source: {request['values']['trajectory_mode']}. "
        f"Growth method: {request['values']['forecast_method']}; "
        f"{forecasting.FORMULAS[request['values']['forecast_method']]}. "
        "u=y/H until H, then u=1. B=baseline MW, T=target MW, H=years to target, y=elapsed years. "
        "Historical shape is learned by month/weekday/hour means or replayed by month/day/hour. "
        "In baseline/target mode every hourly mean, minimum and maximum is multiplied by P(y)/fitted-year peak. "
        "In client milestone mode P(y) instead interpolates within each year between the previous and current "
        "annual anchors; normalize the resulting fitted hourly maximum to the current year's target. "
        "Do not overwrite the client targets with the ten-year model endpoint. "
        "baseline overlay uses B/fitted-year peak. Future calendar composition can change annual energy. "
        "Projected imports bypass this calculation. This is conditional shape-based forecasting, not a "
        "weather/electrification model or a statistically proven long-term trend.",
        "Minimize upfront CAPEX plus sum over operating years of net operating cost times "
        "(1+inflation)^y/(1+discount)^y. OPEX includes grid energy and monthly demand charges, "
        "fuel, fixed and variable maintenance and direct-carbon allowance, less contemporaneous useful heat credit. "
        "Add scheduled like-for-like replacements at entered service-life boundaries; their nominal "
        "cost is original equipment CAPEX times replacement fraction times annual inflation.",
        "Every hour: grid + PV + generator + battery discharge - charge + unserved = hourly load. "
        "0 <= unserved <= hourly load; unserved demand follows the within-hour demand shape proportionally. "
        "Let f=unserved/load (zero if load is zero). Grid peak = grid+(max-mean)*(1-f); "
        "grid minimum = grid-(mean-min)*(1-f). Enforce grid peak <= selected limit and minimum >=0. "
        "Reference automatically upgrades to full-load capacity and forbids shortages; alternatives do not "
        "upgrade. Renewable dispatch <= optimized solar MW * derated availability + planned surplus. "
        "Islanded scenarios forbid imports; generator headroom plus battery reserve must cover the "
        "within-hour net peak margin, with a quarter-hour battery reserve-energy requirement.",
        "Battery SOC(t)=SOC(t-1)+sqrt(RTE)*charge-discharge/sqrt(RTE). SOC is bounded by selected "
        "fractions of nameplate energy and starts/ends every month at 50%. Discharge per day <= "
        "cycles*(SOCmax-SOCmin)*nameplate MWh*sqrt(RTE). Duration min*MW <= MWh <= duration max*MW.",
        "Solar land: installed MW*acres_per_MW <= solar acres. BESS land: MW*acres_per_MW "
        "+ MWh*acres_per_MWh <= BESS acres. All footprints must be explicitly supplied if enabled. "
        "The upgraded-grid reference has no ADDITIONAL PV or BESS; common planned assets remain. "
        "Additional microgrid MW = solar MW + BESS discharge MW + all eligible generator MW; "
        "enforce the entered lower/upper limits (default 8 and 10). This is nameplate, not firm continuous power.",
        "All CHP heat combined <= shared thermal demand; each unit's heat <= its output times "
        "thermal/electrical efficiency. "
        "Purchased hydrogen has no electrolyzer/tank model; zero stack CO2 is not a lifecycle emissions claim.",
        f"HiGHS solves {horizon if cfg['emissions_limit_enabled'] else horizon * 12} chronological "
        f"{'annual' if cfg['emissions_limit_enabled'] else 'monthly'} LP subproblems with a common-capacity master and "
        "dual supporting cuts. Monthly SOC reset restricts the optimum. Capacity objective gap tolerance is $200. "
        "Unserved energy has a $100million/MWh numerical priority, not customer VOLL or an actual expenditure; "
        "it strongly prioritizes adequacy but is not an exact lexicographic proof. It is excluded from cash NPC. "
        "Physical balances, column/row constraints and absence of simultaneous "
        "battery charging/discharging remain required; shortage itself is reported, not a solver failure.",
    ]:
        doc.add_paragraph(text)
    doc.add_paragraph(
        "If enabled, the net-emissions constraint applies separately to every appraisal operating year: "
        "grid import emissions + generator direct/upstream fuel emissions + entered solar/wind operational "
        "factors + entered BESS discharge operational factor - useful displaced-boiler emissions "
        "<= annual target. Committed renewable direct supply is counted as well. Annual dispatch blocks "
        "retain monthly SOC boundaries and monthly billing peaks, allowing exact annual aggregation "
        "rather than imposing an arbitrary monthly share. When disabled, the cap has no effect.")
    doc.add_heading("Run assumptions and explicit inputs", 1)
    for group in dict.fromkeys(f["group"] for f in FIELDS):
        doc.add_heading(group, 2)
        for f in (x for x in FIELDS if x["group"] == group):
            value = request["values"][f["key"]]
            origin = "explicit override" if value != f["default"] else "preloaded screening assumption"
            doc.add_paragraph(f'{f["label"]}: {value} {f["unit"]} ({origin}). {f["note"]}')
    doc.add_heading("Resolved constraints, costs and fuel conversions", 1)
    for key, value in cfg.items():
        doc.add_paragraph(f"{key}: {json.dumps(value)}")
    doc.add_heading("Sources and provenance", 1)
    doc.add_paragraph("Starting assumptions come from the prior audited study. Values edited in the interface "
                      "are explicit user inputs, not independently verified quotations. Exact inputs, resolved "
                      "model and source hashes are saved with this run.")
    for key, url in model.SOURCES.items():
        doc.add_paragraph(f"{key}: {url}")
    doc.add_heading("Hourly projected load, every operating year", 1)
    for chart in charts:
        if chart.get("historical"):
            doc.add_paragraph(chart["note"])
        doc.add_paragraph(f'{chart["year"]}: {chart["hours"]:,} hours; within-hour peak '
                          f'{chart["peak_mw"]:.3f} MW; {chart["energy_mwh"]:,.1f} MWh.')
        doc.add_picture(str(folder / chart["image"]), width=Inches(6.3))
    doc.save(folder / "generation_model_and_results.docx")
    return dict(columns=columns, rows=rows, failures=failures,
                horizon_years=horizon, planning_hours=len(data["load"]),
                results=[{k: v for k, v in r.items() if k != "dispatch"} for r in results])


def atomic_json(path, value):
    """Write JSON through a per-writer temporary file so concurrent writers never share or truncate it."""
    temp = path.with_name(f"{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    try:
        temp.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")
        for attempt in range(250):
            try:
                os.replace(temp, path)
                return
            except PermissionError:
                # Windows refuses the swap while a poller has the old file open.
                if attempt == 249:
                    raise
                time.sleep(.02)
    finally:
        temp.unlink(missing_ok=True)


def read_json_retry(path):
    for attempt in range(250):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (PermissionError, json.JSONDecodeError):
            if attempt == 249:
                raise
            time.sleep(.02)


def pid_alive(pid):
    """Process liveness test that is safe on Windows (os.kill(pid, 0) would terminate the process there)."""
    if os.name != "nt":
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    import ctypes
    kernel = ctypes.windll.kernel32
    kernel.OpenProcess.restype = ctypes.c_void_p
    handle = kernel.OpenProcess(0x1000, False, int(pid))      # PROCESS_QUERY_LIMITED_INFORMATION
    if not handle:
        return False
    try:
        code = ctypes.c_ulong()
        return bool(kernel.GetExitCodeProcess(ctypes.c_void_p(handle), ctypes.byref(code))) and code.value == 259
    finally:
        kernel.CloseHandle(ctypes.c_void_p(handle))


def exit_with_parent(parent_pid):
    """Stop an orphaned worker when the server that launched it dies, so no solver runs unattended."""
    def watch():
        while pid_alive(parent_pid):
            time.sleep(2)
        os._exit(3)
    threading.Thread(target=watch, daemon=True).start()


def worker(folder):
    def status(state, message, **kwargs):
        atomic_json(folder / "status.json", dict(state=state, message=message, **kwargs))
    try:
        request = validate_request(json.loads((folder / "request.json").read_text(encoding="utf-8")))
        cfg = settings_for(request["values"])
        cfg["topology"] = request["topology"]
        horizon = int(request["values"]["horizon_years"])
        first_year = int(request["values"]["start_year"])
        planning = dict(horizon_years=horizon, start_year=first_year, end_year=first_year + horizon - 1,
                        planning_hours=len(forecasting.planning_dates(first_year, horizon)))
        status("running", f"Preparing {planning['planning_hours']:,} hourly inputs and {horizon} yearly plots...",
               planning=planning)
        data, source_kind = make_data(request)
        planning["planning_hours"] = len(data["dates"])
        planning["data_period"] = data["forecast_audit"]["data_period"]
        planning["forecast_mode"] = request["values"]["forecast_mode"]
        charts = write_profile(folder, data)
        if request["solve"]:
            data = resource_profiles.extend_appraisal(data, request["values"])
        planning["appraisal_years"] = int(data["years"].max()) + 1
        planning["appraisal_dispatch_hours"] = len(data["load"])
        file_keys = ("upload_files", "historical_files", "forecast_files", "combined_files",
                     "solar_file", "planned_solar_file", "thermal_file", "wind_file")
        safe_request = {k: value for k, value in request.items() if k not in ("upload_csv", *file_keys)}
        safe_request["upload_sha256"] = hashlib.sha256(request["upload_csv"].encode()).hexdigest() if request["upload_csv"] else None
        safe_request["uploaded_files"] = [dict(name=f["name"], sha256=hashlib.sha256(
            f["content"].encode()).hexdigest()) for f in request["upload_files"]]
        safe_request["profile_file_hashes"] = {
            key: [dict(name=f["name"], sha256=hashlib.sha256(f["content"].encode()).hexdigest())
                  for f in (request[key] if isinstance(request[key], list) else
                            [request[key]] if request[key] is not None else [])] for key in file_keys[1:]}
        atomic_json(folder / "run_configuration.json",
                    dict(request=safe_request, resolved=cfg, source=source_kind,
                         application_version=7, genstudio_version=version.label(), planning=planning,
                         forecast_audit=data["forecast_audit"],
                         annual_trajectory=data["annual_trajectory"], planned_annual=data["planned_annual"],
                         planning_inputs_sha256=hashlib.sha256(Path(planning_inputs.__file__).read_bytes()).hexdigest(),
                         analysis_sha256=hashlib.sha256(Path(scenario_analysis.__file__).read_bytes()).hexdigest(),
                         scenarios_sha256=hashlib.sha256(Path(scenario_inputs.__file__).read_bytes()).hexdigest(),
                         topology_sha256=hashlib.sha256(Path(network_topology.__file__).read_bytes()).hexdigest(),
                         tariffs_sha256=hashlib.sha256(Path(planning_tariffs.__file__).read_bytes()).hexdigest(),
                         resources_sha256=hashlib.sha256(Path(resource_profiles.__file__).read_bytes()).hexdigest(),
                         lifecycle_sha256=hashlib.sha256((ROOT / "lifecycle_costs.py").read_bytes()).hexdigest(),
                         inherited_profile_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest() if SOURCE.exists() else None,
                         engine_sha256=hashlib.sha256(Path(model.__file__).read_bytes()).hexdigest(),
                         application_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                         forecasting_sha256=hashlib.sha256(Path(forecasting.__file__).read_bytes()).hexdigest(),
                         interface_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                           for p in (ROOT / "generation_ui").iterdir()
                                           if p.suffix in (".html", ".css", ".js")},
                         solver_version=model.highspy.Highs().version(), limitations=LIMITATIONS))
        results, failures = [], []
        selected = [s for s in request["scenario_definitions"] if s["id"] in request["scenarios"]]
        carried, base = [], request.get("merge_from")
        if request["solve"] and base:
            for code in request.get("carry_codes", []):
                saved_result = None
                try:
                    saved_result = load_carried(base, code, len(data["dates"]))
                except (OSError, ValueError, KeyError, IndexError):
                    pass
                if saved_result is None:
                    selected += [s for s in request["scenario_definitions"] if s["id"] == code]
                else:
                    carried.append(saved_result)
        if request["solve"]:
            for count, scenario in enumerate(selected, 1):
                code, name = scenario["id"], scenario["name"]
                scenario_base = cfg
                if scenario.get("overrides"):
                    scenario_base = settings_for(clean_overrides(request["values"], scenario))
                    scenario_base["topology"] = request["topology"]
                scenario_cfg, tech = scenario_inputs.settings(scenario_base, scenario)
                status("running", f"Solving {count}/{len(selected)}: {name} with "
                       f"{model.solver_choice(scenario_cfg)[0]}. Full hourly chronology retained.",
                       charts=charts, source=source_kind, planning=planning, annual_trajectory=data["annual_trajectory"],
                       planned_annual=data["planned_annual"])
                try:
                    result = model.solve_decomposed(data, code, name, tech,
                                                    reference=scenario["reference"], settings=scenario_cfg)
                    result["eligible_technologies"] = scenario["technologies"]
                    if scenario.get("overrides"):
                        result["overrides"] = scenario["overrides"]
                    if base:
                        result["provenance"] = dict(status="re_solved", from_run=base, note="Re-solved in this run with the current inputs.")
                    dispatch = result["dispatch"]
                    common_used = dispatch["planned_solar_used"] + dispatch["planned_wind_used"]
                    dispatch["planned_renewable"] = data["planned_direct_supply"] + common_used
                    dispatch["optimized_solar"] = dispatch["solar_output"].copy()
                    for yi, row in enumerate(result["economics"]["annual"]):
                        sel = data["years"] == yi
                        row["planned_renewable_mwh"] = float(dispatch["planned_renewable"][sel].sum())
                        row["optimized_solar_mwh"] = float(dispatch["optimized_solar"][sel].sum())
                    # Save this run's outputs only; original study paths are never modified.
                    with (folder / f"dispatch_{code}.csv").open("w", newline="", encoding="utf-8-sig") as stream:
                        writer = csv.writer(stream)
                        keys = list(result["dispatch"])
                        writer.writerow(["timestamp", "net_load_mw", "grid_peak_mw", "net_served_load_mw",
                                         "gross_load_mw", "total_served_load_mw"] + keys)
                        grid_peaks = model.dispatch_grid_peak(data, result["dispatch"], scenario_cfg)
                        writer.writerows([str(d)] + [model.clean_value(v) for v in (
                                          float(data["load"][i]), float(grid_peaks[i]),
                                          float(data["load"][i] - result["dispatch"]["shortfall"][i]),
                                          float(data["gross_load"][i]),
                                          float(data["service_load"][i] - result["dispatch"]["shortfall"][i] -
                                                .25 * result["dispatch"]["peak_only_shortfall"][i]),
                                          *[float(result["dispatch"][key][i]) for key in keys])]
                                         for i, d in enumerate(data["dates"]))
                    results.append(result)
                    atomic_json(folder / f"result_{code}.json", {k: v for k, v in result.items() if k != "dispatch"})
                except (ValueError, RuntimeError) as exc:
                    traceback.print_exc()
                    failures.append(dict(code=code, name=name, error=str(exc)))
            if carried:
                import shutil
                for result in carried:
                    code = result["code"]
                    shutil.copyfile(RUNS / base / f"dispatch_{code}.csv", folder / f"dispatch_{code}.csv")
                    result["provenance"] = dict(status="carried_over", from_run=base,
                        note=f"Unchanged result carried over from run {base}; not re-solved in this run.")
                    atomic_json(folder / f"result_{code}.json", {k: v for k, v in result.items() if k != "dispatch"})
                results.extend(carried)
                order = {s["id"]: i for i, s in enumerate(request["scenario_definitions"])}
                results.sort(key=lambda r: order.get(r["code"], 1e9))
            import workflow
            workflow.finalize(folder, request, results, lambda message: status(
                "running", message, charts=charts, planning=planning))
            status("running", "Creating Word and Excel documents and graphical outputs...", charts=charts, planning=planning)
            summary = export_results(folder, data, request, cfg, results, failures, charts, source_kind)
            atomic_json(folder / "summary.json", summary)
        files = sorted(p.name for p in folder.iterdir() if p.suffix in (".csv", ".xlsx", ".docx", ".png")
                       or p.name in ("run_configuration.json", "summary.json", "workflow.json"))
        state = "complete" if not request["solve"] or results else "failed"
        has_shortage = any(r["adequacy"]["unserved_hours"] or r["adequacy"]["stress_unserved_mwh"] > 5e-5 for r in results)
        message = ("Completed with unserved load in one or more constrained scenarios. Review adequacy results."
                   if has_shortage else "Completed. Review any scenario failures below.")
        status(state, message if state == "complete" else
               "No selected scenario produced a validated feasible solution. Review limits and solver findings.",
               charts=charts, source=source_kind, files=files, failures=failures, planning=planning,
               summary=summary if request["solve"] else None,
               annual_trajectory=data["annual_trajectory"], planned_annual=data["planned_annual"])
    except Exception as exc:
        traceback.print_exc()
        status("failed", f"{type(exc).__name__}: {exc}")


JOBS = {}
LOCK = threading.Lock()


def active_jobs():
    """Completed snapshots are ready even while their worker interpreter shuts down."""
    for job_id, proc in list(JOBS.items()):
        if proc.poll() is not None:
            continue
        try:
            if read_json_retry(RUNS / job_id / "status.json")["state"] in ("queued", "running"):
                return True
        except (OSError, ValueError, KeyError):
            return True
    return False


def with_recommendation(status, folder):
    """Attach the run's single recommendation and ranking NPC (optimizer NPC + applied corrections) to each saved result.

    Charts read these fields instead of re-deriving a winner, so they always match the Solve table and reports."""
    results = (status.get("summary") or {}).get("results")
    if status.get("state") != "complete" or not results:
        return status
    try:
        import workflow
        rec = workflow.recommendation(folder, results)
    except (OSError, ValueError, KeyError):
        return status
    summary = dict(status["summary"], recommended_code=rec["code"])
    summary["results"] = [dict(r, total_npc=rec["totals"][r["code"]], is_recommended=r["code"] == rec["code"]) for r in results]
    return dict(status, summary=summary)


def interrupted_status(saved, reason):
    """Status for a run whose worker no longer exists; completed solve results stay usable."""
    if (saved.get("summary") or {}).get("results"):
        saved.update(state="complete", analysis_error=f"Analysis interrupted: {reason}",
                     message="Analysis was interrupted. Saved solve results and inputs are preserved.")
    else:
        saved.update(state="interrupted", message=f"Run interrupted: {reason} Inputs and diagnostic files are "
                     "preserved; this is not a complete optimization result. Start a new run.")
    return saved


def run_owned_elsewhere(folder, status_path):
    """True when another live GenStudio server (different port, same Application Runs folder) owns this run."""
    try:
        owner = int((folder / "server.pid").read_text(encoding="ascii").strip())
    except (OSError, ValueError):
        # Runs from before ownership tracking: treat as live only while they are still publishing progress.
        return time.time() - status_path.stat().st_mtime < 300
    return owner != os.getpid() and pid_alive(owner)


def recover_interrupted_runs():
    """At server start, mark runs left running by a dead server as interrupted."""
    if not RUNS.is_dir():
        return []
    recovered = []
    for folder in RUNS.iterdir():
        status_path = folder / "status.json"
        if not extensions.valid_run_id(folder.name) or not status_path.is_file() or folder.name in JOBS:
            continue
        try:
            saved = read_json_retry(status_path)
            if saved.get("state") in ("queued", "running") and not run_owned_elsewhere(folder, status_path):
                for stale in folder.glob("*.tmp"):
                    stale.unlink(missing_ok=True)
                atomic_json(status_path, interrupted_status(saved, "the server stopped while it was running."))
                recovered.append(folder.name)
        except (OSError, ValueError):
            log.exception("Could not inspect run %s", folder.name)
    return recovered


def cancel_job(job_id):
    if not extensions.valid_run_id(job_id):
        raise ValueError("Invalid run ID.")
    with LOCK:
        folder = RUNS / job_id
        if not (folder / "status.json").is_file():
            raise ValueError("Saved run not found.")
        saved = read_json_retry(folder / "status.json")
        if saved["state"] not in ("queued", "running"):
            return saved
        process = JOBS.get(job_id)
        if process is None:
            if (folder / "server.pid").is_file() and run_owned_elsewhere(folder, folder / "status.json"):
                raise ValueError("This run belongs to another GenStudio server that is still running; stop it there.")
            # Left over from a previous server session: nothing this server can terminate, so release the run.
            saved = interrupted_status(saved, "it was orphaned by an earlier server session and has been released.")
            atomic_json(folder / "status.json", saved)
            return saved
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)
        # Read after joining: the worker can have published completion before exiting.
        saved = read_json_retry(folder / "status.json")
        if saved["state"] not in ("queued", "running"):
            return saved
        if (saved.get("summary") or {}).get("results"):
            saved.update(state="complete", analysis_error="Analysis stopped by user; saved solve results preserved.",
                         message="Analysis stopped by user. Saved solve results and inputs are preserved.")
        else:
            saved.update(state="cancelled", message="Run stopped by user. Inputs and diagnostic files are preserved; "
                         "this interrupted run is not a complete optimization result.")
        atomic_json(folder / "status.json", saved)
        return saved


def analysis_worker(folder):
    saved = read_json_retry(folder / "status.json")
    try:
        config = json.loads((folder / "run_configuration.json").read_text(encoding="utf-8"))
        report = scenario_analysis.publish(folder, saved["summary"]["results"],
            {**config["request"]["values"], "_comparison_reference":config["request"].get("comparison_reference", "R0")})
        saved["analysis"] = report
        saved.pop("analysis_error", None)
        saved["files"] = sorted(set(saved["files"]) | {
            "economic_analysis.xlsx", "economic_analysis.docx", "economic_analysis.csv",
            "economic_analysis.json", "lcoe_comparison.png", "economic_carbon_comparison.png"})
        saved["message"] = "Analysis complete using the saved solve assumptions. Review adequacy and financial boundaries."
    except Exception as exc:
        traceback.print_exc()
        saved["analysis_error"] = f"{type(exc).__name__}: {exc}"
        saved["message"] = "Economic analysis failed; the saved solve results are preserved. " + saved["analysis_error"]
    saved["state"] = "complete"
    atomic_json(folder / "status.json", saved)


def launch(flag, folder, log_name):
    """Start a worker interpreter for a run folder; it exits by itself if this server dies."""
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    (folder / "server.pid").write_text(str(os.getpid()), encoding="ascii")
    with (folder / log_name).open("w", encoding="utf-8") as stream:
        return subprocess.Popen([sys.executable, str(Path(__file__).resolve()), flag, str(folder),
                                 "--parent-pid", str(os.getpid())], cwd=ROOT, env=env, stdout=stream, stderr=stream)


def stop_workers():
    """Terminate workers still attached to this server and record the runs as interrupted."""
    for job_id, proc in list(JOBS.items()):
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
        try:
            status_path = RUNS / job_id / "status.json"
            saved = read_json_retry(status_path)
            if saved.get("state") in ("queued", "running"):
                atomic_json(status_path, interrupted_status(saved, "the server was shut down."))
        except (OSError, ValueError):
            log.exception("Could not record shutdown of run %s", job_id)


ASSET_TYPES = {"js": "text/javascript", "css": "text/css", "png": "image/png", "svg": "image/svg+xml"}
FILE_TYPES = {".png": "image/png", ".csv": "text/csv; charset=utf-8", ".json": "application/json",
              ".pdf": "application/pdf", ".html": "text/html; charset=utf-8", ".txt": "text/plain; charset=utf-8",
              ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
              ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"}
MAX_REQUEST_BYTES = 26_000_000
SECURITY_HEADERS = (
    ("X-Content-Type-Options", "nosniff"), ("Referrer-Policy", "no-referrer"),
    ("Cross-Origin-Resource-Policy", "same-origin"), ("X-Frame-Options", "DENY"),
    ("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; "
                                "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"))


class Handler(BaseHTTPRequestHandler):
    timeout = 120          # a stalled client cannot hold a worker thread forever
    server_version = f"GenStudio/{version.VERSION}"
    sys_version = ""

    def log_message(self, fmt, *args):
        if not self.path.startswith("/api/jobs/"):
            log.info("%s %s", self.address_string(), fmt % args)

    def send_error(self, code, message=None, explain=None):
        self.close_connection = True
        self.json_response({"error": message or self.responses.get(code, ("Error",))[0]}, code)

    def send_head(self, content_type, length, status=200, cache="no-store", extra=()):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", cache)
        for key, value in SECURITY_HEADERS + tuple(extra):
            self.send_header(key, value)
        self.end_headers()

    def send_bytes(self, body, content_type, status=200, cache="no-store", extra=()):
        self.send_head(content_type, len(body), status, cache, extra)
        self.wfile.write(body)

    def send_file(self, file, content_type):
        """Stream a result file in chunks so multi-year dispatch CSVs are never held in memory whole."""
        with file.open("rb") as stream:
            self.send_head(content_type, os.fstat(stream.fileno()).st_size)
            while chunk := stream.read(1 << 20):
                self.wfile.write(chunk)

    def send_asset(self, file, content_type):
        """Static UI files revalidate on every load via a content-hash ETag, so a stale script is never served."""
        body = file.read_bytes()
        etag = '"' + hashlib.sha256(body).hexdigest()[:24] + '"'
        if self.headers.get("If-None-Match") == etag:
            self.send_head(content_type, 0, 304, "no-cache", (("ETag", etag),))
            return
        self.send_bytes(body, content_type + "; charset=utf-8", cache="no-cache", extra=(("ETag", etag),))

    def json_response(self, value, status=200):
        try:
            body = json.dumps(value, allow_nan=False).encode()
        except (ValueError, TypeError):
            log.exception("Response could not be serialised")
            body = json.dumps({"error": "The result could not be serialised. See logs\\genstudio.log."}).encode()
            status = 500
        self.send_bytes(body, "application/json; charset=utf-8", status)

    def internal_error(self, exc):
        """Log the traceback server-side; the browser only gets a reference id."""
        ref = uuid4().hex[:8]
        log.error("Internal error %s on %s %s", ref, self.command, self.path, exc_info=exc)
        self.json_response({"error": f"Internal error ({type(exc).__name__}). Reference {ref}; see logs\\genstudio.log."}, 500)

    def local_request(self):
        port = self.server.server_port
        allowed = {f"{host}:{port}" for host in self.server.allowed_hosts}
        if self.headers.get("Host", "") not in allowed:
            self.json_response({"error": "Only local-host access is allowed."}, 403)
            return False
        origin = self.headers.get("Origin")
        if origin and origin not in {f"http://{host}" for host in allowed}:
            self.json_response({"error": "Cross-origin requests are not allowed."}, 403)
            return False
        top_navigation = (self.command == "GET" and urlparse(self.path).path == "/" and
                          self.headers.get("Sec-Fetch-Mode") == "navigate" and
                          self.headers.get("Sec-Fetch-Dest") == "document")
        if self.headers.get("Sec-Fetch-Site") in ("cross-site", "same-site") and not top_navigation:
            self.json_response({"error": "Cross-site requests are not allowed."}, 403)
            return False
        return True

    def do_PUT(self):
        self.send_error(405, "Method not allowed.")

    do_DELETE = do_PATCH = do_OPTIONS = do_PUT

    def do_GET(self):
        if not self.local_request():
            return
        path = urlparse(self.path).path
        if path == "/favicon.ico":
            self.send_response(204)
            self.send_header("Cache-Control", "max-age=86400")
            self.end_headers()
            return
        assets = {"/": ("index.html", "text/html"), "/app.js": ("app.js", "text/javascript"),
                  "/topology.js": ("topology.js", "text/javascript"),
                  "/workspace.js": ("workspace.js", "text/javascript"),
                  "/dataprep.js": ("dataprep.js", "text/javascript"),
                  "/dispatch.js": ("dispatch.js", "text/javascript"),
                  "/app.css": ("app.css", "text/css")}
        extra = re.fullmatch(r"/([A-Za-z0-9_.-]+\.(js|css|png|svg))", path)
        if path not in assets and extra and (ROOT / "generation_ui" / extra.group(1)).is_file():
            assets[path] = (extra.group(1), ASSET_TYPES[extra.group(2)])
        if path == "/api/health":
            self.json_response(dict(status="ok", product=version.PRODUCT, version=version.VERSION,
                                    build_date=version.BUILD_DATE, uptime_s=round(time.time() - STARTED, 1),
                                    busy=active_jobs()))
            return
        if path == "/api/version":
            self.json_response(dict(product=version.PRODUCT, version=version.VERSION, build_date=version.BUILD_DATE,
                                    label=version.label(), application_version=7,
                                    python=sys.version.split()[0], solver=f"HiGHS {model.highspy.Highs().version()}"))
            return
        if path.startswith("/api/x/"):
            handler = extensions.GET.get(path[len("/api/x/"):])
            if handler is None:
                self.json_response({"error": "Not found."}, 404)
                return
            try:
                result = handler(parse_qs(urlparse(self.path).query))
            except (ValueError, KeyError) as exc:
                self.json_response({"error": str(exc)}, 400)
                return
            except Exception as exc:
                self.internal_error(exc)
                return
            if isinstance(result, tuple):
                self.send_bytes(result[0], result[1])
            else:
                self.json_response(result)
            return
        if path in assets:
            name, mime = assets[path]
            self.send_asset(ROOT / "generation_ui" / name, mime)
        elif path.startswith("/load-inputs/"):
            names = {"historical_hourly_2026.csv", "customer_forecast_hourly_2027_2036.csv",
                     "combined_hourly_2026_2036.csv", "customer_annual_targets.csv",
                     "historical_and_forecast.png", "load_profiles.html"}
            name = path.rsplit("/", 1)[-1]
            if name not in names or path != "/load-inputs/" + name or not (ROOT / "Load Profile Inputs" / name).is_file():
                self.json_response({"error": "Load input file not found."}, 404)
                return
            mime = "image/png" if name.endswith(".png") else "text/html; charset=utf-8" if name.endswith(".html") else "text/csv; charset=utf-8"
            self.send_bytes((ROOT / "Load Profile Inputs" / name).read_bytes(), mime)
        elif path.startswith("/solar-inputs/"):
            name = path.rsplit("/", 1)[-1]
            if name not in {"los_angeles_solar_hourly_2025_2026.csv", "los_angeles_solar_provenance.json"} or path != "/solar-inputs/" + name:
                self.json_response({"error": "Solar resource file not found."}, 404)
                return
            file = ROOT / "Solar Profile Inputs" / name
            if not file.is_file():
                self.json_response({"error": "Solar resource has not been downloaded locally."}, 404)
                return
            self.send_bytes(file.read_bytes(), "application/json" if name.endswith(".json") else "text/csv; charset=utf-8")
        elif path == "/api/defaults":
            self.json_response(dict(fields=FIELDS, scenarios=[dict(id=s["id"], name=s["name"]) for s in scenario_inputs.DEFAULTS],
                                    limitations=LIMITATIONS, references={**model.SOURCES,
                                        "Grid emissions method (numeric screening factor not site-verified)": "https://www.epa.gov/egrid",
                                        "Hydrogen cradle-to-gate screening range": "https://www.iea.org/reports/global-hydrogen-review-2024/ghg-emissions-of-hydrogen-and-its-derivatives"},
                                    milestones=planning_inputs.ANNUAL_POINTS,
                                    planned_generation=planning_inputs.PROJECTS, application_version=7,
                                    version=dict(product=version.PRODUCT, version=version.VERSION,
                                                 build_date=version.BUILD_DATE, label=version.label()),
                                    scenario_definitions=scenario_inputs.DEFAULTS, technologies=scenario_inputs.TECHNOLOGIES))
        elif path == "/api/dispatch":
            import dispatch_view
            query = parse_qs(urlparse(self.path).query)
            job_id = query.get("run", [""])[0]
            if not extensions.valid_run_id(job_id):
                self.json_response({"error": "Invalid saved solve ID."}, 400)
                return
            try:
                data = dispatch_view.read(RUNS / job_id, query.get("scenario", [None])[0],
                                          query.get("start", [None])[0], query.get("end", [None])[0],
                                          query.get("resolution", ["auto"])[0])
                self.json_response(data)
            except (ValueError, KeyError) as exc:
                self.json_response({"error": str(exc)}, 400)
            except OSError as exc:
                self.internal_error(exc)
        elif path.startswith("/api/jobs/"):
            job_id = path.split("/")[-1]
            if not extensions.valid_run_id(job_id):
                self.json_response({"error": "Invalid run ID."}, 404)
                return
            folder = RUNS / job_id
            status_path = folder / "status.json"
            if not status_path.exists():
                self.json_response({"error": "Run not found."}, 404)
                return
            status = read_json_retry(status_path)
            proc = JOBS.get(job_id)
            if proc is None and status["state"] in ("queued", "running") and time.time() - status_path.stat().st_mtime > 300 \
                    and not run_owned_elsewhere(folder, status_path):
                status = interrupted_status(status, "no worker is attached to this server and there was no progress for 5 minutes.")
                atomic_json(status_path, status)
            if proc is not None and proc.poll() is not None and status["state"] in ("queued", "running"):
                # The worker may have published its final status between the read above and the exit check.
                status = read_json_retry(status_path)
            if proc is not None and proc.poll() is not None and status["state"] in ("queued", "running"):
                status = dict(state="failed", message=f"Worker exited unexpectedly ({proc.returncode}). See worker.log in the run folder.")
                atomic_json(status_path, status)
            self.json_response(with_recommendation(status, folder))
        elif path.startswith("/files/"):
            parts = path.split("/")
            if len(parts) != 4:
                self.json_response({"error": "Invalid file path."}, 404)
                return
            _, _, job_id, name = parts
            if not extensions.valid_run_id(job_id):
                self.json_response({"error": "Invalid run ID."}, 404)
                return
            allowed = (RUNS / job_id / "status.json")
            if not allowed.exists() or name not in read_json_retry(allowed).get("files", []):
                # Yearly charts may be available while the solver is still running.
                if name not in {f"load_{y}.png" for y in range(2019, 2116)} | {"annual_gross_forecast.png"}:
                    self.json_response({"error": "File unavailable."}, 404)
                    return
            file = RUNS / job_id / name
            mime = FILE_TYPES.get(file.suffix.lower())
            if mime is None or not file.is_file() or not extensions.inside(RUNS / job_id, file):
                self.json_response({"error": "File not found."}, 404)
                return
            self.send_file(file, mime)
        else:
            self.json_response({"error": "Not found."}, 404)

    def do_POST(self):
        if not self.local_request():
            return
        if self.path not in ("/api/jobs", "/api/analyze", "/api/milestones", "/api/summary-pdf", "/api/cancel", "/api/prepare",
                             "/api/pv-preview") and \
                not self.path.startswith("/api/x/"):
            self.json_response({"error": "Not found."}, 404)
            return
        try:
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                length = 0
            if length > MAX_REQUEST_BYTES:
                self.close_connection = True
                self.json_response({"error": f"Request is larger than the {MAX_REQUEST_BYTES // 1_000_000} MB limit."}, 413)
                return
            if length <= 0:
                raise ValueError("Request body is required.")
            if self.headers.get_content_type() != "application/json":
                raise ValueError("Content-Type must be application/json.")
            payload = json.loads(self.rfile.read(length))
            if self.path.startswith("/api/x/"):
                handler = extensions.POST.get(self.path[len("/api/x/"):])
                if handler is None:
                    self.json_response({"error": "Not found."}, 404)
                    return
                result = handler(payload if isinstance(payload, dict) else {})
                if isinstance(result, tuple):
                    self.send_bytes(result[0], result[1])
                else:
                    self.json_response(result)
                return
            if self.path == "/api/cancel":
                self.json_response(cancel_job(payload.get("id") if isinstance(payload, dict) else None))
                return
            if self.path == "/api/prepare":
                import data_prep
                if not isinstance(payload, dict):
                    raise ValueError("Invalid request.")
                options = payload.get("options") if isinstance(payload.get("options"), dict) else {}
                self.json_response(data_prep.prepare(payload.get("kind"), payload.get("files"), options))
                return
            if self.path == "/api/summary-pdf":
                import summary_pdf
                job_id = payload.get("id", "") if isinstance(payload, dict) else ""
                if not extensions.valid_run_id(job_id):
                    raise ValueError("Invalid saved solve ID.")
                folder = RUNS / job_id
                with LOCK:
                    if not (folder / "status.json").is_file():
                        raise ValueError("Saved solve not found.")
                    saved = read_json_retry(folder / "status.json")
                    if saved["state"] != "complete" or not (saved.get("summary") or {}).get("results"):
                        raise ValueError("Complete a saved solve before exporting its PDF summary.")
                    name = summary_pdf.publish(folder, saved)
                    saved["files"] = sorted(set(saved["files"]) | {name})
                    atomic_json(folder / "status.json", saved)
                self.json_response(dict(url=f"/files/{job_id}/{name}"))
                return
            if self.path == "/api/pv-preview":
                self.json_response(pv_preview(payload))
                return
            if self.path == "/api/milestones":
                if not isinstance(payload, dict) or not isinstance(payload.get("csv"), str):
                    raise ValueError("A milestone CSV text field is required.")
                baseline = planning_inputs.finite(payload.get("baseline_year", 2026), "Baseline year", 2019, 2099)
                self.json_response(dict(milestones=planning_inputs.milestone_csv(payload["csv"], int(baseline))))
                return
            if self.path == "/api/analyze":
                job_id = payload.get("id", "") if isinstance(payload, dict) else ""
                if not extensions.valid_run_id(job_id):
                    raise ValueError("Invalid saved solve ID.")
                folder = RUNS / job_id
                with LOCK:
                    if not (folder / "status.json").exists():
                        raise ValueError("Saved solve not found.")
                    saved = read_json_retry(folder / "status.json")
                    config = json.loads((folder / "run_configuration.json").read_text(encoding="utf-8"))
                    if saved["state"] != "complete" or not (saved.get("summary") or {}).get("results"):
                        raise ValueError("Complete a SOLVE with validated scenarios before ANALYZE.")
                    if config.get("application_version", 0) < 3:
                        raise ValueError("This is an older solve. Run SOLVE with the updated model before ANALYZE.")
                    if active_jobs():
                        self.json_response({"error": "Another run is active. Wait for completion."}, 409)
                        return
                    previous = dict(saved)
                    saved.update(state="running", message="Analyzing saved cashflows and emissions; dispatch is not rerun.")
                    atomic_json(folder / "status.json", saved)
                    try:
                        JOBS[job_id] = launch("--analyze", folder, "analysis_worker.log")
                    except OSError:
                        atomic_json(folder / "status.json", previous)
                        raise
                self.json_response(dict(id=job_id), 202)
                return
            request = validate_request(payload)
            # Validate uploaded data before committing an expensive job.
            if request["upload_csv"] or request["upload_files"]:
                forecasting.imported_rows(request["upload_csv"], request["upload_files"],
                                          request["import_mode"], int(request["values"]["start_year"]), int(request["values"]["horizon_years"]))
            planning_inputs.profile_sources(request, int(request["values"]["horizon_years"]), int(request["values"]["start_year"]))
            with LOCK:
                if active_jobs():
                    self.json_response({"error": "Another run is active. Wait for it to finish before submitting."}, 409)
                    return
                job_id = uuid4().hex
                folder = RUNS / job_id
                folder.mkdir(parents=True)
                try:
                    atomic_json(folder / "request.json", request)
                    atomic_json(folder / "status.json", dict(state="queued", message="Starting local model worker..."))
                    JOBS[job_id] = launch("--worker", folder, "worker.log")
                except OSError:
                    shutil.rmtree(folder, ignore_errors=True)
                    raise
            self.json_response(dict(id=job_id), 202)
        except (ValueError, TypeError) as exc:
            self.json_response({"error": str(exc)}, 400)
        except Exception as exc:
            self.internal_error(exc)


class LocalServer(ThreadingHTTPServer):
    allow_reuse_address = False
    request_queue_size = 128

    def __init__(self, address, handler, allowed_hosts=None):
        self.allowed_hosts = tuple(allowed_hosts or ("127.0.0.1", "localhost"))
        super().__init__(address, handler)

    def server_bind(self):
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()

    def handle_error(self, request, client_address):
        log.error("Unhandled error serving %s", client_address, exc_info=True)


def main():
    parser = argparse.ArgumentParser(description=f"{version.label()} - local generation planning application.")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--host", default="127.0.0.1",
                        help="interface to bind; the default accepts this computer only")
    parser.add_argument("--worker", type=Path)
    parser.add_argument("--analyze", type=Path)
    parser.add_argument("--parent-pid", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--open-browser", action="store_true")
    parser.add_argument("--version", action="version", version=version.label())
    args = parser.parse_args()
    if not 0 <= args.port <= 65535:
        parser.error("--port must be between 0 and 65535.")
    if args.parent_pid:
        exit_with_parent(args.parent_pid)
    if args.analyze:
        analysis_worker(args.analyze)
    elif args.worker:
        worker(args.worker)
    else:
        for stream in (sys.stdout, sys.stderr):
            if hasattr(stream, "reconfigure"):
                stream.reconfigure(encoding="utf-8", errors="replace")
        configure_logging()
        extensions.load_all()
        local = args.host in ("127.0.0.1", "localhost", "::1")
        if not local:
            print(f"WARNING: binding to {args.host} exposes this unauthenticated application to your network.", flush=True)
        allowed = ("127.0.0.1", "localhost") if local else ("127.0.0.1", "localhost", args.host)
        try:
            server = LocalServer((args.host, args.port), Handler, allowed)
        except OSError as exc:
            if getattr(exc, "winerror", None) not in (10048, 10013) and exc.errno not in (98, 48):
                raise
            if args.open_browser:
                from urllib.request import urlopen
                try:
                    with urlopen(f"http://127.0.0.1:{args.port}/api/health", timeout=5) as response:
                        existing = json.load(response)
                except (OSError, ValueError):
                    existing = {}
                if existing.get("product") == version.PRODUCT:
                    webbrowser.open(f"http://127.0.0.1:{args.port}")
                    print("Opened the already-running planner.")
                    return
            sys.exit(f"Port {args.port} is already in use (another GenStudio window or application). "
                     f"Close it or choose another port with --port.")
        recovered = recover_interrupted_runs()
        if recovered:
            log.warning("Marked %d run(s) interrupted by an earlier shutdown: %s", len(recovered), ", ".join(recovered))
        url = f"http://{'127.0.0.1' if local else args.host}:{args.port}"
        log.info("%s listening on %s", version.label(), url)
        print(f"{version.label()} ready: {url}", flush=True)
        if args.open_browser:
            threading.Timer(.5, webbrowser.open, args=(url,)).start()
        # SIGTERM / Ctrl+Break raise KeyboardInterrupt so workers are stopped and runs are recorded as interrupted.
        for name in ("SIGTERM", "SIGBREAK"):
            if hasattr(signal, name):
                signal.signal(getattr(signal, name), lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()
            stop_workers()
            log.info("Server stopped")


if __name__ == "__main__":
    main()
