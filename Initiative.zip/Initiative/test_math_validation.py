"""Independent validation of the optimizer.

The reference below is written only from the equations of the published formulation
(export_generic_mathematical_model.py, Sections 5-8): a single monolithic LP per instance, built
directly with scipy/HiGHS and no code shared with optimize_generation_mix. Small instances
(72 h per operating year, 1-3 years) are solved by both implementations and compared on NPC,
capacities, dispatch, energy balance and levelized cost.
"""

from datetime import datetime, timedelta
import math
import unittest

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import lil_matrix

import optimize_generation_mix as model
import scenario_analysis as finance

HOURS = 72
PEAK_START, PEAK_END = 16, 21


def make_data(years=1, growth=.04, heat=0.0, grid_price=(40., 170.), margin=(.4, .3)):
    """One 72-hour dispatch block per operating year; month index = 12 * year."""
    n = HOURS * years
    hour = np.arange(n)
    day_hour = hour % 24
    year = hour // HOURS
    base = np.where((day_hour >= PEAK_START) & (day_hour < PEAK_END), 9.0, 4.0)
    load = base * (1 + growth * year) + .5 * np.sin(hour * .37) ** 2
    resource = np.maximum(0, np.sin((day_hour - 6) * math.pi / 12))
    cloud = np.array([1., .6, .85])[(hour // 24) % 3]
    on_peak = (day_hour >= PEAK_START) & (day_hour < PEAK_END)
    return dict(
        dates=[datetime(2030, 1, 1) + timedelta(hours=int(t)) for t in hour],
        years=year, mi=year * 12, di=hour // 24, peak_window=on_peak,
        load=load, qmax=load + margin[0], qmin=load - margin[1],
        solar=resource * cloud * .85 * (1 - .005) ** year,
        heat=np.full(n, heat), grid_energy=np.where(on_peak, grid_price[1], grid_price[0]),
        facility=np.full(12 * years, 60.), tou=np.full(12 * years, 25.), fixed=np.zeros(12 * years))


def make_settings(**changes):
    """Capital costs are scaled to the 72 hours per year simulated so that investment is interior."""
    cfg = model.default_settings()
    cfg.update(grid_limit=11.5, pv_min=0., pv_max=12., bess_power_max=6., bess_energy_max=30.,
               generator_max=8., forced_generator_min=0., microgrid_min_mw=0., microgrid_max_mw=None,
               dc_ac=1., allow_unserved=False, grid_only_reference=False,
               pv_capex=1500., pv_fom=15., bess_power_capex=250., bess_energy_capex=350.)
    for spec in cfg["technology_parameters"].values():
        spec["capex"] = spec["capex"] / 1500
        spec["fom"] = spec["fom"] / 1500
    cfg.update(changes)
    return cfg


def independent_reference(data, cfg, tech="none", fixed_caps=None):
    """Solve min NPC from the documented equations; returns NPC, capacities and hourly dispatch."""
    n = len(data["load"])
    years = int(data["years"].max()) + 1
    eta = math.sqrt(cfg["round_trip_efficiency"])
    weight = np.array([((1 + cfg["inflation"]) / (1 + cfg["discount"])) ** (y + 1) for y in range(years)])
    annuity = weight.sum()
    spec = cfg["technology_parameters"][tech]
    has_gen = tech != "none"
    unit = (cfg.get("tech_constraints") or {}).get("units", {}).get(tech) if (
        cfg.get("tech_constraints") or {}).get("enabled") else None
    cursor = [0]

    def block(size):
        start = cursor[0]
        cursor[0] += size
        return np.arange(start, start + size)

    x_pv, p_b, e_b, x_g = (block(1)[0] for _ in range(4))
    g, v, c, d, e, p, heat_out, commit, start = (block(n) for _ in range(9))
    peak_cols = block(years)
    tou_cols = block(years)
    total = cursor[0]
    month_of = data["years"]
    cost = np.zeros(total)
    cost[x_pv] = cfg["pv_capex"] + cfg["pv_fom"] * annuity
    cost[p_b] = cfg["bess_power_capex"] * (1 + cfg["bess_fom_fraction"] * annuity)
    cost[e_b] = (cfg["bess_energy_capex"] * (1 + cfg["bess_fom_fraction"] * annuity) +
                 .5 / eta * data["grid_energy"][0])
    cost[x_g] = spec["capex"] + spec["fom"] * annuity
    w_h = weight[data["years"]]
    cost[g] = w_h * data["grid_energy"]
    cost[d] = w_h * model.bess_throughput_rate(cfg)
    cost[p] = w_h * (spec["fuel"] + spec["vom"] + spec["carbon"])
    cost[heat_out] = -w_h * cfg["boiler_credit"]
    if unit:
        cost[start] = w_h * unit["startup"]
    cost[peak_cols] = weight * data["facility"][::12][:years]
    cost[tou_cols] = weight * data["tou"][::12][:years]

    lower, upper = np.zeros(total), np.full(total, np.inf)
    lower[x_pv], upper[x_pv] = cfg["pv_min"], cfg["pv_max"]
    upper[p_b], upper[e_b] = cfg["bess_power_max"], cfg["bess_energy_max"]
    upper[x_g] = cfg["generator_max"] if has_gen else 0
    if fixed_caps is not None:
        for col, key in ((x_pv, "pv_dc_mw"), (p_b, "bess_mw"), (e_b, "bess_mwh"), (x_g, "generator_mw")):
            lower[col] = upper[col] = fixed_caps[key]
    margin_up, margin_dn = data["qmax"] - data["load"], data["load"] - data["qmin"]
    lower[g] = margin_dn
    upper[g] = cfg["grid_limit"] - margin_up
    upper[heat_out] = data["heat"] if has_gen and spec["ratio"] > 0 else 0
    if not unit:
        upper[commit] = upper[start] = 0

    rhs_eq, rhs_ub = [], []
    a_eq = lil_matrix((n * 2 + years, total))
    a_ub = lil_matrix((16 * n + 4 * years + 8, total))
    ne = nu = 0

    def eq(terms, rhs):
        nonlocal ne
        for col, coef in terms:
            a_eq[ne, col] += coef
        rhs_eq.append(rhs)
        ne += 1

    def ub(terms, rhs):
        nonlocal nu
        for col, coef in terms:
            a_ub[nu, col] += coef
        rhs_ub.append(rhs)
        nu += 1

    block_first = np.r_[True, np.diff(data["mi"]) != 0]
    block_last = np.r_[np.diff(data["mi"]) != 0, True]
    for t in range(n):
        eq([(g[t], 1), (v[t], 1), (p[t], 1), (d[t], 1), (c[t], -1)], data["load"][t])
        ub([(v[t], 1), (x_pv, -data["solar"][t])], 0)
        ub([(c[t], 1), (p_b, -1)], 0)
        ub([(d[t], 1), (p_b, -1)], 0)
        ub([(e[t], 1), (e_b, -cfg["soc_max"])], 0)
        ub([(e[t], -1), (e_b, cfg["soc_min"])], 0)
        ub([(p[t], 1), (x_g, -1)], 0)
        ub([(heat_out[t], 1), (p[t], -spec["ratio"])], 0)
        previous = [(e_b, -.5)] if block_first[t] else [(e[t - 1], -1)]
        eq([(e[t], 1), *previous, (c[t], -eta), (d[t], 1 / eta)], 0)
        ub([(g[t], 1), (peak_cols[month_of[t]], -1)], -margin_up[t])
        if data["peak_window"][t]:
            ub([(g[t], 1), (tou_cols[month_of[t]], -1)], -margin_up[t])
        if unit:
            ub([(commit[t], 1), (x_g, -1)], 0)
            ub([(p[t], 1), (commit[t], -1)], 0)
            ub([(commit[t], unit["min_load"]), (p[t], -1)], 0)
            if not block_first[t]:
                ub([(commit[t], 1), (commit[t - 1], -1), (start[t], -1)], 0)
                if unit["ramp"] < 1:
                    ub([(p[t], 1), (p[t - 1], -1), (x_g, -unit["ramp"]), (start[t], -1)], 0)
                    ub([(p[t - 1], 1), (p[t], -1), (x_g, -unit["ramp"]), (commit[t - 1], -1),
                        (commit[t], 1), (start[t], -1)], 0)
    if has_gen and spec["ratio"] > 0:
        for t in range(n):
            ub([(heat_out[t], 1)], data["heat"][t])
    for day in np.unique(data["di"]):
        ts = np.flatnonzero(data["di"] == day)
        ub([*[(d[t], 1) for t in ts],
            (e_b, -(cfg["soc_max"] - cfg["soc_min"]) * eta * cfg["daily_cycles"])], 0)
    for t in np.flatnonzero(block_last):
        eq([(e[t], 1), (e_b, -.5)], 0)
    ub([(x_pv, 1 / cfg["dc_ac"]), (p_b, 1), (x_g, 1)], cfg["microgrid_max_mw"] or 1e9)
    ub([(p_b, cfg["duration_min"]), (e_b, -1)], 0)
    ub([(e_b, 1), (p_b, -cfg["duration_max"])], 0)
    bounds = list(zip(lower, [None if np.isinf(u) else u for u in upper]))
    result = linprog(cost, A_ub=a_ub[:nu].tocsr(), b_ub=rhs_ub, A_eq=a_eq[:ne].tocsr(), b_eq=rhs_eq,
                     bounds=bounds, method="highs-ds",
                     options=dict(primal_feasibility_tolerance=1e-9, dual_feasibility_tolerance=1e-9))
    if not result.success:
        raise RuntimeError(result.message)
    x = result.x
    equipment = (cfg["pv_capex"] * x[x_pv] + cfg["bess_power_capex"] * x[p_b] +
                 cfg["bess_energy_capex"] * x[e_b] + spec["capex"] * x[x_g])
    return dict(npc=float(result.fun), equipment=float(equipment),
                caps=dict(pv_dc_mw=x[x_pv], bess_mw=x[p_b], bess_mwh=x[e_b], generator_mw=x[x_g]),
                grid=x[g], pv=x[v], charge=x[c], discharge=x[d], soc=x[e], gen=x[p], heat=x[heat_out],
                weight=weight)


def run_model(data, cfg, tech="none", fixed_caps=None):
    return model.solve_decomposed(data, "V", "validation", tech, settings=cfg, fixed_caps=fixed_caps)


class IndependentReferenceTests(unittest.TestCase):
    def compare(self, data, cfg, tech="none", cost_tolerance=1.0):
        ref = independent_reference(data, cfg, tech)
        # Decomposition solved freely: within its stated $200 master gap.
        free = run_model(data, cfg, tech)
        self.assertLess(abs(free["economics"]["npc"] - ref["npc"]), 250 + 1e-6 * abs(ref["npc"]))
        self.assertGreaterEqual(free["economics"]["npc"], ref["npc"] - 1e-3)
        # Same capacities: dispatch cost and every hourly quantity must agree with the reference LP.
        fixed = run_model(data, cfg, tech, fixed_caps=ref["caps"])
        self.assertAlmostEqual(fixed["economics"]["npc"], ref["npc"], delta=cost_tolerance)
        return ref, free, fixed

    def check_dispatch_physics(self, data, cfg, result):
        op = result["dispatch"]
        np.testing.assert_allclose(op["grid"] + op["pv"] + op["gen"] + op["discharge"] - op["charge"],
                                   data["load"], atol=1e-6)
        eta = math.sqrt(cfg["round_trip_efficiency"])
        previous = np.r_[.5 * result["caps"]["bess_mwh"], op["soc"][:-1]]
        previous[np.r_[True, np.diff(data["mi"]) != 0]] = .5 * result["caps"]["bess_mwh"]
        np.testing.assert_allclose(op["soc"] - previous, eta * op["charge"] - op["discharge"] / eta, atol=1e-6)

    def test_grid_only(self):
        data, cfg = make_data(years=2), make_settings(pv_max=0., bess_power_max=0., bess_energy_max=0.)
        ref, free, _ = self.compare(data, cfg)
        self.assertAlmostEqual(free["caps"]["pv_dc_mw"], 0)
        np.testing.assert_allclose(free["dispatch"]["grid"], data["load"], atol=1e-6)
        by_hand = 0.0
        for y in range(2):
            hours = data["years"] == y
            peak = data["qmax"][hours].max()
            window_peak = data["qmax"][hours & data["peak_window"]].max()
            by_hand += ref["weight"][y] * (data["grid_energy"][hours] @ data["load"][hours] + 60 * peak + 25 * window_peak)
        self.assertAlmostEqual(free["economics"]["npc"], by_hand, delta=1e-4)
        self.assertAlmostEqual(ref["npc"], by_hand, delta=1e-4)

    def test_pv_and_battery(self):
        data, cfg = make_data(years=2), make_settings()
        ref, free, fixed = self.compare(data, cfg)
        self.assertGreater(ref["caps"]["pv_dc_mw"], 1.0)
        self.assertGreater(ref["caps"]["bess_mwh"], 1.0)
        for key in ("grid", "pv", "charge", "discharge"):
            self.assertLess(abs(fixed["dispatch"][key].sum() - ref[key].sum()), 1e-3 + 1e-6 * ref[key].sum())
        self.assertAlmostEqual(fixed["dispatch"]["grid"] @ data["grid_energy"], ref["grid"] @ data["grid_energy"],
                               delta=1.0)
        self.check_dispatch_physics(data, cfg, free)
        self.check_dispatch_physics(data, cfg, fixed)
        for field in ("charge", "discharge"):
            self.assertLessEqual(fixed["dispatch"][field].max(), ref["caps"]["bess_mw"] + 1e-6)

    def test_levelized_cost_definition(self):
        data, cfg = make_data(years=3), make_settings()
        free = run_model(data, cfg)
        discount = 1 + cfg["discount"]
        energy = sum(data["load"][data["years"] == y].sum() / discount ** (y + 1) for y in range(3))
        self.assertAlmostEqual(free["economics"]["levelized_supply_cost_usd_mwh"],
                               free["economics"]["npc"] / energy, places=6)

    def test_cash_throughput_cost_changes_solution_consistently(self):
        data, cfg = make_data(years=1), make_settings(bess_throughput_cost=5.0)
        ref, free, _ = self.compare(data, cfg)
        plain = independent_reference(data, make_settings())
        self.assertGreaterEqual(ref["npc"], plain["npc"] - 1e-6)
        self.assertLessEqual(ref["discharge"].sum(), plain["discharge"].sum() + 1e-6)

    def test_chp_with_shared_heat_demand(self):
        data = make_data(years=1, heat=2.5, grid_price=(60., 260.))
        cfg = make_settings(pv_max=0., bess_power_max=0., bess_energy_max=0.)
        ref, free, fixed = self.compare(data, cfg, tech="ng_chp")
        self.assertGreater(ref["caps"]["generator_mw"], .5)
        spec = cfg["technology_parameters"]["ng_chp"]
        np.testing.assert_array_less(fixed["dispatch"]["heat"] - 1e-6, data["heat"])
        np.testing.assert_array_less(fixed["dispatch"]["heat"] - 1e-6, spec["ratio"] * fixed["dispatch"]["gen"] + 1e-6)

    def test_thermal_unit_with_minimum_load_ramp_and_startup(self):
        data = make_data(years=1, heat=0.0, grid_price=(60., 260.))
        units = dict(ng=dict(min_load=.4, ramp=.5, startup=40.))
        cfg = make_settings(pv_max=0., bess_power_max=0., bess_energy_max=0.,
                            tech_constraints=dict(enabled=True, units=units))
        free_cfg = make_settings(pv_max=0., bess_power_max=0., bess_energy_max=0.)
        ref, free, fixed = self.compare(data, cfg, tech="ng")
        unconstrained = independent_reference(data, free_cfg, "ng")
        self.assertGreaterEqual(ref["npc"], unconstrained["npc"] - 1e-6)
        capacity = ref["caps"]["generator_mw"]
        self.assertGreater(capacity, 1.0)
        output = fixed["dispatch"]["gen"]
        committed = fixed["dispatch"]["commit_ng"]
        np.testing.assert_array_less(units["ng"]["min_load"] * committed - 1e-6, output + 1e-9)
        np.testing.assert_array_less(output - 1e-6, committed)
        np.testing.assert_array_less(committed - 1e-6, capacity + 1e-9)
        first = np.r_[True, np.diff(data["mi"]) != 0]
        up_steps = np.diff(output)[~first[1:]] - units["ng"]["ramp"] * capacity - fixed["dispatch"]["start_ng"][1:][~first[1:]]
        self.assertLessEqual(up_steps.max(), 1e-6)


class FinancialDefinitionTests(unittest.TestCase):
    def test_npc_decomposition_equals_discounted_cashflows(self):
        data, cfg = make_data(years=3), make_settings()
        result = run_model(data, cfg)
        economics = result["economics"]
        i, r = cfg["inflation"], cfg["discount"]
        flows = [row["total_cash_cost"] for row in economics["annual"]]
        npc = economics["capex"] + sum(f / (1 + r) ** (y + 1) for y, f in enumerate(flows))
        self.assertAlmostEqual(economics["npc"], npc, places=4)
        base = [row["net_opex"] / (1 + i) ** (y + 1) for y, row in enumerate(economics["annual"])]
        self.assertAlmostEqual(base[0], economics["annual"][0]["net_opex"] / (1 + i), places=6)

    def test_annuity_and_incremental_metrics(self):
        r, years, capital = .06, 10, 1_000_000.
        payment = capital * r / (1 - (1 + r) ** -years)
        self.assertAlmostEqual(sum(payment / (1 + r) ** k for k in range(1, years + 1)), capital, places=6)
        metrics = finance.incremental_metrics([-capital, *[payment] * years], r)
        self.assertAlmostEqual(metrics["npv"], 0, places=4)
        self.assertAlmostEqual(metrics["irr"], r, places=6)


if __name__ == "__main__":
    unittest.main()
