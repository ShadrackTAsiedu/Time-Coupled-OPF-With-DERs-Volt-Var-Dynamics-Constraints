"""Regression tests: partial re-runs keep all scenarios, microgrid min/max suggestions stay coherent, panel errors never block navigation."""

import csv
import json
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock
from urllib.request import urlopen

import generation_app as app
import power_flow

ROOT = Path(__file__).resolve().parent
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
BASE = "a" * 32


def values(**overrides):
    v = {f["key"]: f["default"] for f in app.FIELDS}
    v.update(trajectory_mode="model", baseline=33.34421, microgrid_min_mw=0, microgrid_max_mw=1e12)
    v.update(overrides)
    return v


class MicrogridValidationTests(unittest.TestCase):
    def test_message_names_both_values(self):
        with self.assertRaisesRegex(ValueError, r"minimum \(50 MW\) cannot exceed maximum \(40 MW\)"):
            app.validate_request(dict(values=values(microgrid_min_mw=50, microgrid_max_mw=40), scenarios=["P1"], planned_generation=[]))

    def test_suggestions_never_lower_range(self):
        import workflow
        def row(key, cur, sug):
            return dict(target=dict(kind="field", key=key), recommended=True, current=cur, suggested=sug, reason="r")
        entry = dict(code="P1", suggestions=[row("microgrid_max_mw", 10, 0.05), row("microgrid_max_mw", 10, 12), row("microgrid_min_mw", 8, 0.05)])
        self.assertEqual(workflow.fixable_overrides(entry), {})
        adv = workflow.range_advisories(entry)
        self.assertEqual([(a["key"], a["suggested"]) for a in adv], [("microgrid_max_mw", 12), ("microgrid_min_mw", 0.05)])
        self.assertTrue(all(not a["applied"] for a in adv))

class MergeTests(unittest.TestCase):
    def make_base(self, directory):
        folder = Path(directory) / BASE
        folder.mkdir()
        results = []
        for code in ("R0", "P1"):
            result = dict(code=code, name=code, economics=dict(npc=1.0), technical_status=dict(status="FAIL"))
            (folder / f"result_{code}.json").write_text(json.dumps(result), encoding="utf-8")
            with (folder / f"dispatch_{code}.csv").open("w", newline="", encoding="utf-8-sig") as stream:
                w = csv.writer(stream)
                w.writerow(["timestamp", "a", "b", "c", "d", "e", "grid_import", "shortfall"])
                w.writerows([[f"t{i}", 0, 0, 0, 0, 0, i * 1.5, 0] for i in range(4)])
            results.append(result)
        (folder / "status.json").write_text(json.dumps(dict(state="complete", summary=dict(results=results))), encoding="utf-8")

    def test_partial_rerun_carries_other_scenarios(self):
        with tempfile.TemporaryDirectory() as directory, mock.patch.object(app, "RUNS", Path(directory)):
            self.make_base(directory)
            request = app.validate_request(dict(values=values(), scenarios=["P1"], merge_from=BASE, planned_generation=[]))
            self.assertEqual((request["merge_from"], request["carry_codes"]), (BASE, ["R0"]))
            carried = app.load_carried(BASE, "R0", 4)
            self.assertEqual(list(carried["dispatch"]["grid_import"]), [0, 1.5, 3, 4.5])
            self.assertIsNone(app.load_carried(BASE, "R0", 5))
            with self.assertRaises(ValueError):
                app.validate_request(dict(values=values(), scenarios=["P1"], merge_from="../x", planned_generation=[]))
            plain = app.validate_request(dict(values=values(), scenarios=["P1"], planned_generation=[]))
            self.assertEqual(plain["carry_codes"], [])


class PanelErrorBrowserTest(unittest.TestCase):
    def test_failing_panel_never_blocks_navigation(self):
        from playwright.sync_api import sync_playwright
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)], cwd=ROOT,
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try:
                    urlopen(base + "/api/defaults", timeout=.5).close()
                    break
                except OSError:
                    time.sleep(.1)
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
                page = browser.new_page()
                page.goto(base + "/")
                page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
                page.evaluate("() => { solveSnapshot = {summary: {results: []}}; renderSummary = () => { throw new Error('boom'); }; }")
                page.locator("#tab-summary").click()
                self.assertTrue(page.locator("#view-summary").is_visible())
                self.assertIn("boom", page.locator("#view-summary .panel-error").inner_text())
                page.locator("#tab-solve").click()
                self.assertTrue(page.locator("#view-solve").is_visible())
                page.evaluate("() => { Promise.reject(new Error('rejected')); }")
                page.wait_for_timeout(300)
                self.assertIn("rejected", page.locator("#view-solve .panel-error").inner_text())
                page.locator("#tab-powerflow").click()
                self.assertTrue(page.locator("#view-powerflow").is_visible())
                browser.close()
        finally:
            server.terminate()


if __name__ == "__main__":
    unittest.main()
