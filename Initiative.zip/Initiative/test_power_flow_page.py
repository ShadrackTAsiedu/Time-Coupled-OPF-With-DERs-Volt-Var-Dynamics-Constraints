import csv
import io
import json
import unittest
from pathlib import Path
from unittest import mock

import extensions
import generation_app
import network_topology
import power_flow as pf
from test_power_flow import ScreeningTests, diagram, same_kv

HERE = Path(__file__).resolve().parent

FIELD_COUNTS = dict(BUS=13, LOAD=14, GENERATOR=20, BRANCH=18, SHUNT=5)


def split(line):
    body = line.split("/")[0]
    return [cell.strip() for cell in next(csv.reader(io.StringIO(body), skipinitialspace=True, quotechar="'"))]


def parse_raw(text):
    """Structural parse of a v33 RAW file; asserts section order/terminators and returns the records per section."""
    lines = text.splitlines()
    assert lines[-1] == "Q", "file must end with Q"
    head = split(lines[0])
    assert len(head) == 6 and head[2] == "33", head
    pos, out = 3, {}
    for k, section in enumerate(pf.RAW_SECTIONS):
        records = []
        while not lines[pos].startswith("0 /"):
            records.append(lines[pos])
            pos += 1
        assert lines[pos] == pf.raw_terminator(k), (lines[pos], pf.raw_terminator(k))
        pos += 1
        out[section] = records
    assert pos == len(lines) - 1
    return out


class RawTests(unittest.TestCase):
    def network(self, islanded=False):
        nodes = [("g", "grid"), ("sub", "substation"), ("b", "bus"), ("l", "load"), ("pv", "pv"), ("bs", "bess")]
        lines = [("w1", "g", "sub", 5), ("t1", "sub", "b", 0), ("w2", "b", "l", 0.5), ("w3", "pv", "b", 0), ("w4", "bs", "b", 0)]
        over = same_kv(["g", "sub"], kv=33.0)
        over.update(same_kv(["b", "l", "pv", "bs"], kv=11.0))
        over["b"]["shunt_mvar"] = 0.6
        return pf.build_network(diagram(nodes, lines), caps=dict(pv=4.0, bess=2.0),
                                assumptions=dict(nodes=over), islanded=islanded, peak_load_mw=3.0)

    def test_sections_fields_and_references(self):
        net = self.network()
        inj = dict(load_mw=3.0, gens=dict(pv=dict(p=2.5), bess=dict(p=-0.8)))
        raw = pf.export_raw(net, inj)
        self.assertNotIn("\n", raw.replace("\r\n", ""))
        rec = parse_raw(raw)
        buses = [split(r) for r in rec["BUS"]]
        numbers = {int(b[0]) for b in buses}
        self.assertEqual(len(numbers), len(buses))
        for b in buses:
            self.assertEqual(len(b), FIELD_COUNTS["BUS"], b)
            self.assertLessEqual(len(b[1]), 12)
            self.assertIn(int(b[3]), (1, 2, 3, 4))
        self.assertEqual(sum(1 for b in buses if b[3] == "3"), 1, "exactly one swing bus")
        for r in rec["LOAD"]:
            self.assertEqual(len(split(r)), FIELD_COUNTS["LOAD"])
            self.assertIn(int(split(r)[0]), numbers)
        for r in rec["FIXED SHUNT"]:
            self.assertEqual(len(split(r)), FIELD_COUNTS["SHUNT"])
        self.assertEqual(len(rec["FIXED SHUNT"]), 1)
        gens = [split(r) for r in rec["GENERATOR"]]
        self.assertEqual(len(gens), 3)
        swing = next(b[0] for b in buses if b[3] == "3")
        self.assertIn(swing, [g[0] for g in gens])
        for g in gens:
            self.assertEqual(len(g), FIELD_COUNTS["GENERATOR"], g)
            self.assertIn(int(g[0]), numbers)
            self.assertGreater(float(g[8]), 0, "MBASE must be positive")
            self.assertGreaterEqual(float(g[4]), float(g[5]), "QT >= QB")
        bess = next(g for g in gens if float(g[2]) < 0)
        self.assertLessEqual(float(bess[17]), float(bess[2]), "PB <= PG when charging")
        pairs = set()
        for r in rec["BRANCH"]:
            f = split(r)
            self.assertEqual(len(f), FIELD_COUNTS["BRANCH"], f)
            self.assertTrue({int(f[0]), int(f[1])} <= numbers)
            pairs.add((f[0], f[1], f[2]))
        self.assertEqual(len(pairs), len(rec["BRANCH"]), "circuit ids unique")
        trafo = rec["TRANSFORMER"]
        self.assertEqual(len(trafo), 4 * sum(1 for b in net.branches if b["kind"] == "transformer"))
        self.assertTrue(trafo)
        for k in range(0, len(trafo), 4):
            r1, r2, r3, r4 = (split(x) for x in trafo[k:k + 4])
            self.assertEqual(len(r1), 14, r1)
            self.assertEqual(len(r2), 3, r2)
            self.assertEqual(len(r3), 17, r3)
            self.assertEqual(len(r4), 2, r4)
            self.assertTrue({int(r1[0]), int(r1[1])} <= numbers)
            self.assertEqual(r1[2], "0")
            self.assertGreater(float(r3[3]), 0)
            self.assertGreater(float(r2[1]), 0)
            self.assertGreater(float(next(b for b in buses if int(b[0]) == int(r1[0]))[2]),
                               float(next(b for b in buses if int(b[0]) == int(r1[1]))[2]), "winding 1 is the HV side")
        self.assertEqual(len(split(rec["AREA"][0])), 5)
        self.assertEqual(split(rec["AREA"][0])[1], swing)
        self.assertEqual(len(rec["ZONE"]), 1)
        self.assertEqual(len(rec["OWNER"]), 1)
        for name in ("TWO-TERMINAL DC", "VSC DC LINE", "SWITCHED SHUNT", "INDUCTION MACHINE"):
            self.assertEqual(rec[name], [])

    def test_solved_state_is_embedded(self):
        net = self.network()
        inj = dict(load_mw=3.0, gens=dict(pv=dict(p=2.5)))
        case = pf.solve_case(net, inj)
        self.assertTrue(case["converged"])
        rec = parse_raw(pf.export_raw(net, inj, case))
        by_id = {b["id"]: b for b in case["buses"]}
        checked = 0
        for r in rec["BUS"]:
            f = split(r)
            row = next((b for b in case["buses"] if int(f[0]) == b["num"]), None)
            if row:
                checked += 1
                self.assertAlmostEqual(float(f[7]), row["vm"], places=4)
                self.assertAlmostEqual(float(f[8]), row["va_deg"], places=2)
        self.assertGreaterEqual(checked, 4)
        pv = next(split(r) for r in rec["GENERATOR"] if abs(float(split(r)[2]) - 2.5) < 1e-6)
        self.assertAlmostEqual(float(pv[3]), by_id["pv"]["gen_mvar"], places=3)
        self.assertGreaterEqual(float(pv[4]), float(pv[3]) - 1e-3, "voltage-controlled inverter: QT covers dispatched Q")
        self.assertAlmostEqual(float(pv[4]), -float(pv[5]), places=3, msg="Q limits come from the operating pf")
        grid = next(r for r in case["gens"] if r["tech"] == "grid")
        swing = next(split(r) for r in rec["GENERATOR"] if split(r)[4] == "9999.0")
        self.assertAlmostEqual(float(swing[2]), grid["src_p_mw"], places=3)

    def test_islanded_swing_is_forming_unit(self):
        net = self.network(islanded=True)
        rec = parse_raw(pf.export_raw(net, dict(load_mw=1.0, gens=dict(pv=dict(p=1.0)))))
        buses = [split(r) for r in rec["BUS"]]
        swing = [b for b in buses if b[3] == "3"]
        self.assertEqual(len(swing), 1)
        self.assertTrue(swing[0][1].startswith("BESS") and 5000 < int(swing[0][0]) < 6000, swing[0])
        self.assertNotIn("4", [b[3] for b in buses], "out-of-service grid buses are dropped, not written as type 4")
        self.assertFalse(any(int(b[0]) < 2000 for b in buses))


class PageFixture:
    code = "S1"
    setUp = ScreeningTests.setUp
    tearDown = ScreeningTests.tearDown
    make_run = ScreeningTests.make_run


class SuggestionTests(PageFixture, unittest.TestCase):
    nodes = [("g", "grid"), ("b", "bus"), ("l", "load"), ("pv", "pv")]
    lines = [("w1", "g", "b", 0), ("w2", "b", "l", 0), ("w3", "pv", "b", 3)]

    def assumptions(self, rating=1.0):
        return dict(nodes=same_kv(["g", "b", "l", "pv"]), lines=dict(w3=dict(rating_mva=rating)))

    def test_every_violation_has_numeric_suggestion_and_apply_fixes_it(self):
        run = self.make_run(self.nodes, self.lines)
        report = pf.screen_run(run, self.code, assumptions=self.assumptions(), n1=False)
        self.assertEqual(report["status"], "FAIL")
        rows = report["suggestions"]
        row = next(r for r in rows if r["target"] == dict(kind="line", key="rating_mva", id="w3"))
        self.assertEqual(row["current"], 1.0)
        self.assertGreater(row["suggested"], 1.0)
        self.assertTrue(row["applicable"] and row["recommended"])
        for r in rows:
            self.assertIsInstance(r["suggested"], float)
            self.assertIn(r["target"]["kind"], ("field", "node", "line", "advice"))
        again = pf.screen_run(run, self.code, assumptions=self.assumptions(rating=row["suggested"]), n1=False)
        self.assertNotEqual(again["status"], "FAIL", [v for c in again["cases"] for v in c["violations"]])

    def test_targets_map_to_real_inputs(self):
        names = {f["key"] for f in generation_app.FIELDS}
        run = self.make_run(self.nodes, self.lines)
        report = pf.screen_run(run, self.code, assumptions=self.assumptions(), n1=True)
        net = pf.build_network(diagram(self.nodes, self.lines), assumptions=dict(nodes=same_kv(["g", "b", "l", "pv"])),
                               caps=dict(pv=4.0), peak_load_mw=3.0)
        probe = dict(scenario=self.code, cases=[dict(label="x", emergency=False, detail=report["cases"][0]["detail"], violations=[
            dict(type="forming_overload", severity="fail", component="pv", value=5.0, limit=1.0, message="m")])])
        extra = pf.suggest_actions(probe, net, dict(microgrid_max_mw=4.0, microgrid_min_mw=0.0))
        keys = {r["target"]["key"] for r in extra}
        self.assertIn("forming_capacity", keys)
        for r in extra:
            if r["target"]["key"] == "microgrid_max_mw":
                self.assertGreaterEqual(r["suggested"], 4.0)
            if r["target"]["key"] == "microgrid_min_mw":
                self.assertLessEqual(r["suggested"], 4.0)
        kinds = set()
        for r in report["suggestions"] + extra:
            t = r["target"]
            kinds.add(t["kind"])
            if t["kind"] == "field":
                self.assertIn(t["key"], names)
            elif t["kind"] == "node":
                self.assertIn(t["key"], network_topology.NODE_ELECTRICAL)
            elif t["kind"] == "line":
                self.assertIn(t["key"], network_topology.LINE_ELECTRICAL)
        self.assertIn("field", kinds)

    def test_voltage_low_gets_reactive_support(self):
        run = self.make_run([("g", "grid"), ("l", "load")], [("w1", "g", "l", 4.0)])
        a = dict(nodes=same_kv(["g", "l"]), lines=dict(w1=dict(rating_mva=50.0, r_ohm_km=0.6, x_ohm_km=0.5)))
        report = pf.screen_run(run, self.code, assumptions=a, n1=False)
        low = [r for r in report["suggestions"] if r["violation"] == "voltage_low"]
        self.assertTrue(low, report["cases"][0]["violations"])
        self.assertEqual(low[0]["target"]["key"], "shunt_mvar")
        self.assertGreater(low[0]["suggested"], low[0]["current"])

    def test_electrical_data_flows_from_topology(self):
        diag = diagram(self.nodes, self.lines)
        diag["lines"][2]["electrical"] = dict(rating_mva=1.0, bogus=5, mva="x")
        for n in diag["nodes"]:
            n["electrical"] = dict(kv=11.0)
        clean = network_topology.validate_diagram(diag, [])
        self.assertEqual(clean["lines"][2]["electrical"], dict(rating_mva=1.0))
        run = self.make_run(self.nodes, self.lines)
        request = json.loads((run / "request.json").read_text())
        request["topology"]["diagrams"][self.code] = diag
        (run / "request.json").write_text(json.dumps(request))
        report = pf.screen_run(run, self.code, n1=False)
        self.assertEqual(report["status"], "FAIL")
        self.assertTrue(any(r["target"].get("id") == "w3" for r in report["suggestions"]))
        override = pf.screen_run(run, self.code, assumptions=dict(lines=dict(w3=dict(rating_mva=50.0))), n1=False)
        self.assertNotEqual(override["status"], "FAIL")


class ApiTests(PageFixture, unittest.TestCase):
    def setUp(self):
        super().setUp()
        patch = mock.patch.object(extensions, "RUNS", HERE / "test_power_flow_scratch")
        patch.start()
        self.addCleanup(patch.stop)

    def test_snapshot_and_hours_actions(self):
        run = self.make_run([("g", "grid"), ("b", "bus"), ("l", "load"), ("pv", "pv")],
                            [("w1", "g", "b", 0), ("w2", "b", "l", 0), ("w3", "pv", "b", 0)])
        a = dict(nodes=same_kv(["g", "b", "l", "pv"]))
        post = extensions.POST["powerflow"]
        base = dict(run_id=run.name, scenario=self.code, assumptions=a)
        hours = post(dict(base, action="hours"))
        kinds = {p["kind"] for p in hours["picks"]}
        self.assertTrue({"peak", "min_load", "high_pv"} <= kinds)
        peak = post(dict(base, action="snapshot", kind="peak"))
        self.assertEqual(peak["hour_index"], next(p["index"] for p in hours["picks"] if p["kind"] == "peak"))
        self.assertTrue(peak["case"]["converged"])
        self.assertIn("p_mw", peak["case"]["gens"][0])
        self.assertIn(peak["status"], ("PASS", "WARN", "FAIL"))
        user = post(dict(base, action="snapshot", hour_index=5))
        self.assertEqual(user["hour_index"], 5)
        self.assertEqual(user["timestamp"], "2030-01-01 05:00:00")
        with self.assertRaises(ValueError):
            post(dict(base, action="snapshot", hour_index=9999))
        parse_raw(post(dict(base, action="raw", hour_index=12))["text"])
        self.assertIn("suggestions", pf.technical_status(run, self.code, assumptions=a))


class PageAssetsTests(unittest.TestCase):
    def test_page_wiring_exists(self):
        html = (HERE / "generation_ui" / "index.html").read_text(encoding="utf-8")
        self.assertIn('id="tab-powerflow"', html)
        self.assertIn('id="view-powerflow"', html)
        self.assertIn('src="/pfpage.js"', html)
        js = (HERE / "generation_ui" / "pfpage.js").read_text(encoding="utf-8")
        for token in ("powerFlowStatus", "powerflow-status", "pfp-suggestions"):
            self.assertIn(token, js)


if __name__ == "__main__":
    unittest.main()
