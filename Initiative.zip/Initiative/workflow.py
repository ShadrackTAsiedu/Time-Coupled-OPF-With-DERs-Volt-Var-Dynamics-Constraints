"""Two-step workflow: economic SOLVE, then a technical power-flow check on every scenario.

The recommendation is ECONOMIC: the lowest total NPC (optimizer NPC incl. capex, opex, fuel, replacements, upgrades and
any network equipment already included in the scenario, plus the cost of corrections already applied to its inputs)
among scenarios that serve all load.  The technical status (PASS/WARN/FAIL), violations, notes and the indicative cost of
the still-required corrections are REMARKS: they never change the ranking.  "NPC incl. indicative corrections"
(adjusted_npc) is informational only.
Per-run state is stored in <run>/workflow.json (keys documented in GENERATION_APP_README.md):

  version, run_id, updated, technical_check (bool: was it requested for the solve),
  check        {state: not_run|running|complete|error, done, total, message, started, finished}
  basis        "economic" (ranking is always by total NPC; "checked" tells whether technical remarks exist)
  scenarios    [{code, name, reference, order, npc, applied_cost_usd, applied_items, total_npc (ranking basis),
                 fix_cost_usd (indicative, still required), adjusted_npc (= total_npc + fix_cost_usd, informational), costed, fix_items,
                 technical_status (PASS|WARN|FAIL|NOT_RUN), violation_count, violations, suggestions, corrections, feasible,
                 unserved_mwh, rank (= economic_rank), economic_rank, is_recommended, is_leader, overrides}]
  recommended  {code, name, npc, total_npc, adjusted_npc, technical_status, violation_count, compliant, banner, economic_rank,
                leader_code, leader_fails, basis, checked,
                warnings[], unbuilt[], tie_with[], same_mix_as[], check_message, effective_name, effective_technologies, notes[]}
                (added keys only; older keys unchanged)
  iterations   [{iteration, run_id, code, status, violations, npc, total_npc, applied_usd, indicative_usd, sig}]  (reruns)
  effective_technologies {code: {declared, built, unbuilt, unused, effective, energy_mwh, notes, effective_name, is_simplest}},
  effective_name        label of the recommended scenario's effective mix, e.g.
                        "effective mix: Grid + Solar PV + BESS (Hydrogen not built)" (see effective_technologies())
  unit_costs   compliance-fix unit costs used (power_flow.UNIT_COSTS); scenarios also carry check_message, unbuilt, tie_with, same_mix_as, shunt
  iteration    {base_run, iteration, max_iterations, changes}   (only for reruns)
  comparison   [{code, name, changes, npc_before, npc_after, npc_delta, adjusted_before, adjusted_after,
                 adjusted_delta, status_before, status_after}]   (only for reruns)
  decision     {winner_changed, previous_code, new_code, winner_status, action: stop|iterate, reason, banner,
                final_status: compliant|needs_manual_review|not_checked|iterating, suggested_overrides, advisories}
"""

import json
import os
import threading
import time
from pathlib import Path

import extensions

MAX_ITERATIONS = 3
CHECKED = ("PASS", "WARN", "FAIL")
OVERRIDE_SUFFIXES = ("_capex", "_fom_fraction", "_vom", "_fuel_price", "_efficiency", "_heat_efficiency",
                     "_min_load", "_ramp", "_startup", "_acres", "_acres_per_mw", "_acres_per_mwh", "_land_enabled",
                     "_tc_enabled", "_throughput_cost")
OVERRIDE_KEYS = {"microgrid_min_mw", "microgrid_max_mw", "duration_min", "duration_max", "soc_min", "soc_max",
                 "round_trip_efficiency", "daily_cycles"}
_THREADS = {}
_LOCK = threading.Lock()


# ------------------------------------------------------------------ pure ranking logic

def overridable(key):
    key = str(key)
    return key in OVERRIDE_KEYS or any(key.endswith(s) and len(key) > len(s) for s in OVERRIDE_SUFFIXES)

def is_feasible(result):
    a = result.get("adequacy") or {}
    return not a.get("unserved_hours") and (a.get("stress_unserved_mwh") or 0) <= 5e-5


TIE_TOLERANCE = 5e-4   # relative NPC difference below which two options are treated as equal in cost
TECH_LABELS = {"pv": "Solar PV", "bess": "BESS", "wind": "Wind", "h2": "Hydrogen", "h2_chp": "Hydrogen CHP", "ng": "Natural gas",
               "ng_chp": "Natural gas CHP", "diesel": "Diesel", "biogas": "Biogas", "biomass": "Biomass"}


def built_capacity(caps, tech):
    caps = caps or {}
    if tech == "pv":
        return float(caps.get("pv_dc_mw") or 0.0)
    if tech == "bess":
        return float(caps.get("bess_mw") or 0.0) if float(caps.get("bess_mwh") or 0.0) > 1e-6 else 0.0
    if tech == "wind" and caps.get("wind_mw") is not None:
        return float(caps["wind_mw"] or 0.0)
    return float((caps.get("generators_mw") or {}).get(tech) or 0.0)


def unbuilt_technologies(result):
    """Eligible technologies (other than the grid) the optimizer chose not to build, as [{key, label}]."""
    caps = result.get("caps") or {}
    return [dict(key=t, label=TECH_LABELS.get(t, str(t).upper())) for t in result.get("eligible_technologies") or []
            if t != "grid" and built_capacity(caps, t) <= 1e-6]


TECH_ORDER = ["pv", "bess", "wind", "h2", "h2_chp", "ng", "ng_chp", "diesel", "biogas", "biomass"]
# A technology with built capacity is "unused" (and the scenario equals the one without it) when its mean annual
# dispatch is below BOTH floors: 1 MWh/yr absolute (metering noise / numerical dust) and 1e-5 (0.001%) of mean
# annual demand.  Real but marginal peaking units (e.g. gas turbine, ~6 MWh/yr on a 195 GWh/yr load) stay "used".
UNUSED_MWH_YEAR = 1.0
UNUSED_LOAD_FRACTION = 1e-5
EQUIV_TOLERANCE = 5e-3   # relative NPC gap within which a simpler declared scenario counts as equivalent
_CSV_CACHE = {}


def _declared(result):
    declared = [t for t in result.get("eligible_technologies") or [] if t != "grid"]
    if not declared and result.get("eligible_technologies") is None:
        tech = result.get("tech")
        declared = [t for t in (tech if isinstance(tech, list) else [tech]) if t and t != "none"]
        caps = result.get("caps") or {}
        for t in ("pv", "bess"):
            if built_capacity(caps, t) > 1e-6:
                declared.append(t)
    return list(dict.fromkeys(declared))


def _csv_generation(folder, code):
    """Per-generator lifetime MWh from dispatch_<code>.csv gen_<tech> columns (cached by file mtime); None if unavailable."""
    import csv
    path = Path(folder) / f"dispatch_{code}.csv"
    try:
        stamp = (str(path), path.stat().st_mtime_ns)
    except OSError:
        return None
    if stamp not in _CSV_CACHE:
        totals = {}
        with open(path, newline="", encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            cols = [c for c in reader.fieldnames or [] if c.startswith("gen_")]
            totals = dict.fromkeys(cols, 0.0)
            for row in reader:
                for c in cols:
                    try:
                        totals[c] += float(row[c])
                    except (TypeError, ValueError):
                        pass
        _CSV_CACHE.clear()
        _CSV_CACHE[stamp] = {c[4:]: v for c, v in totals.items()}
    return _CSV_CACHE[stamp]


def _lifetime_energy(result, tech, built_generators, folder):
    """Lifetime dispatched MWh of one technology from the annual economics rows; None when unknown."""
    annual = (result.get("economics") or {}).get("annual") or []
    if not annual:
        return None
    if tech == "pv":
        key = "optimized_solar_mwh" if all(a.get("optimized_solar_mwh") is not None for a in annual) else "pv_mwh"
        return sum(float(a.get(key) or 0.0) for a in annual)
    if tech == "bess":
        return sum(float(a.get("bess_discharge_mwh") or 0.0) for a in annual)
    total = sum(float(a.get("gen_mwh") or 0.0) for a in annual)
    if len(built_generators) <= 1:
        return total
    per = _csv_generation(folder, result.get("code")) if folder else None
    if per and tech in per:
        return per[tech]
    caps = result.get("caps") or {}
    share = built_capacity(caps, tech) / sum(built_capacity(caps, g) for g in built_generators)
    return total * share


def effective_technologies(result, folder=None):
    """Which declared technologies really matter in a solved scenario.

    Returns dict(declared, built, unbuilt, unused, effective, effective_key=frozenset, effective_name, energy_mwh, notes):
      built   declared technologies with capacity > 0 (they may still be unused);
      unbuilt declared technologies with zero capacity;
      unused  built technologies whose mean annual dispatch is negligible (see UNUSED_*);
      effective  built and used technologies; the scenario is equivalent to the same one declared with only these.
    Cheap: uses result["economics"]["annual"]; the dispatch CSV (in `folder`) is read, once and cached, only to split
    generation among several built generators.
    """
    caps = result.get("caps") or {}
    declared = _declared(result)
    built = [t for t in declared if built_capacity(caps, t) > 1e-6]
    unbuilt = [t for t in declared if t not in built]
    if "bess" in built and float(caps.get("bess_mwh") or 0.0) <= 1e-6:
        built.remove("bess")
        unbuilt.append("bess")
    annual = (result.get("economics") or {}).get("annual") or []
    years = max(len(annual), 1)
    mean_load = (sum(float(a.get("demand_mwh") or 0.0) for a in annual) / years) if annual else 0.0
    floor = max(UNUSED_MWH_YEAR, UNUSED_LOAD_FRACTION * mean_load)
    gens = [t for t in built if t not in ("pv", "bess")]
    energy, unused = {}, []
    for t in built:
        e = _lifetime_energy(result, t, gens, folder or result.get("_folder"))
        energy[t] = None if e is None else round(e, 3)
        if e is not None and e / years < floor:
            unused.append(t)
    effective = [t for t in built if t not in unused]
    order = lambda ts: sorted(ts, key=lambda t: TECH_ORDER.index(t) if t in TECH_ORDER else 99)
    name = " + ".join(["Grid"] + [TECH_LABELS.get(t, t.upper()) for t in order(effective)])
    dropped = order(unbuilt + unused)
    notes = [f"{TECH_LABELS.get(t, t)} not built." for t in order(unbuilt)] + \
            [f"{TECH_LABELS.get(t, t)} built but negligible dispatch ({energy[t]:g} MWh over {years} y)." for t in order(unused)]
    return dict(declared=order(declared), built=order(built), unbuilt=order(unbuilt), unused=order(unused),
                effective=order(effective), effective_key=frozenset(effective), energy_mwh=energy, notes=notes,
                effective_name=("effective mix: " + name + " (" + ", ".join(
                    TECH_LABELS.get(t, t) + (" not built" if t in unbuilt else " unused") for t in dropped) + ")") if dropped else name,
                is_simplest=not dropped)


def mix_signature(result):
    caps = result.get("caps") or {}
    gens = {k: round(float(v or 0.0), 3) for k, v in (caps.get("generators_mw") or {}).items() if k != "none" and float(v or 0.0) > 1e-6}
    return (round(float(caps.get("pv_dc_mw") or 0.0), 3), round(float(caps.get("bess_mw") or 0.0), 3),
            round(float(caps.get("bess_mwh") or 0.0), 3), tuple(sorted(gens.items())))


def entry_from(result, order=0, folder=None):
    """One scenario row from a saved result dict (works with or without technical results)."""
    eff = effective_technologies(result, folder)
    tech = result.get("technical_status") or {}
    cost = result.get("compliance_cost") or {}
    npc = float((result.get("economics") or {}).get("npc", result.get("npc", 0.0)))
    fix = cost.get("total_usd")
    status = tech.get("status", "NOT_RUN")
    unbuilt = unbuilt_technologies(result)
    notes = list(eff["notes"])
    shunt = result.get("shunt") or {}
    if shunt.get("source") == "autoshunt":
        notes.append(f"Auto shunt: existing {shunt.get('existing_mvar') or 0:g} Mvar, needed {shunt.get('needed_mvar') or 0:g} Mvar, "
                     f"total {shunt.get('mvar') or 0:g} Mvar, cost ${shunt.get('cost_usd') or 0:,.0f}"
                     + (" (applied to the case; counted once in the compliance cost)." if shunt.get("applied") else " (not applied)."))
    message = tech.get("message") or ("" if status != "NOT_RUN" else "The technical check has not been run for this scenario.")
    applied = result.get("applied_corrections") or {}
    applied_usd = float(applied.get("total_usd") or 0.0)
    violations = list(tech.get("violations") or [])
    count = (tech.get("summary") or {}).get("violations")
    return dict(code=result.get("code"), name=result.get("name"), reference=result.get("case") == "Reference" or result.get("code") == "R0",
                order=order, npc=npc, applied_cost_usd=applied_usd, applied_items=list(applied.get("items") or []),
                total_npc=npc + applied_usd, fix_cost_usd=float(fix) if fix is not None else 0.0, costed=fix is not None,
                fix_items=list(cost.get("items") or []), technical_status=status, check_message=message,
                identified_cost_usd=applied_usd + (float(fix) if fix is not None else 0.0),
                identified_items=[dict(i, state="applied") for i in applied.get("items") or []]
                + [dict(i, state="still required") for i in cost.get("items") or []],
                violation_count=int(count) if isinstance(count, (int, float)) else len(violations),
                violations=violations[:20], suggestions=list(tech.get("suggestions") or [])[:40],
                corrections=corrections_of(tech, result.get("shunt")),
                feasible=is_feasible(result),
                unserved_mwh=float((result.get("adequacy") or {}).get("unserved_mwh") or 0.0),
                overrides=result.get("overrides") or {}, shunt=result.get("shunt"),
                eligible_count=len([t for t in result.get("eligible_technologies") or [] if t != "grid"]),
                unbuilt=unbuilt, mix=json.loads(json.dumps(mix_signature(result))),
                declared=eff["declared"], effective_key=sorted(eff["effective_key"]), effective_name=eff["effective_name"],
                effective_technologies={k: v for k, v in eff.items() if k != "effective_key"}, notes=notes,
                islanded=tech.get("islanded"))


def corrections_of(tech, shunt=None):
    """Compact, verified corrections for a scenario: node/line patch, shunt bank, field overrides and range advisories."""
    tech = tech or {}
    entry = dict(suggestions=tech.get("suggestions") or [], code=tech.get("scenario"))
    patch = ((tech.get("verification") or {}).get("patch")) or {}
    nodes = {}
    for nid, vals in (patch.get("nodes") or {}).items():
        vals = {k: v for k, v in (vals or {}).items() if not (k == "shunt_mvar" and isinstance(v, (int, float)) and v > 0)}
        if vals:
            nodes[nid] = vals
    lines = {k: dict(v) for k, v in (patch.get("lines") or {}).items() if v}
    mvar = (shunt or {}).get("mvar")
    fields = fixable_overrides(entry)
    advisories = range_advisories(entry)
    count = len(nodes) + len(lines) + len(fields) + (1 if mvar else 0)
    return dict(patch=dict(nodes=nodes, lines=lines), shunt_mvar=mvar, fields=fields, advisories=advisories, count=count)


def total_npc(result):
    """Ranking NPC of a saved result: optimizer NPC plus the cost of corrections already applied to its inputs."""
    npc = float((result.get("economics") or {}).get("npc", result.get("npc", 0.0)))
    return npc + float((result.get("applied_corrections") or {}).get("total_usd") or 0.0)


def recommendation(folder, results):
    """The ONE recommendation of a saved run, used by every chart, table, summary, report and presentation.

    Returns {code, rank_basis, totals: {code: total NPC}}.  The saved workflow.json is authoritative; when it is
    missing or does not cover these results the ranking is recomputed with rank() (lowest total NPC among fully supplied
    scenarios, equal-cost options resolved to the simpler one).
    """
    results = list(results.values()) if isinstance(results, dict) else list(results)
    codes = [r["code"] for r in results]
    totals = {r["code"]: total_npc(r) for r in results}
    code = None
    try:
        saved = _read(Path(folder) / "workflow.json")
        code = (saved.get("recommended") or {}).get("code")
        saved_codes = {e.get("code") for e in saved.get("scenarios") or []}
        if code not in codes or (saved.get("scenarios") and saved_codes != set(codes)):
            code = None
    except (OSError, ValueError, KeyError, TypeError):
        code = None
    if code is None and results:
        code = rank([entry_from(r, i, Path(folder)) for i, r in enumerate(results)])[1].get("code")
    return dict(code=code, totals=totals)


def rank(entries):
    """Annotate entries with the economic rank / informational adjusted NPC and choose the recommended option.

    ECONOMIC only: order is lowest total NPC (optimizer NPC + corrections already applied), then lowest optimizer NPC, then
    definition order.  Only fully supplied scenarios compete; if none is fully supplied the least unserved energy leads.
    Equal-cost options (TIE_TOLERANCE) prefer the simpler / effective-technology scenario.  The technical status never
    excludes or demotes a scenario: it is reported as a remark, with adjusted_npc (= total NPC + indicative corrections) as an
    informational column.
    """
    entries = [dict(e) for e in entries]
    if not entries:
        return [], dict(code=None, basis="economic", checked=False, leader_code=None, leader_fails=False, warnings=[])
    checked = any(e["technical_status"] in CHECKED for e in entries)
    for e in entries:
        e.setdefault("applied_cost_usd", 0.0)
        e.setdefault("total_npc", e["npc"] + e["applied_cost_usd"])
        e["adjusted_npc"] = e["total_npc"] + (e["fix_cost_usd"] or 0.0) if checked else e["total_npc"]
    value = (lambda e: e["total_npc"])
    key = lambda e: (round(value(e), 2), round(e["npc"], 2), e["order"])
    feasible = [e for e in entries if e["feasible"]]
    tie_codes = []
    if feasible:
        pool = sorted(feasible, key=key)
        top = value(pool[0])
        tied = [e for e in pool if value(e) <= top + abs(top) * TIE_TOLERANCE]
        # Equal-cost options: prefer the simpler one (fewest eligible technologies, then fewest unbuilt ones).
        leader = min(tied, key=lambda e: (e.get("eligible_count", 0), len(e.get("unbuilt") or [])) + key(e))
        pool.remove(leader)
        pool.insert(0, leader)
        simple = _simplest(leader, pool, value)
        if simple is not leader:
            pool.remove(simple)
            pool.insert(0, simple)
            leader = simple
        tie_codes = [e["code"] for e in tied if e is not leader]
    else:
        pool = sorted(entries, key=lambda e: (round(e["unserved_mwh"], 6),) + key(e))
        leader = pool[0]
    for i, e in enumerate(pool, 1):
        e["rank"] = e["economic_rank"] = i
    for e in entries:
        e.setdefault("rank", None)
        e.setdefault("economic_rank", None)
        e["tie_with"] = tie_codes if e is leader else [leader["code"]] if e["code"] in tie_codes else []
        e["same_mix_as"] = [o["code"] for o in entries if o is not e and e.get("mix") is not None and o.get("mix") == e.get("mix")
                            and (e.get("mix") != [0.0, 0.0, 0.0, []])]
    chosen = _simplest(leader, feasible or [leader], value)
    for e in entries:
        e["is_leader"] = e["code"] == leader["code"]
        e["is_recommended"] = e["code"] == chosen["code"]
    warnings = []
    ineffective = [t for t in (chosen.get("declared") or []) if t not in (chosen.get("effective_key") or [])]
    if ineffective and not chosen.get("reference"):
        warnings.append(f"{chosen['effective_name']}: the scenario was declared with "
                        + ", ".join(TECH_LABELS.get(t, t) for t in ineffective) + " but it does not contribute "
                        "(not built or negligible dispatch), so the result equals the simpler scenario without it; "
                        "no simpler equivalent scenario (feasible) exists in this run.")
    for t in chosen.get("unbuilt") or []:
        warnings.append(f"{t['label']} is eligible in this scenario but was not selected by the optimizer (uneconomic): "
                        f"the mix contains no {t['label']}, so this option behaves like the simpler scenario without it.")
    if chosen["same_mix_as"]:
        warnings.append("Identical technology mix to " + ", ".join(chosen["same_mix_as"]) + "; any cost difference is solver noise.")
    if chosen["tie_with"] and chosen is leader:
        warnings.append("Cost is within " + f"{TIE_TOLERANCE * 100:g}% of " + ", ".join(chosen["tie_with"]) + "; the simpler option was preferred.")
    if chosen["technical_status"] == "NOT_RUN":
        warnings.append("This option has NOT been technically checked: " + (chosen.get("check_message") or "the power-flow check did not run") +
                        (" Other options were checked, so compare with care." if checked else ""))
    status = chosen["technical_status"]
    compliant = status in ("PASS", "WARN")
    banner = ""
    count = chosen["violation_count"]
    if status == "FAIL":
        banner = (f"Lowest-cost option, not yet technically compliant: {count} violation{'' if count == 1 else 's'}. "
                  "Apply the corrections to continue.")
    elif status == "WARN":
        banner = (f"Lowest-cost option passes the technical check with {count} warning{'' if count == 1 else 's'}. "
                  "Applying the corrections is optional.")
    return entries, dict(code=chosen["code"], name=chosen["name"], npc=chosen["npc"], total_npc=chosen["total_npc"],
                         adjusted_npc=chosen["adjusted_npc"], economic_rank=chosen.get("economic_rank"),
                         technical_status=status, violation_count=chosen["violation_count"], compliant=compliant, banner=banner,
                         leader_code=leader["code"], leader_fails=status == "FAIL",
                         basis="economic", checked=checked, fully_supplied=bool(feasible),
                         warnings=warnings, unbuilt=[t["key"] for t in chosen.get("unbuilt") or []], tie_with=chosen["tie_with"],
                         same_mix_as=chosen["same_mix_as"], check_message=chosen.get("check_message", ""),
                         effective_name=chosen.get("effective_name") or chosen["name"],
                         effective_technologies=chosen.get("effective_technologies"), notes=chosen.get("notes") or [])


def _simplest(entry, pool, value):
    """The simplest declared scenario equivalent to `entry`'s effective technology set (or `entry` itself).

    When an option carries technologies that were not built or never dispatch, a feasible scenario in `pool` whose
    declared technologies equal the effective set, with NPC within EQUIV_TOLERANCE, replaces it (repeated until stable).
    """
    for _ in range(len(pool) + 1):
        declared, eff = entry.get("declared"), entry.get("effective_key")
        if declared is None or eff is None or entry.get("reference") or set(declared) == set(eff):
            return entry
        base = value(entry)
        same = [e for e in pool if e is not entry and not e.get("reference") and e.get("declared") is not None
                and set(e["declared"]) == set(eff) and abs(value(e) - base) <= abs(base) * EQUIV_TOLERANCE]
        if not same:
            return entry
        entry = min(same, key=lambda e: (value(e), e["order"]))
    return entry


def correction_signature(entry):
    """Stable fingerprint of the corrections still required by an entry (flip-flop / no-progress guard)."""
    c = entry.get("corrections") or {}
    return json.dumps([c.get("patch"), c.get("shunt_mvar") and round(c["shunt_mvar"], 3), c.get("fields")], sort_keys=True, default=str)


def decide(previous_code, ranked, recommended, iteration=0, fixable=False, stopped=False, max_iterations=MAX_ITERATIONS,
           history=None, signature=None, advisories=None):
    """What to tell the user after a re-solve and whether another automatic iteration is warranted.

    Iterates only while the economically recommended option FAILs its technical check and new corrections exist.
    Stops when it is PASS/WARN, at the iteration cap, when stopped, when nothing is fixable, or when the same
    corrections would be applied again (no progress)."""
    code, status = recommended.get("code"), recommended.get("technical_status", "NOT_RUN")
    changed = bool(previous_code) and previous_code != code
    if changed:
        banner = f"New optimum {code} selected; it was technically checked: {status}."
    else:
        banner = f"Optimum unchanged: {code} ({status})."
    if status == "NOT_RUN":
        banner = f"New optimum {code} selected; it has NOT been technically checked." if changed else f"Optimum {code}: technical check not run."
    wants = status == "FAIL"
    seen = [h.get("sig") for h in history or [] if h.get("sig")]
    if not wants:
        action, reason, final = "stop", "The recommended option is technically compliant (PASS/WARN) or was not checked.", \
            "compliant" if status in ("PASS", "WARN") else "not_checked"
    elif stopped:
        action, reason, final = "stop", "Stopped by user.", "needs_manual_review"
    elif iteration >= max_iterations:
        action, reason, final = "stop", f"Iteration cap ({max_iterations}) reached.", "needs_manual_review"
    elif not fixable:
        action, reason, final = "stop", "No input correction can be applied automatically.", "needs_manual_review"
        if advisories:
            reason += " " + "; ".join(f"{a['key']} {a.get('current') if a.get('current') is not None else '-'} -> {a['suggested']:g}"
                                      for a in advisories) + " is a change to your own limits: apply it below if you accept it."
    elif signature is not None and signature in seen:
        action, reason, final = "stop", "The same corrections were already applied: no further progress.", "needs_manual_review"
    else:
        action, reason, final = "iterate", "Applying suggested corrections to the failing scenarios and re-solving all scenarios.", "iterating"
    if final == "needs_manual_review":
        banner += " Still failing after corrections: needs manual review."
    return dict(winner_changed=changed, previous_code=previous_code, new_code=code, winner_status=status,
                action=action, reason=reason, banner=banner, iteration=iteration, max_iterations=max_iterations,
                final_status=final)


FINGERPRINTS = (("planning_inputs_sha256", "planning inputs"), ("topology_sha256", "network topology"),
                ("resources_sha256", "resource data"), ("tariffs_sha256", "tariffs"), ("analysis_sha256", "analysis settings"),
                ("scenarios_sha256", "scenario definitions"), ("lifecycle_sha256", "lifecycle inputs"),
                ("engine_sha256", "optimizer engine"), ("application_sha256", "application model code"))


def model_changes(base_run, run_id):
    """Names of the input/model fingerprints that differ between two runs (empty when like-for-like)."""
    try:
        a = _read(extensions.run_folder(base_run) / "run_configuration.json")
        b = _read(extensions.run_folder(run_id) / "run_configuration.json")
    except (OSError, ValueError):
        return []
    return [name for key, name in FINGERPRINTS if a.get(key) and b.get(key) and a[key] != b[key]]


def run_stamp(run_id):
    """Short readable timestamp of a run, e.g. '18 Oct 14:02' (workflow update time, else status file time)."""
    try:
        folder = extensions.run_folder(run_id)
        for name in ("workflow.json", "status.json"):
            if (folder / name).is_file():
                return time.strftime("%d %b %H:%M", time.localtime((folder / name).stat().st_mtime)).lstrip("0")
    except (ValueError, OSError):
        pass
    return ""


def run_label(n, run_id):
    """Readable run name: 'Run 0 - Initial solve (18 Oct 14:02)'; the id stays available as a tooltip."""
    title = "Initial solve" if not n else "Corrections applied" if n == 1 else f"Corrections applied (round {n})"
    stamp = run_stamp(run_id)
    return f"Run {n} - {title}" + (f" ({stamp})" if stamp else "")


def compare(before, after, changes=None):
    """Before/after rows by scenario code, with deltas.  Inputs are ranked entry lists.

    The optimizer NPC delta is the model/input effect (corrections are never inside it); the change of applied
    corrections is the corrections effect; together they make the total delta."""
    changes = changes or {}
    old = {e["code"]: e for e in before or []}
    rows = []
    for e in after:
        o = old.get(e["code"])
        rows.append(dict(code=e["code"], name=e["name"], changes=changes.get(e["code"]) or e.get("overrides") or {},
                         npc_before=o["npc"] if o else None, npc_after=e["npc"],
                         npc_delta=e["npc"] - o["npc"] if o else None,
                         model_effect=e["npc"] - o["npc"] if o else None,
                         corrections_effect=(e.get("applied_cost_usd") or 0.0) - (o.get("applied_cost_usd") or 0.0) if o else None,
                         total_before=o.get("total_npc", o["npc"]) if o else None, total_after=e.get("total_npc", e["npc"]),
                         adjusted_before=o["adjusted_npc"] if o else None, adjusted_after=e["adjusted_npc"],
                         adjusted_delta=e["adjusted_npc"] - o["adjusted_npc"] if o else None,
                         status_before=o["technical_status"] if o else None, status_after=e["technical_status"]))
    return rows


def fixable_overrides(entry):
    """Per-scenario input overrides taken from the failing option's recommended, applicable field suggestions."""
    out = {}
    for s in entry.get("suggestions") or []:
        t = s.get("target") or {}
        if t.get("kind") == "field" and s.get("recommended") and s.get("applicable", True) and s.get("verified") is not False and \
                overridable(t.get("key", "")) and isinstance(s.get("suggested"), (int, float)) and \
                t.get("key") not in RANGE_KEYS:
            out[t["key"]] = s["suggested"]
    return out


RANGE_KEYS = ("microgrid_min_mw", "microgrid_max_mw")


def range_advisories(entry):
    """Microgrid min/max changes are the client's range: never applied automatically, only reported as advisories."""
    out = []
    for s in entry.get("suggestions") or []:
        t = s.get("target") or {}
        if t.get("kind") == "field" and t.get("key") in RANGE_KEYS and isinstance(s.get("suggested"), (int, float)):
            cur = s.get("current")
            if t["key"] == "microgrid_max_mw" and isinstance(cur, (int, float)) and s["suggested"] < cur:
                continue
            out.append(dict(key=t["key"], current=cur, suggested=s["suggested"], reason=s.get("reason") or s.get("why") or "",
                            code=entry.get("code"), applied=False,
                            actionable=t["key"] == "microgrid_max_mw" and isinstance(cur, (int, float)) and s["suggested"] > cur))
    return out


# ------------------------------------------------------------------ persistence

def _read(path):
    for attempt in range(5):
        try:
            return json.loads(Path(path).read_text(encoding="utf-8"))
        except (PermissionError, json.JSONDecodeError):
            if attempt == 4:
                raise
            time.sleep(.02)


def _write(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + f".{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.write_text(json.dumps(value, indent=1), encoding="utf-8")
    for attempt in range(8):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            if attempt == 7:
                raise
            time.sleep(.03)


def _summary_results(folder):
    try:
        return list(((_read(folder / "status.json").get("summary") or {}).get("results")) or [])
    except (OSError, ValueError):
        return []


# ------------------------------------------------------------------ technical check

def _compliance(run_id, code, tech, bank=False):
    """Costed compliance fixes via power_flow.compliance_cost when available (called defensively).

    With an auto-sized shunt bank (counted once through autoshunt.json) node shunt suggestions are not passed again."""
    if tech.get("status") not in ("FAIL", "WARN"):
        return dict(total_usd=0.0, items=[])
    try:
        import power_flow
        fn = getattr(power_flow, "compliance_cost", None)
        if fn is None:
            return None
        def shunt_row(s):
            t = s.get("target") or {}
            return bank and t.get("kind") == "node" and t.get("key") == "shunt_mvar" and (s.get("suggested") or 0) > 0
        applied = [s for s in tech.get("suggestions") or [] if s.get("recommended") and s.get("applicable", True)
                   and s.get("verified") is not False and (s.get("target") or {}).get("key") not in RANGE_KEYS
                   and not shunt_row(s)]
        out = fn(run_id, code, applied)
        if isinstance(out, dict) and out.get("total_usd") is not None:
            return dict(total_usd=float(out["total_usd"]), items=list(out.get("items") or []))
    except Exception:
        pass
    return None


def screen(folder, code, islanded=False):
    """Technical check of one scenario; never raises.  islanded adds the informational grid-disconnection study."""
    try:
        import power_flow
        fn = getattr(power_flow, "screen_scenario", None)
        out = fn(folder.name, code, dict(islanded=True) if islanded else None) if fn else power_flow.technical_status(folder, code, islanded=islanded)
        if not isinstance(out, dict) or "status" not in out:
            return dict(scenario=code, status="NOT_RUN", message="Power-flow check returned no status.")
        return out
    except Exception as exc:
        return dict(scenario=code, status="NOT_RUN", message=f"{type(exc).__name__}: {exc}")


def _first(row, keys):
    for k in keys:
        if isinstance(row.get(k), (int, float)) and not isinstance(row.get(k), bool):
            return float(row[k])
    return None


def _shunt(run_id, code, tech):
    """Optional shunt sizing (power_flow.size_shunt) for scenarios with voltage problems; None when unavailable."""
    if tech.get("status") not in ("FAIL", "WARN"):
        return None
    try:
        import power_flow
        auto = getattr(power_flow, "autoshunt", None)
        if auto is not None:
            out = auto(run_id, code, apply=True)
            if isinstance(out, dict):
                return dict(mvar=_first(out, ("total_mvar", "needed_mvar")), existing_mvar=_first(out, ("existing_mvar",)),
                            needed_mvar=_first(out, ("needed_mvar",)), applied=bool(out.get("applied")),
                            cost_usd=_first(out, ("cost_usd",)), source="autoshunt", detail=out)
        fn = getattr(power_flow, "size_shunt", None)
        out = fn(run_id, code) if fn else None
        if not isinstance(out, dict):
            return None
        return dict(mvar=_first(out, ("size_mvar", "mvar", "total_mvar", "rating_mvar", "size")),
                    cost_usd=_first(out, ("cost_usd", "total_usd", "cost")), detail=out)
    except Exception:
        return None


def check_results(folder, results, progress=None, codes=None, islanded=False):
    """Run the technical check on every result dict (in place): technical_status and compliance_cost."""
    todo = [r for r in results if codes is None or r["code"] in codes]
    for i, result in enumerate(todo, 1):
        if progress:
            progress(f"Technical power-flow check {i}/{len(todo)}: {result.get('name') or result['code']}...", i - 1, len(todo))
        tech = screen(folder, result["code"], islanded)
        pre = tech
        shunt = _shunt(folder.name, result["code"], pre)
        if shunt and shunt.get("applied"):
            # the shown status is the check WITH the auto-sized compensation; the pre-compensation result is kept for the report
            after = screen(folder, result["code"], islanded)
            if isinstance(after, dict) and after.get("status") not in (None, "NOT_RUN"):
                summ = pre.get("summary") if isinstance(pre.get("summary"), dict) else {}
                after["before_compensation"] = dict(status=pre.get("status"), violations=summ.get("violations"),
                                                    shunt_mvar=shunt.get("mvar"))
                tech = after
        result["technical_status"] = tech
        cost = _compliance(folder.name, result["code"], pre, bool(shunt and shunt.get("source") == "autoshunt"))
        result.pop("shunt", None)
        if shunt:
            result["shunt"] = {k: v for k, v in shunt.items() if k != "detail"}
            known = " ".join(str(it.get("label", "")).lower() for it in (cost or {}).get("items") or [])
            if cost is not None and shunt["cost_usd"] and not any(w in known for w in ("shunt", "capacitor", "reactive")):
                cost = dict(total_usd=cost["total_usd"] + shunt["cost_usd"],
                            items=list(cost["items"]) + [dict(label=f"Shunt capacitor bank {shunt['mvar'] or ''} Mvar".replace("  ", " "),
                                                              cost_usd=shunt["cost_usd"], basis="power_flow.size_shunt")])
        cost = _net_of_applied(cost, result.get("applied_corrections"))
        result["compliance_cost"] = cost if cost is not None else None
        if cost is None:
            result.pop("compliance_cost", None)


def _net_of_applied(cost, applied):
    """Indicative cost net of corrections already applied (and charged to total NPC), so nothing is counted twice."""
    if cost is None or not applied or not applied.get("items"):
        return cost
    paid = {}
    for it in applied["items"]:
        kind = _kind(it.get("label"))
        paid[kind] = paid.get(kind, 0.0) + float(it.get("cost_usd") or 0.0)
    items = []
    for it in cost.get("items") or []:
        kind = _kind(it.get("label"))
        usd = float(it.get("cost_usd") or 0.0)
        take = min(usd, paid.get(kind, 0.0))
        if take > 0:
            paid[kind] -= take
            usd -= take
        if usd > 1e-6:
            items.append(dict(it, cost_usd=usd))
    return dict(total_usd=sum(i["cost_usd"] for i in items), items=items)


def _kind(label):
    text = str(label or "").lower()
    for word, kind in (("shunt", "shunt"), ("capacitor", "shunt"), ("reactor", "reactor"), ("transformer", "transformer"),
                       ("line", "line"), ("reactive", "reactive")):
        if word in text:
            return kind
    return text


def _persist_results(folder, results):
    for r in results:
        path = folder / f"result_{r['code']}.json"
        if path.is_file():
            _write(path, {k: v for k, v in r.items() if k != "dispatch"})


def _unit_costs():
    try:
        import power_flow
        return dict(getattr(power_flow, "UNIT_COSTS", {}) or {})
    except Exception:
        return {}


def _cost_basis():
    try:
        import pf_costs
        return pf_costs.cost_basis()
    except Exception:
        return {}


def build(folder, results, request=None, check=None, requested=None):
    """Rank the results and return the workflow.json document (not yet written)."""
    entries, rec = rank([entry_from(r, i, folder) for i, r in enumerate(results)])
    wf = dict(version=1, run_id=folder.name, updated=time.strftime("%Y-%m-%dT%H:%M:%S"),
              technical_check=requested, check=check or dict(state="complete" if rec["checked"] else "not_run"),
              basis=rec["basis"], scenarios=entries, recommended=rec, unit_costs=_unit_costs(), cost_basis=_cost_basis(),
              effective_technologies={e["code"]: e["effective_technologies"] for e in entries},
              effective_name=rec.get("effective_name"))
    info = (request or {}).get("workflow")
    if info and info.get("base_run"):
        base_wf = previous_workflow(info["base_run"])
        before = base_wf.get("scenarios") or previous_entries(info["base_run"])
        previous = next((e["code"] for e in before if e.get("is_recommended")), None)
        wf["iteration"] = dict(info)
        wf["iteration"].update(base_label=run_label(max(int(info.get("iteration", 1)) - 1, 0), info["base_run"]),
                               label=run_label(int(info.get("iteration", 0)), folder.name),
                               model_changes=model_changes(info["base_run"], folder.name))
        wf["comparison"] = compare(before, entries, info.get("changes"))
        chosen = next((e for e in entries if e["is_recommended"]), None) or {}
        fix = fixable_overrides(chosen) if chosen else {}
        corr = chosen.get("corrections") or {}
        sig = correction_signature(chosen) if chosen else None
        history = list(base_wf.get("iterations") or [])
        if not history and before:
            first = next((e for e in before if e.get("is_recommended")), before[0])
            history = [_iteration_row(0, info["base_run"], first, "")]
        wf["decision"] = decide(previous, entries, rec, int(info.get("iteration", 0)), fixable=bool(corr.get("count")),
                                history=history, signature=sig, advisories=corr.get("advisories"))
        if info.get("mode") == "powerflow" and wf["decision"]["action"] == "iterate":
            wf["decision"].update(action="stop", reason="Re-solve after power-flow edits finished; review the check results.",
                              final_status="needs_manual_review")
        wf["decision"]["suggested_overrides"] = fix
        wf["decision"]["advisories"] = corr.get("advisories") or []
        wf["iterations"] = [dict(h, label=h.get("label") or run_label(h.get("iteration", 0), h.get("run_id")))
                            for h in history + [_iteration_row(int(info.get("iteration", 0)), folder.name, chosen, sig)]]
    else:
        chosen = next((e for e in entries if e["is_recommended"]), None)
        if chosen:
            wf["iterations"] = [_iteration_row(0, folder.name, chosen, correction_signature(chosen))]
    return wf


def _iteration_row(n, run_id, e, sig):
    return dict(iteration=n, run_id=run_id, label=run_label(n, run_id), code=e.get("code"), name=e.get("name"), status=e.get("technical_status"),
                violations=e.get("violation_count"), npc=e.get("npc"), total_npc=e.get("total_npc"),
                applied_usd=e.get("applied_cost_usd"), indicative_usd=e.get("fix_cost_usd"),
                identified_usd=e.get("identified_cost_usd"), sig=sig)


def previous_workflow(run_id):
    try:
        folder = extensions.run_folder(run_id)
        if (folder / "workflow.json").is_file():
            return _read(folder / "workflow.json")
    except (ValueError, OSError):
        pass
    return {}


def previous_entries(run_id):
    """Ranked entries of an earlier run, from its workflow.json or computed in memory (never writes)."""
    try:
        folder = extensions.run_folder(run_id)
    except ValueError:
        return []
    if (folder / "workflow.json").is_file():
        try:
            return _read(folder / "workflow.json").get("scenarios") or []
        except (OSError, ValueError):
            pass
    return rank([entry_from(r, i) for i, r in enumerate(_summary_results(folder))])[0]


def carry_applied(request, results):
    """Set result['applied_corrections'] = corrections charged in earlier iterations (base run) + those sent with this solve."""
    info = (request or {}).get("workflow") or {}
    if not info.get("base_run"):
        return
    base = {e["code"]: e for e in previous_workflow(info["base_run"]).get("scenarios") or []}
    sent = info.get("applied_costs") or {}
    for r in results:
        items = list((base.get(r["code"]) or {}).get("applied_items") or [])
        items += [dict(label=str(i.get("label", "")), cost_usd=float(i.get("cost_usd") or 0.0)) for i in (sent.get(r["code"]) or {}).get("items") or []]
        total = sum(i["cost_usd"] for i in items)
        if items:
            r["applied_corrections"] = dict(total_usd=total, items=items)
        else:
            r.pop("applied_corrections", None)


def finalize(folder, request, results, progress=None):
    """Worker hook after solving: optional technical check on all scenarios, then write workflow.json."""
    folder = Path(folder)
    if not results:
        return None
    carry_applied(request, results)
    requested = bool(request.get("technical_check", True))
    check = dict(state="not_run", done=0, total=len(results))
    if requested:
        started = time.time()
        check_results(folder, results, (lambda msg, i, n: progress(msg)) if progress else None,
                      islanded=bool(request.get("technical_islanded")))
        check = dict(state="complete", done=len(results), total=len(results), started=started, finished=time.time())
        _persist_results(folder, results)
    wf = build(folder, results, request, check, requested)
    for e in wf["scenarios"]:
        for r in results:
            if r["code"] == e["code"]:
                r["adjusted_npc"], r["is_recommended"] = e["adjusted_npc"], e["is_recommended"]
                r["effective_technologies"], r["effective_name"] = e["effective_technologies"], e["effective_name"]
    _persist_results(folder, results)
    _write(folder / "workflow.json", wf)
    return wf


def _islanded_requested(folder):
    """Whether the saved run asked for the informational islanded study."""
    try:
        return _read(folder / "request.json").get("technical_islanded") is True
    except (OSError, ValueError):
        return False


def run_check(run_id, codes=None):
    """On-demand check of an already solved run (all scenarios by default); updates result files, status.json, workflow.json."""
    folder = extensions.run_folder(run_id)
    status = _read(folder / "status.json")
    results = (status.get("summary") or {}).get("results") or []
    if status.get("state") not in ("complete", "completed") or not results:
        raise ValueError("The run has no completed solve to check yet.")
    old = _read(folder / "workflow.json") if (folder / "workflow.json").is_file() else {}
    keep = {k: old[k] for k in ("iteration", "comparison", "decision", "technical_check") if k in old}
    total = len(results)

    def state(done, message="", s="running"):
        wf = dict(old or dict(version=1, run_id=run_id, scenarios=[], recommended={}))
        wf["check"] = dict(state=s, done=done, total=total, message=message, started=started)
        _write(folder / "workflow.json", wf)

    started = time.time()
    state(0, "Starting technical check...")
    try:
        check_results(folder, results, lambda msg, i, n: state(i, msg), codes, islanded=_islanded_requested(folder))
        _persist_results(folder, results)
        wf = build(folder, results, None, dict(state="complete", done=total, total=total, started=started, finished=time.time()),
                   old.get("technical_check"))
        wf.update(keep)
        wf["technical_check"] = True
        status["summary"]["results"] = results
        _write(folder / "status.json", status)
        _write(folder / "workflow.json", wf)
    except Exception as exc:
        state(0, f"{type(exc).__name__}: {exc}", "error")
        raise


def get(run_id):
    folder = extensions.run_folder(run_id)
    if (folder / "workflow.json").is_file():
        wf = _read(folder / "workflow.json")
        wf["persisted"] = True
        if (wf.get("check") or {}).get("state") == "running" and run_id not in _THREADS:
            wf["check"]["state"] = "error"
            wf["check"]["message"] = "The technical check was interrupted (server restarted). Run it again."
        return wf
    results = _summary_results(folder)
    entries, rec = rank([entry_from(r, i, folder) for i, r in enumerate(results)])
    return dict(version=1, run_id=run_id, persisted=False, technical_check=None, check=dict(state="complete" if rec.get("checked") else "not_run"),
                basis=rec["basis"], scenarios=entries, recommended=rec,
                effective_technologies={e["code"]: e["effective_technologies"] for e in entries},
                effective_name=rec.get("effective_name"))


def _start_check(payload):
    run_id = payload.get("run_id")
    folder = extensions.run_folder(run_id)
    codes = payload.get("scenarios")
    if codes is not None and (not isinstance(codes, list) or not all(isinstance(c, str) for c in codes)):
        raise ValueError("scenarios must be a list of scenario IDs.")
    status = _read(folder / "status.json")
    if status.get("state") not in ("complete", "completed"):
        raise ValueError("Wait for the solve to finish before running the technical check.")
    with _LOCK:
        if run_id in _THREADS and _THREADS[run_id].is_alive():
            return dict(started=False, message="A technical check is already running for this run.")

        def job():
            try:
                run_check(run_id, set(codes) if codes else None)
            except Exception:
                import traceback
                traceback.print_exc()
            finally:
                _THREADS.pop(run_id, None)
        thread = threading.Thread(target=job, daemon=True)
        _THREADS[run_id] = thread
        thread.start()
    return dict(started=True)


def _get(query):
    run_id = (query.get("run_id") or [""])[0]
    return get(run_id)


def corrections_plan(payload):
    """Verified corrections for every FAIL/WARN scenario of a run (nothing is changed on disk)."""
    run_id = payload.get("run_id") if isinstance(payload, dict) else None
    folder = extensions.run_folder(run_id)
    wf = get(run_id)
    try:
        diagrams = ((_read(folder / "request.json").get("topology") or {}).get("diagrams")) or {}
    except (OSError, ValueError):
        diagrams = {}
    plan, total = {}, 0.0
    for e in wf.get("scenarios") or []:
        if e.get("technical_status") not in ("FAIL", "WARN"):
            continue
        c = dict(e.get("corrections") or {})
        items = [dict(label=str(i.get("label", "")), cost_usd=float(i.get("cost_usd") or 0.0)) for i in e.get("fix_items") or []]
        usd = float(e.get("fix_cost_usd") or 0.0)
        c.update(code=e["code"], status=e["technical_status"], cost_usd=usd, items=items,
                 diagram=diagrams.get(e["code"]) if c.get("shunt_mvar") else None)
        if c.get("count") or c.get("shunt_mvar"):
            plan[e["code"]] = c
            total += usd
    return dict(run_id=run_id, scenarios=plan, total_usd=total, advisories=[a for c in plan.values() for a in c.get("advisories") or []],
                recommended=(wf.get("recommended") or {}).get("code"))


extensions.POST["workflow_check"] = _start_check
extensions.GET["workflow"] = _get
extensions.GET["workflow_corrections"] = lambda query: corrections_plan(dict(run_id=(query.get("run_id") or [""])[0]))
