"""Currency layer: central helpers (python + browser), unit-override semantics and canonical USD payloads."""

import unittest

from playwright.sync_api import sync_playwright

import currency
import test_e2e_support as support

EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"


class CurrencyHelperTest(unittest.TestCase):
    def tearDown(self):
        currency.activate({})

    def test_default_is_usd_and_invalid_falls_back(self):
        currency.activate({})
        self.assertTrue(currency.is_usd())
        self.assertEqual(currency.fx(), 1.0)
        currency.activate({"currency_code": "XXX-bad", "currency_rate": 5})
        self.assertTrue(currency.is_usd())
        currency.activate({"currency_code": "EUR", "currency_rate": 0})
        self.assertTrue(currency.fx() > 0)

    def test_table_covers_many_countries(self):
        codes = {row["code"] for row in currency.table()}
        self.assertGreaterEqual(len(codes), 150)
        for code in ("USD", "EUR", "GBP", "JPY", "INR", "ZAR", "BRL", "AUD", "CAD", "CNY", "AED", "NGN", "KES"):
            self.assertIn(code, codes)

    def test_scaling_and_labels(self):
        currency.activate({"currency_code": "EUR", "currency_rate": 0.5})
        self.assertAlmostEqual(float(currency.scaled(100)), 50)
        self.assertAlmostEqual(float(currency.mega(2e6)), 1.0)
        self.assertNotIn("$", currency.label("NPC $m"))
        self.assertEqual(currency.xl().count("$"), 0)
        currency.activate({})
        self.assertEqual(currency.label("NPC $m"), "NPC $m")
        self.assertEqual(float(currency.scaled(100)), 100)

    def test_money_text_uses_rate(self):
        currency.activate({"currency_code": "EUR", "currency_rate": 0.5})
        text = currency.money(2e6, 1e6, 2, "")
        self.assertIn("1", text)
        self.assertNotIn("$", text)


class CurrencyBrowserTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = support.Server()

    @classmethod
    def tearDownClass(cls):
        cls.server.close()

    def open(self, playwright):
        browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
        page = browser.new_context(viewport={"width": 1500, "height": 1000}).new_page()
        self.errors = []
        page.on("pageerror", lambda exc: self.errors.append(str(exc)))
        page.goto(self.server.base + "/")
        page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
        page.evaluate("() => { localStorage.removeItem('genstudio-display-units'); unitsUi.resetToDefault(); }")
        return browser, page

    @staticmethod
    def pick(page, selector, value):
        page.evaluate("([s, v]) => { const e = document.querySelector(s); e.value = v; e.dispatchEvent(new Event('change', {bubbles: true})); }", [selector, value])

    def test_header_labels_are_gold_and_field_choice_wins(self):
        with sync_playwright() as p:
            browser, page = self.open(p)
            try:
                colour = page.evaluate("() => getComputedStyle(document.querySelector('header .units-control label, header .units-control strong')).color")
                self.assertEqual(colour, "rgb(255, 210, 74)")
                self.pick(page, "label:has(#microgrid_max_mw) select.unit-select", "GW AC")
                self.pick(page, "#units-power", "kW")
                self.assertEqual(page.input_value("#microgrid_max_mw"), "0.01")  # field-level choice kept
                self.assertEqual(page.input_value("#grid_limit"), str(round(page.evaluate("() => values().grid_limit") * 1000)))  # untouched field follows the global
                page.click("#units-apply-all")
                self.assertEqual(page.input_value("#microgrid_max_mw"), "10000")
                self.pick(page, "label:has(#microgrid_max_mw) select.unit-select", "MW AC")
                self.assertEqual(page.input_value("#microgrid_max_mw"), "10")
                page.click("#units-reset")
                self.assertEqual(page.input_value("#grid_limit"), str(round(page.evaluate("() => values().grid_limit"))))
                self.assertEqual(self.errors, [])
            finally:
                browser.close()

    def test_currency_switch_keeps_usd_payload_and_round_trips(self):
        with sync_playwright() as p:
            browser, page = self.open(p)
            try:
                baseline = page.evaluate("() => values()")
                usd = baseline["ng_capex"]
                self.assertEqual(baseline["currency_code"], "USD")
                self.assertTrue(page.evaluate("() => document.getElementById('currency_rate').readOnly"))
                self.pick(page, "#currency_code", "EUR")
                rate = float(page.input_value("#currency_rate"))
                self.assertNotEqual(rate, 1.0)
                shown = float(page.input_value("#ng_capex"))
                self.assertAlmostEqual(shown, usd * rate, delta=abs(usd * rate) * 1e-3)
                self.assertAlmostEqual(page.evaluate("() => values().ng_capex"), usd, delta=usd * 1e-3)
                # A different rate keeps the typed local numbers, so the USD payload changes accordingly.
                page.evaluate("() => { const e = document.getElementById('currency_rate'); e.value = 2; e.dispatchEvent(new Event('input', {bubbles: true})); }")
                self.assertAlmostEqual(page.evaluate("() => values().ng_capex"), shown / 2, delta=shown * 1e-3)
                self.assertEqual(page.evaluate("() => values().currency_code"), "EUR")
                snap = page.evaluate("() => JSON.parse(JSON.stringify(inputWorkspace.snapshot()))")
                self.assertEqual(snap["values"]["currency_code"], "EUR")
                self.pick(page, "#currency_code", "USD")
                self.assertEqual(page.evaluate("() => values().currency_code"), "USD")
                page.evaluate("(s) => restore(s)", snap)
                self.assertEqual(page.evaluate("() => values().currency_code"), "EUR")
                self.assertAlmostEqual(page.evaluate("() => values().ng_capex"), snap["values"]["ng_capex"], delta=usd * 1e-3)
                self.assertEqual(page.evaluate("() => currencyUi.label('NPC ($ million)')").count("$"), 0)
                self.assertEqual(self.errors, [])
            finally:
                browser.close()

    def test_old_draft_without_currency_loads_as_usd(self):
        with sync_playwright() as p:
            browser, page = self.open(p)
            try:
                snap = page.evaluate("() => JSON.parse(JSON.stringify(inputWorkspace.snapshot()))")
                snap["values"].pop("currency_code", None)
                snap["values"].pop("currency_rate", None)
                page.evaluate("(s) => restore(s)", snap)
                self.assertEqual(page.evaluate("() => currencyUi.code()"), "USD")
                self.assertEqual(self.errors, [])
            finally:
                browser.close()


if __name__ == "__main__":
    unittest.main()
