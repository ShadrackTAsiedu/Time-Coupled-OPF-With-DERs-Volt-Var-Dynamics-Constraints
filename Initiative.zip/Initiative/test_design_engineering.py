"""Hand-calculated engineering checks of design.py (ratings, short circuit, cables, land)."""

import math
import unittest

import design

SQ3 = math.sqrt(3.0)


class Ratings(unittest.TestCase):
    def test_highest_voltage_and_arrester(self):
        self.assertEqual(design.highest_voltage_kv(11), 12)
        self.assertEqual(design.highest_voltage_kv(13.8), 17.5)
        self.assertEqual(design.highest_voltage_kv(33), 36)
        # Ur = 0.8 * 36 = 28.8 -> 30 kV; 0.8 * 145 = 116 -> 117 kV (3 kV steps)
        self.assertEqual(design.arrester_rating_kv(33), 30)
        self.assertEqual(design.arrester_rating_kv(132), 117)

    def test_detuning_frequency(self):
        # f / sqrt(p): 7 % at 60 Hz = 226.8 Hz, at 50 Hz = 189.0 Hz
        self.assertAlmostEqual(design.detuning_hz(7, 60), 226.78, 2)
        self.assertAlmostEqual(design.detuning_hz(7, 50), 188.98, 2)


class ShortCircuit(unittest.TestCase):
    def test_grid_through_transformer(self):
        # 750 MVA grid, 60 MVA 12 % transformer: 1 / (1/750 + 0.12/60) = 300 MVA; plus 32.4 MVA local sources
        self.assertAlmostEqual(design.short_circuit(750, 0.12, 1, 60, 32.4), 332.4, 6)
        self.assertAlmostEqual(332.4 / (SQ3 * 11), 17.446, 3)


class Cables(unittest.TestCase):
    def test_few_large_circuits_preferred(self):
        cab = design.size_cable(2400.0, 11.0, 0.8)
        self.assertLessEqual(cab["circuits"], 6)
        self.assertLessEqual(cab["loading_pct"], 100.0)
        self.assertLessEqual(cab["vd_pct"], design.CABLE_VD_LIMIT_PCT)

    def test_short_circuit_withstand_area(self):
        # A = I sqrt(t) / k = 13650 * sqrt(0.5) / 94 = 102.7 mm2 -> next conductor 150 mm2
        min_area = 13.65 * 1000.0 * math.sqrt(design.CLEARING_S) / design.CABLE_K_AL
        self.assertAlmostEqual(min_area, 102.68, 2)
        self.assertEqual(design.size_cable(50.0, 33.0, 1.0, min_area=min_area)["area"], 150)

    def test_incoming_cable_uses_hv_fault_level(self):
        spec = design.Spec(has_grid=True, v_hv=33.0, v_mv=11.0, s_poi_mva=40.0, peak_load_mw=40.0, load_pf=0.95, main_n=1, main_mva=60.0,
                           margin={}, length_km=dict(incoming=0.5, load=0.5), groups=[], plans={}, isc_ka_mv=17.0, isc_hv_ka=40.0, ov={})
        design._size_feeders(spec)
        self.assertGreaterEqual(spec["feeders"]["incoming"]["area"], 40000.0 * math.sqrt(design.CLEARING_S) / design.CABLE_K_AL)


class ExampleRunEngineering(unittest.TestCase):
    RUN = "7791be18470745f8af5ef34fa3d208f8"

    @classmethod
    def setUpClass(cls):
        try:
            cls.d = design.build_design(cls.RUN)
            cls.d50 = design.build_design(cls.RUN, overrides={"frequency_hz": 50})
        except Exception as exc:
            raise unittest.SkipTest(f"example run unavailable: {exc}")

    def test_breaker_covers_fault_duty(self):
        row = next(e for e in self.d["equipment"] if e["id"] == "SWG-MV-01")
        self.assertGreaterEqual(row["params"]["short_circuit_ka"], row["params"]["fault_duty_ka"])

    def test_fifty_hz_uses_iec_transformer_series(self):
        main = next(e for e in self.d50["equipment"] if e["id"] == "TR-MAIN")
        self.assertIn(main["params"]["mva_onaf"], design.STD_MAIN_MVA_IEC)
        self.assertEqual(design.STD_MAIN_MVA[1], 7.5)  # module constants restored after the build

    def test_land_pv_matches_ac_rating(self):
        pv = next(x for x in self.d["land"] if x["item"] == "PV array")
        self.assertAlmostEqual(pv["quantity"], self.d["totals"]["pv_ac_mw_total"] * design.ACRES_PER_PV_MWAC, 1)


if __name__ == "__main__":
    unittest.main()
