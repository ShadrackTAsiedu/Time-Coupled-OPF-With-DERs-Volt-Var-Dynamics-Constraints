import re
import socket
import subprocess
import sys
import time
import unittest
from pathlib import Path
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"


class DataPrepBrowserTest(unittest.TestCase):
    def test_clean_and_use_messy_load(self):
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)],
                                  cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try:
                    urlopen(base + "/api/defaults", timeout=.5).close()
                    break
                except OSError:
                    time.sleep(.1)
            sample = ROOT / "Data Preparation Samples" / "messy_load_european_hourly_kWh.csv"
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
                page = browser.new_context(viewport={"width": 1600, "height": 1000}, accept_downloads=True).new_page()
                errors = []
                page.on("pageerror", lambda exc: errors.append(str(exc)))
                page.goto(base + "/")
                page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
                nav = page.locator("#input-navigation details").filter(
                    has=page.locator("summary").filter(has_text=re.compile("^Demand$")))
                nav.locator("summary").click()
                self.assertEqual(page.locator("#input-navigation summary", has_text="Data Preparation").count(), 0)
                self.assertEqual(page.locator("#prep-run").count(), 0)
                page.locator("#add-load").click()
                page.locator("#historical-csv").set_input_files(str(sample))
                dialog = page.locator("#data-check-dialog")
                dialog.wait_for(state="visible", timeout=30000)
                self.assertIn("grade", dialog.inner_text())
                self.assertTrue(dialog.locator("svg").is_visible())
                spike = dialog.locator("[data-step=spikes]")
                if spike.count():
                    spike.uncheck()
                    page.wait_for_function("() => document.querySelector('#data-check-dialog [data-step=spikes]')?.checked === false")
                with page.expect_download() as download:
                    dialog.get_by_role("button", name="Download corrected CSV").click()
                self.assertTrue(download.value.suggested_filename.startswith("cleaned_load"))
                dialog.get_by_role("button", name="Accept corrections and continue").click()
                dialog.wait_for(state="detached")
                self.assertIn("cleaned_load", page.locator("#profile-uploads").inner_text())
                self.assertIn("corrected automatically", page.locator("#profile-uploads").inner_text())
                self.assertEqual(errors, [])
                browser.close()
        finally:
            server.terminate()
            server.wait(10)


if __name__ == "__main__":
    unittest.main()
