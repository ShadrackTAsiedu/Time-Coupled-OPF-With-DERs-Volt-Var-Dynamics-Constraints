import shutil
import tempfile
import unittest
import uuid
from pathlib import Path

import numpy as np
from pypdf import PdfReader

import generation_app as app
import network_topology
import optimize_generation_mix as model
import resource_profiles
import scenario_inputs
import summary_pdf
from test_client_planning import short_data
from test_resource_economics_revision import resource


def topology():
    return dict(enabled=True, nodes=[
        dict(id="load", kind="load", x=900, y=400),
        dict(id="bus", kind="substation", x=600, y=400, owner="shared", capital_cost=1234),
        dict(id="grid", kind="grid", x=300, y=200),
        dict(id="wind", kind="wind", x=300, y=600)],
        lines=[dict(id="main", source="bus", target="load", owner="shared", length_km=2, cost_per_km=500),
               dict(id="grid-line", source="grid", target="bus", owner="grid", length_km=.5, cost_per_km=200),
               dict(id="wind-line", source="wind", target="bus", owner="wind", length_km=1, cost_per_km=1000)])


class TopologyWindTests(unittest.TestCase):
    def setup_case(self, charge=0):
        request = app.validate_request(dict(values=dict(horizon_years=1, extended_appraisal=False,
            microgrid_min_mw=0, microgrid_max_mw=10, grid_limit=100, reactive_enabled=False,
            include_replacements=True, wind_life=1), scenarios=["P1"], planned_generation=[]))
        cfg = app.settings_for(request["values"])
        cfg["technology_parameters"]["wind"].update(capex=100, fom=0, vom=0)
        cfg, names = scenario_inputs.settings(cfg, dict(technologies=["grid", "wind"]))
        cfg["connection_costs"] = dict(wind=charge, shared=2234, grid=100)
        data = short_data()
        data.update(load=np.full(288, 3.0), qmax=np.full(288, 3.0), qmin=np.full(288, 3.0),
                    wind=np.full(288, .5), grid_energy=np.full(288, 100.0),
                    facility=np.zeros(12), tou=np.zeros(12), fixed=np.zeros(12), heat=np.zeros(288))
        return data, cfg, names

    def test_owned_cost_validation_and_scenario_connectivity(self):
        scenarios = [dict(id="GW", technologies=["grid", "wind"]), dict(id="G", technologies=["grid"])]
        validated = network_topology.validate(topology(), scenarios)
        costs = network_topology.costs(validated, ["grid", "wind"])
        self.assertEqual(costs["wind"], 1000)
        self.assertEqual(costs["shared"], 2234)
        self.assertEqual(network_topology.costs(validated, ["grid"])["wind"], 0)
        invalid = topology()
        invalid["lines"] = invalid["lines"][:-1]
        with self.assertRaisesRegex(ValueError, "connect wind"):
            network_topology.validate(invalid, scenarios)
        invalid = topology()
        invalid["lines"][0]["length_km"] = -1
        with self.assertRaisesRegex(ValueError, "line length"):
            network_topology.validate(invalid, scenarios)
        invalid = topology()
        invalid["lines"][0]["target"] = "absent"
        with self.assertRaisesRegex(ValueError, "to Load"):
            network_topology.validate(invalid, scenarios)
        dangling = topology()
        dangling["lines"].append(dict(dangling["lines"][0], id="dangling", target="absent"))
        cleaned = network_topology.validate(dangling, scenarios)
        self.assertNotIn("dangling", [line["id"] for line in cleaned["lines"]])

    def test_wind_hourly_dispatch_and_conditional_connection_changes_optimum(self):
        data, cfg, names = self.setup_case(1000)
        cheap = model.solve_decomposed(data, "W", "Wind connection", names, settings=cfg)
        self.assertAlmostEqual(cheap["caps"]["generators_mw"]["wind"], 6, places=5)
        self.assertEqual(cheap["economics"]["connection_capex"], 3334)
        self.assertLessEqual(np.max(cheap["dispatch"]["gen_wind"] -
                                  data["wind"] * cheap["caps"]["generators_mw"]["wind"]), 1e-6)
        self.assertLess(cheap["validation"]["master_gap_usd"], 201)
        cfg["connection_costs"]["wind"] = 1e6
        expensive = model.solve_decomposed(data, "WX", "Expensive line", names, settings=cfg)
        self.assertAlmostEqual(expensive["caps"]["generators_mw"]["wind"], 0, places=6)
        self.assertEqual(expensive["economics"]["connection_capex"], 2334)
        data["wind"][:24] = 0
        cfg["connection_costs"]["wind"] = 1000
        variable = model.solve_decomposed(data, "WV", "Wind profile", names, settings=cfg)
        np.testing.assert_allclose(variable["dispatch"]["gen_wind"][:24], 0, atol=1e-7)
        np.testing.assert_allclose(variable["dispatch"]["grid"][:24], 3, atol=1e-7)

    def test_wind_cap_emissions_land_aging_and_resource_bounds(self):
        data, cfg, names = self.setup_case()
        cfg.update(emissions_limit_enabled=True, emissions_limit_t_year=20, wind_emissions_t_mwh=.1)
        cfg["technology_parameters"]["wind"]["emissions_t_mwh"] = .1
        capped = model.solve_decomposed(data, "WC", "Wind carbon", names, settings=cfg)
        self.assertLessEqual(capped["economics"]["annual"][0]["net_co2e_after_heat_credit_t"], 20.0001)
        dates = app.forecasting.planning_dates(2027, 1)
        values, _ = resource_profiles.read_profile(resource("wind_per_mw", .7), dates, "wind")
        np.testing.assert_allclose(values, .7)
        with self.assertRaisesRegex(ValueError, "invalid nonnegative"):
            resource_profiles.read_profile(resource("wind_per_mw", 1.01), dates, "wind")
        req = app.validate_request(dict(values=dict(horizon_years=1, appraisal_years=3, wind_life=2,
            wind_derate=.8, wind_degradation=.1, wind_land_enabled=True, wind_acres=12, wind_acres_per_mw=3),
            scenarios=["W"], scenario_definitions=[dict(id="W", technologies=["grid", "wind"])],
            wind_file=resource("wind_per_mw", .7), planned_generation=[]))
        physical, _ = app.make_data(req)
        extended = resource_profiles.extend_appraisal(physical, req["values"])
        self.assertAlmostEqual(app.settings_for(req["values"])["wind_max"], 4)
        for year, factor in enumerate([1, .9, 1]):
            np.testing.assert_allclose(extended["wind"][extended["years"] == year], .7*.8*factor)

    def test_export_results_and_pdf_use_saved_wind_and_connection_costs(self):
        data, cfg, names = self.setup_case(1000)
        result = model.solve_decomposed(data, "W", "Wind", names, settings=cfg)
        result["eligible_technologies"] = ["grid", "wind"]
        req = app.validate_request(dict(values=dict(horizon_years=1, extended_appraisal=False), solve=False))
        with tempfile.TemporaryDirectory() as folder:
            summary = app.export_results(Path(folder), data, req, cfg, [result], [], [], "Test")
            self.assertIn("Wind MW", summary["columns"])
            self.assertNotIn("Solar MW", summary["columns"])
            self.assertIn("Connection CAPEX $m", summary["columns"])


if __name__ == "__main__":
    unittest.main()
