﻿"""Display-unit layer: conversion library, form behaviour (browser) and kW-scale end-to-end solve."""

import json
import unittest
from datetime import datetime

from playwright.sync_api import sync_playwright

import test_e2e_support as support

EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"


class UnitsBrowserTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = support.Server()

    @classmethod
    def tearDownClass(cls):
        cls.server.close()

    def open(self, playwright):
        browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
        page = browser.new_context(viewport={"width": 1500, "height": 1000}).new_page()
        self.errors = []
        page.on("pageerror", lambda exc: self.errors.append(str(exc)))
        page.goto(self.server.base + "/")
        page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
        page.evaluate("() => { localStorage.removeItem('genstudio-display-units'); unitsUi.resetToDefault(); }")
        return browser, page

    @staticmethod
    def pick(page, selector, value):
        page.evaluate("([s, v]) => { const e = document.querySelector(s); e.value = v; e.dispatchEvent(new Event('change', {bubbles: true})); }", [selector, value])

    @staticmethod
    def fill(page, selector, value):
        page.evaluate("([s, v]) => { const e = document.querySelector(s); e.value = v; e.dispatchEvent(new Event('input', {bubbles: true})); }", [selector, value])

    def test_conversion_library_round_trips(self):
        with sync_playwright() as p:
            browser, page = self.open(p)
            try:
                bad = page.evaluate("""() => {
                    const out = [];
                    for (const [unit, options] of Object.entries(unitsUi.SPECS)) {
                        if (!options.some(o => o[1] === 1 && o[0] === unit)) out.push("no canonical option " + unit);
                        for (const a of options) for (const b of options) {
                            const v = 1234.5678, back = unitsUi.convert(unitsUi.convert(v, unit, a[0], b[0]), unit, b[0], a[0]);
                            if (Math.abs(back - v) > 1e-9 * v) out.push(`${unit}: ${a[0]} -> ${b[0]} -> ${a[0]} = ${back}`);
                        }
                    }
                    return out;
                }""")
                self.assertEqual(bad, [])
                got = page.evaluate("""() => ({
                    mw: unitsUi.convert(1.5, "MW", "MW", "kW"), kw: unitsUi.toCanonical(800, "MW", "kW"),
                    gw: unitsUi.toCanonical(2, "MWh", "GWh"), usd: unitsUi.convert(1e6, "$/MW", "$/MW", "$/kW"),
                    cents: unitsUi.toCanonical(25, "$/kWh", "\\u00a2/kWh"), mwhPrice: unitsUi.convert(0.25, "$/kWh", "$/kWh", "$/MWh"),
                    gj: unitsUi.convert(10, "$/MMBtu HHV", "$/MMBtu HHV", "$/GJ HHV"), kg: unitsUi.toCanonical(500, "t CO2e/MWh", "kg CO2e/MWh"),
                    small: unitsUi.toCanonical(0.2, "MW", "kW")})""")
                self.assertEqual(got["mw"], 1500)
                self.assertEqual(got["kw"], 0.8)
                self.assertEqual(got["gw"], 2000)
                self.assertAlmostEqual(got["usd"], 1000)
                self.assertAlmostEqual(got["cents"], 0.25)
                self.assertAlmostEqual(got["mwhPrice"], 250)
                self.assertAlmostEqual(got["gj"], 9.47817, places=4)
                self.assertAlmostEqual(got["kg"], 0.5)
                self.assertEqual(got["small"], 0.0002)
                self.assertEqual(self.errors, [])
            finally:
                browser.close()

    def test_field_unit_changes_display_but_not_canonical_values(self):
        with sync_playwright() as p:
            browser, page = self.open(p)
            try:
                page.evaluate("() => { document.getElementById('grid_limit').value = 0.6; }")
                before = page.evaluate("() => values()")
                select = page.locator("select.unit-select[data-for]").first
                self.assertTrue(page.evaluate("() => !!document.querySelector('#grid_limit').parentElement.querySelector('select.unit-select')"))
                self.pick(page, "#grid_limit ~ select.unit-select, label:has(#grid_limit) select.unit-select", "kW")
                self.assertEqual(page.input_value("#grid_limit"), "600")
                self.assertEqual(page.evaluate("() => values().grid_limit"), 0.6)
                # Typing a kW value reaches the request as MW, and every other value is untouched.
                self.fill(page, "#grid_limit", "480")
                after = page.evaluate("() => values()")
                self.assertEqual(after["grid_limit"], 0.48)
                self.assertEqual(after["export_limit_mw"], before["export_limit_mw"])
                self.assertEqual(page.evaluate("() => request(false).values.grid_limit"), 0.48)
                # Cost per power: 70000 $/MW typed as $/kW.
                page.evaluate("() => unitsUi.setCanonical('ng_capex', 1200000)")
                self.pick(page, "label:has(#ng_capex) select.unit-select", "$/kW")
                self.assertEqual(page.input_value("#ng_capex"), "1200")
                self.fill(page, "#ng_capex", "900")
                self.assertEqual(page.evaluate("() => values().ng_capex"), 900000)
                # min/max follow the display unit so the browser still validates in the displayed unit.
                self.assertEqual(page.get_attribute("#grid_limit", "max"), "10000000")
                self.assertEqual(self.errors, [])
            finally:
                browser.close()

    def test_global_display_units_snapshot_restore_and_reset(self):
        with sync_playwright() as p:
            browser, page = self.open(p)
            try:
                baseline = page.evaluate("() => values()")
                self.pick(page, "#units-power", "kW")
                self.pick(page, "#units-energy", "kWh")
                self.assertEqual(page.evaluate("() => values()"), baseline)
                self.assertEqual(page.input_value("#microgrid_max_mw"), "10000")
                self.assertEqual(page.input_value("#bess_energy_capex"), "250")
                saved = page.evaluate("() => JSON.parse(JSON.stringify(inputWorkspace.snapshot()))")
                self.assertEqual(saved["values"], baseline)
                self.assertEqual(saved["display_units"]["fields"]["microgrid_max_mw"], "kW AC")
                # Restoring a saved draft that carries units, then one that does not (an old saved run).
                page.evaluate("(s) => restore(s)", saved)
                self.assertEqual(page.input_value("#microgrid_max_mw"), "10000")
                self.assertEqual(page.evaluate("() => values()"), baseline)
                page.evaluate("() => unitsUi.resetToDefault()")
                self.assertEqual(page.input_value("#microgrid_max_mw"), "10")
                old = dict(saved)
                old.pop("display_units")
                page.evaluate("(s) => restore(s)", old)
                self.assertEqual(page.evaluate("() => values()"), baseline)
                self.assertEqual(page.input_value("#microgrid_max_mw"), "10")
                # Per-field override after a global choice, then a reset to the defined units.
                self.pick(page, "#units-power", "kW")
                self.pick(page, "label:has(#microgrid_max_mw) select.unit-select", "GW AC")
                self.assertEqual(page.input_value("#microgrid_max_mw"), "0.01")
                self.assertEqual(page.evaluate("() => values().microgrid_max_mw"), 10)
                page.click("#units-reset")
                self.assertEqual(page.input_value("#microgrid_max_mw"), "10")
                self.assertEqual(self.errors, [])
            finally:
                browser.close()

    def test_row_inputs_and_presentation_helpers(self):
        with sync_playwright() as p:
            browser, page = self.open(p)
            try:
                page.evaluate("() => { addInputRow('milestone-rows', {year: 2030, peak_mw: 0.8}, milestoneFields); }")
                row = "#milestone-rows .input-row:last-child"
                self.pick(page, row + " select.unit-select", "kW")
                self.assertEqual(page.input_value(row + " [data-key=peak_mw]"), "800")
                self.assertEqual(page.evaluate("() => readRows('milestone-rows').at(-1).peak_mw"), 0.8)
                state = page.evaluate("() => unitsUi.snapshot().rows")
                self.assertTrue(any(v for v in state.values()))
                self.pick(page, "#units-power", "kW")
                self.pick(page, "#units-energy", "kWh")
                got = page.evaluate("""() => {
                    const c = unitsUi.adaptChart({unit: "MW", yTitle: "Power (MW)", series: [{label: "Load (MW)", values: [0.0002, null]}]});
                    const e = unitsUi.adaptChart({unit: "MWh", yTitle: "Energy (MWh)", series: [{label: "SOC", values: [1.5]}]});
                    const t = unitsUi.adaptColumns(["Solar MW", "BESS MWh", "Levelized supplied electricity $/MWh", "NPC $m", "Grid peak import MW"]);
                    return {c, e, t, text: unitsUi.mwh(0.0123, 4)};
                }""")
                self.assertEqual(got["c"]["unit"], "kW")
                self.assertEqual(got["c"]["yTitle"], "Power (kW)")
                self.assertEqual(got["c"]["series"][0]["values"], [0.2, None])
                self.assertEqual(got["e"]["series"][0]["values"], [1500])
                self.assertEqual(got["t"]["columns"], ["Solar kW", "BESS kWh", "Levelized supplied electricity $/kWh", "NPC $m", "Grid peak import kW"])
                self.assertEqual(got["t"]["factors"], [1000, 1000, 0.001, 1, 1000])
                self.assertEqual(got["text"], "12.3 kWh")
                self.assertEqual(self.errors, [])
            finally:
                browser.close()


class KilowattScaleSolveTest(unittest.TestCase):
    """A 0.8 MW peak, 24-hour study must solve end to end and canonical inputs must reach the backend unchanged."""

    @classmethod
    def setUpClass(cls):
        cls.server = support.Server()

    @classmethod
    def tearDownClass(cls):
        cls.server.close()

    def test_small_microgrid_solves_with_exact_canonical_inputs(self):
        peak = 0.8
        csv = support.load_csv(datetime(2025, 3, 3), 24, base=peak / 2, peak=peak)
        # grid_limit as the kW display unit delivers it: 480 kW typed -> 0.48 MW sent.
        body = support.payload(self.server, ["R0", "P1"], csv=csv, baseline=peak, target=peak, grid_limit=0.48,
                               reference_grid_limit=0.48, upgrade_cost=2000, microgrid_max_mw=0.5)
        job, status = self.server.solve(body, 600)
        self.assertEqual(status["state"], "complete", status.get("message"))
        self.assertEqual(support.non_finite(status), [])
        self.assertFalse(status["summary"]["failures"])
        saved = json.loads((self.server.run_folder(job) / "run_configuration.json").read_text(encoding="utf-8"))
        def find(node, key):
            if isinstance(node, dict):
                if key in node and not isinstance(node[key], (dict, list)):
                    return node[key]
                for v in node.values():
                    got = find(v, key)
                    if got is not None:
                        return got
            elif isinstance(node, list):
                for v in node:
                    got = find(v, key)
                    if got is not None:
                        return got
            return None
        self.assertEqual(find(saved, "grid_limit"), 0.48)
        self.assertEqual(find(saved, "microgrid_max_mw"), 0.5)
        columns = status["summary"]["columns"]
        rows = {r[0]: dict(zip(columns, r)) for r in status["summary"]["rows"]}
        self.assertEqual(rows["R0"]["Supply adequacy"], "ALL LOAD SERVED")
        self.assertLessEqual(rows["P1"]["Grid peak import MW"], 0.48 + 1e-6)
        self.assertLessEqual(rows["P1"]["Additional microgrid MW"], 0.5 + 1e-6)
        self.assertGreater(rows["P1"]["BESS MW"], 1e-4)


if __name__ == "__main__":
    unittest.main()
