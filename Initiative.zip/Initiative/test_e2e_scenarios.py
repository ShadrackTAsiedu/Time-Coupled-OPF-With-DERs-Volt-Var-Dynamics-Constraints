"""End-to-end checks against a throw-away copy of the application.

Fast checks always run; set GENSTUDIO_E2E_SLOW=1 for the solves, browser pass and PSS/E-independent exports.
"""

import json
import os
import re
import unittest
from datetime import datetime
from urllib.request import urlopen

import test_e2e_support as support

SLOW = os.environ.get("GENSTUDIO_E2E_SLOW") == "1"
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
DEFS = [dict(id="R0", name="Grid with upgrade", technologies=["grid"], reference=True),
        dict(id="NG", name="Grid NG", technologies=["grid", "ng"])]


class ValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = support.Server()
        cls.base = support.payload(cls.server, ["R0"])

    @classmethod
    def tearDownClass(cls):
        cls.server.close()

    def post(self, mutate=None, **values):
        body = json.loads(json.dumps(self.base))
        body["values"].update(values)
        if mutate:
            mutate(body)
        return self.server.post("/api/jobs", body)

    def test_bad_numbers_are_rejected_with_a_message(self):
        for key, value in (("baseline", 0), ("baseline", -5), ("baseline", "abc"), ("baseline", None), ("horizon_years", 0),
                           ("horizon_years", 31), ("horizon_years", 2.5), ("discount", 1.5), ("grid_limit", -3)):
            with self.subTest(key=key, value=value):
                status, body = self.post(**{key: value})
                self.assertEqual(status, 400)
                self.assertTrue(body["error"])

    def test_bad_uploads_and_scenarios_are_rejected(self):
        cases = {"negative load": lambda p: p.update(upload_csv="timestamp,load_mw\n2025-01-01 00:00:00,-5\n2025-01-01 01:00:00,-5\n"),
                 "zero load": lambda p: p.update(upload_csv=support.load_csv(datetime(2025, 1, 1), 48, 0, 0)),
                 "one row": lambda p: p.update(upload_csv="timestamp,load_mw\n2025-01-01 00:00:00,5\n"),
                 "duplicate ids": lambda p: p.update(scenario_definitions=[
                     dict(id="R0", name="a", technologies=["grid"], reference=True), dict(id="R0", name="b", technologies=["grid", "pv"])]),
                 "path-like id": lambda p: p.update(scenario_definitions=[dict(id="../x", name="n", technologies=["grid"], reference=True)],
                                                    scenarios=["../x"]),
                 "no scenarios": lambda p: p.update(scenarios=[])}
        for name, mutate in cases.items():
            with self.subTest(name):
                self.assertEqual(self.post(mutate)[0], 400)

    def test_file_routes_do_not_escape_the_run_folder(self):
        for bad in ("/files/../generation_app.py", "/files/..%5Cgeneration_app.py", "/api/jobs/%2e%2e",
                    "/files/" + "0" * 32 + "/..%5C..%5Cgeneration_app.py"):
            with self.subTest(bad):
                try:
                    with urlopen(self.server.base + bad, timeout=10) as response:
                        self.fail(f"served {bad}: {response.status}")
                except Exception as exc:
                    self.assertEqual(getattr(exc, "code", None), 404)

    def test_json_helper_flags_non_finite(self):
        self.assertEqual(support.non_finite({"a": [1, float("nan")], "b": "Infinity"}), ["/a[1]", "/b"])


@unittest.skipUnless(SLOW, "set GENSTUDIO_E2E_SLOW=1 to run end-to-end solves")
class SolveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = support.Server()
        body = support.payload(cls.server, ["R0", "NG"], DEFS, blended_kwh=0.25, grid_limit=30, reference_grid_limit=30,
                               upgrade_cost=5e6)
        cls.job, cls.status = cls.server.solve(body, 600)
        cls.folder = cls.server.run_folder(cls.job)

    @classmethod
    def tearDownClass(cls):
        cls.server.close()

    def test_solve_completes_and_is_finite(self):
        self.assertEqual(self.status["state"], "complete", self.status.get("message"))
        self.assertEqual(support.non_finite(self.status), [])

    def test_hourly_energy_balance_and_bounds(self):
        import pandas as pd
        for result in self.status["summary"]["results"]:
            code = result["code"]
            d = pd.read_csv(self.folder / f"dispatch_{code}.csv", encoding="utf-8-sig")
            supply = d["grid"] + d["pv"] + d["discharge"] - d["charge"] + d["gen"] + d["shortfall"] + d["planned_renewable"]
            self.assertLess((supply - d["total_served_load_mw"]).abs().max(), 1e-6, code)
            self.assertLessEqual(d["grid"].max(), 30 + 1e-6 if result["economics"].get("upgrade_required") is False else 1e9)
            self.assertLessEqual(d["gen"].max(), result["caps"]["generator_mw"] + 1e-6)
            self.assertGreaterEqual(d[["grid", "gen"]].min().min(), -1e-9)

    def test_npc_ranking_and_reports_agree(self):
        results = {r["code"]: r for r in self.status["summary"]["results"]}
        best = min(results.values(), key=lambda r: r["economics"]["npc"])["code"]
        digest = json.loads(urlopen(f"{self.server.base}/api/x/report_summary?run_id={self.job}").read())
        self.assertEqual(digest["best"], best)
        with urlopen(f"{self.server.base}/api/x/report?run_id={self.job}&scenario={best}") as response:
            text = re.sub(r"<[^>]+>", " ", response.read().decode("utf-8"))
        self.assertIn(f"{results[best]['economics']['npc'] / 1e6:,.1f}", text)

    def test_summary_pdf_is_generated_and_names_the_data_period(self):
        status, body = self.server.post("/api/summary-pdf", dict(id=self.job))
        self.assertEqual(status, 200)
        with urlopen(self.server.base + body["url"]) as response:
            pdf = response.read()
        self.assertTrue(pdf.startswith(b"%PDF"))
        import io
        import pypdf
        text = "\n".join(page.extract_text() for page in pypdf.PdfReader(io.BytesIO(pdf)).pages)
        self.assertNotIn("Historical demand data: n/a", text)

    def test_raw_export_is_complete(self):
        with urlopen(f"{self.server.base}/api/x/design_raw?run_id={self.job}&scenario=NG") as response:
            raw = response.read().decode("utf-8")
        for marker in ("END OF BUS DATA", "END OF LOAD DATA", "END OF GENERATOR DATA", "END OF BRANCH DATA", "END OF TRANSFORMER DATA"):
            self.assertIn(marker, raw)
        self.assertTrue(raw.rstrip().endswith("Q"))
        self.assertNotRegex(raw, r"(?i)\bnan\b|\binf\b")

    def test_dispatch_csv_has_no_negative_zero(self):
        text = (self.folder / "dispatch_NG.csv").read_text(encoding="utf-8-sig")
        self.assertNotIn(",-0.0,", text)


@unittest.skipUnless(SLOW, "set GENSTUDIO_E2E_SLOW=1 to run the browser pass")
class BrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = support.Server()
        body = support.payload(cls.server, ["R0", "NG"], DEFS, blended_kwh=0.25, grid_limit=30, reference_grid_limit=30,
                               upgrade_cost=5e6)
        cls.job, cls.status = cls.server.solve(body, 600)

    @classmethod
    def tearDownClass(cls):
        cls.server.close()

    def test_every_view_opens_without_script_errors_or_placeholders(self):
        from playwright.sync_api import sync_playwright
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
            page = browser.new_context(viewport={"width": 1600, "height": 1000}).new_page()
            errors = []
            page.on("pageerror", lambda exc: errors.append(str(exc)))
            page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)
            try:
                page.goto(f"{self.server.base}/?run={self.job}")
                page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
                for view in ("solve", "analyze", "summary", "powerflow", "design", "load"):
                    page.evaluate(f"() => switchView('{view}')")
                    page.wait_for_timeout(2500)
                    text = page.locator(f"#view-{view}").inner_text()
                    for token in ("NaN", "[object Object]", "Infinity"):
                        self.assertNotIn(token, text, f"{view}: {token}")
            finally:
                browser.close()
        self.assertEqual(errors, [])


if __name__ == "__main__":
    unittest.main()
