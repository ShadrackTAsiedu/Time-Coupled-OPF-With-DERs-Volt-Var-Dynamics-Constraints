import unittest

import numpy as np

import generation_app as app
import optimize_generation_mix as model
import scenario_inputs
from test_client_planning import short_data


def build(**extra):
    definition = dict(id="FUEL", technologies=["grid", "diesel"])
    values = dict(horizon_years=1, extended_appraisal=False, microgrid_min_mw=0, microgrid_max_mw=10,
                  grid_limit=100, reactive_enabled=False, carbon_price=0, diesel_confirmed=True,
                  diesel_capex=100, diesel_fom_fraction=.01, diesel_vom=2, diesel_fuel_price=4,
                  diesel_efficiency=.4, diesel_emissions_t_mmbtu=.05)
    values.update(extra)
    payload = dict(values=values, scenarios=["FUEL"], scenario_definitions=[definition], planned_generation=[])
    cfg, names = scenario_inputs.settings(app.settings_for(app.validate_request(payload)["values"]), definition)
    data = short_data()
    load = np.full(288, 3.0)
    load[::24] = 1.0
    data.update(load=load, qmax=load.copy(), qmin=load.copy(), grid_energy=np.full(288, 100.0),
                facility=np.zeros(12), tou=np.zeros(12), fixed=np.zeros(12), heat=np.zeros(288))
    return data, cfg, names


class TechConstraintTests(unittest.TestCase):
    def test_defaults_off_and_min_load_enforced(self):
        data, cfg, names = build()
        base = model.solve_decomposed(data, "B", "diesel", names, settings=cfg)
        self.assertFalse(cfg["tech_constraints"]["enabled"])
        data, cfg, names = build(diesel_tc_enabled=True, diesel_min_load=.9, diesel_startup=500)
        solved = model.solve_decomposed(data, "C", "diesel", names, settings=cfg)
        gen = solved["dispatch"]["gen"]
        commit = solved["dispatch"]["commit_diesel"]
        self.assertTrue((gen >= .9 * commit - 1e-6).all())
        self.assertGreaterEqual(solved["economics"]["npc"], base["economics"]["npc"] - 1)
        self.assertIn("start_diesel", solved["dispatch"])

    def test_export_earns_revenue(self):
        data, cfg, names = build(export_enabled=True, export_limit_mw=2, export_price=150)
        solved = model.solve_decomposed(data, "E", "diesel", names, settings=cfg)
        exported = solved["dispatch"]["export"]
        self.assertGreater(exported.sum(), 0)
        self.assertLessEqual(exported.max(), 2 + 1e-6)
        self.assertLess(solved["validation"]["hourly_balance_error_mw"], 5e-5)


if __name__ == "__main__":
    unittest.main()
