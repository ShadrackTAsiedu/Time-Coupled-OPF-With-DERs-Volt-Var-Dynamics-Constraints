"""Incremental project cashflows and served-energy supply-cost analysis."""

import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import numpy as np
from docx import Document
from docx.shared import Inches
from openpyxl import Workbook

import economic_metrics


def payback(cashflows, rate=0):
    """Years until the cumulative (discounted) cashflow becomes and stays non-negative; None if never."""
    return economic_metrics.payback(cashflows, rate)[0]


def incremental_metrics(cashflows, discount):
    values = np.array(cashflows, dtype=float)
    npv = economic_metrics.npv(values, discount)
    irr, reason = economic_metrics.solve_irr(values)
    if reason.startswith("Multiple IRRs"):
        irr, reason = None, reason.split(";")[0] + "; no single IRR reported."
    return dict(npv=npv, irr=irr, irr_note=reason, simple_payback_years=payback(values),
                discounted_payback_years=payback(values, discount))


def analyze(results, values):
    baseline = values.get("_comparison_reference", "R0")
    reference = next((r for r in results if r["code"] == baseline and
                      not r["adequacy"]["unserved_hours"] and
                      r["adequacy"]["stress_unserved_mwh"] <= 5e-5), None)
    discount = values["discount"]
    rows = []
    for result in results:
        econ = result["economics"]
        annual = econ["annual"]
        capex = econ["capex"] + econ["upgrade_pv"]
        served_pv = sum(a["served_mwh"] / (1 + discount)**(i + 1) for i, a in enumerate(annual))
        adequate = result["adequacy"]["unserved_hours"] == 0 and result["adequacy"]["stress_unserved_mwh"] <= 5e-5
        eligible = reference is not None and adequate and result["code"] != baseline
        cashflows = None
        metrics = dict(npv=None, irr=None, irr_note="Reference / no comparable fully supplied reference.",
                       simple_payback_years=None, discounted_payback_years=None,
                       investment=None, op_npv=None, op_irr=None, op_simple_payback_years=None)
        if eligible:
            ref = reference["economics"]
            cashflows = [ref["capex"] + ref["upgrade_pv"] - capex] + [
                ra.get("total_cash_cost", ra["net_opex"]) - a.get("total_cash_cost", a["net_opex"])
                for ra, a in zip(ref["annual"], annual)]
            metrics = incremental_metrics(cashflows, discount)
            if abs(metrics["npv"] - (ref["npc"] - econ["npc"])) > 1:
                raise RuntimeError("Incremental NPV and lifecycle-cost difference disagree.")
            operating = economic_metrics.metrics([-capex] + cashflows[1:], discount)
            metrics.update(investment=capex - ref["capex"] - ref["upgrade_pv"], op_npv=operating["npv"], op_irr=operating["irr"],
                           op_simple_payback_years=operating["simple_payback_years"])
            op_irr, op_pb = operating["irr"], operating["simple_payback_years"]
            metrics["irr_note"] = (metrics["irr_note"] + " " if metrics["irr_note"] else "") + (
                "Operating-savings basis: IRR " + (f"{100 * op_irr:,.2f}%" if op_irr is not None else
                                                   f"not defined ({operating['irr_note']})") + ", simple payback " +
                (f"{op_pb:,.2f} years." if op_pb is not None else "not within the horizon."))
        elif not adequate:
            metrics["irr_note"] = "Unserved demand: incremental investment metrics withheld (unequal service)."
        direct = sum(a["direct_gen_co2_t"] for a in annual)
        grid = sum(a["grid_co2_t"] or 0 for a in annual)
        hydrogen = sum(a["hydrogen_upstream_co2e_t"] or 0 for a in annual)
        factors_confirmed = values.get("emission_factors_confirmed", False)
        rows.append(dict(id=result["code"], name=result["name"], adequate=adequate,
                         npc_usd=econ["npc"], lcoe_usd_mwh=econ["npc"] / served_pv if served_pv > 1e-9 else None,
                         lcoe_basis="Whole-system discounted cash cost / discounted served net electrical load",
                         direct_generator_co2_t=direct,
                         grid_co2e_t=grid if factors_confirmed else None,
                         hydrogen_upstream_co2e_t=hydrogen if factors_confirmed else None,
                         supply_co2e_t=sum(a.get("supply_co2e_t") or 0 for a in annual) if factors_confirmed else None,
                         avoided_boiler_co2_t=sum(a["avoided_boiler_co2_t"] for a in annual),
                         net_after_heat_credit_co2e_t=sum(a.get("net_co2e_after_heat_credit_t") or 0
                                                        for a in annual) if factors_confirmed else None,
                         appraisal_years=len(annual),
                         cashflows=cashflows, **metrics))
    return rows


def publish(folder, results, values):
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FuncFormatter
    import plot_style; plot_style.apply()
    rows = analyze(results, values)
    columns = ["ID", "Cash NPC $m", "Incremental NPV $m", "IRR %", "Simple payback years",
               "Discounted payback years", "Incremental investment $m", "Operating-basis NPV $m", "Operating-basis IRR %",
               "Operating-basis simple payback years", "Levelized supplied electricity $/MWh", "Direct generator CO2 t",
               "Grid CO2e t", "Hydrogen upstream CO2e t", "Total supply CO2e t", "Avoided boiler CO2 t",
               "Net after boiler credit CO2e t", "Notes"]
    def scaled(value, factor):
        return None if value is None else value * factor
    records = [[round(v, 4) if isinstance(v, float) else v for v in (
                r["id"], r["npc_usd"] / 1e6, scaled(r["npv"], 1e-6), scaled(r["irr"], 100), r["simple_payback_years"],
                r["discounted_payback_years"], scaled(r["investment"], 1e-6), scaled(r["op_npv"], 1e-6),
                scaled(r["op_irr"], 100), r["op_simple_payback_years"],
                r["lcoe_usd_mwh"], r["direct_generator_co2_t"],
                r["grid_co2e_t"], r["hydrogen_upstream_co2e_t"], r["supply_co2e_t"],
                r["avoided_boiler_co2_t"], r["net_after_heat_credit_co2e_t"], r["irr_note"])] for r in rows]
    reference_code = values.get("_comparison_reference", "R0") or "no selected baseline"
    statements = [
        f"NPV, IRR and payback use incremental nominal cashflows versus {reference_code}: year 0 is the reference investment "
        "(including any grid upgrade) less the scenario investment; years 1..N are annual operating, fuel, grid, carbon and "
        "replacement savings, discounted at year end. No revenue is assumed.",
        f"Nominal inflation {values['inflation']:.2%}; nominal discount rate {values['discount']:.2%}. "
        "NPV is a present value at the start of the appraisal (year 0).",
        "A positive year-0 amount (avoided upgrade) means immediate payback and no conventional IRR; the operating-basis "
        "columns exclude that credit. IRR is not forced to zero when undefined, and a longer appraisal does not guarantee "
        "an IRR or a payback crossing. Metrics are withheld for scenarios with unequal service (unserved load).",
        "Residual value, incentives, income tax and financing are not included.",
        "Levelized supplied electricity = NPC / discounted served MWh, in nominal $/MWh (a constant nominal price with the "
        "same present value as all costs). It is a whole-system cost including grid imports, not a stand-alone plant LCOE. "
        "The denominator is net served load after efficiency, including supply from cost-excluded planned projects, so this is "
        "a restricted decision boundary rather than a full-site investment LCOE. Shortage cases must not be ranked by LCOE alone.",
        "Emission factors must be confirmed for supply totals; otherwise only direct generator CO2 and avoided boiler CO2 are reported. "
        f"Selected grid factor {values.get('grid_emissions_t_mwh', 0)} t CO2e/MWh; "
        f"hydrogen factor {values.get('h2_emissions_kgco2_kg', 0)} kg CO2e/kg H2. The default grid 0.20 is an analyst "
        "placeholder, not a verified supplier/eGRID value; the default hydrogen 11 is the midpoint of the IEA 10-12 "
        "unabated-natural-gas cradle-to-gate screening range, not delivered clean hydrogen. Hydrogen stack CO2 = 0 does not "
        "establish lifecycle neutrality. Factors are held constant over the appraisal; construction and embodied "
        "emissions and methane leakage beyond the selected factors are not modeled.",
        "Net after boiler credit subtracts the useful-heat displacement of boiler emissions from supply emissions; the common "
        "baseline boiler inventory is not added, so this is a credit-adjusted comparison, not total site emissions.",
        f"Appraisal {len(results[0]['economics']['annual']) if results else 0} years; explicit load forecast "
        f"{values['horizon_years']} years. When the appraisal is longer, final-year gross load and calendar "
        "resource/thermal patterns repeat while all tail years are redispatched with solar degradation, planned "
        "commissioning and escalated costs: a disclosed extrapolation, not a client forecast. Like-for-like replacement "
        "cashflows enter the optimized NPC.",
    ]
    notes = " ".join(statements)
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Economic and carbon analysis"
    sheet.append(columns)
    for record in records:
        sheet.append(record)
    flows = workbook.create_sheet("Incremental cashflows")
    flows.append(["Scenario", "Year index", "Net benefit USD"])
    for row in rows:
        for i, amount in enumerate(row["cashflows"] or []):
            flows.append([row["id"], i, amount])
    sheet = workbook.create_sheet("Method and boundaries")
    for statement in statements:
        sheet.append([statement])
    inputs = workbook.create_sheet("Saved assumptions")
    inputs.append(["Input", "Saved solve value"])
    for key, value in values.items():
        inputs.append([key.lstrip("_"), value if value is None or isinstance(value, (bool, int, float, str)) else json.dumps(value)])
    annual = workbook.create_sheet("Annual supply emissions")
    annual.append(["Scenario", "Year", "Direct generator CO2 t", "Grid CO2e t", "H2 upstream CO2e t",
                   "Supply CO2e t", "Avoided boiler CO2 t", "Net after heat credit CO2e t"])
    for result in results:
        for row in result["economics"]["annual"]:
            enabled = values.get("emission_factors_confirmed", False)
            annual.append([result["code"], row["year"], row["direct_gen_co2_t"],
                row["grid_co2_t"] if enabled else None,
                row["hydrogen_upstream_co2e_t"] if enabled else None,
                row["supply_co2e_t"] if enabled else None, row["avoided_boiler_co2_t"],
                row["net_co2e_after_heat_credit_t"] if enabled else None])
    workbook.save(folder / "economic_analysis.xlsx")
    with (folder / "economic_analysis.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow(columns)
        writer.writerows(records)
    fig, ax = plt.subplots(figsize=(10, 4))
    valid = [r for r in rows if r["lcoe_usd_mwh"] is not None]
    ax.bar([r["id"] for r in valid], [r["lcoe_usd_mwh"] for r in valid],
           color=["#087e8b" if r["adequate"] else "#c66b40" for r in valid])
    base_year = int(values.get("start_year", 2027)) - 1
    ax.set(title="Levelized supplied electricity (orange: unserved load)", ylabel="Nominal $ / discounted MWh served")
    fig.tight_layout()
    fig.savefig(folder / "lcoe_comparison.png", dpi=200)
    plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    comparable = [r for r in rows if r["npv"] is not None]
    axes[0].bar([r["id"] for r in comparable], [r["npv"] / 1e6 for r in comparable], color="#087e8b")
    axes[0].axhline(0, color="gray", lw=.7)
    axes[0].set(title=f"Incremental NPV vs {values.get('_comparison_reference', 'R0') or 'no selected baseline'}",
                ylabel=f"Present value at {base_year}, $ million")
    if values.get("emission_factors_confirmed", False):
        positions = np.arange(len(rows))
        axes[1].bar(positions - .19, [r["supply_co2e_t"] for r in rows], width=.38,
                    color="#77659b", label="Supply")
        axes[1].bar(positions + .19, [r["net_after_heat_credit_co2e_t"] for r in rows], width=.38,
                    color="#218e83", label="After boiler credit")
        axes[1].set(title="Screening CO2e over the appraisal (not total site inventory)", ylabel="tonnes CO2e",
                    xticks=positions, xticklabels=[r["id"] for r in rows])
        axes[1].legend(fontsize=8)
    else:
        axes[1].bar([r["id"] for r in rows], [r["direct_generator_co2_t"] for r in rows], color="#77659b")
        axes[1].set(title="Direct generator CO2 only; supply totals unavailable", ylabel="tonnes CO2")
    axes[1].yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:,.0f}"))
    fig.tight_layout()
    fig.savefig(folder / "economic_carbon_comparison.png", dpi=200)
    plt.close(fig)
    document = Document()
    document.add_heading("Economic and carbon analysis", 0)
    for statement in statements:
        document.add_paragraph(statement, style="List Bullet")
    document.add_paragraph(
        "Emission method reference: https://www.epa.gov/egrid . Hydrogen range reference: "
        "https://www.iea.org/reports/global-hydrogen-review-2024/ghg-emissions-of-hydrogen-and-its-derivatives . "
        "Site-specific factors are unverified; do not interpret screening totals as an audited emissions inventory.")

    def table(title, header, body):
        document.add_heading(title, 1)
        grid = document.add_table(rows=1, cols=len(header))
        grid.style = "Light Grid Accent 1"
        for cell, text in zip(grid.rows[0].cells, header):
            cell.text = text
        for line in body:
            for cell, text in zip(grid.add_row().cells, line):
                cell.text = text
    def show(value, digits=2):
        return "n/a" if value is None else f"{value:,.{digits}f}"
    table("Cost and return (nominal USD)",
          ["Scenario", "Adequate service", "Cash NPC $m", "Incremental NPV $m", "IRR %", "Simple payback yr",
           "Discounted payback yr", "Levelized $/MWh"],
          [[f"{r['id']}: {r['name']}", "yes" if r["adequate"] else "NO", show(r["npc_usd"] / 1e6),
            show(scaled(r["npv"], 1e-6)), show(scaled(r["irr"], 100)), show(r["simple_payback_years"]),
            show(r["discounted_payback_years"]), show(r["lcoe_usd_mwh"])] for r in rows])
    table("Emissions over the appraisal (t)",
          ["Scenario", "Direct generator CO2", "Grid CO2e", "Hydrogen upstream CO2e", "Total supply CO2e",
           "Avoided boiler CO2", "Net after boiler credit CO2e"],
          [[r["id"], show(r["direct_generator_co2_t"], 0), show(r["grid_co2e_t"], 0), show(r["hydrogen_upstream_co2e_t"], 0),
            show(r["supply_co2e_t"], 0), show(r["avoided_boiler_co2_t"], 0), show(r["net_after_heat_credit_co2e_t"], 0)]
           for r in rows])
    notes_rows = [[r["id"], r["irr_note"] or "-"] for r in rows if r["irr_note"]]
    if notes_rows:
        table("IRR and comparability notes", ["Scenario", "Note"], notes_rows)
    for name in ("lcoe_comparison.png", "economic_carbon_comparison.png"):
        document.add_picture(str(folder / name), width=Inches(6.3))
    document.save(folder / "economic_analysis.docx")
    report = dict(columns=columns, rows=records, metrics=rows, notes=notes, saved_assumptions=values,
                  created_utc=datetime.now(timezone.utc).isoformat(),
                  analysis_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  solve_configuration_sha256=hashlib.sha256((folder / "run_configuration.json").read_bytes()).hexdigest()
                  if (folder / "run_configuration.json").exists() else None)
    (folder / "economic_analysis.json").write_text(json.dumps(report, allow_nan=False, indent=2), encoding="utf-8")
    return report
