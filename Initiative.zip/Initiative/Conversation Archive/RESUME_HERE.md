# Generation Planning Studio - continuation notes

Saved October 14, 2026. The adjacent timestamped backup contains the session event
history, existing checkpoints and session attachments. Earlier conversation turns
may be represented by a checkpoint summary rather than verbatim text if they had
already been compacted. The Copilot app also retains the original session.

## Reopen the application

Project: `C:\Projects\Demand\Demand Profile`

Double-click `Launch Generation Planner.cmd`, or run:

`py -3 generation_app.py --open-browser`

Latest complete ten-year comparison:

http://127.0.0.1:8765/?run=a0296ee460514e4390a9b9c8215a6adf

Its inputs and outputs are in:

`Application Runs\a0296ee460514e4390a9b9c8215a6adf`

This demonstration uses a deliberately constrained **10 MW grid limit**, not the
original 40 MW limit. Change it in the interface and SOLVE for another case.

## Current behavior and decisions

- Editable categorized demand, tariff, finance, solar, BESS, hydrogen, natural-gas,
  heat and carbon assumptions. Separate solar/BESS acreage constraints require
  explicit site footprint factors; no land layout is invented.
- R0 is **grid alone with upgrade**, automatically sized to at least the projected
  maximum, with the editable $70m upgrade cost. It serves all projected demand.
  Alternatives do not upgrade and obey the selected grid limit.
- Alternatives return shortages rather than failing solely for unserved demand:
  hourly MW, total/annual MWh, affected hours and served percentage. Shortage
  cases are not presented as equivalent-service cost savings.
- A $100million/MWh numerical shortage priority strongly favors adequacy. It is
  not customer VOLL or a cash expenditure and is excluded from cash NPC.
  It is a finite priority, not an exact lexicographic adequacy proof.
- Horizon is 1-15 years from 2027; planning hours, leap years, LP months, annual
  cashflows, yearly graphs, Word and Excel outputs follow it.
- Five growth methods: concave quadratic, linear, compound/exponential, convex
  quadratic, smoothstep. Growth multiplies every hourly mean/minimum/maximum.
- Historical shape can be learned from month/weekday/hour means or replayed by
  month/day/hour. One historical year does not establish a long-term trend.
- Demand uploads accept canonical MW hourly/quarter-hour CSV or the original
  monthly utility kW files selected together. Historical coverage must span a
  full calendar or rolling year. Full projected inputs bypass growth modeling.
- Yearly demand plots share a vertical axis and show a baseline overlay.
  Annual audit tables include minimum, mean, maximum, energy and growth factor.
- SOLVE writes graphical results, Word documentation, Excel results and complete
  hourly load/dispatch/shortage CSVs in independent run directories.
- The PR case forces zero solar for 72 consecutive hours near the final-year
  peak. Grid remains available at the selected limit; BESS may recharge from
  spare grid capacity. This is NOT a grid-outage backup requirement.
  Any residual stress shortage is disclosed, not silently treated as a pass.
- Battery remains monthly cyclic at 50% SOC; continuous capacities/full
  foresight, no unit commitment or forced outages. Solar weather and thermal
  loads remain screening assumptions unless uploaded.
- Thermal demand assumption: mean 5 MWth, 80% displaced gas boiler efficiency.
  Useful concurrent CHP heat earns avoided fuel/carbon credit. Boiler
  electrification may invalidate future heat benefits.
- Grid base energy component approximately $124.91/MWh summer and $126.77/MWh
  winter, including delivery and modeled delivery tax, PLUS demand/fixed charges.
  Missing retailer supply price is assumed $80/MWh. Escalation 3%, discount 6%.

## Main files

- `generation_app.py`: local server, inputs, runs and report exports.
- `demand_forecasting.py`: import, historical shape learning and all-hour growth.
- `optimize_generation_mix.py`: original study plus configurable monthly
  decomposition engine. Old standalone behavior remains distinct from app settings.
- `generation_ui\index.html`, `app.js`, `app.css`: user interface.
- `GENERATION_APP_README.md`: application instructions, formulas and limitations.
- `test_generation_app.py`, `test_generation_optimization.py`: regression coverage.
- `Generation Optimization Results`: original audited study, unchanged.
- `Application Runs`: exact requests, resolved settings, input/code hashes,
  validation, graphical outputs, Word/Excel/CSV reports.

Regression command:

`py -3 -m unittest test_generation_optimization.py test_generation_app.py -v`

Fourteen tests passed at the last check. Browser checks covered raw monthly-file
upload, 2-year and 10-year solves, zero/low grid limits, full-supply reference,
shortage reporting, dynamic planning-hour headers and Word/Excel downloads.

## Next action

No implementation request is pending. The user asked to save the conversation
and resume work on this application later. Preserve all source data and prior
saved runs. This is a folder-backed project without git version control.
