﻿# GenStudio – Handoff for a new machine / new AI session

Tell the assistant: "Read `Project Handoff\HANDOFF.md`, then the newest files in `Project Handoff\checkpoints\`, and continue development."

## What it is
Local Windows app (Python backend `generation_app.py`, browser UI in `generation_ui\`, HiGHS LP/MIP, optional Gurobi).
Hourly demand forecasting, least-cost microgrid optimization, financial/carbon analysis, SLD topology, AC power flow
with PSS/E RAW export, design, reliability, sensitivity, client report. Version in `version.py`.

## Setup on a new computer
1. Install Python 3.12+ and run `pip install -r requirements.txt` (dev/test: `requirements-dev.txt`).
2. Start with `GenStudio.cmd` (or `py -3 generation_app.py`), open http://127.0.0.1:8765.
3. Tests: `py -3 -m unittest discover -p "test_*.py"` (~8 min; browser tests need Playwright + Edge; PSS/E tests need PSS/E 35/36 installed, otherwise skip).
4. Copy `Application Runs\` too if you want your saved runs/data (current test run: `7791be18470745f8af5ef34fa3d208f8`).

## Folder contents
- `checkpoints\` – 17+ chronological summaries (decisions, files, bugs, next steps). Start with `index.md` and the last one.
- `session_files\` – retired/backup code and screenshots.
- `full_conversation_events.zip` – raw full conversation log (events.jsonl, ~168 MB unzipped; search it, do not read it whole).

## Executive presentation (PowerPoint)
- 
eport_pptx.py builds an editable 16:9 .pptx (custom master/theme, native charts, tables, shapes, text equations, speaker notes on every slide; SLD as picture) from the same data as the report. Route: POST /api/x/report_pptx; offered in the report dialog (checkbox) and as a button on the summary and best-option card (generation_ui\report.js).
- Needs python-pptx, Pillow, pymupdf (in 
equirements.txt). Tests: 	est_report_pptx.py. Not visually rendered in PowerPoint during development (none installed).

## Key decisions
- Power flow is NOT in the LP: post-solve screening + verified-suggestion correction loop (max 3 iterations).
- Ranking is by plain total NPC; technical PASS/WARN/FAIL is a remark; corrections applied afterwards, then re-solve.
- Economics: net basis and operating-only basis; IRR undefined when multiple sign changes.
- Correction costs: `pf_costs.py` (2024 USD, AACE class 5, hand-calibrated).
- Grid upgrade capex only when load exceeds the grid limit; cost pro-rata (unconfirmed by user).
- No inline scripts/styles or CDNs in UI (strict CSP). No node.js installed.

## Open items (from last audit)
- Gurobi untested with a real licence; island "Invalid dual cut" fix unconfirmed on the user's 26–44 MW data.
- Demand shape calibration unverified on the user's data.
- Spreadsheet-injection helpers (`extensions.safe_cell` etc.) not yet applied to report/sensitivity/reliability/design/power-flow exporters.
- Wire `cost_basis` into `pfpage.js`, `workflow.js` (stale `UNIT_DEFAULTS`), `design.py` (flat $/kvar capacitors).
- Reliability: independent N-1 cross-check, FOR/MTTR source notes. Data-sources: UTC-offset field, attribution text.r reject implausible magnitudes, size limit in `data_prep.py`.
- Screenshot review of input pages, dialogs, topology page, dark mode not done.
- Questions for the user: is $1.37M for a 63 MVA transformer swap too high; pro-rata grid upgrade OK; what was the blank "point 3" in an earlier request.

## Power-flow technical correctness pass (impedance, RAW Q limits, pf concept, auto shunts)

- Per-unit basis: Zpu = Z_ohm x 100 / kV^2 (system base 100 MVA; PF page "per_unit_basis" row). The user's 11 kV, 1.5 km 185 mm2 Al cable (0.211+j0.102 ohm/km, design.CABLES) = 0.26+j0.13 pu on 100 MVA but only ~1.3% on its own 4.8 MVA rating; verified not mis-scaled (design.py and power_flow.py use the same formula). Stored drawings with length 0 are ties (no impedance); impedance in the Design RAW comes from design.CABLES (IEC 60287 style 3-core XLPE).
- C:\Projects\Demand\data.xlsx (sheet Impedance, 397 MV cable sections, Al 1/0 AWG - 1500 kcmil; voltage class and Rate units are not stated) was used as a cross-check: R1 matches our r for equal copper area (4/0 AWG 0.30 vs 95 mm2 0.41; 500 kcmil 0.13 vs 240 mm2 0.16 ohm/km); its X1 0.15-0.18 ohm/km (single-core, flat) is ~1.5x our 3-core x (0.09-0.11); B 58-120 uS/km brackets ours. Defaults were therefore NOT made more impedant (they are not "huge"); the sensitivity run with cable x = 0.16 changed nothing on P1/H2/NG because the stored drawings are ties. Standards used: IEC 60287, IEC 60076-1/-5 (transformer Z, short circuit), IEC 60909 (grid fault level), IEEE 399 (Brown Book), IEEE 141, IEEE C57.12.10, IEEE 1547-2018 / 2800-2022 (IBR Q capability), ANSI C84.1 (0.95-1.05 normal, Range B emergency), IEC 60038. Listed in the PF page Assumptions panel.
- Q limits: every machine, idle or not, keeps its capability in the RAW. IBRs (PV/BESS/wind): Qmax/Qmin = +-sqrt(S^2 - P^2), S = MW / pf = MBASE, so S at zero MW (not zero). Idle synchronous sets are written out of service (status 0, bus type 1 if no other in-service unit) with nameplate Qmax/Qmin = MW x tan(acos(pf)). The solver uses the same limits (pinning only when hi == lo). PSS/E read-back test: test_psse_roundtrip.test_machine_q_limits_and_mbase_read_back_from_psse_even_when_idle (psse_check now returns qmax/qmin/mbase/pmax per machine). ZSORCE 0.909 (inverter Norton equivalent, 1/1.1 pu) does not affect load flow.
- pf concept: one unit "Operating power factor" (default 0.9) drives MBASE, Qmax/Qmin and the technical check. The old "pf of control" is only a set-point used when Reactive control = pf, defaults to the unit pf and is hidden otherwise.
- Auto-sized shunts: apply_shunt writes a separate shunt node flagged electrical.shunt_auto (label "... (auto-sized)", tag "Auto-sized by technical check"); a user entry in the dialog sets shunt_user. On load (power_flow._migrate_stale_auto_shunts, in memory only, run folders untouched) any stored bus-level capacitive shunt without shunt_user is ignored as a stale automatic sizing (this removed P1's 9.6 Mvar on every bus). With these gone and idle IBRs providing Q, P1/H2/NG pass with no bank. NOT done: emitting auto banks as PSS/E switched-shunt records (still fixed shunt block).

## Operating power factor and cost basis (unit_pf.py)

- Per-technology inputs <tech>_pf (default 0.9, 0.8-1.0 validated, lagging/exporting) and <tech>_pf_lead for PV, BESS, wind and each genset. MW capacity is the active rating at that pf; the unit is built in MVA = MW / pf; Qmax = MW x tan(acos(pf)).
- Cost basis input cost_basis: per_mw_at_pf (default, entered $/MW already at the stated pf, no uplift) or per_mva (effective $/MW = entered / pf for capex, fixed O&M, BESS power capex; applied once in generation_app.scale_cost_basis inside settings_for, so optimizer, lifecycle, sensitivity and reports share it). Variable cost stays per MWh.
- Old runs missing the fields: pf reads 0.9 for reactive capability, basis per_mw_at_pf, so costs and optimizer results are identical.
- power_flow.py: all non-grid gens are voltage-controlled within pf-derived Q limits (PQ switching), RAW MBASE = MVA, PMAX = MW, QT/QB from pf; size_shunt sizes only the remaining deficit after generator Q and adds a Reason note. design.py uses the same pf per group (MVA, RAW, equipment rows).
- P1/H2/NG autoshunt bank: pf1.0 7.2/9.6/9.6 Mvar -> pf0.9 5.4/8.4/8.4 Mvar (plants are small vs load; deficit is mostly grid-side).
- The 42/18/32 violations were PRE-compensation: workflow.check_results applied autoshunt but kept the first screening. It now re-screens after compensation and stores before_compensation {status, violations, shunt_mvar}; cost still priced once from the pre-compensation status. P1's stored drawing also held stale 9.6 Mvar caps on every bus (overvoltage 1.07-1.10 pu); autoshunt replaces them with one MV bank. After: 0 violations, PASS in all 7 cases (peak, min, max solar/wind, BESS charge, BESS discharge, grid import, genset max) for P1/H2/NG; Vmin 0.956-0.967, Vmax <=1.0 at light load. Limits unchanged (0.95-1.05, N-1 0.90-1.10).
- Done: derived MVA/Mvar hint in form, planned/existing entry pf (validated, used by design.py), report/pptx MVA + statement, PF page Rated MVA column, tests test_unit_pf / test_unit_pf_browser.
- Caveats: planned-entry pf is design-only (PF solver reads request pf); shunt sized from worst case incl. min-load Vmax cap, fixed (not stepped per hour); per-MVA PV scaling uses AC=DC MW.

