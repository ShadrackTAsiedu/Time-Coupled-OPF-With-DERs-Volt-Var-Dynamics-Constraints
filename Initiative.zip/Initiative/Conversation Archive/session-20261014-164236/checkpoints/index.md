# Checkpoint History

Checkpoints are listed in chronological order. Checkpoint 1 is the oldest, higher numbers are more recent.

| # | Title | File |
|---|-------|------|
| 1 | Chronological generation mix optimization | 001-chronological-generation-mix-o.md |
