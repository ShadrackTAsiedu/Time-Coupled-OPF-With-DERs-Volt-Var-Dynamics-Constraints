import json
import re
import unittest
from pathlib import Path

import extensions
import network_topology
import power_flow as pf
import shutil
from test_power_flow import ScreeningTests, diagram, SCRATCH

HERE = Path(__file__).resolve().parent
UI = HERE / "generation_ui"
NODES = [("g", "grid"), ("b", "bus"), ("l", "load"), ("pv", "pv")]
LINES = [("w1", "g", "b", 0), ("w2", "b", "l", 0), ("w3", "pv", "b", 0)]


def bus_rows(text):
    return [l for l in text.split("END OF BUS DATA")[0].splitlines()[3:] if "'" in l]


class FixtureMixin(unittest.TestCase):
    code = "S1"
    make_run = ScreeningTests.make_run
    def run_id(self):
        return "a" * 32

    def setUp(self):
        shutil.rmtree(SCRATCH, ignore_errors=True)
        SCRATCH.mkdir()
        self._folder = extensions.run_folder
        self.run_dir = self.make_run(NODES, LINES)
        extensions.run_folder = lambda rid: self.run_dir

    def tearDown(self):
        extensions.run_folder = self._folder
        shutil.rmtree(SCRATCH, ignore_errors=True)

    def edit_request(self, fn):
        path = self.run_dir / "request.json"
        data = json.loads(path.read_text())
        fn(data["topology"])
        path.write_text(json.dumps(data))


class RawExportTests(FixtureMixin):
    def test_names_numbers_and_swing(self):
        long_nodes = [(f"verylongcomponentname{i}", k) for i, k in enumerate(("grid", "bus", "load", "pv"))]
        ids = [n for n, _ in long_nodes]
        diag = diagram(long_nodes, [("w1", ids[0], ids[1], 0), ("w2", ids[1], ids[2], 0), ("w3", ids[3], ids[1], 0)])
        for n in diag["nodes"]:
            n["label"] = "Very long / illegal name!! " + n["id"]
        net = pf.build_network(diag, caps=dict(pv=2.0), peak_load_mw=2.0)
        rows = bus_rows(pf.export_raw(net, dict(load_mw=2.0, gens={})))
        names = [re.search(r"'([^']*)'", l).group(1) for l in rows]
        self.assertEqual(len(names), len(set(names)))
        self.assertTrue(all(len(n) <= 12 and re.fullmatch(r"[A-Z0-9_.\-]+", n) for n in names), names)
        numbers = [int(l.split(",")[0]) for l in rows]
        self.assertEqual(len(numbers), len(set(numbers)))
        self.assertIn("3", [l.split(",")[3].strip() for l in rows], "swing bus (type 3) missing")

    def test_unreachable_bus_is_dropped(self):
        net = pf.build_network(diagram(NODES + [("l2", "load")], LINES), caps=dict(pv=2.0), peak_load_mw=2.0)
        text, notes = pf.export_raw_notes(net, dict(load_mw=2.0, gens={}))
        types = [l.split(",")[3].strip() for l in bus_rows(text)]
        self.assertNotIn("4", types)
        self.assertEqual(len(types), 5)
        self.assertTrue(notes)


class NoDrawingTests(FixtureMixin):
    def test_screen_without_stored_drawing_uses_autodraw(self):
        self.edit_request(lambda t: t["diagrams"].clear())
        report = pf.screen_scenario(self.run_id(), self.code)
        self.assertIn(report["status"], ("PASS", "WARN", "FAIL"))
        self.assertTrue(any("autodraw" in w for w in report["warnings"]))
        stored = json.loads((self.run_dir / "request.json").read_text())["topology"]["diagrams"]
        self.assertNotIn(self.code, stored)

    def test_unwired_duplicate_load_is_dropped_with_note(self):
        self.edit_request(lambda t: t["diagrams"][self.code]["nodes"].append(dict(id="l_extra", kind="load", label="L2", x=900, y=900)))
        report = pf.screen_scenario(self.run_id(), self.code)
        self.assertTrue(any("extra Load" in w for w in report["warnings"]))
        self.assertFalse(any("not connected" in w for w in report["warnings"]))


class ShuntTests(FixtureMixin):
    def test_shunt_node_is_modelled_and_reported(self):
        def add(t):
            d = t["diagrams"][self.code]
            d["nodes"].append(dict(id="sh", kind="shunt", label="Cap", x=900, y=500, electrical=dict(shunt_mvar=2.0)))
            d["lines"].append(dict(id="wsh", source="b", target="sh", owner="shared", length_km=0, cost_per_km=0))
        self.edit_request(add)
        snap = pf._handle(dict(action="snapshot", run_id=self.run_id(), scenario=self.code))
        bus = next(b for b in snap["case"]["buses"] if b["id"] == "b")
        self.assertEqual(bus["shunt_mvar"], 2.0)
        self.assertEqual(bus["shunt_kind"], "capacitor")
        self.assertGreater(bus["shunt_q_mvar"], 0)
        self.assertNotIn("sh", [b["id"] for b in snap["case"]["buses"]])

    def test_size_apply_and_cost(self):
        sized = pf.size_shunt(self.run_id(), self.code)
        for key in ("shunt_mvar", "total_mvar", "steps", "step_mvar", "cost_usd", "suggestion", "vmin_before", "vmin_after"):
            self.assertIn(key, sized)
        if sized["shunt_mvar"]:
            self.assertGreater(sized["cost_usd"], sized["shunt_mvar"] * 1000 * 10)
            self.assertLess(sized["cost_usd"], sized["shunt_mvar"] * 1000 * 80)
        else:  # generators' own reactive capability (operating pf) already meets the target
            self.assertEqual(sized["cost_usd"], 0)
            self.assertTrue(any("No shunt capacitor needed" in n for n in sized["notes"]))
        forced = pf.compliance_cost(self.run_id(), self.code, [dict(id="x", label="x", target=dict(kind="node", key="shunt_mvar", id="b"),
                                                                    current=0.0, suggested=1.2)])
        self.assertGreater(forced["total_usd"], 50000)
        self.assertLess(forced["total_usd"], 150000)
        self.assertIn("cost_basis", forced)
        pf.apply_shunt(self.run_id(), self.code, 1.2, 4, 0.3)
        stored = json.loads((self.run_dir / "request.json").read_text())["topology"]["diagrams"][self.code]
        node = next(n for n in stored["nodes"] if n["kind"] == "shunt")
        self.assertEqual(node["electrical"]["shunt_mvar"], 1.2)
        self.assertEqual(sum(1 for e in stored["lines"] if node["id"] in (e["source"], e["target"])), 1)
        network_topology.validate_diagram(dict(stored, enabled=True), [])
        self.assertAlmostEqual(pf.size_shunt(self.run_id(), self.code)["existing_mvar"], 1.2)


class DualStatusTests(FixtureMixin):
    def test_screen_payload_lists_hours_and_failing_cases(self):
        report = pf.screen_scenario(self.run_id(), self.code)
        self.assertTrue(report["screened"]["hours"])
        self.assertIn("N-1", report["screened"]["text"])
        for row in report["failing_cases"]:
            for key in ("label", "hour_index", "outages", "gens_out", "severity"):
                self.assertIn(key, row)
        if report["failing_cases"]:
            self.assertEqual(report["worst_case"], report["failing_cases"][0])
            row = report["worst_case"]
            snap = pf._handle(dict(action="snapshot", run_id=self.run_id(), scenario=self.code, hour_index=row["hour_index"],
                                   outages=row["outages"], gens_out=row["gens_out"]))
            self.assertIn("case", snap)


class UiSourceTests(unittest.TestCase):
    def test_wheel_zoom_is_non_passive_and_page_cannot_create_scenarios(self):
        js = (UI / "pfpage.js").read_text(encoding="utf-8")
        self.assertRegex(js, r'addEventListener\("wheel"[\s\S]*?\{passive: false\}')
        self.assertIn("preventDefault", js)
        self.assertIn("Selected operating point", js)
        self.assertIn("Overall screening (all cases + N-1)", js)
        for name in ("pfpage.js", "pfprops.js"):
            text = (UI / name).read_text(encoding="utf-8")
            self.assertNotRegex(text, r"newScenario|topology-new|(?i:new scenario)", name)

    def test_figures_use_at_most_four_decimals(self):
        self.assertIn("Math.min(d, 4)", (UI / "pfpage.js").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
