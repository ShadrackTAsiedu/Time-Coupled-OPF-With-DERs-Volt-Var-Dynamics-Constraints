"""Word helpers for the mathematical-model documents: native OMML equations, tables and page chrome."""

from copy import deepcopy

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from lxml import etree


def math_run(text):
    result = OxmlElement("m:r")
    value = OxmlElement("m:t")
    value.text = str(text)
    value.set(qn("xml:space"), "preserve")
    result.append(value)
    return result


def fill(parent, parts):
    if not isinstance(parts, (list, tuple)):
        parts = [parts]
    for item in parts:
        parent.append(deepcopy(item) if isinstance(item, etree._Element) else math_run(item))


def _pair(tag, first, second):
    result = OxmlElement(tag)
    for name, value in (first, second):
        child = OxmlElement(name)
        fill(child, value)
        result.append(child)
    return result


def indexed(base, index):
    return _pair("m:sSub", ("m:e", base), ("m:sub", index))


def power(base, exponent):
    return _pair("m:sSup", ("m:e", base), ("m:sup", exponent))


def fraction(numerator, denominator):
    return _pair("m:f", ("m:num", numerator), ("m:den", denominator))


def total(index, expression):
    result = OxmlElement("m:nary")
    properties = OxmlElement("m:naryPr")
    character = OxmlElement("m:chr")
    character.set(qn("m:val"), "\u2211")
    properties.append(character)
    location = OxmlElement("m:limLoc")
    location.set(qn("m:val"), "subSup")
    properties.append(location)
    hide = OxmlElement("m:supHide")
    hide.set(qn("m:val"), "1")
    properties.append(hide)
    result.append(properties)
    for name, value in (("m:sub", index), ("m:sup", ""), ("m:e", expression)):
        child = OxmlElement(name)
        fill(child, value)
        result.append(child)
    return result


class Report:
    """A Word document with numbered equations; `equations` counts them for post-build verification."""

    def __init__(self):
        self.doc = Document()
        section = self.doc.sections[0]
        section.page_width, section.page_height = Inches(8.5), Inches(11)
        section.top_margin = section.bottom_margin = Inches(.65)
        section.left_margin = section.right_margin = Inches(.7)
        normal = self.doc.styles["Normal"]
        normal.font.name, normal.font.size = "Calibri", Pt(10)
        normal.paragraph_format.space_after = Pt(6)
        for name in ("Heading 1", "Heading 2", "Heading 3"):
            self.doc.styles[name].font.color.rgb = RGBColor.from_string("174F64")
        header = section.header.paragraphs[0]
        header.text = "GENSTUDIO  |  MATHEMATICAL MODEL"
        header.style = self.doc.styles["Caption"]
        footer = section.footer.paragraphs[0]
        footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        footer.add_run("Implementation-specific screening model  |  Page ")
        field = OxmlElement("w:fldSimple")
        field.set(qn("w:instr"), "PAGE")
        footer._p.append(field)
        self.equations = 0

    def heading(self, text, level=1):
        self.doc.add_heading(text, level)

    def paragraph(self, text, bold=False):
        p = self.doc.add_paragraph()
        p.add_run(text).bold = bold
        return p

    def equation(self, *parts):
        self.equations += 1
        p = self.doc.add_paragraph()
        p.paragraph_format.space_before = Pt(5)
        p.paragraph_format.space_after = Pt(7)
        p.paragraph_format.keep_together = True
        block = OxmlElement("m:oMathPara")
        eq = OxmlElement("m:oMath")
        fill(eq, parts)
        fill(eq, ["    (" + str(self.equations) + ")"])
        block.append(eq)
        p._p.append(block)

    def table(self, headers, rows, size=8):
        table = self.doc.add_table(rows=1, cols=len(headers))
        table.style = "Light Shading Accent 1"
        for cell, value in zip(table.rows[0].cells, headers):
            cell.text = str(value)
        table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
        for row in rows:
            cells = table.add_row().cells
            for cell, value in zip(cells, row):
                cell.text = str(value)
        for row in table.rows:
            row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
            for cell in row.cells:
                for p in cell.paragraphs:
                    p.paragraph_format.space_after = Pt(3)
                    for run in p.runs:
                        run.font.size = Pt(size)
        return table
