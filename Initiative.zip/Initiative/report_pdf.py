"""Server-side PDF rendering of the report documents with real page numbers in the contents lists.

The HTML documents carry empty `<span class="pg" data-a="anchor">` placeholders in the table of contents and in the lists
of figures and tables. Browsers cannot fill those in (target-counter is unsupported), so the document is printed with a
headless Edge/Chrome, the page that each anchor lands on is read back from the PDF's internal link destinations, the
numbers are injected into the HTML and the document is printed again until the page numbers stop moving.
"""
import os
import re
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path

MAX_PASSES = 3
TIMEOUT_S = 180
WORK = Path(__file__).resolve().parent / "_pdf_work"

BROWSERS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
]
PLACEHOLDER = re.compile(r'<span class="pg" data-a="([^"]+)">(?:<i></i><b>\d+</b>)?</span>')
PRINT_HIDE = "<style>footer.end{display:none}</style>"


class PdfUnavailable(RuntimeError):
    """Raised when no browser is installed or the browser fails to print."""


def find_browser():
    """Path of an installed Edge/Chrome (GENSTUDIO_BROWSER overrides), or None."""
    candidates = [os.environ.get("GENSTUDIO_BROWSER", "")] + BROWSERS
    candidates += [shutil.which(name) or "" for name in ("msedge", "chrome", "google-chrome", "chromium")]
    return next((c for c in candidates if c and Path(c).is_file()), None)


def available():
    return find_browser() is not None


def print_pdf(html, browser=None):
    """Print an HTML string to A4 PDF bytes with headless Edge/Chrome (the page's own @page margin boxes give header and footer)."""
    browser = browser or find_browser()
    if not browser:
        raise PdfUnavailable("No Edge or Chrome browser was found on this computer, so the PDF could not be created. Download the HTML report and print it from a browser.")
    WORK.mkdir(exist_ok=True)
    job = WORK / uuid.uuid4().hex
    job.mkdir()
    try:
        source, target = job / "report.html", job / "report.pdf"
        source.write_text(html, encoding="utf-8")
        command = [browser, "--headless=new", "--disable-gpu", "--no-pdf-header-footer", "--no-first-run", "--no-default-browser-check",
                   f"--user-data-dir={job / 'profile'}", f"--print-to-pdf={target}", source.as_uri()]
        try:
            subprocess.run(command, capture_output=True, timeout=TIMEOUT_S, check=False)
        except subprocess.TimeoutExpired as exc:
            raise PdfUnavailable("The browser took too long to print the report.") from exc
        if not target.is_file() or target.stat().st_size == 0:
            raise PdfUnavailable("The browser did not produce a PDF.")
        return target.read_bytes()
    finally:
        shutil.rmtree(job, ignore_errors=True)
        try:
            WORK.rmdir()
        except OSError:
            pass


def anchor_pages(pdf, anchors):
    """1-based page of each anchor id, from the PDF named destinations created for the document's internal links."""
    import pymupdf
    with pymupdf.open(stream=pdf, filetype="pdf") as doc:
        names = doc.resolve_names()
        pages = {}
        for name in anchors:
            target = names.get(name)
            if target and target.get("page") is not None:
                pages[name] = int(target["page"]) + 1
        for page in doc:
            for link in page.get_links():
                name = link.get("nameddest") or ""
                if name in anchors and name not in pages and link.get("page", -1) >= 0:
                    pages[name] = int(link["page"]) + 1
    return pages


def inject_pages(html, pages):
    """Fill every contents placeholder with a dotted leader and its page number; unknown anchors stay empty."""
    def fill(match):
        number = pages.get(match.group(1))
        body = f"<i></i><b>{number}</b>" if number else ""
        return f'<span class="pg" data-a="{match.group(1)}">{body}</span>'
    return PLACEHOLDER.sub(fill, html)


def render(html, passes=MAX_PASSES):
    """PDF bytes of `html` whose contents lists show the real page numbers (stable once the numbers stop moving)."""
    anchors = set(PLACEHOLDER.findall(html))
    html = html.replace("</head>", PRINT_HIDE + "</head>", 1)
    pdf = print_pdf(html)
    if not anchors:
        return pdf
    pages = {}
    for _ in range(max(1, passes)):
        found = anchor_pages(pdf, anchors)
        if found == pages:
            break
        pages = found
        pdf = print_pdf(inject_pages(html, pages))
    return pdf
