"""Public data connector tests: the network is always mocked (datasources._urlopen is replaced)."""

import gzip
import io
import json
import re
import shutil
import struct
import tempfile
import zlib
import unittest
import urllib.error
import urllib.parse
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np

import datasources as ds
import demand_forecasting
import extensions
import resource_profiles

HERE = Path(__file__).resolve().parent
def _png():
    def chunk(tag, data):
        body = tag + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body))
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(b"\x00\xcc\xdd\xee")) + chunk(b"IEND", b""))


PNG = _png()


class Response(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class Net:
    """Routes URLs to canned responses and records every call."""

    def __init__(self):
        self.calls, self.routes = [], []

    def add(self, pattern, body):
        self.routes.append((re.compile(pattern), body))

    def __call__(self, request, timeout=None):
        url = request.full_url if hasattr(request, "full_url") else request
        self.calls.append((url, dict(request.header_items()) if hasattr(request, "header_items") else {}))
        for pattern, body in self.routes:
            if pattern.search(url):
                value = body(url) if callable(body) else body
                if isinstance(value, Exception):
                    raise value
                return Response(value if isinstance(value, bytes) else json.dumps(value).encode())
        raise AssertionError("unexpected URL " + url)


SOLAR_HEADER = "timestamp,ghi_w_m2,dni_w_m2,dhi_w_m2,temperature_c,wind_speed_10m_ms"
SOLAR_HEADER_GHI = "timestamp,ghi_w_m2,temperature_c,wind_speed_10m_ms"
SOLAR_HEADER_POA = "timestamp,poa_irradiance_w_m2,temperature_c,wind_speed_10m_ms"


def nasa_body(url, ghi=500.0, dni=700.0, dhi=100.0, temp=20.0, ws10=5.0, ws50=8.0, hole=None, ps=None):
    query = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
    start = datetime.strptime(query["start"][0], "%Y%m%d")
    end = datetime.strptime(query["end"][0], "%Y%m%d") + timedelta(hours=23)
    keys, t = [], start
    while t <= end:
        keys.append(t.strftime("%Y%m%d%H"))
        t += timedelta(hours=1)
    def series(value):
        return {k: (-999.0 if hole and i in hole else value) for i, k in enumerate(keys)}
    parameter = {
        "ALLSKY_SFC_SW_DWN": series(ghi), "ALLSKY_SFC_SW_DNI": series(dni), "ALLSKY_SFC_SW_DIFF": series(dhi),
        "T2M": series(temp), "WS10M": series(ws10), "WS50M": series(ws50)}
    if ps is not None:
        parameter["PS"] = series(ps)
    return {"header": {"fill_value": -999.0}, "properties": {"parameter": parameter}}


def pvgis_body(url):
    query = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
    first, last = int(query["startyear"][0]), int(query["endyear"][0])
    rows, t = [], datetime(first, 1, 1, 0, 30)
    while t.year <= last:
        rows.append({"time": t.strftime("%Y%m%d:%H%M"), "P": 500.0, "G(i)": 600.0, "H_sun": 10.0, "T2m": 10.0, "WS10m": 4.0})
        t += timedelta(hours=1)
    return {"outputs": {"hourly": rows}}


def tmy_body(url):
    rows, t = [], datetime(2005, 1, 1)
    while len(rows) < 8760:
        if not (t.month == 2 and t.day == 29):
            rows.append({"time(UTC)": t.strftime("%Y%m%d:%H10"), "T2m": float(t.hour), "G(h)": 100.0, "Gb(n)": 200.0, "Gd(h)": 50.0, "WS10m": 3.0})
        t += timedelta(hours=1)
    return {"inputs": {"location": {"irradiance_time_offset": 0.17}}, "outputs": {"tmy_hourly": rows}}


class DatasourceBase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(dir=HERE, prefix="_ds_test_"))
        self._old = ds.CACHE, ds._urlopen, ds.RETRY_DELAYS
        ds.CACHE = self.tmp
        ds.RETRY_DELAYS = ()
        self.net = Net()
        ds._urlopen = self.net
        ds._tile_log.clear()

    def tearDown(self):
        ds.CACHE, ds._urlopen, ds.RETRY_DELAYS = self._old
        shutil.rmtree(self.tmp, ignore_errors=True)

    def build(self, kind, **payload):
        return ds.BUILDERS[kind](dict(payload), lambda message, fraction: None, False)

    def check_solar_file(self, file, kind="solar"):
        dates = [datetime(2031, 7, 4, 12), datetime(2032, 2, 29, 0)]
        return resource_profiles.read_profile(file, dates, "ghi" if kind == "solar" else kind)


class PhysicsTests(unittest.TestCase):
    def test_pv_temperature_derate_hand_value(self):
        out = ds.pv_unit_output(np.array([800.0]), np.array([20.0]), np.array([0.0]), True, -0.0035, 0.0)
        # Tcell = 20 + 800/25 = 52 C -> 0.8 * (1 - 0.0035 * 27) = 0.72440
        self.assertAlmostEqual(float(out[0]), 0.8 * (1 - 0.0035 * 27), places=6)
        self.assertAlmostEqual(float(ds.pv_unit_output(np.array([800.0]), np.array([20.0]), np.array([0.0]), False)[0]), 0.8)
        self.assertAlmostEqual(float(ds.pv_unit_output(np.array([1000.0]), np.array([25.0]), np.array([0.0]), False, losses_pct=10)[0]), 0.9)

    def test_horizontal_plane_poa_is_ghi(self):
        times = np.array(["2024-03-20T12"], dtype="datetime64[h]")
        poa, cosz = ds.poa_irradiance(times, 0.0, 0.0, np.array([900.0]), np.array([800.0]), np.array([100.0]), 0.0, 180.0)
        self.assertGreater(float(cosz[0]), 0.99)
        self.assertAlmostEqual(float(poa[0]), 900.0, delta=15)

    def test_night_has_no_irradiance(self):
        times = np.array(["2024-06-21T00"], dtype="datetime64[h]")
        poa, _ = ds.poa_irradiance(times, 34.0, 0.0, np.array([0.0]), np.array([0.0]), np.array([0.0]), 30.0, 180.0)
        self.assertEqual(float(poa[0]), 0.0)

    def test_tracking_collects_more_than_flat_in_the_morning(self):
        times = np.array(["2024-06-21T08"], dtype="datetime64[h]")
        args = (times, 35.0, 0.0, np.array([400.0]), np.array([600.0]), np.array([80.0]))
        flat, _ = ds.poa_irradiance(*args, 0.0, 180.0)
        tracked, _ = ds.poa_irradiance(*args, 0.0, 180.0, tracking="two_axis")
        self.assertGreater(float(tracked[0]), float(flat[0]))
        with self.assertRaises(ValueError):
            ds.poa_irradiance(*args, 0.0, 180.0, tracking="bogus")

    def test_wind_power_curve_and_shear(self):
        v = np.array([2.0, 3.0, 7.75, 11.0, 12.5, 20.0, 26.0])
        out = ds.turbine_power(v, "iec1")
        # class I: cut-in 3, rated 12.5: (7.75^3 - 27) / (12.5^3 - 27)
        self.assertAlmostEqual(float(out[2]), (7.75 ** 3 - 27) / (12.5 ** 3 - 27), places=6)
        self.assertEqual(list(out[[0, 1, 4, 5, 6]].round(6)), [0.0, 0.0, 1.0, 1.0, 0.0])
        self.assertTrue(np.all((out >= 0) & (out <= 1)))
        self.assertAlmostEqual(float(ds.wind_hub_speed(np.array([8.0]), 50.0, 100.0, "power", 1 / 7)[0]), 8.0 * 2 ** (1 / 7), places=6)
        self.assertAlmostEqual(float(ds.wind_hub_speed(np.array([8.0]), 50.0, 100.0, "log", z0=0.03)[0]), 8.0 * np.log(100 / .03) / np.log(50 / .03), places=6)
        two = ds.wind_hub_speed(np.array([8.0]), 50.0, 100.0, "two_height", ws_lower=np.array([4.0]), lower_height=10.0)
        self.assertGreater(float(two[0]), 8.0)
        with self.assertRaises(ValueError):
            ds.turbine_power(v, "nope")

    def test_air_density_and_speed_equivalent(self):
        self.assertAlmostEqual(float(ds.air_density(np.array([15.0]), np.array([101.325]), 2.0)[0]), 1.225, delta=0.002)
        thin = float(ds.air_density(np.array([15.0]), np.array([80.0]), 2.0)[0])
        self.assertLess(thin, 1.0)
        equivalent = float(ds.density_adjusted_speed(np.array([10.0]), np.array([thin]))[0])
        self.assertAlmostEqual(equivalent, 10.0 * (thin / 1.225) ** (1 / 3), places=6)
        self.assertAlmostEqual(ds.isa_pressure_kpa(0.0), 101.325, places=3)
        self.assertLess(ds.isa_pressure_kpa(1500.0), 86.0)

    def test_pvwatts_module_type_and_leap_label(self):
        self.assertEqual([ds._pvwatts_module_type(g) for g in (-0.5, -0.35, -0.2)], [0, 1, 2])
        self.assertTrue(ds._is_leap_day("20240229:0010"))
        self.assertFalse(ds._is_leap_day("20240228:0010"))

    def test_thermal_proxy_and_calendar_remap(self):
        out = ds.thermal_proxy(np.array([20.0, 15.0, 0.0, -10.0]), "heating", 15.0, 0.0, 0.1, 2.0)
        np.testing.assert_allclose(out, [0.2, 0.2, 2.0, 2.0])
        values = np.arange(8760, dtype=float)
        leap = ds.remap_calendar(values, 2025, 2024, align_weekdays=False)
        self.assertEqual(len(leap), 8784)
        np.testing.assert_allclose(leap[(31 + 28) * 24:(31 + 29) * 24], leap[(31 + 27) * 24:(31 + 28) * 24])  # Feb 29 repeats Feb 28

    def test_typical_load_is_normalised(self):
        times = ds.year_grid(2025, 2025)
        load = ds.typical_load({"office": 1, "retail": 1}, times, np.full(len(times), 20.0))
        self.assertAlmostEqual(float(load.max()), 1.0)
        self.assertGreater(float(load.min()), 0.0)


class ValidationTests(DatasourceBase):
    def test_tile_rejects_bad_arguments(self):
        for q in ({"z": ["3"], "x": ["1"]}, {"z": ["abc"], "x": ["1"], "y": ["1"]}, {"z": ["20"], "x": ["0"], "y": ["0"]},
                  {"z": ["3"], "x": ["8"], "y": ["0"]}, {"z": ["3"], "x": ["-1"], "y": ["0"]},
                  {"z": ["3"], "x": ["../../etc"], "y": ["0"]}, {"z": ["3"], "x": ["1.5"], "y": ["0"]},
                  {"z": ["3"], "x": ["1", "2"], "y": ["0"]}, {"z": ["99999999999"], "x": ["0"], "y": ["0"]}):
            with self.assertRaises(ValueError, msg=str(q)):
                ds.tile(q)
        self.assertEqual(self.net.calls, [])

    def test_tile_fetch_cache_and_user_agent(self):
        self.net.add(r"tile\.openstreetmap\.org/3/1/2\.png", PNG)
        body, mime = ds.tile({"z": ["3"], "x": ["1"], "y": ["2"]})
        self.assertEqual((body, mime), (PNG, "image/png"))
        self.assertIn("GenStudio", self.net.calls[0][1]["User-agent"])
        ds.tile({"z": ["3"], "x": ["1"], "y": ["2"]})
        self.assertEqual(len(self.net.calls), 1)   # second request served from disk
        self.assertTrue((self.tmp / "tiles" / "3" / "1" / "2.png").is_file())

    def test_tile_failure_returns_placeholder_not_error(self):
        self.net.add(r"tile\.openstreetmap\.org", urllib.error.URLError("offline"))
        body, mime = ds.tile({"z": ["2"], "x": ["0"], "y": ["0"]})
        self.assertEqual(body[:8], b"\x89PNG\r\n\x1a\n")
        self.assertFalse((self.tmp / "tiles" / "2" / "0" / "0.png").exists())

    def test_tile_upstream_rate_limit(self):
        self.net.add(r"tile\.openstreetmap\.org", PNG)
        for i in range(200):
            ds._tile_log.append(__import__("time").monotonic())
        body, _ = ds.tile({"z": ["4"], "x": ["1"], "y": ["1"]})
        self.assertNotEqual(body, PNG)
        self.assertEqual(self.net.calls, [])

    def test_geocode_validation_parse_and_cache(self):
        for q in ({}, {"q": [""]}, {"q": ["a"]}, {"q": ["x" * 201]}, {"q": ["bad\x00name"]}):
            with self.assertRaises(ValueError):
                ds.geocode(q)
        self.net.add(r"nominatim\.openstreetmap\.org", [{"lat": "34.05", "lon": "-118.24", "display_name": "Los Angeles, CA", "type": "city",
                                                         "boundingbox": ["33.7", "34.3", "-118.6", "-118.1"], "address": {"state": "California"}},
                                                        {"lat": "bad", "lon": "1"}])
        ds._geo_last[0] = -10
        found = ds.geocode({"q": ["Los  Angeles"]})
        self.assertEqual(len(found["results"]), 1)
        self.assertAlmostEqual(found["results"][0]["lat"], 34.05)
        self.assertIn("openstreetmap", found["attribution"].lower())
        self.assertEqual(ds.geocode({"q": ["los angeles"]}), found)
        self.assertEqual(len(self.net.calls), 1)
        self.assertIn("GenStudio", self.net.calls[0][1]["User-agent"])

    def test_locate_and_coordinates_validation(self):
        self.net.add(r"geo\.fcc\.gov", {"County": {"FIPS": "06037", "name": "Los Angeles County"}, "State": {"code": "CA", "name": "California"}})
        info = ds.locate({"lat": ["34.05"], "lon": ["-118.24"]})
        self.assertEqual((info["county_fips"], info["state"], info["default_utc_offset"]), ("06037", "CA", -8))
        for q in ({"lat": ["91"], "lon": ["0"]}, {"lat": ["x"], "lon": ["0"]}, {"lat": ["0"]}, {"lat": ["nan"], "lon": ["0"]}):
            with self.assertRaises(ValueError):
                ds.locate(q)

    def test_dataset_file_name_validation(self):
        for name in ("../secret.csv", "a/b.csv", "x.exe", "", "..\\x.csv"):
            with self.assertRaises(ValueError):
                ds.dataset_file({"name": [name]})
        with self.assertRaises(ValueError):
            ds.dataset_file({"name": ["missing.csv"]})

    def test_routes_registered(self):
        for name in ("tile", "geocode", "ds_locate", "ds_catalog", "ds_job", "ds_file"):
            self.assertIn(name, extensions.GET)
        self.assertIn("ds_fetch", extensions.POST)
        catalog = ds.catalog()
        self.assertIs(catalog["pyarrow_installed"], False if "pyarrow" not in __import__("sys").modules and not __import__("importlib").util.find_spec("pyarrow") else True)


class NetworkErrorTests(DatasourceBase):
    def test_error_mapping(self):
        cases = [(urllib.error.HTTPError("u", 429, "x", {}, io.BytesIO(b"slow down")), "rate limit"),
                 (urllib.error.HTTPError("u", 403, "x", {}, io.BytesIO(b"bad key api_key=SECRET1")), "refused"),
                 (urllib.error.HTTPError("u", 500, "x", {}, io.BytesIO(b"boom")), "HTTP 500"),
                 (TimeoutError("timed out"), "timeout"),
                 (urllib.error.URLError("getaddrinfo failed"), "no internet")]
        for error, expected in cases:
            self.net.routes = [(re.compile("."), error)]
            with self.assertRaises(ValueError) as caught:
                ds._fetch("https://example.org/x?api_key=SECRET1", secrets=("SECRET1",))
            self.assertIn(expected, str(caught.exception))
            self.assertNotIn("SECRET1", str(caught.exception))

    def test_nasa_error_and_empty_payloads(self):
        self.net.add(r"power\.larc\.nasa\.gov", {"messages": ["No data"]})
        with self.assertRaisesRegex(ValueError, "NASA POWER returned no data"):
            self.build("solar", source="nasa_power", lat=10, lon=10, start_year=2022, utc_offset=0)
        self.net.routes = [(re.compile("."), urllib.error.HTTPError("u", 503, "x", {}, io.BytesIO(b"down")))]
        with self.assertRaisesRegex(ValueError, "HTTP 503"):
            self.build("wind", source="nasa_power", lat=11, lon=11, start_year=2022, utc_offset=0)

    def test_bad_parameters(self):
        base = dict(lat=10, lon=10, start_year=2022, utc_offset=0)
        with self.assertRaises(ValueError):
            self.build("solar", source="nasa_power", **dict(base, start_year=2022, end_year=2021))
        with self.assertRaises(ValueError):
            self.build("solar", source="nasa_power", **dict(base, start_year=1990, end_year=2020))
        with self.assertRaises(ValueError):
            self.build("solar", source="bogus", **base)
        with self.assertRaisesRegex(ValueError, "API key|key"):
            self.build("solar", source="pvwatts", **base)
        with self.assertRaises(ValueError):
            self.build("load", source="eia930", lat=10, lon=10, respondent="CISO", api_key="", peak_mw=5)
        with self.assertRaises(ValueError):
            ds.start_job(dict(kind="nope"))


class BuilderTests(DatasourceBase):
    def setUp(self):
        super().setUp()
        self.net.add(r"power\.larc\.nasa\.gov", nasa_body)
        self.net.add(r"re\.jrc\.ec\.europa\.eu/api/v5_3/seriescalc", pvgis_body)
        self.net.add(r"re\.jrc\.ec\.europa\.eu/api/v5_3/tmy", tmy_body)

    def test_pvgis_tmy_shifts_to_local_standard_time(self):
        hourly = ds.pvgis_tmy(34.0, -118.0, -8, 2025)
        self.assertEqual(len(hourly.times), 8760)
        local_hour = (hourly.times - hourly.times.astype("datetime64[D]")).astype("timedelta64[h]").astype(int)
        np.testing.assert_allclose(hourly.data["temp"], (local_hour + 8) % 24)   # local = UTC - 8
        leap = ds.pvgis_tmy(34.0, -118.0, -8, 2024)
        self.assertEqual(len(leap.times), 8784)
        result = self.build("solar", source="pvgis_tmy", lat=34.0, lon=-118.0, utc_offset=-8, label_year=2025)
        self.assertEqual(result["stats"]["rows"], 8760)
        self.check_solar_file(result["file"])

    def test_nasa_parse_and_gap_filling(self):
        calls = []
        self.net.routes = [(re.compile("power"), lambda url: nasa_body(url, temp=15.0, hole={30, 31, 500}))]
        hourly = ds.nasa_power(34.0, -118.0, 2022, 2022, -8)
        self.assertEqual(len(hourly.times), 8760)
        self.assertTrue(np.isfinite(hourly.data["temp"]).sum() >= 8700)
        values, missing = ds.fill_gaps(hourly.data["temp"])
        self.assertTrue(np.all(np.isfinite(values)))
        np.testing.assert_allclose(values, 15.0)

    def test_solar_nasa_canonical_csv_and_stats(self):
        result = self.build("solar", source="nasa_power", lat=34.0, lon=-118.0, start_year=2022, utc_offset=-8, losses_pct=14)
        self.assertEqual(result["file"]["content"].splitlines()[0], SOLAR_HEADER)
        values, audit = self.check_solar_file(result["file"])
        self.assertTrue(np.all((values >= 0) & (values <= 1500)))
        self.assertAlmostEqual(float(values.max()), 500.0, places=3)
        self.assertEqual(result["stats"]["rows"], 8760)
        self.assertAlmostEqual(result["stats"]["annual_irradiation_kwh_m2"], 500.0 * 8.76, delta=5)
        self.assertAlmostEqual(result["stats"]["mean_temperature_c"], 20.0, places=2)
        for column, kind, expected in (("dni", "dni", 700.0), ("dhi", "dhi", 100.0), ("temp", "temperature", 20.0), ("ws", "windspeed", 5.0)):
            data, _ = resource_profiles.read_profile(result["file"], [datetime(2031, 7, 4, 12)], kind)
            self.assertAlmostEqual(float(data[0]), expected, places=3)
        self.assertEqual(len(result["preview"]["diurnal"]), 24)
        self.assertEqual(len(result["preview"]["monthly"]), 12)
        provenance = result["provenance"]
        for key in ("source", "url_pattern", "latitude", "longitude", "years", "retrieved_utc", "licence", "method", "parameters"):
            self.assertIn(key, provenance)
        self.assertIn("NASA", provenance["licence"])
        self.assertTrue((self.tmp / "datasets" / result["saved"]["csv"]).is_file())
        self.assertTrue((self.tmp / "datasets" / result["saved"]["provenance"]).is_file())
        saved = json.loads((self.tmp / "datasets" / result["saved"]["provenance"]).read_text(encoding="utf-8"))
        self.assertEqual(saved["sha256"], provenance["sha256"])

    def test_solar_output_is_independent_of_pv_parameters(self):
        base = dict(source="nasa_power", lat=34.0, lon=-118.0, start_year=2022, utc_offset=-8)
        a = self.build("solar", **base)["file"]["content"]
        b = self.build("solar", **dict(base, losses_pct=20, tilt=30))["file"]["content"]
        self.assertEqual(a, b)

    def test_second_identical_request_uses_disk_cache(self):
        payload = dict(source="nasa_power", lat=34.0, lon=-118.0, start_year=2022, utc_offset=-8)
        self.build("solar", **payload)
        count = len(self.net.calls)
        self.build("wind", **payload)
        self.assertEqual(len(self.net.calls), count)
        self.build("solar", refresh=False, **payload)
        self.assertEqual(len(self.net.calls), count)

    def test_solar_pvgis_returns_horizontal_irradiance(self):
        result = self.build("solar", source="pvgis", lat=34.0, lon=-118.0, start_year=2022, utc_offset=-8)
        self.assertEqual(result["file"]["content"].splitlines()[0], SOLAR_HEADER_GHI)
        self.assertAlmostEqual(result["stats"]["mean"], 600.0, places=2)
        self.assertTrue(self.net.calls[0][0].startswith(ds.PVGIS_URL + "seriescalc"))
        self.assertIn("pvcalculation=0", self.net.calls[0][0])
        self.check_solar_file(result["file"])

    def test_wind_nasa_hand_value_and_validation(self):
        result = self.build("wind", source="nasa_power", lat=34.0, lon=-118.0, start_year=2022, utc_offset=-8,
                            turbine="iec2", hub_height=100)
        # ws10 = 5, ws50 = 8 -> shear 0.2766; hub 100 m ~ 9.8 m/s; CF must be mid-range and within [0,1]
        shear = np.log(8 / 5) / np.log(5)
        speed = 8 * 2 ** shear
        expected = (speed ** 3 - 27) / (11.0 ** 3 - 27)
        self.assertAlmostEqual(result["stats"]["capacity_factor"], expected, places=3)
        self.assertEqual(result["file"]["content"].splitlines()[0], "timestamp,wind_per_mw")
        values, _ = self.check_solar_file(result["file"], "wind")
        self.assertTrue(np.all((values >= 0) & (values <= 1)))
        self.assertTrue(any("measure" in w.lower() for w in result["warnings"]))
        with self.assertRaises(ValueError):
            self.build("wind", source="nasa_power", lat=34.0, lon=-118.0, start_year=2022, turbine="x")
        with self.assertRaises(ValueError):
            self.build("wind", source="nasa_power", lat=34.0, lon=-118.0, start_year=2022, hub_height=5)

    def test_wind_density_correction_uses_pressure(self):
        self.net.routes.clear()
        self.net.add(r"power\.larc\.nasa\.gov", lambda url: nasa_body(url, ps=80.0))
        base = dict(source="nasa_power", lat=34.0, lon=-118.0, start_year=2022, utc_offset=-8, turbine="iec2", hub_height=100)
        thin = self.build("wind", **base)
        plain = self.build("wind", **dict(base, density_correction=False))
        density = float(ds.air_density(np.array([20.0]), np.array([80.0]), 100.0)[0])
        shear = np.log(8 / 5) / np.log(5)
        speed = 8 * 2 ** shear * (density / 1.225) ** (1 / 3)
        self.assertAlmostEqual(thin["stats"]["capacity_factor"], float(ds.turbine_power(np.array([speed]), "iec2")[0]), places=3)
        self.assertLess(thin["stats"]["capacity_factor"], plain["stats"]["capacity_factor"])

    def test_pvgis_tracking_ids_and_retry(self):
        base = dict(source="pvgis", lat=34.0, lon=-118.0, start_year=2022, utc_offset=-8)
        self.build("solar", **dict(base, refresh=True))
        self.assertIn("angle=0", self.net.calls[0][0])
        wind_base = dict(base)
        for tracking, expected in (("two_axis", 2), ("vertical_axis", 3), ("single_axis", 1)):
            self.net.calls.clear()
            self.build("wind", **dict(wind_base, tracking=tracking, refresh=True))
        ds.RETRY_DELAYS = (0.0,)
        state = {"n": 0}

        def flaky(url):
            state["n"] += 1
            return urllib.error.HTTPError(url, 503, "busy", {}, io.BytesIO(b"{}")) if state["n"] == 1 else pvgis_body(url)
        self.net.routes.insert(0, (re.compile(r"seriescalc"), flaky))
        self.build("solar", **dict(base, start_year=2021, end_year=2021, refresh=True))
        self.assertEqual(state["n"], 2)

    def test_wind_losses_and_power_law(self):
        base = dict(source="pvgis", lat=34.0, lon=-118.0, start_year=2022, utc_offset=-8, hub_height=100, shear_method="power", shear_alpha=0.143)
        result = self.build("wind", **base)
        speed = 4.0 * 10 ** 0.143
        self.assertAlmostEqual(result["stats"]["capacity_factor"], float(ds.turbine_power(np.array([speed]), "iec2")[0]), places=3)
        lossy = self.build("wind", **dict(base, losses_pct=10))
        self.assertAlmostEqual(lossy["stats"]["capacity_factor"], result["stats"]["capacity_factor"] * .9, places=3)

    def test_weather_csv(self):
        result = self.build("weather", source="nasa_power", lat=34.0, lon=-118.0, start_year=2022, utc_offset=-8)
        header = result["file"]["content"].splitlines()[0]
        self.assertTrue(header.startswith("timestamp,"))
        self.assertIn("temperature_c", header)
        self.assertEqual(len(result["file"]["content"].splitlines()), 8761)

    def test_thermal_proxy_csv_and_label(self):
        result = self.build("thermal", source="nasa_power", lat=34.0, lon=-118.0, start_year=2022, utc_offset=-8,
                            mode="cooling", peak_mwth=3, balance_c=18, design_c=30)
        self.assertEqual(result["file"]["content"].splitlines()[0], "timestamp,heat_mwth")
        values, _ = self.check_solar_file(result["file"], "thermal")
        self.assertAlmostEqual(float(values.max()), 3 * (0.0 + 1.0 * (20 - 18) / 12), places=3)   # 20 C constant
        self.assertTrue(any("PROXY" in w for w in result["warnings"]))

    def test_typical_load_canonical_and_parse(self):
        result = self.build("load", source="typical", lat=34.0, lon=-118.0, building_mix={"office": 2, "datacenter": 1},
                            peak_mw=12.5, label_year=2025, utc_offset=-8)
        self.assertEqual(result["file"]["content"].splitlines()[0], "timestamp,load_mw")
        self.assertAlmostEqual(result["stats"]["peak"], 12.5, places=3)
        self.assertTrue(any("proxy" in w.lower() for w in result["warnings"]))
        parsed = demand_forecasting.parse_csv(result["file"]["content"])
        self.assertTrue(parsed)
        with self.assertRaises(ValueError):
            self.build("load", source="typical", lat=34.0, lon=-118.0, building_mix={"unknown": 1}, peak_mw=5)
        with self.assertRaises(ValueError):
            self.build("load", source="typical", lat=34.0, lon=-118.0, building_mix={"office": 1}, peak_mw=0)

    def test_eia930_pagination_scaling_and_key_hygiene(self):
        pages = []

        def eia(url):
            query = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            offset = int(query.get("offset", ["0"])[0])
            pages.append(offset)
            start = datetime(2023, 1, 1)
            rows = [{"period": (start + timedelta(hours=h)).strftime("%Y-%m-%dT%H"), "respondent": "CISO", "type": "D",
                     "value": str(20000 + 5000 * np.sin(h / 24 * 6.283) + (10 ** 7 if h == 77 else 0))}
                    for h in range(offset, min(offset + 5000, 8760))]
            return {"response": {"total": 8760, "data": rows}}
        self.net.add(r"api\.eia\.gov", eia)
        result = self.build("load", source="eia930", respondent="ca" "iso", api_key="EIAKEYSECRET1234567890", peak_mw=40, lat=34, lon=-118,
                            start_year=2023, label_year=2023)
        self.assertGreater(len(pages), 1)
        self.assertAlmostEqual(result["stats"]["peak"], 40.0, places=2)   # the 1e7 spike is dropped as an outlier
        self.assertTrue(any("EIAKEYSECRET1234567890" in call[0] or "EIAKEYSECRET1234567890" in str(call[1]) for call in self.net.calls))
        blob = json.dumps(result)
        for path in self.tmp.rglob("*"):
            if path.is_file():
                data = path.read_bytes()
                if path.suffix == ".gz":
                    data = gzip.decompress(data)
                self.assertNotIn(b"EIAKEYSECRET1234567890", data, str(path))
        self.assertNotIn("EIAKEYSECRET1234567890", blob)

    def test_pvwatts_key_in_header_not_cached(self):
        def pvwatts(url):
            return {"outputs": {"poa": [800.0] * 8760, "tamb": [15.0] * 8760, "wspd": [3.0] * 8760, "dc": [1000.0] * 8760}, "errors": [], "inputs": {}}
        self.net.add(r"developer\.nrel\.gov", pvwatts)
        result = self.build("solar", source="pvwatts", lat=34.0, lon=-118.0, utc_offset=-8, api_key="NRELKEYSECRET1234567890", tilt=20)
        self.assertEqual(result["file"]["content"].splitlines()[0], SOLAR_HEADER_POA)
        self.assertNotIn("NRELKEYSECRET1234567890", self.net.calls[0][0])
        self.assertEqual(self.net.calls[0][1].get("X-api-key"), "NRELKEYSECRET1234567890")
        for path in self.tmp.rglob("*"):
            if path.is_file():
                data = path.read_bytes()
                if path.suffix == ".gz":
                    data = gzip.decompress(data)
                self.assertNotIn(b"NRELKEYSECRET1234567890", data)

    def test_job_lifecycle_never_stores_key(self):
        self.net.routes = [(re.compile("power"), nasa_body)]
        started = ds.start_job(dict(kind="solar", source="nasa_power", lat=34.0, lon=-118.0, start_year=2022, utc_offset=-8, api_key="JOBSECRET"))
        import time
        for _ in range(100):
            status = ds.job_status({"id": [started["job"]]})
            if status["state"] != "running":
                break
            time.sleep(.1)
        self.assertEqual(status["state"], "done", status)
        self.assertNotIn("JOBSECRET", json.dumps(status))
        with self.assertRaises(ValueError):
            ds.job_status({"id": ["../x"]})
        name = status["result"]["saved"]["csv"]
        body, mime = ds.dataset_file({"name": [name]})
        self.assertEqual(body.decode().splitlines()[0], SOLAR_HEADER)
        self.assertTrue(mime.startswith("text/csv"))


class ComStockTests(DatasourceBase):
    def test_comstock_county_composite(self):
        def stock(url):
            rows = ["timestamp,out.electricity.total.energy_consumption.kwh"]
            t = datetime(2018, 1, 1, 0, 15)
            while t < datetime(2019, 1, 1, 0, 1):
                hour = (t - timedelta(minutes=15)).hour
                rows.append(f"{t:%Y-%m-%d %H:%M:%S},{10 + (5 if 8 <= hour < 18 else 0)}")
                t += timedelta(minutes=15)
            return "\n".join(rows).encode()
        self.net.add(r"oedi-data-lake", stock)
        result = self.build("load", source="comstock", lat=34.05, lon=-118.24, county_fips="06037", state="CA",
                            commercial_types={"mediumoffice": 1}, peak_mw=5, label_year=2025, utc_offset=-8)
        self.assertAlmostEqual(result["stats"]["peak"], 5.0, places=3)
        self.assertEqual(result["stats"]["rows"], 8760)
        self.assertIn("CC BY", result["provenance"]["licence"])
        self.assertTrue(demand_forecasting.parse_csv(result["file"]["content"]))
        with self.assertRaises(ValueError):
            self.build("load", source="comstock", lat=34, lon=-118, county_fips="06037", commercial_types={"castle": 1}, peak_mw=5)
        with self.assertRaises(ValueError):
            self.build("load", source="comstock", lat=34, lon=-118, county_fips="../..", commercial_types={"mediumoffice": 1}, peak_mw=5)


if __name__ == "__main__":
    unittest.main()
