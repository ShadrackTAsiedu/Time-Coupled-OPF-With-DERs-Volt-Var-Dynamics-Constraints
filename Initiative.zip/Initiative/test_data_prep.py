import math
import unittest
from datetime import datetime, timedelta

import data_prep
import demand_forecasting as df
import resource_profiles


def year_hours(start=datetime(2025, 1, 1)):
    return [start + timedelta(hours=h) for h in range(8760)]


def load_csv(rows, header="Date,Time,Meter", fmt=("%m/%d/%Y", "%I:%M %p"), quote=True):
    lines = [header]
    for stamp, value in rows:
        text = value if isinstance(value, str) else (f'"{value:,.2f}"' if quote else f"{value:.2f}")
        lines.append(f"{stamp.strftime(fmt[0])},{stamp.strftime(fmt[1])},{text}")
    return "\n".join(lines)


def base_load():
    return [(d, 20000 + 4000 * math.sin(d.hour / 24 * 2 * math.pi) + 300 * d.weekday()) for d in year_hours()]


class DataPrepTests(unittest.TestCase):
    def run_load(self, rows, **kw):
        return data_prep.prepare("load", [{"name": "t.csv", "content": load_csv(rows, **kw)}])

    def step(self, out, name):
        return next(s for s in out["report"]["steps"] if s["id"] == name)

    def test_clean_year_loads_in_model(self):
        out = self.run_load(base_load())
        self.assertTrue(out["report"]["ready"])
        self.assertEqual(out["report"]["grade"], "A")
        self.assertEqual(len(df.hourly_history(df.parse_csv(out["csv"]))[0]), 8760)
        self.assertAlmostEqual(df.parse_csv(out["csv"])[0][1]["load_mw"], 20.0 + 0, delta=2)

    def test_units_gaps_duplicates_spikes_negatives(self):
        rows = base_load()
        rows[1000] = (rows[1000][0], "N/A")
        for k in range(2000, 2010):
            rows[k] = (rows[k][0], "")
        rows[3000] = (rows[3000][0], -500.0)
        rows[4000] = (rows[4000][0], rows[4000][1] * 8)
        rows += [rows[500]]
        rows = rows[:300] + rows[300:600][::-1] + rows[600:]
        out = self.run_load(rows)
        self.assertEqual(self.step(out, "duplicates")["count"], 1)
        self.assertEqual(self.step(out, "short_gaps")["count"], 3)  # N/A + negative + spike, each isolated
        self.assertEqual(self.step(out, "long_gaps")["count"], 10)
        self.assertEqual(self.step(out, "negatives")["count"], 1)
        self.assertGreaterEqual(self.step(out, "spikes")["count"], 1)
        self.assertEqual(len(df.hourly_history(df.parse_csv(out["csv"]))[0]), 8760)
        self.assertTrue(all(float(r.split(",")[1]) >= 0 for r in out["csv"].splitlines()[1:]))

    def test_rejecting_optional_step_keeps_value(self):
        rows = base_load()
        rows[4000] = (rows[4000][0], rows[4000][1] * 8)
        kept = data_prep.prepare("load", [{"name": "t.csv", "content": load_csv(rows)}], {"disabled": ["spikes"]})
        self.assertIn(f"{round(rows[4000][1], 2) / 1000:.6f}", kept["csv"])

    def test_formats_semicolon_comma_decimal_kwh_tz(self):
        lines = ["Timestamp (UTC);Energy kWh;Status"]
        for d in year_hours():
            lines.append(f"{d:%d.%m.%Y %H:%M}Z;{20000 + 100 * d.hour:.1f};OK".replace(".0;", ",0;"))
        out = data_prep.prepare("load", [{"name": "eu.csv", "content": "\n".join(lines)}])
        self.assertTrue(out["report"]["ready"])
        self.assertEqual(self.step(out, "timezone")["count"], 8760)
        self.assertAlmostEqual(df.parse_csv(out["csv"])[0][1]["load_mw"], 20.0, places=3)

    def test_quarter_hour_and_partial_days_trimmed(self):
        rows = []
        for d in year_hours()[5:] :
            for q in range(4):
                rows.append((d + timedelta(minutes=15 * q), 20000.0 + q))
        out = self.run_load(rows)
        self.assertEqual(out["report"]["start"], "2025-01-02 00:00:00")
        self.assertGreater(self.step(out, "aggregate")["count"], 0)
        self.assertGreater(self.step(out, "trim")["count"], 0)

    def test_coarse_data_rejected(self):
        rows = [(datetime(2025, 1, 1) + timedelta(days=i), 20000.0) for i in range(60)]
        with self.assertRaises(data_prep.PrepError):
            self.run_load(rows)

    def test_utility_preamble(self):
        text = "Consumption Usage Report\t\n\nReport Date: x\n\n" + load_csv(base_load()[:200])
        out = data_prep.prepare("load", [{"name": "u.csv", "content": text}])
        self.assertEqual(out["report"]["hours"], 192)

    def test_solar_kwm2_and_gaps_read_by_model(self):
        lines = ["time,GHI (kW/m2),flag"]
        for d in year_hours():
            value = '' if d.hour == 3 and d.day == 4 else f'{max(0, math.sin((d.hour - 6) / 12 * math.pi)):.3f}'
            lines.append(f"{d:%Y-%m-%dT%H:%M:%S}+00:00,{value},0")
        out = data_prep.prepare("solar", [{"name": "s.csv", "content": "\n".join(lines)}])
        self.assertEqual(out["report"]["column"], "poa_irradiance_w_m2")
        self.assertLessEqual(max(float(r.split(",")[1]) for r in out["csv"].splitlines()[1:]), 1000.001)
        self.assertTrue(out["csv"].startswith("timestamp,poa_irradiance_w_m2"))

    def test_wind_needs_capacity_for_power(self):
        text = "Date,Time,Wind Power (kW)\n" + "\n".join(f"{d:%m/%d/%Y},{d:%H:%M},{900 + d.hour * 10}" for d in year_hours())
        with self.assertRaises(data_prep.PrepError):
            data_prep.prepare("wind", [{"name": "w.csv", "content": text}])
        out = data_prep.prepare("wind", [{"name": "w.csv", "content": text}], {"wind_capacity_mw": 1.5})
        self.assertLessEqual(max(float(r.split(",")[1]) for r in out["csv"].splitlines()[1:]), 1.0)

    def test_thermal_units(self):
        text = "timestamp,heat_demand_kWth\n" + "\n".join(f'{d:%Y/%m/%d %H:%M},"{1000 + d.hour * 10:,}"' for d in year_hours())
        out = data_prep.prepare("thermal", [{"name": "t.csv", "content": text}])
        self.assertAlmostEqual(float(out["csv"].splitlines()[1].split(",")[1]), 1.0, places=3)


if __name__ == "__main__":
    unittest.main()
