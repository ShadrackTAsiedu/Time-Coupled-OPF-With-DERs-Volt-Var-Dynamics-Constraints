import unittest

import data_prep
import demand_forecasting as df


def hourly_csv(days, step_minutes=60, level=20.0):
    from datetime import datetime, timedelta
    t, rows = datetime(2025, 1, 1), ["timestamp,load_mw"]
    for _ in range(days * 24 * 60 // step_minutes):
        rows.append(f"{t:%Y-%m-%d %H:%M},{level + (t.hour == 12) * 5}")
        t += timedelta(minutes=step_minutes)
    return "\n".join(rows)


class ForecastCoreTests(unittest.TestCase):
    def test_target_years_validated(self):
        with self.assertRaises(ValueError):
            df.forecast_peaks(5, 33.0, 45.0, 0, "linear")

    def test_linear_reaches_target(self):
        self.assertAlmostEqual(float(df.forecast_peaks(10, 33.0, 45.0, 10, "linear")), 45.0)
        self.assertAlmostEqual(float(df.forecast_peaks(15, 33.0, 45.0, 10, "linear")), 45.0)
        self.assertAlmostEqual(float(df.forecast_peaks(1, 33.0, 45.0, 10, "linear")), 34.2)

    def test_compound_and_smoothstep_known_values(self):
        self.assertAlmostEqual(float(df.forecast_peaks(5, 36.0, 49.0, 10, "compound")), 36.0 * (49 / 36) ** 0.5)
        self.assertAlmostEqual(float(df.forecast_peaks(5, 30.0, 40.0, 10, "smoothstep")), 35.0)

    def test_half_hour_history_is_averaged_to_hourly(self):
        hist = df.hourly_history(df.parse_csv(hourly_csv(366, 30)))
        self.assertGreaterEqual(len(hist[0]), 8760)

    def test_data_prep_preserves_multi_hour_peak(self):
        lines = ["Date,Hour,Load kW"]
        for d in range(60):
            for h in range(1, 25):
                v = 20000 + (1000 if 10 <= h <= 18 else 0)
                if d == 40 and 12 <= h <= 16:
                    v += 9000
                lines.append(f"2025-02-{d % 28 + 1:02d},{h},{v}") if False else lines.append(
                    f"{(__import__('datetime').date(2025, 1, 1) + __import__('datetime').timedelta(days=d)):%Y-%m-%d},{h},{v}")
        out = data_prep.prepare("load", [{"name": "a.csv", "content": "\n".join(lines)}])
        peak = max(float(r.split(",")[1]) for r in out["csv"].splitlines()[1:])
        self.assertAlmostEqual(peak, 30.0, places=3)


if __name__ == "__main__":
    unittest.main()
