import json
import re
import socket
import subprocess
import sys
import time
import unittest
from pathlib import Path
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

import generation_app

ROOT = Path(__file__).resolve().parent
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"


class SolverSettingTests(unittest.TestCase):
    def test_solver_field_default_and_pass_through(self):
        field = next(f for f in generation_app.FIELDS if f["key"] == "solver")
        self.assertEqual(field["default"], "highs")
        self.assertEqual([o[0] for o in field["options"]], ["highs", "gurobi"])
        values = generation_app.validate_request({"values": {"solver": "gurobi"}})["values"]
        self.assertEqual(generation_app.settings_for(values)["solver"], "gurobi")
        defaults = {f["key"]: f["default"] for f in generation_app.FIELDS}
        self.assertEqual(generation_app.settings_for(defaults)["solver"], "highs")


class UiInputTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        cls.base = f"http://127.0.0.1:{port}"
        cls.server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)],
                                      cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(100):
            try:
                with urlopen(cls.base + "/api/defaults", timeout=.5):
                    break
            except OSError:
                time.sleep(.1)
        else:
            cls.server.terminate()
            raise RuntimeError("Test server failed readiness.")
        cls.playwright = sync_playwright().start()
        cls.browser = cls.playwright.chromium.launch(executable_path=EDGE, headless=True)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()
        cls.server.terminate()

    def open_page(self):
        context = self.browser.new_context(viewport={"width": 1600, "height": 1000})
        page = context.new_page()
        self.errors = []
        page.on("pageerror", lambda exc: self.errors.append(str(exc)))
        page.goto(self.base + "/")
        page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
        return page

    def test_menu_order_nesting_and_no_downloads(self):
        page = self.open_page()
        titles = page.locator("#input-navigation > details > summary").all_inner_texts()
        # Hidden (unselected) technologies keep their position; compare the relative order of all entries.
        order = page.evaluate("""() => [...document.querySelectorAll('#input-navigation > details')]
            .map(d => [d.querySelector('summary').textContent, d.classList.contains('nested')])""")
        names = [n for n, _ in order]
        self.assertEqual(titles, [n for n, _ in order])
        self.assertEqual(names[:6], ["Scenarios", "Demand", "Thermal load", "Grid and tariff",
                                     "Existing/Planned Generation", "Microgrid"])
        self.assertEqual(names[-3:], ["Financial", "Carbon emissions", "Save & load"])
        nested = [n for n, flag in order if flag]
        self.assertTrue({"BESS", "Solar PV", "Wind", "Hydrogen turbine", "Natural gas turbine"} <= set(nested))
        self.assertNotIn("Financial", nested)
        self.assertNotIn("Microgrid", nested)
        self.assertEqual(names.index("Microgrid") + 1, names.index(nested[0]))
        self.assertEqual(page.locator("#downloads, #download-links").count(), 0)
        self.assertNotIn("Download saved run", page.locator("body").inner_text())
        self.assertTrue(page.locator("#download-forecast").is_hidden())
        select = page.locator("#solver")
        self.assertEqual(select.input_value(), "highs")
        self.assertEqual(select.locator("option").count(), 2)
        self.assertEqual(self.errors, [])
        page.context.close()

    def test_error_is_clickable_and_guidance_clears_on_fix(self):
        page = self.open_page()
        message = ("diesel: enter positive equipment CAPEX and efficiency, then confirm "
                   "project-specific fuel, maintenance and emissions assumptions.")
        page.evaluate("m => showError(m)", message)
        self.assertTrue(page.locator("#error").is_visible())
        self.assertIn("What to do", page.locator("#error").inner_text())
        page.locator("#error").click()
        self.assertEqual(page.evaluate("document.activeElement.id"), "diesel_capex")
        self.assertTrue(page.locator("#diesel_capex").is_visible())
        self.assertEqual(page.locator(".error-guide").count(), 1)
        self.assertIn("What to do", page.locator(".error-guide").inner_text())
        self.assertEqual(page.locator("label.error-field").count(), 3)
        page.locator("#diesel_capex").fill("1000000")
        self.assertEqual(page.locator(".error-guide").count(), 1)
        # Efficiency and confirmation live in other sections of the Diesel page, so edit them without navigating.
        page.evaluate("""() => {
            const e = document.getElementById('diesel_efficiency'); e.value = '0.35'; e.dispatchEvent(new Event('input', {bubbles: true}));
            const c = document.getElementById('diesel_confirmed'); c.checked = true; c.dispatchEvent(new Event('input', {bubbles: true}));
        }""")
        self.assertEqual(page.locator(".error-guide").count(), 0)
        self.assertEqual(page.locator("label.error-field").count(), 0)
        self.assertTrue(page.locator("#error").is_hidden())
        self.assertEqual(self.errors, [])
        page.context.close()

    def test_microgrid_error_and_manual_clear(self):
        page = self.open_page()
        page.evaluate("showError('Microgrid minimum (12 MW) cannot exceed maximum (10 MW). Raise the maximum.')")
        page.locator("#error").click()
        self.assertEqual(page.evaluate("document.activeElement.id"), "microgrid_min_mw")
        page.locator("#microgrid_min_mw").fill("12")
        page.locator("#microgrid_max_mw").fill("10")
        self.assertEqual(page.locator(".error-guide").count(), 1)
        page.locator("#microgrid_max_mw").fill("15")
        self.assertEqual(page.locator(".error-guide").count(), 0)
        page.evaluate("showError('Microgrid minimum (12 MW) cannot exceed maximum (10 MW).')")
        self.assertEqual(page.locator(".error-guide").count(), 1)
        page.evaluate("showError('')")
        self.assertEqual(page.locator(".error-guide").count(), 0)
        page.evaluate("showError('Load a forecast/combined CSV under Demand, or select Generate a forecast.')")
        page.locator("#error").click()
        self.assertTrue(page.locator("#demand-import").is_visible())
        self.assertEqual(page.locator(".error-guide").count(), 1)
        page.evaluate("showError('Select at least one valid scenario.')")
        page.locator("#error").click()
        self.assertTrue(page.locator("#scenarios").is_visible())
        self.assertEqual(self.errors, [])
        page.context.close()

    def set_technologies(self, page, techs):
        page.evaluate("""techs => {
            for (const box of document.querySelectorAll('#scenario-rows [data-tech]')) {
                box.checked = techs.includes(box.dataset.tech);
                box.dispatchEvent(new Event('change', {bubbles: true})); box.dispatchEvent(new Event('input', {bubbles: true}));
            }
            for (const box of document.querySelectorAll('#scenarios input')) box.checked = true;
            document.getElementById('scenarios').dispatchEvent(new Event('change', {bubbles: true}));
            document.getElementById('horizon_years').dispatchEvent(new Event('input', {bubbles: true}));
        }""", techs)

    def carbon_hidden(self, page):
        return page.evaluate("""() => Object.fromEntries(['grid_emissions_t_mwh', 'h2_emissions_kgco2_kg', 'ng_emissions_t_mmbtu',
            'diesel_emissions_t_mmbtu', 'biogas_emissions_t_mmbtu', 'biomass_emissions_t_mmbtu', 'pv_emissions_t_mwh',
            'bess_emissions_t_mwh', 'wind_emissions_t_mwh'].map(k => [k, document.getElementById(k).closest('label').hidden]))""")

    def test_carbon_inputs_follow_selected_technologies(self):
        page = self.open_page()
        self.set_technologies(page, ["grid", "pv"])
        hidden = self.carbon_hidden(page)
        self.assertFalse(hidden["grid_emissions_t_mwh"])
        self.assertFalse(hidden["pv_emissions_t_mwh"])
        for key in ("biogas_emissions_t_mmbtu", "biomass_emissions_t_mmbtu", "diesel_emissions_t_mmbtu",
                    "h2_emissions_kgco2_kg", "wind_emissions_t_mwh"):
            self.assertTrue(hidden[key], key)
        page.evaluate("document.getElementById('biogas_emissions_t_mmbtu').value = '0.07'")
        self.set_technologies(page, ["pv", "biogas"])
        hidden = self.carbon_hidden(page)
        self.assertTrue(hidden["grid_emissions_t_mwh"])
        self.assertFalse(hidden["biogas_emissions_t_mmbtu"])
        # Hidden fields keep saved values and the request still carries them.
        self.assertEqual(page.evaluate("values().biogas_emissions_t_mmbtu"), 0.07)
        self.assertEqual(page.evaluate("document.getElementById('grid_emissions_t_mwh').checkValidity()"), True)
        self.assertEqual(self.errors, [])
        page.context.close()

    def test_data_source_window_resize_move_maximize_persist(self):
        page = self.open_page()
        page.evaluate("dataSources.open('solar')")
        page.wait_for_selector("#ds-dialog[open]")
        box = page.locator("#ds-dialog").bounding_box()
        self.assertGreater(box["width"], 500)
        # Size set through CSSOM must work under the CSP.
        page.evaluate("document.getElementById('ds-dialog').style.width = '700px'")
        self.assertAlmostEqual(page.locator("#ds-dialog").bounding_box()["width"], 700, delta=2)
        self.assertEqual(self.errors, [])
        head = page.locator(".ds-head h3").bounding_box()
        before = page.locator("#ds-dialog").bounding_box()
        page.mouse.move(head["x"] + 5, head["y"] + 5)
        page.mouse.down(); page.mouse.move(head["x"] + 65, head["y"] + 45, steps=4); page.mouse.up()
        after = page.locator("#ds-dialog").bounding_box()
        self.assertAlmostEqual(after["x"] - before["x"], 60, delta=3)
        page.locator(".win-max").click()
        full = page.locator("#ds-dialog").bounding_box()
        self.assertGreater(full["width"], 1500)
        page.locator(".win-max").click()
        self.assertAlmostEqual(page.locator("#ds-dialog").bounding_box()["width"], 700, delta=3)
        page.evaluate("""() => { const d = document.getElementById('ds-dialog'); d.style.width = '800px'; d.style.height = '600px'; }""")
        page.wait_for_timeout(500)
        page.locator("#ds-close").click()
        saved = json.loads(page.evaluate("localStorage.getItem('genstudio_window_ds-dialog')"))
        self.assertAlmostEqual(saved["width"], 800, delta=3)
        page.evaluate("dataSources.open('solar')")
        page.wait_for_selector("#ds-dialog[open]")
        self.assertAlmostEqual(page.locator("#ds-dialog").bounding_box()["width"], 800, delta=3)
        self.assertEqual(self.errors, [])
        page.context.close()


if __name__ == "__main__":
    unittest.main()
