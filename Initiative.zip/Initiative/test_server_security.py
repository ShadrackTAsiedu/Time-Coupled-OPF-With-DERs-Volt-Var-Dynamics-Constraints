"""HTTP-layer security, robustness and recovery tests for the local server."""

import http.client
import io
import json
import socket
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

from openpyxl import Workbook

import extensions
import generation_app as app
import version

RUN_ID = "a" * 32


class ServerCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.runs = Path(cls.temp.name) / "Application Runs"
        cls.runs.mkdir()
        cls.patches = [mock.patch.object(app, "RUNS", cls.runs), mock.patch.object(extensions, "RUNS", cls.runs)]
        for patch in cls.patches:
            patch.start()
        folder = cls.runs / RUN_ID
        folder.mkdir()
        (folder / "result.csv").write_text("a,b\n1,2\n" * 50000, encoding="utf-8")
        (folder / "notes.exe").write_text("x", encoding="utf-8")
        (folder / "secret.csv").write_text("hidden", encoding="utf-8")
        (folder / "status.json").write_text(json.dumps(dict(state="complete", files=["result.csv", "notes.exe"])),
                                            encoding="utf-8")
        cls.server = app.LocalServer(("127.0.0.1", 0), app.Handler)
        cls.port = cls.server.server_port
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        for patch in cls.patches:
            patch.stop()
        cls.temp.cleanup()

    def call(self, method, path, body=None, headers=None, host=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=20)
        merged = {"Host": host or f"127.0.0.1:{self.port}"}
        merged.update(headers or {})
        connection.request(method, path, body=body, headers=merged)
        response = connection.getresponse()
        data = response.read()
        connection.close()
        return response, data

    def post_json(self, path, payload, headers=None):
        return self.call("POST", path, json.dumps(payload).encode(),
                         {"Content-Type": "application/json", **(headers or {})})


class HttpSecurityTests(ServerCase):
    def test_health_and_version(self):
        response, data = self.call("GET", "/api/health")
        health = json.loads(data)
        self.assertEqual((response.status, health["status"], health["version"]), (200, "ok", version.VERSION))
        info = json.loads(self.call("GET", "/api/version")[1])
        self.assertEqual(info["label"], f"GenStudio {version.VERSION} (build {version.BUILD_DATE})")
        self.assertEqual(json.loads(self.call("GET", "/api/defaults")[1])["version"]["label"], info["label"])

    def test_host_header_allow_list_blocks_dns_rebinding(self):
        for host in ("evil.example.com", f"evil.example.com:{self.port}", "127.0.0.1", f"localhost.evil.com:{self.port}"):
            response, data = self.call("GET", "/api/health", host=host)
            self.assertEqual(response.status, 403, host)
            self.assertIn("error", json.loads(data))
        self.assertEqual(self.call("GET", "/api/health", host=f"localhost:{self.port}")[0].status, 200)

    def test_cross_origin_and_cross_site_requests_are_rejected(self):
        for headers in ({"Origin": "http://evil.example.com"}, {"Origin": f"http://127.0.0.1:{self.port + 1}"},
                        {"Sec-Fetch-Site": "cross-site"}, {"Sec-Fetch-Site": "same-site"}):
            self.assertEqual(self.post_json("/api/milestones", {"csv": ""}, headers)[0].status, 403, headers)
            self.assertEqual(self.call("GET", "/api/defaults", headers=headers)[0].status, 403, headers)
        own = {"Origin": f"http://127.0.0.1:{self.port}", "Sec-Fetch-Site": "same-origin"}
        self.assertEqual(self.call("GET", "/api/defaults", headers=own)[0].status, 200)

    def test_simple_form_posts_and_bad_bodies_are_rejected(self):
        for ctype in ("application/x-www-form-urlencoded", "text/plain", "multipart/form-data; boundary=x"):
            response, data = self.call("POST", "/api/cancel", b'{"id": "x"}', {"Content-Type": ctype})
            self.assertEqual(response.status, 400, ctype)
            self.assertIn("application/json", json.loads(data)["error"])
        self.assertEqual(self.call("POST", "/api/cancel", b"", {"Content-Type": "application/json"})[0].status, 400)
        self.assertEqual(self.call("POST", "/api/cancel", b"{not json", {"Content-Type": "application/json"})[0].status, 400)
        self.assertEqual(self.call("POST", "/api/cancel", b"\xff\xfe", {"Content-Type": "application/json"})[0].status, 400)

    def test_oversized_request_is_refused_before_reading(self):
        with socket.create_connection(("127.0.0.1", self.port), timeout=10) as sock:
            sock.sendall(f"POST /api/jobs HTTP/1.1\r\nHost: 127.0.0.1:{self.port}\r\nContent-Type: application/json\r\n"
                         f"Content-Length: {app.MAX_REQUEST_BYTES + 1}\r\n\r\n".encode())
            reply = sock.recv(4096).decode()
        self.assertTrue(reply.startswith("HTTP/1.0 413") or reply.startswith("HTTP/1.1 413"), reply)

    def test_unknown_routes_and_methods_use_json_errors(self):
        for method, path in (("GET", "/nope"), ("POST", "/api/nope")):
            response, data = self.call(method, path, b"{}" if method == "POST" else None,
                                       {"Content-Type": "application/json"})
            self.assertEqual(response.status, 404)
            self.assertEqual(list(json.loads(data)), ["error"])
        for method in ("PUT", "DELETE", "OPTIONS", "PATCH"):
            response, data = self.call(method, "/api/jobs")
            self.assertEqual(response.status, 405, method)
            self.assertIn("error", json.loads(data))
        response, data = self.call("HEAD", "/")
        self.assertEqual(response.status, 501)

    def test_security_headers_and_asset_revalidation(self):
        response, body = self.call("GET", "/")
        headers = {k.lower(): v for k, v in response.getheaders()}
        self.assertEqual(headers["x-content-type-options"], "nosniff")
        self.assertEqual(headers["referrer-policy"], "no-referrer")
        self.assertIn("script-src 'self'", headers["content-security-policy"])
        self.assertEqual(headers["cache-control"], "no-cache")
        again = self.call("GET", "/", headers={"If-None-Match": headers["etag"]})
        self.assertEqual(again[0].status, 304)
        self.assertEqual(again[1], b"")
        self.assertEqual(self.call("GET", "/api/defaults")[0].getheader("Cache-Control"), "no-store")
        self.assertNotIn("Python", self.call("GET", "/api/health")[0].getheader("Server"))

    def test_run_id_and_file_path_traversal_are_blocked(self):
        attempts = ["/files/../app.py", f"/files/{RUN_ID}/..%2f..%2fapp.py", f"/files/{RUN_ID}/..\\status.json",
                    f"/files/{RUN_ID}/secret.csv", f"/files/{RUN_ID}/notes.exe", f"/files/{RUN_ID}/",
                    "/files/" + "A" * 32 + "/result.csv", "/files/" + "../" * 3 + "Windows/win.ini",
                    f"/files/{RUN_ID}/result.csv/extra", "/files/%2e%2e/%2e%2e/x",
                    "/api/jobs/..%2f..%2f" + "a" * 20, "/api/jobs/" + "G" * 32,
                    "/api/dispatch?run=../..", "/api/dispatch?run=" + "A" * 32, "/load-inputs/../app.py"]
        for path in attempts:
            response, data = self.call("GET", path)
            self.assertIn(response.status, (400, 404), path)
            self.assertIn("error", json.loads(data), path)
        for payload in ({"id": "../" + "a" * 29}, {"id": "A" * 32}, {"id": None}, {"id": [RUN_ID]}):
            for route in ("/api/cancel", "/api/analyze", "/api/summary-pdf"):
                self.assertEqual(self.post_json(route, payload)[0].status, 400, (route, payload))

    def test_listed_file_is_streamed_intact(self):
        response, data = self.call("GET", f"/files/{RUN_ID}/result.csv")
        self.assertEqual(response.status, 200)
        self.assertEqual(response.getheader("Content-Type"), "text/csv; charset=utf-8")
        self.assertEqual(data, (self.runs / RUN_ID / "result.csv").read_bytes())
        self.assertEqual(int(response.getheader("Content-Length")), len(data))

    def test_internal_errors_never_expose_traces_or_paths(self):
        def boom(query):
            raise RuntimeError(r"secret C:\Users\someone\token")

        def boom_post(payload):
            raise KeyError("secret-key")
        with mock.patch.dict(extensions.GET, {"boom": boom}), mock.patch.dict(extensions.POST, {"boom": boom_post}):
            for response, data in (self.call("GET", "/api/x/boom"), self.post_json("/api/x/boom", {})):
                text = data.decode()
                self.assertEqual(response.status, 500)
                self.assertNotIn("secret", text)
                self.assertNotIn("Traceback", text)
                self.assertRegex(json.loads(text)["error"], r"Internal error .*Reference [0-9a-f]{8}")

    def test_user_errors_keep_their_message_with_400(self):
        def refuse(payload):
            raise ValueError("Capacity must be positive.")
        with mock.patch.dict(extensions.POST, {"refuse": refuse}):
            response, data = self.post_json("/api/x/refuse", {})
        self.assertEqual((response.status, json.loads(data)), (400, {"error": "Capacity must be positive."}))


class RecoveryTests(unittest.TestCase):
    @staticmethod
    def dead_pid():
        process = subprocess.Popen([sys.executable, "-c", "pass"])
        process.wait()
        return process.pid

    def folder(self, root, name, status, owner=None):
        folder = root / name
        folder.mkdir()
        (folder / "status.json").write_text(json.dumps(status), encoding="utf-8")
        (folder / "status.json.1.2.tmp").write_text("partial", encoding="utf-8")
        (folder / "server.pid").write_text(str(owner if owner is not None else self.dead_pid()), encoding="ascii")
        return folder

    def test_runs_owned_by_another_live_server_are_left_alone(self):
        with tempfile.TemporaryDirectory() as name, mock.patch.object(app, "RUNS", Path(name)), \
                mock.patch.dict(app.JOBS, clear=True):
            root = Path(name)
            other = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"])
            try:
                live = self.folder(root, "7" * 32, dict(state="running", message="x"), owner=other.pid)
                legacy = root / ("8" * 32)
                legacy.mkdir()
                (legacy / "status.json").write_text(json.dumps(dict(state="running")), encoding="utf-8")
                self.assertEqual(app.recover_interrupted_runs(), [])
                self.assertEqual(json.loads((live / "status.json").read_text(encoding="utf-8"))["state"], "running")
                with self.assertRaisesRegex(ValueError, "another GenStudio server"):
                    app.cancel_job("7" * 32)
            finally:
                other.kill()
                other.wait()
            self.assertEqual(app.recover_interrupted_runs(), ["7" * 32])

    def test_server_restart_marks_running_jobs_interrupted(self):
        with tempfile.TemporaryDirectory() as name, mock.patch.object(app, "RUNS", Path(name)), \
                mock.patch.dict(app.JOBS, clear=True):
            root = Path(name)
            queued = self.folder(root, "1" * 32, dict(state="queued", message="Starting"))
            running = self.folder(root, "2" * 32, dict(state="running", message="Solving"))
            analysing = self.folder(root, "3" * 32, dict(state="running", summary=dict(results=[dict(code="P1")]),
                                                         files=[]))
            done = self.folder(root, "4" * 32, dict(state="complete", message="ok"))
            (root / "not-a-run").mkdir()
            self.assertCountEqual(app.recover_interrupted_runs(), ["1" * 32, "2" * 32, "3" * 32])
            states = {p.name: json.loads((p / "status.json").read_text(encoding="utf-8")) for p in (queued, running, analysing, done)}
            self.assertEqual(states["1" * 32]["state"], "interrupted")
            self.assertEqual(states["2" * 32]["state"], "interrupted")
            self.assertIn("server stopped", states["2" * 32]["message"])
            self.assertEqual(states["3" * 32]["state"], "complete")
            self.assertIn("interrupted", states["3" * 32]["analysis_error"])
            self.assertEqual(states["4" * 32]["message"], "ok")
            self.assertEqual(sorted(p.parent.name for p in root.glob("*/*.tmp")), ["4" * 32])
            self.assertFalse(app.active_jobs())

    def test_cancel_of_orphan_and_stop_workers_record_interruption(self):
        with tempfile.TemporaryDirectory() as name, mock.patch.object(app, "RUNS", Path(name)), \
                mock.patch.dict(app.JOBS, clear=True):
            root = Path(name)
            orphan = self.folder(root, "5" * 32, dict(state="running", message="x"))
            self.assertEqual(app.cancel_job("5" * 32)["state"], "interrupted")
            worker = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"])
            try:
                owned = self.folder(root, "6" * 32, dict(state="running", message="x"))
                app.JOBS["6" * 32] = worker
                app.stop_workers()
                self.assertIsNotNone(worker.poll())
                self.assertEqual(json.loads((owned / "status.json").read_text(encoding="utf-8"))["state"], "interrupted")
            finally:
                worker.kill()
            self.assertTrue(orphan.is_dir())
            with self.assertRaises(ValueError):
                app.cancel_job("../" + "6" * 29)

    def test_atomic_json_is_safe_for_concurrent_writers(self):
        with tempfile.TemporaryDirectory() as name:
            path = Path(name) / "status.json"
            errors = []

            def write(tag):
                try:
                    for i in range(40):
                        app.atomic_json(path, dict(tag=tag, i=i, pad="x" * 5000))
                except Exception as exc:
                    errors.append(exc)
            threads = [threading.Thread(target=write, args=(t,)) for t in range(6)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()
            self.assertEqual(errors, [])
            self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["i"], 39)
            self.assertEqual(list(Path(name).glob("*.tmp")), [])

    def test_pid_alive(self):
        self.assertTrue(app.pid_alive(__import__("os").getpid()))
        process = subprocess.Popen([sys.executable, "-c", "pass"])
        process.wait()
        self.assertFalse(app.pid_alive(process.pid))

    def test_worker_exits_when_server_process_dies(self):
        parent = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"])
        code = ("import sys, time, generation_app as a; a.exit_with_parent(int(sys.argv[1])); time.sleep(60)")
        worker = subprocess.Popen([sys.executable, "-c", code, str(parent.pid)], cwd=Path(app.__file__).parent)
        try:
            parent.kill()
            parent.wait()
            self.assertEqual(worker.wait(timeout=30), 3)
        finally:
            worker.kill()


class ExportSafetyTests(unittest.TestCase):
    def test_formula_cells_are_neutralised(self):
        for text in ("=SUM(A1)", "+1+1", "-2+3", "@cmd", "\t=1", "-HYPERLINK(\"x\")"):
            self.assertEqual(extensions.safe_cell(text), "'" + text)
        for plain in ("Solar", "-5", "+1.5e3", "2026-01-01 00:00:00", "", 7, -3.5, None):
            self.assertEqual(extensions.safe_cell(plain), plain)
        stream = io.StringIO()
        extensions.SafeCsvWriter(stream).writerows([["name", "=1+1"], [-1.5, "@x"]])
        self.assertEqual(stream.getvalue().splitlines(), ["name,'=1+1", "-1.5,'@x"])

    def test_workbook_text_starting_with_equals_is_not_a_formula(self):
        workbook = Workbook()
        workbook.active.append(["=1+1", 5, "ok"])
        self.assertEqual(workbook.active["A1"].data_type, "f")
        extensions.protect_workbook(workbook)
        self.assertEqual(workbook.active["A1"].data_type, "s")
        buffer = io.BytesIO()
        workbook.save(buffer)
        from openpyxl import load_workbook
        reloaded = load_workbook(io.BytesIO(buffer.getvalue()))
        self.assertEqual((reloaded.active["A1"].value, reloaded.active["A1"].data_type), ("=1+1", "s"))

    def test_safe_filename_and_run_id(self):
        self.assertEqual(extensions.safe_filename("..\\..\\evil name.csv"), "evil_name.csv")
        self.assertEqual(extensions.safe_filename("///"), "file")
        self.assertTrue(extensions.valid_run_id("0123456789abcdef" * 2))
        for bad in ("0123456789ABCDEF" * 2, "a" * 31, "a" * 33, "a" * 31 + "\n", None, 5):
            self.assertFalse(extensions.valid_run_id(bad))
        self.assertTrue(extensions.inside(Path.cwd(), Path.cwd() / "x"))
        self.assertFalse(extensions.inside(Path.cwd(), Path.cwd().parent))


class JobLifecycleTests(unittest.TestCase):
    """Runs a private copy of the application so the real Application Runs folder is never touched."""

    @classmethod
    def setUpClass(cls):
        import shutil
        import os
        root = Path(app.__file__).parent
        cls.folder = root / f"_ss_scratch_{os.getpid()}"
        cls.folder.mkdir()
        for item in root.glob("*.py"):
            shutil.copy2(item, cls.folder / item.name)
        for name in ("generation_ui", "Mobile Trailer Sources", "Solar Profile Inputs", "Load Profile Inputs", "Data Cache"):
            if (root / name).is_dir():
                shutil.copytree(root / name, cls.folder / name)
        cls.process = None

    @classmethod
    def tearDownClass(cls):
        import shutil
        cls.stop()
        shutil.rmtree(cls.folder, ignore_errors=True)

    @classmethod
    def start(cls):
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            cls.port = probe.getsockname()[1]
        cls.process = subprocess.Popen([sys.executable, "generation_app.py", "--port", str(cls.port)], cwd=cls.folder,
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        import time
        for _ in range(300):
            try:
                cls.get("/api/health")
                return
            except OSError:
                time.sleep(.2)
        raise RuntimeError("server did not start")

    @classmethod
    def stop(cls):
        if cls.process is not None and cls.process.poll() is None:
            cls.process.kill()
            cls.process.wait()

    @classmethod
    def request(cls, method, path, body=None):
        from urllib.request import Request, urlopen
        from urllib.error import HTTPError
        request = Request(f"http://127.0.0.1:{cls.port}{path}", json.dumps(body).encode() if body is not None else None,
                          {"Content-Type": "application/json"}, method=method)
        try:
            with urlopen(request, timeout=60) as response:
                return response.status, response.read()
        except HTTPError as exc:
            with exc:
                return exc.code, exc.read()

    @classmethod
    def get(cls, path):
        status, data = cls.request("GET", path)
        return json.loads(data)

    def payload(self, scenarios):
        from datetime import datetime, timedelta
        values = {f["key"]: f["default"] for f in self.get("/api/defaults")["fields"]}
        values.update(trajectory_mode="model", baseline=33.34421, microgrid_min_mw=0, microgrid_max_mw=1e12,
                      start_year=2025, horizon_years=1)
        lines = ["timestamp,load_mw"] + [f"{datetime(2025, 3, 3) + timedelta(hours=i):%Y-%m-%d %H:%M:%S},"
                                         f"{44 if 17 <= i % 24 < 21 else 26}" for i in range(168)]
        return dict(values=values, scenarios=scenarios, planned_generation=[], import_mode="historical",
                    upload_csv="\n".join(lines) + "\n")

    def wait(self, job, states, timeout=300):
        import time
        end = time.time() + timeout
        while time.time() < end:
            saved = self.get(f"/api/jobs/{job}")
            if saved["state"] in states:
                return saved
            time.sleep(1)
        raise TimeoutError(job)

    def test_job_runs_blocks_second_job_and_is_recovered_after_server_kill(self):
        import time
        self.start()
        status, body = self.request("POST", "/api/jobs", self.payload(["R0"]))
        self.assertEqual(status, 202, body)
        job = json.loads(body)["id"]
        status, body = self.request("POST", "/api/jobs", self.payload(["R0"]))
        self.assertEqual(status, 409)
        self.assertIn("Another run is active", json.loads(body)["error"])
        saved = self.wait(job, ("complete", "failed", "interrupted"))
        self.assertEqual(saved["state"], "complete", saved)
        run = self.folder / "Application Runs" / job
        self.assertIn("GenStudio", json.loads((run / "run_configuration.json").read_text(encoding="utf-8"))["genstudio_version"])
        self.assertTrue((run / "server.pid").is_file())
        status, data = self.request("GET", f"/files/{job}/generation_results.xlsx")
        self.assertEqual((status, data[:2]), (200, b"PK"))
        self.assertEqual(list(run.glob("*.tmp")), [])

        status, body = self.request("POST", "/api/jobs", self.payload(["R0", "P1"]))
        job = json.loads(body)["id"]
        pid = int((self.folder / "Application Runs" / job / "server.pid").read_text(encoding="ascii"))
        self.assertEqual(pid, self.process.pid)
        self.wait(job, ("running", "complete", "failed"))
        self.stop()                                   # hard kill: no chance to clean up
        time.sleep(1)
        self.start()
        recovered = self.get(f"/api/jobs/{job}")
        if recovered["state"] != "complete":          # the small job may legitimately have finished first
            self.assertEqual(recovered["state"], "interrupted", recovered)
            self.assertIn("interrupted", recovered["message"].lower())
        # A new run can start: the interrupted one no longer blocks the queue.
        status, body = self.request("POST", "/api/jobs", self.payload(["R0"]))
        self.assertEqual(status, 202, body)
        self.wait(json.loads(body)["id"], ("complete", "failed"))


class StartupTests(unittest.TestCase):
    def test_port_in_use_gives_clear_message_without_traceback(self):
        with socket.socket() as holder:
            holder.bind(("127.0.0.1", 0))
            holder.listen(1)
            port = holder.getsockname()[1]
            result = subprocess.run([sys.executable, "generation_app.py", "--port", str(port)], capture_output=True,
                                    text=True, timeout=120, cwd=Path(app.__file__).parent)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("already in use", result.stderr)
        self.assertNotIn("Traceback", result.stderr)

    def test_ctrl_break_stops_server_gracefully(self):
        if sys.platform != "win32":
            self.skipTest("CTRL_BREAK_EVENT is Windows-specific")
        import signal
        import time
        process = subprocess.Popen([sys.executable, "generation_app.py", "--port", "0"], cwd=Path(app.__file__).parent,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                                   creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
        try:
            self.assertIn("ready", process.stdout.readline())
            time.sleep(1)
            process.send_signal(signal.CTRL_BREAK_EVENT)
            self.assertEqual(process.wait(timeout=30), 0)
            self.assertNotIn("Traceback", process.stderr.read())
        finally:
            if process.poll() is None:
                process.kill()
            process.stdout.close()
            process.stderr.close()

    def test_version_flag(self):
        result = subprocess.run([sys.executable, "generation_app.py", "--version"], capture_output=True, text=True,
                                timeout=120, cwd=Path(app.__file__).parent)
        self.assertIn(version.VERSION, result.stdout)


if __name__ == "__main__":
    unittest.main()
