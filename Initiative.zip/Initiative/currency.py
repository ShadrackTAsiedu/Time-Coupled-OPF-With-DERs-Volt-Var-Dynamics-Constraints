"""Currency layer. The optimizer, saved runs and every stored result stay in canonical US dollars (USD).

The user may enter costs and read results in any ISO 4217 currency; the exchange rate (units of local currency per
1 USD) is a saved model input. Conversion happens only at the presentation edge:
  * inputs: local value / rate -> USD (done by the browser before the request is sent);
  * outputs: USD value * rate -> local value (done here for reports/exports, and in currency.js for the UI).
NPV, IRR and payback are scale-free: IRR and payback do not change with the rate; NPV scales exactly with it.
Rates below are rough indicative values (units per 1 USD) for first use only; the user must update them.
"""

import re
import threading

# (code, name, symbol, indicative units per 1 USD). An empty symbol means the code itself is used.
CURRENCIES = [
    ("USD", "US dollar", "$", 1.0), ("EUR", "Euro", "\u20ac", 0.92), ("GBP", "Pound sterling", "\u00a3", 0.79),
    ("JPY", "Japanese yen", "\u00a5", 150.0), ("CNY", "Chinese yuan renminbi", "CN\u00a5", 7.2), ("INR", "Indian rupee", "\u20b9", 83.0),
    ("CAD", "Canadian dollar", "CA$", 1.36), ("AUD", "Australian dollar", "A$", 1.52), ("NZD", "New Zealand dollar", "NZ$", 1.65),
    ("CHF", "Swiss franc", "CHF", 0.88), ("SEK", "Swedish krona", "", 10.5), ("NOK", "Norwegian krone", "", 10.7),
    ("DKK", "Danish krone", "", 6.9), ("ISK", "Icelandic krona", "", 138.0), ("PLN", "Polish zloty", "z\u0142", 4.0),
    ("CZK", "Czech koruna", "K\u010d", 23.0), ("HUF", "Hungarian forint", "Ft", 360.0), ("RON", "Romanian leu", "lei", 4.6),
    ("BGN", "Bulgarian lev", "", 1.8), ("HRK", "Croatian kuna (replaced by EUR)", "", 6.9), ("RSD", "Serbian dinar", "", 108.0),
    ("UAH", "Ukrainian hryvnia", "\u20b4", 41.0), ("RUB", "Russian ruble", "\u20bd", 92.0), ("BYN", "Belarusian ruble", "", 3.3),
    ("MDL", "Moldovan leu", "", 17.8), ("ALL", "Albanian lek", "", 93.0), ("MKD", "North Macedonian denar", "", 56.5),
    ("BAM", "Bosnia-Herzegovina convertible mark", "", 1.8), ("GEL", "Georgian lari", "\u20be", 2.7), ("AMD", "Armenian dram", "", 390.0),
    ("AZN", "Azerbaijani manat", "\u20bc", 1.7), ("TRY", "Turkish lira", "\u20ba", 32.0), ("ILS", "Israeli new shekel", "\u20aa", 3.7),
    ("SAR", "Saudi riyal", "", 3.75), ("AED", "UAE dirham", "", 3.67), ("QAR", "Qatari riyal", "", 3.64),
    ("KWD", "Kuwaiti dinar", "", 0.31), ("BHD", "Bahraini dinar", "", 0.376), ("OMR", "Omani rial", "", 0.385),
    ("JOD", "Jordanian dinar", "", 0.71), ("LBP", "Lebanese pound", "", 89500.0), ("IQD", "Iraqi dinar", "", 1310.0),
    ("IRR", "Iranian rial", "", 42000.0), ("YER", "Yemeni rial", "", 250.0), ("SYP", "Syrian pound", "", 13000.0),
    ("EGP", "Egyptian pound", "E\u00a3", 48.0), ("LYD", "Libyan dinar", "", 4.8), ("TND", "Tunisian dinar", "", 3.1),
    ("DZD", "Algerian dinar", "", 135.0), ("MAD", "Moroccan dirham", "", 10.0), ("SDG", "Sudanese pound", "", 600.0),
    ("SSP", "South Sudanese pound", "", 1300.0), ("ETB", "Ethiopian birr", "", 57.0), ("ERN", "Eritrean nakfa", "", 15.0),
    ("DJF", "Djiboutian franc", "", 178.0), ("SOS", "Somali shilling", "", 571.0), ("KES", "Kenyan shilling", "KSh", 129.0),
    ("UGX", "Ugandan shilling", "USh", 3700.0), ("TZS", "Tanzanian shilling", "TSh", 2600.0), ("RWF", "Rwandan franc", "", 1300.0),
    ("BIF", "Burundian franc", "", 2900.0), ("CDF", "Congolese franc", "", 2800.0), ("ZMW", "Zambian kwacha", "ZK", 26.0),
    ("MWK", "Malawian kwacha", "", 1730.0), ("MZN", "Mozambican metical", "", 64.0), ("ZWL", "Zimbabwean dollar (ZiG)", "", 13.5),
    ("BWP", "Botswana pula", "P", 13.6), ("NAD", "Namibian dollar", "N$", 18.5), ("ZAR", "South African rand", "R", 18.5),
    ("LSL", "Lesotho loti", "", 18.5), ("SZL", "Eswatini lilangeni", "", 18.5), ("MGA", "Malagasy ariary", "", 4500.0),
    ("MUR", "Mauritian rupee", "", 46.0), ("SCR", "Seychellois rupee", "", 13.8), ("KMF", "Comorian franc", "", 450.0),
    ("AOA", "Angolan kwanza", "", 900.0), ("NGN", "Nigerian naira", "\u20a6", 1500.0), ("GHS", "Ghanaian cedi", "GH\u20b5", 14.5),
    ("XOF", "West African CFA franc", "CFA", 600.0), ("XAF", "Central African CFA franc", "FCFA", 600.0),
    ("GMD", "Gambian dalasi", "", 67.0), ("GNF", "Guinean franc", "", 8600.0), ("SLE", "Sierra Leonean leone", "", 22.7),
    ("LRD", "Liberian dollar", "", 190.0), ("CVE", "Cape Verdean escudo", "", 101.0), ("MRU", "Mauritanian ouguiya", "", 40.0),
    ("STN", "Sao Tome and Principe dobra", "", 22.5), ("PKR", "Pakistani rupee", "", 278.0), ("BDT", "Bangladeshi taka", "\u09f3", 118.0),
    ("LKR", "Sri Lankan rupee", "", 300.0), ("NPR", "Nepalese rupee", "", 133.0), ("BTN", "Bhutanese ngultrum", "", 83.0),
    ("MVR", "Maldivian rufiyaa", "", 15.4), ("AFN", "Afghan afghani", "", 71.0), ("KZT", "Kazakhstani tenge", "\u20b8", 470.0),
    ("UZS", "Uzbekistani som", "", 12700.0), ("KGS", "Kyrgyzstani som", "", 89.0), ("TJS", "Tajikistani somoni", "", 10.9),
    ("TMT", "Turkmenistani manat", "", 3.5), ("MNT", "Mongolian togrog", "\u20ae", 3400.0), ("KRW", "South Korean won", "\u20a9", 1350.0),
    ("KPW", "North Korean won", "", 900.0), ("TWD", "New Taiwan dollar", "NT$", 32.0), ("HKD", "Hong Kong dollar", "HK$", 7.8),
    ("MOP", "Macanese pataca", "", 8.0), ("SGD", "Singapore dollar", "S$", 1.35), ("MYR", "Malaysian ringgit", "RM", 4.7),
    ("THB", "Thai baht", "\u0e3f", 36.0), ("VND", "Vietnamese dong", "\u20ab", 25000.0), ("LAK", "Lao kip", "", 21500.0),
    ("KHR", "Cambodian riel", "", 4100.0), ("MMK", "Myanmar kyat", "", 2100.0), ("IDR", "Indonesian rupiah", "Rp", 15800.0),
    ("PHP", "Philippine peso", "\u20b1", 57.0), ("BND", "Brunei dollar", "", 1.35), ("PGK", "Papua New Guinean kina", "", 3.8),
    ("FJD", "Fijian dollar", "FJ$", 2.25), ("WST", "Samoan tala", "", 2.8), ("TOP", "Tongan pa'anga", "", 2.35),
    ("VUV", "Vanuatu vatu", "", 120.0), ("SBD", "Solomon Islands dollar", "", 8.4), ("XPF", "CFP franc", "", 110.0),
    ("MXN", "Mexican peso", "Mex$", 17.0), ("GTQ", "Guatemalan quetzal", "Q", 7.8), ("HNL", "Honduran lempira", "", 24.7),
    ("NIO", "Nicaraguan cordoba", "", 36.8), ("CRC", "Costa Rican colon", "\u20a1", 510.0), ("PAB", "Panamanian balboa", "B/.", 1.0),
    ("BZD", "Belize dollar", "BZ$", 2.0), ("CUP", "Cuban peso", "", 24.0), ("DOP", "Dominican peso", "RD$", 59.0),
    ("HTG", "Haitian gourde", "", 132.0), ("JMD", "Jamaican dollar", "J$", 157.0), ("TTD", "Trinidad and Tobago dollar", "TT$", 6.8),
    ("BBD", "Barbadian dollar", "", 2.0), ("BSD", "Bahamian dollar", "", 1.0), ("XCD", "East Caribbean dollar", "EC$", 2.7),
    ("AWG", "Aruban florin", "", 1.8), ("ANG", "Netherlands Antillean guilder", "", 1.79), ("KYD", "Cayman Islands dollar", "", 0.83),
    ("BMD", "Bermudian dollar", "", 1.0), ("COP", "Colombian peso", "COL$", 3900.0), ("VES", "Venezuelan bolivar", "", 36.0),
    ("GYD", "Guyanese dollar", "", 209.0), ("SRD", "Surinamese dollar", "", 36.0), ("BRL", "Brazilian real", "R$", 5.1),
    ("ARS", "Argentine peso", "", 900.0), ("CLP", "Chilean peso", "CL$", 940.0), ("UYU", "Uruguayan peso", "", 39.0),
    ("PYG", "Paraguayan guarani", "", 7300.0), ("BOB", "Bolivian boliviano", "Bs", 6.9), ("PEN", "Peruvian sol", "S/", 3.75),
    ("FKP", "Falkland Islands pound", "", 0.79), ("GIP", "Gibraltar pound", "", 0.79), ("SHP", "Saint Helena pound", "", 0.79),
]
BY_CODE = {c[0]: c for c in CURRENCIES}
DEFAULT_CODE = "USD"
NOTE = "Indicative rate, update before use."

_state = threading.local()


def options():
    """(code, 'CODE - name (symbol)') pairs for the select input."""
    return [(code, f"{code} - {name}" + (f" ({sym})" if sym and sym != code else "")) for code, name, sym, _ in CURRENCIES]


def table():
    return [dict(code=c, name=n, symbol=s or c, rate=r) for c, n, s, r in CURRENCIES]


def parse(values):
    """Active currency of a request's values; USD / rate 1 for old runs and for invalid input."""
    values = values or {}
    code = values.get("currency_code")
    code = code if code in BY_CODE else DEFAULT_CODE
    rate = values.get("currency_rate")
    ok = isinstance(rate, (int, float)) and not isinstance(rate, bool) and rate == rate and 0 < rate < 1e15
    rate = float(rate) if ok else BY_CODE[code][3]
    if code == DEFAULT_CODE:
        rate = 1.0
    _, name, symbol, _ = BY_CODE[code]
    return dict(code=code, name=name, symbol=symbol or code, rate=rate)


def activate(values):
    """Make the currency of this request current for the calling thread (reports, exports)."""
    _state.current = parse(values)
    return _state.current


def active():
    return getattr(_state, "current", None) or parse({})


def is_usd():
    c = active()
    return c["code"] == "USD" and c["rate"] == 1.0


def fx():
    return active()["rate"]


def prefix(symbol=None):
    symbol = symbol or active()["symbol"]
    return symbol + (" " if symbol[-1:].isalpha() else "")


def xl():
    """Currency literal for an Excel/PowerPoint number format ($ stays bare for USD)."""
    p = prefix()
    return p if p == "$" else '"' + p + '"'


def scaled(value_usd):
    """Canonical USD amount (or USD per unit) expressed in the active currency."""
    return None if value_usd is None else value_usd * fx()


def money(value_usd, scale=1.0, decimals=0, suffix=""):
    """'-$1,234' style text: value_usd * rate / scale, with the active currency symbol."""
    if value_usd is None:
        return "n/a"
    v = float(value_usd) * fx() / scale
    text = f"{abs(v):,.{min(decimals, 4)}f}"
    sign = "-" if v < 0 and float(text.replace(",", "")) != 0 else ""
    return f"{sign}{prefix()}{text}{suffix}"


_DOLLAR = re.compile(r"\$")


def label(text):
    """Replace the dollar sign in a header / unit / sentence by the active currency symbol: 'NPC $M' -> 'NPC \u20acM'."""
    if is_usd() or not isinstance(text, str) or "$" not in text:
        return text
    symbol = active()["symbol"]
    spaced = symbol + " " if symbol[-1:].isalpha() else symbol
    return re.sub(r"\$(?=[A-Za-z])", spaced.replace("\\", "\\\\"), text).replace("$", symbol)


def is_money_header(text):
    return isinstance(text, str) and "$" in text


def scale_table(columns, rows):
    """Copy of a table with every column whose header carries '$' converted to the active currency and relabelled."""
    if is_usd():
        return list(columns), [list(r) for r in rows]
    factor = fx()
    money_cols = [i for i, c in enumerate(columns) if is_money_header(c)]
    new_rows = []
    for row in rows:
        row = list(row)
        for i in money_cols:
            if i < len(row) and isinstance(row[i], (int, float)) and not isinstance(row[i], bool):
                row[i] = row[i] * factor
        new_rows.append(row)
    return [label(c) for c in columns], new_rows


def statement():
    """Sentence stating the currency and rate; empty for the default USD."""
    c = active()
    if is_usd():
        return ""
    return (f"Monetary values are shown in {c['name']} ({c['code']}) at {c['rate']:g} {c['code']} per 1 USD. The model solves in USD; "
            f"amounts are converted by multiplying by this rate. NPV scales with the rate; IRR and payback do not.")


try:
    import extensions
    extensions.GET['currencies'] = lambda query: dict(default=DEFAULT_CODE, note=NOTE, currencies=table())
except ImportError:  # standalone use
    pass


def mega(value_usd):
    """Canonical USD -> millions of the active currency (None-safe)."""
    return None if value_usd is None else value_usd * fx() / 1e6
