import json
import re
import shutil
import subprocess
import sys
import unittest
import uuid
from pathlib import Path

import design
import psse_check
import report
import report_doc

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / "Application Runs"
SOURCE = "7791be18470745f8af5ef34fa3d208f8"
HAS_SOURCE = (RUNS / SOURCE / "status.json").is_file()


def y_sys(model, prefix):
    """Total step-up transformer admittance on the system base for the transformers whose name starts with `prefix`."""
    return sum(t["mva"] / (model["base_mva"] * complex(t["r"], t["x"])) for t in model["trafos"] if t["name"].startswith(prefix))


@unittest.skipUnless(HAS_SOURCE, "reference run not available")
class EquivalentVsDetailed(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rid = uuid.uuid4().hex
        shutil.copytree(RUNS / SOURCE, RUNS / cls.rid)
        cls.codes = [o["code"] for o in design.scenario_options(cls.rid)["options"]]
        cls.v = {(c, d): design.build_design(cls.rid, c, detail=d) for c in cls.codes for d in design.DETAILS}

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(RUNS / cls.rid, ignore_errors=True)

    def test_default_is_equivalent_and_bad_detail_rejected(self):
        self.assertEqual(design.DEFAULT_DETAIL, "equivalent")
        self.assertIs(design.build_design(self.rid, self.codes[0]), self.v[(self.codes[0], "equivalent")])
        with self.assertRaises(ValueError):
            design.build_design(self.rid, self.codes[0], detail="bogus")

    def test_models_are_consistent_and_equivalent_is_smaller(self):
        shrunk = 0
        for c in self.codes:
            eq, de = (self.v[(c, d)]["raw_model"] for d in design.DETAILS)
            self.assertLessEqual(len(eq["buses"]), len(de["buses"]), c)
            shrunk += len(eq["buses"]) < len(de["buses"])
            for m in (eq, de):
                nums = [b["num"] for b in m["buses"]]
                self.assertEqual(len(nums), len(set(nums)), c)
                self.assertTrue(all(len(b["name"]) <= 12 for b in m["buses"]), c)
                self.assertEqual(len({b["name"] for b in m["buses"]}), len(nums), c)
                known = set(nums)
                for br in m["branches"]:
                    self.assertTrue({br["f"], br["t"]} <= known, c)
                for t in m["trafos"]:
                    self.assertTrue({t["hv"], t["lv"]} <= known, c)
                for g in m["gens"]:
                    self.assertIn(g["bus"], known, c)
        self.assertGreater(shrunk, 0, "no scenario was simplified by the equivalent model")

    def test_totals_and_impedance_preserved(self):
        for c in self.codes:
            eq, de = (self.v[(c, d)]["raw_model"] for d in design.DETAILS)
            for tech in {g["tech"] for g in de["gens"]}:
                total = lambda m, key: sum(g[key] for g in m["gens"] if g["tech"] == tech)
                self.assertAlmostEqual(total(eq, "pmax"), total(de, "pmax"), places=3, msg=(c, tech))
                self.assertAlmostEqual(total(eq, "mbase"), total(de, "mbase"), places=3, msg=(c, tech))
                prefix = f"{tech.upper()[:6]} TR"
                self.assertAlmostEqual(sum(t["mva"] for t in eq["trafos"] if t["name"].startswith(prefix)),
                                       sum(t["mva"] for t in de["trafos"] if t["name"].startswith(prefix)), places=3, msg=(c, tech))
                self.assertAlmostEqual(abs(y_sys(eq, prefix)), abs(y_sys(de, prefix)), delta=1e-9 + 1e-3 * abs(y_sys(de, prefix)), msg=(c, tech))
            for row in eq["equivalence"]:
                self.assertAlmostEqual(row["equivalent_gen_mva"], row["unit_mva"] * row["blocks"], places=3)
                if row["has_gsu"]:
                    self.assertAlmostEqual(row["equivalent_mva"], row["block_mva"] * row["blocks"], places=3)
                    self.assertAlmostEqual(row["z_pu_equiv"] * row["blocks"], row["z_pu_block"], delta=1e-4 * row["blocks"])

    def test_boq_unit_counts_are_per_block_in_both_variants(self):
        for c in self.codes:
            eq, de = (self.v[(c, d)] for d in design.DETAILS)
            self.assertEqual(sorted((u["item"], u["count"]) for u in eq["unit_counts"]), sorted((u["item"], u["count"]) for u in de["unit_counts"]), c)
            self.assertEqual(sorted((b["item"], b["quantity"]) for b in eq["bom"]), sorted((b["item"], b["quantity"]) for b in de["bom"]), c)

    def test_assumption_states_equivalence(self):
        for c in self.codes:
            rows = [r for r in self.v[(c, "equivalent")]["basis"] if r["group"] == "Model detail"]
            self.assertTrue(rows, c)
            self.assertTrue(any("equivalent" in (r.get("note") or "").lower() for r in rows), c)
            self.assertTrue(all(r["source"] == "assumed" for r in rows), c)
            self.assertEqual(self.v[(c, "equivalent")]["meta"]["detail"], "equivalent")
            self.assertEqual(self.v[(c, "detailed")]["meta"]["detail"], "detailed")

    def test_unbuilt_technology_is_not_designed(self):
        if "H2" not in self.codes:
            self.skipTest("no H2 scenario")
        note = "Hydrogen turbine eligible but not built (0 MW)"
        for detail in design.DETAILS:
            d = self.v[("H2", detail)]
            self.assertIn(note, d["effective_technologies"]["notes"])
            self.assertNotIn("h2", d["effective_technologies"]["used"])
            svg = design.sld_svg(d)
            self.assertIn("eligible but not built", svg)
            blob = (json.dumps({k: d[k] for k in ("equipment", "bom", "unit_counts")}) + " ".join(b["name"] for b in d["raw_model"]["buses"])).lower().replace(note.lower(), "")
            self.assertNotIn("hydrogen", blob)
            self.assertNotIn("hydrogen turbine", svg.lower().replace(note.lower(), ""))
            self.assertFalse(any(g["tech"] == "h2" for g in d["raw_model"]["gens"]))

    def test_zero_capacity_generators_never_appear(self):
        for c in self.codes:
            caps = json.loads((RUNS / self.rid / f"result_{c}.json").read_text(encoding="utf-8")).get("caps") or {}
            for key, mw in (caps.get("generators_mw") or {}).items():
                if not mw:
                    self.assertNotIn(key, self.v[(c, "equivalent")]["effective_technologies"]["used"], (c, key))

    def test_reports_follow_detail_and_notes(self):
        html_eq = report_doc.build_design_doc(self.rid, {"scenario": "H2"})
        html_de = report_doc.build_design_doc(self.rid, {"scenario": "H2", "detail": "detailed"})
        self.assertIn("Equivalent (PSS/E study)", html_eq)
        self.assertIn("Detailed (per-block, for construction)", html_de)
        self.assertIn("eligible but not built (0 MW)", html_eq)
        self.assertEqual(report_doc.clean_meta({"detail": "x"})["detail"], "equivalent")
        run = report.load_run(self.rid)
        used, notes = report.effective_techs(run, "H2")
        self.assertNotIn("h2", used)
        self.assertTrue(any("Hydrogen turbine eligible but not built" in n for n in notes))
        self.assertNotIn("Hydrogen turbine", report.caps_text(run["results"]["H2"]["caps"], used))

    def test_ui_has_detail_toggle_wired_to_every_request(self):
        js = (ROOT / "generation_ui" / "design.js").read_text(encoding="utf-8")
        self.assertIn('dsel.id = "dsg-detail"', js)
        self.assertIn("Equivalent (PSS/E study)", js)
        self.assertIn("Detailed (per-block, for construction)", js)
        self.assertIn("&detail=${encodeURIComponent(st.detail)}", js)
        self.assertNotIn("/api/x/design?run_id=${encodeURIComponent(run)}", js)

    @unittest.skipUnless(psse_check.available(), "PSS/E 36 (Python 3.14) not available")
    def test_every_variant_loads_and_solves_in_psse(self):
        tmp = ROOT / f"_equiv_{uuid.uuid4().hex[:8]}"
        tmp.mkdir()
        try:
            files = []
            for (c, d), built in self.v.items():
                path = tmp / f"{c}_{d}.raw"
                path.write_bytes(design.raw_text(built).encode("utf-8"))
                files.append(str(path))
            out = subprocess.run([sys.executable, str(ROOT / "psse_check.py"), *files], capture_output=True, text=True, timeout=900).stdout
            results = json.loads(out[re.search(r"(?m)^\[", out).start():])
            self.assertEqual(len(results), len(files))
            for r in results:
                self.assertTrue(r["ok"], r)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
