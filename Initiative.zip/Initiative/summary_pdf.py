"""Concise internal summary PDF of a saved solve (A4, 2-3 pages).

The numbers and wording come from summary_data.build(), the same source as the Result Summary page, so the
page and the PDF always agree. Built with matplotlib's Agg/PDF backends through Figure objects only (never
pyplot), so it is safe to call from the server's request threads: pyplot's default GUI backend can crash the
whole process off the main thread.
"""

import datetime
import io

from matplotlib import rc_context
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.figure import Figure
from matplotlib.font_manager import FontProperties
from matplotlib.patches import Rectangle
from matplotlib.ticker import MaxNLocator
from matplotlib.textpath import TextToPath

import currency
import report as R
import summary_data as S

W, H, MARGIN, BOTTOM = 8.27, 11.69, .6, .75
INK, TEAL, MUTED, GRID = "#1d2b36", "#174f64", "#5c6b78", "#d5dde3"
GOOD, WARN, BAD, NEUTRAL = "#1f7a45", "#b7791f", "#b42318", "#6b7785"
PALETTE = ["#174f64", "#2a9d8f", "#e9a23b", "#8d6cab", "#c8553d", "#5b8def", "#7f8c8d", "#3d9970"]
LEVEL_COLOUR = {"pass": GOOD, "warn": WARN, "fail": BAD, "info": TEAL, "none": NEUTRAL}
_measure = TextToPath()


class Doc:
    def __init__(self, footer):
        self.footer, self.figs, self.fig, self.y = footer, [], None, 0
        self.page()

    def page(self):
        self.fig = Figure(figsize=(W, H), facecolor="white")
        FigureCanvasAgg(self.fig)
        self.figs.append(self.fig)
        self.y = MARGIN

    def room(self, height):
        if self.y + height > H - BOTTOM:
            self.page()

    def width(self, text, size, bold=False):
        prop = FontProperties(size=size, weight="bold" if bold else "normal")
        return _measure.get_text_width_height_descent(text, prop, ismath=False)[0] / 72

    def wrap(self, text, size, width, bold=False):
        lines = []
        for paragraph in str(text).split("\n"):
            line = ""
            for word in paragraph.split():
                trial = f"{line} {word}".strip()
                if line and self.width(trial, size, bold) > width:
                    lines.append(line)
                    line = word
                else:
                    line = trial
            lines.append(line)
        return lines

    def rect(self, x, y, w, h, colour, edge="none"):
        self.fig.add_artist(Rectangle((x / W, 1 - (y + h) / H), w / W, h / H, transform=self.fig.transFigure,
                                      facecolor=colour, edgecolor=edge, linewidth=.6))

    def put(self, x, y, text, size=8.5, colour=INK, bold=False, italic=False):
        self.fig.text(x / W, 1 - y / H, text, fontsize=size, color=colour, va="top", ha="left", parse_math=False,
                      fontweight="bold" if bold else "normal", fontstyle="italic" if italic else "normal")

    def paragraph(self, text, size=8.5, colour=INK, bold=False, gap=.06, italic=False):
        lines = self.wrap(text, size, W - 2 * MARGIN, bold)
        step = size * 1.38 / 72
        self.room(step * len(lines))
        for line in lines:
            self.put(MARGIN, self.y, line, size, colour, bold, italic)
            self.y += step
        self.y += gap

    def heading(self, text, size=11.5):
        self.room(.7)
        self.y += .06
        self.put(MARGIN, self.y, text, size, TEAL, True)
        self.y += size * 1.45 / 72
        self.rect(MARGIN, self.y, W - 2 * MARGIN, .008, GRID)
        self.y += .08

    def bullets(self, items, size=8.5):
        step = size * 1.38 / 72
        for item in items:
            lines = self.wrap(item, size, W - 2 * MARGIN - .2)
            self.room(step * len(lines))
            self.put(MARGIN + .02, self.y, "\u2022", size)
            for line in lines:
                self.put(MARGIN + .2, self.y, line, size)
                self.y += step
            self.y += .035
        self.y += .03

    def tiles(self, items, per_row=4, height=.95):
        gap = .1
        width = (W - 2 * MARGIN - gap * (per_row - 1)) / per_row
        for start in range(0, len(items), per_row):
            self.room(height)
            for i, (value, label, note, colour) in enumerate(items[start:start + per_row]):
                x = MARGIN + i * (width + gap)
                self.rect(x, self.y, width, height, "#f3f7f9", GRID)
                self.rect(x, self.y, .05, height, colour)
                self.put(x + .12, self.y + .06, label, 6.6, MUTED, True)
                size = 12.5 if len(value) < 12 else 9.5 if len(value) < 18 else 8
                self.put(x + .12, self.y + .21, value, size, colour if colour != NEUTRAL else INK, True)
                for n, line in enumerate(self.wrap(note, 6.4, width - .2)[:4]):
                    self.put(x + .12, self.y + .47 + n * .12, line, 6.4, MUTED)
            self.y += height + gap

    def table(self, headers, rows, widths, notes=None, size=7.6):
        scale = (W - 2 * MARGIN) / sum(widths)
        widths = [w * scale for w in widths]
        xs = [MARGIN]
        for w in widths:
            xs.append(xs[-1] + w)
        step = size * 1.3 / 72
        note_size = size - .4

        def head():
            self.room(.8)
            self.rect(MARGIN, self.y, W - 2 * MARGIN, .3, TEAL)
            for i, text in enumerate(headers):
                for n, line in enumerate(self.wrap(text, size - .6, widths[i] - .08, True)[:2]):
                    self.put(xs[i] + .05, self.y + .04 + n * step, line, size - .6, "white", True)
            self.y += .32
        head()
        for r, row in enumerate(rows):
            cells = [c if isinstance(c, tuple) else (str(c), INK) for c in row]
            wrapped = [self.wrap(text, size, widths[i] - .1, i == 0) for i, (text, _) in enumerate(cells)]
            note_lines = self.wrap(notes[r], note_size, W - 2 * MARGIN - .1) if notes and notes[r] else []
            body = max(len(w) for w in wrapped) * step
            height = body + .09 + len(note_lines) * note_size * 1.3 / 72
            if self.y + height > H - BOTTOM:
                self.page()
                head()
            if r % 2 == 0:
                self.rect(MARGIN, self.y, W - 2 * MARGIN, height, "#f6f9fa")
            for i, lines in enumerate(wrapped):
                colour = cells[i][1]
                for n, line in enumerate(lines):
                    self.put(xs[i] + .05, self.y + .04 + n * step, line, size, colour, i == 0 or colour != INK)
            for n, line in enumerate(note_lines):
                self.put(MARGIN + .05, self.y + .05 + body + n * note_size * 1.3 / 72, line, note_size, MUTED, italic=True)
            self.y += height
        self.y += .08

    def chart(self, x, y, w, h, draw, title):
        self.put(x, y, title, 8.2, TEAL, True)
        ax = self.fig.add_axes([(x + .45) / W, 1 - (y + h) / H, (w - .65) / W, (h - .55) / H])
        ax.tick_params(labelsize=6.5, length=2, colors=MUTED)
        for side in ("top", "right"):
            ax.spines[side].set_visible(False)
        for side in ("left", "bottom"):
            ax.spines[side].set_color(GRID)
        ax.grid(axis="y", color=GRID, linewidth=.5)
        ax.set_axisbelow(True)
        try:
            draw(ax)
        except Exception:
            ax.text(.5, .5, "Chart unavailable", ha="center", va="center", transform=ax.transAxes, fontsize=7, color=MUTED)

    def finish(self):
        total = len(self.figs)
        for number, fig in enumerate(self.figs, 1):
            fig.text(MARGIN / W, 1 - (H - .45) / H, self.footer, fontsize=6.5, color=MUTED, va="top")
            fig.text(1 - MARGIN / W, 1 - (H - .45) / H, f"Page {number} of {total}", fontsize=6.5, color=MUTED, va="top", ha="right")
        buffer = io.BytesIO()
        with rc_context({"pdf.fonttype": 42}), PdfPages(buffer, metadata={"Title": "GenStudio internal results summary",
                                                                          "Creator": "GenStudio"}) as pdf:
            for fig in self.figs:
                pdf.savefig(fig)
        return buffer.getvalue()


def level_colour(level):
    return LEVEL_COLOUR.get(level, NEUTRAL)


def charts(doc, results, table, best_code):
    top, cw, ch = doc.y, (W - 2 * MARGIN) / 2, 2.3
    by_code = {r["code"]: r for r in results}
    ordered = [by_code[row["code"]] for row in table if row["code"] in by_code]
    codes = [r["code"] for r in ordered]
    colours = [GOOD if c == best_code else TEAL for c in codes]

    def cost_bars(ax):
        ax.bar(codes, [currency.mega(R.total_npc(r)) for r in ordered], .6, color=colours)
        ax.set_ylabel(currency.label("$M (present value)"), fontsize=7)

    def capacity(ax):
        caps = [r["caps"] for r in ordered]
        layers = [("PV MW", [c.get("pv_dc_mw", 0) for c in caps]), ("BESS MW", [c.get("bess_mw", 0) for c in caps]),
                  ("Wind MW", [c.get("wind_mw", 0) for c in caps])]
        for key in sorted({k for c in caps for k in (c.get("generators_mw") or {})}):
            layers.append((f"{R.GEN_NAMES.get(key, key)} MW", [(c.get("generators_mw") or {}).get(key, 0) for c in caps]))
        base = [0] * len(codes)
        for n, (name, values) in enumerate(layers):
            if any(v > 1e-6 for v in values):
                ax.bar(codes, values, .6, bottom=base, label=name, color=PALETTE[n % len(PALETTE)])
                base = [b + v for b, v in zip(base, values)]
        if any(base):
            ax.legend(fontsize=6, frameon=False, ncol=3, loc="lower center", bbox_to_anchor=(.5, 1.0))
        else:
            ax.text(.5, .5, "No new on-site equipment", transform=ax.transAxes, ha="center", fontsize=7, color=MUTED)
        ax.set_ylabel("MW", fontsize=7)

    def annual(ax):
        for n, r in enumerate(ordered):
            series = r["economics"].get("annual") or []
            ax.plot([a["year"] for a in series], [currency.mega(a.get("total_cash_cost", 0)) for a in series], color=PALETTE[n % len(PALETTE)],
                    linewidth=2.2 if r["code"] == best_code else 1.1, label=r["code"], marker="o", markersize=2)
        ax.legend(fontsize=6, frameon=False, ncol=6, loc="lower center", bbox_to_anchor=(.5, 1.0))
        ax.xaxis.set_major_locator(MaxNLocator(integer=True))
        ax.set_ylabel(currency.label("$M per year (nominal)"), fontsize=7)

    def unserved(ax):
        values = [float((r.get("adequacy") or {}).get("unserved_mwh") or 0) for r in ordered]
        ax.bar(codes, values, .6, color=[BAD if v > 1e-6 else GOOD for v in values])
        if not any(v > 1e-6 for v in values):
            ax.text(.5, .5, "All scenarios serve all load", transform=ax.transAxes, ha="center", fontsize=7, color=MUTED)
        ax.set_ylabel("MWh over the horizon", fontsize=7)

    doc.chart(MARGIN, top, cw, ch, cost_bars, "Net present cost (ranked, lowest first)")
    doc.chart(MARGIN + cw, top, cw, ch, capacity, "New on-site capacity")
    doc.chart(MARGIN, top + ch + .3, cw, ch, annual, "Annual cash cost")
    doc.chart(MARGIN + cw, top + ch + .3, cw, ch, unserved, "Unserved energy")
    doc.y = top + 2 * ch + .8


def analysis_results(doc, data):
    detail = data["detail"]
    econ, sens, rel = detail["economic"]["rows"], detail["sensitivity"], detail["reliability"]
    doc.room(5.2)
    doc.heading("Economic, sensitivity and reliability results")
    top, cw, ch = doc.y, (W - 2 * MARGIN) / 2, 2.3
    lines = []
    if econ:
        best = next((r for r in econ if r["recommended"]), econ[0])
        lines.append(f"Economic: {best['name']} has the lowest NPC of the options that serve all load, {currency.prefix()}{best['npc']:.2f}M (upfront {currency.prefix()}{best['upfront']:.2f}M).")
    for kpi in data["kpis"]:
        if kpi["key"] in ("npv", "npv_op"):
            lines.append(f"{kpi['label']}: {kpi['value']}; {kpi['note']}.")
    if sens:
        lead = sens["swings"][0]
        risk = sens["risk"]
        lines.append(f"Sensitivity ({sens['scenario']}): largest driver is {lead['label'].replace(' *', '')} ({lead['range']}), "
                     f"changing NPC by {lead['low']:+.2f} to                      {lead['high']:+.2f} {currency.label('$M')}."
                                          + (f" NPC P10-P90: {currency.prefix()}{risk['p10'] / 1e6:.2f}M to {currency.prefix()}{risk['p90'] / 1e6:.2f}M." if risk.get("p10") is not None else ""))
    else:
        lines.append("Sensitivity: not run.")
    lines.extend(f"Reliability {r['code']}: LOLE {r['lole']:.2f} h/yr, EENS {r['eens']:.1f} MWh/yr, outage cost {currency.prefix()}{r['cost']:.3f}M/yr"
                 + (f" ({r['verdict']})." if r["verdict"] else ".") for r in rel)
    if not rel:
        lines.append("Reliability: not run.")
    doc.bullets(lines)
    top = doc.y

    def tornado(ax):
        if not sens:
            ax.text(.5, .5, "Sensitivity not run", transform=ax.transAxes, ha="center", fontsize=7, color=MUTED)
            return
        rows = sens["swings"][::-1]
        pos = list(range(len(rows)))
        ax.barh(pos, [r["low"] for r in rows], .4, color=PALETTE[0], label="Low value")
        ax.barh([p + .4 for p in pos], [r["high"] for r in rows], .4, color=PALETTE[1], label="High value")
        ax.set_yticks([p + .2 for p in pos])
        ax.set_yticklabels([r["label"].replace(" *", "")[:22] for r in rows], fontsize=6)
        ax.axvline(0, color=INK, linewidth=.6)
        ax.legend(fontsize=6, frameon=False)
        ax.set_xlabel(currency.label("Change in NPC ($M)"), fontsize=7)

    def reliability(ax):
        if not rel:
            ax.text(.5, .5, "Reliability not run", transform=ax.transAxes, ha="center", fontsize=7, color=MUTED)
            return
        ax.bar([r["code"] for r in rel], [r["eens"] for r in rel], .6, color=PALETTE[3])
        ax.set_ylabel("EENS (MWh/yr)", fontsize=7)

    doc.room(2.6)
    doc.chart(MARGIN, top, cw, ch, tornado, "Sensitivity tornado: NPC change vs base")
    doc.chart(MARGIN + cw, top, cw, ch, reliability, "Expected unserved energy per year")
    doc.y = top + ch + .4


def build(run_id):
    run = R.load_run(run_id)
    data = S.build(run_id, run)
    rec, table = data["recommended"], data["table"]
    values = run["values"]
    start, horizon = values.get("start_year"), values.get("horizon_years")
    doc = Doc(f"GenStudio | Internal discussion summary, not a project report | Solve {run_id} | {datetime.datetime.now():%Y-%m-%d %H:%M}")

    doc.rect(0, 0, W, .95, TEAL)
    doc.put(MARGIN, .2, "Results summary - internal discussion", 17, "white", True)
    span = f", {start}-{int(start) + int(horizon) - 1} ({horizon} year{'' if int(horizon) == 1 else 's'})" if start and horizon else ""
    doc.put(MARGIN, .58, f"Generation planning screening{span}, {len(table)} scenarios compared; ranking by total net present cost (NPC)", 8.5, "#d7e8ee")
    doc.y = 1.15

    doc.heading("Recommended option")
    title = "Best option is the reference case: " if rec["is_reference"] else ""
    doc.paragraph(f"{title}{rec['code']} - {rec['name']}", 12, GOOD if rec["fully_supplied"] else WARN, True, gap=.02)
    doc.paragraph((f"Rank {rec['rank']} of {rec['count']} by total NPC. " if rec["rank"] else "") + f"Equipment: {rec['mix']}.", 8.5, MUTED, gap=.05)
    doc.bullets(rec["why"])

    doc.heading("Key results")
    doc.tiles([(k["value"], k["label"].upper(), k["note"], level_colour(k["level"]) if k.get("level") else TEAL) for k in data["kpis"]],
              per_row=5, height=1.08)

    doc.heading("Analyses")
    doc.table(["Analysis", "Status", "Result"],
              [[a["label"], ("Not run" if a["state"] != "done" else "Done" if a["level"] == "info" else a["level"].upper(), level_colour(a["level"])),
                a["headline"]] for a in data["analyses"]],
              [1.3, .8, 5.0], [a["detail"] for a in data["analyses"]])

    if data["warnings"]:
        doc.heading("Warnings and remarks")
        doc.bullets([w["text"] for w in data["warnings"]])

    doc.heading("Options compared")
    headers = ["Option", "Rank", "NPC", *(["NPC with corrections"] if data["show_adjusted"] else []), "vs ref.", "Upfront", "NPV (net)",
               "Unserved", "Technical"]
    widths = [2.2, .45, .7, *([.9] if data["show_adjusted"] else []), .6, .7, .7, .8, .75]
    rows = []
    for row in table:
        rows.append([f"{row['code']} - {row['name']}" + (" (recommended)" if row["recommended"] else ""), str(row["rank"] or "-"), row["npc"],
                     *([row["adjusted"]] if data["show_adjusted"] else []), row["versus"], row["upfront"], row["npv"],
                     (row["unserved"], BAD if row["unserved"] != "0.00 MWh" else INK), (row["technical"], level_colour(row["technical_level"]))])
    doc.table(headers, rows, widths, [(f"{row['status']}. " if row["status"] != "Ranked" else "") + f"{row['mix']}." for row in table])
    doc.paragraph("NPV (net) is incremental to the reference and includes its avoided upgrade; the technical result is a remark and "
                  "corrections are applied afterwards.", 7, MUTED, italic=True)

    doc.room(5.2)
    doc.heading("Charts")
    charts(doc, list(run["results"].values()), table, rec["code"])
    analysis_results(doc, data)

    doc.room(2.4)
    doc.heading("Key assumptions")
    doc.bullets([f"{name}: {value}." for name, value in data["assumptions"]])
    doc.paragraph("Resource profiles and emission factors are screening-level inputs; the model is a chronological screening tool, "
                  "not an electrical design or investment certification.", 7.5, MUTED, italic=True)

    doc.heading("Next steps")
    steps = [f"Run {a['label'].lower()} on the shortlisted options." for a in data["analyses"] if a["state"] != "done"]
    if any(a["key"] == "technical" and a["level"] == "fail" for a in data["analyses"]):
        steps.append("Review the power-flow findings and apply the suggested corrections before committing to the option.")
    if any(row["status"].startswith("Same equipment") for row in table):
        steps.append("Options with identical equipment are one design; compare the distinct designs when choosing.")
    steps.append("Confirm resource profiles, emission factors and utility interconnection requirements, then extract the full project report.")
    doc.bullets(steps)
    return doc.finish()


def publish(folder, status):
    """Write results_summary.pdf into a saved solve folder (kept for the legacy /api/summary-pdf route)."""
    output, temporary = folder / "results_summary.pdf", folder / "results_summary.tmp.pdf"
    temporary.write_bytes(build(folder.name))
    temporary.replace(output)
    return output.name
