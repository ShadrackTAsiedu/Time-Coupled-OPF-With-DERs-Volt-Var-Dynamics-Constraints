"""Contingency reliability analysis of a saved SOLVE scenario (post-processing, no re-optimization).

Routes (see extensions.py):
    GET  /api/x/reliability_info    defaults, parameter labels and the plain-language method
    POST /api/x/reliability         {run_id, scenario | "all", ...parameters}  -> result (also saved)
    GET  /api/x/reliability_saved   ?run_id=&scenario=  -> saved result, or all saved results + comparison

Saved per run as <run>/reliability/<scenario>.json so the report builder can embed it.

How a contingency is run (hour by hour, vectorised over every possible outage start):
  1. A contingency removes or derates one resource (grid connection, one generator unit, the BESS, PV, wind, or the
     planned/existing renewables that were netted off the load).
  2. For an outage of D hours starting at EVERY hour of the saved dispatch, the remaining resources are re-dispatched
     with a simple energy balance: PV/wind as dispatched -> grid (up to its limit) -> generators (up to their
     capacity) -> BESS discharge (limited by its power and by its state of charge, which starts at the stored value
     of the saved dispatch). Spare supply recharges the BESS. Whatever is still missing is unserved load.
  3. Unserved load is compared with the same windows in a no-contingency re-dispatch so that only the extra
     (incremental) unserved energy and hours caused by the contingency are counted.
  4. A forced outage rate (fraction of time a unit is out) and the outage duration give the yearly frequency
     lambda = rate * 8760 / D. Expected unserved energy per year = lambda * (mean unserved energy over all start hours).
  5. Cost of downtime = unserved MWh * value of lost load (VOLL), discounted over the appraisal years.
The load being served is the saved net load (planned renewables are already netted off it).
"""

import csv
import json
import math
import re
import threading
from datetime import datetime

import numpy as np

import extensions

HOURS_PER_YEAR = 8760
EPS = 1e-6
LOCK = threading.Lock()

# key: (default, minimum, maximum, label, unit)
PARAMS = {
    "voll": (5000.0, 0, 1e7, "Value of lost load", "$/MWh ($5/kWh)"),
    "outage_hours": (8, 1, 48, "Outage duration", "h"),
    "grid_for": (.002, 0, .5, "Grid connection forced outage rate", "fraction of time"),
    "gen_for": (.05, 0, .5, "Generator unit full-loss rate", "fraction of time"),
    "gen_derate_for": (.03, 0, .5, "Generator derate rate", "fraction of time"),
    "bess_for": (.02, 0, .5, "BESS forced outage rate", "fraction of time"),
    "pv_for": (.02, 0, .5, "PV loss rate (inverter/outage equivalent)", "fraction of time"),
    "wind_for": (.02, 0, .5, "Wind loss rate", "fraction of time"),
    "planned_for": (.02, 0, .5, "Planned/existing renewables loss rate", "fraction of time"),
    "derate_remaining_pct": (50.0, 0, 100, "Derate: capacity remaining", "%"),
    "gen_units": (1, 1, 20, "Units per generator technology", "count"),
    "critical_fraction": (.8, .05, 1, "Critical load fraction (kept on in a contingency)", "fraction"),
    "shed_cost_fraction": (.2, 0, 1, "Cost of shedding non-critical load", "fraction of VOLL"),
    "dr_fraction": (.1, 0, 1, "Demand response available", "fraction of load"),
    "dr_standing_usd_kw_yr": (50.0, 0, 1e5, "Demand response standing payment", "$/kW-yr"),
    "dr_activation_usd_mwh": (400.0, 0, 1e6, "Demand response activation payment", "$/MWh"),
    "pv_years": (10, 1, 30, "Present-value horizon", "years"),
    "discount": (None, 0, 1, "Discount rate (blank = scenario's)", "fraction"),
    "standby_gen_capex": (None, 0, 1e8, "Standby genset capital cost (blank = scenario/default)", "$/MW"),
    "bess_power_capex": (None, 0, 1e8, "BESS power capital cost (blank = scenario)", "$/MW"),
    "bess_energy_capex": (None, 0, 1e8, "BESS energy capital cost (blank = scenario)", "$/MWh"),
    "focus_year": (None, 1900, 2200, "Headline year (blank = last year)", "year"),
    "start": (None, None, None, "Specific outage start (optional)", "YYYY-MM-DD HH:MM"),
    "soc_start": ("stored", None, None, "BESS state of charge at outage start", "stored | full"),
    "grid_mw": (None, 0, 1e5, "Grid import limit override", "MW"),
}
DEFAULT_STANDBY = dict(capex=800000.0, fom=20000.0, energy_cost=280.0,
                       source="screening default for standby diesel gensets (installed $/MW, fixed O&M $/MW-yr, "
                              "fuel+variable O&M $/MWh); replace with a vendor quote")
CRITERIA = ("PASS: expected downtime (LOLE) <= 2.4 h/yr (1 day in 10 years) and no single-resource contingency "
            "(grid, generator, BESS, PV, wind or planned asset) leaves load unserved. "
            "WARN: LOLE <= 24 h/yr. FAIL: LOLE > 24 h/yr.")
METHOD = (
    "A contingency removes (or derates) one resource: the grid connection, one generator unit, the BESS, the PV, the "
    "wind, or the planned/existing renewables that were already netted off the load.",
    "The model then replays the saved year of hourly load. An outage of the chosen length is started at EVERY hour "
    "of the year (and the worst start is reported), so each contingency is tested against every possible season, "
    "time of day and load level.",
    "In each outage window the remaining resources are re-dispatched: PV/wind as dispatched, then the grid up to its "
    "limit, then generators up to their rating, then the battery (limited by its MW and by its stored energy, which "
    "starts at the state of charge in the saved dispatch). Spare supply recharges the battery.",
    "Load that still cannot be served is unserved energy (MWh); every hour with unserved load is a downtime hour. "
    "A no-contingency replay of the same windows is subtracted so only the damage caused by the contingency counts.",
    "Outage rates turn one event into a yearly expectation: events/yr = rate x 8760 / duration. Expected unserved "
    "energy/yr = events/yr x average unserved energy per outage. Downtime hours, interruptions (SAIFI-like) and the "
    "share of load served come from the same numbers.",
    "Cost of downtime = unserved MWh x value of lost load, summed over the appraisal years and discounted.",
    "Mitigations (extra BESS, standby generation, load shedding, demand response) are re-simulated, so the downtime "
    "avoided is measured, then compared with their cost.",
)
ASSUMPTIONS = (
    "Forced outage rates are typical screening values (IEEE 762 / NERC GADS ranges); replace them with utility/OEM "
    "data. Grid default 0.2 % is about 17 h/yr of unavailability of the import connection.",
    "One outage at a time (N-1); overlapping and common-mode outages are not modelled. Outage duration is the same "
    "for every contingency.",
    "PV and wind output during an outage is the dispatched value of the saved run (curtailed energy is not "
    "recovered). Planned/existing renewables were netted off the load; losing them adds that output back to the load.",
    "Generators are always able to run at rating (no fuel limit). The optimizer reports one capacity per generator "
    "technology; 'units per technology' splits it into equal units for the single-unit-loss cases.",
    "The BESS starts each outage at the stored state of charge of the cost-optimal saved dispatch (or full if "
    "selected), with the run's round-trip efficiency and SOC limits. Grid/PV headroom recharges it.",
    "Grid import limit is applied to hourly import plus the intra-hour peak adder stored in the saved dispatch "
    "(grid_peak_mw - grid), which is how the optimizer limits the connection.",
    "Load is treated as one customer block: downtime hours are SAIDI-like site hours, not feeder-level indices.",
    "Mitigation costs use the scenario's own capital cost inputs where present, otherwise documented defaults. "
    "Added standby generation and batteries are assumed available when needed (their own outage is not applied).",
)
QUALITATIVE = (
    "Second grid feeder or tie to a different substation (removes the common grid single point of failure).",
    "Black-start / islanding controls so the on-site resources can serve the site when the grid is lost.",
    "Operating policy: hold part of the BESS energy in reserve instead of cycling it for tariff savings.",
    "Spare-parts and maintenance contracts that shorten repair time (lower duration, same rate).",
)


def defaults():
    return {k: v[0] for k, v in PARAMS.items()}


def parse_params(payload):
    p = defaults()
    for key, (default, lo, hi, _, _) in PARAMS.items():
        if key not in payload or payload[key] in (None, ""):
            continue
        v = payload[key]
        if key == "start":
            if not isinstance(v, str):
                raise ValueError("start must be a date-time string.")
            p[key] = v.strip().replace("T", " ")
            continue
        if key == "soc_start":
            if v not in ("stored", "full"):
                raise ValueError("soc_start must be 'stored' or 'full'.")
            p[key] = v
            continue
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
            raise ValueError(f"{key} must be a number.")
        if not lo <= v <= hi:
            raise ValueError(f"{key} must be between {lo} and {hi}.")
        p[key] = v
    for key in ("outage_hours", "gen_units", "pv_years"):
        p[key] = int(round(p[key]))
    p["derate_remaining_pct"] = float(p["derate_remaining_pct"])
    if not 0 < p["derate_remaining_pct"] < 100:
        raise ValueError("Derate capacity remaining must be between 0 and 100 %.")
    return p


# ---------------------------------------------------------------- core simulation
def window_sim(load, var, firm, bess_mw, bess_mwh, soc0, hours, soc_min=0.0, soc_max=1.0, eff=1.0, reduce=0.0,
               record=False):
    """Energy-balance re-dispatch of every `hours`-long window of the hourly series (one window per start hour).

    load, var: arrays over the series (var = PV/wind output).     firm: dispatchable supply in MW (grid + generators), a number or an array over the series.
    soc0: starting stored energy (MWh) for each window (scalar or array of the number of windows).
    Returns dict(short=(hours, windows) unserved MW, shed=(windows,) MWh shed by `reduce`, rec=... if record).
    """
    load, var = np.asarray(load, float), np.asarray(var, float)
    windows = len(load) - hours + 1
    if windows < 1:
        raise ValueError("The series is shorter than the outage duration.")
    bess_mw = bess_mw if bess_mwh > EPS else 0.0
    floor, ceil = soc_min * bess_mwh, soc_max * bess_mwh
    soc = np.minimum(np.broadcast_to(np.asarray(soc0, float), (windows,)).copy(), ceil)
    short = np.empty((hours, windows))
    shed = np.zeros(windows)
    rec = {k: np.empty((hours, windows)) for k in ("load", "pv", "firm", "discharge", "charge", "soc", "shed")} if record else None
    for k in range(hours):
        ld = load[k:k + windows]
        net = ld - var[k:k + windows]
        f = firm[k:k + windows] if np.ndim(firm) else firm
        used = np.clip(net, 0, f)
        deficit = np.maximum(net - f, 0)
        dis = np.minimum(np.minimum(deficit, bess_mw), np.maximum(soc - floor, 0) * eff)
        spare = np.maximum(-net, 0) + (f - used)
        chg = np.minimum(np.minimum(spare, bess_mw), np.maximum(ceil - soc, 0) / eff)
        soc = soc + chg * eff - dis / eff
        cut = np.minimum(deficit - dis, ld * reduce)  # flexible load is the last resort before unserved load
        shed += cut
        short[k] = deficit - dis - cut
        if record:
            rec["load"][k], rec["pv"][k], rec["firm"][k] = ld, np.minimum(var[k:k + windows], np.maximum(ld, 0)), used
            rec["discharge"][k], rec["charge"][k], rec["soc"][k], rec["shed"][k] = dis, chg, soc, cut
    return dict(short=short, shed=shed, rec=rec)


def pv_series(values, rate, horizon):
    return sum(values[min(i, len(values) - 1)] / (1 + rate) ** (i + 1) for i in range(horizon)) if len(values) else 0.0


def make_ctx(d, assets, p, hours):
    """Per-scenario arrays shared by every contingency run."""
    n = len(d["load"])
    starts = n - hours + 1
    years = d["year"][:starts]
    uniq, bounds = np.unique(years, return_index=True)
    stored = np.concatenate([[d["soc"][0]], d["soc"][:-1]])[:starts]
    soc0 = np.full(starts, assets["soc_max"] * assets["bess_mwh"]) if p["soc_start"] == "full" else stored
    ctx = dict(d=d, a=assets, p=p, hours=hours, starts=starts, load=d["load"], pv=d["pv"], wind=d["wind"],
               planned=d["planned"], soc0=soc0, adder=d.get("adder", np.zeros(n)), years=[int(y) for y in uniq], ybounds=bounds,
               ycount=np.diff(np.append(bounds, starts)))
    ctx["base_short"] = run_window(ctx, dict(), None)["short"]
    return ctx


def grid_capacity(a, spec, adder=None):
    """Hourly-average import limit. The saved dispatch limits hourly import PLUS an intra-hour peak adder."""
    cap = a["grid"] * spec.get("grid", 1.0)
    return cap if adder is None else (np.maximum(cap - adder, 0) if cap > 0 else np.zeros_like(adder))


def firm_capacity(a, spec, mit=None, adder=None):
    firm = grid_capacity(a, spec, adder) + sum(cap * spec.get("gens", {}).get(t, 1.0) for t, cap in a["gens"].items())
    return firm + ((mit or {}).get("gen_mw", 0.0) * (mit or {}).get("gen_avail", 1.0))


def run_window(ctx, spec, mit):
    a, mit = ctx["a"], mit or {}
    bf = spec.get("bess", 1.0)
    extra_mwh = mit.get("bess_mwh", 0.0)
    return window_sim(ctx["load"] + ctx["planned"] * (1 - spec.get("planned", 1.0)),
                      ctx["pv"] * spec.get("pv", 1.0) + ctx["wind"] * spec.get("wind", 1.0), firm_capacity(a, spec, mit, ctx["adder"]),
                      a["bess_mw"] * bf + mit.get("bess_mw", 0.0), a["bess_mwh"] * bf + extra_mwh,
                      ctx["soc0"] * bf + extra_mwh * a["soc_max"], ctx["hours"], a["soc_min"], a["soc_max"], a["eff"],
                      mit.get("reduce", 0.0))


def run_contingency(ctx, spec, mit=None):
    sim = run_window(ctx, spec, mit)
    inc = np.maximum(sim["short"] - ctx["base_short"], 0)
    return dict(mwh=inc.sum(0), hrs=(inc > EPS).sum(0).astype(float), peak=inc.max(0), shed=sim["shed"])


def by_year(ctx, values, how="mean"):
    sums = np.add.reduceat(values, ctx["ybounds"])
    return sums / ctx["ycount"] if how == "mean" else sums


def expected(ctx, res, rate):
    """Expected per-year energy, hours, interruptions and shed energy for one contingency (lists over years)."""
    lam = rate * HOURS_PER_YEAR / ctx["hours"]
    return dict(eue=list(lam * by_year(ctx, res["mwh"])), hrs=list(lam * by_year(ctx, res["hrs"])),
                ev=list(lam * by_year(ctx, (res["hrs"] > 0).astype(float))), shed=list(lam * by_year(ctx, res["shed"])),
                lam=lam)


def trace(ctx, spec, start, mit=None):
    """Hour-by-hour re-dispatch of one outage window beginning at hour index `start`."""
    a, hours = ctx["a"], ctx["hours"]
    mit = mit or {}
    sl = slice(start, start + hours)
    bf = spec.get("bess", 1.0)
    extra = mit.get("bess_mwh", 0.0)
    load = (ctx["load"] + ctx["planned"] * (1 - spec.get("planned", 1.0)))[sl]
    var = (ctx["pv"] * spec.get("pv", 1.0) + ctx["wind"] * spec.get("wind", 1.0))[sl]
    adder = ctx["adder"]
    sim = window_sim(load, var, firm_capacity(a, spec, mit, adder)[sl], a["bess_mw"] * bf + mit.get("bess_mw", 0.0),
                     a["bess_mwh"] * bf + extra, ctx["soc0"][start] * bf + extra * a["soc_max"], hours, a["soc_min"],
                     a["soc_max"], a["eff"], mit.get("reduce", 0.0), record=True)
    r = sim["rec"]
    firm = r["firm"][:, 0]
    grid = np.minimum(firm, np.broadcast_to(grid_capacity(a, spec, adder)[sl], (hours,)))
    inc = np.maximum(sim["short"][:, 0] - ctx["base_short"][:, start], 0)
    rows = []
    for k in range(hours):
        rows.append(dict(timestamp=ctx["d"]["ts"][start + k], load_mw=round(float(load[k]), 4),
                         pv_wind_mw=round(float(r["pv"][k, 0]), 4), grid_mw=round(float(grid[k]), 4),
                         gen_mw=round(float(firm[k] - grid[k]), 4), bess_discharge_mw=round(float(r["discharge"][k, 0]), 4),
                         bess_charge_mw=round(float(r["charge"][k, 0]), 4), soc_mwh=round(float(r["soc"][k, 0]), 4),
                         unserved_mw=round(float(sim["short"][k, 0]), 4), shed_mw=round(float(r["shed"][k, 0]), 4),
                         extra_unserved_mw=round(float(inc[k]), 4)))
    return rows


# ---------------------------------------------------------------- inputs
def load_dispatch(folder, code):
    with (folder / f"dispatch_{code}.csv").open(encoding="utf-8-sig") as stream:
        rows = list(csv.DictReader(stream))
    if not rows:
        raise ValueError("The saved dispatch is empty.")
    missing = [k for k in ("timestamp", "net_load_mw", "pv", "soc", "planned_renewable") if k not in rows[0]]
    if missing:
        raise ValueError("The saved dispatch was written by an older version and lacks columns: " + ", ".join(missing)
                         + ". Re-run SOLVE to analyse reliability.")
    col = lambda k: np.array([float(r.get(k) or 0) for r in rows])
    ts = [r["timestamp"] for r in rows]
    return dict(ts=ts, year=np.array([int(t[:4]) for t in ts]), load=np.maximum(col("net_load_mw"), 0),
                pv=np.maximum(col("pv"), 0), wind=np.maximum(col("gen_wind"), 0) if "gen_wind" in rows[0] else np.zeros(len(rows)),
                planned=np.maximum(col("planned_renewable"), 0), soc=col("soc"), shortfall=col("shortfall"),
                adder=np.maximum(col("grid_peak_mw") - col("grid"), 0) if "grid_peak_mw" in rows[0] else np.zeros(len(rows)))


def build_assets(caps, resolved, code, p, has_grid=True, reference_peak=0.0):
    gens = {k: float(v) for k, v in (caps.get("generators_mw") or {}).items() if k not in ("none", "wind") and v > 1e-6}
    grid = float(resolved.get("reference_grid_limit" if code == "R0" else "grid_limit", 0) or 0)
    if code == "R0" and resolved.get("grid_only_reference", True):
        grid = max(grid, float(reference_peak or 0))  # the optimizer widens the grid-only reference to the forecast peak
    if not has_grid:
        grid = 0.0
    if p["grid_mw"] is not None:
        grid = p["grid_mw"]
    rte = float(resolved.get("round_trip_efficiency") or .85)
    return dict(grid=float(grid), gens=gens, bess_mw=float(caps.get("bess_mw", 0) or 0),
                bess_mwh=float(caps.get("bess_mwh", 0) or 0), pv_mw=float(caps.get("pv_dc_mw", 0) or 0),
                soc_min=float(resolved.get("soc_min", .1)), soc_max=float(resolved.get("soc_max", .9)),
                eff=math.sqrt(rte))


def label(tech):
    return tech.upper().replace("_", " ")


def make_specs(ctx):
    a, p, d = ctx["a"], ctx["p"], ctx["d"]
    n, pct = p["gen_units"], p["derate_remaining_pct"] / 100
    specs = []
    if a["grid"] > EPS:
        specs.append(dict(id="grid_loss", kind="grid", name="Grid connection lost", rate=p["grid_for"], grid=0.0,
                          lost_mw=a["grid"], desc=f"Whole {a['grid']:.1f} MW import connection is out."))
    for t, cap in a["gens"].items():
        unit = cap / n
        specs.append(dict(id=f"gen_loss_{t}", kind="gen_unit", name=f"{label(t)} unit lost ({unit:.2f} MW)",
                          rate=p["gen_for"], gens={t: 1 - 1 / n}, lost_mw=unit,
                          desc=f"One of {n} {label(t)} unit(s) fails completely."))
        specs.append(dict(id=f"gen_derate_{t}", kind="gen_derate", name=f"{label(t)} unit derated to {pct * 100:.0f}%",
                          rate=p["gen_derate_for"], gens={t: 1 - (1 - pct) / n}, lost_mw=unit * (1 - pct),
                          desc=f"One {label(t)} unit can only deliver {pct * 100:.0f}% of its rating."))
    if a["bess_mw"] > EPS and a["bess_mwh"] > EPS:
        specs.append(dict(id="bess_loss", kind="bess", name=f"BESS lost ({a['bess_mw']:.1f} MW / {a['bess_mwh']:.1f} MWh)",
                          rate=p["bess_for"], bess=0.0, lost_mw=a["bess_mw"], desc="Battery cannot charge or discharge."))
    if a["pv_mw"] > EPS and d["pv"].max() > EPS:
        specs.append(dict(id="pv_loss", kind="pv", name=f"PV lost ({a['pv_mw']:.1f} MW)", rate=p["pv_for"], pv=0.0,
                          lost_mw=a["pv_mw"], desc="All on-site PV output is lost."))
    if d["wind"].max() > EPS:
        specs.append(dict(id="wind_loss", kind="wind", name="Wind lost", rate=p["wind_for"], wind=0.0,
                          lost_mw=float(d["wind"].max()), desc="All on-site wind output is lost."))
    if d["planned"].max() > EPS:
        specs.append(dict(id="planned_loss", kind="planned", name="Planned/existing renewables lost",
                          rate=p["planned_for"], planned=0.0, lost_mw=float(d["planned"].max()),
                          desc="Generation that was netted off the load is lost, so the load returns to the site."))
    return specs


# ---------------------------------------------------------------- COPT (secondary figure)
def copt(units):
    """Exact capacity distribution: list of (capacity_mw, forced_outage_rate). Returns (levels, prob)."""
    levels, prob = np.array([0.0]), np.array([1.0])
    for cap, rate in units:
        if cap <= 0:
            continue
        levels = np.concatenate([levels + cap, levels])
        prob = np.concatenate([prob * (1 - rate), prob * rate])
    order = np.argsort(levels)
    levels, prob = levels[order], prob[order]
    uniq, inverse = np.unique(np.round(levels, 6), return_inverse=True)
    return uniq, np.bincount(inverse, weights=prob)


def lole_eue(levels, prob, load):
    cdf = np.cumsum(prob)
    below = np.searchsorted(levels, load, side="left")
    loss_p = np.where(below > 0, cdf[np.clip(below - 1, 0, None)], 0.0)
    shortfall = np.array([(prob[:b] * (l - levels[:b])).sum() for l, b in zip(load, below)])
    return float(loss_p.sum()), float(shortfall.sum())


def copt_rows(ctx):
    a, p, d = ctx["a"], ctx["p"], ctx["d"]
    units = [(a["grid"], p["grid_for"])] + [(c / p["gen_units"], p["gen_for"]) for c in a["gens"].values()
                                              for _ in range(p["gen_units"])] + [(a["bess_mw"], p["bess_for"])]
    levels, prob = copt(units)
    total = sum(c for c, _ in units)
    largest = max([c for c, _ in units] + [0])
    rows = []
    for y in sorted({ctx["years"][0], ctx["years"][-1]}):
        load = d["load"][d["year"] == y]
        peak = float(load.max())
        lole, eue = lole_eue(levels, prob, load)
        rows.append(dict(year=int(y), peak_mw=peak, dependable_mw=total, reserve_margin_pct=100 * (total - peak) / max(peak, EPS),
                         n1_capacity_mw=total - largest, n1_pass=bool(total - largest >= peak), lole_hours=lole,
                         eue_mwh=eue, eue_pct=100 * eue / max(float(load.sum()), EPS)))
    return rows


# ---------------------------------------------------------------- mitigation
def unit_costs(resolved, p):
    tp = (resolved.get("technology_parameters") or {})
    gen = dict(DEFAULT_STANDBY)
    for tech in ("diesel", "ng"):
        spec = tp.get(tech) or {}
        if spec.get("capex", 0) > 0:
            gen = dict(capex=float(spec["capex"]), fom=float(spec.get("fom", 0)),
                       energy_cost=float(spec.get("fuel", 0)) + float(spec.get("vom", 0)) + float(spec.get("carbon", 0)),
                       source=f"scenario {tech.upper()} inputs")
            break
    if p["standby_gen_capex"] is not None:
        gen.update(capex=float(p["standby_gen_capex"]), source="user input")
    bess_mw = float(p["bess_power_capex"] if p["bess_power_capex"] is not None else resolved.get("bess_power_capex") or 500000)
    bess_mwh = float(p["bess_energy_capex"] if p["bess_energy_capex"] is not None else resolved.get("bess_energy_capex") or 250000)
    return dict(gen=gen, bess_mw=bess_mw, bess_mwh=bess_mwh, bess_fom=float(resolved.get("bess_fom_fraction") or .025),
                bess_source="scenario inputs" if resolved.get("bess_power_capex") else "documented default")


def portfolio(ctx, specs, mit=None):
    """Expected per-year totals over the given contingencies (only those that can cause unserved load)."""
    years = len(ctx["years"])
    tot = dict(eue=np.zeros(years), hrs=np.zeros(years), ev=np.zeros(years), shed=np.zeros(years), worst=0.0, per={})
    for s in specs:
        res = run_contingency(ctx, s, mit)
        ex = expected(ctx, res, s["rate"])
        for k in ("eue", "hrs", "ev", "shed"):
            tot[k] += np.array(ex[k])
        tot["worst"] = max(tot["worst"], float(res["mwh"].max()))
        tot["per"][s["id"]] = res
    return tot


def mitigation_table(ctx, specs, base_per, base_tot, costs, focus_i, resolved_rate):
    p, a = ctx["p"], ctx["a"]
    voll, horizon = p["voll"], p["pv_years"]
    failing = [s for s in specs if base_per[s["id"]]["mwh"].max() > EPS]
    needs, measures = [], []
    if not failing:
        return needs, measures
    e = a["eff"]
    span = max(a["soc_max"] - a["soc_min"], .05)
    lo_y = ctx["ybounds"][focus_i]
    peak_load = float(ctx["load"][lo_y:lo_y + ctx["ycount"][focus_i]].max())
    for s in failing:
        r = base_per[s["id"]]
        mw, mwh = float(r["peak"].max()), float(r["mwh"].max())
        nameplate = mwh / e / span
        needs.append(dict(id=s["id"], name=s["name"], extra_mw=mw, extra_mwh_unserved=mwh, bess_mwh=nameplate,
                          bess_capex=mw * costs["bess_mw"] + nameplate * costs["bess_mwh"],
                          genset_capex=mw * costs["gen"]["capex"], curtail_share_pct=100 * mw / max(peak_load, EPS)))
    nongrid = [n for n in needs if n["id"] != "grid_loss"]
    grid = [n for n in needs if n["id"] == "grid_loss"]
    largest_unit = max(a["gens"].values(), default=0.0) / p["gen_units"]
    cands = []
    if nongrid:
        mw = max(max(n["extra_mw"] for n in nongrid), 0)
        cands.append(dict(id="standby_n1", name="Standby genset (N+1 for local units)", mw_gen=max(mw, largest_unit),
                          desc="Extra dispatchable generation sized to the larger of the largest local unit and the worst "
                               "local-contingency shortfall."))
        mw = max(n["extra_mw"] for n in nongrid)
        mwh = max(n["bess_mwh"] for n in nongrid)
        cands.append(dict(id="bess_local", name="Extra BESS (cover local contingencies)", mw_bess=mw, mwh_bess=mwh,
                          desc="Extra battery, held full for emergencies, sized to the worst local-contingency window."))
    if grid:
        cands.append(dict(id="backup_island", name="Backup generation to island the site (grid loss)",
                          mw_gen=grid[0]["extra_mw"], desc="Standby generation sized to the worst grid-loss shortfall."))
        cands.append(dict(id="bess_ride", name="Extra BESS to ride through grid loss", mw_bess=grid[0]["extra_mw"],
                          mwh_bess=grid[0]["bess_mwh"], desc="Battery sized to the worst grid-loss window."))
    if p["critical_fraction"] < 1:
        cands.append(dict(id="shed", name=f"Shed non-critical load ({100 * (1 - p['critical_fraction']):.0f}% of load)",
                          reduce=1 - p["critical_fraction"], kind="shed",
                          desc="Pre-agreed shedding of non-critical load, used only as needed and only after the battery, as the last resort before unserved load."))
    if p["dr_fraction"] > 0:
        cands.append(dict(id="dr", name=f"Demand response ({100 * p['dr_fraction']:.0f}% of load)", reduce=p["dr_fraction"],
                          kind="dr", desc="Contracted flexible load reduction while a contingency lasts."))
    base_cost = base_tot["eue"] * voll
    for c in cands:
        mit = dict(gen_mw=c.get("mw_gen", 0.0), gen_avail=1.0, bess_mw=c.get("mw_bess", 0.0),
                   bess_mwh=c.get("mwh_bess", 0.0), reduce=c.get("reduce", 0.0))
        tot = portfolio(ctx, failing, mit)
        local_worst = max([float(r["mwh"].max()) for k, r in tot["per"].items() if k != "grid_loss"], default=0.0)
        grid_worst = float(tot["per"]["grid_loss"]["mwh"].max()) if "grid_loss" in tot["per"] else 0.0
        avoided_mwh = base_tot["eue"] - tot["eue"]
        avoided_cost = avoided_mwh * voll
        capex = c.get("mw_gen", 0.0) * costs["gen"]["capex"] + c.get("mw_bess", 0.0) * costs["bess_mw"] + \
            c.get("mwh_bess", 0.0) * costs["bess_mwh"]
        opex = np.zeros(len(avoided_mwh))
        if c.get("mw_gen"):
            opex += c["mw_gen"] * costs["gen"]["fom"] + np.maximum(avoided_mwh, 0) * costs["gen"]["energy_cost"]
        if c.get("mw_bess"):
            opex += costs["bess_fom"] * (c["mw_bess"] * costs["bess_mw"] + c["mwh_bess"] * costs["bess_mwh"])
        if c.get("kind") == "shed":
            opex += tot["shed"] * p["shed_cost_fraction"] * voll
        if c.get("kind") == "dr":
            opex += p["dr_fraction"] * peak_load * 1000 * p["dr_standing_usd_kw_yr"] + tot["shed"] * p["dr_activation_usd_mwh"]
        cost_pv = capex + pv_series(list(opex), resolved_rate, horizon)
        benefit_pv = pv_series(list(avoided_cost), resolved_rate, horizon)
        net_annual = float(avoided_cost[focus_i] - opex[focus_i])
        measures.append(dict(
            id=c["id"], name=c["name"], description=c["desc"], size_mw=c.get("mw_gen", c.get("mw_bess", 0.0)),
            size_mwh=c.get("mwh_bess", 0.0), capex=float(capex), annual_opex=float(opex[focus_i]), cost_pv=float(cost_pv),
            residual_eue_mwh_yr=float(tot["eue"][focus_i]), residual_downtime_h_yr=float(tot["hrs"][focus_i]),
            avoided_eue_mwh_yr=float(avoided_mwh[focus_i]), avoided_downtime_h_yr=float(base_tot["hrs"][focus_i] - tot["hrs"][focus_i]),
            avoided_cost_yr=float(avoided_cost[focus_i]), avoided_cost_pv=float(benefit_pv),
            net_benefit_pv=float(benefit_pv - cost_pv), benefit_cost_ratio=float(benefit_pv / cost_pv) if cost_pv > EPS else None,
            payback_years=(float(capex / net_annual) if capex > EPS and net_annual > EPS else (0.0 if capex <= EPS and net_annual > 0 else None)),
            worst_window_residual_mwh=float(tot["worst"]), covers_worst_case=bool(tot["worst"] <= EPS),
            residual_local_worst_mwh=local_worst, residual_grid_worst_mwh=grid_worst,
            covers_local=(local_worst <= EPS) if any(s["id"] != "grid_loss" for s in failing) else None,
            covers_grid=(grid_worst <= EPS) if any(s["id"] == "grid_loss" for s in failing) else None,
            cost_basis=(costs["gen"]["source"] if c.get("mw_gen") else costs["bess_source"] if c.get("mw_bess") else "user inputs")))
    measures.sort(key=lambda m: -m["net_benefit_pv"])
    for i, m in enumerate(measures, 1):
        m["rank"] = i
    return needs, measures


# ---------------------------------------------------------------- scenario analysis
def analyse_scenario(folder, code, p):
    path = folder / f"result_{code}.json"
    if not re.fullmatch(r"[A-Za-z0-9_]+", str(code)) or not path.is_file() or not (folder / f"dispatch_{code}.csv").is_file():
        raise ValueError("Choose a solved scenario.")
    result = json.loads(path.read_text(encoding="utf-8"))
    try:
        resolved = json.loads((folder / "run_configuration.json").read_text(encoding="utf-8"))["resolved"]
    except (OSError, KeyError, ValueError):
        resolved = {}
    d = load_dispatch(folder, code)
    has_grid = True
    try:
        defs = json.loads((folder / "request.json").read_text(encoding="utf-8")).get("scenario_definitions") or []
        has_grid = "grid" in next(s["technologies"] for s in defs if s.get("id") == code)
    except (OSError, ValueError, StopIteration, KeyError, TypeError):
        pass
    ref_peak = max([float(a.get("forecast_peak_mw") or 0) for a in (result.get("economics") or {}).get("annual", [])] + [0.0])
    assets = build_assets(result["caps"], resolved, code, p, has_grid, ref_peak)
    ctx = make_ctx(d, assets, p, p["outage_hours"])
    rate = float(p["discount"] if p["discount"] is not None else resolved.get("discount", .06))
    voll, horizon = p["voll"], p["pv_years"]
    years = ctx["years"]
    focus = int(p["focus_year"]) if p["focus_year"] is not None else years[-1]
    if focus not in years:
        raise ValueError(f"Headline year must be one of {years[0]}-{years[-1]}.")
    fi = years.index(focus)
    specs = make_specs(ctx)
    starts_ts = {t: i for i, t in enumerate(d["ts"][:ctx["starts"]])}
    custom_i = None
    if p["start"]:
        custom_i = starts_ts.get(p["start"] if len(p["start"]) > 16 else p["start"] + ":00")
        if custom_i is None:
            raise ValueError("The outage start must be an hour in the saved dispatch and leave room for the whole outage.")
    focus_mask = d["year"] == focus
    focus_load = d["load"][focus_mask]
    peak = float(focus_load.max())
    annual_mwh = float(focus_load.sum())
    rows, per = [], {}
    for s in specs:
        res = run_contingency(ctx, s)
        per[s["id"]] = res
        ex = expected(ctx, res, s["rate"])
        lo = ctx["ybounds"][fi]
        hi = lo + ctx["ycount"][fi]
        seg = res["mwh"][lo:hi]
        worst_all = int(np.argmax(res["mwh"]))
        worst_focus = lo + int(np.argmax(seg))
        firm_after = firm_capacity(assets, s) + assets["bess_mw"] * s.get("bess", 1.0)
        cost_y = [v * voll for v in ex["eue"]]
        row = dict(
            id=s["id"], kind=s["kind"], name=s["name"], description=s["desc"], lost_mw=float(s["lost_mw"]),
            outage_rate=float(s["rate"]), events_per_year=float(ex["lam"]), peak_margin_mw=float(firm_after - peak),
            peak_n1_pass=bool(firm_after >= peak),
            mean_event_mwh=float(res["mwh"][lo:hi].mean()), worst_event_mwh=float(seg.max()),
            worst_event_hours=int(res["hrs"][worst_focus]), worst_event_peak_mw=float(res["peak"][worst_focus]),
            worst_event_start=d["ts"][worst_focus],
            worst_load_served_pct=float(100 * (1 - res["mwh"][worst_focus] / max(float(d["load"][worst_focus:worst_focus + ctx["hours"]].sum()), EPS))),
            starts_with_unserved_pct=float(100 * (res["hrs"][lo:hi] > 0).mean()),
            worst_all_years_mwh=float(res["mwh"][worst_all]), worst_all_years_start=d["ts"][worst_all],
            eue_mwh_yr=float(ex["eue"][fi]), downtime_h_yr=float(ex["hrs"][fi]), interruptions_yr=float(ex["ev"][fi]),
            cost_yr=float(cost_y[fi]), cost_pv=float(pv_series(cost_y, rate, horizon)),
            by_year=[dict(year=y, eue_mwh=float(ex["eue"][i]), downtime_h=float(ex["hrs"][i]), cost=float(cost_y[i]))
                     for i, y in enumerate(years)],
            worst_window=trace(ctx, s, worst_focus))
        if custom_i is not None:
            row["custom_window"] = dict(start=d["ts"][custom_i], unserved_mwh=float(res["mwh"][custom_i]),
                                        downtime_hours=int(res["hrs"][custom_i]), peak_mw=float(res["peak"][custom_i]),
                                        trace=trace(ctx, s, custom_i))
        rows.append(row)
    # largest-unit N-1 roll-up (a view of the worst single supply unit, not an extra event)
    supply = [r for r in rows if r["kind"] in ("grid", "gen_unit", "bess", "pv", "wind", "planned")]
    largest = max(supply, key=lambda r: r["lost_mw"], default=None)
    totals = {k: sum(r[k] for r in rows) for k in ("eue_mwh_yr", "downtime_h_yr", "interruptions_yr", "cost_yr", "cost_pv")}
    by_year_tot = [dict(year=y, eue_mwh=sum(r["by_year"][i]["eue_mwh"] for r in rows),
                        downtime_h=sum(r["by_year"][i]["downtime_h"] for r in rows),
                        cost=sum(r["by_year"][i]["cost"] for r in rows)) for i, y in enumerate(years)]
    base_tot = dict(eue=np.array([x["eue_mwh"] for x in by_year_tot]), hrs=np.array([x["downtime_h"] for x in by_year_tot]),
                    ev=np.zeros(len(years)), shed=np.zeros(len(years)), worst=0.0)
    costs = unit_costs(resolved, p)
    needs, measures = mitigation_table(ctx, specs, per, base_tot, costs, fi, rate)
    sched = [float(d["shortfall"][d["year"] == y].sum()) for y in years]
    local_secure = all(r["worst_all_years_mwh"] <= EPS for r in rows if r["kind"] not in ("grid",))
    grid_secure = all(r["worst_all_years_mwh"] <= EPS for r in rows if r["kind"] == "grid")
    lole = totals["downtime_h_yr"]
    verdict = "PASS" if lole <= 2.4 and local_secure else "WARN" if lole <= 24 else "FAIL"
    worst_row = max(rows, key=lambda r: r["worst_event_mwh"], default=None)
    top_row = max(rows, key=lambda r: r["cost_yr"], default=None)
    served = 100 * (1 - (totals["eue_mwh_yr"] + sched[fi]) / max(annual_mwh, EPS))
    return dict(
        scenario=code, name=result.get("name", code), generated=datetime.now().isoformat(timespec="seconds"),
        params=p, discount_rate=rate, focus_year=focus, years=years, verdict=verdict, criteria=CRITERIA,
        verdict_detail=dict(lole_h_yr=lole, local_n1_secure=local_secure, grid_n1_secure=grid_secure),
        assets=dict(grid_mw=assets["grid"], generators_mw=assets["gens"], bess_mw=assets["bess_mw"],
                    bess_mwh=assets["bess_mwh"], pv_mw=assets["pv_mw"], peak_load_mw=peak, annual_load_mwh=annual_mwh),
        summary=dict(eue_mwh_yr=totals["eue_mwh_yr"], lole_h_yr=lole, interruptions_yr=totals["interruptions_yr"],
                     saidi_like_h_yr=lole, caidi_like_h=lole / totals["interruptions_yr"] if totals["interruptions_yr"] > 0 else 0.0,
                     load_served_pct=served, cost_yr=totals["cost_yr"], cost_pv=totals["cost_pv"],
                     scheduled_unserved_mwh_yr=sched[fi], scheduled_unserved_cost_yr=sched[fi] * voll,
                     scheduled_unserved_cost_pv=pv_series([v * voll for v in sched], rate, horizon),
                     worst_event=dict(name=worst_row["name"], mwh=worst_row["worst_event_mwh"],
                                      start=worst_row["worst_event_start"]) if worst_row else None,
                     costliest=top_row["name"] if top_row and top_row["cost_yr"] > 0 else None,
                     best_measure=measures[0]["name"] if measures else None, by_year=by_year_tot),
        contingencies=rows,
        largest_unit_n1=dict(contingency=largest["id"], name=f"Largest unit N-1: {largest['name']}", lost_mw=largest["lost_mw"],
                             worst_event_mwh=largest["worst_event_mwh"], eue_mwh_yr=largest["eue_mwh_yr"],
                             cost_yr=largest["cost_yr"], peak_margin_mw=largest["peak_margin_mw"]) if largest else None,
        needs=needs, measures=measures, qualitative_measures=list(QUALITATIVE), unit_costs=costs,
        copt=dict(rows=copt_rows(ctx), note="Secondary statistical screen: capacity-outage probability table of "
                  "independent units against hourly net load; no energy storage limits, no PV credit."),
        model_check=model_check(ctx),
        method=list(METHOD), assumptions=list(ASSUMPTIONS))


def model_check(ctx):
    """Single-hour replay of the whole dispatch against the optimizer's own unserved energy (sanity check)."""
    a, d = ctx["a"], ctx["d"]
    own = ctx["hours"]
    sim = window_sim(ctx["load"], ctx["pv"] + ctx["wind"], firm_capacity(a, {}, None, ctx["adder"]), a["bess_mw"], a["bess_mwh"],
                     np.concatenate([[d["soc"][0]], d["soc"][:-1]]), 1, a["soc_min"], a["soc_max"], a["eff"])
    return dict(replay_unserved_mwh=float(sim["short"].sum()), saved_unserved_mwh=float(d["shortfall"].sum()),
                outage_hours=own)


def save(folder, code, out):
    target = folder / "reliability"
    target.mkdir(exist_ok=True)
    (target / f"{code}.json").write_text(json.dumps(out, indent=1), encoding="utf-8")


def scenario_codes(folder):
    codes = [f.stem[len("result_"):] for f in folder.glob("result_*.json")]
    return sorted(codes, key=lambda c: (c != "R0", c))


def comparison(results):
    rows = []
    for r in results:
        s = r["summary"]
        rows.append(dict(scenario=r["scenario"], name=r["name"], verdict=r["verdict"], eue_mwh_yr=s["eue_mwh_yr"],
                         lole_h_yr=s["lole_h_yr"], interruptions_yr=s["interruptions_yr"],
                         load_served_pct=s["load_served_pct"], cost_yr=s["cost_yr"], cost_pv=s["cost_pv"],
                         worst_event=s["worst_event"], best_measure=s["best_measure"]))
    return rows


def analyse(payload):
    folder = extensions.run_folder(payload.get("run_id"))
    p = parse_params(payload)
    want = payload.get("scenario")
    codes = scenario_codes(folder) if want in (None, "", "all") else [want]
    skipped = []
    if want in (None, "", "all"):
        skipped = [c for c in codes if not (folder / f"dispatch_{c}.csv").is_file()]
        codes = [c for c in codes if c not in skipped]
    if not codes:
        raise ValueError("The run has no solved scenarios with a saved dispatch.")
    with LOCK:
        results = []
        for code in codes:
            out = analyse_scenario(folder, code, p)
            out["run_id"] = payload["run_id"]
            save(folder, code, out)
            results.append(out)
    return dict(run_id=payload["run_id"], results=results, comparison=comparison(results), skipped=skipped)


def saved(query):
    folder = extensions.run_folder((query.get("run_id") or [""])[0])
    code = (query.get("scenario") or [""])[0]
    target = folder / "reliability"
    if code:
        path = target / f"{code}.json"
        if not re.fullmatch(r"[A-Za-z0-9_]+", code) or not path.is_file():
            return dict(run_id=folder.name, results=[], comparison=[])
        results = [json.loads(path.read_text(encoding="utf-8"))]
    else:
        results = [json.loads((target / f"{c}.json").read_text(encoding="utf-8")) for c in scenario_codes(folder)
                   if (target / f"{c}.json").is_file()]
    return dict(run_id=folder.name, results=results, comparison=comparison(results))


def info(query):
    return dict(defaults=defaults(), labels={k: dict(label=v[3], unit=v[4]) for k, v in PARAMS.items()},
                method=list(METHOD), criteria=CRITERIA, assumptions=list(ASSUMPTIONS))


extensions.POST["reliability"] = analyse
extensions.GET["reliability_saved"] = saved
extensions.GET["reliability_info"] = info
