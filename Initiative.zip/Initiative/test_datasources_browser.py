"""Browser test of the public data / map dialog. The real server runs through datasources_mock_server.py,
so every external call (NASA POWER, PVGIS, OSM, FCC) is answered locally; nothing depends on the internet."""

import re
import socket
import subprocess
import sys
import time
import unittest
from pathlib import Path
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"


class DataSourcesBrowserTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        cls.base = f"http://127.0.0.1:{port}"
        cls.server = subprocess.Popen([sys.executable, str(ROOT / "datasources_mock_server.py"), "--port", str(port)],
                                      cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(200):
            try:
                urlopen(cls.base + "/api/x/ds_catalog", timeout=.5).close()
                return
            except OSError:
                time.sleep(.1)
        cls.server.terminate()
        raise RuntimeError("mock server did not start")

    @classmethod
    def tearDownClass(cls):
        cls.server.terminate()
        cls.server.wait(10)

    def open_section(self, page, group, button):
        page.locator("#input-navigation details").filter(
            has=page.locator("summary").filter(has_text=re.compile(f"^{group}$"))).locator("summary").click()
        page.locator("#input-navigation details[open] button", has_text=button).first.click()

    def test_map_dialog_solar_download_and_apply(self):
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
            page = browser.new_context(viewport={"width": 1600, "height": 1000}).new_page()
            errors, blocked = [], []
            page.on("pageerror", lambda exc: errors.append(str(exc)))
            page.on("console", lambda m: blocked.append(m.text) if "Content Security Policy" in m.text else None)
            page.goto(self.base + "/")
            page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
            self.assertGreaterEqual(page.locator(".ds-open").count(), 5)
            self.open_section(page, "Solar PV", "Hourly resource")
            page.locator(".ds-open[data-target=solar-upload]").click()
            dialog = page.locator("#ds-dialog")
            dialog.wait_for(state="visible")
            page.wait_for_selector("#ds-map.leaflet-container")
            page.wait_for_selector("#ds-map .leaflet-tile-loaded", timeout=15000)   # tiles arrive through /api/x/tile

            dialog.locator("#ds-q").fill("Los Angeles")
            dialog.locator("#ds-find").click()
            dialog.locator("#ds-results button").first.click()
            self.assertAlmostEqual(float(dialog.locator("#ds-lat").input_value()), 34.0537, places=3)
            page.wait_for_function("() => document.querySelector('#ds-where').textContent.includes('Los Angeles County')")

            dialog.locator("#ds-lat").fill("34.0522")
            dialog.locator("#ds-lon").fill("-118.2437")
            dialog.locator("#ds-lon").dispatch_event("change")
            dialog.locator("[name=source]").select_option("nasa_power")
            dialog.locator("[name=start_year]").fill("2022")
            dialog.locator("[name=end_year]").fill("2022")
            dialog.locator("#ds-fetch").click()
            out = dialog.locator("#ds-out")
            out.wait_for(state="visible", timeout=60000)
            text = out.inner_text()
            self.assertIn("Annual irradiation", text)
            self.assertIn("Missing data", text)
            self.assertEqual(out.locator("svg.ds-chart").count(), 3)
            self.assertIn("Provenance", text)
            self.assertTrue(out.locator("a.ds-link").first.get_attribute("href").startswith("/api/x/ds_file?name="))

            dialog.locator("#ds-use").click()
            dialog.wait_for(state="hidden")
            prep = page.locator("#data-check-dialog")
            try:
                prep.wait_for(state="visible", timeout=8000)
                prep.get_by_role("button", name="Accept corrections and continue").click()
                prep.wait_for(state="detached")
            except Exception:
                pass   # a clean file is accepted silently by the same dataPrep.review path
            page.wait_for_function("() => /solar_resource_nasa_power/.test(document.querySelector('#solar-file-status').textContent)", timeout=15000)
            self.assertTrue(page.locator("#solar_profile_enabled").is_checked())
            self.assertEqual(errors, [])
            self.assertEqual(blocked, [])
            browser.close()

    def test_load_dialog_and_form_state(self):
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
            page = browser.new_context(viewport={"width": 1600, "height": 1000}).new_page()
            errors = []
            page.on("pageerror", lambda exc: errors.append(str(exc)))
            page.goto(self.base + "/")
            page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
            self.open_section(page, "Demand", "Load profiles")
            page.locator("#add-load").click()
            page.locator(".ds-open[data-target=demand-import]").click()
            dialog = page.locator("#ds-dialog")
            dialog.wait_for(state="visible")
            dialog.locator("#ds-fetch").click()
            self.assertIn("location", dialog.locator("#ds-msg").inner_text().lower())   # no point chosen yet
            page.evaluate("() => localStorage.removeItem('genstudio_last_location')")
            dialog.locator("#ds-last").click()
            self.assertIn("No previous", dialog.locator("#ds-msg").inner_text())
            dialog.locator("#ds-lat").fill("34.05")
            dialog.locator("#ds-lon").fill("-118.24")
            dialog.locator("#ds-lon").dispatch_event("change")
            dialog.locator("[name=source]").select_option("eia930")
            self.assertTrue(dialog.locator("[name=eia_key]").is_visible())
            self.assertEqual(dialog.locator("[name=eia_key]").get_attribute("type"), "password")
            dialog.locator("[name=eia_key]").fill("a" * 10)
            dialog.locator("#ds-fetch").click()
            page.wait_for_function("() => document.querySelector('#ds-msg').textContent.includes('EIA')", timeout=20000)
            self.assertEqual(page.evaluate("() => JSON.stringify([localStorage, sessionStorage])").count("aaaaaaaaaa"), 0)
            dialog.locator("[name=source]").select_option("typical")
            dialog.locator("[name=peak_mw]").fill("8")
            dialog.locator("#ds-fetch").click()
            dialog.locator("#ds-out").wait_for(state="visible", timeout=60000)
            self.assertIn("Peak", dialog.locator("#ds-out").inner_text())
            self.assertIn("proxy", dialog.locator("#ds-out").inner_text().lower())
            self.assertEqual(errors, [])
            browser.close()


if __name__ == "__main__":
    unittest.main()
