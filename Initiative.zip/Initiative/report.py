"""Data helpers, SVG charts and section builders for the client project report, plus the report routes.

Routes (see extensions.py):
    GET/POST /api/x/report          -> one HTML document (inline CSS and SVG, no external resources); see report_doc
    GET /api/x/report_summary?run_id= -> best option, per-scenario technical/reliability status, economic,
                                         sensitivity and reliability digest for the in-app Result summary

Everything is read from the saved run folder. Optional analyses (sensitivity, reliability, power flow) are read
defensively: when their saved output is missing the report shows a "not run" section instead of failing.
"""

import csv
import datetime
import html
import json
import math
import re
import sys
from pathlib import Path

import extensions
import currency

TECH_GROUPS = [("pv", "Solar PV", "Solar PV"), ("bess", "BESS", "Battery storage (BESS)"),
               ("wind", "Wind", "Wind"), ("h2", "Hydrogen turbine", "Hydrogen turbine"),
               ("h2_chp", "Hydrogen CHP", "Hydrogen CHP"), ("ng", "Natural gas turbine", "Natural gas turbine"),
               ("ng_chp", "Natural gas CHP", "Natural gas CHP"), ("diesel", "Diesel generator", "Diesel generator"),
               ("biogas", "Biogas generator", "Biogas generator"), ("biomass", "Biomass generator", "Biomass generator")]
GEN_NAMES = {key: label for key, _, label in TECH_GROUPS}
CONSTRAINT_KEYS = ["grid_limit", "reference_grid_limit", "microgrid_min_mw", "microgrid_max_mw", "duration_min",
                   "duration_max", "soc_min", "soc_max", "daily_cycles", "solar_land_enabled", "bess_land_enabled",
                   "wind_land_enabled", "emissions_limit_enabled", "emissions_limit_t_year", "export_enabled",
                   "export_limit_mw", "thermal_enabled", "include_replacements", "extended_appraisal", "reactive_enabled",
                   "h2_tc_enabled", "h2_chp_tc_enabled", "ng_tc_enabled", "ng_chp_tc_enabled"]
COST_COMPONENTS = [("grid", "Grid energy and demand charges"), ("fom", "Fixed O&M"), ("fuel", "Fuel"),
                   ("variable", "Variable O&M"), ("carbon", "Carbon cost"), ("upgrade_om", "Upgrade O&M"),
                   ("replacement", "Replacements")]
# (result key, label, sign): the signed present values add up to the scenario NPC; a heat credit reduces cost.
NPC_COMPONENTS = [("capex", "Upfront capital (incl. connection)", 1), ("grid_pv", "Grid energy and demand charges", 1), ("fuel_pv", "Fuel", 1),
                  ("variable_om_pv", "Variable O&M", 1), ("fixed_om_pv", "Fixed O&M", 1), ("carbon_pv", "Carbon cost", 1),
                  ("replacement_pv", "Replacements", 1), ("upgrade_pv", "Grid upgrade", 1), ("upgrade_om_pv", "Upgrade O&M", 1),
                  ("heat_credit_pv", "Heat credit", -1)]
COLORS = ["#2f6fb3", "#e0a030", "#4f8f5b", "#c0504d", "#7a5ea8", "#3aa6a6", "#8a8f98", "#b5651d"]


# --------------------------------------------------------------------------- formatting

def esc(value):
    return html.escape("" if value is None else str(value), quote=True)


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def num(value, digits=1):
    return f"{value:,.{min(digits, 4)}f}" if finite(value) else "n/a"


def usd(value):
    if not finite(value):
        return "n/a"
    return currency.money(value, 1.0, 0)


def mil(value, digits=2):
    if not finite(value):
        return "n/a"
    return currency.money(value, 1e6, digits, "M")


def pct(value, digits=1):
    return f"{value:+.{min(digits, 4)}f}%" if finite(value) else "n/a"


def plain(value):
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, (int, float)):
        if not math.isfinite(value):
            return "n/a"
        if abs(value) >= 1000 and float(value).is_integer():
            return f"{value:,.0f}"
        return f"{value:.4f}".rstrip("0").rstrip(".") or "0"
    return "" if value is None else str(value)


def element_names(run):
    """Map internal single-line-diagram ids (nodes and lines) to the names shown on the diagram."""
    cached = run.get("_names")
    if cached is not None:
        return cached
    names, lines = {}, []

    def walk(node, depth=0):
        if depth > 8:
            return
        if isinstance(node, dict):
            ident = node.get("id")
            if isinstance(ident, str) and len(ident) >= 5:
                label = node.get("label") or node.get("name")
                if isinstance(label, str) and label.strip():
                    names.setdefault(ident, " ".join(label.split()))
                elif node.get("source") and node.get("target"):
                    lines.append(node)
            for value in node.values():
                walk(value, depth + 1)
        elif isinstance(node, list):
            for value in node:
                walk(value, depth + 1)

    walk(run["request"].get("topology"))
    walk((run["config"] or {}).get("topology"))
    for line in lines:
        if line["id"] not in names:
            names[line["id"]] = f"{names.get(line['source'], 'bus')} to {names.get(line['target'], 'bus')} line"
    run["_names"] = names
    return names


def plant_names(run, html_text):
    """Replace internal element ids in visible text with the plant names."""
    names = element_names(run)
    if not names:
        return html_text
    pattern = re.compile(r"(?<![\w-])(" + "|".join(re.escape(k) for k in sorted(names, key=len, reverse=True)) + r")(?![\w-])")
    return re.sub(r">([^<>]+)<", lambda m: ">" + pattern.sub(lambda hit: esc(names[hit.group(1)]), m.group(1)) + "<", html_text)


def cut_text(cut, names):
    if not isinstance(cut, dict):
        return str(cut)
    who = names.get(cut.get("component"), cut.get("component"))
    parts = [cut.get("reason") or cut.get("message") or str(cut.get("type") or "").replace("_", " ")]
    if cut.get("case"):
        parts.append(f"Case: {cut['case']}.")
    if who:
        parts.append(f"Affects: {who}.")
    return " ".join(p for p in parts if p)


def badge(text, kind=""):
    return f'<span class="badge {kind}">{esc(text)}</span>'


def status_kind(status):
    return {"PASS": "pass", "WARN": "warn", "FAIL": "fail"}.get(str(status).upper(), "")


NUMERIC_CELL = re.compile(r"^[\s$+\-\u2212(]*[\d.,]+\s*[%MkK)]?\s*(?:[A-Za-z%/$ ]{0,12})?$")


def _numeric_like(cell):
    """True for numbers (with sign, $, unit suffix) and empty/placeholder cells; free text stays left-aligned."""
    if cell is None or isinstance(cell, (int, float)):
        return True
    text = str(cell).strip()
    return text in ("", "-", "n/a", "\u2014") or bool(NUMERIC_CELL.match(text)) and len(text) <= 24


def table(headers, rows, numeric=(), row_classes=None, raw_cols=()):
    """Rows hold plain values; columns listed in raw_cols are already-escaped HTML.

    Numeric columns right-align only the cells that look numeric, so text values in a mixed column stay readable."""
    head = "".join(f'<th class="{"n" if i in numeric else ""}">{esc(currency.label(h))}</th>' for i, h in enumerate(headers))
    body = []
    for r, row in enumerate(rows):
        cls = f' class="{row_classes[r]}"' if row_classes and row_classes[r] else ""
        cells = "".join(f'<td class="{"n" if i in numeric and (i in raw_cols or _numeric_like(c)) else ""}">{c if i in raw_cols else esc(c)}</td>'
                        for i, c in enumerate(row))
        body.append(f"<tr{cls}>{cells}</tr>")
    wide = ' class="wide"' if len(headers) >= 9 else ""
    return f'<table{wide}><thead><tr>{head}</tr></thead><tbody>{"".join(body)}</tbody></table>'


def bullets(items):
    return "<ul>" + "".join(f"<li>{esc(i)}</li>" for i in items) + "</ul>" if items else ""


def notrun(text):
    return f'<div class="notrun">{esc(text)}</div>'


# --------------------------------------------------------------------------- SVG charts

def nice_max(value):
    if value <= 0:
        return 1.0
    step = 10 ** (len(str(int(value))) - 1) if value >= 1 else 10 ** -3
    for mult in (1, 2, 4, 8, 10):
        if mult * step >= value:
            return mult * step
    return value


def axis_fmt(value):
    return f"{value / 1e6:,.0f}M" if abs(value) >= 1e6 else f"{value / 1e3:,.0f}k" if abs(value) >= 1e4 else f"{value:,.4g}"


def svg_open(width, height, label):
    return f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="{esc(label)}" xmlns="http://www.w3.org/2000/svg">'


def legend(series, x, y):
    out, cursor = [], x
    for name, color in series:
        out.append(f'<rect x="{cursor:.0f}" y="{y}" width="10" height="10" fill="{color}"/>'
                   f'<text x="{cursor + 14:.0f}" y="{y + 9}">{esc(name)}</text>')
        cursor += 14 + 6.2 * len(str(name)) + 18
    return "".join(out)


def bar_chart(items, label, unit="$M", best=None):
    """Horizontal bars: items = [(label, value)]; the bar of `best` is highlighted."""
    if not items:
        return ""
    width, left, row = 900, 250, 26
    height = 20 + row * len(items)
    top = max(v for _, v in items) or 1
    out = [svg_open(width, height, label)]
    for i, (name, value) in enumerate(items):
        y = 10 + i * row
        w = (width - left - 90) * max(value, 0) / top
        color = "#00827c" if name == best else "#9db4c8"
        out.append(f'<text x="{left - 8}" y="{y + 15}" text-anchor="end">{esc(name[:40])}</text>'
                   f'<rect x="{left}" y="{y + 2}" width="{w:.1f}" height="{row - 8}" fill="{color}"/>'
                   f'<text x="{left + w + 6:.1f}" y="{y + 15}">{value:,.1f} {esc(unit)}</text>')
    return "".join(out) + "</svg>"


def stacked_columns(categories, series, label, unit):
    """series = [(name, values, color)]; one stacked column per category."""
    if not categories:
        return ""
    width, height, left, bottom, top = 900, 330, 70, 70, 14
    totals = [sum(max(s[1][i], 0) for s in series) for i in range(len(categories))]
    ymax = nice_max(max(totals + [1e-9]))
    y = lambda v: top + (height - top - bottom) * (1 - v / ymax)
    band = (width - left - 10) / len(categories)
    out = [svg_open(width, height, label)]
    for k in range(5):
        v = ymax * k / 4
        out.append(f'<line class="grid" x1="{left}" x2="{width - 10}" y1="{y(v):.1f}" y2="{y(v):.1f}"/>'
                   f'<text x="{left - 6}" y="{y(v) + 4:.1f}" text-anchor="end">{axis_fmt(v)}</text>')
    for i, cat in enumerate(categories):
        base = 0
        for name, values, color in series:
            v = max(values[i], 0)
            if v > 0:
                out.append(f'<rect x="{left + i * band + band * .15:.1f}" y="{y(base + v):.1f}" width="{band * .7:.1f}" '
                           f'height="{y(base) - y(base + v):.1f}" fill="{color}"><title>{esc(cat)} {esc(name)}: {v:,.1f}</title></rect>')
            base += v
        out.append(f'<text x="{left + i * band + band / 2:.1f}" y="{height - bottom + 14}" text-anchor="middle">{esc(cat)}</text>')
    out.append(f'<line class="axis" x1="{left}" x2="{left}" y1="{top}" y2="{y(0):.1f}"/>'
               f'<text x="12" y="{top + 8}">{esc(unit)}</text>')
    out.append(legend([(n, c) for n, _, c in series], left, height - 28))
    return "".join(out) + "</svg>"


def line_chart(xs, series, label, unit, xlabels=()):
    """series = [(name, values, color)] on a shared hourly x axis."""
    if not xs:
        return ""
    width, height, left, bottom, top = 900, 300, 70, 62, 14
    lo = min(0, min(min(s[1]) for s in series))
    hi = max(max(s[1]) for s in series)
    ymax = nice_max(hi) if hi > 0 else 1
    ymin = -nice_max(-lo) if lo < 0 else 0
    y = lambda v: top + (height - top - bottom) * (1 - (v - ymin) / (ymax - ymin))
    x = lambda i: left + (width - left - 10) * i / max(len(xs) - 1, 1)
    out = [svg_open(width, height, label)]
    for k in range(5):
        v = ymin + (ymax - ymin) * k / 4
        out.append(f'<line class="grid" x1="{left}" x2="{width - 10}" y1="{y(v):.1f}" y2="{y(v):.1f}"/>'
                   f'<text x="{left - 6}" y="{y(v) + 4:.1f}" text-anchor="end">{v:,.4g}</text>')
    for i, text in xlabels:
        out.append(f'<text x="{x(i):.1f}" y="{height - bottom + 14}" text-anchor="middle">{esc(text)}</text>')
    for name, values, color in series:
        points = " ".join(f"{x(i):.1f},{y(v):.1f}" for i, v in enumerate(values))
        out.append(f'<polyline fill="none" stroke="{color}" stroke-width="1.6" points="{points}"/>')
    out.append(f'<text x="12" y="{top + 8}">{esc(unit)}</text>')
    out.append(legend([(n, c) for n, _, c in series], left, height - 28))
    return "".join(out) + "</svg>"


def waterfall(info):
    steps = info.get("steps") or []
    if not steps or info.get("start") is None:
        return ""
    pts = [dict(label=info["reference"], total=info["start"])]
    running = info["start"]
    for s in steps:
        pts.append(dict(label=s["label"], frm=running, to=running + s["delta"]))
        running += s["delta"]
    pts.append(dict(label=info["name"], total=info["end"]))
    width, height, left, bottom, top = 900, 340, 120, 100, 22
    vals = [0] + [p["total"] if "total" in p else v for p in pts for v in ((p["total"],) if "total" in p else (p["frm"], p["to"]))]
    hi, lo = max(vals) * 1.08, min(vals)
    y = lambda v: top + (height - top - bottom) * (1 - (v - lo) / (hi - lo))
    band = (width - left - 10) / len(pts)
    out = [svg_open(width, height, "NPC waterfall")]
    for i, p in enumerate(pts):
        a, b = (lo, p["total"]) if "total" in p else (p["frm"], p["to"])
        color = "#2f6fb3" if "total" in p else "#4f8f5b" if b < a else "#c0504d"
        xx = left + i * band + band * .15
        out.append(f'<rect x="{xx:.1f}" y="{y(max(a, b)):.1f}" width="{band * .7:.1f}" height="{max(abs(y(a) - y(b)), 1):.1f}" fill="{color}"/>'
                   f'<text x="{xx + band * .35:.1f}" y="{y(max(a, b)) - 4:.1f}" text-anchor="middle">'
                   f'{mil(p["total"], 1) if "total" in p else ("+" if b >= a else "-") + mil(abs(b - a), 1)}</text>'
                   f'<text x="{xx + band * .35:.1f}" y="{height - bottom + 14}" text-anchor="end" '
                   f'transform="rotate(-30 {xx + band * .35:.1f} {height - bottom + 14})">{esc(p["label"][:30])}</text>')
    return "".join(out) + "</svg>"


def tornado(swings, base):
    swings = sorted(swings, key=lambda s: -s["swing"])[:12]
    if not swings:
        return ""
    width, left, row = 900, 300, 26
    height = 40 + row * len(swings)
    span = max(max(abs(s["npc_low"] - base), abs(s["npc_high"] - base)) for s in swings) or 1
    mid = left + (width - left - 40) / 2
    scale = (width - left - 40) / 2 / span
    out = [svg_open(width, height, "Tornado chart of NPC change"),
           f'<text x="{mid:.1f}" y="14" text-anchor="middle">Base NPC {mil(base, 1)}</text>']
    for i, s in enumerate(swings):
        yy = 24 + i * row
        out.append(f'<text x="{left - 8}" y="{yy + 15}" text-anchor="end">{esc(s["label"][:44])}</text>')
        for npc, tag in ((s["npc_low"], "low"), (s["npc_high"], "high")):
            d = npc - base
            out.append(f'<rect x="{min(mid, mid + d * scale):.1f}" y="{yy + 2}" width="{abs(d) * scale:.1f}" height="{row - 8}" '
                       f'fill="{"#4f8f5b" if d < 0 else "#c0504d"}"><title>{esc(tag)}: {mil(npc, 1)} ({mil(d, 1)})</title></rect>')
    out.append(f'<line class="axis" x1="{mid:.1f}" x2="{mid:.1f}" y1="18" y2="{height - 4}"/>')
    return "".join(out) + "</svg>"


# --------------------------------------------------------------------------- data access

def read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def app_module():
    for name in ("generation_app", "__main__"):
        mod = sys.modules.get(name)
        if mod is not None and hasattr(mod, "FIELDS"):
            return mod
    import generation_app
    return generation_app


def fields():
    try:
        return app_module().FIELDS
    except Exception:
        return []


def load_run(run_id):
    folder = extensions.run_folder(run_id)
    request = read_json(folder / "request.json") or {}
    currency.activate(request.get("values"))
    config = read_json(folder / "run_configuration.json") or {}
    status = read_json(folder / "status.json") or {}
    results = {}
    for path in sorted(folder.glob("result_*.json")):
        data = read_json(path)
        if isinstance(data, dict) and data.get("code") and isinstance(data.get("economics"), dict):
            results[data["code"]] = data
    if not results:
        raise ValueError("This run has no saved scenario results; complete a solve first.")
    order = [s["id"] for s in request.get("scenario_definitions") or [] if isinstance(s, dict) and s.get("id") in results]
    order += [c for c in results if c not in order]
    return dict(folder=folder, run_id=run_id, request=request, config=config, status=status,
                results={c: results[c] for c in order}, values=request.get("values") or {},
                resolved=config.get("resolved") or {}, summary=read_json(folder / "summary.json") or {},
                reference=request.get("comparison_reference") or ("R0" if "R0" in results else None))


def is_feasible(result):
    a = result.get("adequacy") or {}
    return not a.get("unserved_hours") and (a.get("stress_unserved_mwh") or 0) <= 5e-5


def total_npc(result):
    """Ranking NPC shown everywhere: optimizer NPC plus corrections already applied (workflow.total_npc)."""
    import workflow
    return workflow.total_npc(result)


def pick_best(results, folder=None):
    """Recommended scenario and whether it is fully supplied.

    With the run folder this is the workflow recommendation (lowest total NPC among fully served scenarios, ties to the
    simpler option) shared by every page and report; without it, the lowest optimizer NPC among fully served scenarios."""
    if folder is not None and results:
        import workflow
        code = workflow.recommendation(folder, results)["code"]
        if code in results:
            return code, is_feasible(results[code])
    pool = [r for r in results.values() if is_feasible(r)]
    if pool:
        return min(pool, key=lambda r: r["economics"]["npc"])["code"], True
    return min(results.values(), key=lambda r: ((r.get("adequacy") or {}).get("unserved_mwh", 0),
                                                r["economics"]["npc"]))["code"], False


def reliability_for(folder, code):
    data = read_json(Path(folder) / "reliability" / f"{code}.json")
    return data if isinstance(data, dict) else None


def reliability_verdict(data):
    if not data:
        return None
    verdict = data.get("verdict") or data.get("status")
    return str(verdict).upper() if verdict else None


def sensitivity_for(folder):
    report = read_json(Path(folder) / "sensitivity" / "report.json")
    job = read_json(Path(folder) / "sensitivity" / "job.json") or {}
    if not isinstance(report, dict) or not report.get("swings"):
        return None
    return dict(report=report, scenario_id=job.get("scenario"))


def caps_text(caps, used=None):
    parts = []
    shown = lambda key: used is None or key in used
    if caps.get("pv_dc_mw", 0) > .05 and shown("pv"):
        parts.append(f"PV {caps['pv_dc_mw']:.1f} MW")
    if caps.get("bess_mw", 0) > .05 and shown("bess"):
        parts.append(f"BESS {caps['bess_mw']:.1f} MW / {caps.get('bess_mwh', 0):.1f} MWh")
    for key, value in (caps.get("generators_mw") or {}).items():
        if value > .05 and shown(key):
            parts.append(f"{GEN_NAMES.get(key, key)} {value:.1f} MW")
    if caps.get("wind_mw", 0) > .05 and shown("wind"):
        parts.append(f"Wind {caps['wind_mw']:.1f} MW")
    return "; ".join(parts) or "No new on-site equipment (grid supply)"


def annual_stats(result):
    rows = result["economics"].get("annual") or []
    n = len(rows) or 1
    return dict(avg_opex=sum(r.get("net_opex", 0) for r in rows) / n,
                grid_peak=max([r.get("grid_peak_mw", 0) for r in rows] + [0]),
                avg_co2=sum(r.get("net_co2e_after_heat_credit_t", r.get("supply_co2e_t", 0)) for r in rows) / n)


def technical(result):
    t = result.get("technical_status")
    return t if isinstance(t, dict) else None


def digest(run):
    """Compact JSON for the in-app Result summary."""
    results, folder = run["results"], run["folder"]
    best, feasible = pick_best(results, folder)
    economic = {m["id"]: m for m in (read_json(folder / "economic_analysis.json") or {}).get("metrics", [])
                if isinstance(m, dict) and "id" in m}
    scenarios = []
    for code, r in results.items():
        tech, rel = technical(r), reliability_for(folder, code)
        e = economic.get(code) or {}
        scenarios.append(dict(
            code=code, name=r["name"], npc=total_npc(r), feasible=is_feasible(r), mix=caps_text(r["caps"]),
            technical=tech and dict(status=tech.get("status"), n1=tech.get("n1_status"),
                                    violations=len(tech.get("violations") or [])),
            reliability=rel and dict(verdict=reliability_verdict(rel), rows=(rel.get("copt") or {}).get("rows") or [],
                                     summary={k: v for k, v in (rel.get("summary") or {}).items() if k != "by_year"},
                                     detail=rel.get("verdict_detail") if isinstance(rel.get("verdict_detail"), dict) else {}),
            economic=dict(economic_rows(run).get(code) or {}, co2=e.get("net_after_heat_credit_co2e_t"))))
    sens = sensitivity_for(folder)
    sensitivity = None
    if sens:
        rep = sens["report"]
        sensitivity = dict(scenario=sens["scenario_id"], name=rep.get("scenario"), base=(rep.get("base") or {}).get("npc"),
                           risk=rep.get("risk"), top=[dict(label=s["label"], swing=s["swing"], unit=s.get("unit"),
                                                           low=s.get("low"), high=s.get("high"))
                                                      for s in sorted(rep["swings"], key=lambda s: -s["swing"])[:5]])
    return dict(run_id=run["run_id"], best=best, best_is_feasible=feasible, reference=run["reference"],
                scenarios=scenarios, sensitivity=sensitivity,
                economic_notes=(read_json(folder / "economic_analysis.json") or {}).get("notes"))


# --------------------------------------------------------------------------- field listings

def field_index():
    return {f["key"]: f for f in fields()}


def display_unit(field):
    unit = field.get("unit") or ""
    return "%" + unit[len("fraction"):] if unit.startswith("fraction") else unit


def display_value(field, value):
    if field and field.get("kind") == "select" and field.get("options"):
        for option in field["options"]:
            if isinstance(option, (list, tuple)) and len(option) >= 2 and option[0] == value:
                return str(option[1])
    if field and isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
        if str(field.get("unit") or "").lower() in ("year", "years") and float(value).is_integer() and 1900 <= value <= 2200 \
                or field["key"].endswith("_year"):
            return str(int(value)) if float(value).is_integer() else plain(value)
        if str(field.get("unit") or "").startswith("fraction"):
            return f"{value * 100:,.4f}".rstrip("0").rstrip(".")
    return plain(value)


def eligible_techs(run):
    """Technologies considered by the run's scenarios (union of eligible technologies; 'grid' included when any scenario uses it).

    None when the run does not record them (nothing is filtered then)."""
    found = None
    for result in (run.get("results") or {}).values():
        techs = result.get("eligible_technologies")
        if isinstance(techs, list):
            found = (found or set()) | {str(t) for t in techs}
    if found is None:
        defs = [d for d in (run.get("request") or {}).get("scenario_definitions") or [] if isinstance(d, dict) and isinstance(d.get("technologies"), list)]
        if defs:
            found = {str(t) for d in defs for t in d["technologies"]}
    return found


TECH_PREFIX = sorted([(k, k) for k, _, _ in TECH_GROUPS] + [("solar", "pv")], key=lambda kv: -len(kv[0]))
TECH_TITLES = {group: key for key, group, _ in TECH_GROUPS}


def field_applicable(field, eligible):
    """False for the inputs of a generation technology (or grid supply) that none of the scenarios considers."""
    if eligible is None:
        return True
    tech = TECH_TITLES.get(field["group"])
    if tech is None:
        key = field["key"]
        tech = next((t for p, t in TECH_PREFIX if key.startswith(p + "_")), None)
    if tech is not None:
        return tech in eligible
    if field["group"] == "Grid and tariff" or field["key"].startswith(("grid_", "reference_grid")):
        return "grid" in eligible
    return True


def fields_for(run):
    eligible = eligible_techs(run)
    return [f for f in fields() if field_applicable(f, eligible)]


def value_rows(run, keys=None, group=None, skip=()):
    out = []
    for f in fields_for(run):
        if keys is not None and f["key"] not in keys:
            continue
        if group is not None and f["group"] not in group:
            continue
        if f["key"] in skip:
            continue
        value = run["values"].get(f["key"], f.get("default"))
        out.append([f["label"], display_value(f, value), display_unit(f)])
    return out


def param_table(rows):
    return table(["Parameter", "Value", "Unit"], rows, numeric=(1,)) if rows else ""


# --------------------------------------------------------------------------- dispatch charts

def read_dispatch(folder, code, year):
    path = Path(folder) / f"dispatch_{code}.csv"
    if not path.is_file():
        return None
    try:
        with path.open(encoding="utf-8-sig") as stream:
            rows = [r for r in csv.DictReader(stream) if str(r.get("timestamp", ""))[:4] == str(year)]
    except (OSError, ValueError):
        return None
    return rows or None


def col(rows, key):
    out = []
    for r in rows:
        try:
            out.append(float(r.get(key) or 0))
        except ValueError:
            out.append(0.0)
    return out


def week_charts(folder, code, year, has_bess):
    rows = read_dispatch(folder, code, year)
    if not rows or len(rows) < 24 * 14:
        return ""
    load, pv = col(rows, "net_load_mw"), col(rows, "pv")
    planned = col(rows, "planned_renewable")
    days = len(rows) // 24
    day_peak = max(range(days), key=lambda d: max(load[d * 24:(d + 1) * 24]))
    day_sun = max(range(days), key=lambda d: sum(pv[d * 24:(d + 1) * 24]))
    out = []
    for title, day in (("Peak-demand week", day_peak), ("Highest-solar week", day_sun)):
        start = min(max(day - 3, 0), days - 7) * 24
        sl = slice(start, start + 168)
        series = [("Net load", load[sl], "#1d2733"), ("Grid import", col(rows, "grid")[sl], "#2f6fb3"),
                  ("Optimized PV", pv[sl], "#e0a030")]
        gen = col(rows, "gen")[sl]
        if max(gen) > 1e-6:
            series.append(("Generators", gen, "#c0504d"))
        if has_bess:
            net = [d - c for d, c in zip(col(rows, "discharge")[sl], col(rows, "charge")[sl])]
            series.append(("BESS (+discharge/-charge)", net, "#4f8f5b"))
        if max(planned[sl]) > 1e-6:
            series.append(("Planned renewables", planned[sl], "#8a8f98"))
        stamps = [(i, rows[start + i]["timestamp"][5:10]) for i in range(0, 168, 24)]
        out.append(f'<figure>{line_chart(list(range(168)), series, title + " dispatch", "MW", stamps)}'
                   f'<figcaption>{esc(title)} of {year}, starting {esc(rows[start]["timestamp"][:10])} (hourly MW).</figcaption></figure>')
        if has_bess and title == "Peak-demand week":
            soc = col(rows, "soc")[sl]
            out.append(f'<figure>{line_chart(list(range(168)), [("State of charge", soc, "#7a5ea8")], "Battery state of charge", "MWh", stamps)}'
                       "<figcaption>Battery state of charge in the same week.</figcaption></figure>")
    return "".join(out)


# --------------------------------------------------------------------------- report sections

def section(number, title, body, anchor):
    return f'<section id="{anchor}"><h2>{number}. {esc(title)}</h2>{body}</section>'


def comparison(run, best):
    rows, classes = [], []
    ref = run["results"].get(run["reference"])
    for code, r in run["results"].items():
        e, st = r["economics"], annual_stats(r)
        tech, rel = technical(r), reliability_for(run["folder"], code)
        rv = reliability_verdict(rel)
        title = f"{code}{' (reference)' if code == run['reference'] else ''}"
        name = esc(r["name"]) + (" " + badge("Best option", "best") if code == best else "")
        d = total_npc(r) - total_npc(ref) if ref and ref is not r else None
        rows.append([f"{title}", name, esc(caps_text(r["caps"])), num(currency.mega(total_npc(r)), 2), pct(100 * d / total_npc(ref)) if d is not None else "-",
                     num(currency.mega(e["capex"]), 2), num(currency.mega(st["avg_opex"]), 2), num(st["grid_peak"], 1), num(st["avg_co2"] / 1e3, 1),
                     badge("Fully served" if is_feasible(r) else f"Unserved {num((r.get('adequacy') or {}).get('unserved_mwh'), 0)} MWh",
                           "good" if is_feasible(r) else "bad"),
                     badge((tech or {}).get("status") or "Not run", status_kind((tech or {}).get("status"))),
                     badge(rv or "Not run", status_kind(rv))])
        classes.append("best" if code == best else "")
    headers = ["ID", "Scenario", "Equipment", "NPC $M", "vs ref.", "Capex $M", "Avg opex $M/yr", "Grid peak MW",
               "Avg CO2e kt/yr", "Adequacy", "Power flow", "Reliability"]
    chart = bar_chart([(f"{c} {r['name']}", currency.mega(total_npc(r))) for c, r in run["results"].items()],
                      "NPC by scenario", currency.label("$M"), best=f"{best} {run['results'][best]['name']}")
    return (table(headers, rows, numeric=(3, 4, 5, 6, 7, 8), row_classes=classes, raw_cols=(1, 9, 10, 11)) +
            f"<figure>{chart}<figcaption>Net present cost by scenario (lower is better); the recommended option is highlighted.</figcaption>"
            "<p class=\"take\"><strong>What this shows:</strong> the lowest bar is the cheapest scenario over the appraisal period; compare it with the reference to see the saving.</p></figure>"
            '<p class="small muted">NPC is the discounted lifecycle cash cost of grid supply, on-site equipment, fuel, O&amp;M and carbon over the '
            "appraisal period. Cases with unserved energy are not equivalent in service and should not be ranked on cost alone.</p>")


def effective_techs(run, code):
    """(keys of technologies built AND dispatched, notes for eligible technologies that are not designed/listed) for one scenario.

    Uses workflow.effective_technologies when available; otherwise built capacity from the result's caps."""
    result = run["results"][code]
    caps = result.get("caps") or {}
    built = {"pv": caps.get("pv_dc_mw") or 0, "bess": caps.get("bess_mw") or 0, "wind": caps.get("wind_mw") or 0}
    built.update({k: v or 0 for k, v in (caps.get("generators_mw") or {}).items() if k != "none"})
    used = {k for k, v in built.items() if v > 1e-6}
    eligible = [t for t in (result.get("eligible_technologies") or []) if t != "grid"]
    notes = []
    try:
        import workflow
        eff = workflow.effective_technologies(result, run.get("folder"))
        used = set(eff["effective"])
        for key in eff.get("unused") or []:
            notes.append(f"{GEN_NAMES.get(key, key)} built but never dispatches (negligible energy): not included")
    except Exception:
        pass
    for key in eligible:
        if key not in used and not any(GEN_NAMES.get(key, key) in n for n in notes):
            notes.append(f"{GEN_NAMES.get(key, key)} eligible but not built (0 MW)")
    return used, notes


def not_built_html(run, code):
    return "".join(f"<p class='small muted'>{esc(n)}.</p>" for n in effective_techs(run, code)[1])


def installed_equipment(run, code):
    import unit_pf
    r = run["results"][code]
    caps = r["caps"]
    vals = (run.get("request") or {}).get("values") or {}
    rows = []
    used = effective_techs(run, code)[0]
    if caps.get("pv_dc_mw", 0) > 1e-6 and "pv" in used:
        rows.append(["Solar PV (new)", "Optimized", num(caps["pv_dc_mw"], 2), "MW DC", mil(r["economics"].get("pv_capex")),
                     unit_pf.mva_text("pv", caps["pv_dc_mw"], vals)])
    if caps.get("bess_mw", 0) > 1e-6 and "bess" in used:
        rows.append(["Battery storage (new)", "Optimized", f"{num(caps['bess_mw'], 2)} MW / {num(caps.get('bess_mwh'), 2)} MWh",
                     f"{num(caps.get('bess_mwh', 0) / max(caps['bess_mw'], 1e-9), 1)} h duration", mil(r["economics"].get("bess_capex")),
                     unit_pf.mva_text("bess", caps["bess_mw"], vals)])
    for key, mw in (caps.get("generators_mw") or {}).items():
        if mw > 1e-6 and key in used:
            rows.append([GEN_NAMES.get(key, key), "Optimized", num(mw, 2), "MW", "(in generator capex)", unit_pf.mva_text(key, mw, vals)])
    if caps.get("wind_mw", 0) > 1e-6 and "wind" in used:
        rows.append(["Wind (new)", "Optimized", num(caps["wind_mw"], 2), "MW", "n/a", unit_pf.mva_text("wind", caps["wind_mw"], vals)])
    if not rows:
        rows.append(["No new on-site equipment", "-", "-", "-", "-", "-"])
    eco = r["economics"]
    parts = [f"<h3>New equipment</h3>{table(['Technology', 'Basis', 'Installed capacity', 'Unit', 'Capex', 'Rated MVA'], rows, numeric=(2,))}",
             f"<p class=\"small muted\">{esc(unit_pf.statement(vals))}</p>",
             not_built_html(run, code),
             f"<p>Total new generation capex {mil(eco.get('gen_capex'))}; connection capex {mil(eco.get('connection_capex'))}; "
             f"total upfront capital {mil(eco['capex'])}. Combined microgrid AC rating {num(caps.get('microgrid_total_ac_mw'), 1)} MW.</p>"]
    return "".join(parts)


def planned_section(run):
    planned = run["request"].get("planned_generation") or []
    rows = []
    for p in planned:
        if not isinstance(p, dict) or not (p.get("name") or p.get("capacity_mw") or p.get("pv_kw")):
            continue
        if p.get("technology") == "Mobile Trailers":
            cap = f"PV {num(p.get('pv_kw', 0), 0)} kW; BESS {num(p.get('bess_kw', 0), 0)} kW / {num(p.get('bess_kwh', 0), 0)} kWh"
            note = f"availability {num(100 * p.get('availability', 0), 0)}%; PV retained {num(100 * p.get('derate_factor', 0), 0)}%"
        else:
            cap = f"{num(p.get('capacity_mw'), 2)} MW"
            note = f"derate {num(p.get('derate_factor'), 2)}; degradation {num(100 * (p.get('degradation') or 0), 1)}%/yr"
        years = f"{p.get('start_year', '')}" + (f"-{p['end_year']}" if p.get("end_year") not in (None, p.get("start_year")) else "")
        rows.append([p.get("name") or "(unnamed)", p.get("technology"), p.get("status"), years, cap, note])
    if not rows:
        return "<p>No existing or planned generation was entered.</p>"
    return (table(["Project", "Technology", "Status", "Years", "Capacity", "Notes"], rows) +
            '<p class="small muted">Existing and planned projects are deducted from gross demand before optimization; their costs are '
            "excluded from every scenario's NPC (the decision boundary covers new optimized equipment and grid supply only).</p>")


def tech_inputs(run, code):
    caps = run["results"][code]["caps"]
    used, notes = effective_techs(run, code)
    active = [k for k, _, _ in TECH_GROUPS if k in used]
    if not active:
        return "<p>The recommended option installs no new equipment, so no technology cost inputs apply.</p>"
    out, index = [], field_index()
    for key, group, title in TECH_GROUPS:
        if key not in active:
            continue
        rows = value_rows(run, group={group}, skip={f["key"] for f in fields() if f["key"].endswith(("_land_enabled", "_acres", "_acres_per_mw", "_acres_per_mwh"))
                                                  and not run["values"].get(f["key"])})
        extra = [k for k in (f"{key}_life", "generator_life" if key not in ("pv", "bess", "wind") else None) if k and k in index]
        extra += [f["key"] for f in fields() if f["group"] == "Carbon emissions" and f["key"].startswith(key + "_emissions")]
        rows += value_rows(run, keys=set(extra))
        out.append(f"<h4>{esc(title)}</h4>{param_table(rows)}")
    return "".join(out) + "".join(f"<p class='small muted'>{esc(n)}.</p>" for n in notes)


def constraints(run):
    rows = [r for r in value_rows(run, keys=set(CONSTRAINT_KEYS))]
    return param_table(rows)


def tariff_financial(run):
    v = run["values"]
    mode = v.get("tariff_mode")
    skip = set()
    if mode == "blended":
        skip |= {k for k in v if k.startswith(("summer_", "winter_")) and k.endswith("_kwh")}
    tariff = value_rows(run, group={"Grid and tariff"}, skip=skip)
    fin = value_rows(run, group={"Financial", "Carbon emissions"})
    return (f"<h3>Grid supply and tariff</h3>{param_table(tariff)}<h3>Financial and emissions assumptions</h3>{param_table(fin)}"
            '<p class="small muted">Costs are escalated at the stated nominal rate and discounted at the nominal discount rate. '
            "No tax, financing, grants or terminal salvage are assumed.</p>")


def demand_basis(run, code):
    cfg, v = run["config"], run["values"]
    planning = cfg.get("planning") or {}
    out = [f"<p>{esc(cfg.get('source') or 'Demand basis not recorded.')}</p>",
           f"<p>Planning horizon: {esc(planning.get('start_year', v.get('start_year')))}-{esc(planning.get('end_year', ''))} "
           f"({esc(planning.get('horizon_years', v.get('horizon_years')))} years, {esc(plain(planning.get('planning_hours')))} hourly steps). "
           f"Appraisal period: {esc(planning.get('appraisal_years', v.get('appraisal_years')))} years.</p>"]
    traj = cfg.get("annual_trajectory") or []
    if traj:
        out.append("<h3>Annual peak demand trajectory</h3>" + table(["Year", "Gross peak MW", "Basis"],
                   [[t.get("year"), num(t.get("peak_mw"), 2), t.get("description") or ""] for t in traj], numeric=(1,)))
    annual = run["results"][code]["economics"].get("annual") or []
    if annual:
        out.append("<h3>Modeled annual demand</h3>" + table(
            ["Year", "Gross demand MWh", "Efficiency saved MWh", "Planned renewables MWh", "Net demand served MWh", "Forecast peak MW"],
            [[a["year"], num(a.get("gross_demand_mwh"), 0), num(a.get("efficiency_saved_mwh"), 0), num(a.get("planned_renewable_mwh"), 0),
              num(a.get("served_mwh", a.get("demand_mwh")), 0), num(a.get("forecast_peak_mw"), 1)] for a in annual], numeric=(1, 2, 3, 4, 5)))
    out.append("<h3>Forecast settings</h3>" + param_table(value_rows(run, group={"Demand"})))
    files = (cfg.get("request") or {}).get("profile_file_hashes") or {}
    names = [f"{k.replace('_', ' ')}: {', '.join(i.get('name', '') for i in v2)}" for k, v2 in files.items() if v2]
    if names:
        out.append("<h3>Input files</h3>" + bullets(names))
    return "".join(out)


def topology_section(run, code):
    topo = run["request"].get("topology") or {}
    diagram = (topo.get("diagrams") or {}).get(code) or topo
    nodes, lines = diagram.get("nodes") or [], diagram.get("lines") or []
    if not nodes:
        return notrun("No single-line diagram was defined for this scenario.")
    by_id = {n.get("id"): n for n in nodes}
    kinds = {}
    for n in nodes:
        kinds[n.get("kind", "?")] = kinds.get(n.get("kind", "?"), 0) + 1
    enabled = bool(diagram.get("enabled", topo.get("enabled")))
    out = [f"<p>Single-line diagram for {esc(code)}: {len(nodes)} elements ({esc(', '.join(f'{v} x {k}' for k, v in sorted(kinds.items())))}) and "
           f"{len(lines)} connection(s). Topology-based connection costs are {'<strong>enabled</strong>' if enabled else '<strong>not enabled</strong>'} "
           "in this run.</p>",
           table(["Element", "Type", "Owner", "Capital cost $"], [[n.get("label"), n.get("kind"), n.get("owner"), usd(n.get("capital_cost") or 0)] for n in nodes], numeric=(3,))]
    if lines:
        rows = [[by_id.get(l.get("source"), {}).get("label", l.get("source")), by_id.get(l.get("target"), {}).get("label", l.get("target")),
                 l.get("owner"), num(l.get("length_km"), 2), usd((l.get("length_km") or 0) * (l.get("cost_per_km") or 0))] for l in lines]
        out.append(table(["From", "To", "Owner", "Length km", "Line cost $"], rows, numeric=(3, 4)))
    out.append("<p class='small muted'>The topology allocates one-time connection costs; network adequacy is assessed in @@sec:powerflow@@.</p>")
    return "".join(out)


def annual_tables(run, code):
    annual = run["results"][code]["economics"].get("annual") or []
    if not annual:
        return notrun("No annual results were saved.")
    cats = [str(a["year"]) for a in annual]
    energy = [("Grid", [a.get("grid_mwh", 0) for a in annual], "#2f6fb3"), ("New PV", [a.get("optimized_solar_mwh", a.get("pv_mwh", 0)) for a in annual], "#e0a030"),
              ("Generators", [a.get("gen_mwh", 0) for a in annual], "#c0504d"), ("BESS discharge", [a.get("bess_discharge_mwh", 0) for a in annual], "#4f8f5b"),
              ("Planned renewables", [a.get("planned_renewable_mwh", 0) for a in annual], "#8a8f98")]
    cost = [(name, [a.get(k, 0) for a in annual], COLORS[i % len(COLORS)]) for i, (k, name) in enumerate(COST_COMPONENTS)]
    et = table(["Year", "Demand MWh", "Grid MWh", "New PV MWh", "Generators MWh", "BESS discharge MWh", "Planned MWh", "Grid peak MW", "Unserved MWh", "Net CO2e t"],
               [[a["year"], num(a.get("demand_mwh"), 0), num(a.get("grid_mwh"), 0), num(a.get("optimized_solar_mwh", a.get("pv_mwh")), 0), num(a.get("gen_mwh"), 0),
                 num(a.get("bess_discharge_mwh"), 0), num(a.get("planned_renewable_mwh"), 0), num(a.get("grid_peak_mw"), 1), num(a.get("unserved_mwh"), 1),
                 num(a.get("net_co2e_after_heat_credit_t", a.get("supply_co2e_t")), 0)] for a in annual], numeric=tuple(range(1, 10)))
    ct = table(["Year"] + [n for _, n in COST_COMPONENTS] + ["Net opex", "Discounted opex"],
               [[a["year"]] + [usd(a.get(k)) for k, _ in COST_COMPONENTS] + [usd(a.get("net_opex")), usd(a.get("discounted_opex"))] for a in annual],
               numeric=tuple(range(1, 10)))
    return (f"<h3>Annual energy mix</h3><figure>{stacked_columns(cats, energy, 'Annual energy mix', 'MWh')}<figcaption>    Energy supplied to the load by source (MWh).</figcaption><p class=\"take\"><strong>What this shows:</strong> how the mix of grid, on-site and stored energy changes as demand grows.</p></figure>{et}"
                f"<h3>Annual operating cost</h3><figure>{stacked_columns(cats, cost, 'Annual cost', '$')}<figcaption>Nominal annual operating cost by component.</figcaption><p class=\"take\"><strong>What this shows:</strong> which cost components drive the yearly operating bill.</p></figure>{ct}")


def economic_rows(run):
    """Per-scenario NPV/IRR/payback computed on the fly from the saved results (no Analyze run needed)."""
    if "economic_rows" not in run:
        import economic_metrics
        try:
            data = economic_metrics.evaluate(list(run["results"].values()), run["values"], run["reference"])
            run["economic_rows"] = {r["code"]: r for r in economic_metrics.flat_rows(data)}
        except (KeyError, ValueError, TypeError, IndexError):
            run["economic_rows"] = {}
    return run["economic_rows"]


def fmt_irr(em, key):
    if em["status"] == "reference":
        return "reference case"
    return "not defined (see note)" if em[key] is None else f"{100 * em[key]:,.2f}%"


def fmt_pb(em, key):
    if em["status"] == "reference":
        return "reference case"
    v = em[key + "_years"]
    return "not within horizon" if v is None else "no net outlay" if v <= 0 else f"{v:,.2f} yr"


def economic_section(run, code, info):
    r = run["results"][code]
    e = r["economics"]
    eco = read_json(run["folder"] / "economic_analysis.json") or {}
    metric = next((m for m in eco.get("metrics", []) if m.get("id") == code), None)
    comps = [(label, e.get(key) or 0, sign) for key, label, sign in NPC_COMPONENTS]
    total = e["npc"] or 1
    out = [table(["NPC component (present value)", "Value $", "Share of NPC"],
                 [[label, usd(v * sign), f"{100 * v * sign / total:.1f}%"] for label, v, sign in comps if abs(v) > 0.5] + [["Net present cost (NPC)", usd(e["npc"]), "100.0%"]],
                 numeric=(1, 2))]
    out.append(f"<p>Residual-value-adjusted NPC: {usd(e.get('npc_with_residual'))}. Sensitivity of NPC to the retail grid price (screening range): "
               f"{usd(e.get('npc_retail_40'))} at {currency.money(40, 1, 0, '/MWh')} and {usd(e.get('npc_retail_120'))} at {currency.money(120, 1, 0, '/MWh')}.</p>")
    if info and info.get("steps"):
        out.append(f"<h3>Cost waterfall: {esc(info['reference'])} to {esc(info['name'])}</h3><figure>{waterfall(info)}"
                   "<figcaption>Change in net present cost versus the reference case, by component.</figcaption>"
                   "<p class=\"take\"><strong>What this shows:</strong> which cost lines the option adds (red) or removes (green) relative to the reference.</p></figure>")
    em = economic_rows(run).get(code)
    if em:
        co2 = (metric or {}).get("net_after_heat_credit_co2e_t")
        kp = [(f"Incremental NPV vs {run['reference']}", "reference case" if em["status"] == "reference" else mil(em["npv"])),
              ("IRR (net basis)", fmt_irr(em, "irr")), ("Simple payback", fmt_pb(em, "simple_payback")),
              ("Discounted payback", fmt_pb(em, "discounted_payback")),
              ("IRR (operating savings only)", fmt_irr(em, "op_irr")), ("Payback (operating savings only)", fmt_pb(em, "op_simple_payback")),
              ("Levelized supplied cost", currency.money(em['lcoe'], 1, 1, '/MWh')),
              ("Net CO2e (appraisal)", "not run" if co2 is None else f"{num(co2 / 1e3, 0)} kt")]
        out.append("<h3>Financial metrics</h3><div class='kpis'>" + "".join(f"<div class='kpi'><b>{esc(v)}</b><span>{esc(k)}</span></div>" for k, v in kp) + "</div>")
        for note in [em["reason"], em["irr_note"], em["simple_payback_note"], em["op_irr_note"], em["op_simple_payback_note"], *em["warnings"]]:
            if note:
                out.append(f"<p class='small muted'>{esc(note)}</p>")
    else:
        out.append(notrun("Financial analysis (NPV, IRR, payback, LCOE, emissions) has not been run for this solve. Use ANALYZE > Economic analysis."))
    rows = economic_rows(run)
    if len(rows) > 1:
        def pb(em, key):
            return "-" if em["status"] == "reference" else fmt_pb(em, key)
        out.append("<h3>Financial metrics, all scenarios</h3>" + table(
            ["ID", "NPC ($M)", "Incremental NPV ($M)", "IRR", "Simple payback", "Discounted payback", "Levelized cost ($/MWh)", "Net CO2e (kt)"],
            [[c, num(currency.mega(run["results"][c]["economics"]["npc"]), 2), "-" if em["status"] == "reference" else num(currency.mega(em["npv"]), 2),
              "-" if em["status"] == "reference" else ("n/d" if em["irr"] is None else f"{100 * em['irr']:,.2f}%"), pb(em, "simple_payback"), pb(em, "discounted_payback"),
              num(currency.scaled(em["lcoe"]), 2), num(((next((m for m in eco.get("metrics", []) if m.get("id") == c), None) or {}).get("net_after_heat_credit_co2e_t") or 0) / 1e3, 1)]
             for c, em in rows.items() if c in run["results"]], numeric=tuple(range(1, 8))))
        out.append("<p class='small muted'>n/d: not defined (all cash flows share one sign). A dash marks the reference case.</p>")
    if eco.get("notes"):
        out.append("<h3>Basis of the financial metrics</h3>" + bullets(sentences(eco["notes"])))
    return "".join(out)


def sens_value(value, unit):
    """Sensitivity range end: relative changes carry a sign, absolute values do not."""
    unit = str(unit or "")
    if not finite(value):
        return "n/a"
    if unit.startswith("%"):
        return f"{value:+,.4g}%"
    if unit == "fraction":
        return f"{100 * value:,.4g}%"
    if unit.startswith("$"):
        return f"{currency.prefix()}{currency.scaled(value):,.4g}{unit[1:]}"
    return f"{value:,.4g} {unit}".strip()


def sensitivity_section(run, code):
    sens = sensitivity_for(run["folder"])
    if not sens:
        return notrun("Sensitivity analysis has not been run for this solve. Use ANALYZE > Sensitivity analysis to quantify how NPC responds to prices, costs and demand.")
    rep = sens["report"]
    base = (rep.get("base") or {}).get("npc") or 0
    out = []
    if sens["scenario_id"] and sens["scenario_id"] != code:
        out.append(f'<div class="warning">The saved sensitivity analysis was run for scenario {esc(sens["scenario_id"])} ({esc(rep.get("scenario"))}), not for the recommended option {esc(code)}.</div>')
    out.append(f"<p>Scenario: {esc(rep.get('scenario'))}. Base NPC {mil(base)}. Each parameter was varied across a low/high range and the system was re-optimized for every case.</p>")
    out.append(f"<figure>{tornado(rep['swings'], base)}<figcaption>Tornado chart: change in NPC from the base case (green = cheaper, red = more expensive).</figcaption>"
                f"<p class=\"take\"><strong>What this shows:</strong> the longest bars are the assumptions that move the cost most and deserve the closest confirmation.</p></figure>")
    out.append(table(["Parameter", "Low case", "High case", "NPC at low ($M)", "NPC at high ($M)", "Swing ($M)", "Mix changes"],
                     [[s["label"], sens_value(s["low"], s.get("unit")), sens_value(s["high"], s.get("unit")), num(currency.mega(s["npc_low"]), 2), num(currency.mega(s["npc_high"]), 2),
                       num(currency.mega(s["swing"]), 2), "Yes" if s.get("mix_changes") else "No"] for s in sorted(rep["swings"], key=lambda s: -s["swing"])], numeric=(1, 2, 3, 4, 5)))
    risk = rep.get("risk")
    if risk:
        out.append("<h3>NPC risk range</h3><div class='kpis'>" + "".join(
            f"<div class='kpi'><b>{mil(risk[k], 1)}</b><span>{label}</span></div>" for k, label in
            (("p10", "P10 (favorable)"), ("p50", "P50 (base)"), ("p90", "P90 (adverse)")) if k in risk) + "</div>")
        out.append(f"<p class='small muted'>{esc(rep.get('method'))}</p>")
    failed = rep.get("failed") or []
    if failed:
        out.append(f"<p class='small muted'>{len(failed)} sensitivity case(s) did not solve and are excluded.</p>")
    return "".join(out)


def reliability_section(run, code):
    rel = reliability_for(run["folder"], code)
    if not rel:
        return notrun(f"Reliability analysis has not been run for {code}. Use ANALYZE > Reliability to compute LOLE/EUE, N-1 adequacy and outage resilience.")
    verdict = reliability_verdict(rel)
    detail = rel.get("verdict_detail") if isinstance(rel.get("verdict_detail"), dict) else {}
    params = rel.get("params") or {}
    out = [f"<p>Overall verdict: {badge(verdict or 'n/a', status_kind(verdict))}</p>"]
    criteria = [c.strip() for c in re.split(r"\s(?=(?:PASS|WARN|FAIL):)", str(rel.get("criteria") or "")) if c.strip()]
    if criteria:
        out.append("<p>Verdict criteria:</p>" + bullets(criteria))
    if detail:
        out.append("<p>" + esc("This option: " + "; ".join(
            [f"expected downtime {num(detail.get('lole_h_yr'), 2)} h/yr"] +
            [f"{label} N-1 {'secure' if detail[key] else 'not secure'}" for key, label in (("local_n1_secure", "local-resource"), ("grid_n1_secure", "grid-loss")) if key in detail])) + ".</p>")
    s = rel.get("summary") or {}
    if s:
        out.append("<div class='kpis'>" + "".join(f"<div class='kpi'><b>{esc(v)}</b><span>{esc(k)}</span></div>" for k, v in [
            ("Downtime h/yr (LOLE-style)", num(s.get("lole_h_yr"), 2)), ("Expected unserved MWh/yr", num(s.get("eue_mwh_yr"), 1)),
            ("Load served", f"{num(s.get('load_served_pct'), 3)}%"), ("Interruptions/yr", num(s.get("interruptions_yr"), 2)),
            ("Average interruption h", num(s.get("caidi_like_h"), 1)), ("Downtime cost/yr", usd(s.get("cost_yr"))),
            (f"Downtime cost PV ({plain(params.get('pv_years'))} y)", usd(s.get("cost_pv")))]) + "</div>")
        worst = s.get("worst_event") or {}
        if worst:
            out.append(f"<p>Worst single event: {esc(worst.get('name'))}, {num(worst.get('mwh'), 1)} MWh unserved (start {esc(worst.get('start'))}).</p>")
    cont = rel.get("contingencies") or []
    if cont:
        out.append("<h3>Contingency results</h3>" + table(
            ["Contingency", "Lost MW", "Events/yr", "Worst outage MWh", "Peak shortfall MW", "Worst load served %", "Downtime h/yr", "Unserved MWh/yr", "Cost $/yr"],
            [[c.get("name"), num(c.get("lost_mw"), 1), num(c.get("events_per_year"), 2), num(c.get("worst_all_years_mwh"), 1), num(c.get("worst_event_peak_mw"), 1),
              num(c.get("worst_load_served_pct"), 1), num(c.get("downtime_h_yr"), 2), num(c.get("eue_mwh_yr"), 1), usd(c.get("cost_yr"))] for c in cont],
            numeric=tuple(range(1, 9))))
    measures = rel.get("measures") or []
    if measures:
        out.append("<h3>Mitigation measures (re-simulated)</h3>" + table(
            ["Rank", "Measure", "Size", "Capex $", "Annual opex $", "Downtime avoided h/yr", "Cost avoided PV $", "Benefit/cost", "Covers local", "Covers grid"],
            [[m.get("rank"), m.get("name"), (f"{num(m.get('size_mw'), 2)} MW / {num(m.get('size_mwh'), 2)} MWh" if m.get("size_mwh") else f"{num(m.get('size_mw'), 2)} MW"),
              usd(m.get("capex")), usd(m.get("annual_opex")), num(m.get("avoided_downtime_h_yr"), 2), usd(m.get("avoided_cost_pv")), num(m.get("benefit_cost_ratio"), 2),
              plain(m.get("covers_local")), plain(m.get("covers_grid"))] for m in measures], numeric=(0, 3, 4, 5, 6, 7)))
    if rel.get("qualitative_measures"):
        out.append("<h3>Other measures</h3>" + bullets(rel["qualitative_measures"]))
    rows = (rel.get("copt") or {}).get("rows") or []
    if rows:
        out.append("<h3>Capacity-outage screening by year</h3>" + table(
            ["Year", "Peak MW", "Dependable MW", "Reserve margin", "N-1 capacity MW", "N-1", "LOLE h/yr", "EUE MWh", "EUE % of load"],
            [[r.get("year"), num(r.get("peak_mw"), 1), num(r.get("dependable_mw"), 1), f"{num(r.get('reserve_margin_pct'), 1)}%", num(r.get("n1_capacity_mw"), 1),
              "Pass" if r.get("n1_pass") else "Fail", num(r.get("lole_hours"), 2), num(r.get("eue_mwh"), 1), f"{num(r.get('eue_pct'), 4)}%"] for r in rows],
            numeric=(1, 2, 3, 4, 6, 7, 8)) + (f"<p class='small muted'>{esc(rel['copt']['note'])}</p>" if (rel.get("copt") or {}).get("note") else ""))
    if rel.get("assumptions"):
        out.append("<h3>Assumptions</h3>" + bullets(rel["assumptions"]))
    return "".join(out)


def powerflow_section(run, code):
    tech = technical(run["results"][code])
    if not tech or str(tech.get("status")).upper() == "NOT_RUN":
        msg = (tech or {}).get("message")
        return notrun("Power-flow screening has not been run for this scenario" + (f" ({msg})" if msg else "") + ". Define a single-line diagram and use ANALYZE > Power flow.")
    status = str(tech.get("status")).upper()
    out = [f"<p>Overall status: {badge(status, status_kind(status))} (normal operation: {esc(tech.get('normal_status') or 'n/a')}; N-1: {esc(tech.get('n1_status') or 'n/a')}).</p>"]
    island = tech.get("islanded")
    if isinstance(island, dict) and island.get("chip"):
        out.append(f"<p class='muted'>{esc(island['chip'])} (informational, not used for the recommendation). {esc(island.get('note') or '')}</p>")
    s = tech.get("summary") or {}
    if s:
        out.append("<div class='kpis'>" + "".join(f"<div class='kpi'><b>{esc(v)}</b><span>{esc(k)}</span></div>" for k, v in [
            ("Min voltage (pu)", num(s.get("vmin"), 3)), ("Max voltage (pu)", num(s.get("vmax"), 3)), ("Max loading", f"{num(s.get('max_loading_pct'), 1)}% {esc(s.get('max_loading_branch') or '')}"),
            ("Max losses", f"{num(s.get('max_losses_mw'), 2)} MW"), ("Violations", plain(s.get("violations")))]) + "</div>")
    viol = tech.get("violations") or []
    if viol:
        groups = {}
        for v in viol:
            groups.setdefault((v.get("case"), str(v.get("severity")).lower(), str(v.get("type") or "").replace("_", " ")), []).append(v)

        def severity(v):
            try:
                return abs(float(v.get("value")) - float(v.get("limit")))
            except (TypeError, ValueError):
                return 0.0
        rows = [[case, sev.upper(), kind or "-", len(items), (max(items, key=severity).get("message") or "")]
                for (case, sev, kind), items in sorted(groups.items(), key=lambda kv: (str(kv[0][0]), kv[0][1] != "fail", kv[0][2]))]
        out.append("<h3>Violations</h3><p class='small muted'>Grouped by case and type; the worst instance of each group is quoted.</p>"
                   + table(["Case", "Severity", "Type", "Count", "Worst instance"], rows, numeric=(3,)))
    else:
        out.append("<p>No voltage or thermal violations were found in the screened cases.</p>")
    cuts = tech.get("cuts")
    if cuts:
        texts = []
        for c in (cuts if isinstance(cuts, list) else [cuts]):
            text = cut_text(c, element_names(run))
            if text not in texts:
                texts.append(text)
        out.append("<h3>Suggested reinforcement</h3>" + bullets(texts[:8])
                   + (f"<p class='small muted'>{len(texts) - 8} further similar item(s) omitted.</p>" if len(texts) > 8 else ""))
    out.append("<p class='small muted'>Steady-state AC screening on the single-line diagram; confirm with a full network study before design.</p>")
    return "".join(out)


def sentences(text):
    return [s.strip() for s in re.split(r"(?<=\.)\s+(?=[A-Z])", text or "") if s.strip()]


def quality_section(run, code):
    r = run["results"][code]
    v, a, cfg = r.get("validation") or {}, r.get("adequacy") or {}, run["config"]
    rows = [["Solver", (r.get("solver") or {}).get("label") or "n/a"], ["Solve status", v.get("status") or "n/a"],
            ["Hourly balance error (MW)", plain(v.get("hourly_balance_error_mw"))], ["Max constraint violation (MW)", plain(v.get("max_constraint_violation_mw"))],
            ["Supply adequacy", a.get("status") or "n/a"], ["Unserved energy (MWh) / hours", f"{num(a.get('unserved_mwh'), 2)} / {plain(a.get('unserved_hours'))}"],
            ["Appraisal dispatch hours", plain((cfg.get("planning") or {}).get("appraisal_dispatch_hours"))], ["Solver version", cfg.get("solver_version") or "n/a"],
            ["Planning inputs checksum", (cfg.get("planning_inputs_sha256") or "n/a")[:16]], ["Application version", plain(cfg.get("application_version"))]]
    out = ["<h3>Model checks</h3>" + table(["Check", "Result"], rows)]
    fails = (run["summary"].get("failures") or [])
    if fails:
        out.append("<h3>Scenarios without a validated solution</h3>" + bullets([f"{f.get('code')}: {f.get('error')}" for f in fails]))
    notes = []
    if not run["values"].get("emission_factors_confirmed"):
        notes.append("Emission factors were not confirmed; supply emissions totals may be incomplete.")
    notes += [s for s in sentences((read_json(run["folder"] / "economic_analysis.json") or {}).get("notes")) if "placeholder" in s or "screening" in s]
    out.append("<h3>Data quality and assumptions</h3>" + bullets(sentences(cfg.get("source")) + notes))
    return "".join(out)


def build_report(run_id, scenario=None, project=None, meta=None):
    """Full industry-format report; `meta` carries the author's document details (see report_doc.clean_meta)."""
    import report_doc
    details = dict(meta or {})
    if project and not details.get("project_name"):
        details["project_name"] = project
    if scenario and not details.get("scenario"):
        details["scenario"] = scenario
    if scenario and scenario not in load_run(run_id)["results"]:
        raise ValueError("Scenario has no saved result.")
    return report_doc.build(run_id, details)


# --------------------------------------------------------------------------- routes

def q1(query, key):
    return (query.get(key) or [""])[0]


def report_route(query):
    doc = build_report(q1(query, "run_id"), q1(query, "scenario") or None, q1(query, "project") or None)
    return doc.encode("utf-8"), "text/html; charset=utf-8"


def report_post(payload):
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    doc = build_report(payload.get("run_id"), meta.get("scenario") or None, None, meta)
    return doc.encode("utf-8"), "text/html; charset=utf-8"


def summary_route(query):
    return digest(load_run(q1(query, "run_id")))


def summary_pdf_post(payload):
    import summary_pdf
    return summary_pdf.build(payload.get("run_id")), "application/pdf"


def design_report_route(query):
    import report_doc
    doc = report_doc.build_design_doc(q1(query, "run_id"), {"scenario": q1(query, "scenario") or "", "project_name": q1(query, "project") or "",
                                                            "detail": q1(query, "detail") or ""})
    return doc.encode("utf-8"), "text/html; charset=utf-8"


def design_report_post(payload):
    import report_doc
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    return report_doc.build_design_doc(payload.get("run_id"), meta).encode("utf-8"), "text/html; charset=utf-8"


def report_pptx_post(payload):
    try:
        import report_pptx
    except ImportError as exc:
        raise ValueError(f"The executive presentation needs the python-pptx package ({exc}). Install it with: pip install python-pptx") from exc
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    return report_pptx.build(payload.get("run_id"), meta), report_pptx.MIME


def report_docx_post(payload):
    import report_docx
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    return report_docx.build(payload.get("run_id"), meta), report_docx.MIME


def design_report_docx_post(payload):
    import report_docx
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else {}
    return report_docx.build_design(payload.get("run_id"), meta), report_docx.MIME


def pdf_response(document_html):
    """Render a report document to PDF with real contents page numbers; the browser is the only external requirement."""
    import report_pdf
    try:
        return report_pdf.render(document_html), "application/pdf"
    except report_pdf.PdfUnavailable as exc:
        raise ValueError(str(exc)) from exc


def report_pdf_post(payload):
    return pdf_response(report_post(payload)[0].decode("utf-8"))


def design_report_pdf_post(payload):
    return pdf_response(design_report_post(payload)[0].decode("utf-8"))


def pdf_status_route(query):
    import report_pdf
    return {"available": report_pdf.available()}

extensions.GET["design_report"] = design_report_route
extensions.POST["design_report"] = design_report_post
extensions.POST["report_pptx"] = report_pptx_post
extensions.POST["report_docx"] = report_docx_post
extensions.POST["design_report_docx"] = design_report_docx_post
extensions.POST["report_pdf"] = report_pdf_post
extensions.POST["design_report_pdf"] = design_report_pdf_post
extensions.GET["pdf_status"] = pdf_status_route
extensions.GET["report"] = report_route
extensions.POST["report"] = report_post
extensions.POST["summary_pdf"] = summary_pdf_post
extensions.GET["report_summary"] = summary_route
