"""Design edits: overrides, topology write-back, shunt/unit counts, technical design report, report eligibility. Uses a COPY of a saved run."""
import json
import re
import shutil
import unittest
import uuid
from pathlib import Path

import design
import extensions
import report
import report_doc

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / "Application Runs"
SOURCE = "7791be18470745f8af5ef34fa3d208f8"
HAS_SOURCE = (RUNS / SOURCE / "status.json").is_file()
CODE = "H2"


@unittest.skipUnless(HAS_SOURCE, "reference run not available")
class DesignEdit(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rid = uuid.uuid4().hex
        shutil.copytree(RUNS / SOURCE, RUNS / cls.rid)
        cls.folder = RUNS / cls.rid
        cls.original = json.loads((cls.folder / "request.json").read_text(encoding="utf-8"))

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.folder, ignore_errors=True)

    def tearDown(self):
        design.reset_overrides(self.rid, CODE)

    def test_validation(self):
        with self.assertRaises(ValueError):
            design.validate_overrides({"no_such_key": 1})
        with self.assertRaises(ValueError):
            design.validate_overrides({"shunt_stages": "abc"})
        with self.assertRaises(ValueError):
            design.validate_overrides({"v_mv_kv": 9999})
        self.assertEqual(design.validate_overrides({"shunt_stages": ""}), {})

    def test_shunts_in_design_outputs_and_answer(self):
        d = design.build_design(self.rid, CODE, overrides={})
        self.assertTrue(d["shunt"]["stages"] > 0)
        self.assertFalse(d["shunt"]["cost_in_technology_cost"])
        self.assertTrue(any("apacitor" in e["type"] for e in d["equipment"]))
        self.assertTrue(any("apacitor" in b["item"] for b in d["bom"]))
        self.assertIn("CAPACITOR BANK", design.sld_svg(d))
        self.assertIn("NOT in the technology cost", d["shunt_note"])
        self.assertTrue(any("shunt" in r["name"].lower() or "capacitor" in r["name"].lower() for r in d["basis"]))

    def test_unit_counts_present_and_editable(self):
        base = design.build_design(self.rid, CODE, overrides={})
        counts = {u["item"]: u for u in base["unit_counts"]}
        self.assertTrue(counts)
        self.assertTrue(any("module" in k.lower() for k in counts))
        for u in base["unit_counts"]:
            self.assertEqual(u["count"], int(u["count"]))
        mod = next(u for k, u in counts.items() if "module" in k.lower())
        edited = design.build_design(self.rid, CODE, overrides={"pv_module_w": 1000})
        mod2 = next(u for u in edited["unit_counts"] if "module" in u["item"].lower())
        self.assertLess(mod2["count"], mod["count"])
        self.assertEqual(mod2["basis"], "user-set")

    def test_save_effect_topology_and_reset_restore(self):
        rec = design.save_overrides(self.rid, CODE, {"shunt_stages": 2, "shunt_stage_mvar": 2.0, "main_tr_mva": 50})
        self.assertTrue((self.folder / f"design_overrides_{CODE}.json").is_file())
        self.assertEqual(rec["values"]["shunt_stages"], 2)
        d = design.build_design(self.rid, CODE)
        self.assertEqual((d["shunt"]["stages"], d["shunt"]["stage_mvar"]), (2, 2.0))
        self.assertEqual(d["shunt"]["source"], "user-set")
        self.assertIn("user-set", {r["source"] for r in d["basis"]})
        stored = json.loads((self.folder / "request.json").read_text(encoding="utf-8"))
        self.assertNotEqual(stored, self.original)
        params = design.design_params(self.rid, CODE)
        self.assertTrue(params["mapped_to_topology"])
        field = next(f for f in params["fields"] if f["key"] == "shunt_stages")
        self.assertTrue(field["user_set"])
        self.assertEqual(field["source"], "user-set")
        design.reset_overrides(self.rid, CODE, ["shunt_stages"])
        self.assertNotIn("shunt_stages", design.load_overrides(self.rid, CODE)["values"])
        design.reset_overrides(self.rid, CODE)
        self.assertFalse((self.folder / f"design_overrides_{CODE}.json").exists())
        self.assertEqual(json.loads((self.folder / "request.json").read_text(encoding="utf-8")), self.original)

    def test_run_power_flow(self):
        out = design.run_power_flow(self.rid, CODE, {"main_tr_mva": 40})
        self.assertIn(out["status"], ("PASS", "WARN", "FAIL"))
        self.assertIn("violations", out)
        self.assertTrue((self.folder / f"design_pf_{CODE}.json").is_file())
        self.assertEqual(design.design_params(self.rid, CODE)["power_flow"]["status"], out["status"])

    def test_routes(self):
        q = {"run_id": [self.rid], "scenario": [CODE]}
        self.assertIn("fields", extensions.GET["design_params"](q))
        out = extensions.POST["design_save"]({"run_id": self.rid, "scenario": CODE, "values": {"aux_load_kw": 150}})
        self.assertEqual(out["overrides"]["aux_load_kw"], 150)
        out = extensions.POST["design_reset"]({"run_id": self.rid, "scenario": CODE})
        self.assertEqual(out["overrides"], {})
        with self.assertRaises(ValueError):
            extensions.POST["design_save"]({"run_id": self.rid, "scenario": CODE, "values": {"bogus": 1}})

    def test_technical_design_report(self):
        design.save_overrides(self.rid, CODE, {"shunt_stages": 2, "shunt_stage_mvar": 2.0})
        html = report_doc.build_design_doc(self.rid, {"scenario": CODE})
        titles = [re.sub(r"<[^>]+>", "", t) for t in re.findall(r"<h2>(.*?)</h2>", html, re.S)]
        for name in ("Design basis", "Single-line diagram", "Equipment schedule", "Bill of quantities", "Power-flow results", "Protection", "Assumptions register"):
            self.assertTrue(any(name in t for t in titles), name)
        self.assertIn("user-set", html)
        self.assertIn("Estimated unit counts", html)
        self.assertIn("<svg", html)
        body, mime = extensions.GET["design_report"]({"run_id": [self.rid], "scenario": [CODE]})
        self.assertTrue(mime.startswith("text/html"))
        self.assertGreater(len(body), 5000)
        self.assertNotRegex(html, r"\d\.\d{5,}")

    def test_main_report_is_slim_and_filters_technologies(self):
        html = report.build_report(self.rid, CODE)
        self.assertIn("Key design parameters", html)
        self.assertNotIn("Equipment schedule", html)
        run = report.load_run(self.rid)
        eligible = report.eligible_techs(run)
        self.assertTrue("grid" in eligible)
        self.assertNotIn("wind", eligible)
        self.assertNotIn("Wind", " ".join(f["group"] for f in report.fields_for(run) if "group" in f))


if __name__ == "__main__":
    unittest.main()
