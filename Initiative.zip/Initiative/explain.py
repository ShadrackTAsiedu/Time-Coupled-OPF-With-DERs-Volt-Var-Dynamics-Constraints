"""Plain-language result explanation, cost waterfall and comparison against the current-supply case.

Route: GET /api/x/explain?run_id=&scenario=
The waterfall walks from the reference (R0, grid-only/current supply) NPC to the chosen scenario NPC through
the NPC components stored in each result. Components are present-value costs; any difference between the sum
of the listed components and the reported NPC is shown as "Other / rounding". The reference is the run's
comparison reference (request.comparison_reference, default R0).
"""

import json
import re

import extensions
import currency
from report import GEN_NAMES
COMPONENTS = [("capex", "Upfront capital (incl. connection)", 1), ("grid_pv", "Grid energy and demand charges", 1),
              ("fuel_pv", "Fuel", 1), ("variable_om_pv", "Variable O&M", 1), ("fixed_om_pv", "Fixed O&M", 1),
              ("carbon_pv", "Carbon cost", 1), ("replacement_pv", "Replacements", 1), ("upgrade_pv", "Grid upgrade", 1),
              ("upgrade_om_pv", "Upgrade O&M", 1), ("heat_credit_pv", "Heat credit", -1)]


def money(v):
    return currency.money(v, 1e6, 1, "M")


def load(folder, code):
    path = folder / f"result_{code}.json"
    if not re.fullmatch(r"[A-Za-z0-9_]+", str(code)) or not path.is_file():
        raise ValueError(f"Scenario {code} has no saved result.")
    return json.loads(path.read_text(encoding="utf-8"))


def parts(result):
    e = result["economics"]
    out = {k: float(e.get(k) or 0) * sign for k, _, sign in COMPONENTS}
    out["other"] = float(e["npc"]) - sum(out.values())
    return out


def read_request(folder):
    try:
        return json.loads((folder / "request.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def reference_code(folder):
    code = read_request(folder).get("comparison_reference") or "R0"
    return code if (folder / f"result_{code}.json").is_file() else None


def upfront(econ):
    """Year-0 outlay: new equipment plus the grid upgrade, which is also paid up front."""
    return float(econ.get("capex") or 0) + float(econ.get("upgrade_pv") or 0)


def battery_use(econ, caps):
    """Average annual battery discharge (MWh) and equivalent full cycles, from the hourly dispatch."""
    rows = econ.get("annual") or []
    mwh = caps.get("bess_mwh") or 0
    if not rows or mwh <= 0:
        return None
    discharge = sum(float(r.get("bess_discharge_mwh") or 0) for r in rows) / len(rows)
    return discharge, discharge / mwh


def explain(query):
    folder = extensions.run_folder((query.get("run_id") or [""])[0])
    currency.activate(read_request(folder).get("values"))
    code = (query.get("scenario") or [""])[0]
    result = load(folder, code)
    ref_code = reference_code(folder)
    ref = load(folder, ref_code) if ref_code and code != ref_code else None
    names = {k: label for k, label, _ in COMPONENTS}
    names["other"] = "Other / rounding"
    mine, base = parts(result), parts(ref) if ref else None
    steps = []
    if base:
        steps = [dict(key=k, label=names[k], delta=mine[k] - base[k]) for k in names if abs(mine[k] - base[k]) > 1e3]
        steps.sort(key=lambda s: -abs(s["delta"]))
        rest = sum(mine[k] - base[k] for k in names) - sum(s["delta"] for s in steps)
        if abs(rest) > .5:
            steps.append(dict(key="small", label="Small items", delta=rest))
    caps, econ = result["caps"], result["economics"]
    mix = [f"{caps.get('pv_dc_mw', 0):.1f} MW solar" if caps.get("pv_dc_mw", 0) > .05 else None,
           f"{caps['bess_mw']:.1f} MW / {caps['bess_mwh']:.1f} MWh battery" if caps.get("bess_mw", 0) > .05 else None]
    mix += [f"{v:.1f} MW {GEN_NAMES.get(k, k)}" for k, v in (caps.get("generators_mw") or {}).items() if v > .05]
    mix = [m for m in mix if m]
    lines = [f"{result['name']} builds {', '.join(mix)}." if mix else
             f"{result['name']} adds no on-site equipment and supplies demand from the grid"
             + (" after the substation upgrade." if float(econ.get("upgrade_pv") or 0) > 0 else ".")]
    outlay = upfront(econ)
    lines.append(f"Net present cost (NPC) is {money(econ['npc'])}; upfront capital is {money(outlay)}"
                 + (f" ({100 * outlay / econ['npc']:.0f}% of NPC)." if econ["npc"] > 0 else "."))
    if ref:
        d = econ["npc"] - ref["economics"]["npc"]
        lines.append(f"Compared with the reference ({ref['name']}, {money(ref['economics']['npc'])}) it is "
                     f"{money(abs(d))} {'cheaper' if d < 0 else 'more expensive'} ({100 * d / ref['economics']['npc']:+.1f}%).")
        if steps:
            lines.append("Largest drivers: " + "; ".join(f"{s['label']} {'+' if s['delta'] >= 0 else '-'}{money(abs(s['delta']))}"
                                                           for s in steps[:3]) + ".")
        if mine["grid_pv"] != base["grid_pv"]:
            lines.append(f"Grid energy and demand charges change by {'-' if mine['grid_pv'] < base['grid_pv'] else '+'}"
                         f"{money(abs(base['grid_pv'] - mine['grid_pv']))} (present value) against the reference.")
    values = read_request(folder).get("values") or {}
    total = caps.get("microgrid_total_ac_mw") or 0
    if total > .05 and values.get("microgrid_max_mw") and total >= float(values["microgrid_max_mw"]) - .01:
        lines.append(f"On-site capacity ({total:.1f} MW AC) is at the maximum you set ({float(values['microgrid_max_mw']):,.1f} MW); "
                     "a higher limit could change the result.")
    elif total > .05 and values.get("microgrid_min_mw") and total <= float(values["microgrid_min_mw"]) + .01:
        lines.append(f"On-site capacity ({total:.1f} MW AC) is at the minimum you set ({float(values['microgrid_min_mw']):,.1f} MW); "
                     "the minimum may be forcing a larger build than cost alone would choose.")
    use = battery_use(econ, caps) if caps.get("bess_mw", 0) > .05 else None
    if use:
        lines.append(f"The battery ({caps['bess_mw']:.1f} MW / {caps['bess_mwh']:.1f} MWh, "
                     f"{caps['bess_mwh'] / caps['bess_mw']:.1f} h) discharges {use[0]:,.0f} MWh per year on average, "
                     f"about {use[1]:,.0f} full cycles per year.")
    ad = result.get("adequacy") or dict(unserved_mwh=float(econ.get("unserved_mwh") or 0),
                                        unserved_hours=int(econ.get("unserved_hours") or 0))
    lines.append("All hourly demand is served." if ad["unserved_mwh"] < 1e-3 else
                 f"Warning: {ad['unserved_mwh']:,.0f} MWh ({ad['unserved_hours']} h) of demand is unserved; relax limits or add capacity.")
    tech = result.get("technical_status") or {}
    if tech.get("status") and tech["status"] != "NOT_RUN":
        count = len(tech.get("violations") or [])
        lines.append(f"Power-flow screening: {tech['status']} ({count:,} finding{'s' if count != 1 else ''}). It is a remark only; "
                     "the ranking is by total NPC and corrections are applied afterwards.")
    return dict(scenario=code, name=result["name"], summary=lines, reference=ref["name"] if ref else None,
                steps=steps, start=base and sum(base.values()), end=sum(mine.values()),
                components=[dict(label=names[k], value=mine[k], reference=base[k] if base else None) for k in names])


extensions.GET["explain"] = explain

import summary_data  # noqa: E402,F401  (registers GET /api/x/summary_dashboard)
