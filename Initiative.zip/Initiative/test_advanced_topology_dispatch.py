import csv
from datetime import datetime, timedelta
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import subprocess
import sys

import numpy as np

import dispatch_view
import generation_app as app
import network_topology
import optimize_generation_mix as model
import scenario_inputs
from test_client_planning import short_data
from test_topology_wind import topology


class AdvancedTopologyDispatchTests(unittest.TestCase):
    def test_stop_joins_owned_worker_and_preserves_completed_results(self):
        with tempfile.TemporaryDirectory() as name:
            root=Path(name)
            job="a"*32
            folder=root/job
            folder.mkdir()
            process=subprocess.Popen([sys.executable,"-c","import time; time.sleep(60)"])
            try:
                (folder/"status.json").write_text(json.dumps(dict(state="running",message="Solving")))
                with patch.object(app,"RUNS",root),patch.dict(app.JOBS,{job:process},clear=True):
                    result=app.cancel_job(job)
                    self.assertEqual(result["state"],"cancelled")
                    self.assertIsNotNone(process.poll())
                    self.assertFalse(app.active_jobs())
                    self.assertEqual(app.cancel_job(job)["state"],"cancelled")
                    complete=dict(state="complete",summary=dict(results=[dict(code="P1")]))
                    (folder/"status.json").write_text(json.dumps(complete))
                    self.assertEqual(app.cancel_job(job),complete)
                    (folder/"status.json").write_text(json.dumps(dict(state="running",summary=complete["summary"])))
                    result=app.cancel_job(job)
                    self.assertEqual(result["state"],"complete")
                    self.assertEqual(result["summary"],complete["summary"])
            finally:
                if process.poll() is None:
                    process.terminate()
                    process.wait(timeout=10)

    def test_scenario_routes_ports_and_legacy_costs(self):
        graph = topology()
        graph["lines"][0].update(points=[dict(x=600, y=500), dict(x=900, y=500)],
                                 source_port="bottom", target_port="left")
        scenarios = [dict(id="GW", technologies=["grid", "wind"]), dict(id="G", technologies=["grid"])]
        legacy = network_topology.validate(graph, scenarios)
        self.assertEqual(network_topology.costs(legacy, ["grid", "wind"])["wind"], 1000)
        second = topology()
        second["lines"][0]["cost_per_km"] = 1000
        graph.update(diagrams=dict(GW=second), active_scenario="GW")
        saved = network_topology.validate(graph, scenarios)
        self.assertEqual(saved["lines"][0]["points"], [dict(x=600, y=500), dict(x=900, y=500)])
        self.assertEqual(saved["lines"][0]["target_port"], "left")
        cfg, _ = scenario_inputs.settings(dict(topology=saved), scenarios[0])
        self.assertEqual(cfg["connection_costs"]["shared"], 3234)
        cfg, _ = scenario_inputs.settings(dict(topology=saved), scenarios[1])
        self.assertEqual(cfg["connection_costs"]["shared"], 2234)
        graph["diagrams"]["GW"]["lines"][0]["points"] = [dict(x=1601, y=100)]
        with self.assertRaisesRegex(ValueError, "bend x"):
            network_topology.validate(graph, scenarios)
        graph["diagrams"]["GW"]["lines"][0]["points"] = []
        graph["diagrams"]["GW"]["lines"][0]["source_port"] = "invalid"
        with self.assertRaisesRegex(ValueError, "connection port"):
            network_topology.validate(graph, scenarios)

    def test_new_fuel_inputs_conversion_dispatch_emissions_and_merit(self):
        for technology in ("diesel", "biogas", "biomass"):
            with self.subTest(technology=technology):
                definition = dict(id="FUEL", technologies=["grid", technology])
                payload = dict(values=dict(horizon_years=1, extended_appraisal=False,
                    microgrid_min_mw=0, microgrid_max_mw=10, grid_limit=100, reactive_enabled=False,
                    carbon_price=10), scenarios=["FUEL"], scenario_definitions=[definition], planned_generation=[])
                with self.assertRaisesRegex(ValueError, "confirm project-specific"):
                    app.validate_request(payload)
                # Explicit synthetic test inputs, not application defaults or investment estimates.
                payload["values"].update({technology+"_confirmed": True, technology+"_capex": 100,
                    technology+"_fom_fraction": .01, technology+"_vom": 2,
                    technology+"_fuel_price": 4, technology+"_efficiency": .4,
                    technology+"_emissions_t_mmbtu": .05})
                validated = app.validate_request(payload)
                cfg, names = scenario_inputs.settings(app.settings_for(validated["values"]), definition)
                spec = cfg["technology_parameters"][technology]
                self.assertAlmostEqual(spec["fuel"], 4 * model.MMBTU_PER_MWH / .4)
                self.assertAlmostEqual(spec["emissions_t_mwh"], .05 * model.MMBTU_PER_MWH / .4)
                self.assertAlmostEqual(spec["carbon"], 10 * spec["emissions_t_mwh"])
                self.assertEqual(spec["ratio"], 0)
                data = short_data()
                data.update(load=np.full(288, 3.0), qmax=np.full(288, 3.0), qmin=np.full(288, 3.0),
                            grid_energy=np.full(288, 100.0), facility=np.zeros(12), tou=np.zeros(12),
                            fixed=np.zeros(12), heat=np.zeros(288))
                solved = model.solve_decomposed(data, "F", technology, names, settings=cfg)
                self.assertAlmostEqual(solved["caps"]["generators_mw"][technology], 3, places=5)
                annual = solved["economics"]["annual"][0]
                self.assertAlmostEqual(annual["direct_gen_co2_t"], 288*3*spec["emissions_t_mwh"], places=5)
                self.assertAlmostEqual(annual[technology+"_generation_mwh"], 288*3, places=5)
                self.assertAlmostEqual(annual["fuel"], 288*3*spec["fuel"]*(1+cfg["inflation"]), places=5)
                cfg["emissions_limit_enabled"] = True
                cfg["emissions_limit_t_year"] = 0
                zero = model.solve_decomposed(data, "Z", technology, names, settings=cfg)
                self.assertLess(zero["caps"]["generators_mw"][technology], 1e-5)

    def make_dispatch(self, folder):
        result = dict(code="P1", name="Test", eligible_technologies=["grid", "pv", "bess", "biogas"],
                      caps=dict(generators_mw=dict(biogas=1)), economics=dict(npc=1),
                      adequacy=dict(unserved_hours=0, stress_unserved_mwh=0))
        (folder / "status.json").write_text(json.dumps(dict(state="complete", summary=dict(results=[result]))))
        (folder / "run_configuration.json").write_text(json.dumps(dict(
            planning=dict(start_year=2027, end_year=2027))))
        with (folder / "dispatch_P1.csv").open("w", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(["timestamp", "net_load_mw", "grid", "pv", "optimized_solar", "planned_renewable",
                             "charge", "discharge", "shortfall", "gen", "gen_biogas"])
            # service demand=5, planned=4 (3 direct + 1 surplus used), grid=2;
            # extra demand=-1, while solar=1, generator=1 and charging=3 => net=-1.
            writer.writerow(["2027-01-01 00:00:00", 2, 2, 2, 1, 4, 3, 0, 0, 1, 1])
            # Another hour: service=5, planned direct=1, grid=2, solar=1,
            # discharge=.5, generator=.5. Extra=2, microgrid net=2.
            writer.writerow(["2027-01-01 01:00:00", 4, 2, 1, 1, 1, 0, .5, 0, .5, .5])

    def test_saved_dispatch_reconciles_surplus_charging_and_signed_residual(self):
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            self.make_dispatch(folder)
            view = dispatch_view.read(folder, start="2027-01-01T00:00", end="2027-01-01T01:00")
            self.assertEqual(view["hours"], 2)
            self.assertEqual(view["series"]["demand"], [5, 5])
            self.assertEqual(view["series"]["extra"], [-1, 2])
            self.assertEqual(view["series"]["microgrid_net"], [-1, 2])
            self.assertEqual(view["series"]["charging"], [-3, 0])
            self.assertEqual(view["series"]["gen_biogas"], [1, .5])
            self.assertEqual(view["balance_error_mw"], 0)
            for start, end in [("2028-01-01", "2028-01-01"), ("2027-01-01T00:30", "2027-01-01T01:00"),
                               ("2027-01-01T01:00", "2027-01-01T00:00"), ("2027-01-01T00:00Z", "2027-01-01T01:00Z")]:
                with self.assertRaises(ValueError):
                    dispatch_view.read(folder, start=start, end=end)
            with self.assertRaisesRegex(ValueError, "incomplete"):
                dispatch_view.read(folder, start="2027-01-01T00:00", end="2027-01-01T02:00")
            with self.assertRaisesRegex(ValueError, "Select a scenario"):
                dispatch_view.read(folder, scenario="../../elsewhere")

    def test_aggregation_preserves_weighted_energy_and_checks_hourly_continuity(self):
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            self.make_dispatch(folder)
            first = datetime(2027, 1, 1)
            with (folder / "dispatch_P1.csv").open("w", newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(["timestamp", "net_load_mw", "grid", "pv", "optimized_solar", "planned_renewable",
                                 "charge", "discharge", "shortfall", "gen", "gen_biogas"])
                for hour in range(2001):
                    demand = 2 + hour % 2
                    writer.writerow([str(first+timedelta(hours=hour)), demand, 1, 0, 0, 0,
                                     0, 0, 0, demand-1, demand-1])
            end = (first+timedelta(hours=2000)).isoformat()
            view = dispatch_view.read(folder, start=first.isoformat(), end=end)
            self.assertEqual(view["hours"], 2001)
            self.assertEqual(view["bin_hours"], 2)
            self.assertEqual(len(view["timestamps"]), 1001)
            self.assertEqual(view["counts"][-1], 1)
            energy = sum(power*hours for power, hours in zip(view["series"]["demand"], view["counts"]))
            self.assertEqual(energy, sum(2+hour % 2 for hour in range(2001)))
            self.assertEqual(view["balance_error_mw"], 0)
            text = (folder / "dispatch_P1.csv").read_text()
            (folder / "dispatch_P1.csv").write_text(text.replace("2027-01-01 01:00:00", "2027-01-01 00:00:00"))
            with self.assertRaisesRegex(ValueError, "duplicate or out-of-order"):
                dispatch_view.read(folder, start=first.isoformat(), end=end)


if __name__ == "__main__":
    unittest.main()
