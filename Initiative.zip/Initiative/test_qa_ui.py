import json
import math
import re
import unittest
from pathlib import Path

import report
import report_doc

ROOT = Path(__file__).resolve().parent
RUN_ID = "25253846a35d4d2583767b43da6bd098"
RUN_DIR = ROOT / "Application Runs" / RUN_ID


class FormattingTests(unittest.TestCase):
    def test_non_finite_numbers_render_as_na(self):
        for value in (float("nan"), math.inf, -math.inf):
            for fn in (report.num, report.usd, report.mil, report.pct):
                self.assertEqual(fn(value), "n/a")

    def test_cell_handles_tuples_and_none(self):
        text = report_doc.cell((1, None, "a"))
        self.assertNotIn("None", text)


@unittest.skipUnless(RUN_DIR.exists(), "example run not available")
class ReportContentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = report.build_report(RUN_ID)
        cls.rel = next(json.load(open(p, encoding="utf-8")) for p in sorted((RUN_DIR / "reliability").glob("*.json")))

    def test_no_broken_placeholders(self):
        for bad in ("[object Object]", "NaN", "{{", ">undefined<"):
            self.assertNotIn(bad, self.html)

    def test_reliability_section_uses_current_schema(self):
        self.assertIn("Contingency results", self.html)
        self.assertIn(report.num(self.rel["contingencies"][0]["lost_mw"], 1), self.html)

    def test_design_section_has_no_raw_model_dump(self):
        self.assertNotIn("raw_model", self.html)
        self.assertNotIn("sld_model", self.html)
        self.assertFalse(re.search(r"\(\s*&#x27;|\(\s*'[^']*',\s*None", self.html))


class ReliabilityJsTests(unittest.TestCase):
    def test_verdict_object_is_formatted(self):
        src = (ROOT / "generation_ui" / "reliability.js").read_text(encoding="utf-8")
        self.assertIn("verdictText", src)
        self.assertIn("failedRun", src)


class ServerTests(unittest.TestCase):
    def test_server_has_json_500_and_favicon(self):
        src = (ROOT / "generation_app.py").read_text(encoding="utf-8")
        self.assertIn("/favicon.ico", src)
        self.assertIn("except Exception", src)


if __name__ == "__main__":
    unittest.main()
