"""Resource, annual emissions, thermal boundary and lifecycle regression tests."""

import csv
from datetime import datetime
import io
import unittest

import numpy as np

import demand_forecasting
import generation_app as app
import lifecycle_costs
import optimize_generation_mix as model
import resource_profiles
import scenario_analysis
import scenario_inputs
from test_client_planning import short_data
from test_generation_optimization import small_inputs


def resource(column, value):
    stream = io.StringIO()
    writer = csv.writer(stream)
    writer.writerow(["timestamp", column])
    for date in demand_forecasting.planning_dates(2024, 1):
        writer.writerow([str(date), value])
    return dict(name="profile.csv", content=stream.getvalue())


class ResourceEconomicsRevisionTests(unittest.TestCase):
    def request(self, **values):
        return app.validate_request(dict(values=dict(horizon_years=1, **values), scenarios=["R0","P1"]))

    def test_resource_replay_conversion_and_malformed_input(self):
        dates = [datetime(2031, 7, 4), datetime(2032, 2, 29)]
        actual, _ = resource_profiles.read_profile(resource("poa_irradiance_w_m2", 700), dates, "solar")
        np.testing.assert_allclose(actual, .7)
        bad = dict(name="bad.csv", content="timestamp,solar_per_mw\n2031-01-01 00:00,3")
        with self.assertRaisesRegex(ValueError, "invalid nonnegative"):
            resource_profiles.read_profile(bad, dates, "solar")
        with self.assertRaisesRegex(ValueError, "complete calendar"):
            resource_profiles.read_profile(dict(name="short.csv",
                content="timestamp,heat_mwth\n2031-01-01 00:00,2"), dates, "thermal")

    def test_separate_planned_solar_and_thermal_off(self):
        request = self.request()
        request.update(solar_file=resource("solar_per_mw", .8),
                       planned_solar_file=resource("solar_per_mw", .3),
                       planned_solar_profile_enabled=True)
        request["values"]["solar_profile_enabled"] = True
        request = app.validate_request(request)
        request["planned_generation"] = [p for p in request["planned_generation"] if p["technology"] != "Mobile Trailers"]
        data, _ = app.make_data(request)
        np.testing.assert_allclose(data["solar"], .8 * request["values"]["solar_derate"])
        solar_capacity = (.5 + 10/3) * .85
        np.testing.assert_allclose(data["planned_solar_available"], .3 * solar_capacity)
        self.assertTrue(np.all(data["planned_direct_supply"] <= data["service_load"]))
        np.testing.assert_allclose(data["load"],
            np.maximum(data["service_load"] - data["planned_solar_available"] - data["planned_wind"], 0))
        request["values"].update(thermal_enabled=True, thermal_profile_enabled=True)
        request["thermal_file"] = resource("heat_mwth", 1.7)
        hot, _ = app.make_data(app.validate_request(request))
        np.testing.assert_allclose(hot["heat"], 1.7)
        self.assertEqual(app.settings_for(self.request()["values"])["boiler_credit"], 0)

    def test_appraisal_extends_calendar_and_respects_physical_aging(self):
        request = self.request(appraisal_years=3, pv_life=2)
        data, _ = app.make_data(request)
        extended = resource_profiles.extend_appraisal(data, request["values"])
        self.assertEqual(extended["dates"][-1].year, data["dates"][0].year + 2)
        self.assertEqual(extended["appraisal_years"], 3)
        np.testing.assert_allclose(extended["gross_load"][:len(data["load"])], data["gross_load"])
        for yi in range(3):
            sel = extended["years"] == yi
            resource = extended["solar_resource"][sel]
            ratio = extended["solar"][sel][resource > 0] / resource[resource > 0]
            np.testing.assert_allclose(ratio, request["values"]["solar_derate"] *
                                       (1-request["values"]["solar_degradation"])**(yi % 2))
        np.testing.assert_allclose(extended["load"],
            np.maximum(extended["service_load"] - extended["planned_solar_available"] -
                       extended["planned_wind"], 0))

    def test_replacement_present_value_and_cashflow_identity(self):
        request = self.request(bess_life=3)
        cfg = app.settings_for(request["values"])
        data = small_inputs()
        cfg, names = scenario_inputs.settings(cfg, dict(technologies=["grid","bess"]))
        result = model.solve_decomposed(data, "REPL", "Replacement audit", names, settings=cfg)
        caps, econ = result["caps"], result["economics"]
        equipment = caps["bess_mw"] * cfg["bess_power_capex"] + caps["bess_mwh"] * cfg["bess_energy_capex"]
        expected, events = lifecycle_costs.replacements(equipment, 3, cfg["replacement_fraction"], 10,
                                                       cfg["inflation"], cfg["discount"])
        self.assertGreater(expected, 0)
        self.assertAlmostEqual(econ["replacement_pv"], expected)
        self.assertEqual([a["replacement"] for a in econ["annual"]],
                         [events.get(y, 0) for y in range(1, 11)])
        self.assertAlmostEqual(econ["npc"], econ["capex"] + econ["upgrade_pv"] +
            sum(a["total_cash_cost"] / (1+cfg["discount"])**(i+1) for i,a in enumerate(econ["annual"])))
        self.assertLessEqual(result["validation"]["master_gap_usd"], 201)

    def test_annual_emissions_cap_is_hard_and_reconciles_reporting(self):
        data = short_data()
        request = self.request(microgrid_min_mw=0, microgrid_max_mw=0,
                               emissions_limit_enabled=True, emissions_limit_t_year=1000,
                               reactive_enabled=False)
        cfg = app.settings_for(request["values"])
        cfg["grid_limit"] = 100
        cfg["boiler_credit"] = 0
        cfg["boiler_emissions_t_mwhth"] = 0
        capped = model.solve_decomposed(data, "CAP", "Annual cap", ["none"], settings=cfg)
        net = capped["economics"]["annual"][0]["net_co2e_after_heat_credit_t"]
        self.assertLessEqual(net, 1000.0001)
        self.assertAlmostEqual(net, capped["dispatch"]["grid"].sum() * cfg["grid_emissions_t_mwh"])
        self.assertGreater(capped["adequacy"]["unserved_mwh"], 0)
        cfg["emissions_limit_enabled"] = False
        uncapped = model.solve_decomposed(data, "FREE", "Cap disabled", ["none"], settings=cfg)
        self.assertEqual(uncapped["adequacy"]["unserved_hours"], 0)
        self.assertGreater(uncapped["economics"]["annual"][0]["net_co2e_after_heat_credit_t"], 1000)

    def test_emissions_feasibility_cuts_can_build_heat_recovery(self):
        data = short_data()
        data["planned_solar_direct"] = np.full(len(data["load"]), .1)
        request = self.request(microgrid_min_mw=0, microgrid_max_mw=10,
                               thermal_enabled=True, boiler_efficiency=.1,
                               emissions_limit_enabled=True, emissions_limit_t_year=0,
                               grid_emissions_t_mwh=0, pv_emissions_t_mwh=1)
        cfg = app.settings_for(request["values"])
        cfg.update(grid_limit=100, pv_max=0, bess_power_max=0, bess_energy_max=0)
        result = model.solve_decomposed(data, "HEAT", "Feasibility cuts", ["ng_chp"], settings=cfg)
        self.assertGreater(result["caps"]["generators_mw"]["ng_chp"], 0)
        self.assertLessEqual(result["economics"]["annual"][0]["net_co2e_after_heat_credit_t"], .0001)

    def test_maintenance_fractions_and_fuel_costs_per_technology(self):
        values = self.request(ng_fuel_price=11, ng_chp_fuel_price=9, h2_fuel_price=4,
                              h2_chp_fuel_price=7, pv_fom_fraction=.023)["values"]
        cfg = app.settings_for(values)
        self.assertAlmostEqual(cfg["pv_fom"], values["pv_capex"] * .023)
        for key in ("ng","ng_chp","h2","h2_chp"):
            spec = cfg["technology_parameters"][key]
            self.assertAlmostEqual(spec["fom"], spec["capex"] * values[key+"_fom_fraction"])
        self.assertNotEqual(cfg["technology_parameters"]["ng"]["fuel"],
                            cfg["technology_parameters"]["ng_chp"]["fuel"])

    def test_no_wind_silent_simulation_and_no_grid_scenario_supported(self):
        self.assertIn("wind", dict(scenario_inputs.TECHNOLOGIES))
        self.assertEqual(scenario_inputs.validate([dict(id="W", technologies=["wind"])])[0]["technologies"], ["wind"])
        with self.assertRaisesRegex(ValueError, "wind_file"):
            app.validate_request(dict(values={}, scenario_definitions=[dict(id="W", technologies=["wind"])],
                                      scenarios=["W"]))
        definitions = scenario_inputs.validate([dict(id="ISL", technologies=["pv","bess"])])
        cfg, _ = scenario_inputs.settings(app.settings_for(self.request()["values"]), definitions[0])
        self.assertTrue(cfg["islanded"])
        self.assertEqual(cfg["grid_limit"], 0)


if __name__ == "__main__":
    unittest.main()
