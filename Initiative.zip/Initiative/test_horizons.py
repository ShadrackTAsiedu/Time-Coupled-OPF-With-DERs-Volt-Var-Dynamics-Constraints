"""Any data period x any economic horizon, forecast on/off, and the grid-upgrade-only-if-required rule."""

import json
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np

import demand_forecasting as forecasting
import generation_app as app
import optimize_generation_mix as model
import scenario_inputs
from test_generation_optimization import small_inputs

ROOT = Path(__file__).resolve().parent
USER_RUN = ROOT / "Application Runs" / "7791be18470745f8af5ef34fa3d208f8"


def load_csv(start, hours, base=26.0, peak=44.0, growth_per_year=0.0):
    lines = ["timestamp,load_mw"]
    for i in range(hours):
        d = start + timedelta(hours=i)
        value = (peak if 17 <= d.hour < 21 else base) * (1 + growth_per_year) ** (d.year - start.year)
        lines.append(f"{d:%Y-%m-%d %H:%M:%S},{value}")
    return "\n".join(lines) + "\n"


def make_request(csv_text=None, mode="historical", forecast_text=None, **values):
    full = {f["key"]: f["default"] for f in app.FIELDS}
    full.update(trajectory_mode="model", baseline=33.34421, microgrid_min_mw=0, microgrid_max_mw=1e12)
    full.update(values)
    payload = dict(values=full, scenarios=["R0", "P1"], planned_generation=[])
    if csv_text is not None:
        payload.update(upload_csv=csv_text, import_mode=mode)
    if forecast_text is not None:
        payload.update(forecast_files=[dict(name="forecast.csv", content=forecast_text)], demand_source="upload")
    return app.validate_request(payload)


class DataPeriodTests(unittest.TestCase):
    def check_shape(self, data, horizon):
        self.assertEqual(int(data["years"].max()) + 1, horizon)
        self.assertEqual(len(data["load"]), len(data["dates"]))
        self.assertEqual(len(data["facility"]), 12 * horizon)
        self.assertTrue(np.all(np.isfinite(data["load"])) and data["load"].min() >= 0)

    def test_every_data_length_with_forecast_on_and_off(self):
        cases = {"24h": (datetime(2025, 6, 10), 24), "168h": (datetime(2025, 3, 3), 168),
                 "1 month": (datetime(2025, 7, 1), 744), "1 year": (datetime(2025, 1, 1), 8760),
                 "2 years": (datetime(2025, 1, 1), 17520)}
        for name, (start, hours) in cases.items():
            text = load_csv(start, hours)
            for mode in ("none", "grow"):
                for horizon in (1, 2):
                    with self.subTest(data=name, forecast=mode, horizon=horizon):
                        request = make_request(text, forecast_mode=mode, horizon_years=horizon)
                        data, _ = app.make_data(request)
                        self.check_shape(data, horizon)
                        period = data["forecast_audit"]["data_period"]
                        self.assertEqual(period["hours"], hours)
                        self.assertEqual(period["economic_horizon_years"], horizon)
                        self.assertEqual(period["full_year"], hours >= 8760)
                        if mode == "none":
                            self.assertAlmostEqual(float(data["qmax"].max()), 44.0, delta=1.0)
                            self.assertEqual(data["load"][data["years"] == 0].max(),
                                             data["load"][data["years"] == horizon - 1].max())

    def test_all_economic_horizons_without_forecast(self):
        text = load_csv(datetime(2025, 6, 10), 24)
        for horizon in (1, 2, 5, 10, 15, 20):
            with self.subTest(horizon=horizon):
                data, _ = app.make_data(make_request(text, forecast_mode="none", horizon_years=horizon))
                self.check_shape(data, horizon)
                self.assertEqual(len(data["load"]), len(forecasting.planning_dates(2027, horizon)))

    def test_no_forecast_growth_applies_flat_rate_per_year(self):
        text = load_csv(datetime(2025, 1, 1), 8760)
        data, _ = app.make_data(make_request(text, forecast_mode="none", horizon_years=3, economic_growth=.1))
        peaks = [float(data["qmax"][data["years"] == y].max()) for y in range(3)]
        self.assertAlmostEqual(peaks[1] / peaks[0], 1.1)
        self.assertAlmostEqual(peaks[2] / peaks[0], 1.21)

    def test_short_period_not_annualized_dispatches_only_the_period(self):
        text = load_csv(datetime(2025, 6, 10), 24)
        data, _ = app.make_data(make_request(text, forecast_mode="none", horizon_years=2, annualize_partial=False))
        self.assertEqual(len(data["load"]), 48)
        self.assertEqual(list(np.unique(data["years"])), [0, 1])
        self.assertFalse(data["forecast_audit"]["data_period"]["annualized"])
        self.assertTrue(data["forecast_audit"]["data_period"]["warnings"])

    def test_clear_validation_messages_name_the_field(self):
        with self.assertRaisesRegex(ValueError, "at least 24"):
            app.make_data(make_request(load_csv(datetime(2025, 1, 1), 12), forecast_mode="none"))
        with self.assertRaisesRegex(ValueError, "Economic horizon"):
            make_request(horizon_years=31)
        with self.assertRaisesRegex(ValueError, "Economic horizon"):
            make_request(horizon_years=2.5)
        with self.assertRaisesRegex(ValueError, "Economic horizon"):
            make_request(horizon_years=0)
        with self.assertRaisesRegex(ValueError, "year-end"):
            app.make_data(make_request(load_csv(datetime(2025, 12, 31, 20), 30), forecast_mode="none",
                                       annualize_partial=False))
        with self.assertRaisesRegex(ValueError, "Forecast mode"):
            make_request(forecast_mode="sometimes")

    def test_forecast_file_longer_or_shorter_than_horizon_is_accepted(self):
        full = load_csv(datetime(2027, 1, 1), len(forecasting.planning_dates(2027, 3)), growth_per_year=.05)
        for horizon in (1, 3, 5):
            with self.subTest(horizon=horizon):
                data, _ = app.make_data(make_request(forecast_text=full, horizon_years=horizon))
                self.check_shape(data, horizon)
                self.assertAlmostEqual(float(data["qmax"][data["years"] == 0].max()), 44.0)
                if horizon == 5:  # years 4-5 repeat the last projected year
                    self.assertAlmostEqual(float(data["qmax"][data["years"] == 4].max()),
                                           float(data["qmax"][data["years"] == 2].max()))

    def test_forecast_file_in_other_years_is_shifted_and_short_file_is_representative(self):
        shifted = load_csv(datetime(2030, 1, 1), 8760)
        data, _ = app.make_data(make_request(forecast_text=shifted, horizon_years=1))
        self.assertEqual(data["dates"][0].year, 2027)
        short = load_csv(datetime(2027, 5, 5), 48)
        data, _ = app.make_data(make_request(forecast_text=short, forecast_mode="none", horizon_years=2))
        self.check_shape(data, 2)

    def test_existing_ten_year_defaults_are_unchanged(self):
        self.assertEqual(app.make_data(make_request(load_csv(datetime(2025, 1, 1), 8760)))[0]["years"].max(), 9)
        self.assertEqual(next(f for f in app.FIELDS if f["key"] == "forecast_mode")["default"], "grow")
        self.assertEqual(next(f for f in app.FIELDS if f["key"] == "horizon_years")["default"], 10)


class OptimizerHorizonTests(unittest.TestCase):
    def solve(self, text, scenario="P1", **values):
        request = make_request(text, **values)
        data, _ = app.make_data(request)
        cfg = app.settings_for(request["values"])
        cfg.update(pv_min=0, pv_max=4, bess_power_max=6, bess_energy_max=24, generator_max=0)
        definition = next(s for s in request["scenario_definitions"] if s["id"] == scenario)
        scenario_cfg, tech = scenario_inputs.settings(cfg, definition)
        return data, model.solve_decomposed(data, scenario, scenario, tech, reference=definition["reference"],
                                            settings=scenario_cfg)

    def test_24_hour_run_end_to_end_through_optimizer(self):
        text = load_csv(datetime(2025, 6, 10), 24)
        for scenario in ("R0", "P1"):
            data, result = self.solve(text, scenario, forecast_mode="none", horizon_years=1)
            self.assertEqual(len(result["economics"]["annual"]), 1)
            self.assertLess(result["validation"]["hourly_balance_error_mw"], 5e-5)
            self.assertEqual(result["adequacy"]["unserved_hours"], 0)

    def test_horizons_one_to_five_through_optimizer_and_npc_grows_with_horizon(self):
        text = load_csv(datetime(2025, 1, 1), 24 * 7)
        npcs = []
        for horizon in (1, 2, 5):
            _, result = self.solve(text, "R0", forecast_mode="none", horizon_years=horizon)
            self.assertEqual(len(result["economics"]["annual"]), horizon)
            npcs.append(result["economics"]["npc"])
        self.assertLess(npcs[0], npcs[1])
        self.assertLess(npcs[1], npcs[2])

    def test_period_only_run_charges_only_the_period(self):
        text = load_csv(datetime(2025, 6, 10), 24, peak=30.0)
        _, annual = self.solve(text, "R0", forecast_mode="none", horizon_years=1)
        _, period = self.solve(text, "R0", forecast_mode="none", horizon_years=1, annualize_partial=False)
        self.assertLess(period["economics"]["npc"], annual["economics"]["npc"] / 50)

    def test_period_only_with_emissions_limit_is_rejected_clearly(self):
        text = load_csv(datetime(2025, 6, 10), 24)
        with self.assertRaisesRegex(ValueError, "emissions_limit_enabled"):
            app.make_data(make_request(text, forecast_mode="none", annualize_partial=False,
                                       emissions_limit_enabled=True, emission_factors_confirmed=True))


class GridUpgradeTests(unittest.TestCase):
    def cfg(self, **overrides):
        cfg = app.settings_for(make_request()["values"])
        cfg.update(pv_max=0, pv_min=0, bess_power_max=0, bess_energy_max=0, generator_max=0)
        cfg.update(overrides)
        return cfg

    def scaled(self, factor):
        data = small_inputs()
        for key in ("load", "qmax", "qmin"):
            data[key] = data[key] * factor
        return data

    def test_upgrade_not_required_costs_nothing_and_equals_grid_only(self):
        data = self.scaled(.6)  # peak ~26.7 MW against a 40 MW limit
        upgraded = model.solve_decomposed(data, "R0", "Grid with substation upgrade", "none", reference=True,
                                          settings=self.cfg())
        free = model.solve_decomposed(data, "G", "Grid only", "none", reference=True,
                                      settings=self.cfg(upgrade_cost=0.0, upgrade_fom_fraction=0.0))
        e = upgraded["economics"]
        self.assertFalse(e["upgrade_required"])
        self.assertEqual(e["upgrade_pv"], 0)
        self.assertEqual(e["upgrade_om_pv"], 0)
        self.assertIn("not required", e["upgrade_note"])
        self.assertAlmostEqual(e["npc"], free["economics"]["npc"], places=2)

    def test_upgrade_required_includes_capex_and_om(self):
        result = model.solve_decomposed(small_inputs(), "R0", "Grid with substation upgrade", "none",
                                        reference=True, settings=self.cfg())
        e = result["economics"]
        self.assertTrue(e["upgrade_required"])
        self.assertAlmostEqual(e["upgrade_pv"], 70e6)
        self.assertGreater(e["upgrade_om_pv"], 0)
        self.assertEqual(e["upgrade_first_year"], 2027)
        self.assertGreater(e["npc"], 70e6)

    def test_upgrade_sized_pro_rata_beyond_quoted_capacity(self):
        result = model.solve_decomposed(small_inputs(), "R0", "Grid with substation upgrade", "none",
                                        reference=True, settings=self.cfg(reference_grid_limit=42.0))
        needed = result["economics"]["upgrade_needed_import_mw"]
        self.assertAlmostEqual(result["economics"]["upgrade_pv"], 70e6 * (needed - 40) / (42 - 40), places=0)

    def test_alternative_scenarios_never_pay_an_upgrade(self):
        cfg = self.cfg(pv_max=8, pv_min=8, bess_power_max=20, bess_energy_max=80)
        result = model.solve_decomposed(small_inputs(), "P1", "PV+BESS", "none", settings=cfg)
        self.assertEqual(result["economics"]["upgrade_pv"], 0)
        self.assertLessEqual(result["validation"]["max_quarter_hour_grid_mw"], 40.00005)

    def test_one_year_user_case_no_upgrade_but_ten_year_unchanged(self):
        if not USER_RUN.exists():
            self.skipTest("saved user run is not available")
        request = json.loads((USER_RUN / "request.json").read_text(encoding="utf-8"))
        saved = json.loads((USER_RUN / "result_R0.json").read_text(encoding="utf-8"))["economics"]
        results = {}
        for horizon in (1, 10):
            request["values"]["horizon_years"] = horizon
            checked = app.validate_request(request)
            data, _ = app.make_data(checked)
            cfg = app.settings_for(checked["values"])
            cfg["topology"] = checked["topology"]
            definition = next(s for s in checked["scenario_definitions"] if s["id"] == "R0")
            scenario_cfg, tech = scenario_inputs.settings(cfg, definition)
            results[horizon] = model.solve_decomposed(data, "R0", "R0", tech, reference=True,
                                                      settings=scenario_cfg)["economics"]
        self.assertFalse(results[1]["upgrade_required"])
        self.assertEqual(results[1]["upgrade_pv"], 0)
        self.assertLess(results[1]["npc"], 30e6)
        self.assertTrue(results[10]["upgrade_required"])
        self.assertAlmostEqual(results[10]["upgrade_pv"], saved["upgrade_pv"])
        # The saved run predates the irradiance->PV conversion (pv_model), which moves only the grid energy cost
        # (+0.65%); the upgrade sizing and cost stay exactly as saved.
        self.assertAlmostEqual(results[10]["npc"] / saved["npc"], 1.0, delta=0.01)
        self.assertAlmostEqual(results[10]["upgrade_om_pv"], saved["upgrade_om_pv"])


class WorkerEndToEndTests(unittest.TestCase):
    def test_24_hour_run_completes_through_worker_with_results(self):
        request = make_request(load_csv(datetime(2025, 6, 10), 24), forecast_mode="none", horizon_years=1)
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            (folder / "request.json").write_text(json.dumps(request), encoding="utf-8")
            app.worker(folder)
            status = json.loads((folder / "status.json").read_text(encoding="utf-8"))
            self.assertEqual(status["state"], "complete", status.get("message"))
            self.assertEqual(status["planning"]["data_period"]["hours"], 24)
            self.assertFalse(status["failures"])
            self.assertTrue((folder / "result_R0.json").exists())


if __name__ == "__main__":
    unittest.main()
