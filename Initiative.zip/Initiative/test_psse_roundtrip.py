"""PSS/E round trip of the RAW export: random messy topologies and every scenario/hour of a saved run are loaded in PSS/E 35/36,
must read and solve with no message other than routine progress, and must reproduce the GenStudio solution (1e-3 pu / 1e-2 MW)."""
import json
import random
import re
import shutil
import tempfile
import unittest
from pathlib import Path

import network_topology
import power_flow as pf
import psse_check
from test_power_flow import diagram

HERE = Path(__file__).resolve().parent
RUN = HERE / "Application Runs" / "7791be18470745f8af5ef34fa3d208f8"
GEN_KINDS = ["pv", "bess", "wind", "ng", "ng_chp", "h2", "h2_chp", "diesel", "biogas", "biomass"]


def random_network(seed):
    """(net, inj) of a random user-drawn single-line diagram: loops, parallel feeders, orphan loads, islands, out-of-service
    equipment, shunts, mixed 11/33 kV, user bus numbers/names/areas/zones, voltage/pf/Q-controlled generators."""
    rnd = random.Random(seed)
    nodes = [("g", "grid")] if rnd.random() < 0.85 else []
    buses = [f"b{k}" for k in range(rnd.randint(1, 4))]
    nodes += [(b, "bus") for b in buses]
    loads = [f"l{k}" for k in range(rnd.randint(1, 3))]
    nodes += [(l, "load") for l in loads]
    gens = [(f"x{k}", rnd.choice(GEN_KINDS)) for k in range(rnd.randint(0, 5))]
    if not nodes or nodes[0][1] != "grid":
        gens.append(("xb", "bess"))
    nodes += gens
    ids = [n[0] for n in nodes]
    lines, count = [], 0
    attach = []
    for k, ident in enumerate(ids):
        if ident == "g":
            continue
        if ident == buses[0]:
            if "g" in ids:
                attach.append((ident, "g"))
        else:
            attach.append((ident, rnd.choice([b for b in buses if b != ident])))
    for a, b in attach:
        count += 1
        lines.append((f"w{count}", a, b, rnd.choice([0, 0, 0.4, 1.5, 6.0])))
    if "g" not in ids:
        count += 1
        lines.append((f"w{count}", "xb", buses[0], 0))
    for _ in range(rnd.randint(0, 3)):
        a, b = rnd.sample([i for i in ids if i != "g"] or ids, 2)
        count += 1
        lines.append((f"w{count}", a, b, rnd.choice([0, 0.8, 2.5])))
    diag = diagram(nodes, lines)
    for n in diag["nodes"]:
        e = {}
        kv = 33.0 if n["kind"] == "grid" else rnd.choice([11.0, 11.0, 33.0])
        if rnd.random() < 0.7:
            e["kv"] = kv
        if n["kind"] in ("bus", "load") and rnd.random() < 0.3:
            e["shunt_mvar"] = rnd.choice([-0.6, 0.6, 1.2, 2.4])
        if rnd.random() < 0.15 and n["kind"] not in ("grid",):
            e["in_service"] = False
        if rnd.random() < 0.3:
            e["bus_number"] = rnd.choice([17, 105, 12345, 98765])
        if rnd.random() < 0.3:
            e["bus_name"] = rnd.choice(["Main Plant HV 33kV long name", "a b", "x'y", "Ü-bus"])
        if rnd.random() < 0.3:
            e["area"], e["zone"] = rnd.choice([(2, 3), (5, 1), (1, 7)])
        if n["kind"] in GEN_KINDS:
            e["control"] = rnd.choice(["pf", "voltage", "q"])
            e["pf"] = rnd.choice([0.9, 0.95, 1.0])
            e["pf_mode"] = rnd.choice(["lag", "lead"])
            e["vset"] = rnd.choice([0.98, 1.0, 1.03])
            e["q_mvar"] = rnd.choice([-0.4, 0.0, 0.5])
            if rnd.random() < 0.3:
                e["q_min_mvar"], e["q_max_mvar"] = -0.2, 0.3
            if rnd.random() < 0.3:
                e["pmax_mw"], e["pmin_mw"], e["mbase_mva"], e["xd2_pu"] = 3.0, 0.0, 4.0, 0.2
        if n["kind"] == "load" and rnd.random() < 0.3:
            e["load_mw"], e["load_mvar"] = 0.7, 0.2
        if n["kind"] == "grid":
            e["sc_mva"] = rnd.choice([75.0, 750.0, 5000.0])
            e["vset"] = rnd.choice([1.0, 1.02])
        if e:
            n["electrical"] = e
    for edge in diag["lines"]:
        e = {}
        if rnd.random() < 0.12:
            e["in_service"] = False
        if rnd.random() < 0.2:
            e["circuits"] = 2
        if rnd.random() < 0.3:
            e["mva"], e["tap"] = rnd.choice([(5.0, 1.025), (10.0, 0.975), (16.0, 1.0)])
        if e:
            edge["electrical"] = e
    diag = network_topology.pf_view(diag)
    caps = {k: rnd.choice([1.0, 2.0, 5.0]) for k in GEN_KINDS}
    net = pf.build_network(diag, caps=caps, peak_load_mw=rnd.choice([1.0, 3.0, 6.0]))
    inj = dict(load_mw=rnd.choice([0.5, 3.0, 8.0]), gens={})
    for g in net.gens:
        if g["tech"] != "grid":
            inj["gens"][g["tech"]] = dict(p=rnd.choice([-1.0, 0.0, 0.3, 1.0, 2.0]) if g["tech"] == "bess" else rnd.choice([0.0, 0.3, 1.0, 2.0]))
    return net, inj


def compare(net, case, res):
    """Largest |PSS/E - GenStudio| over bus voltage (pu), angle (deg), branch flow (MW/Mvar) and generator output (MW/Mvar)."""
    bus = {b["number"]: b for b in res["bus"]}
    worst = dict(vm=0.0, va=0.0, flow=0.0, machine=0.0)
    nums = {b["id"]: b["num"] for b in net.buses}
    for b in case["buses"] + case["internal"]:
        if nums[b["id"]] in bus and b["vm"]:
            got = bus[nums[b["id"]]]
            worst["vm"] = max(worst["vm"], abs(got["vm"] - b["vm"]))
            worst["va"] = max(worst["va"], abs(got["va"] - b["va_deg"]))
    pairs = {}
    for r in res["branch"]:
        low, high = sorted((r["from_"], r["to"]))
        p, q = (r["p"], r["q"]) if r["from_"] == low else (-(r["p"] - r["loss_p"]), -(r["q"] - r["loss_q"]))
        got = pairs.setdefault((low, high), [0.0, 0.0])
        got[0] += p
        got[1] += q
    app = {}
    for br in case["branches"]:
        if not br["energized"]:
            continue
        a, b = nums[br["from_id"]], nums[br["to_id"]]
        p, q = (br["p_from_mw"], br["q_from_mvar"]) if a <= b else (br["p_to_mw"], br["q_to_mvar"])
        got = app.setdefault((min(a, b), max(a, b)), [0.0, 0.0])
        got[0] += p
        got[1] += q
    for key, mine in app.items():
        theirs = pairs.get(key)
        worst["flow"] = float("inf") if theirs is None else max(worst["flow"], *(abs(x - y) for x, y in zip(mine, theirs)))
    machines = {m["bus"]: m for m in res["machine"]}
    for g in case["gens"]:
        if g["tech"] == "grid":
            continue
        m = machines.get(nums[g["id"]])
        if m:
            worst["machine"] = max(worst["machine"], abs(m["p"] - g["p_mw"]), abs(m["q"] - g["q_mvar"]))
    return worst


def check_files(items):
    """items: list of (name, raw text, case or None, net); writes the files, runs PSS/E, returns [(name, entry, worst)]."""
    folder = Path(tempfile.mkdtemp(dir=HERE))
    try:
        paths = []
        for name, text, _, _ in items:
            path = folder / f"{name}.raw"
            path.write_text(text, encoding="utf-8", newline="")
            paths.append(str(path))
        entries = psse_check.check(paths, details=True)
        return [(name, entry, compare(net, case, entry) if case is not None and entry.get("bus") else None)
                for (name, _, case, net), entry in zip(items, entries)]
    finally:
        shutil.rmtree(folder, ignore_errors=True)


@unittest.skipUnless(psse_check.available(), "PSS/E with its Python is not available")
class PsseRoundTrip(unittest.TestCase):
    def assert_clean(self, results):
        for name, entry, worst in results:
            with self.subTest(name):
                self.assertTrue(entry["ok"], {k: v for k, v in entry.items() if k not in ("bus", "branch", "machine")})
                if worst is not None:
                    self.assertLess(worst["vm"], 1e-3, worst)
                    self.assertLess(worst["va"], 0.05, worst)
                    self.assertLess(worst["flow"], 1e-2, worst)
                    self.assertLess(worst["machine"], 1e-2, worst)

    def test_machine_q_limits_and_mbase_read_back_from_psse_even_when_idle(self):
        d = network_topology.autodraw(["grid", "pv", "bess", "ng"], enabled=True)
        net = pf.build_network(network_topology.pf_view(d), {"pv": 6.6833, "bess": 3.0, "ng": 4.0}, peak_load_mw=8.0)
        inj = dict(load_mw=8.0, gens={t: dict(p=0.0) for t in ("pv", "bess", "ng")})
        case = pf.solve_case(net, inj, label="idle")
        text, _ = pf.export_raw_notes(net, inj, case)
        self.assertEqual(pf.raw_consistency_problems(text), [])
        (_, entry, worst), = check_files([("idle", text, case, net)])
        self.assertTrue(entry["ok"], entry)
        by_bus = {m["bus"]: m for m in entry["machine"]}
        pv = next(m for m in entry["machine"] if abs(m["pmax"] - 6.6833) < 1e-3)
        self.assertAlmostEqual(pv["mbase"], 6.6833 / 0.9, places=2)
        self.assertAlmostEqual(pv["qmax"], 6.6833 / 0.9, places=2)  # MVA circle at P = 0: Qmax = S, not 0
        self.assertAlmostEqual(pv["qmin"], -6.6833 / 0.9, places=2)
        bess = next(m for m in entry["machine"] if abs(m["pmax"] - 3.0) < 1e-3)
        self.assertAlmostEqual(bess["qmax"], 3.0 / 0.9, places=2)
        ng_row = next(l for l in text.split("BEGIN GENERATOR DATA")[1].splitlines() if l.startswith("3002,")).split(",")
        self.assertGreater(float(ng_row[4]), 0.0)  # offline set keeps its nameplate capability in the record
        self.assertLess(float(ng_row[5]), 0.0)
        self.assertEqual(int(ng_row[14]), 0)
        self.assertLess(worst["vm"], 1e-3)

    def test_random_messy_topologies_load_and_solve_cleanly(self):
        items = []
        for seed in range(60):
            try:
                net, inj = random_network(seed)
            except ValueError:
                continue
            case = pf.solve_case(net, inj, label="t")
            try:
                text, _ = pf.export_raw_notes(net, inj, case)
            except ValueError:
                continue
            self.assertEqual(pf.raw_consistency_problems(text), [], seed)
            items.append((f"seed{seed}", text, case if case["converged"] else None, net))
        self.assertGreater(len(items), 30)
        self.assert_clean(check_files(items))

    @unittest.skipUnless(RUN.is_dir(), "the reference run is not on this machine")
    def test_reference_run_scenarios_match_psse(self):
        items = []
        results = json.loads((RUN / "status.json").read_text())["summary"]["results"]
        for r in results:
            ctx = pf._run_context(RUN, r["code"])
            data = pf._read_dispatch(ctx["path"])
            net = pf._prepare(ctx, r["code"], None, None, data)
            for label, hour in pf._hour_selection(data)[0]:
                inj = pf._hour_inputs(data, hour)
                pf._assign_genset_total(net, data, inj, hour)
                case = pf.solve_case(net, inj, label=label)
                text, _ = pf.export_raw_notes(net, inj, case)
                items.append((f"{r['code']}_{hour}", text, case, net))
        self.assert_clean(check_files(items))


class RawFormatTests(unittest.TestCase):
    def test_header_documents_the_export(self):
        net, inj = random_network(1)
        text = pf.export_raw(net, inj, meta=dict(project="Demo", scenario="P1", timestamp="2030-01-01 12:00:00"))
        head = text.splitlines()[:3]
        self.assertTrue(head[0].startswith("0, "))
        self.assertIn("P1", head[1] + head[2])
        self.assertIn("2030-01-01 12:00:00", head[1] + head[2])
        self.assertTrue(all(len(line) <= 60 for line in head[1:]))
        self.assertEqual(text, pf.export_raw(net, inj, meta=dict(project="Demo", scenario="P1", timestamp="2030-01-01 12:00:00")),
                         "the export is deterministic")

    def test_names_areas_and_swing_records_are_unique_and_consistent(self):
        for seed in range(60):
            try:
                net, inj = random_network(seed)
                text = pf.export_raw(net, inj)
            except ValueError:
                continue
            rows = text.splitlines()
            starts = [i for i, line in enumerate(rows) if line.startswith("0 /")]
            bus_rows = [r.split(",") for r in rows[3:starts[0]]]
            bus_area = {int(r[0]): int(r[4]) for r in bus_rows}
            swings = {int(r[0]) for r in bus_rows if int(r[3]) == 3}
            names = [re.findall(r"'([^']*)'", rows[i])[-1] for i in range(starts[4] + 1, starts[5], 4)]
            self.assertEqual(len(names), len(set(names)), f"seed {seed}: duplicate transformer names")
            for r in (line.split(",") for line in rows[starts[5] + 1:starts[6]]):
                isw = int(r[1])
                if isw:
                    self.assertIn(isw, swings, f"seed {seed}: area slack must be a swing bus")
                    self.assertEqual(bus_area[isw], int(r[0]), f"seed {seed}: area slack outside its area")
            for r in rows[starts[3] + 1:starts[4]]:
                self.assertNotEqual(r.split(",")[0].strip(), r.split(",")[1].strip(), f"seed {seed}: bus joined to itself")


if __name__ == "__main__":
    unittest.main()
