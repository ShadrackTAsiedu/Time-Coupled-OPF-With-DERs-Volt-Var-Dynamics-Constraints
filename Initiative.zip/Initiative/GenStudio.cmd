@echo off
setlocal EnableDelayedExpansion
title GenStudio - Generation Planning Studio
cd /d "%~dp0"
set "PORT=8765"
if not "%~1"=="" set "PORT=%~1"
set "PY="
set "CHECK=import numpy, scipy, highspy, matplotlib, openpyxl, docx, pypdf, lxml, pptx, PIL, fitz"

echo ============================================================
echo  GenStudio - Generation Planning Studio
echo ============================================================

call :findpython
if not defined PY goto installpython

:havepython
%PY% -c "%CHECK%" >nul 2>&1
if not errorlevel 1 goto ready

echo.
echo Installing required Python packages (internet required, first run only)...
%PY% -m ensurepip --upgrade >nul 2>&1
%PY% -m pip install --disable-pip-version-check --upgrade pip >nul 2>&1
%PY% -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto pipfailed
%PY% -c "%CHECK%" >nul 2>&1
if errorlevel 1 goto pipfailed

:ready
netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul 2>&1
if not errorlevel 1 goto inuse

echo Starting on http://127.0.0.1:%PORT% - keep this window open while you work.
echo Close this window (or press Ctrl+C) to stop GenStudio.
echo.
%PY% generation_app.py --port %PORT% --open-browser
if errorlevel 1 goto failed
goto end

:findpython
for %%C in ("py -3" "python" "python3") do (
  if not defined PY (
    %%~C -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
    if not errorlevel 1 set "PY=%%~C"
  )
)
exit /b 0

:installpython
echo.
echo Python 3.10 or newer was not found. Installing Python 3.12 now...
where winget >nul 2>&1
if errorlevel 1 goto manualpython
winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
call :findpython
if not defined PY (
  for /d %%D in ("%LocalAppData%\Programs\Python\Python3*") do if exist "%%D\python.exe" if not defined PY set PY="%%D\python.exe"
)
if not defined PY goto manualpython
goto havepython

:manualpython
echo.
echo Python could not be installed automatically.
echo Download it from https://www.python.org/downloads/ , tick "Add python.exe to PATH",
echo then run this file again.
start "" "https://www.python.org/downloads/"
goto fail

:pipfailed
echo.
echo The required packages could not be installed. Check the internet connection
echo (or proxy settings) and run this file again. Manual command:
echo   %PY% -m pip install -r requirements.txt
goto fail

:inuse
echo.
echo Port %PORT% is already in use. GenStudio may already be running:
echo   http://127.0.0.1:%PORT%
echo To use another port run:  GenStudio.cmd 8766
start "" "http://127.0.0.1:%PORT%"
goto fail

:failed
echo.
echo GenStudio could not start. Read the message above.
echo See the Troubleshooting section of GENERATION_APP_README.md.

:fail
echo.
pause
exit /b 1

:end
endlocal
