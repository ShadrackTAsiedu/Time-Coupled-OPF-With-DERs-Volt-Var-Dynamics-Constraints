"""Read saved hourly balances without rerunning dispatch or repricing a study."""

import csv
from datetime import datetime, timedelta
import json
import math

import scenario_inputs


def bess_audit(file, result, config):
    """Monthly storage energy balance over the whole saved horizon (pooled committed + optimized BESS)."""
    settings = config.get("resolved") or {}
    eta = float(settings.get("round_trip_efficiency") or 0)
    nameplate = float((result.get("caps") or {}).get("bess_mwh") or 0)
    window = (float(settings.get("soc_max", 0.9)) - float(settings.get("soc_min", 0.1))) * nameplate
    months = {}
    with file.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if not {"charge", "discharge", "soc"} <= set(reader.fieldnames or []):
            return None
        for row in reader:
            key = row["timestamp"][:7]
            charge, discharge, soc = float(row["charge"]), float(row["discharge"]), float(row["soc"])
            item = months.get(key)
            if item is None:
                item = months[key] = dict(month=key, charge_mwh=0.0, discharge_mwh=0.0, soc_start_mwh=soc,
                                          soc_min_mwh=soc, soc_max_mwh=soc, charge_hours=0,
                                          discharge_hours=0, simultaneous_hours=0)
            item["charge_mwh"] += charge
            item["discharge_mwh"] += discharge
            item["soc_end_mwh"] = soc
            item["soc_min_mwh"] = min(item["soc_min_mwh"], soc)
            item["soc_max_mwh"] = max(item["soc_max_mwh"], soc)
            item["charge_hours"] += charge > 1e-6
            item["discharge_hours"] += discharge > 1e-6
            item["simultaneous_hours"] += charge > 1e-6 and discharge > 1e-6
    rows = list(months.values())
    for item in rows:
        item["cycles"] = item["discharge_mwh"] / window if window > 0 else None
        item["efficiency_realized"] = item["discharge_mwh"] / item["charge_mwh"] if item["charge_mwh"] > 1e-9 else None
        item["soc_drift_mwh"] = item.get("soc_end_mwh", 0) - item["soc_start_mwh"]
    return dict(rows=rows, round_trip_efficiency=eta or None,
                total_charge_mwh=sum(r["charge_mwh"] for r in rows),
                total_discharge_mwh=sum(r["discharge_mwh"] for r in rows),
                simultaneous_hours=sum(r["simultaneous_hours"] for r in rows),
                nameplate_mwh=nameplate, usable_mwh=window)


RESOLUTIONS = ("auto", "hour", "day", "month")
MAX_HOURLY_POINTS = 17568   # two leap years; longer periods must be aggregated to stay readable and responsive
MAX_POINTS = 2000


def recommended_code(folder, results):
    """Scenario code the Solve page recommends: the workflow ranking when saved, else the cheapest fully supplied one."""
    adequate = [r for r in results if not r["adequacy"]["unserved_hours"] and r["adequacy"]["stress_unserved_mwh"] <= 5e-5]
    if not adequate:
        return None
    try:
        import workflow
        code = workflow.recommendation(folder, results)["code"]
    except (OSError, ValueError, KeyError):
        code = None
    if any(r["code"] == code for r in adequate):
        return code
    return min(adequate, key=lambda r: r["economics"]["npc"])["code"]


PLANT_COLORS = ["#f2b134", "#e4572e", "#4d9078", "#b5838d", "#6d8fc4", "#8f7e3a", "#c46d9f", "#90be6d"]
_PLANTS = {}


def committed_plants(folder):
    """Existing and planned solar, wind and trailer plants of a run, for the per-plant layers of the whole-system chart.

    Each plant's output is the committed renewable output times its share of the installed effective capacity
    (planning_inputs.planned_profiles is linear in capacity, so the shares reproduce the optimizer's input exactly)."""
    path = folder / "request.json"
    try:
        stamp = path.stat().st_mtime_ns
    except OSError:
        return []
    hit = _PLANTS.get(str(path))
    if hit and hit[0] == stamp:
        return hit[1]
    try:
        projects = json.loads(path.read_text(encoding="utf-8")).get("planned_generation") or []
    except (OSError, ValueError):
        projects = []
    plants = []
    for index, p in enumerate(projects):
        tech = p.get("technology") if isinstance(p, dict) else None
        capacity = float((p.get("capacity_mw") if isinstance(p, dict) else 0) or 0)
        if tech not in ("Solar", "Wind", "Mobile Trailers") or capacity <= 0:
            continue
        status = "existing" if p.get("status") == "existing" else "planned"
        name = str(p.get("name") or "").strip() or f"{tech} {index + 1}"
        start, end = int(p["start_year"]), int(p.get("end_year", p["start_year"]))
        span = f"from {start}" if start == end else f"{start}-{end}"
        plants.append(dict(key=f"plant_{len(plants)}", kind="wind" if tech == "Wind" else "solar", trailer=tech == "Mobile Trailers",
                           capacity=capacity, start=start, end=end, month=int(p.get("start_month", 1)), derate=float(p.get("derate_factor", 1)),
                           degradation=float(p.get("degradation", 0)), cf=float(p.get("capacity_factor", 0)), status=status,
                           label=f"{'Existing' if status == 'existing' else 'Planned'}: {name}" + ("" if status == "existing" else f" ({span})"),
                           color=PLANT_COLORS[len(plants) % len(PLANT_COLORS)], cache={}))
    _PLANTS[str(path)] = (stamp, plants)
    return plants


def plant_weight(p, timestamp):
    """Effective capacity (MW) of a plant at an hour, as in planning_inputs.planned_profiles (wind: times capacity factor)."""
    year = timestamp.year
    on = not (p["trailer"] and year == p["start"] and timestamp < datetime(p["start"], p["month"], 1))
    key = (year, on)
    if key not in p["cache"]:
        if p["trailer"]:
            value = p["capacity"] * (1 - p["degradation"]) ** (year - p["start"]) * p["derate"] if year >= p["start"] and on else 0.0
        else:
            span = p["end"] - p["start"] + 1
            vintage = sum((1 - p["degradation"]) ** (year - c) / span for c in range(p["start"], min(year, p["end"]) + 1))
            value = p["capacity"] * vintage * p["derate"] * (p["cf"] if p["kind"] == "wind" else 1)
        p["cache"][key] = value
    return p["cache"][key]


def forecast_peaks(folder, start, end):
    """Hourly upper envelope of the built forecast (gross_load_max_mw), the profile the annual project peaks refer to."""
    file = folder / "hourly_projected_load.csv"
    out = {}
    try:
        with file.open(encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            if "gross_load_max_mw" not in (reader.fieldnames or []):
                return None
            for row in reader:
                stamp = datetime.fromisoformat(row["timestamp"])
                if stamp < start:
                    continue
                if stamp > end:
                    break
                out[stamp] = float(row["gross_load_max_mw"])
    except (OSError, ValueError, KeyError):
        return None
    return out


def read(folder, scenario=None, start=None, end=None, resolution="auto"):
    if resolution not in RESOLUTIONS:
        raise ValueError("Resolution must be auto, hour, day or month.")
    status = json.loads((folder / "status.json").read_text(encoding="utf-8"))
    if status["state"] != "complete" or not (status.get("summary") or {}).get("results"):
        raise ValueError("Complete a saved solve before exploring dispatch.")
    config = json.loads((folder / "run_configuration.json").read_text(encoding="utf-8"))
    planning = config.get("planning")
    if not isinstance(planning, dict) or not {"start_year", "end_year"} <= planning.keys():
        raise ValueError("This legacy run lacks explicit forecast horizon metadata. Solve again for the interactive view.")
    first = datetime(int(planning["start_year"]), 1, 1)
    last = datetime(int(planning["end_year"]) + 1, 1, 1) - timedelta(hours=1)
    results = status["summary"]["results"]
    best = recommended_code(folder, results)
    if not scenario or scenario == "best":
        if best is None:
            raise ValueError("No fully supplied scenario is available. Select a shortage scenario explicitly.")
        result = next(r for r in results if r["code"] == best)
    else:
        result = next((r for r in results if r["code"] == scenario), None)
        if result is None:
            raise ValueError("Select a scenario from this saved solve.")
    def date(value, default):
        if not value:
            return default
        try:
            parsed = datetime.fromisoformat(value)
        except (TypeError, ValueError) as exc:
            raise ValueError("Use a valid local date/time at hourly resolution.") from exc
        if parsed.tzinfo or parsed.minute or parsed.second or parsed.microsecond:
            raise ValueError("Use timezone-free, whole-hour date/times.")
        return parsed
    start = date(start, datetime(int(planning["end_year"]), 1, 1))
    end = date(end, min(start + timedelta(hours=167), last))
    if not first <= start <= end <= last:
        raise ValueError(f"Select an ordered period within {first.isoformat()} through {last.isoformat()} (explicit forecast horizon).")
    file = folder / f"dispatch_{result['code']}.csv"
    if not file.is_file():
        raise ValueError("This saved run has no hourly dispatch CSV. Solve again to create it.")
    names = {key: name for key, name in scenario_inputs.TECHNOLOGIES}
    eligible = result.get("eligible_technologies")
    generators = [key for key in scenario_inputs.GENERATORS
                  if key in (eligible or result["caps"].get("generators_mw", {}))]
    generators.sort()
    # Every reported trace uses the same bin means so the balance remains additive.
    count = int((end - start).total_seconds() // 3600) + 1
    # Long hourly requests are downsampled to bin means plus the per-bin demand extremes (peaks stay visible);
    # zooming in the UI asks again for the visible window, which is hourly once it is short enough.
    auto_hours = max(1, math.ceil(count / MAX_POINTS))
    def bin_key(stamp, offset):
        if resolution == "hour" and count <= MAX_HOURLY_POINTS:
            return offset
        if resolution == "day":
            return stamp.date()
        if resolution == "month":
            return stamp.year, stamp.month
        return offset // auto_hours

    groups = []
    keys = []
    max_error = 0
    stack_error = 0.0
    plants = committed_plants(folder)
    peaks = forecast_peaks(folder, start, end)
    expected = start
    with file.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        required = {"timestamp", "net_load_mw", "grid", "pv", "charge", "discharge", "gen",
                    "planned_renewable", "optimized_solar", "shortfall"}
        if not required <= set(reader.fieldnames or []):
            raise ValueError("This legacy dispatch lacks renewable source separation; solve again for the interactive view.")
        has_built = "gross_load_mw" in reader.fieldnames
        for row in reader:
            timestamp = datetime.fromisoformat(row["timestamp"])
            if timestamp < start:
                continue
            if timestamp > end:
                break
            if timestamp != expected:
                raise ValueError("Saved hourly dispatch has missing, duplicate or out-of-order timestamps in this period.")
            expected += timedelta(hours=1)
            def value(key):
                raw = float(row.get(key, 0))
                if not math.isfinite(raw):
                    raise ValueError(f"Nonfinite saved dispatch value: {key}.")
                return raw
            grid, planned, solar = value("grid"), value("planned_renewable"), value("optimized_solar")
            surplus_used = value("pv") - solar
            planned_direct = planned - surplus_used
            demand = value("net_load_mw") + planned_direct
            extra = demand - grid - planned
            microgrid_net = solar + value("gen") + value("discharge") - value("charge")
            error = abs(extra - microgrid_net - value("shortfall"))
            max_error = max(max_error, error)
            values = dict(demand=demand, grid=grid, planned=planned, solar=solar,
                          discharge=value("discharge"), charging=-value("charge"),
                          unserved=value("shortfall"), extra=extra, microgrid_net=microgrid_net,
                          **{"gen_" + key: value("gen_" + key) for key in generators})
            if has_built:
                built = value("gross_load_mw")
                values["built"] = built
                values["efficiency"] = built - demand
                used = {"solar": value("planned_solar_used"), "wind": value("planned_wind_used")}
                if used["solar"] + used["wind"] < 1e-9:
                    # The saved split is empty on some runs: share the used energy by effective capacity.
                    used = {kind: planned * (1 if kind == "solar" else 0) for kind in used}
                    if not any(p["kind"] == "solar" for p in plants):
                        used = {"solar": 0.0, "wind": planned}
                weight = {kind: sum(plant_weight(p, timestamp) for p in plants if p["kind"] == kind) for kind in used}
                assigned = 0.0
                for p in plants:
                    share = used[p["kind"]] * plant_weight(p, timestamp) / weight[p["kind"]] if weight[p["kind"]] > 0 else 0.0
                    values[p["key"]] = share
                    assigned += share
                values["planned_other"] = planned - assigned
                peak = peaks.get(timestamp, built) if peaks else built
            groups_soc = value("soc") if "soc" in row else 0.0
            bin_id = bin_key(timestamp, int((timestamp - start).total_seconds() // 3600))
            if not groups or keys[-1] != bin_id:
                keys.append(bin_id)
                groups.append(dict(timestamp=timestamp.isoformat(timespec="minutes"), hours=0, soc=0.0,
                                   high=demand, low=demand, built_high=-math.inf, built_low=math.inf, built_peak=-math.inf,
                                   values={key: 0.0 for key in values}))
            group = groups[-1]
            group["hours"] += 1
            group["high"] = max(group["high"], demand)
            group["low"] = min(group["low"], demand)
            if has_built:
                group["built_high"] = max(group["built_high"], built)
                group["built_low"] = min(group["built_low"], built)
                group["built_peak"] = max(group["built_peak"], peak)
                stack = (values["efficiency"] + grid + planned + solar + values["discharge"] + values["charging"] + values["unserved"]
                         + sum(values["gen_" + key] for key in generators))
                stack_error = max(stack_error, abs(stack - built))
            group["soc"] += groups_soc
            for key, number in values.items():
                group["values"][key] += number
    if sum(group["hours"] for group in groups) != count:
        raise ValueError("Saved hourly dispatch is incomplete for the selected period.")
    if max_error > 5e-5:
        raise ValueError(f"Saved source separation does not reconcile with demand ({max_error:g} MW); solve again.")
    if has_built and stack_error > 5e-4:
        raise ValueError(f"Whole-system supply layers do not add up to the built load ({stack_error:g} MW); solve again.")
    gen_colors = ["#19866c", "#b75b36", "#7465a3", "#a78c26", "#326caa", "#9e4f7d", "#53812a", "#aa7146"]
    stacked = [
        dict(key="efficiency", label="Efficiency / demand-side load reduction", color="#9fb8c4", full=True, micro=False, area=True),
        *[dict(key=p["key"], label=p["label"], color=p["color"], full=True, micro=False, area=True) for p in plants],
        dict(key="planned_other", label="Other committed supply", color="#b16aaf", full=True, micro=False, area=True),
        dict(key="grid", label="Grid", color="#748d9d", full=True, micro=False, area=True),
        dict(key="solar", label="Microgrid solar (optimized)", color="#d99714", full=True, micro=True, area=True),
        *[dict(key="gen_" + key, label=names[key], color=color, full=True, micro=True, area=True)
          for key, color in zip(generators, gen_colors)],
        dict(key="discharge", label="BESS discharge (pooled)", color="#1887b0", full=True, micro=True, area=True),
        dict(key="charging", label="BESS charging (-)", color="#8163b3", full=True, micro=True, area=True),
        dict(key="unserved", label="Unserved hourly demand", color="#db3939", full=True, micro=True, area=True),
    ]
    traces = [
        *([dict(key="built", label="Built load profile (hourly mean, before efficiency)", color="#0b2533", full=True, micro=False, line=True)]
          if has_built else []),
        dict(key="demand", label="Demand after efficiency (what the optimizer must serve)", color="#d9534f", full=True, micro=False, line=True),
        *(stacked if has_built else [
            dict(key="grid", label="Grid", color="#748d9d", full=True, micro=False),
            dict(key="planned", label="Planned renewable supply used", color="#b16aaf", full=True, micro=False),
            dict(key="solar", label="Microgrid solar", color="#d99714", full=True, micro=True),
            *[dict(key="gen_" + key, label=names[key], color=color, full=True, micro=True)
              for key, color in zip(generators, gen_colors)],
            dict(key="discharge", label="BESS discharge (pooled)", color="#1887b0", full=True, micro=True),
            dict(key="charging", label="BESS charging (-)", color="#8163b3", full=True, micro=True),
            dict(key="unserved", label="Unserved hourly demand", color="#db3939", full=True, micro=True)]),
        *([dict(key="planned", label="Planned renewable supply used", color="#b16aaf", full=False, micro=True)] if has_built else []),
        dict(key="extra", label="Demand minus grid and planned supply", color="#183e4e", full=False, micro=True),
        dict(key="microgrid_net", label="Net microgrid contribution", color="#03a393", full=False, micro=True),
    ]
    if eligible is not None:
        traces = [trace for trace in traces if not (trace["key"] == "grid" and "grid" not in eligible) and
                  not (trace["key"] == "solar" and "pv" not in eligible)]
    # Do not show nonexistent storage or common renewables as technology contributions.
    for key in ("planned", "planned_other", "discharge", "charging", "unserved", *[p["key"] for p in plants]):
        if all(abs(group["values"].get(key, 0)) < 1e-9 for group in groups):
            traces = [trace for trace in traces if trace["key"] != key]
    spans = [group["hours"] for group in groups]
    binned = max(spans) > 1
    series = {trace["key"]: [group["values"][trace["key"]] / group["hours"] for group in groups] for trace in traces}
    if binned:
        series["demand_high"] = [group["high"] for group in groups]
        series["demand_low"] = [group["low"] for group in groups]
        envelope = [dict(key="demand_high", label="Demand after efficiency: highest hour in bin", color="#d9534f", full=True, micro=False, envelope=True),
                    dict(key="demand_low", label="Demand after efficiency: lowest hour in bin", color="#d9534f", full=True, micro=False, envelope=True)]
        if has_built:
            series["built_high"] = [group["built_high"] for group in groups]
            series["built_low"] = [group["built_low"] for group in groups]
            envelope = [dict(key="built_high", label="Built load: highest hour in bin (envelope)", color="#0b2533", full=True, micro=False, envelope=True),
                        dict(key="built_low", label="Built load: lowest hour in bin (envelope)", color="#0b2533", full=True, micro=False, envelope=True), *envelope]
            if peaks:
                series["built_peak"] = [group["built_peak"] for group in groups]
                envelope.insert(1, dict(key="built_peak", label="Built load: forecast upper envelope (project peak)", color="#6b7f8c", full=True, micro=False, envelope=True))
        traces[1 if has_built else 0:1 if has_built else 0] = envelope
    return dict(scenario=result["code"], name=result["name"], best_fully_supplied=result["code"] == best,
                first=first.isoformat(timespec="minutes"), last=last.isoformat(timespec="minutes"),
                start=start.isoformat(timespec="minutes"), end=end.isoformat(timespec="minutes"),
                hours=count, bin_hours=max(spans), resolution=resolution if resolution != "auto" else
                ("hour" if max(spans) == 1 else "bins"), balance_error_mw=max_error, stack_balance_error_mw=stack_error if has_built else None,
                stacked=has_built, envelope=binned, traces=traces,
                downsampled=binned and resolution in ("hour", "auto"),
                export_csv=file.name if file.name in (status.get("files") or []) else None,
                soc_mwh=[group["soc"] / group["hours"] for group in groups],
                bess_audit=bess_audit(file, result, config),
                timestamps=[group["timestamp"] for group in groups], counts=[group["hours"] for group in groups],
                series=series,
                note="Whole-hour local-clock dispatch. End hour included. Built load profile = the forecast you built, before any efficiency or generation netting; the stacked areas add up to it hour by hour (efficiency / demand-side reduction + existing and planned plants by their own profiles + grid + microgrid supply + BESS discharge - charging + unserved). The optimizer is given the built load net of efficiency, existing and planned generation (demand after efficiency less committed supply). Long periods show the mean MW of each bin for the stacked supply and the built load; the thin envelope lines show the highest and lowest hourly built load inside each bin (project peaks are visible there), and zooming in loads the true hourly values. "
                     "Daily, monthly and long-period bins show the arithmetic mean MW of their hours. Demand after efficiency = built load less the incremental efficiency measures. "
                     "Extra demand = demand after efficiency minus actual grid imports and all used planned renewable supply. "
                     "Net microgrid = additional solar + generators + discharge - charging. Negative residuals represent net charging support, not export. "
                     "Storage includes committed and optimized BESS in one pool; its source attribution cannot be separated. "
                     "Hourly means do not show within-hour peak-only shortfalls. No new solve or input repricing.")
