"""Incremental NPV, IRR and payback for every scenario against a chosen reference case.

Route: GET /api/x/economics?run_id=&reference=&residual=0|1

Cash flows are nominal USD, year 0 = investment at the start of the appraisal, years 1..N = end of each appraisal
year, discounted at the saved nominal discount rate (the same convention as the optimizer's NPC).

Two bases are reported for every scenario:
  net        year 0 = (reference capex + grid upgrade) - (scenario capex + grid upgrade), so an avoided upgrade is
             credited as an up-front benefit; years 1..N = reference cash cost - scenario cash cost (opex, fuel,
             grid, carbon, replacements). NPV(net) = NPC(reference) - NPC(scenario) when residual value is excluded.
  operating  year 0 = -(scenario capex + grid upgrade); years 1..N as above. The reference's avoided capex is NOT
             credited, so this answers "do the operating savings repay the money I put in?".
Optional residual value (saved by the model as a present value at the discount rate) is added in year N.
"""

import json
import re

import numpy as np
from scipy.optimize import brentq

import extensions

SERVED_TOL = 5e-5
LOG_LO, LOG_HI, GRID_POINTS = np.log(.001), np.log(1001), 2001


def npv(cashflows, rate):
    values = np.asarray(cashflows, dtype=float)
    return float(np.sum(values / (1 + rate) ** np.arange(len(values))))


def solve_irr(cashflows):
    """Return (irr or None, explanation). IRR is a fraction, searched over -99.9%..100,000%."""
    values = np.asarray(cashflows, dtype=float)
    nonzero = values[np.abs(values) > 1e-7]
    if not len(nonzero):
        return None, "No cash flows: no investment and no savings."
    if nonzero[0] > 0:
        if np.all(nonzero > 0):
            return None, ("No additional investment: the scenario costs less up front than the reference and saves money in "
                          "every year, so a return on investment does not apply (IRR is not defined).")
        return None, "Cash flows start with a benefit, not an investment; a conventional IRR is not defined."
    if np.all(nonzero < 0):
        return None, "No sign change: the investment never pays back (savings are never positive), so IRR does not exist."
    f = lambda x: float(np.sum(values * np.exp(-x * np.arange(len(values)))))
    grid = np.linspace(LOG_LO, LOG_HI, GRID_POINTS)
    fx = np.array([f(x) for x in grid])
    roots = []
    for i in range(len(grid) - 1):
        if fx[i] == 0:
            roots.append(grid[i])
        elif fx[i] * fx[i + 1] < 0:
            roots.append(brentq(f, grid[i], grid[i + 1], xtol=1e-13))
    roots = sorted(set(round(float(np.expm1(r)), 10) for r in roots))
    if not roots:
        return None, "No rate between -99.9% and 100,000% sets NPV to zero; IRR not found."
    note = ""
    if len(roots) > 1:
        note = "Multiple IRRs (" + ", ".join(f"{100 * r:,.2f}%" for r in roots[:4]) + "); lowest reported."
    return roots[0], note


def payback(cashflows, rate=0.0):
    """Years until the cumulative (discounted) cash flow becomes and stays non-negative, interpolated linearly.

    Returns (years or None, explanation)."""
    values = np.asarray(cashflows, dtype=float) / (1 + rate) ** np.arange(len(cashflows))
    cumulative = np.cumsum(values)
    negative = np.flatnonzero(cumulative < -1e-7)
    if not len(negative):
        return 0.0, "No net outlay: nothing to pay back."
    last = int(negative[-1])
    if last >= len(values) - 1:
        return None, (f"Not within the {len(values) - 1}-year horizon: cumulative"
                      f"{' discounted' if rate else ''} savings reach {cumulative[-1]:,.0f} against the investment.")
    return float(last + -cumulative[last] / values[last + 1]), ""


def metrics(cashflows, discount):
    irr, irr_note = solve_irr(cashflows)
    simple, simple_note = payback(cashflows)
    disc, disc_note = payback(cashflows, discount)
    discounted = np.asarray(cashflows, dtype=float) / (1 + discount) ** np.arange(len(cashflows))
    return dict(cashflows=[float(v) for v in cashflows], discounted=[float(v) for v in discounted],
                cumulative=[float(v) for v in np.cumsum(cashflows)],
                cumulative_discounted=[float(v) for v in np.cumsum(discounted)],
                npv=npv(cashflows, discount), irr=irr, irr_note=irr_note,
                simple_payback_years=simple, simple_payback_note=simple_note,
                discounted_payback_years=disc, discounted_payback_note=disc_note)


def is_adequate(result):
    a = result["adequacy"]
    return not a["unserved_hours"] and a.get("stress_unserved_mwh", 0) <= SERVED_TOL


def evaluate(results, values, reference_code=None, include_residual=False):
    """Pure computation on saved result dictionaries (shape of result_<code>.json)."""
    codes = [r["code"] for r in results]
    discount, inflation = float(values["discount"]), float(values.get("inflation", 0))
    fallback = reference_code not in codes
    if fallback:
        reference_code = "R0" if "R0" in codes else codes[0]
    ref = next(r for r in results if r["code"] == reference_code)
    ref_econ = ref["economics"]
    horizon = len(ref_econ["annual"])
    start_year = int(values.get("start_year", ref_econ["annual"][0].get("year", 1) if horizon else 1))
    warnings = []
    if fallback and "R0" not in codes:
        warnings.append(f"No grid-only reference scenario is solved; comparisons use {reference_code} as the baseline.")
    if not is_adequate(ref):
        warnings.append(f"Reference {reference_code} does not serve all load; savings versus it are not like-for-like.")

    def own_capex(e):
        return float(e["capex"]) + float(e.get("upgrade_pv") or 0)

    def residual(e):
        return float(e.get("residual_value_pv") or 0) * (1 + discount) ** horizon if include_residual else 0.0

    def cash(a):
        return float(a.get("total_cash_cost", a["net_opex"]))

    def co2e(e):
        """Appraisal-horizon net CO2e (t) after the useful-heat credit; None unless emission factors are confirmed."""
        values_t = [a.get("net_co2e_after_heat_credit_t") for a in e["annual"]]
        return None if any(v is None for v in values_t) else float(sum(values_t))

    ref_co2e = co2e(ref_econ)
    rows = []
    for r in results:
        e = r["economics"]
        served_pv = sum(a["served_mwh"] / (1 + discount) ** (i + 1) for i, a in enumerate(e["annual"]))
        row = dict(code=r["code"], name=r["name"], is_reference=r["code"] == reference_code, adequate=is_adequate(r),
                   npc=float(e["npc"]), lcoe=e["npc"] / served_pv if served_pv > 1e-9 else None,
                   unserved_mwh=float(r["adequacy"].get("unserved_mwh") or 0),
                   unserved_hours=int(r["adequacy"].get("unserved_hours") or 0),
                   capex=own_capex(e), co2e_t=co2e(e), co2e_avoided_t=None, warnings=[], status="ok", reason="")
        if row["is_reference"]:
            row.update(status="reference", reason="Reference case: all incremental metrics are measured against it.")
        else:
            if len(e["annual"]) != horizon:
                row.update(status="unavailable", reason="Appraisal horizon differs from the reference.")
            else:
                savings = [cash(ra) - cash(a) for ra, a in zip(ref_econ["annual"], e["annual"])]
                salvage = residual(e) - residual(ref_econ)
                tail = [0.0] * (horizon - 1) + [salvage]
                investment = own_capex(e) - own_capex(ref_econ)
                flows = [savings[i] + tail[i] for i in range(horizon)]
                row["investment"] = investment
                row["upfront_saving"] = -investment if investment < 0 else 0.0
                row["annual_savings"] = savings
                if ref_co2e is not None and row["co2e_t"] is not None:
                    row["co2e_avoided_t"] = ref_co2e - row["co2e_t"]
                row["net"] = metrics([-investment, *flows], discount)
                row["operating"] = metrics([-own_capex(e), *flows], discount)
                if not include_residual:
                    gap = row["net"]["npv"] - (float(ref_econ["npc"]) - float(e["npc"]))
                    row["npc_check_usd"] = gap
                if not row["adequate"]:
                    row["warnings"].append(
                        f"Not equivalent service: {row['unserved_mwh']:,.1f} MWh unserved in {row['unserved_hours']:,} h; "
                        "part of the saving comes from unmet demand. Metrics are shown for information only.")
        rows.append(row)
    years = [start_year - 1 + i for i in range(horizon + 1)]
    return dict(reference=reference_code, reference_name=ref["name"], discount=discount, inflation=inflation,
                horizon_years=horizon, calendar_years=years, include_residual=include_residual,
                carbon_available=ref_co2e is not None,
                grid_emissions_t_mwh=float(values["grid_emissions_t_mwh"]) if "grid_emissions_t_mwh" in values else None,
                scenarios=rows, warnings=warnings, how=explanation(reference_code, discount, inflation, horizon,
                                                                   start_year, include_residual))


def explanation(reference, discount, inflation, horizon, start_year, residual):
    return [
        f"Reference case: {reference}. Every other scenario is compared with it; the reference itself shows '-' (reference case).",
        f"Cash flows are nominal USD. Year 0 = investment ({start_year - 1}); years 1..{horizon} = {start_year}..{start_year + horizon - 1} year-end.",
        "Savings(t) = reference cash cost(t) - scenario cash cost(t); cash cost = grid + fixed/variable O&M + fuel + carbon "
        "+ replacements - heat credit.",
        "Net basis: CF0 = (ref capex + ref upgrade) - (scenario capex + scenario upgrade). An avoided grid upgrade is a benefit in year 0.",
        "Operating basis: CF0 = -(scenario capex + upgrade): the reference's avoided capex is not credited.",
        f"NPV = sum CF(t) / (1 + {discount:.4g})^t, discount rate {100 * discount:.4g}% (saved nominal rate; "
        f"costs escalate at {100 * inflation:.4g}% inflation inside the cash flows).",
        "IRR = rate r with sum CF(t) / (1 + r)^t = 0, found by bracketing sign changes of NPV(r) between -99.9% and "
        "100,000%; reported as '-' with the reason when there is no investment, no sign change or no root.",
        "Simple payback = first time cumulative CF stays >= 0 (linear interpolation within the year). "
        "Discounted payback does the same on discounted CF. 'Not within horizon' if it does not happen by the last year.",
        "Residual value " + ("is included as a year-" + str(horizon) + " inflow." if residual else
                             "is excluded (consistent with NPC); tick 'Include residual value' to add it in the last year."),
        "NPC and LCOE are standalone and do not depend on the reference. LCOE = NPC / discounted served MWh: a levelized "
        "nominal $/MWh for the whole supply system (grid imports, upgrades and all assets), not a stand-alone plant LCOE.",
        "CO2e = horizon total of grid + generator + hydrogen-upstream + operational emissions less the useful-heat boiler credit, "
        "using the saved constant emission factors (no embodied or lifecycle emissions). Any carbon price is already inside "
        "cash cost. CO2e avoided = reference CO2e - scenario CO2e; shown only when emission factors are confirmed.",
    ]


def load_run(folder):
    summary = json.loads((folder / "summary.json").read_text(encoding="utf-8"))
    results = []
    for item in summary["results"]:
        code = item["code"]
        path = folder / f"result_{code}.json"
        results.append(json.loads(path.read_text(encoding="utf-8")) if re.fullmatch(r"[A-Za-z0-9_]+", code) and path.is_file() else item)
    config = json.loads((folder / "run_configuration.json").read_text(encoding="utf-8"))["request"]
    return results, config


def for_run(folder, reference=None, include_residual=False):
    results, config = load_run(folder)
    reference = reference or config.get("comparison_reference") or None
    out = evaluate(results, config["values"], reference, include_residual)
    out["reference_options"] = [dict(code=r["code"], name=r["name"], adequate=is_adequate(r)) for r in results]
    out["recommended_code"] = recommended_code(folder, results)
    return out


def recommended_code(folder, results):
    """Recommended scenario of the run: the same decision the Solve and Summary pages show (workflow.rank)."""
    import report
    import workflow
    code = workflow.recommendation(folder, results)["code"]
    if code not in [r["code"] for r in results]:
        code = report.pick_best({r["code"]: r for r in results})[0]
    return code


def flat_rows(data):
    """Compact per-scenario record for summaries and reports (net basis)."""
    rows = []
    for s in data["scenarios"]:
        net, op = s.get("net"), s.get("operating")
        rows.append(dict(code=s["code"], name=s["name"], status=s["status"], reason=s["reason"],
                         adequate=s["adequate"], npc=s["npc"], lcoe=s["lcoe"], investment=s.get("investment"),
                         co2e_t=s["co2e_t"], co2e_avoided_t=s["co2e_avoided_t"],
                         npv=net and net["npv"], irr=net and net["irr"], irr_note=net and net["irr_note"],
                         simple_payback_years=net and net["simple_payback_years"],
                         simple_payback_note=net and net["simple_payback_note"],
                         discounted_payback_years=net and net["discounted_payback_years"],
                         op_npv=op and op["npv"], op_irr=op and op["irr"], op_irr_note=op and op["irr_note"],
                         op_simple_payback_years=op and op["simple_payback_years"],
                         op_simple_payback_note=op and op["simple_payback_note"],
                         op_discounted_payback_years=op and op["discounted_payback_years"],
                         warnings=s["warnings"]))
    return rows


def handler(query):
    folder = extensions.run_folder((query.get("run_id") or [""])[0])
    reference = (query.get("reference") or [""])[0] or None
    include_residual = (query.get("residual") or ["0"])[0] in ("1", "true")
    if not (folder / "summary.json").is_file():
        raise ValueError("This run has no saved solve results yet.")
    return for_run(folder, reference, include_residual)


extensions.GET["economics"] = handler
