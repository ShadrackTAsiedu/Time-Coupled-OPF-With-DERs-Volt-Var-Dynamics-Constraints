"""Application validation, exact land constraints and configurable finance."""

import csv
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import numpy as np

import generation_app as app
import optimize_generation_mix as model
import demand_forecasting as forecasting
from test_generation_optimization import small_inputs


class ApplicationTests(unittest.TestCase):
    def test_completed_worker_does_not_block_next_action_during_shutdown(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory) / "job"
            folder.mkdir()
            process = mock.Mock()
            process.poll.return_value = None
            with mock.patch.object(app, "RUNS", Path(directory)), mock.patch.object(app, "JOBS", {"job": process}):
                for state, expected in (("queued", True), ("running", True),
                                        ("complete", False), ("failed", False)):
                    (folder / "status.json").write_text(json.dumps({"state": state}), encoding="utf-8")
                    self.assertEqual(app.active_jobs(), expected)
                process.poll.return_value = 0
                self.assertFalse(app.active_jobs())

    def request(self, **overrides):
        values = {f["key"]: f["default"] for f in app.FIELDS}
        values.update(trajectory_mode="model", baseline=33.34421,
                      microgrid_min_mw=0, microgrid_max_mw=1e12)
        values.update(overrides)
        return app.validate_request(dict(values=values, scenarios=["P1", "CHP"], planned_generation=[]))

    def test_validation_requires_explicit_land_factors(self):
        with self.assertRaisesRegex(ValueError, "positive solar footprint"):
            self.request(solar_land_enabled=True)
        with self.assertRaisesRegex(ValueError, "positive BESS"):
            self.request(bess_land_enabled=True)
        with self.assertRaisesRegex(ValueError, "minimum .* cannot exceed"):
            self.request(microgrid_min_mw=10, microgrid_max_mw=8)
        with self.assertRaisesRegex(ValueError, "Years to target"):
            self.request(target_years=5.5)
        with self.assertRaisesRegex(ValueError, "efficiency cannot exceed"):
            self.request(ng_chp_efficiency=.8)
        with self.assertRaisesRegex(ValueError, "finite number"):
            self.request(grid_limit=float("nan"))

    def test_land_and_grid_limits_are_solver_constraints(self):
        request = self.request(grid_limit=38, solar_land_enabled=True,
                               solar_acres=4, solar_acres_per_mw=2, bess_land_enabled=True,
                               bess_acres=0, bess_acres_per_mw=.1, bess_acres_per_mwh=.02)
        cfg = app.settings_for(request["values"])
        result = model.solve_decomposed(small_inputs(), "LAND", "Test zero BESS land", "ng_chp", settings=cfg)
        self.assertLessEqual(result["caps"]["pv_dc_mw"], 2.00001)
        self.assertLessEqual(result["caps"]["bess_mw"], .00001)
        self.assertLessEqual(result["caps"]["bess_mwh"], .00001)
        self.assertGreater(result["caps"]["generator_mw"], 6)
        self.assertLessEqual(result["validation"]["max_quarter_hour_grid_mw"], 38.00005)

    def test_finance_and_carbon_recalculate_independently(self):
        request = self.request(inflation=.01, discount=.10, ng_fuel_price=10, carbon_price=0)
        cfg = app.settings_for(request["values"])
        data = small_inputs()
        caps = dict(pv_dc_mw=8, bess_mw=0, bess_mwh=0, generator_mw=5)
        dispatch = {k: np.zeros(len(data["load"])) for k in (
            "pv", "charge", "discharge", "soc", "heat", "gen", "grid")}
        dispatch["gen"][:] = 1
        dispatch["grid"] = data["load"] - 1
        econ = model.economics(data, caps, dispatch, "ng", False, cfg)
        self.assertEqual(econ["carbon_pv"], 0)
        self.assertGreater(econ["annual"][0]["direct_gen_co2_t"], 0)
        self.assertAlmostEqual(econ["annual"][0]["discounted_opex"],
                               econ["annual"][0]["net_opex"] / 1.10)
        self.assertAlmostEqual(cfg["technology_parameters"]["ng"]["fuel"],
                               10 * model.MMBTU_PER_MWH / .30)

    def test_grid_peak_column_in_exported_results(self):
        from docx import Document
        from openpyxl import load_workbook
        request = self.request(horizon_years=1)
        cfg = app.settings_for(request["values"])
        data = small_inputs()
        data = {key: value[:12] if key in ("facility", "tou", "fixed") else value[:288]
                for key, value in data.items()}
        result = model.solve_decomposed(data, "R0", "Grid reference", "none",
                                        reference=True, settings=cfg)
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            summary = app.export_results(folder, data, request, cfg, [result], [], [], "Test inputs")
            index = summary["columns"].index("BESS MWh") + 1
            self.assertNotIn("Generator MW", summary["columns"])
            self.assertEqual(summary["columns"][index], "Grid peak import MW")
            self.assertAlmostEqual(summary["rows"][0][index], 44.5)
            workbook = load_workbook(folder / "generation_results.xlsx", read_only=True)
            rows = list(workbook["Costs and capacities"].values)
            self.assertEqual(rows[0][index], "Grid peak import MW")
            self.assertAlmostEqual(rows[1][index], 44.5)
            workbook.close()
            document = Document(folder / "generation_model_and_results.docx")
            self.assertEqual(document.tables[0].rows[0].cells[4].text, "Grid peak import MW")
            self.assertEqual(document.tables[0].rows[1].cells[4].text, "44.500")

    def test_full_profile_shapes_and_forecast(self):
        request = self.request(target_years=5)
        data, _ = app.make_data(request)
        self.assertEqual(len(data["load"]), 87672)
        self.assertEqual(sum(data["years"] == 1), 8784)
        self.assertAlmostEqual(data["qmax"][data["years"] == 4].max(), 45)
        self.assertAlmostEqual(data["qmax"][data["years"] == 9].max(), 45)
        self.assertTrue(np.all(data["qmin"] <= data["load"]))
        self.assertTrue(np.all(data["qmax"] >= data["load"]))

    def test_historical_starting_case_precedes_forecast_without_extra_planning_hours(self):
        from openpyxl import load_workbook
        data, _ = app.make_data(self.request(horizon_years=1))
        historical = data["historical"]
        self.assertEqual(len(historical["load"]), 8760)
        self.assertAlmostEqual(historical["qmax"].max(), model.B)
        self.assertAlmostEqual(historical["load"].sum(), 143958.7480525)
        self.assertEqual(len(data["load"]), 8760)
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            charts = app.write_profile(folder, data)
            self.assertEqual([c["year"] for c in charts], [2026, 2027])
            self.assertTrue(charts[0]["historical"])
            self.assertEqual(charts[0]["growth_factor"], 1)
            self.assertTrue((folder / "load_2026.png").exists())
            book = load_workbook(folder / "hourly_projected_load.xlsx", read_only=True)
            self.assertEqual(book["Historical 2026"].max_row, 8761)
            book.close()

    def test_csv_rejects_gaps_nonfinite_and_invalid_columns(self):
        for text in ("timestamp,watts\n2027-01-01 00:00:00,1",
                     "timestamp,load_mw\n2027-01-01 00:00:00,nan",
                     "timestamp,load_mw\n2027-01-01 00:00:00,10"):
            with self.assertRaises(ValueError):
                app.read_import(text, "historical")
        stream = io.StringIO()
        writer = csv.writer(stream)
        writer.writerow(["timestamp", "load_mw"])
        from datetime import datetime, timedelta
        for i in range(8760):
            writer.writerow([str(datetime(2025, 1, 1) + timedelta(hours=i)), 10])
        rows = app.read_import(stream.getvalue(), "historical")
        self.assertEqual(len(rows), 8760)
        request = self.request()
        request["upload_csv"] = stream.getvalue()
        data, description = app.make_data(request)
        self.assertIn("Uploaded", description)
        self.assertAlmostEqual(data["load"][-1], 45)

    def test_shortfall_is_reported_and_reference_is_upgraded_grid_only(self):
        cfg = app.settings_for(self.request(grid_limit=0, reference_grid_limit=50)["values"])
        cfg.update(pv_max=0, bess_power_max=0, bess_energy_max=0)
        data = small_inputs()
        result = model.solve_decomposed(data, "SHED", "No supply", "none", settings=cfg)
        self.assertAlmostEqual(result["economics"]["unserved_mwh"], data["load"].sum(), places=3)
        self.assertEqual(result["adequacy"]["unserved_hours"], len(data["load"]))
        self.assertEqual(result["adequacy"]["status"], "UNSERVED LOAD")
        self.assertLess(result["economics"]["npc"], 1e8)  # Numerical priority is not an expenditure.
        self.assertLess(result["validation"]["hourly_balance_error_mw"], 5e-5)
        self.assertLess(result["validation"]["max_quarter_hour_grid_mw"], 5e-5)
        reference = model.solve_decomposed(data, "UP", "Grid only", "none", reference=True, settings=cfg)
        self.assertEqual(reference["caps"]["pv_dc_mw"], 0)
        self.assertEqual(reference["adequacy"]["unserved_hours"], 0)
        self.assertAlmostEqual(reference["adequacy"]["reference_grid_limit_mw"], max(50, data["qmax"].max()))
        self.assertAlmostEqual(reference["economics"]["upgrade_pv"], 70e6)
        self.assertTrue(np.allclose(reference["dispatch"]["grid"], data["load"]))

    def test_forecast_grows_every_hour_for_every_method(self):
        for method, _ in forecasting.METHODS:
            with self.subTest(method=method):
                request = self.request(horizon_years=5, target_years=5,
                                       shape_method="replay", forecast_method=method)
                data, _ = app.make_data(request)
                for yi in (0, 4):
                    sel = data["years"] == yi
                    peak = forecasting.forecast_peaks(yi + 1, 33.34421, 45, 5, method)
                    ratio = peak / 33.34421
                    self.assertTrue(np.allclose(data["load"][sel], data["baseline_load"][sel] * ratio))
                self.assertGreater(data["load"][data["years"] == 4].mean(),
                                   data["load"][data["years"] == 0].mean())
                self.assertAlmostEqual(data["qmax"][data["years"] == 4].max(), 45)
                self.assertEqual(len(data["load"]), 43824)

    def test_learned_shape_aligns_future_weekdays(self):
        from datetime import datetime, timedelta
        history = []
        for i in range(8760):
            d = datetime(2025, 1, 1) + timedelta(hours=i)
            value = 20.0 if d.weekday() < 5 else 10.0
            history.append((d, dict(load_mw=value, load_max_mw=value, load_min_mw=value)))
        dates = forecasting.planning_dates(2027, 1)
        learned, audit = forecasting.learn_shape(history, dates, "learned")
        self.assertEqual(audit["template_groups"], 12 * 7 * 24)
        for d, r in zip(dates, learned):
            self.assertEqual(r["load_mw"], 20 if d.weekday() < 5 else 10)

    def test_horizon_controls_inputs_cost_years_and_import_validation(self):
        for horizon in (1, 5, 15):
            request = self.request(horizon_years=horizon)
            data, _ = app.make_data(request)
            self.assertEqual(len(data["load"]), len(forecasting.planning_dates(2027, horizon)))
            self.assertEqual(len(data["facility"]), horizon * 12)
            self.assertEqual(data["dates"][-1].year, 2026 + horizon)
        data = small_inputs()
        # A short, complete set of 12 monthly representative days exercises dynamic LP accounting.
        data = {key: value[:12] if key in ("facility", "tou", "fixed") else value[:288]
                for key, value in data.items()}
        cfg = app.settings_for(self.request(horizon_years=1)["values"])
        result = model.solve_decomposed(data, "YEAR", "One year", "none", reference=True, settings=cfg)
        self.assertEqual(len(result["economics"]["annual"]), 1)
        self.assertEqual(result["economics"]["annual"][0]["year"], 2027)
        with self.assertRaisesRegex(ValueError, "8,760"):
            app.read_import("timestamp,load_mw\n2027-01-01 00:00:00,10", "projected", 1)

    def test_severe_grid_reduction_and_stress_do_not_fail(self):
        cfg = app.settings_for(self.request(grid_limit=.1)["values"])
        cfg.update(pv_max=0, bess_power_max=0, bess_energy_max=0)
        data = small_inputs()
        result = model.solve_decomposed(data, "LOW", "Constrained PV+BESS", "none",
                                        require_stress=True, settings=cfg)
        self.assertGreater(result["adequacy"]["unserved_mwh"], 0)
        self.assertGreater(result["adequacy"]["stress_unserved_mwh"], 0)
        self.assertLessEqual(result["validation"]["max_quarter_hour_grid_mw"], .10005)


if __name__ == "__main__":
    unittest.main()
