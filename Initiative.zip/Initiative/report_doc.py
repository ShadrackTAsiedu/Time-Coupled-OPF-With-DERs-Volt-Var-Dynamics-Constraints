"""Professional project report assembly (cover, document control, numbered sections, appendices).

report.py supplies the data helpers, charts and per-topic sections; this module owns the document structure:
sanitised author metadata, section selection, automatic numbering of headings, figures and tables, cross-references,
the contents/figure/table lists and the A4 print stylesheet. Every user-supplied string is HTML-escaped (or CSS-escaped
for the running header and footer) before it reaches the document.
"""

import datetime
import html
import re

import currency
import report as R
import report_charts as C
import report_exec as X

esc = R.esc

PURPOSES = ["For information", "For review", "For approval", "For construction"]
SHORT_FIELDS = [("project_name", 120), ("project_number", 60), ("client_name", 120), ("client_contact", 160),
                ("consulting_company", 120), ("prepared_by", 80), ("reviewed_by", 80), ("approved_by", 80),
                ("document_number", 60), ("revision", 20), ("site", 160), ("revision_description", 160)]
SECTION_KEYS = [("exec", "Executive summary"), ("intro", "Introduction and scope"), ("data", "Data and demand forecast"),
                ("basis", "Basis of design and assumptions"), ("method", "Methodology"),
                ("results", "Scenario results and comparison"), ("solution", "Recommended solution"),
                ("economic", "Economic analysis"), ("sensitivity", "Sensitivity and uncertainty"),
                ("reliability", "Reliability and resilience"), ("powerflow", "Network and power-flow verification"),
                ("design", "Design summary"), ("risk", "Risks and compliance summary"),
                ("conclusions", "Conclusions and recommendations"), ("app_inputs", "Appendix: input parameters"),
                ("app_equations", "Appendix: key equations"),
                ("app_quality", "Appendix: data quality and cleaning log"), ("app_dispatch", "Appendix: dispatch charts"),
                ("app_glossary", "Appendix: glossary and abbreviations"), ("app_refs", "Appendix: references")]
LOGO_RE = re.compile(r"^data:image/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/=]+$")
CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
DEFAULT_CONFIDENTIALITY = ("This document contains confidential information prepared for the named client. "
                           "It must not be copied or disclosed to third parties without written consent.")


def clean_meta(raw):
    raw = raw if isinstance(raw, dict) else {}

    def text(key, limit, multiline=False):
        value = CONTROL_RE.sub("", str(raw.get(key) or "")).replace("\r\n", "\n").replace("\r", "\n")
        if not multiline:
            value = " ".join(value.split())
        return value.strip()[:limit]

    meta = {key: text(key, limit) for key, limit in SHORT_FIELDS}
    meta["notes"] = text("notes", 6000, True)
    meta["confidentiality"] = text("confidentiality", 800) or DEFAULT_CONFIDENTIALITY
    purpose = text("issue_purpose", 40)
    meta["issue_purpose"] = purpose if purpose in PURPOSES else ""
    try:
        meta["date"] = datetime.date.fromisoformat(text("date", 10)).isoformat()
    except ValueError:
        meta["date"] = datetime.date.today().isoformat()
    logo = str(raw.get("logo") or "").strip()
    meta["logo"] = logo if len(logo) <= 2_000_000 and LOGO_RE.match(logo) else ""
    meta["scenario"] = text("scenario", 40)
    meta["detail"] = text("detail", 20) if text("detail", 20) in ("equivalent", "detailed") else "equivalent"
    selected = raw.get("sections")
    valid = [k for k, _ in SECTION_KEYS]
    chosen = [k for k in valid if k in selected] if isinstance(selected, list) else []
    meta["sections"] = chosen or valid
    return meta


def rev_label(meta):
    return f"Rev {meta['revision']}" if meta["revision"] else ""


def round_text(html_text):
    """Limit every decimal figure in visible text to four decimal places."""
    def fix(match):
        value = f"{float(match.group(0)):.4f}".rstrip("0").rstrip(".")
        return value or "0"

    def text_node(match):
        return ">" + re.sub(r"(?<![\w.])-?\d+\.\d{5,}(?![\d])", fix, match.group(1)) + "<"
    return re.sub(r">([^<>]+)<", text_node, html_text)


def css_string(value):
    """Safe content for a CSS string literal (running header and footer)."""
    return re.sub(r"[\\\"<>&\n\r]", " ", value)[:90]


STYLE = """
*{box-sizing:border-box}
html{-webkit-print-color-adjust:exact;print-color-adjust:exact}
body{font:10.5pt/1.5 Calibri,"Segoe UI",Arial,sans-serif;color:#111a24;margin:0;background:#e9edf2}
main{max-width:210mm;margin:0 auto;background:#fff;padding:18mm 20mm 20mm}
h1,h2,h3,h4{color:#0b2a3c;font-family:Calibri,"Segoe UI",Arial,sans-serif;line-height:1.25}
h2{font-size:19pt;border-bottom:2.5px solid #00827c;padding-bottom:4px;margin:0 0 12px}
h3{font-size:13pt;margin:20px 0 6px}h4{font-size:11pt;margin:14px 0 4px;color:#27495c}
p,li{max-width:100%;text-align:left}.muted{color:#4a5764}.small{font-size:9pt}
section.doc{break-before:page}section.doc:first-of-type{break-before:auto}
.num{display:inline-block;min-width:2.4em}
table{border-collapse:collapse;width:100%;margin:6px 0 14px;font-size:9pt}
caption{caption-side:top;text-align:left;font-weight:600;font-size:9pt;color:#0b2a3c;padding:2px 0 4px}
th,td{border:1px solid #c5cdd6;padding:3px 6px;text-align:left;vertical-align:top}
th{background:#0b2a3c;color:#fff;font-weight:600}tbody tr:nth-child(even) td{background:#f4f7fa}
td.n,th.n{text-align:right;font-variant-numeric:tabular-nums}
table.wide{font-size:7.5pt}table.wide th,table.wide td{padding:2px 3px}td:first-child{white-space:nowrap}
tr.best td{background:#d9f1e4!important;font-weight:600}
thead{display:table-header-group}tr{break-inside:avoid}
.badge{display:inline-block;border-radius:9px;padding:0 8px;font-size:8.5pt;font-weight:600;color:#fff;background:#4a5764;white-space:nowrap}
.badge.good,.badge.pass{background:#1e7a3a}.badge.warn{background:#9a6200}.badge.bad,.badge.fail{background:#b3202f}.badge.best{background:#00695f}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(40mm,1fr));gap:8px;margin:10px 0}
.kpi{border:1px solid #9fb0bf;border-left:4px solid #00827c;padding:6px 10px;break-inside:avoid}.kpi b{display:block;font-size:14pt}.kpi span{font-size:8.5pt;color:#34414d}
.callout{background:#e3f4ec;border-left:5px solid #00695f;padding:8px 14px;margin:10px 0}
.warning{background:#fff1d6;border-left:5px solid #9a6200;padding:6px 14px;margin:10px 0;break-inside:avoid}
.notrun{background:#f1f3f6;border:1px dashed #5d6b78;padding:8px 14px;color:#34414d;margin:10px 0}
svg{max-width:100%;height:auto;margin:4px 0}svg text{font:11px Calibri,"Segoe UI",Arial,sans-serif;fill:#111a24}
svg .axis{stroke:#111a24;stroke-width:1.2}svg .grid{stroke:#c9d1d9;stroke-width:1}
figure{margin:10px 0;break-inside:avoid}figcaption{font-size:9pt;color:#0b2a3c;margin-top:2px}
figure.sld svg{width:100%;height:auto;max-height:215mm;background:#fff;border:1px solid #c5cdd6}
.cover{min-height:255mm;display:flex;flex-direction:column;break-after:page;border-top:12px solid #0b2a3c;padding-top:8mm;position:relative}
.cover:before{content:"";position:absolute;top:-12px;left:0;width:38mm;border-top:12px solid #00827c}
.cover .logo{max-height:22mm;max-width:70mm;margin-bottom:6mm;align-self:flex-start}
.cover .company{font-size:13pt;font-weight:600;color:#27495c}
.cover .eyebrow{letter-spacing:.14em;text-transform:uppercase;color:#00695f;font-weight:700;margin-top:38mm}
.cover h1{font-size:30pt;margin:4mm 0 2mm;color:#0b2a3c}.cover .subtitle{font-size:14pt;color:#27495c;margin-bottom:12mm}
.cover table{font-size:10.5pt;max-width:140mm}.cover th{width:42mm;background:#e6edf3;color:#0b2a3c}.cover td{background:#fff}
.cover .conf{margin-top:auto;border-top:3px solid #00827c;padding-top:4mm;font-size:9pt;color:#34414d}
.frontmatter{break-after:page}.frontmatter h2{font-size:17pt}
.toc-row{display:flex;gap:6px;padding:1px 0;font-size:10pt}.toc-row.l1{font-weight:600;margin-top:5px}.toc-row.l2{padding-left:9mm;font-size:9.5pt}
.toc-row a,.lof-row a{color:#0b2a3c;text-decoration:none}.toc-row .num{min-width:2.6em}.toc-row.app .num{min-width:6em}
.toc-row a,.lof-row a{display:flex;flex:1;gap:6px;align-items:baseline}.toc-row .tx,.lof-row .tx{flex:0 1 auto}
.pg{flex:1;display:flex;align-items:baseline;min-width:2.2em}.pg i{flex:1;border-bottom:1px dotted #7d8b98;margin:0 3px}.pg b{font-weight:inherit;font-variant-numeric:tabular-nums}
.lof-row{font-size:9.5pt;padding:1px 0}
td.eqn{width:44%;font-family:Cambria,"Times New Roman",serif;font-size:10pt}
.sig td{height:9mm}
footer.end{margin-top:12mm;border-top:1px solid #9fb0bf;padding-top:6px;font-size:8.5pt;color:#34414d}
.takeaways{background:#eef6f5;border:1px solid #b7d8d4;border-left:5px solid #00827c;border-radius:3px;padding:8px 14px 6px;margin:2px 0 14px;break-inside:avoid}
.takeaways .tk-title{font-weight:700;color:#00695f;letter-spacing:.06em;text-transform:uppercase;font-size:9pt}
.takeaways ul{margin:4px 0 2px;padding-left:18px}.takeaways li{margin:2px 0}
p.take{margin:1px 0 0;font-size:9pt;color:#34414d}
h3,h4,caption{break-after:avoid}h3+figure,h3+table{break-before:avoid}
.pagebreak{break-after:page}
.decision{background:#0b2a3c;color:#fff;border-radius:4px;padding:10px 16px;margin:0 0 10px}
.decision p{margin:3px 0;color:#e8f0f5}.decision .eyebrow{color:#7fd6cf;letter-spacing:.14em;text-transform:uppercase;font-weight:700;font-size:8.5pt}
.decision .dtitle{font-size:15pt;font-weight:700;margin:2px 0 4px;color:#fff}
.tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:8px 0}
.tile{border:1px solid #c5cdd6;border-top:4px solid #00827c;border-radius:3px;padding:6px 10px;break-inside:avoid;background:#fff}
.tile .tl{display:block;font-size:8.5pt;color:#34414d;text-transform:uppercase;letter-spacing:.04em}.tile b{display:block;font-size:15pt;color:#0b2a3c;margin:1px 0}
.tile .tn{display:block;font-size:8pt;color:#4a5764}
.tile.warn{border-top-color:#9a6200}.tile.fail,.tile.bad{border-top-color:#b3202f}.tile.pass,.tile.good{border-top-color:#1e7a3a}
.chips{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:6px 0}
.chipcard{border:1px solid #c5cdd6;border-radius:3px;padding:6px 10px;break-inside:avoid}.chipcard .cn{font-weight:700;color:#0b2a3c;margin-bottom:3px}
.chipcard .cd{font-size:8.5pt;color:#34414d;margin-top:4px}
.twocol{display:grid;grid-template-columns:1fr 1fr;gap:14px}.twocol h4{margin-top:6px}
@media print{body{background:#fff}main{max-width:none;padding:0}a{color:inherit}}
@media screen and (max-width:760px){table{display:block;overflow-x:auto}figure,svg,img{max-width:100%;height:auto}}
@page{size:A4;margin:20mm 16mm 20mm 16mm}
"""


def page_css(meta, title):
    left = css_string(f"{meta['project_name'] or title}")
    right = css_string(" - ".join(x for x in (meta["document_number"], rev_label(meta), meta["issue_purpose"]) if x))
    foot = css_string(meta["consulting_company"] or "GenStudio report")
    return (f'@page{{@top-left{{content:"{left}";font:8pt Calibri,Arial,sans-serif;color:#34414d}}'
            f'@top-right{{content:"{right}";font:8pt Calibri,Arial,sans-serif;color:#34414d}}'
            f'@bottom-left{{content:"{foot}";font:8pt Calibri,Arial,sans-serif;color:#34414d}}'
            '@bottom-right{content:"Page " counter(page) " of " counter(pages);font:8pt Calibri,Arial,sans-serif;color:#34414d}}'
            "@page:first{@top-left{content:none}@top-right{content:none}@bottom-left{content:none}@bottom-right{content:none}}")


# --------------------------------------------------------------------------- static reference content

STANDARDS = [
    ["IEEE 1547-2018", "Interconnection and interoperability of distributed energy resources with associated electric power systems interfaces",
     "Interconnection requirements for inverter-based and rotating DER connecting at distribution level"],
    ["IEEE 2800-2022", "Interconnection and interoperability of inverter-based resources interconnecting with transmission systems",
     "Ride-through, voltage and frequency response for PV, BESS and wind connected at transmission level"],
    ["IEEE 519-2022", "Harmonic control in electric power systems", "Harmonic limits at the point of common coupling; filter sizing"],
    ["IEC 60076 series", "Power transformers", "Transformer ratings, impedance, temperature rise and short-circuit withstand"],
    ["IEEE C57.12.00", "General requirements for liquid-immersed distribution, power and regulating transformers", "Transformer specification (ANSI practice)"],
    ["ANSI / IEEE C37 series", "Circuit breakers, switchgear, relays and substation equipment", "Switchgear ratings, interrupting duty and protective-relay application"],
    ["NFPA 855", "Installation of stationary energy storage systems", "BESS siting, separation, fire protection and hazard mitigation"],
    ["UL 9540 / UL 9540A", "Energy storage systems and equipment; test method for thermal-runaway fire propagation", "BESS product certification and large-scale fire-test basis"],
    ["IEEE 80-2013", "Guide for safety in AC substation grounding", "Referenced for grounding-grid design (touch and step voltage)"],
    ["NFPA 70 (NEC) / IEEE C2 (NESC)", "National Electrical Code; National Electrical Safety Code", "Installation and safety rules for on-site and utility-side works"],
]

GLOSSARY = [
    ["BESS", "Battery energy storage system"], ["BOM", "Bill of materials"], ["CHP", "Combined heat and power"],
    ["DER", "Distributed energy resource"], ["EUE", "Expected unserved energy"], ["IRR", "Internal rate of return"],
    ["LCOE", "Levelized cost of energy (here: levelized supply cost of served electricity)"], ["LOLE", "Loss-of-load expectation (expected downtime, hours per year)"],
    ["LP / MILP", "Linear program / mixed-integer linear program"], ["N-1", "Loss of any single element with the system still within limits"],
    ["NPC", "Net present cost - discounted lifecycle cash cost"], ["NPV", "Net present value"], ["O&M", "Operation and maintenance (fixed and variable)"],
    ["P50 / P90", "Values not exceeded with 50% / 90% probability"], ["POI", "Point of interconnection"], ["PSS/E", "Power System Simulator for Engineering (network model format)"],
    ["PV", "Photovoltaic"], ["SLD", "Single-line diagram"], ["SOC", "State of charge"], ["VOLL", "Value of lost load"],
]

REFERENCES = [
    "IEEE Std 1547-2018, IEEE Standard for Interconnection and Interoperability of Distributed Energy Resources with Associated Electric Power Systems Interfaces.",
    "IEEE Std 2800-2022, IEEE Standard for Interconnection and Interoperability of Inverter-Based Resources Interconnecting with Associated Transmission Electric Power Systems.",
    "IEEE Std 519-2022, IEEE Standard for Harmonic Control in Electric Power Systems.",
    "IEC 60076 series, Power transformers.",
    "IEEE Std C57.12.00, General Requirements for Liquid-Immersed Distribution, Power, and Regulating Transformers.",
    "IEEE C37 series, Standards for circuit breakers, switchgear and protective relays.",
    "NFPA 855, Standard for the Installation of Stationary Energy Storage Systems.",
    "ANSI/CAN/UL 9540, Standard for Energy Storage Systems and Equipment; UL 9540A, Test Method for Evaluating Thermal Runaway Fire Propagation in Battery Energy Storage Systems.",
    "IEEE Std 80-2013, IEEE Guide for Safety in AC Substation Grounding.",
    "HiGHS linear and mixed-integer optimization solver (https://highs.dev), as identified in the run configuration.",
    "GenStudio mathematical optimization model documentation and saved run configuration (run_configuration.json) for this study.",
]


# --------------------------------------------------------------------------- sections

def ref(key):
    return f"@@sec:{key}@@"


def intro_section(run, code, meta, best, feasible):
    r = run["results"][code]
    planning = run["config"].get("planning") or {}
    out = ["<h3>Background and purpose</h3>",
           f"<p>This report presents the results of a least-cost generation planning study"
           + (f" for {esc(meta['client_name'])}" if meta["client_name"] else "")
           + (f" at {esc(meta['site'])}" if meta["site"] else "")
           + f". It documents the demand forecast, the optimization model, the evaluated scenarios, the recommended supply solution, "
             "its design basis, economics, sensitivity, reliability and network verification.</p>"]
    if meta["notes"]:
        out.append("<h3>Project notes and scope statement</h3>" + "".join(f"<p>{esc(p).replace(chr(10), '<br>')}</p>" for p in re.split(r"\n\s*\n", meta["notes"]) if p.strip()))
    out.append("<h3>Objectives</h3>" + R.bullets([
        "Forecast the hourly electrical demand over the planning horizon from the supplied load and growth information.",
        "Determine the lowest net-present-cost mix of grid supply, solar PV, battery storage, wind and thermal or hydrogen generation that serves all demand.",
        "Compare all configured scenarios on a like-for-like service basis.",
        "Test the recommended solution for economic risk, reliability and network adequacy, and describe its construction-oriented design.",
    ]))
    out.append("<h3>Scope and study boundary</h3>" + R.bullets([
        f"Planning horizon {planning.get('start_year', '')}-{planning.get('end_year', '')} ({planning.get('horizon_years', '')} years); appraisal period {planning.get('appraisal_years', '')} years.",
        f"{len(run['results'])} scenario(s) evaluated: {', '.join(run['results'])}.",
        "The decision boundary covers new optimized equipment and grid supply; existing and planned projects are deducted from demand and not costed.",
        "Results are planning-level; they are not an investment certification or a substitute for a full network or protection study.",
    ]))
    out.append("<h3>Report structure</h3><p>Sections follow the study workflow: data and demand forecast (" + ref("data") + "), basis of design (" + ref("basis") +
               "), methodology (" + ref("method") + "), scenario results (" + ref("results") + "), the recommended solution (" + ref("solution") +
               "), economic (" + ref("economic") + "), sensitivity (" + ref("sensitivity") + "), reliability (" + ref("reliability") + ") and power-flow (" + ref("powerflow") +
               ") assessments, a design summary (" + ref("design") + "), risks (" + ref("risk") + ") and conclusions (" + ref("conclusions") +
               "). Appendices hold inputs, equations, data-quality records, dispatch charts, a glossary and references.</p>")
    return "".join(out)


def basis_section(run, code):
    out = ["<h3>Load forecast</h3>", R.demand_basis(run, code).replace("<h3>", "<h4>").replace("</h3>", "</h4>"),
           "<h3>Existing and planned generation</h3>", R.planned_section(run),
           "<h3>Tariff and financial assumptions</h3>", R.tariff_financial(run).replace("<h3>", "<h4>").replace("</h3>", "</h4>"),
           "<h3>Technology cost inputs</h3>", R.tech_inputs(run, code),
           "<h3>Constraints and operating switches</h3>", R.constraints(run),
           "<h3>Codes and standards referenced</h3>",
           "<p>The following standards are referenced as the design basis. They are cited for guidance; compliance is to be confirmed during detailed design and utility interconnection review.</p>",
           R.table(["Standard", "Title", "Application"], STANDARDS)]
    return "".join(out)


def method_section(run, code):
    r = run["results"][code]
    cfg = run["config"]
    solver = (r.get("solver") or {}).get("label") or cfg.get("solver_version") or "HiGHS"
    out = ["<h3>Demand forecast</h3><p>Hourly demand is built from the uploaded history and growth settings, or from an imported forecast when one is supplied. "
           "Annual peak targets (client milestones) control the trajectory; existing efficiency programs and planned renewable projects are deducted to give net demand for dispatch. "
           "The chronological hourly profile is retained for every year so that peaks, ramps and seasonal patterns are preserved.</p>",
           "<h3>Optimization formulation</h3>",
           "<p><strong>Objective.</strong> Minimize lifecycle net present cost: upfront capital (including connection works) plus the discounted sum of grid energy and demand charges, fuel, "
           "variable and fixed O&amp;M, carbon cost, equipment replacements and upgrade O&amp;M, less any heat credit.</p>",
           "<p><strong>Decision variables.</strong> Installed capacity of each eligible technology (capacity master) and hourly dispatch of grid import, solar, wind, generators, battery charge/discharge and state of charge, and unserved energy.</p>",
           "<p><strong>Principal constraints.</strong></p>",
           R.bullets(["Hourly power balance: supply from all sources plus unserved energy equals net demand.",
                      "Grid import limited by the connection capacity; optional export limit.",
                      "Solar and wind output limited by the per-MW resource profile, derate and degradation.",
                      "Battery power, duration, round-trip efficiency, state-of-charge window and daily cycle limits; monthly cyclic state of charge.",
                      "Generator capacity, availability and (where enabled) emissions limit; microgrid minimum and maximum size; land availability.",
                      "Optional reactive-power and technology-specific constraints when enabled in the inputs."]),
           "<p><strong>How it is solved.</strong> Capacity is decided first, then each month of hourly operation is solved and fed back to improve the capacity decision; "
           "this keeps long multi-year studies tractable. Shortage is allowed at a high numerical price so that infeasible cases are reported rather than hidden; "
           "that price is not a cash cost.</p>",
           f"<h3>Solver and validation</h3><p>Solver: {esc(solver)}. Every solution is independently checked for hourly balance, constraint violation and objective reconstruction.</p>"
           + R.table(["Check", "Result"], [["Solve status", (r.get("validation") or {}).get("status") or "n/a"],
                                           ["Hourly balance error (MW)", R.plain((r.get("validation") or {}).get("hourly_balance_error_mw"))],
                                           ["Max constraint violation (MW)", R.plain((r.get("validation") or {}).get("max_constraint_violation_mw"))],
                                           ["Solver run time (s)", R.num(r.get("solver_seconds"), 1)]])]
    return pipeline_figure() + "".join(out)


def audit_table(run):
    audit = run["config"].get("forecast_audit") or {}
    rows = []
    hist = audit.get("historical") or {}
    if hist:
        rows += [["Historical raw records", R.plain(hist.get("raw_records"))], ["Hourly records after resampling", R.plain(hist.get("hourly_records"))],
                 ["Duplicated timestamps averaged", R.plain(hist.get("duplicated_timestamps_averaged"))],
                 ["Missing intervals interpolated", R.plain(hist.get("missing_intervals_interpolated"))], ["Source interval (minutes)", R.plain(hist.get("interval_minutes"))]]
    fore = audit.get("forecast") or {}
    if fore:
        rows += [["Forecast hourly records", R.plain(fore.get("hourly_records"))], ["Imported projected load used directly", R.plain(fore.get("projected_load_used_directly"))]]
    for name, info in (audit.get("resources") or {}).items():
        if isinstance(info, dict):
            rows.append([f"Resource profile: {name.replace('_', ' ')}", f"{info.get('name', '')} ({info.get('rows', '')} rows); {info.get('mapping', '')}"])
    return R.table(["Item", "Value"], rows) if rows else ""


STEPS = [("Data", "Load history,\nresource profiles"), ("Forecast", "Hourly demand\nover the horizon"), ("Optimization", "Least-cost mix\nand dispatch"),
         ("Economics", "NPC, NPV, LCOE,\npayback, CO2e"), ("Risk", "Sensitivity and\nreliability"), ("Network", "Power-flow\nverification"), ("Design", "Single-line diagram,\nequipment")]


def pipeline_figure():
    w, box, gap = 912, 108, 24
    parts = []
    for i, (title, sub) in enumerate(STEPS):
        x = 6 + i * (box + gap)
        parts.append(f'<rect x="{x}" y="18" width="{box}" height="76" rx="8" fill="#eef4fb" stroke="#1f4e79" stroke-width="1.2"/>'
                     f'<text x="{x + box / 2}" y="40" text-anchor="middle" font-size="12.5" font-weight="700" fill="#1f4e79">{i + 1}. {title}</text>')
        for j, line in enumerate(sub.split("\n")):
            parts.append(f'<text x="{x + box / 2}" y="{58 + 14 * j}" text-anchor="middle" font-size="10.5" fill="#333">{esc(line)}</text>')
        if i < len(STEPS) - 1:
            parts.append(f'<path d="M{x + box + 3} 56 h{gap - 8} m-5 -4 l5 4 l-5 4" fill="none" stroke="#1f4e79" stroke-width="1.5"/>')
    svg = f'<svg viewBox="0 0 {w} 112" width="100%" role="img" aria-label="Study workflow" font-family="Segoe UI, Arial, sans-serif">{"".join(parts)}</svg>'
    return f"<h3>Study workflow</h3><figure>{svg}<figcaption>How the study moves from data to design.</figcaption></figure>"


def results_section(run, code, best):
    wind_on = any(abs((r["caps"].get("wind_mw") or 0)) > 1e-6 for r in run["results"].values()) or "wind" in (R.eligible_techs(run) or {"wind"})
    gen_on = any(any(v > .05 for v in (r["caps"].get("generators_mw") or {}).values()) for r in run["results"].values())
    npc_cols = [(label, key, sign) for key, label, sign in R.NPC_COMPONENTS
                if any(abs((r["economics"].get(key) or 0)) > 0.5 for r in run["results"].values())]
    rows_caps, rows_cost, rows_ad = [], [], []
    for c, r in run["results"].items():
        caps, e, a = r["caps"], r["economics"], r.get("adequacy") or {}
        gens = "; ".join(f"{R.GEN_NAMES.get(k, k)} {v:,.2f}" for k, v in (caps.get("generators_mw") or {}).items() if v > .05) or "-"
        rows_caps.append([c, r["name"], R.num(caps.get("pv_dc_mw"), 2), R.num(caps.get("bess_mw"), 2), R.num(caps.get("bess_mwh"), 2)]
                         + ([R.num(caps.get("wind_mw"), 2)] if wind_on else []) + ([gens] if gen_on else []) + [R.num(caps.get("microgrid_total_ac_mw"), 2)])
        rows_cost.append([c] + [R.num(sign * currency.mega(e.get(key) or 0), 2) for _, key, sign in npc_cols] + [R.num(currency.mega(e["npc"]), 2)])
        rows_ad.append([c, R.num(a.get("unserved_mwh"), 2), R.plain(a.get("unserved_hours")), f"{100 * e.get('served_fraction', 1):.4f}%",
                        (r.get("validation") or {}).get("status") or "n/a"])
    classes = ["best" if c == best else "" for c in run["results"]]
    failures = run["summary"].get("failures") or []
    cap_heads = ["ID", "Scenario", "PV (MW DC)", "BESS (MW)", "BESS (MWh)"] + (["Wind (MW)"] if wind_on else []) + (["Generators (MW)"] if gen_on else []) + ["Microgrid (MW AC)"]
    cap_numeric = tuple(i for i, h in enumerate(cap_heads) if h not in ("ID", "Scenario", "Generators (MW)"))
    out = ["<h3>Scenario comparison</h3>", R.comparison(run, best),
           "<h3>Installed capacity by scenario</h3>", C.fig_capacity(run),
           R.table(cap_heads, rows_caps, numeric=cap_numeric, row_classes=classes),
           "<h3>Net present cost components by scenario</h3>", C.fig_npc_components(run, best),
           R.table(["ID"] + [label + " ($M)" for label, _, _ in npc_cols] + ["NPC ($M)"], rows_cost,
                   numeric=tuple(range(1, len(npc_cols) + 2)), row_classes=classes),
           "<p class='small muted'>Components are present values and sum to the NPC of each scenario (heat credit shown as a negative cost).</p>",
           "<h3>Energy supply, service and emissions by scenario</h3>", C.fig_energy_by_scenario(run), C.fig_unserved(run), C.fig_co2_by_scenario(run),
           R.table(["ID", "Unserved (MWh)", "Unserved (hours)", "Energy served", "Solution validation"], rows_ad, numeric=(1, 2, 3), row_classes=classes)]
    if failures:
        out.append(R.bullets([f"{f.get('code')}: {f.get('error')}" for f in failures]))
    return "".join(out)


def solution_section(run, code, feasible):
    r = run["results"][code]
    caps = r["caps"]
    out = [f"<p><strong>{esc(code)} - {esc(r['name'])}</strong>. {esc(R.caps_text(caps))}.</p>"]
    out.append("<h3>Installed equipment</h3>" + R.installed_equipment(run, code).replace("<h3>New equipment</h3>", ""))
    out.append("<h3>How the system operates</h3>" + "".join([C.fig_renewable_grid(run, code), C.fig_peak_grid(run, code), C.fig_monthly_dispatch(run, code),
                                                            C.fig_typical_day(run, code), C.fig_soc(run, code)]))
    out.append("<h3>Network topology</h3>" + R.topology_section(run, code).replace("section 14", ref("powerflow")))
    out.append("<h3>Annual energy and operating cost</h3>" + R.annual_tables(run, code).replace("<h3>", "<h4>").replace("</h3>", "</h4>"))
    return "".join(out)


def data_section(run, code):
    audit = audit_table(run)
    out = ["<h3>Historical demand</h3>" + "".join([C.fig_monthly_load(run), C.fig_season_day(run), C.fig_ldc(run)])]
    out.append("<h3>Demand forecast</h3>" + C.fig_forecast(run, code))
    annual = run["results"][code]["economics"].get("annual") or []
    if annual:
        out.append(R.table(["Year", "Peak (MW)", "Gross demand (GWh)", "Efficiency savings (GWh)", "Planned renewables (GWh)", "Net demand to supply (GWh)"],
                           [[a["year"], R.num(a.get("forecast_peak_mw"), 2), R.num((a.get("gross_demand_mwh") or 0) / 1e3, 1), R.num((a.get("efficiency_saved_mwh") or 0) / 1e3, 1),
                             R.num((a.get("planned_renewable_mwh") or 0) / 1e3, 1), R.num((a.get("demand_mwh") or 0) / 1e3, 1)] for a in annual], numeric=(1, 2, 3, 4, 5)))
    resources = C.fig_solar_cf(run)
    if resources:
        out.append("<h3>Renewable resource</h3>" + resources)
    out.append("<h3>Data quality summary</h3>" + (audit or "<p>No data-processing audit was recorded for this run.</p>")
               + "<p class='small muted'>The full cleaning log is in the data-quality appendix.</p>")
    return "".join(out)


def sens_section(run, code):
    base = R.sensitivity_section(run, code)
    sens = R.sensitivity_for(run["folder"])
    if not sens:
        return base
    ref = run["results"].get(run["reference"])
    extra = C.fig_risk_range(run, ref["economics"]["npc"] if ref else None) + C.fig_sens_cases(run)
    return base + (("<h3>Cost risk and cases</h3>" + extra) if extra else "")


def rel_section(run, code):
    base = R.reliability_section(run, code)
    rel = R.reliability_for(run["folder"], code)
    if not rel:
        return base
    figs = C.fig_contingencies(rel) + C.fig_mitigation(rel) + C.fig_eens_trend(rel) + C.fig_reliability_scenarios(run)
    return base + (("<h3>Reliability charts</h3>" + figs) if figs else "")


def pf_section(run, code, detail):
    base = R.powerflow_section(run, code)
    data, _ = design_data(run, code, detail)
    checks = (data or {}).get("checks") if isinstance(data, dict) else None
    figs = C.fig_violations(run) + (C.fig_voltage_cases(checks) + C.fig_branch_loading(checks) if checks else "")
    return base + (("<h3>Network charts</h3>" + figs) if figs else "")


def econ_section(run, code, info):
    figs = C.fig_cashflow(run, "net") + C.fig_cashflow(run, "operating") + C.fig_economic_panels(run, code)
    return R.economic_section(run, code, info) + (("<h3>Cash flow and financial comparison</h3>" + figs) if figs else "")


def clean_svg(svg):
    svg = str(svg or "")
    start = svg.find("<svg")
    if start < 0:
        return ""
    svg = svg[start:]
    svg = re.sub(r"<script\b.*?</script\s*>|<foreignObject\b.*?</foreignObject\s*>", "", svg, flags=re.S | re.I)
    svg = re.sub(r"\son\w+\s*=\s*(\"[^\"]*\"|'[^']*'|[^\s>]+)", "", svg, flags=re.I)
    svg = re.sub(r"(href\s*=\s*[\"']?)\s*javascript:", r"\1#", svg, flags=re.I)
    return svg


DESIGN_GROUPS = [("overview", "Design overview", ()), ("criteria", "Design criteria", ("criteria", "basis", "standard", "code")),
                 ("sld", "Single-line diagram", ("sld", "single_line", "diagram")), ("schedule", "Equipment schedule", ("equipment", "schedule")),
                 ("transformers", "Transformers", ("transformer",)), ("switchgear", "Switchgear and busbars", ("switchgear", "breaker", "busbar")),
                 ("shunt", "Reactive compensation and shunt devices", ("shunt", "reactive", "capacitor", "reactor", "filter")),
                 ("cables", "Cables and conductors", ("cable", "conductor", "feeder", "line")),
                 ("protection", "Protection and control", ("protection", "relay", "control", "scada")),
                 ("psse", "PSS/E model", ("psse", "pss_e", "raw")), ("bom", "Bill of materials", ("bom", "material")),
                 ("pf", "Power-flow verification", ("power_flow", "powerflow", "verification", "load_flow")),
                 ("other", "Additional design information", ())]
MATCH_ORDER = ["transformers", "switchgear", "shunt", "protection", "psse", "bom", "pf", "cables", "criteria", "sld", "schedule"]
DESIGN_SKIP = {"sld_svg", "svg", "run_id", "sld_model", "raw_model"}


UNIT_WORDS = {"kv": "kV", "mw": "MW", "kw": "kW", "mva": "MVA", "kva": "kVA", "mvar": "MVAr", "mwh": "MWh", "kwh": "kWh", "hv": "HV", "lv": "LV",
              "mv": "MV", "ac": "AC", "dc": "DC", "bess": "BESS", "pv": "PV", "poi": "POI", "psse": "PSS/E", "bom": "BOM", "sld": "SLD", "id": "ID", "pu": "pu"}


def label(key):
    words = str(key).replace("_", " ").split()
    words = [UNIT_WORDS.get(w.lower(), w) for w in words]
    text = " ".join(words)
    return text[:1].upper() + text[1:]


def cell(value):
    if isinstance(value, tuple):
        value = list(value)
    if isinstance(value, (dict, list)):
        return "; ".join(f"{label(k)}: {cell(v)}" for k, v in value.items()) if isinstance(value, dict) else ", ".join(cell(v) for v in value if v is not None)
    return R.plain(value)


def render_value(value, depth=0):
    if value is None or value == "" or value == [] or value == {}:
        return ""
    if isinstance(value, list):
        if all(isinstance(i, dict) for i in value):
            cols = []
            for item in value:
                cols += [k for k in item if k not in cols]
            cols = cols[:12]
            return R.table([label(c) for c in cols], [[cell(i.get(c)) for c in cols] for i in value],
                           numeric=tuple(n for n, c in enumerate(cols) if all(isinstance(i.get(c), (int, float)) and not isinstance(i.get(c), bool) for i in value if i.get(c) is not None)))
        return R.bullets([cell(i) for i in value])
    if isinstance(value, dict):
        simple = {k: v for k, v in value.items() if not isinstance(v, (list, dict)) and v not in (None, "")}
        out = [R.table(["Item", "Value"], [[label(k), cell(v)] for k, v in simple.items()])] if simple else []
        for k, v in value.items():
            if isinstance(v, (list, dict)) and v:
                out.append(f"<h4>{esc(label(k))}</h4>" + render_value(v, depth + 1))
        return "".join(out)
    return f"<p>{esc(cell(value))}</p>"


def _src(source):
    kind = {"user-set": "warn", "assumed": "", "from model": "good", "model": "good"}.get(source, "")
    return R.badge(source or "-", kind)


def _status_badge(status):
    return R.badge(status or "-", R.status_kind(status))


def key_parameters(data):
    """Small headline table used by the main report: status, voltages, transformer, reactive compensation, fault level, quantities."""
    meta, volts, totals = data.get("meta") or {}, data.get("voltages") or {}, data.get("totals") or {}
    shunt, sc = data.get("shunt") or {}, data.get("short_circuit") or {}
    rows = [["Design status", meta.get("status") or "-", ""],
            ["Grid connection voltage", volts.get("hv_kv") if not meta.get("islanded") else "islanded", "kV" if not meta.get("islanded") else ""],
            ["Plant medium-voltage bus", volts.get("mv_kv"), "kV"],
            ["Inverter / low-voltage terminals", volts.get("lv_kv"), "kV"],
            ["Main transformer rating (total)", totals.get("main_transformer_mva") or "none", "MVA" if totals.get("main_transformer_mva") else ""],
            ["Fault level at the MV bus", sc.get("mv_ka"), "kA"],
            ["Capacitor bank", f"{shunt.get('stages', 0)} x {shunt.get('stage_mvar', 0)}" if shunt.get("stages") else "none", "Mvar" if shunt.get("stages") else ""]]
    return R.table(["Parameter", "Value", "Unit"], [r for r in rows if r[1] not in (None, "")], numeric=(1,))


def _not_built_html(data):
    notes = [n for n in ((data.get("effective_technologies") or {}).get("notes") or [])]
    return "".join(f'<p class="small muted">{esc(n)}.</p>' for n in notes)


def design_data(run, code, detail=None):
    """Design model for the selected scenario, built once per report ((data, None) or (None, reason))."""
    if "_design" not in run:
        try:
            import design
            data = design.build_design(run["run_id"], code, **({"detail": detail} if detail and detail != "equivalent" else {}))
            if not isinstance(data, dict) or not data:
                raise ValueError("no design data returned")
            run["_design"] = (data, None)
        except Exception as exc:
            run["_design"] = (None, "" if isinstance(exc, ImportError) else f" ({exc})")
    return run["_design"]


def design_section(run, code, detail=None):
    """Main-report design summary: the single-line diagram and a few key parameters (the detail is in the technical design report)."""
    data, reason = design_data(run, code, detail)
    if data is None:
        return R.notrun("Design not available" + reason + ". The single-line diagram and key design parameters appear here when the design module is installed.")
    import design
    svg = ""
    try:
        svg = clean_svg(design.sld_svg(data))
    except Exception:
        svg = ""
    out = []
    if svg:
        out.append(f'<h3>Single-line diagram</h3><figure class="sld">{svg}<figcaption>Single-line diagram, scenario {esc(code)}.</figcaption></figure>')
    out.append("<h3>Key design parameters</h3>" + key_parameters(data) + _not_built_html(data))
    out.append("<p class=\"small muted\">The design basis, equipment schedule, bill of quantities, power-flow results, protection scheme and the register of assumed "
               "and user-set values are issued separately in the technical design report.</p>")
    return "".join(out)


# --------------------------------------------------------------------------- technical design report

DESIGN_SECTIONS = [("basis", "Design basis"), ("sld", "Single-line diagram"), ("schedule", "Equipment schedule"),
                   ("boq", "Bill of quantities"), ("pf", "Power-flow results"), ("protection", "Protection and control"),
                   ("assumptions", "Assumptions register")]


def dr_basis(d):
    out = []
    shunt_note = d.get("shunt_note")
    if shunt_note:
        out.append(f'<div class="callout"><strong>Shunt compensation.</strong> {esc(shunt_note)}</div>')
    label = (d.get("meta") or {}).get("detail_label")
    if label:
        out.append(f'<p><strong>Design detail:</strong> {esc(label)}.</p>')
    out.append(_not_built_html(d))
    groups = {}
    for row in d.get("basis") or []:
        groups.setdefault(row.get("group") or "General", []).append(row)
    for group, rows in groups.items():
        out.append(f"<h4>{esc(group)}</h4>" + R.table(["Item", "Value", "Unit", "Source", "Note"],
                   [[r.get("name"), R.plain(r.get("value")), r.get("unit") or "", _src(r.get("source")), r.get("note") or ""] for r in rows],
                   numeric=(1,), raw_cols=(3,)))
    return "".join(out) or R.notrun("No design basis rows were produced.")


def dr_sld(d, code):
    try:
        import design
        svg = clean_svg(design.sld_svg(d))
    except Exception:
        svg = ""
    if not svg:
        return R.notrun("The single-line diagram could not be drawn.")
    return f'<figure class="sld">{svg}<figcaption>Single-line diagram, scenario {esc(code)}.</figcaption></figure>'


def dr_schedule(d):
    import design
    rows = []
    for e in d.get("equipment") or []:
        rows.append([e["id"], e["category"], e["type"], e["description"], e["rating"], R.plain(e["voltage"]), e["quantity"],
                     design._param_text({k: v for k, v in (e.get("params") or {}).items() if k not in ("sizing",)}), _src(e.get("basis"))])
    return R.table(["ID", "Category", "Type", "Description", "Rating", "Voltage (kV)", "Qty", "Key parameters", "Basis"], rows, numeric=(6,), raw_cols=(8,)) + \
        "".join(f'<p class="small"><strong>{esc(f["id"])}</strong> &ndash; {esc(f["note"])}</p>' for f in (d.get("flags") or [])[:40])


def dr_boq(d):
    units = d.get("unit_counts") or []
    out = ["<h4>Estimated unit counts</h4>",
           R.table(["Item", "Count", "Unit size", "Unit", "Basis", "Note"],
                   [[u["item"], R.plain(u["count"]), R.plain(u["unit_size"]), u.get("unit") or "", _src(u.get("basis")), u.get("note") or ""] for u in units],
                   numeric=(1, 2), raw_cols=(4,)) if units else R.notrun("No unit counts."),
           '<p class="small muted">Unit sizes are assumptions (editable on the Design page) and give an order-of-magnitude count for budgeting, not a procurement quantity.</p>',
           "<h4>Bill of materials</h4>",
           R.table(["Item", "Quantity", "Unit", "Note"], [[b["item"], R.plain(b["quantity"]), b["unit"], b.get("note") or ""] for b in d.get("bom") or []], numeric=(1,))]
    land = d.get("land") or []
    if land:
        out.append("<h4>Land</h4>" + R.table(["Item", "Quantity", "Unit", "Basis"], [[x["item"], R.plain(x["quantity"]), x["unit"], x.get("basis") or ""] for x in land], numeric=(1,)))
    return "".join(out)


def dr_pf(d, saved):
    checks = d.get("checks") or {}
    out = [f"<p>Design check status: {_status_badge(checks.get('status'))}. Balanced positive-sequence steady-state Newton solution of the design network at the "
           "selected operating hours.</p>"]
    cases = checks.get("cases") or []
    if cases:
        out.append("<h4>Operating cases</h4>" + R.table(
            ["Case", "Load (MW)", "Grid (MW)", "Grid (Mvar)", "Grid pf", "Vmin (pu)", "Vmax (pu)", "Max loading (%)", "Losses (MW)", "Capacitor stages in"],
            [[c.get("label"), R.plain(c.get("load_mw")), R.plain(c.get("grid_mw")), R.plain(c.get("grid_mvar")), R.plain(c.get("grid_pf")), R.plain(c.get("vmin")),
              R.plain(c.get("vmax")), R.plain(c.get("max_loading_pct")), R.plain(c.get("losses_mw")), R.plain(c.get("cap_stages_in"))] for c in cases],
            numeric=tuple(range(1, 10))))
    viol = [dict(case=c.get("label"), **v) for c in cases for v in c.get("violations") or []]
    if viol:
        out.append("<h4>Violations and warnings</h4>" + R.table(["Case", "Severity", "Component", "Message"],
                   [[v["case"], v.get("severity"), v.get("component_name") or v.get("component"), v.get("message")] for v in viol]))
    else:
        out.append("<p>No voltage, loading or reactive-limit violations in the screened cases.</p>")
    n1 = checks.get("n1") or []
    if n1:
        out.append("<h4>N-1 contingencies</h4>" + R.table(["Contingency", "Status", "Note"], [[n.get("label"), n.get("status"), n.get("note") or ""] for n in n1]))
    cab = d.get("cables") or []
    if cab:
        out.append("<h4>Cable checks</h4>" + R.table(["Circuit", "Size", "Length (km)", "Current per circuit (A)", "Derated ampacity (A)", "Loading (%)", "Voltage drop (%)"],
                   [[c.get("id"), c.get("size"), R.plain(c.get("length_km")), R.plain(c.get("i_per_circuit_a")), R.plain(c.get("derated_ampacity_a")),
                     R.plain(c.get("loading_pct")), R.plain(c.get("voltage_drop_pct"))] for c in cab], numeric=(2, 3, 4, 5, 6)))
    sc = d.get("short_circuit") or {}
    if sc:
        out.append(f"<p>Fault level: MV bus {R.plain(sc.get('mv_ka'))} kA ({R.plain(sc.get('mv_mva'))} MVA); connection voltage {R.plain(sc.get('hv_ka'))} kA ({R.plain(sc.get('hv_mva'))} MVA).</p>")
    if d.get("iterations"):
        out.append("<h4>Design iterations</h4>" + R.bullets(d["iterations"]))
    if saved:
        out.append(f"<h4>Power flow on the edited design</h4><p>Screening of the stored single-line diagram with the design edits: {_status_badge(saved.get('status'))} "
                   f"(normal {esc(saved.get('normal_status') or '-')}, N-1 {esc(saved.get('n1_status') or '-')}), run {esc(saved.get('ran') or '')}.</p>")
        if saved.get("violations"):
            out.append(R.table(["Case", "Severity", "Component", "Message"], [[v.get("case"), v.get("severity"), v.get("component_name") or v.get("component"), v.get("message")] for v in saved["violations"]]))
    return "".join(out)


def dr_protection(d):
    rows = d.get("protection") or []
    out = [R.table(["Zone", "Device", "Functions", "Qty", "Note"], [[p.get("zone"), p.get("device"), p.get("functions"), p.get("quantity"), p.get("note") or ""] for p in rows], numeric=(3,))] if rows else []
    earth = [e for e in d.get("equipment") or [] if e["category"] in ("Grounding", "Control and protection")]
    if earth:
        out.append("<h4>Earthing and control equipment</h4>" + R.table(["ID", "Type", "Rating", "Basis"], [[e["id"], e["type"], e["rating"], _src(e.get("basis"))] for e in earth], raw_cols=(3,)))
    return "".join(out) or R.notrun("No protection schedule was produced.")


def dr_assumptions(d, params):
    out = []
    user = [f for f in (params or {}).get("fields", []) if f.get("user_set")]
    if user:
        out.append("<h4>User-set values</h4>" + R.table(["Parameter", "Group", "User value", "Default", "Unit"],
                   [[f["label"], f["group"], R.plain(f["value"]), R.plain(f["default"]), f["unit"]] for f in user], numeric=(2, 3)))
    else:
        out.append("<p>No value was edited by the user: every assumed value below is the design default.</p>")
    basis = [r for r in d.get("basis") or [] if r.get("source") in ("assumed", "user-set")]
    out.append("<h4>Assumed and user-set design basis</h4>" + R.table(["Item", "Value", "Unit", "Source"],
               [[r["name"], R.plain(r.get("value")), r.get("unit") or "", _src(r.get("source"))] for r in basis], numeric=(1,), raw_cols=(3,)))
    eq = [e for e in d.get("equipment") or [] if e.get("basis") in ("assumed", "user-set")]
    out.append("<h4>Equipment ratings that are assumed or user-set</h4>" + R.table(["ID", "Equipment", "Rating", "Basis"],
               [[e["id"], e["type"], e["rating"], _src(e.get("basis"))] for e in eq], raw_cols=(3,)))
    if d.get("limitations"):
        out.append("<h4>Limitations</h4>" + R.bullets(d["limitations"]))
    return "".join(out)


def build_design_doc(run_id, meta_raw=None):
    """Stand-alone technical design report (HTML like the main report) for the recommended or selected scenario, with the user's design edits."""
    import design
    meta = clean_meta(meta_raw)
    run = R.load_run(run_id)
    code = meta["scenario"]
    if code not in run["results"]:
        try:
            code = design.recommended_scenario(run_id, None)
        except Exception:
            code = None
        if code not in run["results"]:
            code = R.pick_best(run["results"], run["folder"])[0]
    if code not in run["results"]:
        code = next(iter(run["results"]))
    d = design.build_design(run_id, code, detail=meta["detail"])
    try:
        params = design.design_params(run_id, code)
    except Exception:
        params = None
    saved = (params or {}).get("power_flow")
    stamp = datetime.datetime.fromtimestamp((run["folder"] / "status.json").stat().st_mtime)
    title = meta["project_name"] or run["results"][code].get("name") or "Technical design"
    builders = {"basis": lambda: dr_basis(d), "sld": lambda: dr_sld(d, code), "schedule": lambda: dr_schedule(d), "boq": lambda: dr_boq(d),
                "pf": lambda: dr_pf(d, saved), "protection": lambda: dr_protection(d), "assumptions": lambda: dr_assumptions(d, params)}
    lists = dict(toc=[], figures=[], tables=[])
    body = []
    for index, (key, name) in enumerate(DESIGN_SECTIONS, 1):
        lists["toc"].append((1, f"s{index}", str(index), name))
        content = number_section(index, str(index), name, R.plant_names(run, builders[key]()), lists)
        body.append(f'<section class="doc" id="s{index}"><h2><span class="num">{index}</span>{esc(name)}</h2>{content}</section>')
    user_n = len((params or {}).get("overrides") or {})
    rows = [("Client", meta["client_name"]), ("Project number", meta["project_number"]), ("Site / location", meta["site"]),
            ("Document number", meta["document_number"]), ("Revision", meta["revision"] or d["meta"].get("revision")), ("Issue purpose", meta["issue_purpose"]),
            ("Date", meta["date"]), ("Prepared by", meta["prepared_by"]), ("Scenario", f"{code} - {run['results'][code].get('name')}"),
            ("Design status", d["meta"].get("status")), ("Design detail", d["meta"].get("detail_label")), ("User-set values", str(user_n))]
    logo = f'<img class="logo" src="{meta["logo"]}" alt="Company logo">' if meta["logo"] else ""
    company = f'<div class="company">{esc(meta["consulting_company"])}</div>' if meta["consulting_company"] else ""
    cover = (f'<div class="cover">{logo}{company}<div class="eyebrow">Technical design report</div><h1>{esc(title)}</h1>'
             f'<div class="subtitle">Electrical design: single-line diagram, equipment, bill of quantities and power flow<br>Scenario {esc(code)}</div>'
             "<table><tbody>" + "".join(f"<tr><th>{esc(k)}</th><td>{esc(v)}</td></tr>" for k, v in rows if v) + "</tbody></table>"
             f'<div class="conf"><strong>Confidentiality.</strong> {esc(meta["confidentiality"])}</div></div>')
    front = (f'<section class="frontmatter" id="contents"><h2>Table of contents</h2>{toc_html(lists)}'
             f'<h3>List of figures</h3>{list_html(lists["figures"])}<h3>List of tables</h3>{list_html(lists["tables"])}</section>')
    when = datetime.datetime.now()
    ident = " ".join(x for x in (meta["document_number"], rev_label(meta)) if x)
    tail = " - ".join(x for x in (meta["consulting_company"], ident) if x)
    document = cover + control_html(meta, run_id, stamp) + front + "".join(body)
    return (f'<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            f"<title>{esc('Technical design report - ' + title)}</title><style>{STYLE}{page_css(meta, 'Technical design report - ' + title)}</style></head>"
            f"<body><main>{round_text(document)}<footer class='end'>{esc(tail + '. ' if tail else '')}Generated by GenStudio on {when:%Y-%m-%d %H:%M}. "
            "Screening-level design; verify with the utility, OEM data and a detailed study before construction. To save as PDF open this file in a browser and print (A4).</footer>"
            "</main></body></html>")


def risk_register(run, code, rel, feasible):
    """Risk rows as dicts (id, cat, risk, lik, imp, rating, mit); the rating is likelihood x impact."""
    r = run["results"][code]
    tech = R.technical(r)
    verdict = R.reliability_verdict(rel)
    sens = R.sensitivity_for(run["folder"])
    top = None
    if sens and sens["report"].get("swings"):
        top = max(sens["report"]["swings"], key=lambda s: s["swing"])["label"]
    level = {"PASS": ("Low", "Low"), "WARN": ("Medium", "High"), "FAIL": ("High", "High")}
    rel_l, rel_i = level.get(verdict, ("Medium", "High"))
    pf_status = str((tech or {}).get("status") or "").upper()
    pf_l, pf_i = level.get(pf_status, ("Medium", "High"))
    caps = r["caps"]
    gens = [k for k, v in (caps.get("generators_mw") or {}).items() if v > .05]
    score = {"Low": 1, "Medium": 2, "High": 3}
    rows = [
        ["Demand", "Actual demand growth differs from the forecast", "Medium", "High", "Review milestones annually; use sensitivity ranges for sizing margins."],
        ["Commercial", "Energy price, tariff or escalation differ from assumptions" + (f" (largest tested driver: {top})" if top else ""), "Medium", "High",
         "Confirm tariff with the utility; consider hedging or contracts."],
        ["Capital cost", "Technology capex escalation or supply-chain delay", "Medium", "Medium", "Obtain budgetary quotes; include contingency; stage procurement."],
        ["Reliability", "Reliability screening: " + (verdict or "not run"), rel_l, rel_i, "Address N-1 and LOLE findings; add redundancy or storage where flagged."],
        ["Network", "Power-flow screening: " + (pf_status if pf_status and pf_status != "NOT_RUN" else "not run"), pf_l, pf_i,
         "Complete detailed network studies; implement reinforcement identified in the screening."],
        ["Service", "Unserved energy in the selected scenario" if not feasible else "Shortage in stress conditions", "High" if not feasible else "Low",
         "High", "Do not adopt a scenario with unserved energy without remedial capacity." if not feasible else "None beyond routine monitoring."],
        ["Interconnection", "Utility approval, permitting or interconnection queue delay", "Medium", "High", "Engage the utility and authority having jurisdiction early."],
        ["Data", "Screening-level resource data, unconfirmed emission factors or sparse history", "Medium", "Medium", "Replace proxies with measured site data before final design."],
        ["Design maturity", "Design is concept-level until detailed engineering is complete", "Medium", "Medium",
         "Progress to detailed design, protection coordination and short-circuit studies."],
    ]
    if caps.get("bess_mw", 0) > .05:
        rows.append(["Safety", "BESS fire safety, degradation and end-of-life", "Low", "High", "Design to NFPA 855 / UL 9540; hazard mitigation analysis; warranty and augmentation plan."])
    if gens:
        rows.append(["Fuel", f"Fuel availability and price for {', '.join(R.GEN_NAMES.get(g, g) for g in gens)}", "Medium", "High", "Secure fuel supply agreements and on-site storage."])
    table_rows = []
    for i, (cat, risk, lik, imp, mit) in enumerate(rows, 1):
        s = score[lik] * score[imp]
        table_rows.append(dict(id=f"R-{i:02d}", cat=cat, risk=risk, lik=lik, imp=imp, mit=mit,
                               rating="High" if s >= 6 else "Medium" if s >= 3 else "Low", score=s))
    return table_rows


def risk_section(run, code, best, rel, feasible, risks):
    rows = [[x["id"], x["cat"], x["risk"], x["lik"], x["imp"], R.badge(x["rating"], {"High": "bad", "Medium": "warn", "Low": "good"}[x["rating"]]), x["mit"]] for x in risks]
    limitations = [s.replace("Otherwise solar uses", "Where no solar profile is uploaded, solar uses")
                   for s in R.sentences(run["config"].get("limitations"))
                   if not re.match(r"(?:Use|Upload|Enter|Confirm|Review|Define|Select|Check|Choose|Set|Add|Provide)\b", s)] + [
        "This report is a planning-level screening result, not an investment certification or electrical design."]
    return ("<h3>Technical compliance by scenario</h3>" + compliance_table(run, code, best) +
            "<h3>Risk register</h3><p class='small muted'>Rating = likelihood x impact (Low 1, Medium 2, High 3): 6-9 High, 3-4 Medium, 1-2 Low.</p>" +
            R.table(["ID", "Category", "Risk", "Likelihood", "Impact", "Rating", "Mitigation"], rows, raw_cols=(5,)) +
            "<h3>Limitations</h3>" + R.bullets(limitations))


def compliance_table(run, code, best):
    """Technical compliance summary: one row per scenario so that cost ranking and technical status are read side by side."""
    rows, classes = [], []
    for c, r in run["results"].items():
        a, tech, rel = r.get("adequacy") or {}, R.technical(r) or {}, R.reliability_for(run["folder"], c)
        detail = (rel or {}).get("verdict_detail") if isinstance((rel or {}).get("verdict_detail"), dict) else {}
        served = R.is_feasible(r)
        pf = str(tech.get("status") or "NOT_RUN").upper()
        rv = R.reliability_verdict(rel)

        def secure(key):
            return "-" if key not in detail else "Secure" if detail[key] else "Not secure"
        rows.append([c, R.badge("Fully served" if served else f"Unserved {R.num(a.get('unserved_mwh'), 2)} MWh", "good" if served else "bad"),
                     R.badge((r.get("validation") or {}).get("status") or "n/a", "good" if (r.get("validation") or {}).get("status") == "PASS" else ""),
                     R.badge(pf.replace("_", " "), R.status_kind(pf)), tech.get("n1_status") or "-",
                     R.badge(rv or "NOT RUN", R.status_kind(rv)), R.num(detail.get("lole_h_yr"), 2) if "lole_h_yr" in detail else "-",
                     secure("local_n1_secure"), secure("grid_n1_secure")])
        classes.append("best" if c == best else "")
    chosen = run["results"][code]
    chosen_pf = str((R.technical(chosen) or {}).get("status") or "NOT_RUN").upper()
    remark = ("Scenarios are ranked by total net present cost; technical status is a remark on each option. "
              "Where a status is WARN or FAIL, the corrective measures listed in @@sec:powerflow@@ and @@sec:reliability@@ are not yet included in the NPC.")
    if chosen_pf in ("WARN", "FAIL"):
        remark += f" The selected option {esc(code)} reports power-flow status {chosen_pf}."
    return ("<p>PASS means all criteria are met, WARN that criteria are met with margin concerns or "
            "limited deviations, and FAIL that at least one criterion is violated in the screened cases.</p>"
            + R.table(["ID", "Supply adequacy", "Solution validation", "Power flow", "Power-flow N-1", "Reliability", "LOLE (h/yr)", "N-1 local resources", "N-1 grid loss"],
                      rows, numeric=(6,), row_classes=classes, raw_cols=(1, 2, 3, 5))
            + f"<p class='small muted'>{remark}</p>")


EQUATIONS = [
    ("Net present cost (objective)", "NPC = C<sub>0</sub> + &Sigma;<sub>y=1..N</sub> O<sub>y</sub> &middot; (1 + i)<sup>y</sup> / (1 + r)<sup>y</sup>",
     "C<sub>0</sub> upfront capital including connection works (year 0, not inflated or discounted); O<sub>y</sub> base-year operating cost "
     "(grid energy and demand charges, fuel, variable and fixed O&amp;M, carbon, replacements, upgrade O&amp;M, less heat credit); "
     "i inflation ({infl}); r nominal discount rate ({disc}); N appraisal years ({years}). Operating cash flows are year-end."),
    ("Hourly power balance", "G<sub>h</sub> + PV<sub>h</sub> + W<sub>h</sub> + &Sigma;P<sub>gen,h</sub> + d<sub>h</sub> &minus; c<sub>h</sub> + U<sub>h</sub> = L<sub>h</sub>",
     "For every hour h: grid import G, solar PV, wind W, generators, battery discharge d and charge c, unserved energy U and net demand L (MW; hourly values are MWh)."),
    ("Battery state of charge", "SOC<sub>h</sub> = SOC<sub>h&minus;1</sub> + &eta;<sub>c</sub> c<sub>h</sub> &minus; d<sub>h</sub> / &eta;<sub>d</sub>;&nbsp; SOC<sub>min</sub> &le; SOC<sub>h</sub> &le; SOC<sub>max</sub> &middot; E<sub>B</sub>",
     "E<sub>B</sub> installed energy capacity (MWh); &eta;<sub>c</sub> = &eta;<sub>d</sub> = &radic;(round-trip efficiency). Opening and closing state of charge of each month are equal."),
    ("Discount factor and inflation factor", "b<sub>y</sub> = 1 / (1 + r)<sup>y</sup>;&nbsp; a<sub>y</sub> = (1 + i)<sup>y</sup>", "Combined operating weight w<sub>y</sub> = a<sub>y</sub> b<sub>y</sub>."),
    ("Incremental net present value versus the reference case", "NPV<sub>s</sub> = NPC<sub>ref</sub> &minus; NPC<sub>s</sub> = CF<sub>0</sub> + &Sigma;<sub>y</sub> CF<sub>y</sub> / (1 + r)<sup>y</sup>",
     "CF are the cash-flow differences between the reference case and scenario s. IRR is the rate at which this sum is zero; it is reported only when the cash flows change sign once."),
    ("Levelized supply cost", "LCOE = NPC / &Sigma;<sub>y</sub> [E<sub>served,y</sub> / (1 + r)<sup>y</sup>]",
     "Whole-system cost per MWh of served load (base-year $/MWh), including grid imports; it is not a stand-alone plant LCOE."),
    ("Annual emissions", "CO<sub>2</sub>e<sub>y</sub> = EF<sub>grid</sub> &middot; E<sub>grid,y</sub> + &Sigma; EF<sub>fuel</sub> &middot; F<sub>y</sub> &minus; avoided boiler emissions",
     "Emission factors are held constant over the horizon; totals are summed without discounting."),
]


def equations_section(run):
    values = run["values"]
    planning = run["config"].get("planning") or {}
    fill = dict(infl=R.display_value({"unit": "fraction", "key": "inflation"}, values.get("inflation", .03)) + "%",
                disc=R.display_value({"unit": "fraction", "key": "discount"}, values.get("discount", .06)) + "%",
                years=planning.get("appraisal_years") or values.get("appraisal_years") or "n/a")
    rows = "".join(f"<tr><th>{esc(name)}</th><td class='eqn'>{formula}</td><td>{where.format(**fill)}</td></tr>" for name, formula, where in EQUATIONS)
    return ("<p>The principal relations used by the optimization and the post-solve financial analysis are summarized below. "
            "The complete formulation is available in the model documentation referenced in the appendix of references.</p>"
            f"<table><thead><tr><th>Relation</th><th>Equation</th><th>Definitions</th></tr></thead><tbody>{rows}</tbody></table>")


def next_steps(run, code, rel, sens):
    tech = R.technical(run["results"][code])
    steps = ["Confirm demand milestones, tariff and technology budgets with the client."]
    if not sens:
        steps.append("Run the sensitivity analysis to quantify cost risk before commitment.")
    if not rel:
        steps.append("Run the reliability analysis for the selected option.")
    if not tech or str(tech.get("status")).upper() == "NOT_RUN":
        steps.append("Define the single-line diagram and run the power-flow screening.")
    elif str(tech.get("status")).upper() in ("WARN", "FAIL"):
        steps.append("Implement the network reinforcement indicated by the power-flow screening and re-run.")
    return steps + ["Commission detailed network, short-circuit, protection-coordination and grounding studies.",
                    "Request equipment quotations and utility interconnection feasibility confirmation.",
                    "Progress the design to issue for construction and update this report at each revision."]


def conclusions_section(run, code, best, feasible, rel, sens, steps):
    r = run["results"][code]
    e = r["economics"]
    ref_r = run["results"].get(run["reference"])
    tech = R.technical(r)
    bullets = [f"{code} - {r['name']} {'is the lowest-cost fully served option' if code == best and feasible else 'is the reported option'}, with a net present cost of {R.mil(e['npc'])} and upfront capital of {R.mil(e['capex'])}.",
               f"It comprises: {R.caps_text(r['caps'])}."]
    if ref_r and ref_r is not r:
        d = e["npc"] - ref_r["economics"]["npc"]
        bullets.append(f"Versus reference {ref_r['code']}, NPC is {R.mil(abs(d))} {'lower' if d <= 0 else 'higher'} ({R.pct(100 * d / ref_r['economics']['npc'])}).")
    bullets.append(f"Power-flow screening: {(tech or {}).get('status') or 'not run'}; reliability screening: {R.reliability_verdict(rel) or 'not run'}.")
    others = sorted((x for x in run["results"].values() if x["code"] != code and R.is_feasible(x)), key=lambda x: x["economics"]["npc"])
    if others and R.is_feasible(r):
        o = others[0]
        bullets.append(f"The next-best fully served alternative is {o['code']} - {o['name']} at {R.mil(o['economics']['npc'])} "
                       f"({R.mil(o['economics']['npc'] - e['npc'])} higher); the ranking is by total net present cost, with technical status as a remark.")
    if tech and str(tech.get("status")).upper() in ("WARN", "FAIL"):
        bullets.append(f"The option's power-flow status is {str(tech['status']).upper()}: the cost ranking does not yet include the network corrections, "
                       "so the NPC is a lower bound for a technically compliant design.")
    if sens and (sens["report"].get("risk") or {}).get("p50") is not None:
        risk = sens["report"]["risk"]
        bullets.append(f"Within the tested ranges the NPC spans {R.mil(risk['p10'], 1)} (P10) to {R.mil(risk['p90'], 1)} (P90), median {R.mil(risk['p50'], 1)}.")
    return "<h3>Conclusions</h3>" + R.bullets(bullets) + "<h3>Recommendations and next steps</h3><ol>" + "".join(f"<li>{esc(s)}</li>" for s in steps) + "</ol>"


def app_inputs(run):
    """Assumption register: every applicable input with its value, unit and whether it differs from the program default."""
    groups = {}
    for f in R.fields_for(run):
        if f["group"] in ("Solver", "Scenarios"):
            continue
        value = run["values"].get(f["key"], f.get("default"))
        changed = "default" in f and R.display_value(f, value) != R.display_value(f, f.get("default"))
        groups.setdefault(f["group"], []).append([f["label"], R.display_value(f, value), R.display_unit(f), "User-set" if changed else "Default"])
    out = [f"<h3>{esc(group)}</h3>" + R.table(["Parameter", "Value", "Unit", "Basis"], rows, numeric=(1,)) for group, rows in groups.items()]
    defs = run["request"].get("scenario_definitions") or []
    if defs:
        out.append("<h3>Scenario definitions</h3>" + scenario_table(defs))
    ms = run["request"].get("milestones") or []
    if ms:
        cols = [("Year", lambda m: R.plain(m.get("year")).replace(",", ""), False), ("Peak (MW)", lambda m: R.num(m.get("peak_mw"), 2), True),
                ("Growth (%)", lambda m: R.plain(m.get("growth_percent")) if m.get("growth_percent") not in (None, "", 0) else "", True),
                ("Description", lambda m: m.get("description") or "", False)]
        cols = [c for c in cols if any(c[1](m) for m in ms) or c[0] == "Year"]
        out.append("<h3>Client annual milestones</h3>" + R.table([c[0] for c in cols], [[c[1](m) for c in cols] for m in ms],
                                                                  numeric=tuple(i for i, c in enumerate(cols) if c[2])))
    return "".join(out)


def scenario_table(defs):
    return R.table(["ID", "Name", "Eligible technologies", "Role"],
                   [[d.get("id"), d.get("name"), ", ".join(R.GEN_NAMES.get(t, "Grid supply" if t == "grid" else str(t)) for t in d.get("technologies") or []),
                     "Reference (business as usual)" if d.get("reference") else "Alternative"] for d in defs])


# --------------------------------------------------------------------------- numbering and assembly

TOKEN = re.compile(r'<h3>(.*?)</h3>|<h4>(.*?)</h4>|<figcaption>(.*?)</figcaption>|<table( class="wide")?>', re.S)


def strip_tags(text):
    return html.unescape(re.sub(r"<[^>]+>", "", text))


def number_section(index, label_text, title, body, lists):
    """Number subsections, figures and tables of one section; fill the contents lists."""
    state = dict(sub=0, fig=0, tab=0, cur=title)

    def repl(m):
        if m.group(1) is not None:
            state["sub"] += 1
            anchor = f"s{index}-{state['sub']}"
            state["cur"] = strip_tags(m.group(1))
            lists["toc"].append((2, anchor, f"{label_text}.{state['sub']}", state["cur"]))
            return f'<h3 id="{anchor}"><span class="num">{label_text}.{state["sub"]}</span>{m.group(1)}</h3>'
        if m.group(2) is not None:
            state["cur"] = strip_tags(m.group(2))
            return m.group(0)
        if m.group(3) is not None:
            state["fig"] += 1
            num_text = f"Figure {label_text}-{state['fig']}"
            anchor = f"fig-{index}-{state['fig']}"
            lists["figures"].append((anchor, num_text, strip_tags(m.group(3))))
            return f'<figcaption><a id="{anchor}"></a><strong>{num_text}</strong> &ndash; {m.group(3)}</figcaption>'
        state["tab"] += 1
        num_text = f"Table {label_text}-{state['tab']}"
        anchor = f"tab-{index}-{state['tab']}"
        lists["tables"].append((anchor, num_text, state["cur"]))
        return f'<table{m.group(4) or ""}><caption><a id="{anchor}"></a>{num_text} &ndash; {esc(state["cur"])}</caption>'

    return TOKEN.sub(repl, body)


def toc_html(lists):
    rows = [f'<div class="toc-row l{lvl}{" app" if n.startswith("Appendix") else ""}"><a href="#{a}"><span class="num">{esc(n)}</span><span class="tx">{esc(t)}</span><span class="pg" data-a="{a}"></span></a></div>' for lvl, a, n, t in lists["toc"]]
    return "".join(rows)


def list_html(entries):
    if not entries:
        return '<p class="muted">None.</p>'
    return "".join(f'<div class="lof-row"><a href="#{a}"><span class="tx"><strong>{esc(n)}</strong> &ndash; {esc(t)}</span><span class="pg" data-a="{a}"></span></a></div>' for a, n, t in entries)


def cover_html(meta, title, run, code, best_label):
    planning = run["config"].get("planning") or {}
    logo = f'<img class="logo" src="{meta["logo"]}" alt="Company logo">' if meta["logo"] else ""
    horizon = f"{planning['start_year']}-{planning['end_year']}" if planning.get("start_year") and planning.get("end_year") else ""
    rows = [("Client", meta["client_name"]), ("Project number", meta["project_number"]), ("Site / location", meta["site"]),
            ("Document number", meta["document_number"]), ("Revision", meta["revision"]), ("Issue purpose", meta["issue_purpose"]),
            ("Date", meta["date"]), ("Prepared by", meta["prepared_by"]), ("Planning horizon", horizon)]
    table = "<table><tbody>" + "".join(f"<tr><th>{esc(k)}</th><td>{esc(v)}</td></tr>" for k, v in rows if v) + "</tbody></table>"
    company = f'<div class="company">{esc(meta["consulting_company"])}</div>' if meta["consulting_company"] else ""
    return (f'<div class="cover">{logo}{company}'
            f'<div class="eyebrow">Technical report</div><h1>{esc(title)}</h1>'
            f'<div class="subtitle">Generation planning, optimization and design study<br>Recommended option: {esc(best_label)}</div>{table}'
            f'<div class="conf"><strong>Confidentiality.</strong> {esc(meta["confidentiality"])}</div></div>')


def control_html(meta, run_id, stamp):
    detail = [["Document number", meta["document_number"]], ["Project number", meta["project_number"]], ["Project", meta["project_name"]],
              ["Client", meta["client_name"]], ["Client contact", meta["client_contact"]], ["Consulting company", meta["consulting_company"]],
              ["Revision", meta["revision"]], ["Issue purpose", meta["issue_purpose"]], ["Date", meta["date"]],
              ["Source solve", f"{run_id} ({stamp:%Y-%m-%d %H:%M})"], ["Currency", currency.statement().replace("Monetary values are shown in ", "")]]
    ctl = R.table(["Item", "Detail"], [row for row in detail if row[1]])
    # Revision history keeps only the columns that have content.
    revision = [("Rev", meta["revision"]), ("Date", meta["date"]), ("Description", meta["revision_description"]),
                ("Prepared", meta["prepared_by"]), ("Reviewed", meta["reviewed_by"]), ("Approved", meta["approved_by"])]
    revision = [(h, v) for h, v in revision if v] if meta["revision"] or meta["revision_description"] else []
    revs = f"<h3>Revision history</h3>{R.table([h for h, _ in revision], [[v for _, v in revision]])}" if revision else ""
    people = [(role, name) for role, name in (("Prepared by", meta["prepared_by"]), ("Reviewed by", meta["reviewed_by"]),
                                              ("Approved by", meta["approved_by"])) if name]
    appr = ('<h3>Approvals</h3><table class="sig"><thead><tr><th>Role</th><th>Name</th><th>Signature</th><th>Date</th></tr></thead><tbody>'
            + "".join(f"<tr><td>{role}</td><td>{esc(name)}</td><td></td><td></td></tr>" for role, name in people)
            + "</tbody></table>") if people else ""
    return (f'<section class="frontmatter" id="doccontrol"><h2>Document control</h2><h3>Document details</h3>{ctl}'
            f"{revs}{appr}</section>")


def resolve_refs(body, numbers):
    return re.sub(r"@@sec:(\w+)@@", lambda m: numbers.get(m.group(1), "the relevant section"), body)


def build(run_id, meta_raw=None):
    meta = clean_meta(meta_raw)
    run = R.load_run(run_id)
    best, feasible = R.pick_best(run["results"], run["folder"])
    code = meta["scenario"] if meta["scenario"] in run["results"] else best
    chosen_feasible = feasible if code == best else R.is_feasible(run["results"][code])
    import explain
    try:
        info = explain.explain({"run_id": [run_id], "scenario": [code]})
    except Exception:
        info = None
    rel, sens = R.reliability_for(run["folder"], code), R.sensitivity_for(run["folder"])
    r = run["results"][code]
    planning = run["config"].get("planning") or {}
    stamp = datetime.datetime.fromtimestamp((run["folder"] / "status.json").stat().st_mtime)
    title = meta["project_name"] or "Generation planning study"
    risks = risk_register(run, code, rel, chosen_feasible)
    steps = next_steps(run, code, rel, sens)
    builders = {
        "exec": lambda: X.exec_section(run, code, best, chosen_feasible, info, rel, sens, risks, steps),
        "intro": lambda: intro_section(run, code, meta, best, feasible),
        "data": lambda: data_section(run, code),
        "basis": lambda: basis_section(run, code),
        "method": lambda: method_section(run, code),
        "results": lambda: results_section(run, code, best),
        "solution": lambda: solution_section(run, code, chosen_feasible),
        "economic": lambda: econ_section(run, code, info),
        "sensitivity": lambda: sens_section(run, code),
        "reliability": lambda: rel_section(run, code),
        "powerflow": lambda: pf_section(run, code, meta["detail"]),
        "design": lambda: design_section(run, code, meta["detail"]),
        "risk": lambda: risk_section(run, code, best, rel, chosen_feasible, risks),
        "conclusions": lambda: conclusions_section(run, code, best, feasible, rel, sens, steps),
        "app_inputs": lambda: app_inputs(run),
        "app_equations": lambda: equations_section(run),
        "app_quality": lambda: R.quality_section(run, code),
        "app_dispatch": lambda: R.week_charts(run["folder"], code, planning.get("start_year") or run["values"].get("start_year"),
                                              r["caps"].get("bess_mw", 0) > 1e-6) or R.notrun("Hourly dispatch was not saved for this scenario."),
        "app_glossary": lambda: R.table(["Term", "Meaning"], GLOSSARY),
        "app_refs": lambda: "<ol>" + "".join(f"<li>{esc(x)}</li>" for x in REFERENCES) + "</ol>",
    }
    titles = dict(SECTION_KEYS)
    appendix_titles = {"app_inputs": "Input parameters", "app_equations": "Key equations", "app_quality": "Data quality and cleaning log", "app_dispatch": "Dispatch charts",
                       "app_glossary": "Glossary and abbreviations", "app_refs": "References"}
    selected = [k for k, _ in SECTION_KEYS if k in meta["sections"]]
    numbers, order = {}, []
    main_n = app_n = 0
    for key in selected:
        if key.startswith("app_"):
            label_text = chr(65 + app_n)
            app_n += 1
            numbers[key] = f"Appendix {label_text}"
            order.append((key, label_text, appendix_titles[key], f"Appendix {label_text}"))
        else:
            main_n += 1
            numbers[key] = f"section {main_n}"
            order.append((key, str(main_n), titles[key], str(main_n)))
    lists = dict(toc=[], figures=[], tables=[])
    body = []
    for index, (key, label_text, title_text, shown) in enumerate(order, 1):
        lists["toc"].append((1, f"s{index}", shown if key.startswith("app_") else label_text, title_text if not key.startswith("app_") else title_text))
        takeaway = X.box(X.takeaways(key, run, code, best, chosen_feasible, rel, sens, risks)) if not key.startswith("app_") and key != "exec" else ""
        html_body = takeaway + builders[key]()
        content = number_section(index, label_text, title_text, html_body if key == "design" else R.plant_names(run, html_body), lists)
        heading = f"{shown}  {title_text}" if not key.startswith("app_") else f"{shown} &ndash; {esc(title_text)}"
        head_html = f'<h2><span class="num">{label_text}</span>{esc(title_text)}</h2>' if not key.startswith("app_") else f"<h2>{heading}</h2>"
        body.append(f'<section class="doc" id="s{index}">{head_html}{content}</section>')
    best_label = f"{code} - {r['name']}"
    front = (f'<section class="frontmatter" id="contents"><h2>Table of contents</h2>{toc_html(lists)}'
             f'<h3>List of figures</h3>{list_html(lists["figures"])}<h3>List of tables</h3>{list_html(lists["tables"])}</section>')
    document = cover_html(meta, title, run, code, best_label) + control_html(meta, run_id, stamp) + front + "".join(body)
    document = resolve_refs(document, numbers)
    when = datetime.datetime.now()
    ident = " ".join(x for x in (meta["document_number"], rev_label(meta)) if x)
    tail = " - ".join(x for x in (meta["consulting_company"], ident) if x)
    return (f'<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            f"<title>{esc(' - '.join(x for x in (title, meta['document_number'] or code, rev_label(meta)) if x))}</title>"
            f"<style>{STYLE}{page_css(meta, title)}</style></head><body><main>{round_text(document)}"
            f"<footer class='end'>{esc(tail + '. ' if tail else '')}"
            f"Generated by GenStudio on {when:%Y-%m-%d %H:%M}. Planning-level screening results; to save as PDF open this file in a browser and print (A4).</footer>"
            "</main></body></html>")
