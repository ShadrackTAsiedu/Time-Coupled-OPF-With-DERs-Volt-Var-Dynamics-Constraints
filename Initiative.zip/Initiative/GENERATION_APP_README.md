# GenStudio - Generation Planning Studio

GenStudio is a local decision-support application for planning the generation mix of a
campus, studio lot, industrial site or microgrid. From hourly load history and a growth guide it
builds a multi-year hourly demand forecast, finds the least-cost combination of solar PV, wind,
battery storage, fuel-based generators and grid supply with a chronological optimization
model, appraises each option financially and in carbon terms, checks the winner electrically
(AC power flow, N-1), produces a screening-level design with PSS/E RAW and single-line-diagram
exports, and writes client-ready reports.

Everything runs on your own computer. The browser interface talks only to a server bound to
`127.0.0.1`; there is no cloud solver and no data leaves the machine, except the public-data
downloads and map tiles that you explicitly request (see [Data sources](#data-sources-and-attribution)).

Contents: [Quick start](#quick-start) | [Workflow](#workflow-walkthrough) |
[Methods](#methods-and-formulation-summary) | [Defaults and cost basis](#assumptions-and-default-cost-basis) |
[Data formats](#input-data-formats) | [Data sources](#data-sources-and-attribution) |
[Solvers](#solvers-highs-and-gurobi) | [PSS/E](#psse-compatibility) | [Limitations](#limitations) |
[Troubleshooting](#troubleshooting) | [FAQ](#faq) | [Folders](#folder-structure) | [Testing](#testing) |
[Changelog](#versioning-and-changelog)

## Key features

| Area | Capability |
|---|---|
| Demand | Learns the hourly shape from historical files, then forecasts 1-15 years from a client annual-peak guide or a baseline/target growth model (five growth curves). Imports projected hourly demand directly. Every upload is integrity-checked and repaired with a visible change log. |
| Optimization | Chronological hourly least-cost capacity and dispatch over the forecast and an extended appraisal period (default 25 years): solar PV, wind, BESS, hydrogen / natural gas / diesel / biogas / biomass generators (turbine or CHP), grid import, optional export, existing and planned assets, land limits, optional operating constraints (minimum load, ramps, start-up) and an annual emissions cap. |
| Finance and carbon | NPC, incremental NPV, IRR, simple and discounted payback against a chosen baseline, whole-system levelized cost of supplied electricity, annual emissions. |
| Technical check | Balanced positive-sequence AC power flow (own Newton-Raphson) on each scenario's single-line diagram: critical hours plus N-1, PASS / WARN / FAIL, costed corrections and an automatic correction loop. |
| Design | Screening-level design of one chosen option: equipment schedule, protection summary, bill of materials, A3 single-line diagram (SVG), PSS/E v33 RAW. |
| Risk | Sensitivity (tornado, combined cases, P10 / P50 / P90 NPC) and contingency reliability (LOLE, EUE, cost of downtime, mitigation options). |
| Reporting | Client report (HTML / Word), Excel results, summary PDF, hourly CSV downloads, mathematical model documentation. |

## Quick start

Requirements: Windows, Python 3.10 or newer from [python.org](https://www.python.org/downloads/)
(with the `py` launcher; developed and tested on Python 3.14), and a modern Chromium-, Edge- or
Firefox-based browser.

1. Double-click **`GenStudio.cmd`**. It checks for Python and the packages, offers to install the
   missing ones (`py -3 -m pip install -r requirements.txt`), starts the server and opens
   <http://127.0.0.1:8765>. Keep that window open while you work; close it to stop the server.
   To use another port: `GenStudio.cmd 8766`.
2. Or start it manually:

   ```
   py -3 -m pip install -r requirements.txt
   py -3 generation_app.py --open-browser          # add --port 8766 to change the port
   ```
3. Open **Demand**, add a load profile (upload your CSVs, or use a public data source), review the
   inputs, then press **SOLVE**.

`requirements.txt` lists the runtime packages (numpy, scipy, highspy, matplotlib, openpyxl,
python-docx, lxml, pypdf). `requirements-dev.txt` adds Playwright for the browser tests and the
optional packages used by `download_solar_profile.py`. Gurobi is optional (see below).
A clean virtual environment built from `requirements.txt` starts the server and serves the
interface; the pinned versions are lower bounds, and the current release set (numpy 2.4,
scipy 1.18, highspy 1.15, matplotlib 3.11, openpyxl 3.1, python-docx 1.2, lxml 6.1, pypdf 6.2)
is what is exercised by the test suite.

## Workflow walkthrough

The four top menus (**Build Load Profile**, **Solve**, **Analyze**, **Results Summary**) plus
**Power Flow** and **Design** show one output pane at a time; every pane keeps its saved run
across reloads. The left **Model inputs** menu lists the categories (Scenarios, Demand,
Existing / Planned Generation, Grid and tariff, Microgrid with each technology, Financial,
Carbon emissions, Save and load). Inputs, uploaded profiles and diagram edits autosave in the
browser (IndexedDB); **Save inputs** commits at once and a write failure is reported explicitly.
Fractions are decimals (3 % = `0.03`); milestone growth percentages use `3` for 3 %.

1. **Scenarios.** Tick the eligible technologies per scenario. A checked technology may still
   receive zero capacity, so scenarios are menus of options, not forced investments. Omit
   Grid for a grid-independent case. `R0` is the upgraded-grid reference (existing plus planned
   projects, no additional optimized resource).
2. **Demand.** *Add load profile* asks whether to load a complete forecast or to generate one.
   Generate mode needs historical hourly files, a first operating year, a 1-15-year horizon, a growth
   mode and optional annual milestones. The uploaded data pass the automatic check (below).
   *Build load profile* creates the annual guide plot, one plot per year, the complete hourly CSV and
   a yearly-sheet Excel file.
3. **Existing / Planned Generation.** Committed assets (solar, wind, BESS, mobile trailers, efficiency
   programmes) with their commissioning dates. They reduce the net load the optimizer sees; their own
   CAPEX/OPEX is outside the optimized cost by design.
4. **Microgrid.** Total microgrid rating limits, per-technology cost, resource, lifetime and emissions
   inputs, and the **Topology / single-line diagram** editor (autodraw, wires, buses, substations,
   one-time connection costs, PSS/E-style electrical properties by double-click).
5. **Finance.** Tariff (blended or time-of-use, all-inclusive $/kWh, optional reactive-demand charge),
   inflation, discount rate, appraisal period, replacements, carbon price and emission factors.
6. **Solve.** Choose the solver method and confirm. The economic optimization runs first and the
   options are ranked by total NPC among scenarios that serve all load. If *Run technical power-flow
   check after solve* is on (default), every scenario is then screened electrically. The result page shows the economic
   table, then the technical check, then the dispatch graphs. A technically failing lowest-cost option is flagged, never
   hidden or re-ranked.
7. **Corrections loop.** *Apply corrections to all scenarios and re-solve* applies verified corrections
   (reactive support, transformer / line ratings, taps; it never lowers the maximum microgrid rating),
   re-solves, re-checks and re-ranks, for at most 3 iterations or until the recommended option
   is PASS or WARN. It stops if the same corrections would be applied again. The cost of applied
   corrections is added to that scenario's total NPC. Final state: `compliant` or `needs_manual_review`.
8. **Analyze.** Reads the saved solve (no re-dispatch): incremental NPV, IRR, payback, levelized cost,
   carbon tables and plots, plus the **Sensitivity** and **Reliability** sub-tabs.
9. **Power Flow.** Inspect any scenario at the peak, minimum-load, high-renewable or any chosen date/time
   on the single-line diagram (voltages, flows, loading, violations), edit electrical parameters, accept
   suggested corrections, export a PSS/E RAW file.
10. **Design.** Screening-level design of one option (default: the recommended one).
11. **Results Summary and reports.** Summary of the lowest-NPC fully supplied case, dispatch explorer
    (day, week, month, year or custom window), summary PDF, client report, Word and Excel exports.

Every solve is stored in its own `Application Runs\<run-id>` folder with exact inputs, resolved
settings, code and source hashes, validation findings and `worker.log`. A run can be bookmarked as
`?run=<run-id>`. Older runs keep the model and tariff assumptions they were solved with; rerun to
reprice. Only one solve runs at a time per server; **Stop** terminates only the server-owned worker
and marks the run `cancelled`.

### Automatic data check on upload

Every CSV chosen in the workflow (history, forecast, solar, wind, thermal) is checked locally by
`data_prep.py`. A usable file is used as is, silently. Otherwise a review dialog lists each issue,
the correction, a quality score, a before / after chart and the changed hours; optional repairs
(negatives, zero drop-outs, spikes) can be unticked. Detected automatically: delimiter, header,
date format (including separate date and time columns), time-zone suffixes, value column and units
(kW / MW / W, kWh, kW/m2, %). Corrected: duplicates averaged, sub-hourly data aggregated, gaps up to 3 h
interpolated and longer gaps filled from the same hour on neighbouring weeks or days, partial first
and last days trimmed, resources clipped to physical limits. Daily or monthly summaries are rejected.
Practice files are in `Data Preparation Samples\` (`py -3 make_messy_samples.py` recreates them).

## Methods and formulation summary

The full symbolic model (no project numbers) is in
`Model Documentation\GenStudio_Generic_Mathematical_Model_Revision_3.docx`
(`py -3 export_generic_mathematical_model.py`); `test_generic_mathematical_model.py` and
`test_math_validation.py` check equation identities and re-derive dispatch objectives independently.

### Demand forecast (`demand_forecasting.py`, `planning_inputs.py`)

* *Shape learning.* The historical month / day / hour pattern is normalized by the fitted yearly peak and
  scaled by the annual peak envelope of each forecast year, so every hourly mean, minimum and maximum grows,
  not only the peak. One year of history gives seasonality and schedules, not a defensible decade-long trend.
* *Client milestone mode.* Annual peak targets (absolute MW or year-on-year %) are interpolated (linear or
  shape-preserving cubic); the learned shape is normalized so each year's within-hour maximum equals its
  controlling target exactly.
* *Baseline / target mode.* With baseline `B`, target `T`, years to target `H`, `y` elapsed years and
  `u = min(y/H, 1)`: concave quadratic `B+(T-B)(2u-u^2)`, linear `B+(T-B)u`, compound `B(T/B)^u`,
  convex quadratic `B+(T-B)u^2`, smoothstep `B+(T-B)(3u^2-2u^3)`. The target is held after `H` years.
* *Projected mode.* An imported hourly demand file is used as gross load; planned efficiency and generation
  still apply. The **All hourly loads CSV** download is a valid import template.

### Optimization model (`optimize_generation_mix.py`, `solver_backend.py`)

* *Decision variables.* Installed MW of each eligible technology, BESS MW and MWh, hourly generator output,
  grid import (and export if enabled), BESS charge / discharge / state of charge, curtailment and unserved load.
* *Objective.* Minimize net present cost (NPC): upfront CAPEX + discounted annual fixed O&M, variable O&M,
  fuel, grid energy and reactive-demand charges, carbon price on direct emissions, scheduled
  replacements and the grid upgrade where required. Prices escalate at inflation, cash flows are
  discounted at the nominal discount rate. A finite shortfall priority ($100 million/MWh) discourages
  unserved load; it is not a cash cost and is excluded from reported NPC.
* *Constraints.* Hourly energy balance on the aggregate electrical bus; generator, PV and wind
  availability limits (with derate and degradation); BESS power, energy, 10-90 % state-of-charge band, round-trip
  efficiency, daily-cycle limit and no simultaneous charge / discharge; grid import / export limits;
  total microgrid minimum and maximum; land limits; islanded cases require generator headroom and
  battery reserve for within-hour peaks; optional minimum load / ramp / start-up and annual net-emissions cap.
* *Decomposition.* Capacities are chosen by a small capacity master problem; hourly dispatch is solved as
  one LP per month and returns dual cuts (Benders-style) to the master until the cost gap closes.
  Monthly battery state of charge is cyclic. When technology-owned connection costs are positive, the master is a MILP with
  binary activation variables (capacity <= maximum rating x activation).
* *Exactness.* Dispatch uses full foresight within a month. Monthly cyclic storage is a deliberate LP
  approximation of seasonal storage. A cycling preference is a tie-break, not binary exclusion. These
  approximations are listed in the model documentation.
* *Effective technology.* A technology whose dispatch is below 0.1 % of served energy is reported as unused; when a
  simpler scenario is within NPC tolerance, it is preferred (`workflow.effective_technologies`).
* *Outputs.* `result_<code>.json` with capacities, annual energy, NPC components, per-year cashflows and
  solver metadata; hourly dispatch CSV / NPZ.

### Financial and carbon metrics (`economic_metrics.py`, `scenario_analysis.py`, `lifecycle_costs.py`)

* Cash flows are nominal USD; CAPEX at year 0, annual costs at the end of each appraisal year, discounted at
  `(1+discount)^y`; prices escalate at `(1+inflation)^y`. No taxes, financing, grants or terminal value in the primary NPC.
* *Incremental NPV* = NPC(baseline) - NPC(scenario). Year-0 benefit = baseline investment (incl. upgrade) minus
  scenario investment; later years = baseline minus scenario cash cost. *IRR* is solved by Brent's method over
  -99.9 % to 100,000 % and withheld when there is no sign change, multiple sign changes or no root.
  *Payback* interpolates the cumulative cash flow; if the initial benefit is already non-negative (avoided
  upgrade) payback is shown as 0 with a non-conventional-investment warning and no IRR. Cases with unserved load
  have no equivalent-service NPV, IRR or payback.
* *Levelized cost* = cash NPC / discounted served net electrical MWh. It is a **whole-system** supplied-electricity
  cost (including grid imports and planned generation energy), not a standalone generator LCOE.
* *Replacements* occur at each service-life boundary (PV 30, BESS 15, generators 25, grid upgrade 40 years; screening
  values), costed at replacement fraction x original CAPEX with inflation; a replacement at the exact end of appraisal is omitted.
* *Emissions* = imports x grid factor + direct fuel CO2 + upstream hydrogen + entered operational factors; CHP avoided boiler CO2 is
  shown separately. Undiscounted, fixed factors.
* *Extended appraisal.* Beyond the explicit forecast, final-year demand and resources repeat by month / day / hour and the tail years
  are physically re-dispatched (not scaled).

### Power flow (`power_flow.py`, `pf_suggest.py`, `workflow.py`)

* Every SLD node is a bus; wires between different voltage levels are transformers, same-level wires are lines or cables, zero-length
  wires are ties. Own Newton-Raphson, balanced positive sequence (numpy / scipy), base-invariant.
* `screen_run` evaluates peak load, minimum load, maximum solar / wind, maximum BESS charge and discharge, maximum
  grid import, maximum generator output and maximum reverse flow, plus N-1 (each line, transformer and the largest generator)
  at the peak hour. Limits default to 0.95-1.05 pu (0.90-1.10 emergency), 100 % thermal.
* Corrections are verified by re-solving before being offered, with indicative costs: capacitor 25 $/kvar, reactor 20 $/kvar,
  transformer 12,000 $/MVA, line upgrade 40,000 $/MVA, added reactive capability 60 $/kvar (`power_flow.UNIT_COSTS`). They are costed after
  the LP, never inside it.
* *Why not AC power flow inside the optimizer:* it is non-convex, would destroy the LP duality used by the decomposition, and would
  multiply 8,760 x years of hourly solves. The architecture is LP / MILP dispatch -> AC screening of critical hours and N-1 -> costed corrections ->
  re-solve -> re-screen.
* All defaults (line r / x / b / ampacity per voltage class, transformer %Z and X/R, grid short-circuit MVA, power factors, Q limits)
  are in `power_flow.DEFAULTS`, shown in the UI Assumptions table with their basis, and overridable per component.

### Reliability (`reliability.py`)

Post-processing of a saved solve, no re-optimization. One resource (grid connection, one generator unit, BESS, PV, wind,
planned renewables) is removed or derated, an outage of D hours (default 8) starts at every hour of the saved year, and the
remaining resources are re-dispatched (renewables, grid, generators, BESS within power and state of charge). Incremental unserved
energy is measured against a no-contingency replay. Annual frequency is `forced outage rate x 8760 / D`; EUE = frequency x mean unserved
energy; downtime cost = EUE x VOLL (default $5,000/MWh) discounted over a present-value horizon (default 10 years). Status: PASS if LOLE <= 2.4 h/yr and no single
contingency loses load; WARN if LOLE <= 24 h/yr; FAIL otherwise. Mitigation options (standby generator, extra BESS, critical-load
shedding, demand response) are costed with editable parameters. Forced outage rates are screening values, not fleet statistics.

### Sensitivity (`sensitivity.py`)

Each case is a real re-optimization of the chosen scenario from the saved request (capacities may change). One-at-a-time sweeps give a
tornado of NPC; combined adverse and favourable cases cross-check it. Each low / high pair is read as the P10 / P90 of an independent,
approximately normal driver: `sd_i = (NPC_high - NPC_low) / (2 x 1.2816)`, portfolio `sd = sqrt(sum sd_i^2)`, P90 = base + 1.2816 sd. This ignores
correlation, asymmetry and non-linearity. Drivers: fuel, hydrogen and grid prices, carbon price, CAPEX of PV / BESS / wind / generators, discount rate,
load growth and level, solar and wind resource, mobile-trailer availability.

### Explanation (`explain.py`)

A cost waterfall walks from the reference NPC to the chosen scenario's NPC through the stored NPC components; any remainder is shown as
"Other / rounding".

## Assumptions and default cost basis

Defaults are **screening values to be replaced with project quotes**, not engineering certifications. Fuel-technology placeholders for
diesel, biogas and biomass are deliberately zero and unconfirmed, so those cases are not solve-ready until the user enters project data.

| Input | Default | Basis |
|---|---|---|
| Solar PV CAPEX / fixed O&M | $2,500,000/MW AC; 1 %/yr of CAPEX | [NREL ATB 2024](https://atb.nlr.gov/electricity/2024/commercial_pv) screening |
| Solar derate / degradation | 0.85 retained; 0.5 %/yr | generic screening values |
| BESS CAPEX | $400,000/MW + $250,000/MWh; 2.5 %/yr maintenance | [NREL ATB 2024](https://atb.nlr.gov/electricity/2024/utility-scale_battery_storage) screening |
| BESS operation | 85 % round trip, 10-90 % SOC, 1 cycle/day, duration up to 8 h | generic |
| Wind CAPEX / fixed O&M | $1,800,000/MW; 2.5 %/yr | screening |
| Natural gas turbine / CHP CAPEX | $2.0 m/MW / $3.1 m/MW; fuel $8/MMBtu HHV | [EPA CHP catalog](https://www.epa.gov/sites/default/files/2015-07/documents/catalog_of_chp_technologies_section_3._technology_characterization_-_combustion_turbines.pdf), [EIA gas prices](https://www.eia.gov/dnav/ng/ng_pri_sum_dcu_SCA_m.htm) |
| Hydrogen turbine / CHP CAPEX | $3.0 m/MW / $3.8 m/MW; fuel $6/kg | screening |
| Gas direct CO2 | 0.05306 t/MMBtu HHV | [EPA GHG Emission Factors Hub](https://www.epa.gov/climateleadership/ghg-emission-factors-hub) |
| Grid energy tariff | $0.0798/kWh all-inclusive (blended); reactive $0.66 x 1.045 /kVar-month at 0.37 kVar/kW | project bills; TOU placeholders equal the blended rate and are **not** contractual |
| Grid emissions factor | 0.20 t CO2e/MWh | analyst placeholder; replace with supplier data or [EPA eGRID](https://www.epa.gov/egrid) |
| Hydrogen upstream | 11 kg CO2e/kg H2 | midpoint of the IEA 10-12 range for unabated natural-gas hydrogen ([IEA Global Hydrogen Review 2024](https://www.iea.org/reports/global-hydrogen-review-2024/ghg-emissions-of-hydrogen-and-its-derivatives)); not green hydrogen |
| Carbon price | $100/t CO2 on direct combustion | screening |
| Inflation / discount | 3 % / 6 % nominal | screening |
| Appraisal period | 25 years, extended beyond the 1-15-year forecast | screening |
| Existing grid limit / upgraded reference | 40 MW / 50 MW; upgrade $70 m, 0.5 %/yr maintenance | project assumption (lump sum, not an engineering estimate) |
| Microgrid rating | 8-10 MW | project assumption |
| Land | no default footprints | user must supply site layout factors |

The default client annual peak guide runs from 33.34 MW (2026 baseline, observed interval peak 33.3442 MW) to a 45 MW plateau from 2033
(2027-2032 are approximate readings of the client curve: 34.5, 36, 37, 38, 41.5, 43.5 MW). All points are editable.

Solar resource convention: output = unit hourly resource x installed MW x derate x degradation; POA irradiance is divided by 1,000 W/m2 and
not clipped. Raw GHI is not accepted as tilted-array POA. Wind needs a verified `wind_per_mw` series in [0, 1], not wind speeds.

## Input data formats

| File | Columns |
|---|---|
| Historical or projected load | timestamp plus load in kW / MW (units detected); optional min / max columns; optional `heat_mwth`, solar columns |
| Solar resource | `timestamp,poa_irradiance_w_m2` or `timestamp,solar_per_mw` |
| Wind resource | `timestamp,wind_per_mw` (0-1) |
| Thermal | `timestamp,heat_mwth` |
| Client milestones | `year,peak_mw,growth_percent,description` (absolute peak or year-on-year %; 2026 must be an absolute positive peak) |

Ready-to-use inputs are in `Load Profile Inputs\`, `Solar Profile Inputs\` (Los Angeles PVGIS-ERA5 typical year, rebuilt by
`download_solar_profile.py`) and `Mobile Trailer Sources\`. Timestamps are local standard time without daylight saving unless an offset is set.

## Data sources and attribution

The **Get data from a public source / map** button opens a Leaflet / OpenStreetMap map (search, click or type coordinates). The downloaded
profile is previewed and then passes through the same automatic data check as an uploaded file.

| Data | Source |
|---|---|
| Solar | [NASA POWER](https://power.larc.nasa.gov/) hourly; [PVGIS-ERA5 / TMY](https://re.jrc.ec.europa.eu/pvg_tools/) (EU JRC); optional [NREL PVWatts v8](https://developer.nrel.gov/docs/solar/pvwatts/v8/) (own free key) |
| Wind | NASA POWER or PVGIS wind extrapolated to hub height (power law / log), generic 3 MW-class IEC I/II/III curves; reanalysis wind is smoothed - use site measurements for investment decisions |
| Weather / thermal | NASA POWER, PVGIS TMY (thermal profile is a degree-hour proxy) |
| Load (US) | [EIA-930](https://www.eia.gov/opendata/) by balancing authority (own free key); NREL ComStock / ResStock via OEDI; typical shapes; FCC Area API for county lookup |
| Map and search | OpenStreetMap tiles and Nominatim; (c) OpenStreetMap contributors, ODbL |

Licences and terms: NASA POWER open data (cite NASA POWER); PVGIS free reuse with attribution; NREL ComStock / ResStock CC BY 4.0; EIA public domain;
OpenStreetMap data ODbL, tile usage policy (descriptive User-Agent, tiles cached 7 days, limited concurrency) and Nominatim policy (at most 1 request per second);
Leaflet BSD-2-Clause. EIA and PVWatts keys are held in browser session memory only and sent per request, never stored or logged. Downloads are cached in
`Data Cache\` (tiles, raw API responses, datasets with provenance JSON: source, parameters, location, retrieval date, citation). The application needs network
access only for these downloads. Third-party software licences: see [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

## Solvers: HiGHS and Gurobi

* **HiGHS** (default, MIT licence, installed by `highspy`): three methods in the Solve dialog - dual simplex (recommended for repeated monthly LPs), interior point with crossover, and automatic.
  They are modes of one engine, not three products. The capacity master (LP or MILP) always runs on HiGHS.
* **Gurobi** (optional): `py -3 -m pip install gurobipy`, then activate a licence (`grbgetkey`). The Solver select offers Gurobi for the monthly dispatch LPs;
  the benders cut duals are Gurobi's reduced costs. `GET /api/x/solvers` reports availability. If `gurobipy` is missing, unlicensed or limited to
  the size-restricted licence (the check solves a model above 2,000 variables / constraints), GenStudio falls back to HiGHS and records the reason in the result's solver metadata.
  Academic or commercial licences are obtained from Gurobi; GenStudio does not distribute Gurobi.

## PSS/E compatibility

* **Export.** The Power Flow page and the Design tab write PSS/E **v33** RAW text (all sections in order, correct field counts, names up to 12 characters, bus numbers by convention:
  utility / HV 1001+, main MV 2001+, generation 3001+, loads 4001+, BESS 5001+). The Design RAW defaults to an equivalent plant model (one machine and one transformer per technology block);
  a detailed option writes every inverter, transformer and feeder.
* **Verification.** `psse_check.py` loads RAW files in PSS/E 35 (Python 3.11) or PSS/E 36 (Python 3.14), runs the topology and series-element checks and a full Newton-Raphson solve
  (`FNSL`). Exported cases were solved in PSS/E during development; run `py -3 psse_check.py file.raw` in your own installation (it requires a licensed PSS/E and is not part of the standard
  test suite). Differences from the GenStudio solver arise from default impedances, tap and shunt modelling.
* **Scope.** Positive-sequence steady-state data only; no dynamic data (`.dyr`), sequence data or short-circuit duty are written.

## Limitations

* Planning and screening tool, not a stamped design or a bankable financial model. Defaults must be replaced with project data before investment decisions.
* The optimizer uses an aggregate electrical bus, continuous sizing and full foresight within a month; there is no network-constrained dispatch (AC screening is post-solve),
  no probabilistic outage model inside the optimization, no taxes, incentives or financing.
* Planned and existing generation is excluded from optimized cost (listed in the NPC boundary notes). Planned assets' footprints are not charged to land limits.
* One year of history gives seasonality, not a trend; the 2027-2032 default guide points are approximate readings.
* Hourly resolution: within-hour peaks are handled by a demand-variation margin and a quarter-hour reserve convention; sub-hourly dispatch is not modelled.
* The power-flow screen is balanced positive sequence, N-1 at the peak hour only, aggregate technologies, typical (not manufacturer) data; no harmonics, protection coordination, dynamics or earthing design.
* Reanalysis solar / wind data are smoothed typical years, not observed weather of the labelled years.
* Reliability forced-outage rates and VOLL are screening inputs.

## Troubleshooting

| Symptom | Action |
|---|---|
| `py` is not recognized | Install Python 3.10+ from python.org with the *py launcher* option, reopen the terminal. |
| `ModuleNotFoundError` | `py -3 -m pip install -r requirements.txt` |
| Port 8765 in use | GenStudio may already be running at <http://127.0.0.1:8765>, or start another instance with `GenStudio.cmd 8766`. |
| Browser shows "Only local-host access is allowed" | Use `127.0.0.1` or `localhost` with the same port as the server; remote access is deliberately refused. |
| Page does not load or maps are blank | The server refuses other origins; maps need internet access for tiles (cached after first use). |
| Solve fails with a validation message | The message names the field; clicking it in the error list jumps to it. Technology cases with zero placeholders need project cost and efficiency and the confirm box. |
| Gurobi not used | Open the Solver select / `GET /api/x/solvers` for the reason (not installed, unlicensed, restricted licence). HiGHS is used instead. |
| Solve looks stuck | Long multi-scenario runs take minutes; progress is shown. Use **Stop** and see `Application Runs\<run>\worker.log`. |
| Unserved load appears | The scenario's technologies, microgrid rating or land cannot supply the full load: this is a result, not an error. |

## FAQ

**Is any data uploaded?** No. Data leave the machine only for the public-data and map downloads you request.
**Why is the cheapest option marked not compliant?** Ranking is economic; the technical status is a remark. Use the corrections loop or edit the design.
**Why is Hydrogen "not built" or "unused"?** The optimizer built nothing or dispatched it below 0.1 % of energy; it ties with a simpler scenario and the simpler one is recommended.
**Can I rely on the LCOE for a single technology?** No, it is a whole-system served-electricity cost; compare options by NPC.
**Can I compare a solved run after changing inputs?** Runs keep their own assumptions; re-solve to reprice.
**Does the app work offline?** Yes, except public-data downloads and uncached map tiles.

## Folder structure

| Path | Content |
|---|---|
| `generation_app.py`, `extensions.py` | HTTP server, API routes, extension registry |
| `optimize_generation_mix.py`, `solver_backend.py` | optimization model, HiGHS / Gurobi backends |
| `demand_forecasting.py`, `planning_inputs.py`, `planning_tariffs.py`, `scenario_inputs.py`, `resource_profiles.py`, `data_prep.py` | demand, tariffs, scenarios, resources, upload cleaning |
| `economic_metrics.py`, `scenario_analysis.py`, `lifecycle_costs.py`, `sensitivity.py`, `reliability.py`, `explain.py`, `dispatch_view.py` | analysis modules |
| `network_topology.py`, `power_flow.py`, `pf_suggest.py`, `workflow.py`, `design.py` | topology, AC screening, corrections, two-step workflow, design |
| `report.py`, `report_doc.py`, `summary_pdf.py`, `export_*.py` | reports and model documentation |
| `datasources.py` | public-data connectors, map proxy, cache |
| `generation_ui\` | browser interface (no inline scripts or styles; no CDNs; Leaflet bundled) |
| `Application Runs\` | one folder per solve (never overwritten) |
| `Data Cache\`, `Load Profile Inputs\`, `Solar Profile Inputs\`, `Mobile Trailer Sources\`, `Data Preparation Samples\` | cached downloads and sample / input data |
| `Forecast Results\`, `Generation Optimization Results\`, `Model Documentation\` | reference outputs of the original studies and model documents |
| `test_*.py` | test suite |

## Testing

```
py -3 -m pip install -r requirements-dev.txt
py -3 -m playwright install chromium          # browser tests only
py -3 -m unittest test_generation_app test_client_planning test_economic_metrics   # example subset
py -3 -m unittest discover -p "test_*.py"     # full suite (browser tests and long solves take many minutes)
```

Tests that need the reference run `Application Runs\7791be18470745f8af5ef34fa3d208f8` skip when it is absent; they copy it to temporary run folders and never modify it.
Browser tests start their own server on a random free port. Useful subsets: power flow `test_power_flow test_pf_params test_pf_raw2 test_power_flow_page`; reliability and sensitivity
`test_reliability test_sensitivity`; reports `test_report`; data sources `test_datasources` (mocked network); security `test_server_security`.

## Versioning and changelog

Application model version 7 (stored with each run as `application_version`). Each run also stores solver version, source hashes and settings.

* **Current** - Two-step workflow (economic solve, technical check, corrections loop); effective-technology ranking; optional Gurobi backend with HiGHS fallback; PSS/E-style
  properties dialog, bus numbering and RAW fixes; equivalent-model Design RAW; reordered input menu with technologies under Microgrid; public data sources with map.
* **Earlier** - Chronological generation-mix optimization, client milestones and planned assets, topology editor, wind, existing / planned split, automatic data check, financial
  and carbon analysis, sensitivity, reliability, power flow, Design tab, reports.

## Licence

GenStudio itself is distributed under the licence chosen by its owner (none is bundled). Third-party components and their licences are listed in
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
