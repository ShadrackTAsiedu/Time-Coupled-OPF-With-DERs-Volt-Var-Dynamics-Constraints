import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import generation_app as app
import power_flow
import workflow
from test_qa_optimizer import values


def result(code, npc, status=None, fix=None, feasible=True, name=None, **extra):
    r = dict(code=code, name=name or code, economics=dict(npc=npc),
             adequacy=dict(unserved_hours=0 if feasible else 3, unserved_mwh=0 if feasible else 10, stress_unserved_mwh=0))
    if status:
        r["technical_status"] = dict(status=status, violations=[], suggestions=extra.pop("suggestions", []))
    if fix is not None:
        r["compliance_cost"] = dict(total_usd=fix, items=[])
    r.update(extra)
    return r


def ranked(results):
    return workflow.rank([workflow.entry_from(r, i) for i, r in enumerate(results)])


class RankTests(unittest.TestCase):
    def test_economic_ranking_when_unchecked(self):
        entries, rec = ranked([result("A", 100), result("B", 90)])
        self.assertEqual(rec["code"], "B")
        self.assertEqual(rec["basis"], "economic")
        self.assertEqual({e["code"]: e["adjusted_npc"] for e in entries}, dict(A=100, B=90))
        self.assertEqual(rec["banner"], "")

    def test_adjusted_npc_is_informational_only(self):
        entries, rec = ranked([result("A", 100, "PASS", 0), result("B", 90, "PASS", 25)])
        self.assertEqual(rec["code"], "B")
        self.assertEqual(rec["adjusted_npc"], 115)
        self.assertEqual({e["code"]: e["economic_rank"] for e in entries}, dict(A=2, B=1))

    def test_tie_prefers_lower_raw_then_order(self):
        _, rec = ranked([result("A", 100, "PASS", 0), result("B", 90, "PASS", 10)])
        self.assertEqual(rec["code"], "B")
        _, rec = ranked([result("A", 100, "PASS", 0), result("B", 100, "PASS", 0)])
        self.assertEqual(rec["code"], "A")

    def test_failing_cheapest_still_wins_with_banner(self):
        entries, rec = ranked([result("A", 100, "PASS", 0), result("B", 80, "FAIL", 50)])
        self.assertEqual(rec["code"], "B")
        self.assertEqual(rec["technical_status"], "FAIL")
        self.assertFalse(rec["compliant"])
        self.assertIn("Lowest-cost option, not yet technically compliant", rec["banner"])
        self.assertIn("Apply the corrections to continue.", rec["banner"])
        self.assertEqual(len(entries), 2)

    def test_warn_banner_is_not_a_failure_message(self):
        _, rec = ranked([result("A", 100, "WARN", 5)])
        self.assertTrue(rec["compliant"])
        self.assertNotIn("not yet technically compliant", rec["banner"])
        self.assertIn("passes the technical check", rec["banner"])

    def test_cheaper_failing_beats_expensive_grid(self):
        _, rec = ranked([result("R0", 217, "WARN", 0, reference=True), result("NG", 149, "FAIL", 1.0), result("S1", 142, "FAIL", 0, feasible=False)])
        self.assertEqual(rec["code"], "NG")

    def test_applied_cost_enters_total_npc(self):
        a = result("A", 100, "PASS", 0)
        b = result("B", 95, "PASS", 0, applied_corrections=dict(total_usd=10, items=[]))
        entries, rec = ranked([a, b])
        self.assertEqual(rec["code"], "A")
        self.assertEqual({e["code"]: e["total_npc"] for e in entries}, dict(A=100, B=105))

    def test_unsupplied_scenario_does_not_win(self):
        _, rec = ranked([result("A", 100), result("B", 50, feasible=False)])
        self.assertEqual(rec["code"], "A")

    def test_empty(self):
        self.assertEqual(workflow.rank([])[1]["code"], None)


class DecideTests(unittest.TestCase):
    def rec(self, status="PASS"):
        return dict(code="B", technical_status=status)

    def test_winner_changed_banner(self):
        d = workflow.decide("A", [], self.rec())
        self.assertTrue(d["winner_changed"])
        self.assertIn("New optimum B selected; it was technically checked: PASS", d["banner"])
        self.assertEqual(d["action"], "stop")
        self.assertEqual(d["final_status"], "compliant")

    def test_iterates_on_failure_until_cap(self):
        for i, expected in ((0, "iterate"), (2, "iterate"), (3, "stop")):
            d = workflow.decide("A", [], self.rec("FAIL"), iteration=i, fixable=True)
            self.assertEqual(d["action"], expected, i)
        self.assertIn("cap", d["reason"])
        self.assertEqual(d["final_status"], "needs_manual_review")
        self.assertIn("needs manual review", d["banner"])

    def test_stop_conditions(self):
        self.assertIn("user", workflow.decide("A", [], self.rec("FAIL"), 0, True, stopped=True)["reason"])
        self.assertEqual(workflow.decide("A", [], self.rec("FAIL"), 0, False)["action"], "stop")

    def test_stops_when_corrections_repeat(self):
        d = workflow.decide("B", [], self.rec("FAIL"), 1, True, history=[dict(sig="x")], signature="x")
        self.assertEqual(d["action"], "stop")
        self.assertIn("no further progress", d["reason"])
        d = workflow.decide("B", [], self.rec("FAIL"), 1, True, history=[dict(sig="x")], signature="y")
        self.assertEqual(d["action"], "iterate")

    def test_warn_is_compliant(self):
        self.assertEqual(workflow.decide("B", [], self.rec("WARN"), 1, True)["action"], "stop")

    def test_unfixable_failure_points_to_the_actionable_advisory(self):
        adv = [dict(key="microgrid_max_mw", current=10, suggested=11, actionable=True)]
        d = workflow.decide("B", [], self.rec("FAIL"), 0, False, advisories=adv)
        self.assertEqual(d["action"], "stop")
        self.assertIn("microgrid_max_mw 10 -> 11", d["reason"])
        self.assertIn("apply it below", d["reason"])


class AdvisoryTests(unittest.TestCase):
    def sugg(self, current, suggested):
        return dict(target=dict(kind="field", key="microgrid_max_mw"), current=current, suggested=suggested, reason="needs more")

    def test_only_raising_the_maximum_is_actionable(self):
        up = workflow.range_advisories(dict(code="P1", suggestions=[self.sugg(10, 11)]))
        self.assertEqual([a["actionable"] for a in up], [True])
        self.assertEqual(workflow.range_advisories(dict(code="P1", suggestions=[self.sugg(10, 8)])), [])


class IslandedEntryTests(unittest.TestCase):
    def test_islanded_result_never_changes_status_or_ranking(self):
        chip = "Islanded: would not be self-supportable (needs 43.1 MW grid-forming vs 3.3 MW)"
        plain = result("A", 100, "PASS")
        flagged = result("A", 100, "PASS")
        flagged["technical_status"]["islanded"] = dict(chip=chip, status="NOT_SUPPORTABLE")
        e_plain, rec_plain = ranked([plain, result("B", 120, "PASS")])
        e_flag, rec_flag = ranked([flagged, result("B", 120, "PASS")])
        self.assertEqual(rec_plain["code"], rec_flag["code"])
        self.assertEqual(e_flag[0]["technical_status"], "PASS")
        self.assertEqual(e_flag[0]["islanded"]["chip"], chip)


class CompareTests(unittest.TestCase):
    def test_deltas(self):
        before, _ = ranked([result("A", 100, "PASS", 0), result("B", 90, "PASS", 5)])
        after, _ = ranked([result("A", 100, "PASS", 0), result("B", 95, "PASS", 5, overrides=dict(ng_capex=1))])
        rows = {r["code"]: r for r in workflow.compare(before, after)}
        self.assertEqual(rows["B"]["npc_delta"], 5)
        self.assertEqual(rows["B"]["adjusted_delta"], 5)
        self.assertEqual(rows["A"]["npc_delta"], 0)
        self.assertEqual(rows["B"]["changes"], dict(ng_capex=1))

    def test_fixable_overrides_filters(self):
        entry = dict(suggestions=[
            dict(target=dict(kind="field", key="microgrid_max_mw"), recommended=True, suggested=12),
            dict(target=dict(kind="field", key="demand_scale"), recommended=True, suggested=1),
            dict(target=dict(kind="field", key="soc_min"), recommended=True, suggested=0.1),
            dict(target=dict(kind="node", key="x"), recommended=True, suggested=1),
            dict(target=dict(kind="field", key="ng_capex"), recommended=False, suggested=1)])
        self.assertEqual(workflow.fixable_overrides(entry), dict(soc_min=0.1))

    def test_delta_is_split_into_model_and_corrections_effect(self):
        before, _ = ranked([result("A", 150.0, "FAIL", 0)])
        after, _ = ranked([result("A", 145.0, "WARN", 0, applied_corrections=dict(total_usd=0.4, items=[dict(label="Shunt bank", cost_usd=0.4)]))])
        row = workflow.compare(before, after)[0]
        self.assertAlmostEqual(row["model_effect"], -5.0)
        self.assertAlmostEqual(row["corrections_effect"], 0.4)
        self.assertAlmostEqual(row["total_after"] - row["total_before"], row["model_effect"] + row["corrections_effect"])

    def test_identified_corrections_include_applied_and_still_required(self):
        e = workflow.entry_from(result("A", 100, "WARN", 5, applied_corrections=dict(total_usd=7, items=[dict(label="Shunt", cost_usd=7)])))
        self.assertEqual(e["identified_cost_usd"], 12)
        self.assertEqual([i["state"] for i in e["identified_items"]], ["applied"])
        e = workflow.entry_from(dict(result("A", 100, "WARN"), compliance_cost=dict(total_usd=5, items=[dict(label="Line", cost_usd=5)])))
        self.assertEqual((e["identified_cost_usd"], e["identified_items"][0]["state"]), (5, "still required"))

    def test_readable_run_labels(self):
        self.assertTrue(workflow.run_label(0, "z" * 32).startswith("Run 0 - Initial solve"))
        self.assertTrue(workflow.run_label(1, "z" * 32).startswith("Run 1 - Corrections applied"))
        self.assertNotIn("zzzz", workflow.run_label(2, "z" * 32))
        row = workflow._iteration_row(1, "z" * 32, dict(code="A"), "s")
        self.assertTrue(row["label"].startswith("Run 1"))

    def test_model_changes_flag_different_fingerprints(self):
        with tempfile.TemporaryDirectory() as tmp:
            runs = {}
            for rid, topo in (("a" * 32, "1"), ("b" * 32, "2")):
                (Path(tmp) / rid).mkdir()
                (Path(tmp) / rid / "run_configuration.json").write_text(json.dumps(dict(topology_sha256=topo, engine_sha256="e")), encoding="utf-8")
                runs[rid] = Path(tmp) / rid
            with mock.patch.object(workflow.extensions, "run_folder", side_effect=lambda r: runs[r]):
                self.assertEqual(workflow.model_changes("a" * 32, "b" * 32), ["network topology"])
                self.assertEqual(workflow.model_changes("a" * 32, "a" * 32), [])


class ValidationTests(unittest.TestCase):
    defs = [dict(id="R0", name="Ref", technologies=["grid"], reference=True),
            dict(id="G", name="NG", technologies=["grid", "ng"])]

    def request(self, overrides, **extra):
        defs = [dict(d) for d in self.defs]
        defs[1]["overrides"] = overrides
        return dict(values=values(), scenarios=["R0", "G"], scenario_definitions=defs, planned_generation=[], **extra)

    def test_valid_override_kept(self):
        out = app.validate_request(self.request(dict(microgrid_max_mw=5)))
        self.assertEqual([d for d in out["scenario_definitions"] if d["id"] == "G"][0]["overrides"], dict(microgrid_max_mw=5))
        self.assertTrue(out["technical_check"])

    def test_islanded_option_defaults_off_and_must_be_boolean(self):
        self.assertFalse(app.validate_request(self.request({}))["technical_islanded"])
        self.assertTrue(app.validate_request(self.request({}, technical_islanded=True))["technical_islanded"])
        with self.assertRaises(ValueError):
            app.validate_request(self.request({}, technical_islanded="yes"))

    def test_request_without_grid_only_reference_is_valid(self):
        defs = [dict(id="P1", name="PV", technologies=["grid", "pv"])]
        out = app.validate_request(dict(values=values(), scenarios=["P1"], scenario_definitions=defs, planned_generation=[]))
        self.assertIsNone(out["comparison_reference"])
        self.assertEqual([d["id"] for d in out["scenario_definitions"]], ["P1"])

    def test_bad_key_rejected(self):
        with self.assertRaises(ValueError):
            app.validate_request(self.request(dict(demand_scale=2)))

    def test_min_above_max_rejected(self):
        with self.assertRaises(ValueError):
            app.validate_request(self.request(dict(microgrid_min_mw=9, microgrid_max_mw=3)))

    def test_workflow_cleaned_and_capped(self):
        out = app.validate_request(self.request({}, technical_check=False,
                                                workflow=dict(base_run="a" * 32, iteration=99, evil="x")))
        self.assertFalse(out["technical_check"])
        self.assertEqual(out["workflow"]["max_iterations"], 3)
        self.assertNotIn("evil", out["workflow"])


class FinalizeTests(unittest.TestCase):
    def make(self, d):
        folder = Path(d) / ("d" * 32)
        folder.mkdir()
        return folder

    def test_finalize_with_stubbed_power_flow(self):
        statuses = dict(A=dict(status="PASS", violations=[], suggestions=[]),
                        B=dict(status="WARN", violations=[], suggestions=[]))
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(power_flow, "screen_scenario", lambda run, code, overrides=None: statuses[code], create=True), \
                mock.patch.object(power_flow, "compliance_cost",
                                  lambda run, code, applied: dict(total_usd=25.0 if code == "B" else 0.0, items=[]), create=True):
            folder = self.make(d)
            results = [result("A", 100), result("B", 90)]
            workflow.finalize(folder, dict(technical_check=True), results)
            data = json.loads((folder / "workflow.json").read_text(encoding="utf-8"))
        self.assertEqual(data["recommended"]["code"], "B")
        self.assertEqual({s["code"]: s["adjusted_npc"] for s in data["scenarios"]}, dict(A=100, B=115))
        self.assertEqual({s["code"]: s["economic_rank"] for s in data["scenarios"]}, dict(A=2, B=1))
        self.assertEqual([s["technical_status"] for s in data["scenarios"]], ["PASS", "WARN"])

    def test_finalize_without_check_is_raw(self):
        with tempfile.TemporaryDirectory() as d:
            folder = self.make(d)
            workflow.finalize(folder, dict(technical_check=False), [result("A", 100), result("B", 90)])
            data = json.loads((folder / "workflow.json").read_text(encoding="utf-8"))
        self.assertEqual(data["recommended"]["code"], "B")
        self.assertFalse(data["technical_check"])
        self.assertTrue(all(s["technical_status"] == "NOT_RUN" for s in data["scenarios"]))

    def test_absent_compliance_cost_falls_back_to_raw(self):
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(power_flow, "screen_scenario", lambda *a, **k: dict(status="FAIL"), create=True), \
                mock.patch.object(power_flow, "compliance_cost", side_effect=RuntimeError("boom"), create=True):
            folder = self.make(d)
            workflow.finalize(folder, dict(technical_check=True), [result("A", 100), result("B", 90)])
            data = json.loads((folder / "workflow.json").read_text(encoding="utf-8"))
        self.assertEqual(data["recommended"]["code"], "B")
        self.assertTrue(all(not s["costed"] for s in data["scenarios"]))


class WorkerTest(unittest.TestCase):
    def test_rerun_with_per_scenario_override_resolves_all(self):
        defs = [dict(id="R0", name="Ref", technologies=["grid"], reference=True),
                dict(id="G", name="NG", technologies=["grid", "ng"], overrides=dict(microgrid_max_mw=1e6))]
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d) / ("e" * 32)
            folder.mkdir()
            request = dict(values=values(grid_limit=0), scenarios=["R0", "G"], scenario_definitions=defs,
                           planned_generation=[], technical_check=False)
            (folder / "request.json").write_text(json.dumps(request), encoding="utf-8")
            app.worker(folder)
            status = json.loads((folder / "status.json").read_text(encoding="utf-8"))
            self.assertEqual(status["state"], "complete", status.get("message"))
            self.assertEqual(len(status["summary"]["results"]), 2)
            data = json.loads((folder / "workflow.json").read_text(encoding="utf-8"))
        self.assertEqual({s["code"] for s in data["scenarios"]}, {"R0", "G"})
        self.assertEqual([s for s in data["scenarios"] if s["code"] == "G"][0]["overrides"], dict(microgrid_max_mw=1e6))


if __name__ == "__main__":
    unittest.main()
