import json
import shutil
import unittest
from pathlib import Path

import numpy as np

import extensions
import reliability as rel

HERE = Path(__file__).resolve().parent
SANDBOX = HERE / "_reliability_test_runs"
RUN_ID = "ab" * 16
REAL_RUN = HERE / "Application Runs" / "25253846a35d4d2583767b43da6bd098"


def make_ctx(load, grid=0.0, gens=None, bess_mw=0.0, bess_mwh=0.0, pv=0.0, planned=0.0, soc=0.0, hours=8, **over):
    n = len(load)
    arr = lambda v: np.full(n, float(v)) if np.isscalar(v) else np.asarray(v, float)
    d = dict(ts=[f"2030-01-{1 + i // 24:02d} {i % 24:02d}:00:00" for i in range(n)], year=np.full(n, 2030),
             load=arr(load), pv=arr(pv), wind=np.zeros(n), planned=arr(planned), soc=arr(soc), shortfall=np.zeros(n))
    a = dict(grid=grid, gens=gens or {}, bess_mw=bess_mw, bess_mwh=bess_mwh, pv_mw=float(np.max(d["pv"])),
             soc_min=0.0, soc_max=1.0, eff=1.0)
    p = rel.defaults()
    p["outage_hours"] = hours
    p.update(over)
    return rel.make_ctx(d, a, p, hours)


def spec(**kw):
    return dict(id="x", name="x", rate=.05, lost_mw=10, **kw)


class ContingencySimulation(unittest.TestCase):
    def test_single_gen_lost_no_other_supply(self):
        ctx = make_ctx(np.full(48, 10.0), gens={"g": 10.0})
        res = rel.run_contingency(ctx, spec(gens={"g": 0.0}))
        self.assertTrue(np.allclose(res["mwh"], 80))          # 10 MW x 8 h
        self.assertTrue(np.allclose(res["hrs"], 8))
        self.assertTrue(np.allclose(res["peak"], 10))
        ex = rel.expected(ctx, res, .05)
        self.assertAlmostEqual(ex["lam"], .05 * 8760 / 8)       # 54.75 events/yr
        self.assertAlmostEqual(ex["eue"][0], 4380.0)            # 54.75 x 80 MWh
        self.assertAlmostEqual(ex["eue"][0] * 5000, 21_900_000.0)

    def test_event_cost_is_80_mwh_times_voll(self):
        ctx = make_ctx(np.full(48, 10.0), gens={"g": 10.0})
        res = rel.run_contingency(ctx, spec(gens={"g": 0.0}))
        self.assertAlmostEqual(res["mwh"].max() * ctx["p"]["voll"], 400_000.0)

    def test_redundant_supply_means_no_unserved(self):
        ctx = make_ctx(np.full(48, 10.0), grid=10.0, gens={"g": 10.0})
        self.assertEqual(rel.run_contingency(ctx, spec(gens={"g": 0.0}))["mwh"].max(), 0)
        self.assertEqual(rel.run_contingency(ctx, spec(grid=0.0))["mwh"].max(), 0)

    def test_derate_to_half(self):
        ctx = make_ctx(np.full(48, 10.0), gens={"g": 10.0})
        res = rel.run_contingency(ctx, spec(gens={"g": .5}))
        self.assertTrue(np.allclose(res["mwh"], 40))

    def test_battery_energy_limit(self):
        # grid lost; 5 MW / 20 MWh battery: 4 h at 5 MW short, then 4 h at 10 MW short = 20 + 40
        ctx = make_ctx(np.full(48, 10.0), grid=10.0, bess_mw=5.0, bess_mwh=20.0, soc=20.0)
        res = rel.run_contingency(ctx, spec(grid=0.0))
        self.assertTrue(np.allclose(res["mwh"][1:30], 60))
        self.assertTrue(np.allclose(res["hrs"][1:30], 8))
        self.assertTrue(np.allclose(res["peak"][1:30], 10))

    def test_battery_loss_with_grid_short_of_load(self):
        # 8 MW grid + 2 MW battery cover 10 MW; losing the battery leaves 2 MW short for 8 h
        ctx = make_ctx(np.full(48, 10.0), grid=8.0, bess_mw=2.0, bess_mwh=100.0, soc=100.0)
        self.assertEqual(ctx["base_short"].sum(), 0)
        res = rel.run_contingency(ctx, spec(bess=0.0))
        self.assertTrue(np.allclose(res["mwh"], 16))

    def test_pv_counts_in_dispatch_and_pv_loss_removes_it(self):
        ctx = make_ctx(np.full(48, 10.0), gens={"g": 6.0}, pv=4.0)
        self.assertEqual(rel.run_contingency(ctx, spec(gens={"g": 1.0}))["mwh"].max(), 0)
        self.assertTrue(np.allclose(rel.run_contingency(ctx, spec(gens={"g": 0.0}))["mwh"], 48))   # 6 MW x 8 h
        self.assertTrue(np.allclose(rel.run_contingency(ctx, spec(pv=0.0))["mwh"], 32))            # 4 MW x 8 h

    def test_planned_generation_loss_returns_load(self):
        ctx = make_ctx(np.full(48, 6.0), grid=6.0, planned=3.0)
        res = rel.run_contingency(ctx, spec(planned=0.0))
        self.assertTrue(np.allclose(res["mwh"], 24))

    def test_baseline_shortfall_is_not_charged_to_contingency(self):
        # grid limit 8 MW against 10 MW load: 2 MW is already unserved; losing the grid adds only the other 8 MW x 8 h
        ctx = make_ctx(np.full(48, 10.0), grid=8.0)
        self.assertTrue(np.allclose(ctx["base_short"], 2))
        res = rel.run_contingency(ctx, spec(grid=0.0))
        self.assertTrue(np.allclose(res["mwh"], 64))

    def test_load_shedding_and_demand_response_reduce_unserved(self):
        ctx = make_ctx(np.full(48, 10.0), gens={"g": 10.0})
        res = rel.run_contingency(ctx, spec(gens={"g": 0.0}), dict(reduce=.3))
        self.assertTrue(np.allclose(res["mwh"], 56))             # 7 MW x 8 h still unserved
        self.assertTrue(np.allclose(res["shed"], 24))            # 3 MW x 8 h shed

    def test_standby_generator_removes_downtime(self):
        ctx = make_ctx(np.full(48, 10.0), gens={"g": 10.0})
        self.assertTrue(np.allclose(rel.run_contingency(ctx, spec(gens={"g": 1.0}), dict(reduce=.3))["shed"], 0))  # no need, no shedding
        res = rel.run_contingency(ctx, spec(gens={"g": 0.0}), dict(gen_mw=10.0))
        self.assertEqual(res["mwh"].max(), 0)

    def test_extra_battery_starts_full(self):
        ctx = make_ctx(np.full(48, 10.0), gens={"g": 10.0})
        res = rel.run_contingency(ctx, spec(gens={"g": 0.0}), dict(bess_mw=10.0, bess_mwh=40.0))
        self.assertTrue(np.allclose(res["mwh"], 40))             # 40 MWh delivered of 80 needed

    def test_window_trace_balances(self):
        ctx = make_ctx(np.full(48, 10.0), grid=10.0, bess_mw=5.0, bess_mwh=20.0, soc=20.0)
        rows = rel.trace(ctx, spec(grid=0.0), 3)
        self.assertEqual(len(rows), 8)
        for r in rows:
            supply = r["pv_wind_mw"] + r["grid_mw"] + r["gen_mw"] + r["bess_discharge_mw"] + r["unserved_mw"]
            self.assertAlmostEqual(supply, r["load_mw"])
        self.assertAlmostEqual(sum(r["extra_unserved_mw"] for r in rows), 60)

    def test_worst_window_found_in_varying_load(self):
        load = np.full(48, 2.0)
        load[20:24] = 10.0
        ctx = make_ctx(load, gens={"g": 10.0})
        res = rel.run_contingency(ctx, spec(gens={"g": 0.0}))
        self.assertAlmostEqual(res["mwh"].max(), 4 * 10 + 4 * 2)  # a window holding the whole 4 h peak plus 4 quiet hours
        self.assertTrue(res["mwh"][int(np.argmax(res["mwh"]))] >= res["mwh"].max())

    def test_present_value_factor(self):
        self.assertAlmostEqual(rel.pv_series([100.0], .10, 2), 100 / 1.1 + 100 / 1.21)

    def test_pv_helper_removed_and_criteria_covers_all_resources(self):
        self.assertFalse(hasattr(rel, "pv_factor"))
        self.assertIn("planned", rel.CRITERIA)

    def test_copt_two_units(self):
        levels, prob = rel.copt([(10, .1), (10, .1)])
        self.assertTrue(np.allclose(levels, [0, 10, 20]))
        self.assertTrue(np.allclose(prob, [.01, .18, .81]))


class EndToEnd(unittest.TestCase):
    def setUp(self):
        self.old = extensions.RUNS
        extensions.RUNS = SANDBOX
        run = SANDBOX / RUN_ID
        run.mkdir(parents=True, exist_ok=True)
        (run / "status.json").write_text("{}", encoding="utf-8")
        (run / "run_configuration.json").write_text(json.dumps(dict(resolved=dict(
            grid_limit=0, discount=.06, soc_min=0, soc_max=1, round_trip_efficiency=1))), encoding="utf-8")
        (run / "result_G1.json").write_text(json.dumps(dict(name="Gen only", caps=dict(
            pv_dc_mw=0, bess_mw=0, bess_mwh=0, generators_mw=dict(ng=10.0)))), encoding="utf-8")
        rows = ["timestamp,net_load_mw,soc,shortfall,pv,planned_renewable,gen_ng"]
        for i in range(48):
            rows.append(f"2030-01-{1 + i // 24:02d} {i % 24:02d}:00:00,10,0,0,0,0,10")
        (run / "dispatch_G1.csv").write_text("\n".join(rows), encoding="utf-8")

    def tearDown(self):
        extensions.RUNS = self.old
        shutil.rmtree(SANDBOX, ignore_errors=True)

    def test_route_unserved_and_cost(self):
        out = rel.analyse(dict(run_id=RUN_ID, scenario="G1", outage_hours=8, voll=5000, gen_for=.05, gen_derate_for=0))
        r = out["results"][0]
        loss = next(c for c in r["contingencies"] if c["id"] == "gen_loss_ng")
        self.assertAlmostEqual(loss["worst_event_mwh"], 80)
        self.assertEqual(loss["worst_event_hours"], 8)
        self.assertAlmostEqual(loss["worst_event_mwh"] * 5000, 400_000)
        self.assertAlmostEqual(loss["eue_mwh_yr"], 4380)
        self.assertAlmostEqual(loss["cost_yr"], 4380 * 5000)
        self.assertEqual(r["verdict"], "FAIL")
        self.assertTrue((SANDBOX / RUN_ID / "reliability" / "G1.json").is_file())
        saved = rel.saved(dict(run_id=[RUN_ID]))
        self.assertEqual(saved["comparison"][0]["scenario"], "G1")
        self.assertTrue(any(m["id"] == "standby_n1" and m["covers_worst_case"] for m in r["measures"]))

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            rel.analyse(dict(run_id=RUN_ID, scenario="G1", voll=-1))
        with self.assertRaises(ValueError):
            rel.analyse(dict(run_id=RUN_ID, scenario="nope"))
        with self.assertRaises(ValueError):
            rel.analyse(dict(run_id=RUN_ID, scenario="G1", outage_hours=100))


@unittest.skipUnless(REAL_RUN.is_dir(), "saved sample run not present")
class RealRunSmoke(unittest.TestCase):
    def test_scenarios_run_and_replay_matches_optimizer(self):
        p = rel.parse_params({})
        for code in ("R0", "S1", "NG"):
            r = rel.analyse_scenario(REAL_RUN, code, p)
            check = r["model_check"]
            self.assertAlmostEqual(check["replay_unserved_mwh"], check["saved_unserved_mwh"],
                                   delta=max(1.0, .02 * check["saved_unserved_mwh"]))
            self.assertIn(r["verdict"], ("PASS", "WARN", "FAIL"))
            self.assertTrue(r["contingencies"])


if __name__ == "__main__":
    unittest.main()
