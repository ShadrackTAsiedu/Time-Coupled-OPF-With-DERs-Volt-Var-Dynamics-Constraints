"""Browser tests for the Power Flow page (verification card, SLD labels/colours, tables, charts, validation) on a copy of a saved run."""
import shutil
import socket
import subprocess
import sys
import time
import unittest
from pathlib import Path
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
SRC = ROOT / "Application Runs" / "7791be18470745f8af5ef34fa3d208f8"
COPY = "c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0"

try:
    from playwright.sync_api import sync_playwright
except ImportError:  # pragma: no cover
    sync_playwright = None


@unittest.skipUnless(sync_playwright and Path(EDGE).exists() and SRC.exists(), "Edge/Playwright or the reference run is unavailable")
class PowerFlowPageBrowser(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dst = ROOT / "Application Runs" / COPY
        if cls.dst.exists():
            shutil.rmtree(cls.dst)
        shutil.copytree(SRC, cls.dst)
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]
        cls.base = f"http://127.0.0.1:{port}"
        cls.srv = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)], cwd=ROOT,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(150):
            try:
                urlopen(cls.base + "/api/defaults", timeout=.5).close()
                break
            except OSError:
                time.sleep(.1)
        cls.pw = sync_playwright().start()
        cls.browser = cls.pw.chromium.launch(executable_path=EDGE, headless=True)
        cls.page = cls.browser.new_context(viewport={"width": 1600, "height": 1000}).new_page()
        cls.errors = []
        cls.page.on("pageerror", lambda e: cls.errors.append(str(e)))
        cls.page.goto(cls.base + "/?run=" + COPY)
        cls.page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=90000)
        cls.page.evaluate("() => switchView('powerflow')")
        cls.page.wait_for_selector("#pfp-svg", timeout=90000)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()
        cls.srv.terminate()
        cls.srv.wait(10)
        shutil.rmtree(cls.dst, ignore_errors=True)

    def test_verification_card(self):
        text = self.page.locator("#pfp-verifycard").inner_text().lower()
        for word in ("technical verification", "lowest voltage", "highest loading", "total losses", "reactive balance", "n-1 security"):
            self.assertIn(word, text)
        self.assertIn("pu", text)

    def test_reactive_balance_closes(self):
        mismatch = self.page.evaluate("""() => {
            const c = powerFlowPage.state.snap.case;
            const g = c.buses.reduce((a, b) => a + (b.gen_mvar || 0) + (b.shunt_q_mvar || 0), 0);
            const l = c.buses.reduce((a, b) => a + (b.load_mvar || 0), 0);
            const n = c.branches.reduce((a, b) => a + (b.energized ? b.q_from_mvar + b.q_to_mvar : 0), 0);
            return g - l - n;
        }""")
        self.assertLess(abs(mismatch), 0.05)

    def test_voltages_have_four_decimals_and_no_overlong_numbers(self):
        labels = self.page.eval_on_selector_all("#pfp-svg .pfp-volt", "els => els.map(e => e.textContent)")
        self.assertTrue(labels)
        for t in labels:
            self.assertRegex(t, r"^\d\.\d{4} pu\s+-?[\d,]+\.\d{2}°$")
        body = self.page.locator("#view-powerflow").inner_text()
        import re
        self.assertIsNone(re.search(r"\d\.\d{5,}", body))

    def test_arrow_follows_flow_sign(self):
        res = self.page.evaluate("""() => {
            const out = [];
            const flows = new Map(powerFlowPage.state.snap.case.branches.map(b => [b.id, b]));
            for (const p of document.querySelectorAll('#pfp-svg .pfp-flow')) {
                const id = p.closest('.pfp-branch').dataset.id, f = flows.get(id);
                if (!f) continue;
                out.push([Number(p.dataset.sign), f.p_from_mw >= 0 ? 1 : -1]);
            }
            return out;
        }""")
        self.assertTrue(res)
        for got, want in res:
            self.assertEqual(got, want)

    def test_colours_follow_scenario_limits(self):
        ok = self.page.evaluate("""() => {
            const snap = powerFlowPage.state.snap, lim = snap.assumptions.base.voltage_limits;
            const bad = snap.case.buses.filter(b => b.energized && (b.vm < lim[0] || b.vm > lim[1])).map(b => b.id);
            const red = [...document.querySelectorAll('#pfp-svg .pfp-node')].filter(n => n.querySelector('.pfp-g-volt rect')?.getAttribute('fill') === '#d62839').map(n => n.dataset.id);
            return bad.every(id => red.includes(id));
        }""")
        self.assertTrue(ok)

    def test_charts_legend_and_tables(self):
        self.assertGreaterEqual(self.page.locator("#pfp-charts svg").count(), 2)
        self.assertIn("Arrows point", self.page.locator("#pfp-legend").inner_text())
        heads = self.page.locator("#pfp-tables th").all_inner_texts()
        for h in ("V (kV)", "S from MVA", "Tap (pu)", "Z %"):
            self.assertIn(h, heads)
        self.assertGreater(self.page.locator("#pfp-tables td.num").count(), 10)
        self.assertEqual(self.page.locator("#pfp-tables th:not([scope])").count(), 0)

    def test_corrective_actions_cost_is_live(self):
        box = self.page.locator("#pfp-suggestions")
        self.assertIn("Corrective actions", box.inner_text())
        boxes = box.locator("input[type=checkbox]")
        if boxes.count() == 0:
            self.skipTest("no suggestions for this run")
        for i in range(boxes.count()):
            if boxes.nth(i).is_enabled() and boxes.nth(i).is_checked():
                boxes.nth(i).uncheck()
        self.assertIn("USD 0", self.page.locator("#pfp-cost").inner_text())

    def test_properties_validation(self):
        self.page.evaluate("() => { const n = document.querySelector('#pfp-svg .pfp-node'); n.dispatchEvent(new MouseEvent('dblclick', {bubbles: true})); }")
        self.page.wait_for_selector("#pfprops-dialog:not([hidden]) #pfprops-kv", timeout=30000)
        self.page.fill("#pfprops-kv", "-5")
        self.page.click("#pfprops-ok")
        self.assertIn("between", self.page.locator("#pfprops-dialog").inner_text())
        self.assertEqual(self.page.get_attribute("#pfprops-bus_name", "maxlength"), "12")
        self.page.keyboard.press("Escape")

    def _dblclick(self, selector):
        box = self.page.locator(selector).first
        box.scroll_into_view_if_needed()
        bb = box.bounding_box()
        self.page.mouse.dblclick(bb["x"] + bb["width"] / 2, bb["y"] + bb["height"] / 2)

    def test_double_click_opens_editor_and_saved_edit_changes_case(self):
        kinds = self.page.eval_on_selector_all("#pfp-svg .pfp-node", "els => els.map(e => e.dataset.kind)")
        self.assertIn("load", kinds)
        self.assertIn("grid", kinds)
        for kind in ("grid", "load"):
            self._dblclick(f'#pfp-svg .pfp-node[data-kind="{kind}"] .pfp-box')
            self.page.wait_for_selector("#pfprops-dialog:not([hidden]) #pfprops-title", timeout=15000)
            self.page.click("#pfprops-cancel")
        # a branch opens its own editor
        self._dblclick("#pfp-svg .pfp-branch .pfp-wire")
        self.page.wait_for_selector("#pfprops-dialog:not([hidden]) #pfprops-title", timeout=15000)
        self.assertIn("branch", self.page.inner_text("#pfprops-title"))
        self.page.click("#pfprops-cancel")
        # a saved load edit is written to the scenario topology and the case is re-run
        before = self.page.evaluate("() => powerFlowPage.state.snap.case.load_mw")
        self._dblclick('#pfp-svg .pfp-node[data-kind="load"] .pfp-box')
        self.page.wait_for_selector("#pfprops-load_mw", timeout=15000)
        self.page.fill("#pfprops-load_mw", str(round(before / 2 + 0.7, 4)))
        with self.page.expect_response(lambda r: "/api/x/powerflow" in r.url and r.request.post_data and '"snapshot"' in r.request.post_data, timeout=60000):
            self.page.click("#pfprops-ok")
        self.page.wait_for_function("(b) => Math.abs(powerFlowPage.state.snap.case.load_mw - b) > 1e-6", arg=before, timeout=30000)

    def test_drag_pans_without_blocking_double_click_and_wheel_zooms(self):
        self.page.wait_for_selector("#view-powerflow:not([aria-busy])", timeout=60000)
        vb = lambda: self.page.get_attribute("#pfp-svg", "viewBox")
        start = vb()
        self.page.locator("#pfp-svg").scroll_into_view_if_needed()
        svg = self.page.locator("#pfp-svg").bounding_box()
        x, y = svg["x"] + 30, svg["y"] + svg["height"] / 2
        self.page.mouse.move(x, y)
        self.page.mouse.down()
        self.page.mouse.move(x + 60, y + 40, steps=5)
        self.page.mouse.up()
        self.assertNotEqual(start, vb())
        panned = vb()
        self.page.mouse.move(svg["x"] + svg["width"] / 2, svg["y"] + svg["height"] / 2)
        self.page.mouse.wheel(0, -300)
        self.page.wait_for_function("(v) => document.getElementById('pfp-svg').getAttribute('viewBox') !== v", arg=panned, timeout=5000)
        self.page.click(".pfp-zoombtn:has-text('Fit')")
        self._dblclick('#pfp-svg .pfp-node[data-kind="load"] .pfp-box')
        self.page.wait_for_selector("#pfprops-dialog:not([hidden]) #pfprops-title", timeout=15000)
        self.page.click("#pfprops-cancel")

    def test_no_script_errors(self):
        self.assertEqual(self.errors, [])


if __name__ == "__main__":
    unittest.main()
