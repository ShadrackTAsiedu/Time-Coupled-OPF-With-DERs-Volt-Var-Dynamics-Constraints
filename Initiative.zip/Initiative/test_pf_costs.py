import unittest

import pf_costs
import power_flow as pf


class CostModelTests(unittest.TestCase):
    def test_transformer_ranges(self):
        swap = pf_costs.transformer_cost(63, 33, pf_costs.effective_costs(None))
        total = swap["cost_usd"] if isinstance(swap, dict) else swap
        self.assertTrue(500_000 <= total <= 1_800_000, total)

    def test_economies_of_scale(self):
        p = pf_costs.effective_costs(None)
        cost = lambda mva: pf_costs.transformer_cost(mva, 33, p)
        cost = (lambda f: (lambda m: (lambda r: r["cost_usd"] if isinstance(r, dict) else r)(f(m))))(cost)
        self.assertLess(cost(63) / 63, cost(25) / 25)
        self.assertGreater(cost(63), cost(25))

    def test_capacitor_bank_range(self):
        r = pf_costs.shunt_cost(9.6, 11, pf_costs.effective_costs(None), False, False)
        total = r["cost_usd"] if isinstance(r, dict) else r
        self.assertTrue(100_000 <= total <= 250_000, total)

    def test_overrides_validated_and_applied(self):
        with self.assertRaises(ValueError):
            pf_costs.effective_costs({"contingency_pct": -5})
        self.assertEqual(pf_costs.effective_costs({"regional_factor": 1.5})["regional_factor"], 1.5)

    def test_basis_payload(self):
        basis = pf_costs.cost_basis()
        self.assertEqual(basis["year"], 2024)
        self.assertTrue(all(p["setting_key"].startswith("cost_") for p in basis["parameters"]))
        self.assertTrue(basis["examples"])

    def test_row_cost_uses_voltage(self):
        row = dict(target=dict(kind="node", key="shunt_mvar", id="b"), current=0.0, suggested=5.0)
        low = pf.row_cost(dict(row, cost_inputs=dict(kv=11.0)))[0]
        high = pf.row_cost(dict(row, cost_inputs=dict(kv=132.0)))[0]
        self.assertGreater(high, low)


if __name__ == "__main__":
    unittest.main()
