"""Shared professional matplotlib style for report/PNG charts (colour-blind safe, no clipped legends)."""
PALETTE = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#56B4E9", "#CC79A7", "#7A8794", "#B8A100"]
DPI = 200


def apply():
    import matplotlib as mpl
    from cycler import cycler
    mpl.rcParams.update({
        "figure.dpi": 100, "savefig.dpi": DPI, "savefig.bbox": "tight", "savefig.pad_inches": 0.25,
        "savefig.facecolor": "white", "figure.facecolor": "white", "axes.facecolor": "white",
        "font.family": "sans-serif", "font.sans-serif": ["Segoe UI", "Helvetica", "Arial", "DejaVu Sans"],
        "font.size": 10, "axes.titlesize": 13, "axes.titleweight": "bold", "axes.titlelocation": "left",
        "axes.labelsize": 10, "axes.labelcolor": "#33414d", "axes.edgecolor": "#9aa7b2", "axes.linewidth": 0.8,
        "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "axes.axisbelow": True,
        "grid.color": "#e3e8ec", "grid.linewidth": 0.7, "xtick.color": "#33414d", "ytick.color": "#33414d",
        "axes.prop_cycle": cycler(color=PALETTE), "lines.linewidth": 2.0,
        "legend.frameon": False, "legend.fontsize": 9, "axes.formatter.use_locale": False,
        "axes.formatter.limits": (-5, 6), "figure.constrained_layout.use": False,
    })
    import matplotlib.ticker as ticker
    mpl.rcParams["axes.unicode_minus"] = False
    def fmt(v, _):
        text = f"{v:,.4f}".rstrip("0").rstrip(".")
        return "0" if text in ("-0", "") else text
    return ticker.FuncFormatter(fmt)
