"""Rule-based cleaning of uploaded load and resource CSVs into the model's canonical hourly format.

Every repair is logged, optional repairs can be rejected, and nothing is changed silently.
Pure standard library plus numpy so the tool stays portable.
"""

import csv
import io
import itertools
import math
import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta

import numpy as np

KINDS = {
    "load": dict(column="load_mw", label="Load"),
    "solar": dict(column="solar_per_mw", label="Solar"),
    "wind": dict(column="wind_per_mw", label="Wind"),
    "thermal": dict(column="heat_mwth", label="Thermal"),
}
OPTIONAL_STEPS = {
    "negatives": "Negative values",
    "zero_dropouts": "Zero readings inside normal operation (meter drop-outs)",
    "spikes": "Isolated spikes",
}
MAX_SHORT_GAP = 3
MAX_ZERO_REPAIR_HOURS = 72
FLATLINE_HOURS = 12
MISSING_TOKENS = {"", "na", "n/a", "nan", "null", "none", "-", "--", "#n/a", "#value!", "#div/0!", "error", "nd"}
DATE_FORMATS = ["%Y-%m-%d", "%Y/%m/%d", "%m/%d/%Y", "%d/%m/%Y", "%m-%d-%Y", "%d-%m-%Y", "%d.%m.%Y",
                "%Y%m%d", "%m/%d/%y", "%d/%m/%y", "%d-%b-%Y", "%d %b %Y", "%b %d, %Y"]
TIME_FORMATS = ["%H:%M:%S", "%H:%M", "%I:%M:%S %p", "%I:%M %p", "%I:%M:%S%p", "%I:%M%p", "%H%M"]
TZ_SUFFIX = re.compile(r"\s*(Z|UTC|GMT|[+-]\d{2}:?\d{2})$")
MIDNIGHT_24 = re.compile(r"(?<=[ T])24:(\d\d)")


class PrepError(ValueError):
    pass


def split_lines(text):
    return text.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n").split("\n")


def detect_delimiter(lines):
    sample = [line for line in lines if line.strip()][:60]
    best, best_score = ",", 0
    for delimiter in [",", ";", "\t", "|"]:
        counts = [len(next(csv.reader([line], delimiter=delimiter))) for line in sample]
        if not counts:
            continue
        common, frequency = Counter(counts).most_common(1)[0]
        score = (common - 1) * frequency
        if score > best_score:
            best, best_score = delimiter, score
    return best


def parse_number(text):
    """Return (value, flag) where flag may be 'percent' or 'unreadable'. NaN means missing or unreadable."""
    s = str(text).strip().strip('"')
    if s.lower() in MISSING_TOKENS:
        return math.nan, None
    flag = None
    if s.endswith("%"):
        flag, s = "percent", s[:-1]
    s = re.sub(r"(?i)\s*(kwh|mwh|wh|kw|mw|w)\s*$", "", s).strip().replace(" ", "")
    if re.fullmatch(r"[-+]?\d{1,3}(,\d{3})+(\.\d+)?", s):
        s = s.replace(",", "")
    elif "," in s and "." not in s:
        s = s.replace(",", ".")
    elif "," in s and s.rfind(",") > s.rfind("."):  # European 1.234,56
        s = s.replace(".", "").replace(",", ".")
    try:
        value = float(s)
    except ValueError:
        return math.nan, "unreadable"
    return (value, flag) if math.isfinite(value) else (math.nan, "unreadable")


def is_number(text):
    value, flag = parse_number(text)
    return not math.isnan(value)


def strip_tz(text):
    if ":" in text:
        stripped = TZ_SUFFIX.sub("", text)
        return stripped, stripped != text
    return text, False


def timestamp_formats(separate_time):
    if separate_time:
        return [f"{d} {t}" for d in DATE_FORMATS for t in TIME_FORMATS]
    formats = [f"{d}{sep}{t}" for d in DATE_FORMATS for t in TIME_FORMATS for sep in (" ", "T")]
    return formats + DATE_FORMATS


def choose_format(samples, separate_time):
    """Pick the format that parses the most samples; break d/m vs m/d ties by chronological order."""
    candidates = timestamp_formats(separate_time)
    scored = []
    for fmt in candidates:
        parsed = []
        for s in samples:
            try:
                parsed.append(datetime.strptime(s, fmt))
            except ValueError:
                pass
        if parsed:
            backward = sum(1 for a, b in zip(parsed, parsed[1:]) if b < a)
            span = (max(parsed) - min(parsed)).total_seconds()
            scored.append((len(parsed), -backward, -span, fmt))
    if not scored:
        return None, False
    scored.sort(reverse=True)
    best = scored[0]
    def day_first(f):
        return "%d" in f and "%m" in f and f.index("%d") < f.index("%m")
    ambiguous = any(item[0] == best[0] and item[1] == best[1] and day_first(item[3]) != day_first(best[3])
                    for item in scored[1:])
    return best[3], ambiguous


def find_header(rows):
    """Index of the header row: followed by consistent rows whose first columns hold dates."""
    for i, row in enumerate(rows[:200]):
        if len(row) < 2:
            continue
        following = [r for r in rows[i + 1:i + 6] if any(c.strip() for c in r)]
        if len(following) < 2 or any(len(r) != len(row) for r in following):
            continue
        if all(any(looks_like_date(c) for c in r) for r in following) and not all(looks_like_date(c) for c in row if c.strip()):
            return i
    for i, row in enumerate(rows[:200]):
        if len(row) >= 2 and any(looks_like_date(c) for c in row):
            return None
    raise PrepError("Could not find a header row followed by dated records.")


def looks_like_date(text):
    s, _ = strip_tz(str(text).strip())
    if not s or re.fullmatch(r"[-+]?\d+(\.\d+)?", s):
        return False
    for fmt in timestamp_formats(False):
        try:
            datetime.strptime(s, fmt)
            return True
        except ValueError:
            continue
    return False


def pick_value_column(names, columns, kind, exclude):
    """Return the best numeric column index and the reason."""
    keywords = {
        "load": ["load", "demand", "kw", "mw", "usage", "consumption", "energy", "power", "kwh"],
        "solar": ["solar_per_mw", "poa_irradiance_w_m2", "poa", "ghi", "irradi", "w/m", "solar", "pv", "output", "generation", "power"],
        "wind": ["wind_per_mw", "capacity_factor", "capacity factor", "cf", "wind", "output", "generation", "power"],
        "thermal": ["heat_mwth", "thermal", "heat", "mwth", "kwth", "demand", "load"],
    }[kind]
    numeric = []
    for j, name in enumerate(names):
        if j in exclude:
            continue
        values = [c for c in columns[j][:2000] if str(c).strip()]
        if values and sum(is_number(v) for v in values) / len(values) >= .8:
            numeric.append(j)
    if not numeric:
        raise PrepError("No numeric value column was found.")
    best, best_score = numeric[0], -1
    for j in numeric:
        label = names[j].lower()
        score = max((len(keywords) - k for k, word in enumerate(keywords) if word in label), default=0)
        if kind == "load" and re.search(r"max|min|peak|billed|status|flag|quality", label):
            score -= len(keywords) + 1
        if score > best_score:
            best, best_score = j, score
    return best, [names[j] for j in numeric if j != best]


def sniff_unit(name):
    """Return (unit, is_energy) from a column header, or (None, False)."""
    label = name.lower().replace("_", " ")
    energy = bool(re.search(r"\b(kwh|mwh|wh)\b", label))
    for pattern, unit in [(r"\b(mw|mwh|mwth)\b", "mw"), (r"\b(kw|kwh|kwth)\b", "kw"), (r"\b(w|wh)\b", "w")]:
        if re.search(pattern, label):
            return unit, energy
    return None, False


def read_file(file, kind, options):
    name, text = file.get("name", "file.csv"), file.get("content", "")
    lines = split_lines(text)
    delimiter = detect_delimiter(lines)
    rows = [r for r in csv.reader(lines, delimiter=delimiter)]
    rows = [r for r in rows if any(c.strip() for c in r)]
    if len(rows) < 3:
        raise PrepError(f"{name}: file has fewer than 3 data rows.")
    header = find_header(rows)
    if header is None:
        names, body = [f"column{j + 1}" for j in range(len(rows[0]))], rows
        header_note = "no header row; columns numbered"
    else:
        names, body = [c.strip() for c in rows[header]], rows[header + 1:]
        header_note = f"header at row {header + 1}"
    width = len(names)
    ragged = sum(1 for r in body if len(r) != width and any(c.strip() for c in r))
    body = [r for r in body if len(r) == width and any(c.strip() for c in r)]
    if not body:
        raise PrepError(f"{name}: no data rows match the header width.")
    columns = [[r[j] for r in body] for j in range(width)]
    lower = [n.lower().strip() for n in names]

    # Timestamp columns: one combined column, or separate date and time columns.
    date_col = next((j for j, n in enumerate(lower) if n in ("date", "day") or n.startswith("date")), None)
    time_col = next((j for j, n in enumerate(lower)
                     if n in ("hour", "hr", "he", "hour_ending", "hour ending") or (n.startswith("time") and "zone" not in n)), None)
    ts_col = next((j for j, n in enumerate(lower) if re.search(r"time ?stamp|datetime|date_time|date/time", n)), None)
    separate = False
    if ts_col is None and date_col is not None and time_col is not None and date_col != time_col:
        separate, ts_cols = True, [date_col, time_col]
        times = [c.strip() for c in columns[time_col]]
        if all(re.fullmatch(r"\d{1,2}", t) for t in times if t):
            times = [f"{int(t):02d}:00" if t else t for t in times]  # integer hour column
        raw_stamps = [f"{a.strip()} {b}" for a, b in zip(columns[date_col], times)]
    else:
        if ts_col is None:
            ts_col = next((j for j in range(width)
                           if sum(looks_like_date(c) for c in columns[j][:30]) >= max(1, len(columns[j][:30]) * .8)), None)
        if ts_col is None:
            raise PrepError(f"{name}: no timestamp column was found.")
        ts_cols = [ts_col]
        raw_stamps = [c.strip() for c in columns[ts_col]]
        following = columns[ts_col + 1][:30] if ts_col + 1 < width else []
        if following and not any(":" in c for c in raw_stamps[:30]) and sum(
                bool(re.fullmatch(r"\s*\d{1,2}:\d{2}(:\d{2})?\s*([AaPp][Mm])?\s*", c)) for c in following) >= .8 * len(following):
            separate, ts_cols = True, [ts_col, ts_col + 1]  # unlabelled time column next to a date-only column
            raw_stamps = [f"{a.strip()} {b.strip()}" for a, b in zip(columns[ts_col], columns[ts_col + 1])]
    tz_removed, tz_utc = 0, False
    cleaned_stamps = []
    for s in raw_stamps:
        match = TZ_SUFFIX.search(s) if ":" in s else None
        tz_utc = tz_utc or bool(match and match.group(1) in ("Z", "UTC", "GMT"))
        s, removed = strip_tz(s)
        tz_removed += removed
        cleaned_stamps.append(s)
    # Hour-ending clocks run 01:00 ... 24:00; 24:xx is the next day's midnight and marks interval-ending stamps.
    next_day = [bool(MIDNIGHT_24.search(s)) for s in cleaned_stamps]
    cleaned_stamps = [MIDNIGHT_24.sub(r"00:\1", s) for s in cleaned_stamps]
    interval_ending = any(next_day)
    sample = [s for s in cleaned_stamps[::max(1, len(cleaned_stamps) // 400)] if s]
    fmt, ambiguous = choose_format(sample, separate)
    if fmt is None:
        raise PrepError(f"{name}: timestamps are in an unrecognised format (e.g. '{sample[0] if sample else ''}').")

    value_col, ignored = pick_value_column(names, columns, kind, set(ts_cols))
    # Optional explicit max/min columns for load.
    extras = {}
    if kind == "load":
        for j, n in enumerate(lower):
            if j in ts_cols or j == value_col or not is_number(columns[j][0] if columns[j] else ""):
                continue
            if re.search(r"max", n) and "load_max" not in extras:
                extras["load_max"] = j
            elif re.search(r"min", n) and "load_min" not in extras:
                extras["load_min"] = j
    ignored = [n for n in ignored if names.index(n) not in extras.values()]

    stamps, values, maxes, mins = [], [], [], []
    dropped_ts = unreadable = percent_cells = 0
    for i, s in enumerate(cleaned_stamps):
        try:
            stamp = datetime.strptime(s, fmt)
        except ValueError:
            try:
                stamp = datetime.fromisoformat(s)
            except ValueError:
                dropped_ts += 1
                continue
        if next_day[i]:
            stamp += timedelta(days=1)
        value, flag = parse_number(columns[value_col][i])
        unreadable += flag == "unreadable"
        percent_cells += flag == "percent"
        stamps.append(stamp.replace(tzinfo=None))
        values.append(value)
        if extras:
            maxes.append(parse_number(columns[extras["load_max"]][i])[0] if "load_max" in extras else math.nan)
            mins.append(parse_number(columns[extras["load_min"]][i])[0] if "load_min" in extras else math.nan)
    if not stamps:
        raise PrepError(f"{name}: no timestamps could be parsed.")
    return dict(name=name, delimiter=delimiter, header=header_note, timestamp_columns=[names[j] for j in ts_cols],
                timestamp_format=fmt, ambiguous_dates=ambiguous, value_column=names[value_col],
                ignored_numeric_columns=ignored, rows=len(body) + ragged, dropped_timestamps=dropped_ts + ragged,
                unreadable_values=unreadable, tz_removed=tz_removed, tz_utc=tz_utc, percent_cells=percent_cells,
                interval_ending=interval_ending,
                stamps=stamps, values=np.array(values, dtype=float),
                maxes=np.array(maxes, dtype=float) if maxes else None,
                mins=np.array(mins, dtype=float) if mins else None)


def file_interval_minutes(stamps):
    unique = sorted(set(stamps))
    diffs = [(b - a).total_seconds() / 60 for a, b in zip(unique, unique[1:])]
    if not diffs:
        raise PrepError("A single timestamp cannot define an interval.")
    return Counter(round(d) for d in diffs if d > 0).most_common(1)[0][0]


def positive_number(value):
    """A finite positive float, or 0.0 when the option is missing or invalid."""
    try:
        number = float(value)
    except (TypeError, ValueError):
        return 0.0
    return number if math.isfinite(number) and number > 0 else 0.0


def convert_units(read, kind, options, notes):
    """Convert a file's values to MW (load/thermal) or per-unit/irradiance, returning the output unit label."""
    values, name = read["values"], read["value_column"]
    interval = file_interval_minutes(read["stamps"])
    if interval > 60:
        raise PrepError(f"{read['name']}: data are every {interval} minutes. Hourly or finer data are required; "
                        "daily or monthly summaries cannot build an hourly profile.")
    read["interval_minutes"] = interval
    if read["interval_ending"]:
        shift = timedelta(minutes=interval)
        read["stamps"] = [s - shift for s in read["stamps"]]
        notes.append(dict(level="info", text=f"{read['name']}: stamps run to 24:00, so they were read as interval-ending "
                          f"and moved back {interval} minutes to the interval start (the model uses hour-beginning)."))
    positive = values[np.isfinite(values) & (values > 0)]
    median = float(np.median(positive)) if positive.size else 0.0
    peak = float(np.nanmax(values)) if positive.size else 0.0
    forced = options.get("unit", "auto")
    if kind in ("load", "thermal"):
        unit, energy = sniff_unit(name)
        reason = "from the column header"
        if forced in ("kw", "mw", "w"):
            unit, reason = forced, "chosen by you"
        elif unit is None:
            unit = "kw" if median >= 500 else "mw"
            reason = f"guessed from magnitude (median {median:,.1f}); confirm or choose the unit explicitly"
            read["unit_guess"] = (unit, median, median >= 5000 or median < 50)
        scale = {"kw": 1e-3, "mw": 1.0, "w": 1e-6}[unit]
        out = values * scale
        if energy:
            out = out / (interval / 60)
            reason += f"; energy per {interval}-minute interval converted to average power"
        for key in ("maxes", "mins"):
            if read[key] is not None:
                read[key] = read[key] * scale / ((interval / 60) if energy else 1)
        read["unit_note"] = f"{unit.upper()} {reason}"
        read["values"] = out
        return KINDS[kind]["column"]
    label = name.lower()
    if kind == "solar":
        irradiance = bool(re.search(r"poa|ghi|dni|dhi|irradi|w/m|w_m2|wm2|w m2", label))
        power_unit = None if irradiance or re.search(r"per[ _]?(mw|unit)|/ ?mw|\bpu\b|capacity|\bcf\b", label) else sniff_unit(name)[0]
        if power_unit and not (read["percent_cells"] or re.search("percent|%", label)):
            capacity = positive_number(options.get("solar_capacity_mw"))
            if not capacity:
                raise PrepError(f"{read['name']}: solar output looks like power (max {peak:,.1f}). "
                                "Enter the plant capacity in MW so it can be converted to per-unit.")
            scale = {"kw": 1e-3, "mw": 1.0, "w": 1e-6}[power_unit]
            read.update(values=values * scale / capacity,
                        unit_note=f"power divided by the {capacity:g} MW capacity you entered")
            return "solar_per_mw"
        if irradiance or (peak > 2 and not re.search("percent|%", label)):
            if re.search(r"kw/m|kw_m2", label) or (peak <= 2 and re.search(r"kw", label)):
                out, reason = values * 1000, "kW/m2 converted to W/m2"
            else:
                out, reason = values.copy(), "W/m2"
            if not irradiance:
                notes.append(dict(level="warning", text=f"{read['name']}: values up to {peak:,.1f} were read as irradiance "
                                  "in W/m2 from their magnitude; name the column with its unit if that is wrong."))
            read.update(values=out, unit_note=f"plane-of-array irradiance, {reason}")
            return "poa_irradiance_w_m2"
        if read["percent_cells"] or re.search("percent|%", label):
            read.update(values=values / 100, unit_note="percent converted to per-unit")
        else:
            read["unit_note"] = "per-unit output per installed MW"
        return "solar_per_mw"
    if kind == "wind":
        capacity = positive_number(options.get("wind_capacity_mw"))
        if read["percent_cells"] or re.search("percent|%", label) or (1.5 < peak <= 100 and not re.search(r"kw|mw", label)):
            read.update(values=values / 100, unit_note="percent converted to per-unit")
        elif peak > 1.5:
            unit, _ = sniff_unit(name)
            if not capacity:
                raise PrepError(f"{read['name']}: wind output looks like power (max {peak:,.1f}). "
                                "Enter the plant capacity in MW so it can be converted to per-unit.")
            scale = {"kw": 1e-3, "mw": 1.0, "w": 1e-6}.get(unit or ("kw" if peak > 500 else "mw"))
            read.update(values=values * scale / capacity,
                        unit_note=f"power divided by the {capacity:g} MW capacity you entered")
        else:
            read["unit_note"] = "per-unit capacity factor"
        return "wind_per_mw"
    raise PrepError("Unknown data kind.")


def runs(mask):
    """Yield (start, stop_inclusive) of consecutive True runs."""
    idx = np.flatnonzero(mask)
    if not idx.size:
        return
    start = prev = idx[0]
    for i in idx[1:]:
        if i != prev + 1:
            yield int(start), int(prev)
            start = i
        prev = i
    yield int(start), int(prev)


def window_fill(x, i, step, count):
    """Median of the same hour on neighbouring days (step=24) or weeks (step=168)."""
    candidates = []
    for k in range(1, count + 1):
        for j in (i - k * step, i + k * step):
            if 0 <= j < x.size and np.isfinite(x[j]):
                candidates.append(x[j])
    return float(np.median(candidates)) if candidates else math.nan


def hour_of_week_baseline(dates, x):
    key = np.array([d.weekday() * 24 + d.hour for d in dates])
    base = np.full(x.size, math.nan)
    for k in range(168):
        sel = key == k
        valid = sel & np.isfinite(x) & (x >= 0)
        if valid.sum() >= 3:
            base[sel] = np.median(x[valid])
    return base


def aggregate_hourly(stamps, values, maxes, mins, kind):
    """Average duplicate/sub-hourly stamps into hours; return hourly grid arrays and counters."""
    buckets = defaultdict(list)
    for i, s in enumerate(stamps):
        buckets[s.replace(minute=0, second=0, microsecond=0)].append(i)
    first, last = min(buckets), max(buckets)
    n = int((last - first).total_seconds() // 3600) + 1
    dates = [first + timedelta(hours=h) for h in range(n)]
    mean = np.full(n, math.nan)
    hi = np.full(n, math.nan)
    lo = np.full(n, math.nan)
    duplicates = subhourly = 0
    for h, d in enumerate(dates):
        idx = buckets.get(d)
        if not idx:
            continue
        vals = values[idx]
        stamps_in = {stamps[i] for i in idx}
        if len(idx) > len(stamps_in):
            duplicates += len(idx) - len(stamps_in)
        subhourly += len(stamps_in) > 1
        good = vals[np.isfinite(vals)]
        if good.size:
            mean[h] = good.mean()
            hi[h] = good.max() if maxes is None else np.nanmax(np.r_[good, maxes[idx]])
            lo[h] = good.min() if mins is None else np.nanmin(np.r_[good, mins[idx]])
    return dates, mean, hi, lo, duplicates, subhourly


def prepare(kind, files, options=None):
    options = options or {}
    if kind not in KINDS:
        raise PrepError("Choose a data type: load, solar, wind or thermal.")
    if not files or not all(isinstance(f, dict) and isinstance(f.get("content"), str) for f in files):
        raise PrepError("Select at least one CSV file.")
    disabled = set(options.get("disabled", [])) & set(OPTIONAL_STEPS)
    notes, file_reports, steps = [], [], []
    reads, units = [], set()
    for file in files:
        read = read_file(file, kind, options)
        column = convert_units(read, kind, options, notes)
        units.add(column)
        reads.append(read)
        file_reports.append({k: read[k] for k in (
            "name", "delimiter", "header", "timestamp_columns", "timestamp_format", "value_column",
            "ignored_numeric_columns", "rows", "interval_minutes", "unit_note")})
        if read["ignored_numeric_columns"]:
            notes.append(dict(level="info", text=f"{read['name']}: used '{read['value_column']}'; ignored numeric columns "
                              f"{', '.join(read['ignored_numeric_columns'][:6])}."))
    ambiguous = [r for r in reads if r["ambiguous_dates"]]
    if ambiguous:
        notes.append(dict(level="warning", text=f"Day/month order is ambiguous in {len(ambiguous)} file(s) "
                          f"({', '.join(r['name'] for r in ambiguous[:3])}{', ...' if len(ambiguous) > 3 else ''}); "
                          "the order that keeps each file chronological was used."))
    for confident in (False, True):
        guessed = [r for r in reads if "unit_guess" in r and r["unit_guess"][2] == confident]
        if guessed:
            names = ", ".join(r["name"] for r in guessed[:3]) + (", ..." if len(guessed) > 3 else "")
            units_used = sorted({r["unit_guess"][0].upper() for r in guessed})
            notes.append(dict(level="info" if confident else "warning",
                              text=f"No unit in the column header of {len(guessed)} file(s) ({names}); "
                                   f"{'/'.join(units_used)} was inferred from the magnitude of the readings"
                                   + ("." if confident else "; confirm it, or choose the unit explicitly.")))
    if any(r["tz_utc"] for r in reads):
        notes.append(dict(level="warning", text="Timestamps are labelled UTC. The suffix was removed without shifting to "
                          "local time, so the daily profile is offset by the UTC difference; convert to local time first "
                          "if the load follows local working hours."))
    if len(units) > 1:
        raise PrepError("The selected files mix different quantities (for example irradiance and per-unit output).")
    out_column = units.pop()
    stamps = list(itertools.chain.from_iterable(r["stamps"] for r in reads))
    values = np.concatenate([r["values"] for r in reads])
    has_extras = kind == "load" and any(r["maxes"] is not None or r["mins"] is not None for r in reads)
    maxes = mins = None
    if has_extras:
        maxes = np.concatenate([r["maxes"] if r["maxes"] is not None else np.full(r["values"].size, math.nan) for r in reads])
        mins = np.concatenate([r["mins"] if r["mins"] is not None else np.full(r["values"].size, math.nan) for r in reads])

    dropped = sum(r["dropped_timestamps"] for r in reads)
    unreadable = sum(r["unreadable_values"] for r in reads)
    blank = int(np.isnan(values).sum()) - unreadable
    tz_removed = sum(r["tz_removed"] for r in reads)
    dates, x, hi, lo, duplicates, subhourly = aggregate_hourly(stamps, values, maxes, mins, kind)
    raw_hourly = x.copy()
    total_hours = x.size
    # Trim leading/trailing hours with no data, then partial days (load only).
    valid = np.flatnonzero(np.isfinite(x))
    if not valid.size:
        raise PrepError("No usable numeric readings were found.")
    lo_i, hi_i = int(valid[0]), int(valid[-1])
    if kind == "load":
        while lo_i < hi_i and dates[lo_i].hour != 0:
            lo_i += 1
        while hi_i > lo_i and dates[hi_i].hour != 23:
            hi_i -= 1
    trimmed = total_hours - (hi_i - lo_i + 1)
    dates, x, hi, lo, raw_hourly = (a[lo_i:hi_i + 1] for a in (np.array(dates, dtype=object), x, hi, lo, raw_hourly))
    dates = list(dates)
    n = x.size
    if n < 24:
        raise PrepError("Fewer than one full day of data remains after cleaning.")

    reason = np.full(n, "", dtype=object)
    original = x.copy()
    missing = ~np.isfinite(x)
    reason[missing] = "missing"

    # Optional repairs flag values for replacement.
    marks = {}
    if kind in ("load", "thermal"):
        marks["negatives"] = np.isfinite(x) & (x < 0)
        positive = x[np.isfinite(x) & (x > 0)]
        median = float(np.median(positive)) if positive.size else 0.0
        baseline = hour_of_week_baseline(dates, np.where(x >= 0, x, math.nan))
        zero_like = np.isfinite(x) & (np.abs(x) <= max(1e-9, .02 * median)) & (np.nan_to_num(baseline) > .3 * median)
        repairable = np.zeros(n, bool)
        long_zero = 0
        for a, b in runs(zero_like):
            if b - a + 1 <= MAX_ZERO_REPAIR_HOURS:
                repairable[a:b + 1] = True
            else:
                long_zero += b - a + 1
        marks["zero_dropouts"] = repairable
        if long_zero:
            notes.append(dict(level="warning", text=f"{long_zero} hours of zero demand in runs longer than "
                              f"{MAX_ZERO_REPAIR_HOURS} h were left unchanged (possible real shutdown); review them."))
        spikes = np.zeros(n, bool)
        usable = np.isfinite(x) & (x >= 0) & ~zero_like
        if n >= 28 * 24 and median > 0:
            resid = np.where(usable & np.isfinite(baseline), x - baseline, math.nan)
            center = np.nanmedian(resid)
            scale = 1.4826 * np.nanmedian(np.abs(resid - center))
            threshold = max(8 * scale, .6 * median)
            outlier = usable & np.isfinite(resid) & (np.abs(resid - center) > threshold) & (np.abs(x) > 0)
            # Only short excursions that jump away from both neighbours are meter glitches; a smooth
            # multi-hour rise (for example a heat-wave peak) is real demand and is kept.
            for a, b in runs(outlier):
                edges = [abs(x[a] - x[a - 1]) if a > 0 else math.nan, abs(x[b] - x[b + 1]) if b < n - 1 else math.nan]
                if b - a + 1 <= MAX_SHORT_GAP and all(e > threshold / 2 for e in edges if math.isfinite(e)):
                    spikes[a:b + 1] = True
        else:
            notes.append(dict(level="info", text="Spike detection needs at least 4 weeks of data and was skipped."))
        marks["spikes"] = spikes & ~marks["negatives"] & ~repairable
    else:
        marks = {}
    flat = np.zeros(n, bool)
    if kind != "solar":
        same = np.r_[False, np.isfinite(x[1:]) & np.isfinite(x[:-1]) & (x[1:] == x[:-1]) & (np.abs(x[1:]) > 1e-9)]
        for a, b in runs(same):
            if b - a + 1 + 1 >= FLATLINE_HOURS:
                flat[a - 1:b + 1] = True
    counts = {}
    work = x.copy()
    for step in ("negatives", "zero_dropouts", "spikes"):
        mask = marks.get(step)
        if mask is None:
            continue
        counts[step] = int(mask.sum())
        if step in disabled:
            continue
        work[mask] = math.nan
        reason[mask] = step

    # Hard physical clipping for resources (logged, reversible: original kept in the change log).
    clipped = 0
    if kind != "load" and kind != "thermal":
        upper = {"solar_per_mw": 2.0, "wind_per_mw": 1.0, "poa_irradiance_w_m2": 2000.0}[out_column]
        over = np.isfinite(work) & ((work > upper) | (work < 0))
        for i in np.flatnonzero(over):
            reason[i] = reason[i] or "clipped"
        work[over] = np.clip(work[over], 0, upper)
        clipped = int(over.sum())

    # Fill gaps and removed values.
    bad = ~np.isfinite(work)
    short = long = 0
    step_size, windows = (168, 4) if kind in ("load", "thermal") else (24, 10)
    for a, b in runs(bad):
        length = b - a + 1
        interpolate = length <= MAX_SHORT_GAP and a > 0 and b < n - 1
        for i in range(a, b + 1):
            if interpolate:
                left, right = work[a - 1], work[b + 1]
                work[i] = left + (right - left) * (i - a + 1) / (length + 1)
            else:
                value = window_fill(work, i, step_size, windows)
                if math.isnan(value):
                    value = window_fill(work, i, 24, 14)
                work[i] = value if math.isfinite(value) else float(np.nanmedian(work))
            if reason[i] == "missing":
                reason[i] = "short_gaps" if interpolate else "long_gaps"
        short += length if interpolate else 0
        long += 0 if interpolate else length
    if np.any(~np.isfinite(work)):
        raise PrepError("Some hours could not be repaired; supply more data.")
    if long / n > .2:
        raise PrepError(f"{long / n:.0%} of the hours are missing in long gaps; the profile is not reliable enough to repair.")
    # Keep min/max envelopes consistent with repaired means.
    out_hi = np.where(np.isfinite(hi), hi, work)
    out_lo = np.where(np.isfinite(lo), lo, work)
    repaired = reason != ""
    out_hi = np.where(repaired, work, out_hi)
    out_lo = np.where(repaired, work, out_lo)
    out_hi, out_lo = np.maximum(out_hi, work), np.minimum(out_lo, work)
    if kind == "load":
        out_lo = np.clip(out_lo, 0, None)

    # Coverage check: the model needs every month/day/hour of a year (Feb 29 optional).
    present = {(d.month, d.day, d.hour) for d in dates if not (d.month == 2 and d.day == 29)}
    coverage_ok = len(present) == 8760
    full_days = len({d.date() for d in dates})

    def add(step_id, title, count, action, detail, optional=False):
        steps.append(dict(id=step_id, title=title, count=int(count), action=action, detail=detail,
                          optional=optional, enabled=step_id not in disabled))
    add("structure", "File structure detected", len(reads), "info",
        "; ".join(f"{r['name']}: {r['delimiter']!r}-separated, {r['header']}, time = {' + '.join(r['timestamp_columns'])} "
                  f"({r['timestamp_format']}), value = '{r['value_column']}' ({r['unit_note']})" for r in reads))
    if dropped:
        add("bad_timestamps", "Rows with unreadable timestamps", dropped, "removed", "These rows could not be placed in time and were dropped.")
    if unreadable or blank:
        add("bad_values", "Blank or non-numeric values", unreadable + blank, "gap", "Treated as missing and repaired with the gap rules below.")
    if tz_removed:
        add("timezone", "Timestamps with a time-zone suffix", tz_removed, "converted", "Suffix removed; local clock time is kept, as the model uses time-zone-free hours.")
    if duplicates:
        add("duplicates", "Duplicate timestamps", duplicates, "averaged", "Repeated readings (including a repeated daylight-saving hour) were averaged.")
    if subhourly:
        add("aggregate", "Sub-hourly intervals aggregated", subhourly, "aggregated", "Readings inside each hour were averaged; the hourly max/min are kept for load.")
    if trimmed:
        add("trim", "Edge hours trimmed", trimmed, "removed", "Leading/trailing empty hours and, for load, partial first/last days were removed so the series starts at 00:00 and ends at 23:00.")
    add("short_gaps", f"Short gaps (up to {MAX_SHORT_GAP} h)", short, "interpolated", "Filled by straight-line interpolation between the neighbouring hours.")
    add("long_gaps", "Long gaps", long, "filled", "Filled with the median of the same hour on neighbouring "
        + ("weeks" if kind in ("load", "thermal") else "days") + "; treat these hours as estimates.")
    for step_id, title in OPTIONAL_STEPS.items():
        if step_id in marks:
            add(step_id, title, counts.get(step_id, 0), "skipped" if step_id in disabled else "replaced",
                {"negatives": "Replaced with the gap-fill value. Negative demand is not valid for this model.",
                 "zero_dropouts": f"Zeros (up to {MAX_ZERO_REPAIR_HOURS} h) where the same hour-of-week is normally well above zero.",
                 "spikes": "Values far from the typical same-hour-of-week level (robust 8-sigma rule, at least 60% of median load)."}[step_id],
                optional=True)
    if kind != "solar" and flat.any():
        add("flatlines", f"Frozen readings (>= {FLATLINE_HOURS} identical hours)", int(flat.sum()), "reported",
            "Possible stuck meter. Not changed automatically; review the chart.")
    if clipped:
        add("clipping", "Values outside the physical range", clipped, "clipped", "Clipped to the allowed range for this data type.")
    add("coverage", "Coverage", len(present), "ok" if coverage_ok else "warning",
        f"{full_days} days; {len(present):,} of 8,760 month/day/hour slots covered. "
        + ("Complete year." if coverage_ok else "Hourly history for the model needs every month/day/hour of one year; a rolling year is allowed."))

    repaired_hours = int((reason != "").sum())
    penalty = 100 * (short + 4 * long + 2 * sum(counts.get(s, 0) for s in OPTIONAL_STEPS if s not in disabled)) / n
    score = max(0, round(100 - penalty))
    grade = "A" if score >= 95 else "B" if score >= 85 else "C" if score >= 70 else "D"
    ready = coverage_ok or kind != "load"
    if not coverage_ok:
        notes.append(dict(level="warning", text="The cleaned load history does not cover a full year, so the model will reject it as historical data. "
                          "It can still be used as forecast data if it covers the whole forecast horizon."))

    stats = lambda a: dict(mean=float(np.mean(a)), max=float(np.max(a)), min=float(np.min(a)))
    before_finite = raw_hourly[np.isfinite(raw_hourly)]
    report = dict(kind=kind, column=out_column, hours=n, start=dates[0].isoformat(sep=" "), end=dates[-1].isoformat(sep=" "),
                  score=score, grade=grade, repaired_hours=repaired_hours, ready=ready, files=file_reports,
                  steps=steps, notes=notes,
                  before=stats(before_finite) if before_finite.size else None, after=stats(work))

    # Daily before/after means for the review chart.
    day_index = np.array([(d - dates[0]).days for d in dates])
    days = int(day_index.max()) + 1
    daily = []
    for k in range(days):
        sel = day_index == k
        b = raw_hourly[sel]
        b = b[np.isfinite(b)]
        daily.append(dict(date=(dates[0] + timedelta(days=k)).strftime("%Y-%m-%d"),
                          before=float(b.mean()) if b.size else None, after=float(work[sel].mean())))
    report["daily"] = daily

    # Change log: every repaired hour with its original and new value.
    log = io.StringIO()
    writer = csv.writer(log)
    writer.writerow(["timestamp", "step", "original", "new"])
    log_rows = []
    for i in np.flatnonzero(reason != ""):
        orig = "" if not math.isfinite(original[i]) else f"{original[i]:.6f}"
        log_rows.append(dict(timestamp=dates[i].strftime("%Y-%m-%d %H:%M"), step=reason[i], original=orig or None,
                             new=round(float(work[i]), 6)))
        writer.writerow([dates[i].strftime("%Y-%m-%d %H:%M:%S"), reason[i], orig, f"{work[i]:.6f}"])
    report["changes_total"] = len(log_rows)
    report["changes"] = log_rows[:300]

    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\n")
    if kind == "load":
        writer.writerow(["timestamp", "load_mw", "load_max_mw", "load_min_mw"])
        for d, v, h, l in zip(dates, work, out_hi, out_lo):
            writer.writerow([d.strftime("%Y-%m-%d %H:%M:%S"), f"{v:.6f}", f"{h:.6f}", f"{l:.6f}"])
    else:
        writer.writerow(["timestamp", out_column])
        for d, v in zip(dates, work):
            writer.writerow([d.strftime("%Y-%m-%d %H:%M:%S"), f"{v:.6f}"])
    report["file_name"] = f"cleaned_{kind}_{dates[0].year}_{dates[-1].year}.csv"
    if kind == "load":
        try:
            import demand_forecasting
            for file in files:
                demand_forecasting.parse_csv(file["content"])
            report["original_ok"] = True
        except Exception:
            report["original_ok"] = False
    return dict(report=report, csv=out.getvalue(), changes_csv=log.getvalue())
