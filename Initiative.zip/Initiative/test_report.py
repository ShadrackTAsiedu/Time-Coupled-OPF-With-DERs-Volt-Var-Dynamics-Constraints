"""Client report: structure, numbers, best-option rule and HTTP routes."""

import json
import re
import socket
import subprocess
import sys
import time
import unittest
from pathlib import Path
from urllib.request import Request, urlopen

import report
import report_pdf

ROOT = Path(__file__).resolve().parent
RUN_ID = "25253846a35d4d2583767b43da6bd098"
RUN = ROOT / "Application Runs" / RUN_ID
SECTIONS = ["Executive summary", "Introduction and scope", "Data and demand forecast", "Basis of design and assumptions", "Methodology",
            "Scenario results and comparison", "Recommended solution", "Economic analysis", "Sensitivity and uncertainty",
            "Reliability and resilience", "Network and power-flow verification", "Design summary",
            "Risks and compliance summary", "Conclusions and recommendations", "Input parameters", "Key equations",
            "Data quality and cleaning log", "Dispatch charts", "Glossary and abbreviations", "References"]
META = {"project_name": "Harbor <script>alert(1)</script> Microgrid", "client_name": "ACME & Sons \"Ltd\"", "consulting_company": "Volt</style>Works",
        "document_number": "DOC-<b>9</b>", "revision": "B", "issue_purpose": "For approval", "prepared_by": "A. Engineer", "reviewed_by": "R. Viewer",
        "approved_by": "P. Approver", "site": "Pier 7", "date": "2026-03-05", "notes": "Scope A\n\nScope <img src=x onerror=alert(1)>",
        "confidentiality": "Strictly <i>private</i>", "logo": "data:image/png;base64,iVBORw0KGgo="}


def case(npc, unserved=0.0, hours=0):
    return {"economics": {"npc": npc}, "adequacy": {"unserved_hours": hours, "stress_unserved_mwh": 0, "unserved_mwh": unserved}}


def named(results):
    return {k: dict(v, code=k) for k, v in results.items()}


class BestOptionRule(unittest.TestCase):
    def test_lowest_npc_among_fully_served(self):
        results = named({"R0": case(300), "A": case(200), "B": case(100, unserved=5, hours=3)})
        self.assertEqual(report.pick_best(results), ("A", True))

    def test_reference_wins_only_when_cheapest(self):
        self.assertEqual(report.pick_best(named({"R0": case(100), "A": case(200)}))[0], "R0")

    def test_no_feasible_uses_least_shortage(self):
        results = named({"A": case(100, unserved=9, hours=9), "B": case(500, unserved=1, hours=1)})
        self.assertEqual(report.pick_best(results), ("B", False))


class FormattingHelpers(unittest.TestCase):
    def test_years_have_no_separator(self):
        self.assertEqual(report.display_value({"key": "start_year", "unit": "year"}, 2026), "2026")

    def test_fraction_shown_as_percent(self):
        field = {"key": "discount", "unit": "fraction"}
        self.assertEqual(report.display_value(field, 0.06), "6")
        self.assertEqual(report.display_unit(field), "%")
        self.assertEqual(report.display_unit({"unit": "fraction/year"}), "%/year")

    def test_sensitivity_values(self):
        self.assertEqual(report.sens_value(20, "% change"), "+20%")
        self.assertEqual(report.sens_value(0.25, "fraction"), "25%")
        self.assertEqual(report.sens_value(200, "$/tonne"), "$200/tonne")
        self.assertEqual(report.sens_value(None, "x"), "n/a")

    def test_numeric_alignment_detection(self):
        self.assertTrue(report._numeric_like("1,234.5"))
        self.assertTrue(report._numeric_like("-3.2%"))
        self.assertFalse(report._numeric_like("Fully served"))


@unittest.skipUnless(RUN.exists(), "example run not available")
class ReportShipReadiness(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = report.load_run(RUN_ID)
        cls.html = report.build_report(RUN_ID)

    def test_npc_components_sum_to_npc(self):
        for r in self.data["results"].values():
            e = r["economics"]
            total = sum(sign * (e.get(key) or 0) for key, _, sign in report.NPC_COMPONENTS)
            self.assertAlmostEqual(total, e["npc"], delta=max(1.0, abs(e["npc"]) * 1e-9))

    def test_compliance_and_equations_present(self):
        self.assertIn("Technical compliance by scenario", self.html)
        self.assertIn("Key equations", self.html)
        self.assertIn("Net present cost (objective)", self.html)

    def test_no_stale_wording_or_ui_hints(self):
        self.assertNotIn("compliance-adjusted", self.html.lower())
        limitations = re.search(r"Limitations</h3>(.*?)</section>", self.html, re.S).group(1)
        self.assertNotRegex(limitations, r"<li>(?:Use|Upload|Enter|Select|Define) ")

    def test_no_empty_revision_block(self):
        self.assertNotIn("Revision history", self.html)

    def test_no_more_than_four_decimals(self):
        text = re.sub(r"<[^>]+>", " ", self.html)
        self.assertIsNone(re.search(r"\d\.\d{5,}", text))


@unittest.skipUnless(RUN.exists(), "example run not available")
class ReportContent(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = report.build_report(RUN_ID)
        cls.best, cls.feasible = report.pick_best(report.load_run(RUN_ID)["results"])
        cls.result = json.loads((RUN / f"result_{cls.best}.json").read_text(encoding="utf-8"))

    def test_sections_present(self):
        headings = re.findall(r"<h[12][^>]*>(.*?)</h[12]>", self.html, re.S)
        text = " | ".join(re.sub(r"<[^>]+>", "", h) for h in headings)
        for name in SECTIONS:
            self.assertIn(name, text)

    def test_cover_and_run_id(self):
        self.assertIn(RUN_ID, self.html)

    def test_numbers_match_result_json(self):
        e = self.result["economics"]
        self.assertIn(f"{e['npc'] / 1e6:,.2f}", self.html)
        self.assertIn(f"{e['capex'] / 1e6:,.2f}", self.html)
        self.assertIn(self.result["name"], self.html)

    def test_best_option_is_feasible_and_named(self):
        self.assertTrue(self.feasible)
        self.assertEqual(self.result["adequacy"]["unserved_hours"], 0)
        self.assertIn(self.best, self.html)

    def test_not_run_sections_when_outputs_absent(self):
        if not (RUN / "reliability").exists():
            self.assertRegex(self.html, r"(?i)not run")

    def test_self_contained(self):
        self.assertNotRegex(self.html, r"(?i)(src|href)\s*=\s*[\"']https?:")
        self.assertNotIn("<script", self.html.lower())
        self.assertIn("<svg", self.html)
        self.assertIn("@media print", self.html)

    def test_other_scenario_selectable(self):
        other = next(p.stem.split("_", 1)[1] for p in RUN.glob("result_*.json") if p.stem.split("_", 1)[1] != self.best)
        self.assertIn(other, report.build_report(RUN_ID, other))

    def test_headings_are_numbered_in_order(self):
        numbers = re.findall(r'<h2><span class="num">(\d+)</span>', self.html)
        self.assertEqual(numbers, [str(i) for i in range(1, 15)])
        self.assertEqual(len(re.findall(r"<h2>Appendix [A-F] &ndash;", self.html)), 6)
        self.assertRegex(self.html, r"Figure \d+-\d+</strong>")
        self.assertRegex(self.html, r"Table \d+-\d+ &ndash;")
        self.assertIn("List of figures", self.html)
        self.assertIn("List of tables", self.html)
        self.assertIn("Document control", self.html)
        self.assertNotIn("@@sec:", self.html)

    def test_all_scenarios_listed_and_best_highlighted(self):
        for path in RUN.glob("result_*.json"):
            result = json.loads(path.read_text(encoding="utf-8"))
            self.assertIn(f"{result['economics']['npc'] / 1e6:,.2f}", self.html)
            self.assertIn(result["name"], self.html)
        self.assertRegex(self.html, r'<tr class="best">')
        self.assertIn("Best option", self.html)

    def test_design_section_present_or_placeholder(self):
        match = re.search(r'<section class="doc" id="s12">(.*?)</section>', self.html, re.S)
        self.assertIsNotNone(match)
        try:
            import design
            available = hasattr(design, "build_design")
        except ImportError:
            available = False
        if not available:
            self.assertIn("Design not available", match.group(1))


RICH_RUN = "7791be18470745f8af5ef34fa3d208f8"
BARE_RUN = "006ddbffe4e841cd92068dcf8c8cc734"


@unittest.skipUnless((ROOT / "Application Runs" / RICH_RUN).exists(), "full example run not available")
class ReportGraphCoverage(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = report.build_report(RICH_RUN)

    def test_minimum_figure_count_and_takeaways(self):
        figures = re.findall(r"<figure[ >].*?</figure>", self.html, re.S)
        self.assertGreaterEqual(len(figures), 35)
        charts = [f for f in figures if 'class="sld"' not in f]
        with_takeaway = [f for f in charts if 'class="take"' in f]
        self.assertGreaterEqual(len(with_takeaway), 30)

    def test_no_empty_charts(self):
        for svg in re.findall(r"<svg.*?</svg>", self.html, re.S):
            self.assertGreater(len(re.findall(r"<(?:rect|path|polyline|circle|line)\b", svg)), 2)

    def test_new_topics_charted(self):
        for caption in ("Monthly", "Load duration", "forecast", "capacity", "components", "Cumulative", "risk range", "Contingency", "voltage", "Violations"):
            self.assertRegex(self.html, rf"(?i)<figcaption>.*?{caption}", msg=caption)

    def test_dashboard_and_takeaways(self):
        self.assertIn("Decision at a glance", self.html)
        for chip in ("Economic", "Sensitivity", "Reliability", "Power flow"):
            self.assertIn(f'<div class="cn">{chip}</div>', self.html)
        self.assertGreaterEqual(self.html.count("Key takeaways"), 13)

    def test_cross_references_resolve(self):
        self.assertNotIn("@@sec:", self.html)
        self.assertNotIn("the relevant section", self.html)


@unittest.skipUnless((ROOT / "Application Runs" / BARE_RUN).exists(), "bare example run not available")
class ReportWithoutOptionalAnalyses(unittest.TestCase):
    def test_not_run_notes_and_no_empty_charts(self):
        html = report.build_report(BARE_RUN)
        self.assertIn("Sensitivity analysis has not been run", html)
        self.assertIn("NOT RUN", html)
        self.assertNotRegex(html, r"<svg[^>]*>\s*</svg>")
        self.assertNotIn("@@sec:", html)

    def test_section_selection(self):
        html = report.build_report(BARE_RUN, None, None, {"sections": ["data", "economic"]})
        headings = [re.sub(r"<[^>]+>", "", h) for h in re.findall(r"<h2>(.*?)</h2>", html, re.S)]
        self.assertEqual(headings, ["Document control", "Table of contents", "1Data and demand forecast", "2Economic analysis"])


def toc_numbers(doc, titles, last_page):
    """Page number printed beside each title in the contents pages (same text line, right-aligned)."""
    found = {}
    for index in range(last_page):
        for block in doc[index].get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                text = "".join(span["text"] for span in line["spans"]).strip()
                if text in titles and text not in found:
                    y = (line["bbox"][1] + line["bbox"][3]) / 2
                    digits = [w[4] for w in doc[index].get_text("words") if w[4].isdigit() and abs((w[1] + w[3]) / 2 - y) < 3 and w[0] > 450]
                    if digits:
                        found[text] = int(digits[-1])
    return found


@unittest.skipUnless((ROOT / "Application Runs" / RICH_RUN).exists() and report_pdf.available(), "example run or Edge/Chrome not available")
class ReportPdfPageNumbers(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import pymupdf
        cls.html = report.build_report(RICH_RUN)
        cls.pdf = report_pdf.render(cls.html)
        cls.doc = pymupdf.open(stream=cls.pdf, filetype="pdf")

    def test_footer_page_x_of_n_and_no_footer_on_cover(self):
        total = self.doc.page_count
        self.assertIn(f"Page 3 of {total}", self.doc[2].get_text())
        self.assertNotRegex(self.doc[0].get_text(), r"Page \d+ of")
        self.assertIn(f"Page {total} of {total}", self.doc[total - 1].get_text())

    def test_contents_numbers_match_actual_pages(self):
        anchors = set(report_pdf.PLACEHOLDER.findall(self.html))
        actual = report_pdf.anchor_pages(self.pdf, anchors)
        self.assertEqual(len(actual), len(anchors))
        sections = re.findall(r'<div class="toc-row l1[^"]*"><a href="#(s\d+)">.*?<span class="tx">(.*?)</span>', self.html)
        self.assertGreaterEqual(len(sections), 14)
        printed = toc_numbers(self.doc, {title for _, title in sections}, 5)
        self.assertGreaterEqual(len(printed), 5)
        for anchor, title in sections:
            if title in printed:
                self.assertEqual(printed[title], actual[anchor], title)
                self.assertIn(title, self.doc[actual[anchor] - 1].get_text().replace("\n", " "), title)

    def test_figure_and_table_lists_are_numbered_and_stable(self):
        stable = report_pdf.anchor_pages(self.pdf, set(report_pdf.PLACEHOLDER.findall(self.html)))
        filled = report_pdf.inject_pages(self.html, stable)
        self.assertEqual(filled.count('<span class="pg" data-a='), len(report_pdf.PLACEHOLDER.findall(self.html)))
        self.assertEqual(len(re.findall(r"<i></i><b>\d+</b>", filled)), len(stable))
        self.assertEqual(report_pdf.inject_pages(filled, stable), filled)

    def test_html_keeps_empty_placeholders(self):
        self.assertNotRegex(self.html, r"<b>\d+</b></span>")
        self.assertIn('class="pg" data-a="s1"', self.html)

@unittest.skipUnless(RUN.exists(), "example run not available")
class ReportMetadata(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = report.build_report(RUN_ID, None, None, META)

    def test_metadata_is_escaped(self):
        for raw in ("<script>alert(1)</script>", "<b>9</b>", "<img src=x", "<i>private</i>", "</style>Works"):
            self.assertNotIn(raw, self.html)
        self.assertIn("Harbor &lt;script&gt;alert(1)&lt;/script&gt; Microgrid", self.html)
        self.assertIn("ACME &amp; Sons &quot;Ltd&quot;", self.html)
        self.assertNotIn("<script", self.html.lower())
        self.assertNotRegex(self.html, r"(?i)<[a-z][^>]*\sonerror\s*=")

    def test_document_control_fields(self):
        for text in ("Pier 7", "2026-03-05", "For approval", "A. Engineer", "R. Viewer", "P. Approver", "Revision history", "Approvals", "Pier 7"):
            self.assertIn(text, self.html)
        self.assertIn("Rev B", self.html)
        self.assertIn('<img class="logo" src="data:image/png;base64,iVBORw0KGgo="', self.html)
        self.assertIn("Scope A", self.html)

    def test_running_header_is_css_safe(self):
        header = re.search(r"@top-left\{content:\"([^\"]*)\"", self.html).group(1)
        self.assertNotIn("<", header)
        self.assertNotIn("\\", header)

    def test_bad_logo_dropped_and_sections_filtered(self):
        html = report.build_report(RUN_ID, None, None, {"logo": "data:image/svg+xml;base64,PHN2Zz4=", "sections": ["exec", "conclusions", "bogus"]})
        self.assertNotIn('class="logo"', html)
        headings = [re.sub(r"<[^>]+>", "", h) for h in re.findall(r"<h2>(.*?)</h2>", html, re.S)]
        self.assertEqual(headings, ["Document control", "Table of contents", "1Executive summary", "2Conclusions and recommendations"])

    def test_design_contract_with_stub(self):
        import types
        stub = types.ModuleType("design")
        stub.build_design = lambda run_id, scenario: {"scenario": scenario, "criteria": [{"item": "Voltage", "value": "34.5 kV"}],
                                                      "transformers": [{"tag": "TX-1", "mva": 50}], "bom": [{"item": "XLPE cable <x>", "qty": 3}]}
        stub.sld_svg = lambda design: '<svg viewBox="0 0 10 10" onload="x()"><script>x()</script><rect width="5" height="5"/></svg>'
        saved = sys.modules.get("design")
        sys.modules["design"] = stub
        try:
            html = report.build_report(RUN_ID, None, None, {"sections": ["design"]})
        finally:
            if saved is None:
                del sys.modules["design"]
            else:
                sys.modules["design"] = saved
        self.assertNotIn("TX-1", html)
        self.assertNotIn("XLPE cable", html)
        self.assertIn("technical design report", html)
        self.assertIn("Single-line diagram", html)
        self.assertIn("<rect", html)
        self.assertNotIn("onload", html)
        self.assertNotIn("<script", html.lower())
        self.assertNotIn("Design not available", html)


@unittest.skipUnless(RUN.exists(), "example run not available")
class ReportRoutes(unittest.TestCase):
    def test_http_endpoints(self):
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)], cwd=ROOT,
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try:
                    urlopen(base + "/api/defaults", timeout=.5).read()
                    break
                except OSError:
                    time.sleep(.1)
            with urlopen(f"{base}/api/x/report?run_id={RUN_ID}", timeout=60) as response:
                self.assertTrue(response.headers["Content-Type"].startswith("text/html"))
                body = response.read().decode("utf-8")
            self.assertIn("Executive summary", body)
            request = Request(f"{base}/api/x/report", method="POST", headers={"Content-Type": "application/json"},
                              data=json.dumps({"run_id": RUN_ID, "meta": META}).encode("utf-8"))
            with urlopen(request, timeout=60) as response:
                self.assertTrue(response.headers["Content-Type"].startswith("text/html"))
                posted = response.read().decode("utf-8")
            self.assertIn("ACME &amp; Sons", posted)
            self.assertIn("Rev B", posted)
            with urlopen(f"{base}/api/x/report_summary?run_id={RUN_ID}", timeout=30) as response:
                digest = json.load(response)
            self.assertEqual(digest["run_id"], RUN_ID)
            self.assertTrue(digest["scenarios"])
            with urlopen(base + "/report.js", timeout=5) as response:
                self.assertIn("reportUi", response.read().decode("utf-8"))
        finally:
            server.terminate()
            server.wait(10)


@unittest.skipUnless(RUN.exists(), "example run not available")
class OptionalFieldsAndSummaryPdf(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.empty = report.build_report(RUN_ID, None, None, {})

    def test_empty_meta_leaves_no_placeholders(self):
        for bad in (">undefined<", "undefined ", ">None<", ">Rev <", "Rev 0", "For information"):
            self.assertNotIn(bad, self.empty.replace("can be undefined", ""))
        self.assertNotIn("<td>Revision</td><td></td>", self.empty)

    def test_blank_strings_equal_empty(self):
        blanks = {k: "" for k in ("project_name", "client_name", "revision", "issue_purpose", "notes")}
        blanks["sections"] = []
        html = report.build_report(RUN_ID, None, None, blanks)
        self.assertNotIn(">undefined<", html)
        self.assertIn("Executive summary", html)

    def test_no_more_than_four_decimals_in_text(self):
        text = re.sub(r"<(style|script)[^>]*>.*?</\1>|<[^>]+>", " ", self.empty, flags=re.S)
        self.assertEqual(re.findall(r"\d+\.\d{5,}", text), [])

    def test_summary_pdf_is_short_real_pdf(self):
        import summary_pdf
        import io
        import pypdf
        data = summary_pdf.build(RUN_ID)
        self.assertTrue(data.startswith(b"%PDF"))
        pages = len(pypdf.PdfReader(io.BytesIO(data)).pages)
        self.assertTrue(2 <= pages <= 4, pages)
        self.assertNotRegex(Path(summary_pdf.__file__).read_text(encoding="utf-8"), r"import matplotlib\.pyplot|from matplotlib import pyplot")


if __name__ == "__main__":
    unittest.main()
