"""Verified corrections for a power-flow screening report.

Every numeric suggestion is applied to the electrical model (an `assumptions` patch) and the violating cases are re-solved, so a
suggestion is only offered when it is shown to clear (or at least improve) the violation it targets.  Rules:

* The microgrid minimum/maximum is the client's allowed range.  Suggestions may only WIDEN it (raise the maximum) and never lower the
  maximum or raise the minimum above the maximum.  When the network cannot host what the range allows, an advisory in plain language
  is given instead of an input suggestion.
* Cheapest effective remedy first: transformer tap, voltage set-point and inverter power factor (set-point changes, no equipment) before a
  shunt capacitor / reactor (net Mvar: + capacitor raises V, - reactor lowers V), before a transformer/line upgrade or a larger
  reactive capability.  Remedies are ranked by their indicative cost (pf_costs); a capacitor and a reactor are never combined.
  A transformer or line overload is first tried against a capacitor at its load side and the cheaper verified option is offered.

Entry point: suggest(report, net, values, verifier) -> (rows, patch).  `patch` is the combined assumptions patch of the recommended
electrical rows (used by screen_run for the final re-screen)."""
import copy
import json
import math

import pf_costs
import power_flow as pf

SHUNT_LEVELS = [0.3, 0.6, 0.9, 1.2, 1.8, 2.4, 3.0, 3.6, 4.8, 6.0, 7.2, 9.6, 12.0, 15.0, 20.0, 25.0, 30.0]
TAP_STEPS = [0.025, 0.05, 0.075, 0.1]
VSET_STEPS = [0.01, 0.02, 0.03, 0.04, 0.05]
PF_LEVELS = [0.98, 0.95, 0.92, 0.9]
VOLTAGE = ("voltage_low", "voltage_high")
THERMAL = ("thermal", "high_loading")


def _merge(base, piece):
    out = copy.deepcopy(base or {})
    for group in ("nodes", "lines"):
        for ident, row in (piece.get(group) or {}).items():
            out.setdefault(group, {}).setdefault(ident, {}).update(row)
    return out


class Result:
    def __init__(self, items, vmin, vmax, loads):
        self.items, self.vmin, self.vmax, self.loads = items, vmin, vmax, loads
        self.keys = {(label, v["type"], v["component"]) for label, _, v in items}
        self.fails = {(label, v["type"], v["component"]) for label, _, v in items if v["severity"] == "fail"}
        excess = 0.0
        for _, _, v in items:
            if v["type"] in VOLTAGE:
                excess += abs(v["value"] - v["limit"])
            elif v["type"] in THERMAL:
                excess += (v["value"] - v["limit"]) / 100.0
            else:
                excess += 0.01
        self.score = (len(self.fails), len(self.items), round(excess, 6))


class Verifier:
    """Re-solves the report's cases on a patched model.  Normal cases are always solved; N-1 cases only when they had violations."""

    def __init__(self, ctx, code, data, assumptions, topology, report):
        self.ctx, self.code, self.data, self.assumptions, self.topology = ctx, code, data, assumptions, topology
        self.specs = []
        for case in report["cases"]:
            detail = case.get("detail") or {}
            hour = case.get("hour_index", detail.get("hour_index"))
            if hour is None or (case["emergency"] and not case["violations"]):
                continue
            self.specs.append(dict(label=case["label"], hour=int(hour), emergency=bool(case["emergency"]),
                                   outages=list(case.get("outages") or detail.get("outages") or []),
                                   gens_out=list(case.get("gens_out") or detail.get("gens_out") or [])))
        self.cache, self.runs = {}, 0

    def run(self, patch):
        key = json.dumps(patch, sort_keys=True, default=str)
        if key in self.cache:
            return self.cache[key]
        self.runs += 1
        net = pf._prepare(self.ctx, self.code, _merge(self.assumptions, patch), self.topology, self.data)
        items, vmin, vmax, loads = [], None, None, {}
        for spec in self.specs:
            case = pf._case_for_hour(net, self.data, spec["hour"], spec["label"], outages=spec["outages"], gens_out=spec["gens_out"])
            items.extend((spec["label"], spec["emergency"], v) for v in pf.evaluate(net, case, spec["emergency"]))
            if not spec["emergency"] and case["converged"]:
                live = [b["vm"] for b in case["buses"] if b["energized"] and b["kind"] != "source"]
                if live:
                    vmin = min(live) if vmin is None else min(vmin, min(live))
                    vmax = max(live) if vmax is None else max(vmax, max(live))
            for br in case["branches"]:
                if br["energized"] and br["rating_mva"]:
                    loads[br["id"]] = max(loads.get(br["id"], 0.0), br["loading_pct"])
        self.cache[key] = Result(items, vmin, vmax, loads)
        return self.cache[key]


class Engine:
    def __init__(self, report, net, values, verifier):
        self.report, self.net, self.V = report, net, verifier
        self.values = values or {}
        self.scenario = report.get("scenario")
        self.nm = lambda ident: net.names.get(ident, ident)
        self.branches = {b["id"]: b for b in net.branches}
        self.caps = {g["tech"]: (g["cap"] or 0.0) for g in net.gens if g["tech"] != "grid"}
        self.cur_max = pf._number(self.values.get("microgrid_max_mw"))
        if self.cur_max is None and self.caps:
            self.cur_max = max(self.caps.values())
        self.cur_min = pf._number(self.values.get("microgrid_min_mw")) or 0.0
        self.costs = pf.cost_overrides(getattr(net, "settings", None))
        self.rows, self.acc = {}, {}
        if verifier is not None:
            self.cur = verifier.run({})
        else:
            items = [(c["label"], bool(c["emergency"]), v) for c in report["cases"] for v in c["violations"]]
            self.cur = Result(items, None, None, {})

    # ------------------------------------------------------------------ helpers
    def detail_row(self, group, ident, key="id"):
        for case in self.report["cases"]:
            for row in (case.get("detail") or {}).get(group, []):
                if row.get(key) == ident:
                    return row
        return None

    def of_type(self, *types):
        return [it for it in self.cur.items if it[2]["type"] in types]

    def clears(self, res, targets):
        return not (res.keys & targets) and not (res.fails - self.cur.fails)

    def node_value(self, ident, key, default=None):
        patched = (self.acc.get("nodes") or {}).get(ident, {})
        return patched[key] if key in patched else default

    def shunt_total(self, bus_id):
        return self.node_value(bus_id, "shunt_mvar", self.net.bus(bus_id)["shunt_mvar"])

    def evidence(self, items):
        label, _, v = max(items, key=lambda it: self._excess(it[2]))
        return f"Evidence: {v['message']} (case: {label})"

    @staticmethod
    def _excess(v):
        if v.get("value") is None or v.get("limit") is None:
            return 0.0
        return abs(v["value"] - v["limit"])

    def verify_text(self, before, after, extra=""):
        parts = [f"Re-screened with this change applied: {len(before.items)} -> {len(after.items)} violation(s)"]
        if after.vmin is not None:
            parts.append(f"voltage range {after.vmin:.3f}-{after.vmax:.3f} pu (before {before.vmin:.3f}-{before.vmax:.3f})")
        return "; ".join(parts) + "." + (" " + extra if extra else "")

    def price(self, row):
        """Attach the cost-model inputs to a row and return its indicative cost in USD (used to rank remedies and to price the row)."""
        ctx = pf_costs.context_for(self.net, row)
        target = row.get("target") or {}
        if target.get("kind") == "line" and target.get("key") == "tap":
            detail = self.detail_row("branches", target.get("id"))
            ctx["mva"] = (detail or {}).get("rating_mva")
        row["cost_inputs"] = ctx
        row["cost_usd"], row["cost_basis"] = pf.row_cost(row, self.costs)
        return row["cost_usd"]

    def shunt_conflict(self, sign):
        """True when an accepted change already moves a shunt the opposite way (never a capacitor and a reactor in one design)."""
        return any((row["shunt_mvar"] - self.net.bus(bus)["shunt_mvar"]) * sign < -1e-9
                   for bus, row in (self.acc.get("nodes") or {}).items() if "shunt_mvar" in row)

    def put(self, row):
        key = (row["target"]["kind"], row["target"]["key"], row["target"].get("id"))
        old = self.rows.get(key)
        if old is not None and old.get("recommended") and row.get("recommended"):
            row["current"] = old["current"]
        elif old is not None and old.get("recommended") and not row.get("recommended"):
            return
        self.rows[key] = row

    def make(self, violation, items, component, target, label, unit, current, suggested, reason, **extra):
        sev = "fail" if any(it[2]["severity"] == "fail" for it in items) else "warn"
        worst = max(items, key=lambda it: self._excess(it[2]))
        row = dict(id=f"{self.scenario}:{target['kind']}:{target['key']}:{target.get('id') or ''}", scenario=self.scenario,
                   case=worst[0], violation=violation, severity=sev, component=component, label=label, unit=unit,
                   current=None if current is None else round(float(current), 4), suggested=round(float(suggested), 4),
                   direction="up" if current is None or suggested >= current else "down", reason=reason,
                   recommended=True, applicable=True, target=target, verified=None, verification="", predicted=None,
                   alternative=False)
        row.update(extra)
        return row

    def adopt(self, piece, row, before, after, cleared):
        self.acc = _merge(self.acc, piece)
        row["verified"] = True if cleared else "partial"
        row["verification"] = self.verify_text(before, after, "" if cleared else "Improves the case but does not clear it completely; see the advisory.")
        self.put(row)
        self.cur = after

    # ------------------------------------------------------------------ A: thermal
    def thermal(self):
        net = self.net
        for bid in dict.fromkeys(it[2]["component"] for it in self.of_type(*THERMAL)):
            br, row = self.branches.get(bid), self.detail_row("branches", bid)
            if not br or not row or not row["rating_mva"]:
                continue
            mine = [it for it in self.cur.items if it[2]["type"] in THERMAL and it[2]["component"] == bid]
            worst = max(it[2]["value"] for it in mine)
            flow = row["rating_mva"] * worst / 100.0
            high, limit = net.limits["high"] / 100.0, net.limits["thermal"] / 100.0
            transformer = br["kind"] == "transformer"
            predicted = pf.standard_mva(flow / high) if transformer else round(flow / high, 2)
            if transformer:
                options = [s for s in pf.STD_MVA if s >= flow / limit and s > row["rating_mva"] * 1.001][:6]
                key = "mva"
            else:
                base = flow / high
                options = sorted({math.ceil(base * m * 2) / 2.0 for m in (1.0, 1.15, 1.3, 1.6, 2.0, 3.0)})
                options = [s for s in options if s > row["rating_mva"] * 1.001]
                key = "rating_mva"
            targets = {k for k in self.cur.keys if k[2] == bid and k[1] in THERMAL}
            before = self.cur
            for size in options:
                piece = dict(lines={bid: {key: size}})
                if self.V is None:
                    chosen, res = size, None
                    if size < predicted:
                        continue
                else:
                    res = self.V.run(_merge(self.acc, piece))
                    if not self.clears(res, targets):
                        continue
                    chosen = size
                kind = "Transformer" if transformer else "Line"
                case = max(mine, key=lambda it: it[2]["value"])
                after = f"{res.loads.get(bid, 0):.0f} %" if res else f"about {flow / chosen * 100:.0f} %"
                reason = (f"{kind} {self.nm(bid)} carries {flow:.1f} MVA, {worst:.0f} % of its {row['rating_mva']:.4g} MVA rating "
                          f"(limit {net.limits['thermal']:.0f} %, planning margin {net.limits['high']:.0f} %; worst case: {case[0]}). "
                          f"A {chosen:g} MVA {'standard transformer' if transformer else 'rating (re-conductor or parallel circuit)'} "
                          f"brings the worst loading to {after}.")
                new = self.make(case[2]["type"], mine, bid, dict(kind="line", key=key, id=bid),
                                f"{kind} {self.nm(bid)} rating", "MVA", row["rating_mva"], chosen, reason, predicted=predicted)
                if res is None:
                    new["verified"] = None
                    self.put(new)
                else:
                    self.adopt(piece, new, before, res, True)
                break

    # ------------------------------------------------------------------ C: reactive capability
    def reactive(self):
        for comp in dict.fromkeys(it[2]["component"] for it in self.of_type("reactive_limit")):
            row = self.detail_row("gens", comp)
            gen = next((g for g in self.net.gens if g["node"] == comp and g["tech"] != "grid"), None)
            if not gen or not row:
                continue
            mine = [it for it in self.cur.items if it[2]["type"] == "reactive_limit" and it[2]["component"] == comp]
            lo, hi = row["q_min"], row["q_max"]
            hi_need = lo_need = 0.0
            for it in mine:
                crow = next((g for c in self.report["cases"] if c["label"] == it[0] for g in c["detail"].get("gens", []) if g["id"] == comp), None)
                if crow:
                    if crow["q_mvar"] >= 0:
                        hi_need = max(hi_need, crow["q_mvar"])
                    else:
                        lo_need = max(lo_need, -crow["q_mvar"])
            upper = hi_need >= lo_need
            targets = {(it[0], it[2]["type"], comp) for it in mine if not it[1]} or {(it[0], it[2]["type"], comp) for it in mine}
            before = self.cur
            seen = set()
            done = False

            def widen(value, need, mult):
                if need <= 0:
                    return value
                raw = max(abs(value), need) * mult
                step = 0.05 if raw < 2 else 0.1 if raw < 10 else 0.5
                return math.ceil(raw / step - 1e-9) * step

            for mult in (1.1, 1.25, 1.5, 2.0, 3.0, 5.0):
                new_hi, new_lo = widen(hi, hi_need, mult), -widen(-lo, lo_need, mult)
                if (new_hi, new_lo) in seen:
                    continue
                seen.add((new_hi, new_lo))
                piece = dict(nodes={comp: {"q_min_mvar": new_lo, "q_max_mvar": new_hi}})
                res = self.V.run(_merge(self.acc, piece)) if self.V else None
                if res is not None and not self.clears(res, targets):
                    continue
                changed = [("q_max_mvar", "Qmax", hi, new_hi, "q_min_mvar", new_lo), ("q_min_mvar", "Qmin", lo, new_lo, "q_max_mvar", new_hi)]
                for key, name, old, new_val, other, other_val in changed:
                    if new_val == old:
                        continue
                    reason = (f"{self.nm(comp)} reached its {name} limit of {old:.4g} Mvar and cannot hold its voltage set-point "
                              f"(needs about {(hi_need if name == 'Qmax' else lo_need):.3g} Mvar {'injection' if name == 'Qmax' else 'absorption'}; "
                              f"Qmin is negative = absorbs). Widening it to {new_val:.4g} Mvar lets it regulate in the screened cases. "
                              "Needs a larger inverter/machine reactive capability.")
                    new = self.make("reactive_limit", mine, comp, dict(kind="node", key=key, id=comp, also={other: other_val}),
                                    f"Reactive capability ({name}) at {self.nm(comp)}", "Mvar", old, new_val, reason,
                                    predicted=round((hi_need if name == "Qmax" else -lo_need) * 1.25, 3))
                    if res is None:
                        new["verified"] = None
                        self.put(new)
                    else:
                        self.adopt(dict(), new, before, res, True)
                if res is not None:
                    self.acc = _merge(self.acc, piece)
                done = True
                break
            if not done and self.V is not None and gen.get("control") == "voltage":
                self.reactive_setpoint(comp, gen, row, mine, targets, upper)

    def reactive_setpoint(self, comp, gen, row, mine, targets, upper):
        """Capability widening cannot clear it: let the machine regulate to a set-point it can hold."""
        v0 = self.node_value(comp, "vset", gen["vset"])
        sign = -1 if upper else 1
        levels = [s for s in VSET_STEPS if 0.9 <= v0 + sign * s <= 1.1]
        found = self.search(levels, lambda s: dict(nodes={comp: dict(vset=round(v0 + sign * s, 3))}), targets)
        if found is None or not found[2]:
            return
        piece, res, _, step = found
        new_v = piece["nodes"][comp]["vset"]
        reason = (f"{self.nm(comp)} is at its {'Qmax' if upper else 'Qmin'} limit ({row['q_max'] if upper else row['q_min']:.4g} Mvar) because its voltage "
                  f"set-point ({v0:.3f} pu) is {'above' if upper else 'below'} what the network voltage allows. Setting it to {new_v:.3f} pu lets it regulate "
                  "inside its reactive capability (a larger capability would have to be unreasonably large for this unit).")
        new = self.make("reactive_limit", mine, comp, dict(kind="node", key="vset", id=comp),
                        f"Voltage set-point at {self.nm(comp)}", "pu", v0, new_v, reason)
        self.adopt(piece, new, self.cur, res, True)
    def search(self, levels, make, targets):
        """Smallest level that clears the targets (bisection; levels ascending).  -> (piece, result, cleared) or None."""
        tested = {}

        def test(i):
            if i not in tested:
                piece = make(levels[i])
                res = self.V.run(_merge(self.acc, piece))
                tested[i] = (piece, res, self.clears(res, targets), levels[i])
            return tested[i]
        if not levels:
            return None
        if not test(len(levels) - 1)[2]:
            for i in range(len(levels)):
                test(i)
            cleared = [t for t in tested.values() if t[2]]
            best = min(cleared or tested.values(), key=lambda t: (not t[2], t[1].score))
            return (best[0], best[1], best[2], best[3]) if best[1].score < self.cur.score else None
        lo, hi = 0, len(levels) - 1
        while lo < hi:
            mid = (lo + hi) // 2
            if test(mid)[2]:
                hi = mid
            else:
                lo = mid + 1
        return test(hi)

    def sites(self, targets):
        net = self.net
        worst = max((it for it in self.cur.items if (it[0], it[2]["type"], it[2]["component"]) in targets), key=lambda it: self._excess(it[2]))
        out = [worst[2]["component"]]
        keep, Z = pf._zbus(net)
        if keep is not None:
            need = {}
            for it in self.cur.items:
                if (it[0], it[2]["type"], it[2]["component"]) in targets:
                    need[it[2]["component"]] = max(need.get(it[2]["component"], 0.0), self._excess(it[2]) + 0.005)
            rank, best = dict(load=0, bus=1, substation=2), None
            for k in keep:
                if net.buses[k]["kind"] not in rank and net.buses[k]["id"] not in need:
                    continue
                xs = [Z[keep.index(net.index[b]), keep.index(k)].imag for b in need if net.index[b] in keep]
                if len(xs) != len(need) or min(xs) <= 1e-9:
                    continue
                q = max(dv * pf.BASE_MVA / x for dv, x in zip(need.values(), xs))
                score = (round(q, 3), rank.get(net.buses[k]["kind"], 3))
                if best is None or score < best[0]:
                    best = (score, net.buses[k]["id"])
            if best and best[1] not in out:
                out.append(best[1])
        return out

    def shunt_family(self, side, targets, mine):
        sign = 1 if side == "voltage_low" else -1
        if self.shunt_conflict(sign):
            return None
        best = None
        for bus in self.sites(targets):
            total = self.shunt_total(bus)
            levels = set(SHUNT_LEVELS)
            if sign < 0 and total > 0.05:
                levels.add(round(total, 3))
            found = self.search(sorted(levels), lambda d, bus=bus, total=total: dict(nodes={bus: dict(shunt_mvar=round(total + sign * d, 3))}), targets)
            if found is None:
                continue
            piece, res, cleared, delta = found
            score = (not cleared, delta)
            if best is None or score < best[0]:
                best = (score, bus, total, piece, res, cleared, delta)
        if best is None:
            return None
        _, bus, total, piece, res, cleared, delta = best
        new_total = piece["nodes"][bus]["shunt_mvar"]
        xth = pf._thevenin_x(self.net, bus)
        excess = max(self._excess(it[2]) for it in mine) + 0.005
        predicted = round(sign * excess * pf.BASE_MVA / xth, 3) if xth else None
        worst = max(mine, key=lambda it: self._excess(it[2]))
        v = worst[2]
        word = "below" if sign > 0 else "above"
        what = ("capacitor (positive Mvar raises voltage)" if new_total > 0 else "reactor (negative Mvar lowers voltage)") if new_total != 0 else "no shunt"
        verb = "adding" if sign > 0 else "removing/absorbing"
        reason = (f"{len(set(it[2]['component'] for it in mine))} bus(es) are {word} the voltage limit; worst {self.nm(v['component'])} at {v['value']:.4f} pu "
                  f"(limit {v['limit']:.4g} pu, case: {worst[0]}). Net shunt at {self.nm(bus)} changes from {total:.4g} to {new_total:.4g} Mvar "
                  f"({what}; {verb} {delta:.4g} Mvar of reactive support). Linear estimate {predicted if predicted is not None else 'n/a'} Mvar.")
        row = self.make(v["type"], mine, bus, dict(kind="node", key="shunt_mvar", id=bus),
                        f"Net shunt at {self.nm(bus)} (+ capacitor raises V / - reactor lowers V)", "Mvar", total, new_total, reason,
                        predicted=None if predicted is None else round(total + predicted, 3))
        return piece, row, res, cleared

    def tap_family(self, side, targets, mine):
        sign = 1 if side == "voltage_low" else -1
        best = None
        for br in [b for b in self.net.branches if b["kind"] == "transformer" and b["on"]][:3]:
            t0 = (self.acc.get("lines") or {}).get(br["id"], {}).get("tap", br["tap"])
            trial = {}
            for d in (1, -1):
                piece = dict(lines={br["id"]: dict(tap=round(min(max(t0 + d * TAP_STEPS[0], 0.8), 1.2), 4))})
                trial[d] = self.V.run(_merge(self.acc, piece)).score
            d = min(trial, key=trial.get)
            if trial[d] >= self.cur.score:
                continue
            levels = [s for s in TAP_STEPS if 0.8 <= t0 + d * s <= 1.2]
            found = self.search(levels, lambda s, br=br, d=d, t0=t0: dict(lines={br["id"]: dict(tap=round(t0 + d * s, 4))}), targets)
            if found is None:
                continue
            piece, res, cleared, step = found
            if best is None or (not cleared, step) < (not best[0], best[1]):
                best = (cleared, step, br, t0, piece, res, d)
        if best is None:
            return None
        cleared, step, br, t0, piece, res, d = best
        new = piece["lines"][br["id"]]["tap"]
        worst = max(mine, key=lambda it: self._excess(it[2]))
        reason = (f"Voltage {'below' if sign > 0 else 'above'} limit at {self.nm(worst[2]['component'])} ({worst[2]['value']:.4f} pu, case: {worst[0]}). "
                  f"Changing the {self.nm(br['id'])} tap ratio from {t0:.4g} to {new:.4g} ({step * 100:.1f} %) shifts the voltage profile; verified by re-solving.")
        row = self.make(worst[2]["type"], mine, br["id"], dict(kind="line", key="tap", id=br["id"]),
                        f"Transformer {self.nm(br['id'])} tap ratio", "ratio", t0, new, reason)
        return piece, row, res, cleared

    def vset_family(self, side, targets, mine):
        sign = 1 if side == "voltage_low" else -1
        best = None
        for g in [g for g in self.net.gens if g["tech"] != "grid" and g["on"] and g.get("control") == "voltage"][:3]:
            v0 = self.node_value(g["node"], "vset", g["vset"])
            levels = [s for s in VSET_STEPS if 0.9 <= v0 + sign * s <= 1.1]
            found = self.search(levels, lambda s, g=g, v0=v0: dict(nodes={g["node"]: dict(vset=round(v0 + sign * s, 3))}), targets)
            if found is None:
                continue
            piece, res, cleared, step = found
            if best is None or (not cleared, step) < (not best[0], best[1]):
                best = (cleared, step, g, v0, piece, res)
        if best is None:
            return None
        cleared, step, g, v0, piece, res = best
        new = piece["nodes"][g["node"]]["vset"]
        worst = max(mine, key=lambda it: self._excess(it[2]))
        reason = (f"Voltage {'below' if sign > 0 else 'above'} limit at {self.nm(worst[2]['component'])} ({worst[2]['value']:.4f} pu, case: {worst[0]}). "
                  f"Moving the {self.nm(g['node'])} voltage set-point from {v0:.3f} to {new:.3f} pu lets the machine's AVR "
                  f"{'raise' if sign > 0 else 'lower'} the local voltage (within its reactive capability).")
        row = self.make(worst[2]["type"], mine, g["node"], dict(kind="node", key="vset", id=g["node"]),
                        f"Voltage set-point at {self.nm(g['node'])}", "pu", v0, new, reason)
        return piece, row, res, cleared

    def pf_family(self, side, targets, mine):
        sign = 1 if side == "voltage_low" else -1
        mode = "lag" if sign > 0 else "lead"
        best = None
        gens = [g for g in self.net.gens if g["tech"] != "grid" and g["on"] and g.get("control") == "pf" and g.get("inverter")]
        for g in sorted(gens, key=lambda g: -(g["cap"] or 0))[:3]:
            pf0 = self.node_value(g["node"], "pf", g["pf"])
            mode0 = self.node_value(g["node"], "pf_mode", g["pf_mode"])
            levels = sorted([p for p in PF_LEVELS if mode0 != mode or p < pf0], reverse=True)
            found = self.search(levels, lambda p, g=g: dict(nodes={g["node"]: dict(pf=p, pf_mode=mode)}), targets)
            if found is None:
                continue
            piece, res, cleared, level = found
            if best is None or (not cleared, -level) < (not best[0], -best[1]):
                best = (cleared, level, g, pf0, mode0, piece, res)
        if best is None:
            return None
        cleared, level, g, pf0, mode0, piece, res = best
        worst = max(mine, key=lambda it: self._excess(it[2]))
        reason = (f"Voltage {'below' if sign > 0 else 'above'} limit at {self.nm(worst[2]['component'])} ({worst[2]['value']:.4f} pu, case: {worst[0]}). "
                  f"Running {self.nm(g['node'])} at power factor {level:g} {mode} ({'injects' if sign > 0 else 'absorbs'} Mvar; currently {pf0:g} {mode0}) "
                  "changes its reactive exchange; verified by re-solving.")
        row = self.make(worst[2]["type"], mine, g["node"], dict(kind="node", key="pf", id=g["node"], also=dict(pf_mode=mode)),
                        f"Power factor at {self.nm(g['node'])} (set {mode}: {'injects' if sign > 0 else 'absorbs'} Mvar)", "pf", pf0, level, reason)
        return piece, row, res, cleared

    def voltage(self):
        families = (self.tap_family, self.vset_family, self.pf_family, self.shunt_family)
        for rnd in range(3):
            vv = self.of_type(*VOLTAGE)
            if not vv:
                break
            side_rank = {}
            for kind in VOLTAGE:
                mine = [it for it in vv if it[2]["type"] == kind]
                if mine:
                    side_rank[kind] = (any(it[2]["severity"] == "fail" for it in mine), max(self._excess(it[2]) for it in mine))
            side = max(side_rank, key=side_rank.get)
            mine = [it for it in vv if it[2]["type"] == side]
            targets = {(it[0], it[2]["type"], it[2]["component"]) for it in mine}
            options = []
            for fam in families:
                got = fam(side, targets, mine)
                if got is not None:
                    options.append(got)
                if rnd > 0 and got is not None and got[3]:
                    break
            if not options:
                break
            cleared = [(self.price(o[1]), n, o) for n, o in enumerate(options) if o[3]]
            chosen = min(cleared, key=lambda c: c[:2])[2] if cleared else None
            if chosen is None:
                chosen = min(options, key=lambda o: o[2].score)
            before = self.cur
            piece, row, res, cleared = chosen
            self.adopt(piece, row, before, res, cleared)
            if rnd == 0:
                for o in options:
                    if o is not chosen and o[3]:
                        alt = o[1]
                        alt.update(recommended=False, alternative=True, verified=True,
                                   verification=self.verify_text(before, o[2], "Alternative to the recommended change (verified on its own)."))
                        alt["reason"] = "Alternative: " + alt["reason"]
                        self.put(alt)
            if not cleared and rnd == 2:
                break

    # ------------------------------------------------------------------ D: advisories and microgrid range
    def advisories(self):
        net, nm = self.net, self.nm
        voltage_done = set()
        for case_label, emergency, v in self.cur.items:
            t = v["type"]
            sev = v["severity"]
            items = [(case_label, emergency, v)]
            if t in VOLTAGE:
                same = [it for it in self.cur.items if it[2]["type"] == t]
                worst = max(same, key=lambda it: self._excess(it[2]))
                if t in voltage_done or (case_label, v["component"]) != (worst[0], worst[2]["component"]):
                    continue
                voltage_done.add(t)
                items, v, case_label = same, worst[2], worst[0]
                buses = len({it[2]["component"] for it in same})
            if t == "reactive_limit":
                if ("reactive", v["component"]) in voltage_done:
                    continue
                voltage_done.add(("reactive", v["component"]))
                same = [it for it in self.cur.items if it[2]["type"] == t and it[2]["component"] == v["component"]]
                self.put(self.make(t, same, v["component"], dict(kind="advice", key="reactive_limit", id=v["component"]),
                                   f"Advisory: {nm(v['component'])} at its reactive limit", "Mvar", v["value"], v["value"],
                                   f"{nm(v['component'])} reaches its reactive-power limit in {len(same)} screened case(s) while holding its voltage set-point, "
                                   "and widening Qmin/Qmax in verified steps does not remove it (the unit is small compared with the network's reactive needs). "
                                   "Options: put it on constant power-factor control, move its set-point closer to the bus voltage it actually sees, use a larger "
                                   "machine/inverter, or accept it (this is a warning, not a limit violation).",
                                   recommended=False, applicable=False))
            elif t == "islanded":
                outage = next((c["detail"]["outages"][0] for c in self.report["cases"] if c["label"] == case_label and c["detail"].get("outages")), v["component"])
                self.put(self.make(t, items, outage, dict(kind="advice", key="redundancy", id=outage),
                                   f"Add a parallel feeder/transformer for {nm(outage)}", "MW served", None, v["value"],
                                   v["message"] + " Technically no remedy exists without topology change; options: a second feeder/transformer, "
                                   "or a grid-forming BESS/genset in the isolated section.", recommended=False, applicable=False,
                                   verified=None, direction="up"))
            elif t == "forming_overload":
                self.forming(items)
            elif t == "non_convergence" and not emergency:
                self.convergence(items)
            elif t in VOLTAGE:
                word = "low" if t == "voltage_low" else "high"
                text = (f"Technically the network cannot keep {nm(v['component'])}{f' and {buses - 1} other bus(es)' if buses > 1 else ''} within {v['limit']:.4g} pu in '{case_label}' "
                        f"(worst {v['value']:.4f} pu, voltage {word}) with the verified changes above"
                        + (": a fixed shunt/tap that fixes the peak-load hours over- or under-corrects at the other extreme (light load vs peak). " if any(k for k in self.rows if k[1] in ("shunt_mvar", "tap")) else ". ")
                        + "Options: "
                        + ("add reactive support (capacitor/STATCOM) or a stronger grid connection, upgrade the feeder, or accept curtailment/lower dispatch in that hour."
                           if t == "voltage_low" else
                           "let inverters/generators absorb reactive power, add a shunt reactor, change the transformer tap, or curtail P in the high-voltage hours.")
                        + " The microgrid min/max range is not changed for this.")
                self.put(self.make(t, items, v["component"], dict(kind="advice", key="voltage_" + word, id=v["component"]),
                                   f"Advisory: {word} voltage at {nm(v['component'])}", "pu", v["value"], v["limit"], text,
                                   recommended=False, applicable=False, direction="down" if word == "high" else "up"))
            elif t == "thermal":
                self.put(self.make(t, items, v["component"], dict(kind="advice", key="overload", id=v["component"]),
                                   f"Advisory: {nm(v['component'])} overloaded", "%", v["value"], v["limit"],
                                   f"Technically {nm(v['component'])} cannot carry the flow in '{case_label}' ({v['value']:.0f} % of rating) with the "
                                   "sizes tried. Options: a larger rating, a parallel circuit/transformer, or curtailing generation behind it.",
                                   recommended=False, applicable=False, direction="down"))

    def microgrid_row(self, key, label, current, suggested, reason, items, violation):
        row = self.make(violation, items, "network", dict(kind="field", key=key), label, "MW", current, suggested, reason,
                        recommended=False, group="microgrid_limits", page="Microgrid", verified=None,
                        verification="Not verifiable by a power-flow re-screen: the optimiser must be re-run with the new limit.")
        self.put(row)

    def forming(self, items):
        v = items[0][2]
        need = math.ceil(v["value"] * 1.05 * 10) / 10.0
        advice = (f"In '{items[0][0]}' the grid-forming unit at {self.nm(v['component'])} would have to supply {v['value']:.2f} MW but is rated "
                  f"{v['limit']:.2f} MW. Technically the island cannot be supplied without more grid-forming capacity there. Options: a larger or "
                  "second grid-forming BESS/genset, load shedding in that contingency, a parallel grid tie, or accept it as an N-1 warning.")
        self.put(self.make("forming_overload", items, v["component"], dict(kind="advice", key="forming_capacity", id=v["component"]),
                           f"Advisory: grid-forming capacity at {self.nm(v['component'])}", "MW", v["limit"], need, advice,
                           recommended=False, applicable=False, direction="up"))
        if self.cur_max is None:
            return
        if need <= self.cur_max:
            if need > self.cur_min:
                self.microgrid_row("microgrid_min_mw", "Minimum microgrid size", self.cur_min, need,
                                   f"Optional: raise the minimum to {need:g} MW (within your {self.cur_max:g} MW maximum) so the microgrid is built large "
                                   f"enough to carry the island case. {advice}", items, "forming_overload")
        elif need <= 2 * self.cur_max:
            wide = math.ceil(need)
            self.microgrid_row("microgrid_max_mw", "Maximum microgrid / generator size", self.cur_max, float(wide),
                               f"Optional: widen the maximum from {self.cur_max:g} to {wide:g} MW. Your range is {self.cur_min:g}-{self.cur_max:g} MW and the "
                               f"island case needs about {need:g} MW of grid-forming capacity. Widening only lets the optimiser build more; the minimum is "
                               f"unchanged. {advice}", items, "forming_overload")

    def convergence(self, items):
        v = items[0][2]
        text = (v["message"] + " Technically the case is beyond the network's transfer capability. Options: reduce the load or generator MW at the weakest "
                "point, upsize the feeder/transformer, add reactive support, or strengthen the grid connection (higher short-circuit level). "
                "The microgrid range is not lowered.")
        self.put(self.make("non_convergence", items, "network", dict(kind="advice", key="convergence", id="network"),
                           "Advisory: case does not converge", "", None, 0.0, text, recommended=False, applicable=False))
        for g in self.net.gens:
            if g["tech"] != "grid" or self.V is None:
                continue
            piece = dict(nodes={g["node"]: dict(sc_mva=round(g["sc_mva"] * 2, 3))})
            res = self.V.run(_merge(self.acc, piece))
            if not any(k[1] == "non_convergence" for k in res.keys):
                row = self.make("non_convergence", items, g["node"], dict(kind="node", key="sc_mva", id=g["node"]), "Grid short-circuit level", "MVA",
                                g["sc_mva"], g["sc_mva"] * 2, text.split(" Options")[0] + " A stronger connection point (x2 short-circuit level) restores convergence.",
                                recommended=False, verified=True, verification=self.verify_text(self.cur, res))
                self.put(row)

    def enforce_range_rules(self):
        """Last line of defence: never lower the maximum, never raise the minimum above the maximum."""
        for key in list(self.rows):
            row = self.rows[key]
            if key[:2] == ("field", "microgrid_max_mw") and (self.cur_max is None or row["suggested"] < self.cur_max):
                del self.rows[key]
        new_max = self.rows.get(("field", "microgrid_max_mw", None), {}).get("suggested", self.cur_max)
        for key in list(self.rows):
            row = self.rows[key]
            if key[:2] == ("field", "microgrid_min_mw") and new_max is not None and row["suggested"] > new_max:
                del self.rows[key]

    # ------------------------------------------------------------------ linear fallback (no verifier)
    def linear(self):
        net = self.net
        self.thermal()
        for comp in dict.fromkeys(it[2]["component"] for it in self.of_type("reactive_limit")):
            row = self.detail_row("gens", comp)
            if not row or not any(g["node"] == comp and g["tech"] != "grid" for g in net.gens):
                continue
            upper = row["q_mvar"] >= 0
            new_abs = math.ceil((abs(row["q_mvar"]) * 1.25 + 0.1) * 20) / 20.0
            key, cur = ("q_max_mvar", row["q_max"]) if upper else ("q_min_mvar", row["q_min"])
            if new_abs <= abs(cur or 0):
                continue
            mine = [it for it in self.cur.items if it[2]["type"] == "reactive_limit" and it[2]["component"] == comp]
            other = dict(q_min_mvar=row["q_min"]) if upper else dict(q_max_mvar=row["q_max"])
            self.put(self.make("reactive_limit", mine, comp, dict(kind="node", key=key, id=comp, also=other),
                               f"Reactive capability ({'Qmax' if upper else 'Qmin'}) at {self.nm(comp)}", "Mvar", cur, new_abs if upper else -new_abs,
                               f"{self.nm(comp)} reached its reactive limit; widen it (estimate, not re-screened). " + self.evidence(mine)))
        for side in VOLTAGE:
            mine = self.of_type(side)
            if not mine:
                continue
            worst = max(mine, key=lambda it: self._excess(it[2]))
            bus = worst[2]["component"]
            xth = pf._thevenin_x(net, bus)
            if not xth:
                continue
            sign = 1 if side == "voltage_low" else -1
            q = math.ceil((self._excess(worst[2]) + 0.005) * pf.BASE_MVA / xth * 20) / 20.0
            cur = net.bus(bus)["shunt_mvar"]
            self.put(self.make(side, mine, bus, dict(kind="node", key="shunt_mvar", id=bus),
                               f"Net shunt at {self.nm(bus)} (+ capacitor raises V / - reactor lowers V)", "Mvar", cur, cur + sign * q,
                               "Linear estimate from network sensitivity (not re-screened). " + self.evidence(mine), predicted=cur + sign * q))


def suggest(report, net, values=None, verifier=None):
    engine = Engine(report, net, values, verifier)
    if verifier is None:
        engine.linear()
    else:
        engine.thermal()
        engine.voltage()
        engine.reactive()
    engine.advisories()
    engine.enforce_range_rules()
    rows = list(engine.rows.values())
    for row in rows:
        row["cost_usd"], row["cost_basis"] = pf.row_cost(row)
    order = {"fail": 0, "warn": 1}
    rows.sort(key=lambda r: (order.get(r["severity"], 2), r["alternative"], r["id"]))
    return rows, engine.acc
