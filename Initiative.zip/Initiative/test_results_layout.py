import re
import unittest
from pathlib import Path

import workflow

UI = Path(__file__).resolve().parent / "generation_ui"


def res(code, npc, eligible, caps=None, status=None, message=None, **extra):
    caps = {**dict(pv_dc_mw=0.0, bess_mw=0.0, bess_mwh=0.0, generators_mw={}), **(caps or {})}
    r = dict(code=code, name=code, economics=dict(npc=npc), eligible_technologies=eligible, caps=caps,
             adequacy=dict(unserved_hours=0, unserved_mwh=0, stress_unserved_mwh=0))
    if status:
        r["technical_status"] = dict(status=status, violations=[], suggestions=[], **({"message": message} if message else {}))
    r.update(extra)
    return r


def ranked(results):
    return workflow.rank([workflow.entry_from(r, i) for i, r in enumerate(results)])


MIX = dict(pv_dc_mw=6.68, bess_mw=3.32, bess_mwh=14.89)


class UnbuiltTechnologyTests(unittest.TestCase):
    def results(self, h2_npc=149_980_000.0, p1_npc=149_980_000.0):
        return [res("R0", 200e6, ["grid"]),
                res("H2", h2_npc, ["grid", "pv", "bess", "h2"], dict(MIX, generators_mw={"h2": 0.0})),
                res("P1", p1_npc, ["grid", "pv", "bess"], dict(MIX, generators_mw={"none": 0.0}))]

    def test_tie_prefers_simpler_scenario_even_when_listed_first(self):
        entries, rec = ranked(self.results(h2_npc=149_979_000.0, p1_npc=149_980_000.0))
        self.assertEqual(rec["code"], "P1")
        by = {e["code"]: e for e in entries}
        self.assertEqual(by["H2"]["same_mix_as"], ["P1"])
        self.assertEqual(by["P1"]["tie_with"], ["H2"])
        self.assertEqual([e["code"] for e in sorted(entries, key=lambda e: e["rank"])][:2], ["P1", "H2"])

    def test_unbuilt_technology_is_flagged_when_it_is_recommended(self):
        results = [res("H2", 100e6, ["grid", "pv", "bess", "h2"], dict(MIX, generators_mw={"h2": 0.0})), res("R0", 200e6, ["grid"])]
        entries, rec = ranked(results)
        self.assertEqual(rec["code"], "H2")
        self.assertEqual(rec["unbuilt"], ["h2"])
        self.assertTrue(any("Hydrogen is eligible" in w and "uneconomic" in w for w in rec["warnings"]))

    def test_real_cost_difference_beyond_tolerance_still_wins(self):
        _, rec = ranked(self.results(h2_npc=140e6))
        self.assertEqual(rec["code"], "H2")

    def test_built_technology_is_not_flagged(self):
        r = res("NG", 100e6, ["grid", "pv", "ng"], dict(MIX, generators_mw={"ng": 0.76}))
        self.assertEqual(workflow.unbuilt_technologies(r), [])


class NotRunTests(unittest.TestCase):
    def test_not_run_is_flagged_with_reason(self):
        results = [res("A", 100e6, ["grid", "pv"], status="PASS", **{}),
                   res("B", 90e6, ["grid", "pv"], status="NOT_RUN", message="The single-line diagram needs nodes connected by wires")]
        entries, rec = ranked([dict(r, compliance_cost=dict(total_usd=0, items=[])) for r in results])
        self.assertEqual(rec["code"], "B")
        text = " ".join(rec["warnings"])
        self.assertIn("NOT been technically checked", text)
        self.assertIn("single-line diagram", text)
        self.assertEqual(entries[1]["check_message"], "The single-line diagram needs nodes connected by wires")

    def test_unchecked_clone_of_failing_option_is_not_recommended(self):
        h2 = res("H2", 149.98e6, ["grid", "pv", "bess", "h2"], dict(MIX, generators_mw={"h2": 0.0}), status="NOT_RUN")
        p1 = res("P1", 149.98e6, ["grid", "pv", "bess"], dict(MIX, generators_mw={"none": 0.0}), status="FAIL")
        entries, rec = ranked([dict(h2), dict(p1, compliance_cost=dict(total_usd=0, items=[]))])
        self.assertEqual(rec["code"], "P1")
        self.assertTrue(rec["leader_fails"] or rec["technical_status"] == "FAIL")

    def test_screen_reports_reason_instead_of_raising(self):
        from unittest import mock
        import power_flow
        with mock.patch.object(power_flow, "screen_scenario", side_effect=ValueError("no drawing")):
            out = workflow.screen(Path("Application Runs") / ("0" * 32), "H2")
        self.assertEqual(out["status"], "NOT_RUN")
        self.assertIn("no drawing", out["message"])

    def test_shunt_is_sized_and_costed_when_available(self):
        from unittest import mock
        import power_flow
        tech = dict(status="WARN", violations=[], suggestions=[])
        shunt = dict(size_mvar=2.5, cost_usd=62500.0)
        with mock.patch.object(power_flow, "screen_scenario", return_value=tech), \
                mock.patch.object(power_flow, "autoshunt", None, create=True), \
                mock.patch.object(power_flow, "size_shunt", create=True, return_value=shunt), \
                mock.patch.object(power_flow, "compliance_cost", return_value=dict(total_usd=0.0, items=[])):
            r = res("A", 100e6, ["grid", "pv"])
            workflow.check_results(Path("Application Runs") / ("0" * 32), [r])
        self.assertEqual(r["shunt"]["mvar"], 2.5)
        self.assertEqual(r["compliance_cost"]["total_usd"], 62500.0)
        entry = workflow.entry_from(r)
        self.assertEqual(entry["shunt"]["cost_usd"], 62500.0)


class LayoutTests(unittest.TestCase):
    html = (UI / "index.html").read_text(encoding="utf-8")
    css = (UI / "app.css").read_text(encoding="utf-8")

    def test_solve_results_order(self):
        h = self.html
        order = [h.index(f'id="{i}"') for i in ("result-table", "workflow-panel", "adequacy-warnings", "result-charts", "land-summary")]
        self.assertEqual(order, sorted(order))
        self.assertGreater(h.index('id="results"'), h.index('id="solve"'))

    def test_workflow_panel_inside_results_section(self):
        h = self.html
        start = h.index('<section id="results"')
        self.assertLess(start, h.index('id="workflow-panel"'))
        self.assertLess(h.index('id="workflow-panel"'), h.index("</section>", start))

    def test_sticky_label_column_rules(self):
        self.assertRegex(self.css, r"\.table-scroll table td:first-child[^{]*\{[^}]*position:sticky;left:0;z-index:1;background:#fff")
        for selector in (".pf-cases", ".dsg-table", ".sens-table", ".xl2"):
            self.assertIn(selector, self.css)

    def test_rendered_tables_get_the_class(self):
        app = (UI / "app.js").read_text(encoding="utf-8")
        self.assertGreaterEqual(len(re.findall(r'node\("table", undefined, "xl"\)', app)), 3)
        self.assertIn("xl", (UI / "workflow.js").read_text(encoding="utf-8"))

    def test_explainer_text_present(self):
        js = (UI / "workflow.js").read_text(encoding="utf-8")
        for phrase in ("What is this?", "NOT part of the optimization", "Unit costs used"):
            self.assertIn(phrase, js)


if __name__ == "__main__":
    unittest.main()
