import json
import shutil
import unittest
import uuid
from pathlib import Path

import design
import extensions
import power_flow as pf
from test_power_flow import BIG_GRID, diagram, feeder, same_kv

HERE = Path(__file__).parent
RUN = "25253846a35d4d2583767b43da6bd098"
HAS_RUN = (HERE / "Application Runs" / RUN / "status.json").is_file()


def build(nodes, lines, kv=11.0, grid_kv=None, peak=5.0, caps=None, **kwargs):
    over = same_kv([n for n, _ in nodes], kv)
    for n, kind in nodes:
        if kind == "grid":
            over[n].update(BIG_GRID)
            if grid_kv:
                over[n]["kv"] = grid_kv
    return pf.build_network(diagram(nodes, lines), caps=caps or {}, assumptions=dict(nodes=over, lines={}), peak_load_mw=peak, **kwargs)


class SolverConventionTests(unittest.TestCase):
    def test_power_balance_and_losses(self):
        net = feeder(km=2.0, gen=3.0)
        case = pf.solve_case(net, dict(load_mw=5.0, gens=dict(pv=dict(p=3.0)), grid_mw=2.0))
        self.assertTrue(case["converged"])
        self.assertGreaterEqual(case["losses_mw"], 0.0)
        self.assertAlmostEqual(case["slack_mw"], 5.0 - 3.0 + case["losses_mw"], places=3)

    def test_bess_charging_draws_from_grid(self):
        nodes = [("g", "grid"), ("l", "load"), ("b", "bess")]
        net = build(nodes, [("w1", "g", "l", 1.0), ("w2", "b", "l", 0.0)], caps={"bess": 4.0})
        idle = pf.solve_case(net, dict(load_mw=2.0, gens=dict(bess=dict(p=0.0)), grid_mw=2.0))
        charge = pf.solve_case(net, dict(load_mw=2.0, gens=dict(bess=dict(p=-3.0)), grid_mw=5.0))
        self.assertAlmostEqual(charge["slack_mw"] - idle["slack_mw"], 3.0, places=1)

    def test_zero_length_wire_is_a_tie(self):
        nodes = [("g", "grid"), ("l", "load")]
        net = build(nodes, [("w1", "g", "l", 0.0)])
        self.assertTrue(pf.solve_case(net, dict(load_mw=1.0, gens={}, grid_mw=1.0))["converged"])

    def test_mismatched_kv_without_transformer_rejected_or_bridged(self):
        nodes = [("g", "grid"), ("l", "load")]
        net = build(nodes, [("w1", "g", "l", 1.0)], grid_kv=69.0, kv=13.8)
        kinds = {b["kind"] for b in net.branches}
        self.assertIn("transformer", kinds)

    def test_two_grid_nodes_rejected(self):
        nodes = [("g", "grid"), ("g2", "grid"), ("l", "load")]
        import network_topology
        raw = diagram(nodes, [("w1", "g", "l", 1.0), ("w2", "g2", "l", 1.0)])
        raw["enabled"] = True
        with self.assertRaises(ValueError):
            network_topology.validate_diagram(raw, [])

    def test_island_without_source_rejected(self):
        nodes = [("w", "wind"), ("l", "load")]
        with self.assertRaises(ValueError):
            build(nodes, [("w1", "w", "l", 1.0)], islanded=True, caps={"wind": 3.0})

    def test_kv_levels_all_solve(self):
        for grid_kv, kv in ((230, 34.5), (115, 13.8), (69, 4.16), (34.5, 34.5), (13.8, 13.8)):
            with self.subTest(grid_kv=grid_kv, kv=kv):
                nodes = [("g", "grid"), ("l", "load")]
                net = build(nodes, [("w1", "g", "l", 1.0)], grid_kv=grid_kv, kv=kv, peak=2.0)
                self.assertTrue(pf.solve_case(net, dict(load_mw=2.0, gens={}, grid_mw=2.0))["converged"])


@unittest.skipUnless(HAS_RUN, "example run not available")
class DesignEditedTopologyTests(unittest.TestCase):
    """Works on a private copy of the example run; the original is never touched."""

    def setUp(self):
        self.rid = uuid.uuid4().hex
        self.folder = HERE / "Application Runs" / self.rid
        shutil.copytree(HERE / "Application Runs" / RUN, self.folder)
        design._CACHE.clear()
        pf._CACHE.clear()

    def tearDown(self):
        shutil.rmtree(self.folder, ignore_errors=True)
        design._CACHE.clear()
        pf._CACHE.clear()

    def set_kv(self, code, **kv):
        path = self.folder / "request.json"
        req = json.loads(path.read_text(encoding="utf-8"))
        for node in req["topology"]["diagrams"][code]["nodes"]:
            if node["kind"] in kv:
                node["electrical"] = dict(node.get("electrical") or {}, kv=kv[node["kind"]])
        path.write_text(json.dumps(req), encoding="utf-8")

    def test_single_voltage_level_has_no_main_transformer(self):
        self.set_kv("NG", grid=34.5, bus=34.5, load=34.5)
        d = design.build_design(self.rid, "NG")
        self.assertTrue(all(c["converged"] for c in d["checks"]["cases"]))
        self.assertTrue(design.raw_text(d))
        self.assertIn("<svg", design.sld_svg(d))

    def test_voltage_levels_every_scenario(self):
        for kv in ((230, 34.5), (115, 13.8), (69, 4.16), (13.8, 13.8)):
            for code in ("NG", "S2"):
                with self.subTest(kv=kv, scenario=code):
                    self.set_kv(code, grid=kv[0], bus=kv[1], load=kv[1])
                    design._CACHE.clear()
                    d = design.build_design(self.rid, code)
                    self.assertTrue(design.raw_text(d))
                    self.assertIn("<svg", design.sld_svg(d))


if __name__ == "__main__":
    unittest.main()
