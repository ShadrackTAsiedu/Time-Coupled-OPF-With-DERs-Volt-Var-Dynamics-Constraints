import re
import socket
import subprocess
import sys
import time
import unittest
from pathlib import Path
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

TOPOLOGY = dict(enabled=True, nodes=[
    dict(id="g", kind="grid", label="Grid", x=200, y=300),
    dict(id="b", kind="bus", label="Bus", x=500, y=300),
    dict(id="l", kind="load", label="Load", x=800, y=200),
    dict(id="pv", kind="pv", label="Solar", x=800, y=400),
], lines=[
    dict(id="w1", source="g", target="b", owner="shared", length_km=0, cost_per_km=0, points=[]),
    dict(id="w2", source="b", target="l", owner="shared", length_km=1, cost_per_km=0, points=[]),
    dict(id="w3", source="pv", target="b", owner="shared", length_km=0.5, cost_per_km=0, points=[]),
], diagrams={})


class PowerFlowBrowserTest(unittest.TestCase):
    def test_overlay_toggle_restores_diagram(self):
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)],
                                  cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try:
                    urlopen(base + "/api/defaults", timeout=.5).close()
                    break
                except OSError:
                    time.sleep(.1)
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
                page = browser.new_context(viewport={"width": 1600, "height": 1000}).new_page()
                errors = []
                page.on("pageerror", lambda exc: errors.append(str(exc)))
                page.goto(base + "/")
                page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
                group = page.locator("#input-navigation details").filter(
                    has=page.locator("summary").filter(has_text=re.compile("^Microgrid$")))
                if group.get_attribute("open") is None:
                    group.locator("summary").click()
                group.get_by_role("button", name="Topology / single-line diagram", exact=True).click()
                page.evaluate("(t) => topologyEditor.restore(t)", TOPOLOGY)
                page.wait_for_selector("#topology-svg [data-node]")
                self.assertGreaterEqual(page.locator("#topology-svg [data-node]").count(), 4)
                toggle = page.locator("#pf-toggle")
                self.assertEqual(toggle.inner_text(), "Show power flow")
                strip = ("() => { const c = document.getElementById('topology-svg').cloneNode(true);"
                         " c.querySelector('#powerflow-overlay')?.remove(); return c.innerHTML; }")
                before = page.evaluate(strip)
                self.assertEqual(page.locator("#powerflow-overlay").count(), 0)

                toggle.click()
                self.assertEqual(toggle.inner_text(), "Hide power flow")
                page.wait_for_selector("#pf-solve-manual", state="visible")
                page.locator("#pf-load-mw").fill("3")
                page.locator("#pf-solve-manual").click()
                page.wait_for_selector("#powerflow-overlay .pf-volt", timeout=15000)
                self.assertGreaterEqual(page.locator("#powerflow-overlay .pf-flow").count(), 1)
                self.assertGreaterEqual(page.locator("#powerflow-overlay .pf-volt").count(), 3)
                self.assertIn("MW", page.locator("#powerflow-overlay .pf-label").first.text_content())
                dash1 = page.locator("#powerflow-overlay .pf-flow").first.get_attribute("stroke-dashoffset")
                page.wait_for_timeout(300)
                dash2 = page.locator("#powerflow-overlay .pf-flow").first.get_attribute("stroke-dashoffset")
                self.assertNotEqual(dash1, dash2)
                self.assertEqual(page.evaluate(strip), before)

                # The overlay survives a diagram re-render and the manual result shows no violations text error.
                page.locator("#topology-fit").click()
                page.wait_for_selector("#powerflow-overlay")
                page.locator("#pf-assume").click()
                page.wait_for_selector("#pf-assumptions table")

                toggle.click()
                self.assertEqual(toggle.inner_text(), "Show power flow")
                self.assertEqual(page.locator("#powerflow-overlay").count(), 0)
                self.assertFalse(page.locator("#powerflow-panel").is_visible())
                self.assertEqual(page.evaluate("() => document.getElementById('topology-svg').innerHTML"), before)
                self.assertEqual(errors, [])
                browser.close()
        finally:
            server.terminate()
            server.wait(10)


class PowerFlowPageBrowserTest(unittest.TestCase):
    RUN = "25253846a35d4d2583767b43da6bd098"

    def test_page_tab_status_api_and_run(self):
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)],
                                  cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try:
                    urlopen(base + "/api/defaults", timeout=.5).close()
                    break
                except OSError:
                    time.sleep(.1)
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
                page = browser.new_context(viewport={"width": 1600, "height": 1000}).new_page()
                errors = []
                page.on("pageerror", lambda exc: errors.append(str(exc)))
                page.goto(base + "/")
                page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
                page.locator("#tab-powerflow").click()
                self.assertTrue(page.locator("#view-powerflow").is_visible())
                self.assertTrue(page.locator("#pfp-run").is_visible())
                self.assertTrue(page.locator("#pfp-animate").is_visible())
                self.assertTrue(page.locator("#pfp-raw").is_visible())
                self.assertEqual(page.evaluate("() => window.powerFlowStatus.get('X').status"), "NOT_RUN")
                page.locator("#tab-solve").click()
                self.assertFalse(page.locator("#view-powerflow").is_visible())
                if (ROOT / "Application Runs" / self.RUN / "result_S1.json").is_file():
                    page.evaluate("""(run) => { solveRun = run; solveSnapshot = {summary: {results: [{code: 'S1'}]}}; }""", self.RUN)
                    events = page.evaluate("() => { window.pfEvents = 0; document.addEventListener('powerflow-status', () => window.pfEvents++); return 0; }")
                    page.locator("#tab-powerflow").click()
                    page.wait_for_selector("#pfp-summary .pfp-title", timeout=60000)
                    self.assertGreaterEqual(page.locator("#pfp-case option").count(), 2)
                    self.assertGreaterEqual(page.locator("#pfp-tables table").count(), 3)
                    page.locator("#pfp-animate").click()
                    self.assertEqual(page.locator("#pfp-animate").get_attribute("aria-pressed"), "true")
                    page.locator("#pfp-animate").click()
                    self.assertEqual(page.locator("#pfp-animate").get_attribute("aria-pressed"), "false")
                    self.assertTrue(page.locator("#pfp-suggestions").is_visible())
                self.assertEqual(errors, [])
                browser.close()
        finally:
            server.terminate()
            server.wait(10)


if __name__ == "__main__":
    unittest.main()
