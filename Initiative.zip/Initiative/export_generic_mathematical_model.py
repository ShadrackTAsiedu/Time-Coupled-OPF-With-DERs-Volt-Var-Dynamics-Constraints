"""Publish a symbolic, project-independent formulation of GenStudio."""

from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import unittest
import zipfile

from docx import Document
from lxml import etree

from docx_math import Report, fraction, indexed, power, total


ROOT = Path(__file__).resolve().parent
FILENAME = "GenStudio_Generic_Mathematical_Model.docx"
GATE_TESTS = [
    "test_generic_mathematical_model",
    "test_math_validation",
    "test_model_revision.RevisionTests.test_charging_cost_paid_by_grid_or_generator_not_twice",
    "test_model_revision.RevisionTests.test_blended_total_rate_reactive_and_single_inflation",
    "test_model_revision.RevisionTests.test_joint_hydrogen_gas_optional_and_shared_heat",
    "test_resource_economics_revision",
    "test_topology_wind",
]
FORBIDDEN_TEXT = ("33.34", "0.0798", "2026", "2036", "f578bcc", "$70", "8-10")


def build_document():
    """Return the Report holding the generic formulation; has no filesystem side effects."""
    report = Report()
    doc = report.doc
    doc.sections[0].header.paragraphs[0].text = "GENSTUDIO | GENERAL MATHEMATICAL FORMULATION"
    doc.sections[0].footer.paragraphs[0].runs[0].text = "Project-independent formulation | Page "
    h, p, eq, tab = report.heading, report.paragraph, report.equation, report.table
    sub, sup, frac, sigma = indexed, power, fraction, total

    h("GenStudio", 0)
    h("General mathematical model", 0)
    p("Symbolic capacity planning, chronological dispatch, demand forecasting, "
      "lifecycle economics and emissions")
    p("No project input values, dates, scenario results, tariff quotations or equipment "
      "defaults are specified. Symbols are parameters supplied separately for each project. "
      "Zero, unity and polynomial coefficients in the equations are mathematical constants, "
      "not project assumptions.")
    p("Purpose: specify a reusable optimization problem and identify exactly which "
      "interpretations are supported by the current implementation. This document replaces "
      "a numerical case-study explanation; it does not change application inputs or algorithms.")
    h("Model status and mathematical scope")
    p("The implemented core is deterministic linear capacity expansion and dispatch. "
      "Optional technology-owned fixed connection costs introduce binary activation "
      "variables in the capacity master; hourly recourse remains an LP. "
      "Capacity is selected once for the horizon. Dispatch is chronological "
      "inside cyclic monthly storage periods. Dispatch blocks are monthly normally, "
      "or annual when an annual emissions limit couples the months. The electrical time step in the application "
      "is hourly. Delta_t is retained symbolically to make power-to-energy conversions explicit; "
      "arbitrary time steps are not an existing application feature.")
    p("Non-simultaneous battery operation, exact subhourly reliability, stochastic grid "
      "outages and a globally continuous multi-month storage trajectory are NOT guaranteed "
      "by this LP. Their mathematical extensions are clearly separated in Section 12. "
      "The implemented peak-envelope and shortage-energy rules are screening approximations, "
      "not identities about an unobserved subhourly load curve.", True)

    h("1. Sets, indices, conventions and parameter domains")
    tab(["Symbol", "Definition"], [
        ["s in S", "Independent scenario. Scenario index is suppressed below."],
        ["y in Y; t in T_y", "Operating year and chronological dispatch time step in that year."],
        ["b in B; t in T_b", "Calendar-month storage boundary and billing period."],
        ["omega in Omega", "Dispatch decomposition group: a month, or a full year with an annual emissions limit."],
        ["d in D; t in T_d", "Calendar day and its dispatch steps."],
        ["k in K_s", "Eligible generation units including hourly-resource-limited wind; retain individual names."],
        ["j in J; v in V_j", "Committed project and its commissioning vintage."],
        ["Delta_t; tau", "Dispatch duration and assumed peak-event duration, in hours."],
        ["r; i; a_y; D_y", "Nominal discount rate, common inflation rate, escalation and discount factors."],
        ["MW; MWh; MWth", "Electrical power; electrical energy; useful thermal power."],
        ["CU", "Any consistently selected project currency. Cost base is time zero."],
    ])
    eq(sub("a", "y"), " = ", sup("(1+i)", "y"), ";    ",
       sub("D", "y"), " = ", sup("(1+r)", "y"), ";    ",
       sub("w", "y"), " = ", frac(sub("a", "y"), sub("D", "y")))
    p("Assume r > -1, i > -1, Delta_t > 0, tau >= 0. Installed capacities, "
      "load, tariff coefficients and physical resource availability are nonnegative. "
      "Battery efficiencies lie in (0,1], and 0 <= sigma_min <= sigma_0 <= sigma_max <= 1. "
      "Derate factors are retained-output fractions in [0,1]; degradation fractions "
      "are in [0,1). The current cost model uses a common escalator, with end-of-year "
      "operating cashflows. Do not inflate a tariff twice or mix a real discount rate "
      "with nominal cashflows.")
    p("The explicitly forecast horizon and lifecycle appraisal horizon may differ. "
      "After the last forecast year, the application repeats its final gross-demand, "
      "resource and thermal calendar pattern, then redispatches every appraisal year "
      "with commissioned assets, degradation and scheduled replacement. The tail is "
      "an explicit modeling assumption, not an inferred client forecast. All cash "
      "and adequacy comparisons below use the common appraisal horizon.")

    h("2. Demand input, annual trajectories and temporal downscaling")
    p("A complete uploaded forecast supplies gross hourly mean, minimum and maximum "
      "demand directly. Forecast generation below is used only if such a forecast is "
      "not supplied. Never apply forecast growth again to an already forecast upload.")
    eq("0 <= ", sub("L", "yt"), "^- <= ", sub("L", "yt"), " <= ", sub("L", "yt"), "^+")
    h("2.1 Annual targets", 2)
    eq(sub("P", "y"), " = ", sub("P", "y-1"), "(1+", sub("g", "y"), ")")
    p("P_y is the annual maximum-demand target and g_y is a dimensionless year-on-year "
      "growth fraction. A specified peak P_y overrides a growth-derived value at that "
      "anchor; each input row must specify either peak or growth, not both. "
      "Milestone descriptions require a user-confirmed numeric interpretation; "
      "text alone does not uniquely determine an electrical forecast.")
    eq("u = min(1, max(0, e/H));    P(e) = B + (T-B) f(u)")
    tab(["Selectable trajectory", "Symbolic f(u) / P(e)"], [
        ["Linear", "f(u) = u"],
        ["Decelerating quadratic", "f(u) = 2u - u^2"],
        ["Accelerating quadratic", "f(u) = u^2"],
        ["Smoothstep", "f(u) = 3u^2 - 2u^3"],
        ["Compound", "P(e) = B (T/B)^u; B > 0 and T > 0"],
    ])
    p("B and T are the baseline and target peaks, H > 0 is elapsed time to target, "
      "and e is elapsed time. With clipping, the target remains flat after H. "
      "For sparse annual milestones the app selects linear interpolation or "
      "shape-preserving piecewise cubic interpolation (PCHIP), not the five within-year "
      "growth curves. Outside the last milestone it holds the last target. "
      "Annual growth is g_y = P_y/P_(y-1) - 1 when P_(y-1) > 0.")
    eq("P(y) = (1-u)P_a + u P_b;    u = (y-a)/(b-a)")
    eq("P_PCHIP(y) = (2u^3-3u^2+1)P_a + (u^3-2u^2+u)(b-a)m_a "
       "+ (-2u^3+3u^2)P_b + (u^3-u^2)(b-a)m_b")
    p("a and b are consecutive anchor years. PCHIP uses shape-preserving endpoint "
      "slopes m. At an interior anchor, let h_- and h_+ be adjacent year spacings "
      "and delta_- and delta_+ the adjacent secant slopes. If the secants have "
      "opposite signs or either is zero, m=0. Otherwise use the weighted harmonic "
      "mean below. Boundary slopes use the one-sided quadratic estimate, clipped "
      "to preserve the adjoining secant sign and limited to three times that "
      "secant when the next secant changes sign. This is the standard PCHIP "
      "interpolator used by the application.")
    eq("w_- = 2h_+ + h_-;    w_+ = h_+ + 2h_-;    "
       "m = (w_- + w_+) / (w_-/delta_- + w_+/delta_+)")
    h("2.2 Learn the shape and scale every hourly value", 2)
    eq(sub("q", "yt"), "^a = mean{", sub("L", "n"), "^a : n in historical group c(y,t)},"
       "    a in {-, mean, +}")
    p("The learned grouping is calendar month, weekday and hour; replay grouping uses "
      "month, day and hour. Use the same grouping for mean and extrema. Calendar mapping, "
      "leap days, time-zone conventions, gaps and repeated timestamps must be handled before "
      "optimization. Learning a shape is not a claim that one historical year identifies "
      "long-term growth.")
    eq(sub("A", "yt"), " = ", sub("P", "y-1"), " + (", sub("P", "y"), "-", sub("P", "y-1"),
       ") f(", sub("u", "yt"), ");    ",
       sub("Z", "y"), " = max{", sub("q", "yt"), "^+ ", sub("A", "yt"), " : t in T_y}")
    eq(sub("alpha", "yt"), " = ", frac([sub("P", "y"), sub("A", "yt")], sub("Z", "y")),
       ";    ", sub("L", "yt"), "^a = ", sub("alpha", "yt"), sub("q", "yt"), "^a")
    p("This A/envelope rule is the milestone-guided mode. In baseline/target model "
      "mode, instead use alpha_yt = P_y / max_t q_yt^+, constant within the year, "
      "with P_y from the selected horizon growth curve. Require the normalizer "
      "to be positive. Both normalizations give max_t L^+_yt = P_y, while preserving "
      "L^- <= L <= L^+ because all three values share a nonnegative multiplier. This is "
      "peak-constrained downscaling, not an annual-energy forecast: an independently "
      "specified annual energy is not guaranteed simultaneously. Additional energy "
      "constraints would require a different shape-fitting problem.")

    h("3. Committed assets and the load decision boundary")
    eq(sub("K", "jy"), " = ", sub("d", "j"),
       sigma("v in V_j, v <= y", [sub("Delta K", "jv"), sup("(1-gamma_j)", "y-v")]))
    p("Delta K_jv is the committed nameplate tranche in vintage v, d_j is the retained-output "
      "derate, and gamma_j is annual degradation. Equal annual tranches are a scheduling "
      "convention, not a mathematical requirement. The application uses January commissioning "
      "and equal tranches across an entered year range. Committed BESS power and energy "
      "are formed separately by the same vintage sum. Do not apply derating twice to a "
      "resource profile already expressed as final usable output.")
    eq(sub("epsilon", "y"), " = min(1, ", frac(sub("K", "EE,y"), sub("P", "y")), ");    ",
       sub("L", "yt"), "^a,svc = (1-", sub("epsilon", "y"), ")", sub("L", "yt"), "^a")
    p("K_EE,y includes only efficiency tranches commissioned after the historical metering "
      "boundary; earlier savings are already embedded in the measurements. This formula "
      "models efficiency as a proportional peak reduction, not constant night-time generation. "
      "It requires a positive annual peak.")
    eq(sub("R", "yt"), " = ",
       sigma("j in committed renewables", [sub("K", "jy"), sub("phi", "jyt")]))
    eq(sub("F", "yt"), " = min(", sub("R", "yt"), ",", sub("L", "yt"), "^svc);    ",
       sub("S", "yt"), " = max(", sub("R", "yt"), "-", sub("L", "yt"), "^svc,0)")
    eq(sub("ell", "yt"), "^a = max(", sub("L", "yt"), "^a,svc - ", sub("R", "yt"), ",0)")
    p("F is committed renewable supply used directly, S is remaining committed renewable "
      "availability, and ell is residual load. Thus L^svc = F + ell for hourly means. "
      "In the present application, committed solar uses an hourly resource; committed wind "
      "uses an entered constant capacity factor. Neither committed resource nor efficiency "
      "is an additional investment decision. The project must explicitly declare whether "
      "committed costs are outside the decision boundary; the current app excludes them. "
      "Their usable output is nevertheless included in served electrical demand.")

    h("4. Investment and dispatch variables")
    tab(["Variable", "Units and definition"], [
        ["X_PV; P_B; E_B; X_k", "MW new solar, MW new BESS power, MWh new BESS energy, MW of each new generator."],
        ["g_yt; v_yt; p_kyt", "MW grid import, used new-renewable/committed-surplus supply, generator output."],
        ["c_yt; d_yt; e_yt", "MW battery charge, MW battery discharge, MWh stored energy at the end of step."],
        ["h_kyt", "MWth useful recovered heat from generator k."],
        ["u_yt; z_yt", "MW unmet hourly-mean residual demand; MW peak-only screening slack."],
        ["G_b; G_b^on", "MW monthly all-hours and optional tariff-window billing peaks."],
        ["b_yt", "MW islanded battery upward reserve; only used in islanded scenarios."],
    ])
    p("All variables are nonnegative. Omitted technologies have capacity fixed to zero; "
      "eligible technologies need not be installed. An aggregate minimum may force "
      "investment even when an unconstrained least-cost solution would install nothing.")

    h("5. Objective derivation: cash cost versus numerical preference")
    h("5.1 Initial investment", 2)
    eq(sub("C", "equip"), " = ", sub("c", "PV"), " X_PV + ",
       sub("c", "BP"), " P_B + ", sub("c", "BE"), " E_B + ",
       sigma("k in K_s", [sub("c", "k"), " X_k"]))
    p("Power CAPEX coefficients have units CU/MW; the energy CAPEX coefficient has "
      "units CU/MWh. The BESS energy component purchases energy-storage capacity, "
      "not charging electricity.")
    eq(sub("C", "inventory"), " = ", frac("sigma_0 E_B", "eta_c"), " pi_0;    ",
       sub("C", "0"), " = ", sub("C", "equip"), " + ", sub("C", "inventory"), " + C_up + C_connect")
    eq("F_j = ", sigma("e owned by j", "length_e rate_e"), " + ",
       sigma("n owned by j", "substation_CAPEX_n"))
    eq("C_connect = F_shared + a_grid F_grid + ", sigma("j in additional technologies", "F_j b_j"))
    eq("0 <= x_j <= M_max b_j;    b_j in {0,1}")
    p("Topology endpoints, route lengths and cost allocations are fixed user inputs, "
      "not optimized routes or geographical distances. Shared and eligible-grid costs "
      "are fixed scenario constants. Other technology-owned connections activate with "
      "positive installed power x_j; storage uses its power rating, not MWh. Each line "
      "and substation has exactly one cost owner. Common paths require Shared ownership. "
      "No line replacement, maintenance, power-flow, losses, voltage or thermal-rating "
      "constraints are inferred. These one-time costs are excluded from equipment FOM "
      "and replacement bases to avoid invented recurring expenditure.")
    p("pi_0 is a declared initial-inventory valuation in CU/MWh. The current app values "
      "new battery opening inventory using the first grid energy price, even for an island. "
      "This is a bookkeeping convention, not a physically modeled pre-horizon charging "
      "event. No additional initial inventory payment is assigned to committed batteries. "
      "An alternative project boundary must define its own inventory treatment.")
    h("5.2 Base-price annual operating cost", 2)
    eq(sub("C", "grid,y"), " = ",
       sigma("t in T_y", ["pi_yt g_yt Delta_t"]), " + ",
       sigma("b in B_y", ["kappa_b G_b + kappa_b^on G_b^on + F_b"]))
    p("pi_yt is an all-inclusive energy price in CU/MWh, selected from blended or "
      "seasonal time-of-use data. CU/kWh input must be converted consistently. F_b is "
      "a fixed bill and kappa is CU/MW-month. The current UI sets fixed and additional "
      "TOU-demand adders to zero; they are retained symbolically here as inactive terms.")
    eq("kappa_b^react = chi_P Qrate_b chi_Q")
    p("chi_P converts MW to kW; Qrate_b is CU/kVar-month; chi_Q is the assumed "
      "kVar/kW ratio. This estimates reactive billing from active peak under a constant "
      "ratio. Reactive charges are not energy prices and cannot be added as CU/kWh. "
      "If the energy price already includes this charge, do not add it separately.")
    eq(sub("C", "FOM,y"), " = f_PV X_PV + f_B (c_BP P_B + c_BE E_B) + ",
       sigma("k in K_s", ["f_k X_k"]), " + f_up C_up")
    eq("f_PV = mu_PV c_PV;    f_k = mu_k c_k")
    eq(sub("C", "dispatch,y"), " = ",
       sigma("t in T_y", [sigma("k in K_s", ["(f_k^fuel + v_k + c_k^CO2) p_kyt Delta_t"])]))
    eq(sub("C", "heat,y"), " = ",
       sigma("t in T_y", [sigma("k in CHP", ["beta h_kyt Delta_t"])]))
    eq(sub("C", "op,y"), " = C_grid,y + C_FOM,y + C_dispatch,y - C_heat,y")
    p("f_B and f_up are annual fractions of equipment and upgrade CAPEX. Other FOM "
      "coefficients are CU/MW-year. v_k, f_k^fuel and c_k^CO2 are CU/MWh electrical "
      "output. beta is CU/MWhth displaced useful boiler heat. The grid-upgrade reference "
      "has C_up and its maintenance; alternatives have no upgrade investment unless "
      "explicitly configured otherwise.")
    h("5.3 Fuel, carbon and useful-heat coefficients", 2)
    eq("f_k^fuel = ", frac("p_fuel,k chi_fuel,k", "eta_k^el"), ";    ",
       "c_k^CO2 = ", frac("p_CO2 EF_fuel,k chi_fuel,k", "eta_k^el"))
    eq("beta = ", frac("chi_boiler", "eta_boiler"),
       " (p_boiler,fuel + p_CO2 EF_boiler)")
    p("chi_fuel converts one MWh of fuel energy to the units used for fuel price and "
      "emission factor; efficiencies must use that same HHV or LHV basis. For purchased "
      "hydrogen priced by mass, chi_fuel is the reciprocal of its heating value in "
      "MWh/kg. Upstream hydrogen and grid emissions are reporting terms, not additional "
      "carbon costs in the current objective. Carbon prices apply only to the explicitly "
      "included combustion boundary. Heat credit requires useful demand and displaced fuel; "
      "it is not unrestricted revenue. Wind has zero fuel, combustion cost and recoverable heat; "
      "its variable maintenance applies to actual used output.")
    h("5.4 Lifecycle objective and shortage treatment", 2)
    eq("C_repl,y^nom = a_y ", sigma("j in additional assets", ["I_jy mu_repl c_j x_j"]))
    eq("NPC = C_0 + ", sigma("y in Y", ["w_y C_op,y + C_repl,y^nom / D_y"]))
    p("mu_PV and mu_k are annual fixed-maintenance fractions of installed equipment CAPEX. "
      "For replacement, x_j includes solar MW, BESS power MW, BESS MWh and generator MW "
      "with their appropriate cost units; include the fixed reference upgrade analogously. "
      "I_jy is a fixed indicator at integer multiples of entered service life strictly "
      "before the end of appraisal. mu_repl is the entered like-for-like replacement "
      "cost fraction. Replacement is not an optimized technology expansion decision. "
      "Disable replacement by setting every I_jy to zero.")
    eq("U_proxy = ", sigma("y,t", ["u_yt Delta_t + tau z_yt"]), ";    ",
       "J = NPC + lambda_U U_proxy + ",
       sigma("y,t", ["w_y epsilon_B d_yt Delta_t"]))
    p("Minimize J subject to Sections 6-9. lambda_U is a finite, undiscounted numerical "
      "shortage priority in CU/MWh-equivalent; it is not a stated customer value of lost "
      "load. epsilon_B is a small discharge tie-break (0.01 CU/MWh), not a cash expense. "
      "When a positive BESS cycling cost theta_B (CU per MWh discharged; non-reference "
      "cases only) is entered it replaces epsilon_B, is a real cash cost, and is included in "
      "C_dispatch,y as theta_B sum_t d_yt Delta_t. "
      "Reported NPC excludes the shortage priority and the tie-break but includes theta_B. "
      "The current primary objective includes "
      "configured replacements but has no terminal salvage, financing, income tax or incentives.")
    p("A finite penalty is not a proof of lexicographic reliability: sufficiently "
      "large cost savings can outweigh shortage. Strict service requires u=z=0; strict "
      "reliability-first planning requires a staged objective (Section 12). "
      "tau z is only an assumed energy equivalent. It must not be described as measured "
      "unserved energy without a resolved subhourly chronology.")
    h("5.5 Charging is paid for at its source", 2)
    eq("g_yt + v_yt + ", sigma("k", "p_kyt"),
       " + d_yt + u_yt = ell_yt + c_yt")
    p("The balance makes charging additional electrical demand. Grid energy, generator "
      "fuel, variable cost and losses are therefore paid through their source terms. "
      "Adding those same source expenditures again to BESS OPEX double-counts cost. "
      "Charging from otherwise curtailed renewables may have zero marginal energy cost. "
      "In a mixed bus, an aggregate LP does not uniquely identify which source charged "
      "the battery; source attribution requires an additional accounting convention.")

    h("6. Investment feasibility and technology eligibility")
    eq("0 <= X_PV <= a_PV Xbar_PV;    0 <= P_B <= a_B Pbar_B;    "
       "0 <= E_B <= a_B Ebar_B;    0 <= X_k <= a_k Xbar_k")
    eq("H_min P_B <= E_B <= H_max P_B")
    eq("M_min <= X_PV/alpha_DC + P_B + ", sigma("k", "X_k"), " <= M_max")
    eq("ell_PV X_PV <= A_PV;    ell_BP P_B + ell_BE E_B <= A_B")
    p("a values are fixed scenario eligibility flags, not binary investment decisions. "
      "H_min and H_max are duration bounds in hours. M_min and M_max bound the sum "
      "of additional installed power ratings; they exclude grid, committed projects and "
      "BESS MWh. This sum is not firm capacity or an energy guarantee. Solar's rating "
      "basis must match the unit-output resource, derate and CAPEX. The DC/AC ratio "
      "alpha_DC (>= 1; the application default is 1) converts solar DC rating to AC: the "
      "aggregate bound uses X_PV/alpha_DC and the PV capacity column remains DC MW. "
      "Land inequalities apply only when enabled, "
      "with documented footprint coefficients and consistent area units. Upper bounds "
      "must not accidentally prevent a permitted technology mix.")

    h("7. Dispatch, renewables, storage and useful heat")
    eq("0 <= v_yt <= phi_PV,yt d_PV (1-gamma_PV)^age_PV,y X_PV + S_yt")
    eq("0 <= p_wind,yt <= phi_wind,yt d_wind (1-gamma_wind)^age_wind,y X_wind")
    p("The uploaded unit wind electrical-output profile phi_wind is in [0,1], "
      "not raw wind speed. Derate and degradation apply once; scheduled replacement "
      "resets age and enters lifecycle cost. Wind land use satisfies ell_wind X_wind "
      "<= A_wind when enabled. Calendar replay and tail-year extension follow the "
      "same disclosed temporal convention as other resources; unused wind is curtailed.")
    p("phi_PV,yt is the pre-derate unit output resource. Supply not used in v is "
      "curtailed unless export is enabled (default: disabled). With export, an extra "
      "nonnegative variable x_yt <= X_exp, x_yt <= v_yt + sum_k p_kyt (only PV and "
      "generator output can be exported; BESS discharge and grid imports cannot) enters "
      "the balance as a load-like term and earns the price pi_exp in CU/MWh, credited "
      "against grid cost: C_grid,y -= sum_t pi_exp x_yt Delta_t. A pre-processed degraded "
      "solar profile must not be degraded a second time. age_PV,y is elapsed age since "
      "the latest scheduled replacement, or y-1 if replacements are disabled. "
      "The implementation separately tracks new solar and used committed solar/wind "
      "surplus so differing operational emissions factors are counted correctly.")
    eq("Pbar_yt = P_B + P_plan,yt;    Ebar_yt = E_B + E_plan,yt")
    eq("0 <= c_yt <= Pbar_yt;    0 <= d_yt <= Pbar_yt;    "
       "sigma_min Ebar_yt <= e_yt <= sigma_max Ebar_yt")
    eq("e_yt = e_prev + eta_c c_yt Delta_t - ",
       frac("d_yt Delta_t", "eta_d"), ";    eta_RT = eta_c eta_d")
    eq("e_open,b = sigma_0 Ebar_b;    e_end,b = sigma_0 Ebar_b")
    eq(sigma("t in T_d", ["d_yt Delta_t"]),
       " <= N_cyc (sigma_max - sigma_min) eta_d Ebar_d")
    p("Ebar_b is constant inside each monthly block in the implemented commissioning "
      "schedule. The application uses equal one-way efficiencies, each the square root "
      "of round-trip efficiency. Both newly optimized and committed BESS dispatch "
      "physically through the same aggregate storage model. Scheduled new-BESS "
      "replacement is costed and ongoing augmentation is in fixed maintenance. "
      "Optional annual capacity fade phi_B per year scales the usable window: with "
      "health_y = max(1 - phi_B age_B,y, 0.5) the SOC bounds become sigma_min health_y Ebar "
      "<= e <= sigma_max health_y Ebar and the daily throughput limit scales by health_y "
      "(age resets at scheduled replacement); power rating is not derated and the opening/"
      "closing state remains sigma_0 Ebar. Committed degradation changes available capacity "
      "by commissioning vintage. Independent monthly opening/closing states disallow "
      "seasonal energy transfer and can reset capacity-adjustment inventory.")
    p("The LP does not impose c_yt d_yt = 0. A cycling preference and a post-solve "
      "non-simultaneity check are used. This is not an exact formulation of exclusive "
      "charge/discharge and can fail for some tariffs or constraints. A rejected "
      "simultaneous-cycle solution must not be reported as a physically valid optimum.")
    eq("0 <= p_kyt <= X_k;    0 <= h_kyt <= rho_k p_kyt;    ",
       sigma("k in CHP", "h_kyt"), " <= H_yt")
    eq("rho_k = ", frac("eta_k^th", "eta_k^el"))
    p("H_yt is verified useful thermal demand shared across all CHP units. By default "
      "no generator unit commitment, minimum stable load, startup, ramping or fuel supply "
      "network is represented; the opt-in technology constraints below add them. "
      "Purchased hydrogen is not on-site hydrogen production.")
    h("7.1 Opt-in technology operating constraints", 2)
    p("When enabled for a unit k (not wind), a continuous committed-capacity relaxation "
      "is added. u_kyt is committed capacity in MW (not a binary), s_kyt is capacity "
      "started in MW; lambda_k is the minimum stable load fraction, R_k the ramp "
      "limit as a fraction of installed capacity per hour, and c_k^start the startup "
      "cost in CU per MW started. Start variables link consecutive steps only inside a "
      "dispatch block, not at the block opening.")
    eq("0 <= u_kyt <= X_k;    lambda_k u_kyt <= p_kyt <= u_kyt;    s_kyt >= u_kyt - u_k,y,t-1")
    eq("p_kyt - p_k,y,t-1 <= R_k X_k + s_kyt")
    eq("p_k,y,t-1 - p_kyt <= R_k X_k + u_k,y,t-1 - u_kyt + s_kyt")
    eq("C_start,y = ", sigma("t in T_y", [sigma("k", ["c_k^start s_kyt"])]), "    (added to C_dispatch,y)")
    p("Because u is continuous, the LP is a lower bound on the corresponding "
      "mixed-integer commitment problem (a relaxation); the +s term in the ramp rows "
      "allows a started capacity to ramp freely. Cost duals still support Benders cuts.")

    h("8. Grid-connected peak-envelope constraints")
    eq("m_yt^+ = ell_yt^+ - ell_yt;    m_yt^- = ell_yt - ell_yt^-")
    eq("r_yt^+ = ", frac("m_yt^+", "ell_yt"), ";    r_yt^- = ",
       frac("m_yt^-", "ell_yt"), "    when ell_yt > 0; otherwise both ratios are zero")
    eq("0 <= u_yt <= ell_yt;    0 <= z_yt <= m_yt^+ I(ell_yt = 0)")
    eq("g_yt - r_yt^+ u_yt - z_yt <= Gbar_s - m_yt^+")
    eq("g_yt + r_yt^- u_yt >= m_yt^-")
    eq("G_b >= g_yt + m_yt^+ - r_yt^+ u_yt - z_yt    for t in T_b")
    eq("G_b^on >= g_yt + m_yt^+ - r_yt^+ u_yt - z_yt    for t in T_b^on")
    p("I is a fixed data indicator, so the equations remain linear. z is enabled only "
      "when shortage reporting is allowed and mean residual demand is zero. The "
      "proportional terms assume mean-load shedding reduces the within-hour envelope "
      "proportionally. The upper inequality limits estimated peak import; the lower "
      "inequality represents no export at the estimated within-hour minimum.")
    p("These are envelope heuristics. They hold controllable dispatch constant within "
      "the hour and do not resolve subhourly renewable variability or battery changes. "
      "Separate hourly mean plus tau times peak-only shortage is not generally the "
      "integral of max(load minus supply, zero). Use true subhourly dispatch for "
      "settlement-grade demand billing or exact unserved-energy claims.")
    h("8.1 Upgraded-grid reference", 2)
    eq("X_PV = P_B = E_B = X_k = 0;    u_yt = z_yt = 0")
    eq("Gbar_ref = max(Gbar_ref,input, max{ell_yt^+ : y,t})")
    p("The reference still receives the same committed project reductions and committed "
      "storage availability. Its upgraded limit covers the residual peak, and its "
      "upgrade investment and maintenance enter cash cost. Alternative connected cases "
      "retain their chosen existing-grid limit. Different service levels must be "
      "disclosed rather than treated as interchangeable economic alternatives.")
    eq("C_up = C_quote m_up;    m_up = ",
       frac("G^needed - Gbar_exist", "Gbar_quote - Gbar_exist"), "  if G^needed > Gbar_quote, else 1")
    p("In the upgraded-grid reference case only, the upgrade is conditional: C_up = 0 "
      "unless the peak grid requirement G^needed exceeds the existing limit Gbar_exist. "
      "The quoted cost C_quote buys capacity up to the quoted limit Gbar_quote; a larger "
      "requirement is priced pro rata (multiplier m_up above), and the upgraded limit "
      "is max(G^needed, Gbar_quote). Alternatives never pay an upgrade.")

    h("9. Islanded peak-reserve screening")
    eq("g_yt = 0;    b_yt + d_yt <= Pbar_yt;    ",
       frac("tau b_yt", "eta_d"), " <= e_yt - sigma_min Ebar_yt")
    eq(sigma("k in fuel generators", ["X_k - p_kyt"]), " + b_yt >= m_yt^+ - r_yt^+ u_yt - z_yt")
    p("Use the same mean balance and physical storage constraints. Connected-grid "
      "envelope margins are disabled for g=0; the original upper residual-load margin "
      "is used in this reserve inequality. Spare generator rating and battery power/"
      "energy cover a prescribed deterministic peak-event proxy. The current battery "
      "reserve uses end-of-step SOC, not a resolved worst intra-step SOC; instantaneous "
      "generator headroom has no ramp constraint. This is not a probabilistic outage, "
      "loss-of-load or stability guarantee. Wind receives no assumed firm reserve credit.")

    h("10. Finance and emissions reporting")
    eq("O_y^nom = a_y C_op,y + C_repl,y^nom;    NPC = C_0 + ",
       sigma("y", frac("O_y^nom", "D_y")))
    eq("CF_0 = C_0,ref - C_0,s;    CF_y = O_y,ref^nom - O_y,s^nom")
    eq("NPV_s = ", sigma("y including 0", frac("CF_y", "(1+r)^y")),
       " = NPC_ref - NPC_s")
    eq("0 = ", sigma("y including 0", frac("CF_y", "(1+IRR)^y")))
    p("Report incremental NPV, IRR and payback only for a compatible reference and "
      "equal modeled service. IRR may be undefined or nonunique; do not force a value. "
      "The app reports the lowest IRR (with a note listing all roots) when the cashflows "
      "have several sign changes, and withholds IRR with an explanation when there is "
      "no investment, no sign change or no root in the searched range.")
    eq("B_n(r) = CF_0 + ", sigma("y <= n", frac("CF_y", "(1+r)^y")))
    eq("PB(r) = n-1 + ", frac("-B_(n-1)(r)", "CF_n/(1+r)^n"))
    p("For the first n with B_(n-1) < 0 <= B_n and a positive discounted CF_n, "
      "the formula interpolates within a year. Use r=0 for simple payback. Initial "
      "nonnegative cumulative benefit gives immediate payback; no crossing means no "
      "payback within the horizon. Interpolation is a reporting convention, not a "
      "claim about the actual timing of within-year cash receipts.")
    eq("E_y^svc = ", sigma("t in T_y", ["L_yt^svc Delta_t"]),
       ";    E_y^served,proxy = E_y^svc - ",
       sigma("t in T_y", ["u_yt Delta_t + tau z_yt"]))
    eq("LCOE_system = ", frac("NPC", sigma("y", frac("E_y^served,proxy", "D_y"))))
    p("The denominator is customer demand served after efficiency, not the sum of "
      "grid, renewables and BESS discharge (which would double-count storage). Require "
      "a positive denominator and flag any nonphysical shortage proxy. This is a "
      "whole-system levelized supply cost within the stated cost boundary, not a "
      "stand-alone generation-plant LCOE. Excluding committed asset costs while "
      "including their supply must be prominent. Shortage cases cannot be ranked "
      "as if they deliver equivalent service.")
    eq("EM_y^supply = ", sigma("t in T_y", [
        "(EF_grid,yt g_yt + ", sigma("k", "EF_k^el p_kyt"),
        " + EF_PV p_PV,yt^used + EF_W p_W,yt^used + EF_B d_yt) Delta_t"]))
    eq("EM_y^avoided = ", sigma("t in T_y", [
        sigma("k in CHP", "EF_boiler^useful h_kyt Delta_t")]),
        ";    EM_y^net = EM_y^supply - EM_y^avoided")
    eq("EM_y^net <= EMbar_y    for every y in the appraisal, only when enforcement is enabled")
    p("EM_y^supply also includes entered operational solar/wind factors on used output, "
      "including committed direct supply, and any independently justified battery "
      "discharge operational factor. Do not double-count battery charging-source "
      "emissions. These factors are not embodied-emissions inventories. The cap is a "
      "hard annual constraint, distinct from a carbon price, and is independently "
      "reconciled to the annual report. It can cause unmet demand or make a strict "
      "reference infeasible; a cap alone does not establish adequate service. When "
      "disabled, no emissions-budget row is added.")
    p("p_PV^used and p_W^used include both committed direct supply and dispatched "
      "surplus, with new PV output added to p_PV^used. This avoids assigning all "
      "mixed renewable surplus to solar. The resource upload supplies unit output "
      "directly or POA irradiation divided by reference STC irradiance, without "
      "an extra DC/AC clipping factor; derate and aging apply separately.")
    p("Every EF must be in consistent tonnes CO2e per MWh of delivered electricity "
      "or useful heat. Fuel-based factors must be divided by the matching conversion "
      "efficiency. For hydrogen, multiply mass consumption per MWh by upstream "
      "emissions per mass, converting kilograms to tonnes explicitly. No temporal "
      "discounting is applied to physical tonnes. Stack-zero hydrogen does not imply "
      "zero upstream emissions. Avoided boiler emissions are a separate displacement "
      "credit, not a complete site inventory. Unverified factors produce unavailable "
      "supply totals, not assumed-zero emissions.")

    h("11. Linear structure, decomposition and correctness checks")
    p("For fixed scenario flags and input profiles, all implemented objective "
      "coefficients and constraint coefficients are constants. Products such as "
      "r_yt u_yt are parameter times variable, not bilinear terms. The dispatch LP "
      "is separable by month because each month has a fixed cyclic SOC boundary, "
      "unless annual emissions couple the months. Then use full-year groups omega, "
      "retaining the monthly billing peaks and cyclic storage boundaries inside each year.")
    eq("min{ c^T x + ", sigma("omega", "Q_omega(x)"), " : A x <= a }")
    eq("Q_omega(x) = min{ q_omega^T z_omega : W_omega z_omega >= h_omega - T_omega x, z_omega >= 0 }")
    eq("Q_omega(x) = max{ lambda_omega^T(h_omega - T_omega x) : "
       "W_omega^T lambda_omega <= q_omega, lambda_omega >= 0 }")
    eq("theta_omega >= Q_omega(x^j) + (g_omega^j)^T(x-x^j);    g_omega^j = -T_omega^T lambda_omega^j")
    eq("F_omega(x^j) + (g_F,omega^j)^T(x-x^j) <= 0")
    p("Equalities and finite bounds are represented by equivalent paired inequalities "
      "or by their corresponding dual variables. x contains investment capacities "
      "and z_omega here is the entire block dispatch vector, not peak-only slack z_yt. "
      "The app fixes capacity columns inside each block and uses their dual prices "
      "as the same value-function subgradient. Strong LP duality makes each cut a "
      "global lower support when the subproblem is feasible and solved optimally.")
    eq("LB <= J_star <= UB;    0 <= UB-LB <= epsilon_abs + epsilon_rel |UB|")
    p("LB is the optimized cut-master bound; UB is the best feasible design evaluated "
      "in all blocks. Constants omitted from both optimization bounds must be restored "
      "for cash reporting. A valid finite lower bound is required for each recourse "
      "variable, including possible heat credit. If a subproblem is infeasible, use "
      "feasibility cuts or an explicitly feasible recourse construction; a solver "
      "failure is not an economic result. For an infeasible annual emissions block, "
      "the app solves a temporary Phase-I LP minimizing emissions-budget excess. "
      "Its value F_omega and capacity subgradient generate the feasibility cut above. "
      "Only capacities for which that minimum is zero are feasible. Phase-I slack "
      "is fixed to zero in every accepted dispatch; it is not a soft emissions "
      "relaxation. The app uses penalized electrical shortage recourse for alternatives "
      "and reports any remaining unmet load.")
    p("Dual simplex, interior point and automatic selection are methods of the same "
      "LP engine, not independent mathematical formulations. Positive objective "
      "rescaling changes neither primal optimizer nor problem; objectives and duals "
      "must be transformed back consistently. With fixed technology connection charges, "
      "the capacity master is mixed-integer and includes the activation inequalities "
      "and binary costs. LP recourse cuts remain valid for the continuous capacity "
      "value function and are evaluated at integer-feasible master designs. Dispatch "
      "still uses the selected LP method; capacity activation uses the HiGHS MIP solver.")
    tab(["Validation obligation", "Required mathematical check"], [
        ["Units", "Every balance is MW; every SOC update is MWh; every objective term is CU."],
        ["Demand", "Ordered extrema, nonnegative load, annual-peak anchor, uploaded forecasts not rescaled."],
        ["Conservation", "Hourly balance and storage recurrence; cyclic sum d Delta = eta_RT sum c Delta."],
        ["Costs", "Single escalation and discount; charge supply paid once; reconstruct reported cash NPC."],
        ["Capacity", "Eligibility, duration, aggregate rating and enabled land constraints."],
        ["Dispatch", "All primal bounds and residuals; no accepted simultaneous charge/discharge."],
        ["Peak/adequacy", "Enforce the specified proxy; distinguish it from physical subhourly evidence."],
        ["Optimality", "Dual-cut lower support, LB/UB gap, and solver residuals at retained best design."],
        ["Finance", "Incremental NPV equals reference NPC minus alternative NPC for equal service."],
        ["Reporting", "Positive LCOE denominator; no double-counted BESS energy; correct emissions units."],
    ])

    h("12. Exact extensions and limitations: not claimed as implemented")
    h("12.1 Exclusive battery operation", 2)
    eq("c_yt <= Pmax bmode_yt;    d_yt <= Pmax (1-bmode_yt);    bmode_yt in {0,1}")
    p("Together with c,d <= installed available power, a valid fixed Pmax gives "
      "an exact mixed-integer charge/discharge exclusion. Alternatively c*d=0 is a "
      "nonconvex complementarity constraint. Do not multiply an investment variable "
      "by a binary without a correct linearization. These extensions change the LP "
      "and invalidate ordinary LP Benders cuts unless treated appropriately.")
    h("12.2 Reliability-first objective and exact chronology", 2)
    eq("Stage A: U_star = min U;    Stage B: min NPC subject to U <= U_star + epsilon_U")
    p("Use this staged optimization for strict reliability-first ordering; no finite "
      "penalty alone establishes that ordering. For exact energy not served, solve "
      "each measured subhourly step with its own load, resource, state and shortage, "
      "then U = sum u_t Delta_t. Do not add a separate peak-only shortage term to "
      "that resolved integral.")
    p("For continuous seasonal storage, link e_open,b to e_end,b-1 rather than resetting "
      "it. Commissioning, retirement and capacity degradation require explicit inventory "
      "carryover, spill and initial-energy treatment. Such links couple blocks and "
      "require a different decomposition. End-of-step reserve should be replaced by "
      "an event-consistent intra-step chronology when precise reserve assurance is required.")
    h("12.3 Other extensions", 2)
    p("Multi-stage investments, endogenous battery replacement/aging, stochastic "
      "outages, risk constraints, binary (integer) unit commitment, on-site hydrogen "
      "production/storage, distribution power flow, voltage/frequency dynamics, "
      "project-specific taxes and salvage need additional equations and "
      "verified data. They are not implied by technology names or by the generic "
      "symbols in this document.")
    p("Conclusion: the stated LP is internally linear and its conservation, financial "
      "and dual-cut identities are mathematically checkable. Its numerical solution "
      "is valid only for its declared approximations, input boundary and solver "
      "tolerances. Mathematical consistency is not evidence that a project resource, "
      "tariff, forecast or reliability assumption is empirically correct.")
    h("13. Validation performed for this edition")
    p("Publication is gated on executable checks: the document generator refuses "
      "to publish if any selected check fails. The validation uses separate test "
      "fixtures; their numerical values are not assumptions of the generic model "
      "and are intentionally omitted here.")
    tab(["Check group", "Result and scope"], [
        ["Demand trajectories", "PASS: every selectable trajectory reaches both endpoints; normalized "
         "hourly extrema hit the annual peak and retain their ordering."],
        ["Committed supply", "PASS: direct supply, surplus and residual-load partition conserve power."],
        ["Storage", "PASS: recurrence and cyclic round-trip conservation, including arbitrary-duration "
         "symbolic identity checks and the implemented hourly LP."],
        ["Finance and units", "PASS: nominal escalation/discount identity, incremental NPV, payback "
         "interpolation and core electrical objective dimensions."],
        ["Implemented LP", "PASS: independent balance, SOC, grid envelope, shared heat and "
         "objective reconstruction from an actual dispatch solution."],
        ["Independent reference", "PASS: a separate scipy/HiGHS implementation written only from these "
         "equations reproduces the optimizer's NPC, capacities, dispatch and LCOE for grid-only, "
         "PV+BESS, CHP and thermal minimum-load/ramp/startup instances."],
        ["Benders cuts", "PASS: capacity-price cuts are lower supports at multiple independently "
         "evaluated trial designs."],
        ["Source charging costs", "PASS: grid and generator supply pay for charging without "
         "duplicated battery energy charges."],
        ["Tariffs and shared CHP", "PASS: one annual escalation, tariff accounting and competing "
         "generators with a shared useful-heat limit."],
        ["Resources and thermal boundary", "PASS: resource conversion and calendar replay; independent "
         "committed-solar resource; disabled thermal demand receives no useful-heat credit."],
        ["Lifecycle appraisal", "PASS: calendar extension and solar aging; scheduled replacement "
         "present values reconcile with nominal cashflows and the optimized objective."],
        ["Annual emissions", "PASS: binding hard cap matches reported tonnes and changes dispatch; "
         "Phase-I feasibility cuts discover a feasible heat-recovery investment."],
        ["Technology eligibility", "PASS: technology-specific fuel and CAPEX-fraction maintenance; "
         "Wind requires an hourly profile and observes its availability, land, aging and emissions."],
        ["Connection investment", "PASS: scenario connectivity and route-cost ownership; fixed "
         "connection cost changes the selected capacity and reconciles to cash NPC; saved results export to PDF."],
    ])
    p("These checks provide executable consistency evidence, not a formal proof for "
      "every possible input. The LP dual-support argument and symbolic conservation/"
      "cashflow identities are given above. No check upgrades a screening approximation "
      "to an exact physical representation. Revalidate after changing the implementation.")

    doc.core_properties.title = "GenStudio Generic Mathematical Model"
    doc.core_properties.subject = "Project-independent symbolic optimization formulation"
    doc.core_properties.author = "GenStudio"
    return report


def publish():
    suite = unittest.TestLoader().loadTestsFromNames(GATE_TESTS)
    test_output = io.StringIO()
    validation = unittest.TextTestRunner(stream=test_output).run(suite)
    if not validation.wasSuccessful():
        raise RuntimeError("Mathematical validation failed:\n" + test_output.getvalue())
    report = build_document()
    directory = ROOT / "Model Documentation"
    directory.mkdir(exist_ok=True)
    output = directory / FILENAME
    report.doc.save(output)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        xml = etree.fromstring(archive.read("word/document.xml"))
        ns = {"m": "http://schemas.openxmlformats.org/officeDocument/2006/math"}
        assert len(xml.findall(".//m:oMath", ns)) == report.equations
        text = " ".join(xml.itertext())
    for forbidden in FORBIDDEN_TEXT:
        assert forbidden not in text, forbidden
    assert len(Document(output).tables) >= 4
    sources = ("optimize_generation_mix.py", "generation_app.py", "planning_inputs.py",
               "planning_tariffs.py", "demand_forecasting.py", "scenario_analysis.py",
               "economic_metrics.py", "resource_profiles.py", "lifecycle_costs.py",
               "scenario_inputs.py", "network_topology.py")
    manifest = dict(
        created_utc=datetime.now(timezone.utc).isoformat(),
        document=str(output),
        document_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
        equations=report.equations,
        validation=dict(tests_run=validation.testsRun, failures=len(validation.failures),
                        errors=len(validation.errors), passed=validation.wasSuccessful()),
        source_hashes={name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                       for name in sources},
    )
    (directory / "generic_mathematical_model_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8")
    (directory / "generic_mathematical_model_validation.txt").write_text(
        test_output.getvalue(), encoding="utf-8")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    publish()
