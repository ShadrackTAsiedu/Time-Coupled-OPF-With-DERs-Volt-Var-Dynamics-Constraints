"""User-facing tariff, net-demand and freely competing scenario contracts."""

from datetime import datetime
import unittest

import numpy as np

import generation_app as app
import optimize_generation_mix as model
import planning_inputs as planning
import planning_tariffs
import scenario_inputs
from test_client_planning import short_data


class RevisionTests(unittest.TestCase):
    def request(self, **values):
        return app.validate_request(dict(values=values, scenarios=["R0", "ALL"]))

    def test_removed_inputs_and_only_total_microgrid_capacity_bounds(self):
        keys = {f["key"] for f in app.FIELDS}
        for key in ("retail","summer_energy","pv_min","pv_max","bess_power_max","bess_energy_max",
                    "generator_max","forced_generator_min","dc_ac","solar_cf","utility_tax"):
            self.assertNotIn(key, keys)
        self.assertEqual({f["key"] for f in app.FIELDS if f["group"] == "Microgrid"},
                         {"microgrid_min_mw","microgrid_max_mw"})
        cfg = app.settings_for(self.request()["values"])
        self.assertEqual(cfg["pv_min"], 0)
        self.assertEqual(cfg["forced_generator_min"], 0)
        self.assertEqual(cfg["pv_max"], 10)
        self.assertEqual(cfg["bess_energy_max"], 80)
        self.assertEqual(cfg["dc_ac"], 1)

    def test_solver_choices_reject_unknown_methods(self):
        with self.assertRaisesRegex(ValueError,"Invalid selection"):
            self.request(solver_method="not-a-solver")
        with self.assertRaisesRegex(ValueError,"Unknown solver"):
            model.solver_choice(dict(solver_method="not-a-solver"))
        self.assertEqual(len(model.SOLVERS),3)

    def test_grid_bess_zero_energy_price_all_solver_methods(self):
        request = self.request(horizon_years=1,blended_kwh=0,reactive_rate=.66,bess_power_capex=500000)
        data, _ = app.make_data(request)
        scenarios = [dict(technologies=["grid","bess"]),dict(technologies=["grid","pv","bess"])]
        costs = []
        for method in model.SOLVERS:
            request["values"]["solver_method"] = method
            for scenario in scenarios:
                cfg, names = scenario_inputs.settings(app.settings_for(request["values"]),scenario)
                result = model.solve_decomposed(data,"BATTERY","Zero energy price",names,settings=cfg)
                self.assertEqual(result["solver"]["method"],method)
                self.assertEqual(result["solver"]["capacity_solver"],model.SOLVERS[method][2])
                self.assertEqual(result["solver"]["dispatch_solver"],model.SOLVERS[method][1])
                self.assertLessEqual(result["validation"]["max_simultaneous_charge_discharge_mw"],5e-5)
                self.assertLessEqual(result["validation"]["max_constraint_violation_mw"],5e-5)
                self.assertEqual(result["adequacy"]["unserved_hours"],0)
                self.assertAlmostEqual(result["caps"]["bess_mw"],8)
                costs.append(result["economics"]["npc"])
        np.testing.assert_allclose(costs,costs[0],atol=200,rtol=0)

    def test_blended_total_rate_reactive_and_single_inflation(self):
        request = self.request()
        data, _ = app.make_data(request)
        np.testing.assert_allclose(data["grid_energy"], 79.8)
        np.testing.assert_allclose(data["facility"], .6897 * .37 * 1000)
        self.assertTrue(np.all(data["tou"] == 0))
        self.assertTrue(np.all(data["fixed"] == 0))
        values = self.request(reactive_enabled=False)["values"]
        test = short_data()
        test.update(planning_tariffs.tariffs(test["dates"], values))
        dispatch = {k: np.zeros(len(test["load"])) for k in ("pv","gen","heat","discharge","shortfall")}
        dispatch["grid"] = test["load"].copy()
        econ = model.economics(test, dict(pv_dc_mw=0,bess_mw=0,bess_mwh=0,generator_mw=0),
                               dispatch, "none", False, app.settings_for(values))
        self.assertAlmostEqual(econ["annual"][0]["grid"], test["load"].sum() * 79.8 * 1.03)

    def test_tou_seasons_periods_and_shared_rate(self):
        values = self.request(tariff_mode="tou", summer_same=False, winter_same=False,
            summer_off_kwh=.05, summer_mid_kwh=.1, summer_peak_kwh=.2,
            winter_off_kwh=.06, winter_mid_kwh=.12, winter_peak_kwh=.24)["values"]
        dates = [datetime(2027,7,5,10),datetime(2027,7,5,18),datetime(2027,7,5,22),
                 datetime(2027,7,3,18), datetime(2027,1,4,18)]
        np.testing.assert_allclose(planning_tariffs.tariffs(dates, values)["grid_energy"], [50,200,100,100,240])
        values["summer_same"] = True
        np.testing.assert_allclose(planning_tariffs.tariffs(dates, values)["grid_energy"], [50,50,50,50,240])

    def test_joint_hydrogen_gas_optional_and_shared_heat(self):
        cfg = app.settings_for(self.request()["values"])
        cfg, names = scenario_inputs.settings(cfg, scenario_inputs.DEFAULTS[5])
        result = model.solve_decomposed(short_data(), "ALL", "All eligible", names, settings=cfg)
        caps = result["caps"]
        self.assertAlmostEqual(caps["microgrid_total_ac_mw"],
            caps["pv_dc_mw"] + caps["bess_mw"] + sum(caps["generators_mw"].values()))
        self.assertGreaterEqual(caps["microgrid_total_ac_mw"], 8 - 1e-6)
        self.assertLessEqual(caps["microgrid_total_ac_mw"], 10 + 1e-6)
        self.assertTrue(any(c == 0 for c in caps["generators_mw"].values()))
        self.assertTrue(np.all(result["dispatch"]["heat"] <= short_data()["heat"] + 1e-6))
        sub = model.MonthlyDispatch(short_data(), 0, ["h2_chp","ng_chp"], False,
                                    short_data()["solar"], settings=cfg)
        cap = np.array([0,0,0,6,6.])
        cost, grad = sub.evaluate(cap)
        self.assertEqual(len(grad),5)
        other = cap + [0,0,0,1,-1]
        trial, _ = sub.evaluate(other)
        self.assertGreaterEqual(trial + 1e-6, cost + grad @ (other - cap))
        self.assertTrue(np.all(sub.operation()["heat"] <= 5 + 1e-6))

    def test_island_without_grid_and_ineligible_generators(self):
        scenario = dict(id="I",name="PV battery island",technologies=["pv","bess"],reference=False)
        cfg, names = scenario_inputs.settings(app.settings_for(self.request()["values"]),scenario)
        data = short_data()
        result = model.solve_decomposed(data,"I","Island",names,settings=cfg)
        self.assertTrue(np.all(np.abs(result["dispatch"]["grid"]) < 1e-6))
        self.assertEqual(result["caps"]["generator_mw"],0)
        self.assertEqual(result["validation"]["max_quarter_hour_grid_mw"],0)
        self.assertGreater(result["adequacy"]["unserved_mwh"],0)
        self.assertLess(result["validation"]["max_constraint_violation_mw"],5e-5)

    def test_generators_compete_on_cost_without_forced_capacity(self):
        from pathlib import Path
        import tempfile
        cfg = app.settings_for(self.request()["values"])
        cfg.update(pv_max=0,bess_power_max=0,bess_energy_max=0)
        for name, fuel in (("h2",1),("ng",2)):
            cfg["technology_parameters"][name].update(capex=10000,fom=0,fuel=fuel,vom=0,carbon=0)
        result = model.solve_decomposed(short_data(),"MERIT","Competing generators",["ng","h2"],settings=cfg)
        self.assertAlmostEqual(result["caps"]["generators_mw"]["h2"],10)
        self.assertAlmostEqual(result["caps"]["generators_mw"]["ng"],0)
        self.assertGreater(result["dispatch"]["gen_h2"].sum(),0)
        self.assertAlmostEqual(result["dispatch"]["gen_ng"].sum(),0)
        result["eligible_technologies"] = ["grid","ng","h2"]
        with tempfile.TemporaryDirectory() as directory:
            summary = app.export_results(Path(directory),short_data(),self.request(horizon_years=1),
                                         cfg,[result],[],[],"Named generator test")
            self.assertNotIn("Generator MW",summary["columns"])
            self.assertNotIn("Hydrogen CHP MW",summary["columns"])
            self.assertAlmostEqual(summary["rows"][0][summary["columns"].index("Hydrogen turbine MW")],10)
            self.assertGreater(summary["rows"][0][summary["columns"].index("Hydrogen turbine MWh")],0)
            self.assertAlmostEqual(summary["rows"][0][summary["columns"].index("Natural gas turbine MW")],0)

    def test_export_reimport_applies_derate_and_plans_once(self):
        import csv
        import io
        request = self.request(horizon_years=1)
        data, _ = app.make_data(request)
        text = io.StringIO()
        writer = csv.writer(text)
        writer.writerow(app.HOURLY_COLUMNS)
        writer.writerows(app.profile_row(data,i) for i in range(len(data["load"])))
        request["forecast_files"] = [dict(name="projected.csv",content=text.getvalue())]
        imported, _ = app.make_data(app.validate_request(request))
        for key in ("gross_load","load","qmax","qmin","solar_resource","solar","planned_solar_available"):
            np.testing.assert_allclose(data[key],imported[key],rtol=1e-12,atol=1e-12)

    def test_charging_cost_paid_by_grid_or_generator_not_twice(self):
        data = short_data()
        cfg = app.settings_for(self.request()["values"])
        caps = dict(pv_dc_mw=0,bess_mw=8,bess_mwh=16,generator_mw=10)
        base = {k:np.zeros(len(data["load"])) for k in
                ("grid","gen","pv","charge","discharge","heat","shortfall")}
        base["grid"] = data["load"].copy()
        data.update(planning_tariffs.tariffs(data["dates"],self.request(reactive_enabled=False)["values"]))
        baseline = model.economics(data,caps,base,"ng",False,cfg)
        for source in ("grid","gen"):
            charged = {k:v.copy() for k,v in base.items()}
            charged["charge"][:] = 1
            charged[source] += 1
            actual = model.economics(data,caps,charged,"ng",False,cfg)
            unit_cost = (79.8 if source == "grid" else sum(
                cfg["technology_parameters"]["ng"][k] for k in ("fuel","vom","carbon")))
            self.assertAlmostEqual(actual["annual"][0]["net_opex"] - baseline["annual"][0]["net_opex"],
                                   len(data["load"]) * unit_cost * 1.03)
            self.assertEqual(actual["annual"][0]["bess_charge_mwh"],len(data["load"]))

    def test_generator_columns_follow_eligibility_even_when_zero(self):
        results = [
            dict(eligible_technologies=["grid","ng_chp"],tech=["ng_chp"]),
            dict(eligible_technologies=["grid","h2"],tech=["h2"])]
        self.assertEqual(scenario_inputs.selected_generators(results),
                         [("h2","Hydrogen turbine"),("ng_chp","Natural gas CHP")])

    def test_planned_net_first_surplus_and_separate_derate(self):
        data = short_data()
        data["solar_resource"] = np.ones(len(data["load"]))
        data["solar"] = data["solar_resource"] * .5
        project = planning.validate_projects([dict(name="Committed solar",technology="Solar",capacity_mw=100,
            start_year=2027,end_year=2027,derate_factor=.8,degradation=.01)])
        planning.planned_profiles(data,project,.005)
        np.testing.assert_allclose(data["planned_solar_available"],80)
        planning.apply_planned_net_load(data)
        self.assertTrue(np.all(data["load"] == 0))
        np.testing.assert_allclose(data["planned_surplus"] + data["planned_direct_supply"],80)
        cfg = app.settings_for(self.request()["values"])
        result = model.solve_decomposed(data,"R0","Reference","none",reference=True,settings=cfg)
        self.assertEqual(result["caps"]["microgrid_total_ac_mw"],0)
        self.assertLess(result["dispatch"]["grid"].sum(),1e-5)
        self.assertAlmostEqual(result["economics"]["annual"][0]["served_mwh"], data["service_load"].sum())

    def test_generic_year_and_upload_requires_forecast(self):
        request = self.request(start_year=2030, horizon_years=1, trajectory_mode="model")
        request["planned_generation"] = []
        data, _ = app.make_data(request)
        self.assertEqual(data["dates"][0].year,2030)
        self.assertEqual(data["historical"]["dates"][0].year,2029)
        self.assertEqual(data["annual_trajectory"][0]["year"],2029)
        with self.assertRaisesRegex(ValueError,"Load a forecast"):
            app.validate_request(dict(values={},demand_source="upload"))

    def test_zero_net_mean_with_remaining_peak_reports_shortage(self):
        data = short_data()
        data["load"][:] = 0
        data["qmin"][:] = 0
        data["qmax"][:] = 1
        data["service_load"] = np.full(len(data["load"]),20.)
        for eligible in (["grid"],["pv"]):
            cfg, names = scenario_inputs.settings(app.settings_for(self.request(
                grid_limit=0,microgrid_min_mw=0,microgrid_max_mw=0)["values"]),
                dict(technologies=eligible))
            result = model.solve_decomposed(data,"PEAK","Peak only",names,settings=cfg)
            self.assertEqual(result["adequacy"]["unserved_hours"],len(data["load"]))
            self.assertAlmostEqual(result["adequacy"]["unserved_mwh"],len(data["load"]) * .25)
            self.assertAlmostEqual(result["validation"]["hourly_balance_error_mw"],0)
            self.assertLess(result["validation"]["max_quarter_hour_grid_mw"],1e-6)


if __name__ == "__main__":
    unittest.main()
