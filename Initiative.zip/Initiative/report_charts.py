"""Print-quality inline SVG charts and figure builders for the client report.

Every chart is plain SVG (no scripts, fonts or external resources) drawn in the report's palette. Each figure builder
returns a complete ``<figure>`` (chart, title and a one-sentence takeaway) or an empty string when the data behind it is
missing, so a section never shows an empty chart.
"""

import csv
import math
from pathlib import Path

import currency
import report as R

esc = lambda s: R.esc(currency.label(s) if isinstance(s, str) else s)
W = 900
BLUE, AMBER, GREEN, RED, PURPLE, TEAL, GREY, BROWN, NAVY, ACCENT = (
    "#2f6fb3", "#e0a030", "#4f8f5b", "#c0504d", "#7a5ea8", "#3aa6a6", "#8a8f98", "#b5651d", "#0b2a3c", "#00827c")
MUTED_BAR = "#9db4c8"
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
SEASONS = [("Dec-Feb", (12, 1, 2), BLUE), ("Mar-May", (3, 4, 5), GREEN), ("Jun-Aug", (6, 7, 8), AMBER), ("Sep-Nov", (9, 10, 11), PURPLE)]
NPC_COLORS = {"capex": NAVY, "grid_pv": BLUE, "fuel_pv": RED, "variable_om_pv": PURPLE, "fixed_om_pv": TEAL, "carbon_pv": GREY,
              "replacement_pv": BROWN, "upgrade_pv": AMBER, "upgrade_om_pv": GREEN}


# --------------------------------------------------------------------------- geometry helpers

def _step(span, count=5):
    raw = max(span, 1e-12) / count
    mag = 10 ** math.floor(math.log10(raw))
    return next(m * mag for m in (1, 2, 2.5, 5, 10) if raw <= m * mag * 1.0001)


def axis(lo, hi, count=5):
    """Round axis bounds and tick values that cover [lo, hi]."""
    if hi - lo < 1e-12:
        hi = lo + 1
    step = _step(hi - lo, count)
    a, b = math.floor(lo / step + 1e-9) * step, math.ceil(hi / step - 1e-9) * step
    return a, b, [a + i * step for i in range(int(round((b - a) / step)) + 1)]


def tick(value, scale):
    if abs(value) < 1e-12:
        return "0"
    if scale >= 1e6:
        return f"{value / 1e6:,.4g}M"
    if scale >= 1e4:
        return f"{value / 1e3:,.4g}k"
    return f"{value:,.4g}"


def fnum(value, decimals=1):
    return f"{value:,.{min(decimals, 4)}f}"


def legend(items, x, y, max_w):
    """Wrapped legend; returns (svg, height used)."""
    out, cx, cy = [], x, y
    for name, color in items:
        width = 20 + 5.9 * len(str(name))
        if cx + width > x + max_w and cx > x:
            cx, cy = x, cy + 16
        out.append(f'<rect x="{cx:.0f}" y="{cy}" width="10" height="10" fill="{color}"/><text x="{cx + 14:.0f}" y="{cy + 9}">{esc(name)}</text>')
        cx += width + 12
    return "".join(out), cy + 16 - y


def wrap(body, height, label):
    return R.svg_open(W, round(height), label) + "".join(body) + "</svg>"


def _cat_labels(out, categories, x0, band, y, rotate):
    for i, cat in enumerate(categories):
        cx = x0 + band * (i + .5)
        text = esc(str(cat)[:30])
        if rotate:
            out.append(f'<text x="{cx:.1f}" y="{y}" text-anchor="end" transform="rotate(-35 {cx:.1f} {y})">{text}</text>')
        else:
            out.append(f'<text x="{cx:.1f}" y="{y}" text-anchor="middle">{text}</text>')


def _needs_rotation(categories, band):
    return max((len(str(c)) for c in categories), default=0) * 5.8 > band * .95


# --------------------------------------------------------------------------- chart primitives

def stacked(categories, series, unit, label, decimals=0, totals=True, plot_h=250, subs=None):
    """Stacked columns, one per category; series = [(name, values, color)]. Negative values stack downward."""
    series = [(n, [v or 0 for v in vals], c) for n, vals, c in series if any(abs(v or 0) > 1e-9 for v in vals)]
    if not categories or not series:
        return ""
    left, right, top = 66, 14, 26
    band = (W - left - right) / len(categories)
    rotate = _needs_rotation(categories, band)
    pos = [sum(max(s[1][i], 0) for s in series) for i in range(len(categories))]
    neg = [sum(min(s[1][i], 0) for s in series) for i in range(len(categories))]
    lo, hi, ticks = axis(min(neg + [0]), max(pos + [1e-9]))
    y = lambda v: top + plot_h * (1 - (v - lo) / (hi - lo))
    scale = max(abs(lo), abs(hi))
    out = [f'<text x="{left - 6}" y="{top - 12}" text-anchor="end">{esc(unit)}</text>']
    for t in ticks:
        out.append(f'<line class="grid" x1="{left}" x2="{W - right}" y1="{y(t):.1f}" y2="{y(t):.1f}"/><text x="{left - 6}" y="{y(t) + 4:.1f}" text-anchor="end">{tick(t, scale)}</text>')
    for i, cat in enumerate(categories):
        up, down = 0, 0
        for name, vals, color in series:
            v = vals[i]
            if abs(v) < 1e-9:
                continue
            a, b = (up, up + v) if v > 0 else (down + v, down)
            up, down = (up + v, down) if v > 0 else (up, down + v)
            out.append(f'<rect x="{left + i * band + band * .16:.1f}" y="{y(b):.1f}" width="{band * .68:.1f}" height="{max(y(a) - y(b), .5):.1f}" fill="{color}">'
                       f'<title>{esc(cat)} {esc(name)}: {fnum(v, decimals)}</title></rect>')
        if totals and pos[i] > 0:
            out.append(f'<text x="{left + i * band + band / 2:.1f}" y="{y(pos[i]) - 4:.1f}" text-anchor="middle" font-weight="600">{fnum(pos[i] + neg[i], decimals)}</text>')
    out.append(f'<line class="axis" x1="{left}" x2="{W - right}" y1="{y(0):.1f}" y2="{y(0):.1f}"/>')
    base = top + plot_h + (50 if rotate else 16)
    _cat_labels(out, categories, left, band, top + plot_h + 14, rotate)
    if subs:
        base += 14
        for i, text in enumerate(subs):
            out.append(f'<text x="{left + band * (i + .5):.1f}" y="{base}" text-anchor="middle" class="sub">{esc(text)}</text>')
        base += 4
    lg, lh = legend([(n, c) for n, _, c in series], left, base + 8, W - left - right)
    return wrap(out + [lg], base + 8 + lh, label)


def hbars_multi(rows, series, unit, label, decimals=1, best=None, vlines=(), label_w=None, row_h=None):
    """Horizontal bars; rows = [(label, [value per series])]; None values are skipped. series = [(name, color)]."""
    rows = [(l, v) for l, v in rows if any(x is not None for x in v)]
    if not rows:
        return ""
    k = len(series)
    label_w = label_w or min(380, max(120, max(len(str(l)) for l, _ in rows) * 5.9 + 12))
    left, right, top = label_w + 10, 90, 10
    bar = 15 if k > 1 else 18
    row = row_h or (bar * k + 10)
    vals = [x for _, v in rows for x in v if x is not None]
    lo, hi, ticks = axis(min(vals + [0]), max(vals + [1e-9]), 4)
    x = lambda v: left + (W - left - right) * (v - lo) / (hi - lo)
    scale = max(abs(lo), abs(hi))
    plot_h = row * len(rows)
    out = []
    for t in ticks:
        out.append(f'<line class="grid" x1="{x(t):.1f}" x2="{x(t):.1f}" y1="{top}" y2="{top + plot_h}"/>'
                   f'<text x="{x(t):.1f}" y="{top + plot_h + 14}" text-anchor="middle">{tick(t, scale)}</text>')
    out.append(f'<text x="{W - right}" y="{top + plot_h + 28}" text-anchor="end">{esc(unit)}</text>')
    for r, (name, vs) in enumerate(rows):
        y0 = top + r * row + 4
        out.append(f'<text x="{left - 8}" y="{y0 + bar * k / 2 + 4:.1f}" text-anchor="end" font-weight="{600 if name == best else 400}">{esc(str(name)[:64])}</text>')
        for j, v in enumerate(vs):
            if v is None:
                continue
            color = ACCENT if (best is not None and name == best and k == 1) else series[j][1]
            xa, xb = sorted((x(0), x(v)))
            out.append(f'<rect x="{xa:.1f}" y="{y0 + j * bar:.1f}" width="{max(xb - xa, .8):.1f}" height="{bar - 2}" fill="{color}"/>'
                       f'<text x="{(xb + 5) if v >= 0 else (xa - 5):.1f}" y="{y0 + j * bar + bar - 4:.1f}" text-anchor="{"start" if v >= 0 else "end"}">{fnum(v, decimals)}</text>')
    out.append(f'<line class="axis" x1="{x(0):.1f}" x2="{x(0):.1f}" y1="{top}" y2="{top + plot_h}"/>')
    for value, text in vlines:
        if lo <= value <= hi:
            out.append(f'<line x1="{x(value):.1f}" x2="{x(value):.1f}" y1="{top}" y2="{top + plot_h}" stroke="{RED}" stroke-width="1.4" stroke-dasharray="5 3"/>'
                       f'<text x="{x(value) + 4:.1f}" y="{top + 11}" fill="{RED}" style="fill:{RED}">{esc(text)}</text>')
    height = top + plot_h + 34
    if k > 1:
        lg, lh = legend(series, left, height, W - left - right)
        out.append(lg)
        height += lh
    return wrap(out, height + 4, label)


def hbars(items, unit, label, decimals=1, best=None, color=MUTED_BAR, vlines=()):
    return hbars_multi([(n, [v]) for n, v in items], [("", color)], unit, label, decimals, best, vlines)


def panels(cats, specs, label, best=None):
    """Small-multiple horizontal bars sharing one category column; specs = [(title, values, suffix, decimals)]."""
    cats_vals = [(c, [s[1][i] for s in specs]) for i, c in enumerate(cats)]
    if not cats or all(v is None for _, vs in cats_vals for v in vs):
        return ""
    label_w = min(260, max(60, max(len(str(c)) for c in cats) * 5.9 + 12))
    gap, top, row = 18, 30, 24
    pw = (W - label_w - 14 - gap * (len(specs) - 1)) / len(specs)
    out = []
    for p, (title, values, suffix, decimals) in enumerate(specs):
        x0 = label_w + 10 + p * (pw + gap)
        real = [v for v in values if v is not None]
        out.append(f'<text x="{x0:.0f}" y="16" font-weight="600">{esc(title)}</text>')
        if not real:
            continue
        lo, hi = min(real + [0]), max(real + [1e-9])
        span = (hi - lo) or 1
        inner = pw - 62
        x = lambda v: x0 + inner * (v - lo) / span
        for i, v in enumerate(values):
            y = top + i * row
            if v is None:
                out.append(f'<text x="{x0:.1f}" y="{y + 14}" style="fill:#6b7885">n/a</text>')
                continue
            xa, xb = sorted((x(0), x(v)))
            color = ACCENT if cats[i] == best else MUTED_BAR
            out.append(f'<rect x="{xa:.1f}" y="{y + 3}" width="{max(xb - xa, .8):.1f}" height="{row - 9}" fill="{color}"/>'
                       f'<text x="{(xb + 4) if v >= 0 else (xa - 4):.1f}" y="{y + 14}" text-anchor="{"start" if v >= 0 else "end"}">{fnum(v, decimals)}{esc(suffix)}</text>')
        out.append(f'<line class="axis" x1="{x(0):.1f}" x2="{x(0):.1f}" y1="{top - 2}" y2="{top + row * len(cats)}"/>')
    for i, c in enumerate(cats):
        out.append(f'<text x="{label_w}" y="{top + i * row + 14}" text-anchor="end" font-weight="{600 if c == best else 400}">{esc(str(c)[:40])}</text>')
    return wrap(out, top + row * len(cats) + 8, label)


def xy_lines(series, unit, label, xticks=None, ymin=None, ymax=None, hlines=(), plot_h=250, decimals=1, markers=True, area=None, xlabel=""):
    """Line chart; series = [(name, [(x, y)...], color, dashed)]. hlines = [(y, text, color)]. area = (name, lows, highs, color) band on series x."""
    pts = [p for s in series for p in s[1] if p[1] is not None]
    if not pts:
        return ""
    left, right, top = 66, 22, 26
    xs = [p[0] for p in pts] + ([] if not area else [])
    x_lo, x_hi = min(xs), max(xs)
    if x_hi == x_lo:
        x_hi = x_lo + 1
    ys = [p[1] for p in pts] + [h[0] for h in hlines] + (list(area[2]) + list(area[1]) if area else [])
    lo, hi, ticks = axis(min(ys) if ymin is None else ymin, max(ys) if ymax is None else ymax)
    if ymin is not None:
        lo = ymin
    if ymax is not None:
        hi = ymax
    ticks = [t for t in ticks if lo - 1e-9 <= t <= hi + 1e-9]
    x = lambda v: left + (W - left - right) * (v - x_lo) / (x_hi - x_lo)
    y = lambda v: top + plot_h * (1 - (v - lo) / (hi - lo))
    scale = max(abs(lo), abs(hi))
    out = [f'<text x="{left - 6}" y="{top - 12}" text-anchor="end">{esc(unit)}</text>']
    for t in ticks:
        out.append(f'<line class="grid" x1="{left}" x2="{W - right}" y1="{y(t):.1f}" y2="{y(t):.1f}"/><text x="{left - 6}" y="{y(t) + 4:.1f}" text-anchor="end">{tick(t, scale)}</text>')
    labels = xticks if xticks is not None else [(v, f"{v:g}") for v in sorted({p[0] for p in pts})]
    for value, text in labels:
        out.append(f'<text x="{x(value):.1f}" y="{top + plot_h + 14}" text-anchor="middle">{esc(text)}</text>')
    if xlabel:
        out.append(f'<text x="{(left + W - right) / 2:.0f}" y="{top + plot_h + 30}" text-anchor="middle">{esc(xlabel)}</text>')
    if area:
        name, lows, highs, color = area
        base = [p for p in series[0][1]]
        upper = " ".join(f"{x(p[0]):.1f},{y(h):.1f}" for p, h in zip(base, highs))
        lower = " ".join(f"{x(p[0]):.1f},{y(l):.1f}" for p, l in zip(reversed(base), reversed(lows)))
        out.append(f'<polygon points="{upper} {lower}" fill="{color}" opacity=".18"/>')
    for value, text, color in hlines:
        out.append(f'<line x1="{left}" x2="{W - right}" y1="{y(value):.1f}" y2="{y(value):.1f}" stroke="{color}" stroke-width="1.4" stroke-dasharray="6 3"/>'
                   f'<text x="{W - right - 4}" y="{y(value) - 4:.1f}" text-anchor="end" style="fill:{color}">{esc(text)}</text>')
    out.append(f'<line class="axis" x1="{left}" x2="{W - right}" y1="{y(lo):.1f}" y2="{y(lo):.1f}"/>')
    for name, points, color, dashed in series:
        pts_ok = [p for p in points if p[1] is not None]
        line = " ".join(f"{x(px):.1f},{y(py):.1f}" for px, py in pts_ok)
        out.append(f'<polyline fill="none" stroke="{color}" stroke-width="2" {"stroke-dasharray=%s5 3%s" % (chr(34), chr(34)) if dashed else ""} points="{line}"/>')
        if markers and len(pts_ok) <= 40:
            out += [f'<circle cx="{x(px):.1f}" cy="{y(py):.1f}" r="2.8" fill="{color}"><title>{esc(name)}: {fnum(py, decimals)}</title></circle>' for px, py in pts_ok]
    items = [(s[0], s[2]) for s in series if s[0]] + ([(area[0], area[3])] if area else [])
    base = top + plot_h + (36 if xlabel else 22)
    lg, lh = legend(items, left, base, W - left - right) if items else ("", 0)
    return wrap(out + [lg], base + lh + 4, label)


def combo(categories, stacks, line, unit_left, unit_right, label, decimals=0, plot_h=250):
    """Stacked columns on the left axis and one line on the right axis; line = (name, values, color)."""
    stacks = [(n, [v or 0 for v in vals], c) for n, vals, c in stacks if any(abs(v or 0) > 1e-9 for v in vals)]
    if not categories or not stacks:
        return ""
    left, right, top = 66, 66, 26
    band = (W - left - right) / len(categories)
    totals = [sum(s[1][i] for s in stacks) for i in range(len(categories))]
    lo, hi, ticks = axis(0, max(totals + [1e-9]))
    y = lambda v: top + plot_h * (1 - (v - lo) / (hi - lo))
    out = [f'<text x="{left - 6}" y="{top - 12}" text-anchor="end">{esc(unit_left)}</text><text x="{W - right + 6}" y="{top - 12}">{esc(unit_right)}</text>']
    for t in ticks:
        out.append(f'<line class="grid" x1="{left}" x2="{W - right}" y1="{y(t):.1f}" y2="{y(t):.1f}"/><text x="{left - 6}" y="{y(t) + 4:.1f}" text-anchor="end">{tick(t, hi)}</text>')
    for i, cat in enumerate(categories):
        base = 0
        for name, vals, color in stacks:
            if vals[i] > 0:
                out.append(f'<rect x="{left + i * band + band * .18:.1f}" y="{y(base + vals[i]):.1f}" width="{band * .64:.1f}" height="{y(base) - y(base + vals[i]):.1f}" fill="{color}">'
                           f'<title>{esc(cat)} {esc(name)}: {fnum(vals[i], decimals)}</title></rect>')
            base += vals[i]
    _cat_labels(out, categories, left, band, top + plot_h + 14, _needs_rotation(categories, band))
    nm, vals, color = line
    real = [v for v in vals if v is not None]
    if real:
        rlo, rhi, rticks = axis(0, max(real))
        yr = lambda v: top + plot_h * (1 - (v - rlo) / (rhi - rlo))
        for t in rticks:
            out.append(f'<text x="{W - right + 6}" y="{yr(t) + 4:.1f}" style="fill:{color}">{tick(t, rhi)}</text>')
        pts = [(left + band * (i + .5), yr(v)) for i, v in enumerate(vals) if v is not None]
        out.append(f'<polyline fill="none" stroke="{color}" stroke-width="2.2" points="{" ".join(f"{a:.1f},{b:.1f}" for a, b in pts)}"/>')
        out += [f'<circle cx="{a:.1f}" cy="{b:.1f}" r="3" fill="{color}"/>' for a, b in pts]
    out.append(f'<line class="axis" x1="{left}" x2="{W - right}" y1="{y(0):.1f}" y2="{y(0):.1f}"/>')
    base_y = top + plot_h + 24
    lg, lh = legend([(n, c) for n, _, c in stacks] + [(nm, color)], left, base_y, W - left - right)
    return wrap(out + [lg], base_y + lh + 4, label)


def ranges(rows, unit, label, bands=(), vlines=(), decimals=3):
    """Horizontal min-max range per row with an optional marker; rows = [(label, low, high, marker)]. bands = [(lo, hi, color)]."""
    rows = [r for r in rows if r[1] is not None and r[2] is not None]
    if not rows:
        return ""
    label_w = min(340, max(100, max(len(str(r[0])) for r in rows) * 5.9 + 12))
    left, right, top, row = label_w + 10, 30, 14, 26
    vals = [v for r in rows for v in r[1:3]] + [v for b in bands for v in b[:2]] + [v for v, _ in vlines]
    lo, hi, ticks = axis(min(vals), max(vals), 5)
    x = lambda v: left + (W - left - right) * (v - lo) / (hi - lo)
    out = []
    for a, b, color in bands:
        out.append(f'<rect x="{x(a):.1f}" y="{top}" width="{x(b) - x(a):.1f}" height="{row * len(rows)}" fill="{color}" opacity=".16"/>')
    for t in ticks:
        out.append(f'<line class="grid" x1="{x(t):.1f}" x2="{x(t):.1f}" y1="{top}" y2="{top + row * len(rows)}"/>'
                   f'<text x="{x(t):.1f}" y="{top + row * len(rows) + 14}" text-anchor="middle">{tick(t, 1)}</text>')
    for value, text in vlines:
        out.append(f'<line x1="{x(value):.1f}" x2="{x(value):.1f}" y1="{top}" y2="{top + row * len(rows)}" stroke="{RED}" stroke-width="1.4" stroke-dasharray="5 3"/>'
                   f'<text x="{x(value):.1f}" y="{top + row * len(rows) + 28}" text-anchor="middle" style="fill:{RED}">{esc(text)}</text>')
    for i, (name, a, b, mid) in enumerate(rows):
        y = top + i * row
        out.append(f'<text x="{left - 8}" y="{y + 16}" text-anchor="end">{esc(str(name)[:58])}</text>'
                   f'<rect x="{x(a):.1f}" y="{y + 6}" width="{max(x(b) - x(a), 2):.1f}" height="12" rx="2" fill="{BLUE}"><title>{fnum(a, decimals)} to {fnum(b, decimals)} {esc(unit)}</title></rect>'
                   f'<text x="{x(a) - 4:.1f}" y="{y + 16}" text-anchor="end" style="font-size:10px">{fnum(a, decimals)}</text>'
                   f'<text x="{x(b) + 4:.1f}" y="{y + 16}" style="font-size:10px">{fnum(b, decimals)}</text>')
        if mid is not None:
            out.append(f'<rect x="{x(mid) - 1.5:.1f}" y="{y + 3}" width="3" height="18" fill="{NAVY}"/>')
    height = top + row * len(rows) + (40 if vlines else 22)
    out.append(f'<text x="{W - right}" y="{height - 2}" text-anchor="end">{esc(unit)}</text>')
    return wrap(out, height + 6, label)


def fig(svg, title, take):
    if not svg:
        return ""
    return f'<figure>{svg}<figcaption>{esc(title)}</figcaption><p class="take"><strong>What this shows:</strong> {esc(take)}</p></figure>'


# --------------------------------------------------------------------------- data loaders

def _hist_files(folder):
    return sorted(Path(folder).glob("historical_load_*.csv"))


def _read_series(path, columns):
    """Rows of (month, hour, year, *values) for the named columns; unreadable rows are skipped."""
    out = []
    try:
        with Path(path).open(encoding="utf-8-sig", newline="") as stream:
            reader = csv.reader(stream)
            header = next(reader)
            idx = [header.index(c) if c in header else None for c in columns]
            for row in reader:
                try:
                    ts = row[0]
                    out.append((int(ts[5:7]), int(ts[11:13]), int(ts[:4])) + tuple(float(row[i]) if i is not None and row[i] != "" else None for i in idx))
                except (ValueError, IndexError):
                    continue
    except (OSError, StopIteration, ValueError):
        return []
    return out


def _percentile_curve(values, points=101):
    ordered = sorted(values, reverse=True)
    n = len(ordered)
    return [(100 * i / (points - 1), ordered[min(n - 1, int(round(i * (n - 1) / (points - 1))))]) for i in range(points)]


def load_profiles(run):
    """Historical and modeled hourly load summaries (cached on the run): monthly band, seasonal day, duration curves, solar capacity factor."""
    if "_profiles" in run:
        return run["_profiles"]
    folder = run["folder"]
    data = dict(hist=None, proj={}, solar_cf=None)
    rows = [r for p in _hist_files(folder) for r in _read_series(p, ["load_mw"])]
    rows = [r for r in rows if r[3] is not None]
    if len(rows) >= 24 * 60:
        data["hist"] = dict(rows=rows, years=sorted({r[2] for r in rows}))
    proj = _read_series(folder / "hourly_projected_load.csv", ["load_mw", "solar_per_mw"]) if (folder / "hourly_projected_load.csv").is_file() else []
    by_year = {}
    for m, h, y, load, solar in proj:
        by_year.setdefault(y, []).append(load)
    data["proj"] = {y: v for y, v in by_year.items() if len(v) >= 8000 and all(x is not None for x in v)}
    solar = [(m, s) for m, h, y, load, s in proj if s is not None]
    if len(solar) >= 8000 and max(s for _, s in solar) > 0:
        sums, counts = [0.0] * 12, [0] * 12
        for m, s in solar:
            sums[m - 1] += s
            counts[m - 1] += 1
        data["solar_cf"] = [sums[i] / counts[i] if counts[i] else None for i in range(12)]
    if data["hist"] is None and data["proj"]:
        first = min(data["proj"])
        data["hist"] = dict(rows=[r for r in proj if r[2] == first and r[3] is not None], years=[first], modeled=True)
    run["_profiles"] = data
    return data


def dispatch_summary(run, code, years):
    """One pass over a dispatch CSV: monthly energy by source and hour-of-day means for the given years (cached)."""
    key = ("_dispatch", code, tuple(years))
    if key in run:
        return run[key]
    path = Path(run["folder"]) / f"dispatch_{code}.csv"
    result = {}
    if path.is_file():
        try:
            with path.open(encoding="utf-8-sig", newline="") as stream:
                reader = csv.DictReader(stream)
                fields = reader.fieldnames or []
                load_key = "net_load_mw" if "net_load_mw" in fields else "load_mw"
                solar_key = "optimized_solar" if "optimized_solar" in fields else "pv"
                cols = dict(load=load_key, grid="grid", solar=solar_key, wind="gen_wind", gen="gen", planned="planned_renewable",
                            discharge="discharge", charge="charge", soc="soc")
                for r in reader:
                    ts = r.get("timestamp") or ""
                    year = int(ts[:4]) if ts[:4].isdigit() else None
                    if year not in years:
                        continue
                    d = result.setdefault(year, dict(month=[dict() for _ in range(12)], hour=[dict(n=0) for _ in range(24)], soc=[[] for _ in range(24)], rows=0))
                    m, h = int(ts[5:7]) - 1, int(ts[11:13])
                    d["rows"] += 1
                    d["hour"][h]["n"] += 1
                    for name, column in cols.items():
                        try:
                            v = float(r.get(column) or 0)
                        except ValueError:
                            v = 0.0
                        d["month"][m][name] = d["month"][m].get(name, 0.0) + v
                        d["hour"][h][name] = d["hour"][h].get(name, 0.0) + v
                        if name == "soc":
                            d["soc"][h].append(v)
        except (OSError, ValueError):
            result = {}
    run[key] = result
    return result


# --------------------------------------------------------------------------- shared series helpers

def energy_series(annual):
    """Energy by source per year (MWh), keeping only the sources that supply energy in this scenario."""
    def col(*keys):
        return [sum(a.get(k) or 0 for k in keys) for a in annual]
    wind = col("wind_generation_mwh")
    gens = [max((a.get("gen_mwh") or 0) - (a.get("wind_generation_mwh") or 0), 0) for a in annual]
    series = [("Grid import", col("grid_mwh"), BLUE), ("New solar PV", col("optimized_solar_mwh", "pv_mwh") if any(a.get("optimized_solar_mwh") is not None for a in annual)
              else col("pv_mwh"), AMBER), ("Wind", wind, TEAL), ("Generators", gens, RED), ("Planned renewables", col("planned_renewable_mwh"), GREY),
              ("BESS discharge", col("bess_discharge_mwh"), GREEN)]
    return [s for s in series if sum(s[1]) > 1e-6]


def renewable_fraction(annual):
    out = []
    for a in annual:
        demand = a.get("demand_mwh") or 0
        ren = (a.get("optimized_solar_mwh") or 0) + (a.get("wind_generation_mwh") or 0) + (a.get("planned_renewable_mwh") or 0)
        out.append(100 * ren / demand if demand > 0 else None)
    return out


def annual_of(run, code):
    return run["results"][code]["economics"].get("annual") or []


def mm(value, digits=1):
    return R.mil(value, digits)


# --------------------------------------------------------------------------- figure builders: data and demand

def fig_monthly_load(run):
    hist = (load_profiles(run).get("hist"))
    if not hist:
        return ""
    sums = [[] for _ in range(12)]
    for m, h, y, v in [r[:4] for r in hist["rows"]]:
        sums[m - 1].append(v)
    if any(not s for s in sums):
        return ""
    mn, mean, mx = [min(s) for s in sums], [sum(s) / len(s) for s in sums], [max(s) for s in sums]
    pts = lambda vals: [(i + 1, v) for i, v in enumerate(vals)]
    svg = xy_lines([("Monthly average", pts(mean), NAVY, False)], "MW", "Monthly load profile", xticks=[(i + 1, MONTHS[i]) for i in range(12)],
                   area=("Monthly minimum to maximum", mn, mx, BLUE), ymin=0)
    kind = "modeled first-year" if hist.get("modeled") else "historical"
    peak_m = max(range(12), key=lambda i: mx[i])
    return fig(svg, f"Monthly load profile ({kind} demand, {hist['years'][0]}{'-' + str(hist['years'][-1]) if len(hist['years']) > 1 else ''}): average with minimum-to-maximum band (MW).",
               f"Demand is highest in {MONTHS[peak_m]} (up to {fnum(mx[peak_m])} MW); the monthly average ranges from {fnum(min(mean))} to {fnum(max(mean))} MW.")


def fig_season_day(run):
    hist = load_profiles(run).get("hist")
    if not hist:
        return ""
    series = []
    for name, months, color in SEASONS:
        sel = [[] for _ in range(24)]
        for m, h, y, v in [r[:4] for r in hist["rows"]]:
            if m in months:
                sel[h].append(v)
        if all(sel):
            series.append((name, [(h, sum(s) / len(s)) for h, s in enumerate(sel)], color, False))
    if not series:
        return ""
    svg = xy_lines(series, "MW", "Typical day by season", xticks=[(h, f"{h:02d}:00") for h in range(0, 24, 3)], ymin=0, markers=False, xlabel="Hour of day")
    peaks = {s[0]: max(s[1], key=lambda p: p[1]) for s in series}
    top = max(peaks, key=lambda k: peaks[k][1])
    return fig(svg, "Typical daily load shape by season (average hourly MW).",
               f"The daily peak is {fnum(peaks[top][1])} MW around {peaks[top][0]:02d}:00 in {top}; the shape shows when storage and solar can help most.")


def fig_ldc(run):
    prof = load_profiles(run)
    hist, proj = prof.get("hist"), prof.get("proj") or {}
    series = []
    if hist and not hist.get("modeled"):
        series.append((f"Historical {hist['years'][0]}", _percentile_curve([r[3] for r in hist["rows"]]), NAVY, False))
    years = sorted(proj)
    if years:
        series.append((f"Forecast {years[0]}", _percentile_curve(proj[years[0]]), BLUE, False))
        if len(years) > 1:
            series.append((f"Forecast {years[-1]}", _percentile_curve(proj[years[-1]]), RED, False))
    if not series:
        return ""
    svg = xy_lines(series, "MW", "Load duration curve", xticks=[(v, f"{v}%") for v in range(0, 101, 20)], ymin=0, markers=False, xlabel="Share of the year the load is at or above this level")
    last = series[-1]
    peak, base = last[1][0][1], last[1][-1][1]
    return fig(svg, "Load duration curves: hourly load sorted from highest to lowest.",
               f"{last[0]} load ranges from a {fnum(peak)} MW peak down to {fnum(base)} MW; the curve flattens the more constant the demand is.")


def fig_forecast(run, code):
    annual = annual_of(run, code)
    if len(annual) < 2:
        return ""
    cats = [str(a["year"]) for a in annual]
    served = [a.get("served_mwh", a.get("demand_mwh")) for a in annual]
    saved = [a.get("efficiency_saved_mwh") or 0 for a in annual]
    energy = [("Net demand served (GWh)", [(v or 0) / 1e3 for v in served], BLUE)]
    if any(saved):
        energy.append(("Efficiency savings already deducted (GWh)", [v / 1e3 for v in saved], MUTED_BAR))
    peak = [a.get("forecast_peak_mw") for a in annual]
    svg = combo(cats, energy, ("Forecast peak (MW)", peak, RED), "GWh", "MW", "Annual energy and peak forecast", 1)
    first, last = annual[0], annual[-1]
    years = max(last["year"] - first["year"], 1)
    cagr = lambda a, b: 100 * ((b / a) ** (1 / years) - 1) if a and a > 0 and b and b > 0 else None
    e_g, p_g = cagr(first.get("served_mwh", first.get("demand_mwh")), last.get("served_mwh", last.get("demand_mwh"))), cagr(first.get("forecast_peak_mw"), last.get("forecast_peak_mw"))
    growth = (f"Energy grows {fnum(e_g, 2)}% a year and the peak {fnum(p_g, 2)}% a year" if e_g is not None and p_g is not None else "Demand grows over the horizon")
    return fig(svg, "Annual energy demand (columns) and forecast peak demand (line).",
               f"{growth}, from a {fnum(first.get('forecast_peak_mw'))} MW peak in {first['year']} to {fnum(last.get('forecast_peak_mw'))} MW in {last['year']}.")


def fig_solar_cf(run):
    cf = load_profiles(run).get("solar_cf")
    if not cf or any(v is None for v in cf):
        return ""
    cats = MONTHS
    svg = stacked(cats, [("Solar capacity factor (%)", [100 * v for v in cf], AMBER)], "%", "Solar capacity factor by month", 1, totals=True, plot_h=200)
    best = max(range(12), key=lambda i: cf[i])
    return fig(svg, "Average solar capacity factor by month (share of nameplate output, all hours).",
               f"Solar output peaks in {MONTHS[best]} ({fnum(100 * cf[best])}%) and the annual average is {fnum(100 * sum(cf) / 12)}%, which sets how much energy new PV can supply.")


# --------------------------------------------------------------------------- figure builders: scenario results

def scenario_codes(run):
    return list(run["results"])


def fig_capacity(run):
    codes = scenario_codes(run)
    caps = [run["results"][c]["caps"] for c in codes]
    series = [("Solar PV (MW DC)", [c.get("pv_dc_mw") or 0 for c in caps], AMBER), ("Wind (MW)", [c.get("wind_mw") or 0 for c in caps], TEAL),
              ("BESS power (MW)", [c.get("bess_mw") or 0 for c in caps], GREEN)]
    gen_keys = []
    for c in caps:
        for k, v in (c.get("generators_mw") or {}).items():
            if v > .05 and k not in gen_keys:
                gen_keys.append(k)
    palette = [RED, PURPLE, BROWN, GREY, BLUE]
    for i, k in enumerate(gen_keys):
        series.append((f"{R.GEN_NAMES.get(k, k)} (MW)", [(c.get("generators_mw") or {}).get(k, 0) for c in caps], palette[i % len(palette)]))
    if not any(any(v > .05 for v in s[1]) for s in series):
        return ""
    subs = [f"{fnum(c.get('bess_mwh') or 0)} MWh" if (c.get("bess_mw") or 0) > .05 else "" for c in caps]
    svg = stacked(codes, series, "MW", "Installed capacity by scenario", 1, subs=subs if any(subs) else None)
    big = max(codes, key=lambda c: sum(max(v, 0) for s in series for v in [s[1][codes.index(c)]]))
    return fig(svg, "New installed capacity by scenario (MW; battery energy in MWh shown under the scenario ID).",
               f"{big} builds the most new capacity ({fnum(sum(s[1][codes.index(big)] for s in series))} MW in total); scenarios without bars rely on grid supply alone.")


def fig_npc_components(run, best):
    codes = scenario_codes(run)
    series = []
    for key, name, sign in R.NPC_COMPONENTS:
        vals = [sign * currency.mega(run["results"][c]["economics"].get(key) or 0) for c in codes]
        if any(abs(v) > .005 for v in vals):
            series.append((name, vals, NPC_COLORS.get(key, GREY)))
    if not series:
        return ""
    svg = stacked(codes, series, "$M", "Net present cost components by scenario", 1)
    e = run["results"][best]["economics"]
    top = max(R.NPC_COMPONENTS, key=lambda k: k[2] * (e.get(k[0]) or 0))
    share = 100 * top[2] * (e.get(top[0]) or 0) / e["npc"] if e["npc"] else 0
    return fig(svg, "Net present cost by component and scenario ($M; column labels show the NPC).",
               f"For {best}, {top[1].lower()} is the largest cost ({fnum(share, 0)}% of its NPC), so that is the lever with the most influence on the result.")


def fig_unserved(run):
    codes = scenario_codes(run)
    vals = [(run["results"][c].get("adequacy") or {}).get("unserved_mwh") or 0 for c in codes]
    if max(vals) < 1e-3:
        return ""
    svg = hbars([(c, v) for c, v in zip(codes, vals)], "MWh", "Unserved energy by scenario", 1, color=RED)
    return fig(svg, "Unserved energy by scenario over the appraisal period (MWh).",
               f"{sum(v > 1e-3 for v in vals)} of {len(codes)} scenarios leave some demand unserved; these are not equivalent in service and are excluded from the cost ranking.")


def fig_energy_by_scenario(run):
    codes = scenario_codes(run)
    totals = {}
    for c in codes:
        for name, vals, color in energy_series(annual_of(run, c)):
            totals.setdefault(name, (color, {}))[1][c] = sum(vals) / 1e3
    order = ["Grid import", "New solar PV", "Wind", "Generators", "Planned renewables", "BESS discharge"]
    series = [(n, [totals[n][1].get(c, 0) for c in codes], totals[n][0]) for n in order if n in totals]
    if not series:
        return ""
    svg = stacked(codes, series, "GWh", "Energy supplied by source and scenario", 0)
    grid = {c: totals.get("Grid import", (0, {}))[1].get(c, 0) for c in codes}
    allv = {c: sum(s[1][i] for s in series) for i, c in enumerate(codes)}
    low = min(codes, key=lambda c: grid[c] / allv[c] if allv[c] else 1)
    return fig(svg, "Energy supplied to the load by source and scenario, summed over the appraisal period (GWh).",
               f"{low} depends least on the grid ({fnum(100 * grid[low] / allv[low], 0)}% of supplied energy); the rest of the energy comes from on-site sources.")


def fig_co2_by_scenario(run):
    codes = scenario_codes(run)
    vals = []
    for c in codes:
        annual = annual_of(run, c)
        vals.append(sum((a.get("net_co2e_after_heat_credit_t", a.get("supply_co2e_t")) or 0) for a in annual) / 1e3 if annual else None)
    if all(v is None for v in vals) or max(v or 0 for v in vals) < 1e-6:
        return ""
    ref = run["reference"] if run["reference"] in codes else None
    svg = hbars([(c, v) for c, v in zip(codes, vals)], "kt CO2e", "CO2e by scenario", 1, color=GREY)
    low = min((c for c, v in zip(codes, vals) if v is not None), key=lambda c: vals[codes.index(c)])
    extra = ""
    if ref and low != ref and vals[codes.index(ref)]:
        extra = f", {fnum(100 * (1 - vals[codes.index(low)] / vals[codes.index(ref)]), 1)}% below the reference"
    return fig(svg, "Net CO2e emissions by scenario over the appraisal period (kt).",
               f"{low} has the lowest emissions ({fnum(vals[codes.index(low)])} kt){extra}; grid electricity is the main emission source in most scenarios.")


# --------------------------------------------------------------------------- figure builders: recommended solution

def fig_renewable_grid(run, code):
    annual = annual_of(run, code)
    if len(annual) < 2:
        return ""
    ren = renewable_fraction(annual)
    grid = [100 * (a.get("grid_mwh") or 0) / a["demand_mwh"] if a.get("demand_mwh") else None for a in annual]
    year = [a["year"] for a in annual]
    series = [("Grid share of energy (%)", list(zip(year, grid)), BLUE, False), ("Renewable share of energy (%)", list(zip(year, ren)), GREEN, False)]
    svg = xy_lines(series, "% of demand", "Renewable share and grid dependence by year", ymin=0, ymax=100)
    return fig(svg, f"Share of annual demand met by the grid and by renewables, {code}.",
               f"Grid dependence moves from {fnum(grid[0], 0)}% to {fnum(grid[-1], 0)}% and the renewable share from {fnum(ren[0], 0)}% to {fnum(ren[-1], 0)}% between {year[0]} and {year[-1]}.")


def grid_limit_for(run, code):
    try:
        import summary_data
        return summary_data.grid_limit(run, run["results"][code])
    except Exception:
        value = run["values"].get("grid_limit")
        return float(value) if value not in (None, "") else None


def fig_peak_grid(run, code):
    annual = annual_of(run, code)
    if len(annual) < 2 or not any(a.get("grid_peak_mw") for a in annual):
        return ""
    year = [a["year"] for a in annual]
    series = [("Peak grid import", [(y, a.get("grid_peak_mw")) for y, a in zip(year, annual)], BLUE, False),
              ("Forecast peak demand", [(y, a.get("forecast_peak_mw")) for y, a in zip(year, annual)], GREY, True)]
    limit = grid_limit_for(run, code)
    svg = xy_lines(series, "MW", "Peak grid import by year", ymin=0, hlines=[(limit, f"Grid limit {fnum(limit)} MW", RED)] if limit else ())
    peak = max(a.get("grid_peak_mw") or 0 for a in annual)
    tail = f" against a {fnum(limit)} MW connection limit" if limit else ""
    return fig(svg, f"Highest hourly grid import each year compared with the forecast peak demand, {code}.",
               f"Peak grid import reaches {fnum(peak)} MW{tail}; the gap to the demand peak is covered by on-site supply.")


def _years_for(run, code):
    years = [a["year"] for a in annual_of(run, code)]
    return sorted({years[0], years[-1]}) if len(years) > 1 else years


def fig_monthly_dispatch(run, code):
    years = _years_for(run, code)
    data = dispatch_summary(run, code, tuple(years))
    out = []
    for year in years:
        d = data.get(year)
        if not d or d["rows"] < 24 * 300:
            continue
        month = d["month"]
        g = lambda k: [(m.get(k, 0) or 0) / 1e3 for m in month]
        wind = g("wind")
        gens = [max(a - b, 0) for a, b in zip(g("gen"), wind)]
        series = [("Grid import", g("grid"), BLUE), ("New solar PV", g("solar"), AMBER), ("Wind", wind, TEAL), ("Generators", gens, RED),
                  ("Planned renewables", g("planned"), GREY), ("BESS discharge", g("discharge"), GREEN)]
        series = [s for s in series if sum(s[1]) > 1e-6]
        if not series:
            continue
        svg = stacked(MONTHS, series, "GWh", f"Monthly energy by source {year}", 1, totals=False)
        grid = sum(series[0][1]) if series[0][0] == "Grid import" else 0
        total = sum(sum(s[1]) for s in series)
        out.append(fig(svg, f"Monthly energy supplied by source in {year} (GWh).",
                       f"The grid supplies {fnum(100 * grid / total, 0)}% of the energy in {year}; monthly bars show how the mix follows the seasonal load and solar."))
    return "".join(out)


def fig_soc(run, code):
    caps = run["results"][code]["caps"]
    if (caps.get("bess_mwh") or 0) <= 1e-6:
        return ""
    years = _years_for(run, code)
    year = years[-1]
    d = dispatch_summary(run, code, tuple(years)).get(year)
    if not d or not any(d["soc"]):
        return ""
    mn = [min(s) for s in d["soc"]]
    mx = [max(s) for s in d["soc"]]
    mean = [sum(s) / len(s) for s in d["soc"]]
    series = [("Average state of charge", [(h, v) for h, v in enumerate(mean)], GREEN, False)]
    svg = xy_lines(series, "MWh", "Battery state of charge by hour of day", xticks=[(h, f"{h:02d}:00") for h in range(0, 24, 3)], ymin=0, area=("Minimum to maximum", mn, mx, GREEN), xlabel="Hour of day")
    hi = max(range(24), key=lambda h: mean[h])
    return fig(svg, f"Battery state of charge by hour of day in {year} ({fnum(caps['bess_mwh'])} MWh installed).",
               f"The battery is on average fullest around {hi:02d}:00 ({fnum(mean[hi])} MWh) and swings between {fnum(min(mn))} and {fnum(max(mx))} MWh over the year.")


def fig_typical_day(run, code):
    years = _years_for(run, code)
    year = years[-1]
    d = dispatch_summary(run, code, tuple(years)).get(year)
    if not d or min(h["n"] for h in d["hour"]) < 300:
        return ""
    mean = lambda k: [h.get(k, 0) / h["n"] for h in d["hour"]]
    wind = mean("wind")
    series = [("Grid import", mean("grid"), BLUE), ("New solar PV", mean("solar"), AMBER), ("Wind", wind, TEAL),
              ("Generators", [max(a - b, 0) for a, b in zip(mean("gen"), wind)], RED), ("Planned renewables", mean("planned"), GREY),
              ("BESS discharge", mean("discharge"), GREEN)]
    series = [s for s in series if sum(s[1]) > 1e-6]
    if not series:
        return ""
    load = mean("load")
    cats = [f"{h:02d}" for h in range(24)]
    svg = stacked(cats, series, "MW", f"Average day dispatch {year}", 1, totals=False, plot_h=230)
    grid, solar = mean("grid"), mean("solar")
    gh, sh = max(range(24), key=lambda h: grid[h]), max(range(24), key=lambda h: solar[h])
    take = f"Average grid import peaks at {gh:02d}:00 ({fnum(grid[gh])} MW)" + (f" while new solar peaks at {sh:02d}:00 ({fnum(solar[sh])} MW)." if solar[sh] > 1e-6 else ".")
    return fig(svg, f"Average daily dispatch by hour in {year} (MW; the average load is {fnum(sum(load) / 24)} MW).", take)


# --------------------------------------------------------------------------- figure builders: economics

def cashflow_curves(run):
    """Cumulative discounted cash flows versus the reference per scenario, net and operating basis (None when unavailable)."""
    if "_econ_eval" not in run:
        import economic_metrics
        try:
            run["_econ_eval"] = economic_metrics.evaluate(list(run["results"].values()), run["values"], run["reference"])
        except (KeyError, ValueError, TypeError, IndexError):
            run["_econ_eval"] = {}
    out = dict(net=[], operating=[])
    for s in run["_econ_eval"].get("scenarios") or []:
        if s.get("status") != "ok" or s.get("is_reference"):
            continue
        for basis in ("net", "operating"):
            curve = (s.get(basis) or {}).get("cumulative_discounted")
            if curve:
                out[basis].append((s["code"], [(i, currency.mega(v)) for i, v in enumerate(curve)]))
    return out


def fig_cashflow(run, basis):
    curves = cashflow_curves(run).get(basis) or []
    if not curves:
        return ""
    palette = [BLUE, AMBER, GREEN, RED, PURPLE, TEAL, BROWN]
    series = [(c, pts, palette[i % len(palette)], False) for i, (c, pts) in enumerate(curves)]
    ref = run["reference"]
    svg = xy_lines(series, "$M", "Cumulative discounted cash flow", xticks=[(i, f"Y{i}") for i in range(len(curves[0][1]))],
                   hlines=[(0, "break-even", GREY)], xlabel=f"Years from start (versus {ref})", decimals=2)
    final = {c: pts[-1][1] for c, pts in curves}
    top = max(final, key=final.get)
    if basis == "net":
        title = f"Cumulative discounted net cash flow versus the reference {ref} ($M; net basis, including the avoided upgrade)."
        take = f"{top} builds the largest cumulative saving ({mm(final[top] * 1e6 / currency.fx())} by the end of the horizon)."
    else:
        title = f"Cumulative discounted operating cash flow versus {ref} ($M; operating basis, savings against the option's own capital cost)."
        crossed = [c for c, pts in curves if pts[-1][1] > 0]
        take = (f"{', '.join(crossed)} recover{'s' if len(crossed) == 1 else ''} the investment within the horizon." if crossed
                else "No option recovers its own investment within the horizon on the operating basis; the curve closest to break-even is " + top + ".")
    return fig(svg, title, take)


def fig_economic_panels(run, best):
    rows = R.economic_rows(run)
    codes = [c for c in run["results"] if c in rows]
    if len(codes) < 2:
        return ""
    ok = lambda c: rows[c]["status"] != "reference"
    npv = [currency.mega(rows[c]["npv"]) if ok(c) and rows[c]["npv"] is not None else None for c in codes]
    lcoe = [currency.scaled(rows[c]["lcoe"]) for c in codes]
    irr = [100 * rows[c]["irr"] if ok(c) and rows[c]["irr"] is not None else None for c in codes]
    pb = [rows[c]["simple_payback_years"] if ok(c) and rows[c]["simple_payback_years"] is not None else None for c in codes]
    specs = [("Incremental NPV ($M)", npv, "", 1), ("Levelized cost ($/MWh)", lcoe, "", 1), ("IRR (%)", irr, "%", 1), ("Simple payback (years)", pb, "", 1)]
    specs = [s for s in specs if any(v is not None for v in s[1]) and not (s[0].startswith("Simple payback") and max(v or 0 for v in s[1]) <= 0)]
    svg = panels(codes, specs, "Financial metrics by scenario", best)
    cheapest = min((c for c in codes if rows[c]["lcoe"] is not None), key=lambda c: rows[c]["lcoe"])
    return fig(svg, "Financial metrics by scenario; n/a = not defined (see the notes below).",
               f"{cheapest} delivers the lowest levelized supply cost (${fnum(currency.scaled(rows[cheapest]['lcoe']))}/MWh); NPV, IRR and payback are measured against the reference case.")


# --------------------------------------------------------------------------- figure builders: sensitivity

def fig_risk_range(run, reference_npc=None):
    from report import sensitivity_for
    sens = sensitivity_for(run["folder"])
    risk = (sens or {}).get("report", {}).get("risk") or {}
    if risk.get("p50") is None or risk.get("p10") is None or risk.get("p90") is None:
        return ""
    lo, hi = (risk.get("minimum"), risk.get("maximum"))
    rows = [("P10 - P90 (bar), P50 (marker)", currency.mega(risk["p10"]), currency.mega(risk["p90"]), currency.mega(risk["p50"]))]
    if lo is not None and hi is not None:
        rows.insert(0, ("Minimum - maximum of all cases", currency.mega(lo), currency.mega(hi), currency.mega(risk["p50"])))
    vlines = [(currency.mega(reference_npc), "reference base NPC")] if reference_npc else []
    svg = ranges(rows, "NPC $M", "NPC risk range", vlines=vlines, decimals=1)
    take = f"The NPC is most likely between {mm(risk['p10'], 1)} and {mm(risk['p90'], 1)}, with a median of {mm(risk['p50'], 1)}."
    if reference_npc:
        take += " The dashed line marks the reference case at its base value."
    return fig(svg, "NPC risk range from the probabilistic sensitivity run ($M).", take)


def fig_sens_cases(run):
    from report import sensitivity_for
    sens = sensitivity_for(run["folder"])
    table = (sens or {}).get("report", {}).get("table") or []
    items = [(str(r.get("label")), currency.mega(r.get("npc") or 0), bool(r.get("mix_changed"))) for r in table if r.get("npc")]
    if len(items) < 3:
        return ""
    base_name = items[0][0]
    svg = hbars_multi([(n, [v]) for n, v, _ in items], [("", MUTED_BAR)], "$M", "NPC for every tested sensitivity case", 1)
    svg = _recolor_rows(svg, items, base_name)
    changed = sum(1 for _, _, c in items if c)
    return fig(svg, "NPC in every sensitivity case ($M): green = base case, amber = the optimal equipment mix changes, grey = same equipment.",
               f"The cheapest equipment mix changes in {changed} of {len(items) - 1} tested cases; the bars show how far each assumption moves total cost.")


def _recolor_rows(svg, items, base_name):
    """Re-colour the bars of hbars output row by row (rows appear in the order of items)."""
    colors = [ACCENT if n == base_name else (AMBER if c else MUTED_BAR) for n, _, c in items]
    parts = svg.split(f'fill="{MUTED_BAR}"')
    if len(parts) != len(colors) + 1:
        return svg
    return "".join(p + (f'fill="{colors[i]}"' if i < len(colors) else "") for i, p in enumerate(parts))


# --------------------------------------------------------------------------- figure builders: reliability

def fig_contingencies(rel):
    cont = (rel or {}).get("contingencies") or []
    if not cont:
        return ""
    names = [c.get("name") or c.get("id") for c in cont]
    specs = [("Downtime (h/yr)", [c.get("downtime_h_yr") for c in cont], "", 2), ("Unserved energy (MWh/yr)", [c.get("eue_mwh_yr") for c in cont], "", 1),
             ("Cost ($M/yr)", [currency.mega(c.get("cost_yr") or 0) for c in cont], "", 2)]
    svg = panels(names, specs, "Reliability by contingency")
    worst = max(cont, key=lambda c: c.get("cost_yr") or 0)
    return fig(svg, "Expected downtime, unserved energy and outage cost for each contingency.",
               f"{worst.get('name')} is the costliest contingency ({mm(worst.get('cost_yr'), 2)} a year, {fnum(worst.get('downtime_h_yr'), 1)} hours of downtime).")


def fig_mitigation(rel):
    measures = (rel or {}).get("measures") or []
    rows = [(m.get("name"), [currency.mega(m.get("cost_pv") or 0), currency.mega(m.get("avoided_cost_pv") or 0)]) for m in measures if m.get("name")]
    if not rows:
        return ""
    svg = hbars_multi(rows, [("Cost of the measure (present value)", RED), ("Avoided outage cost (present value)", GREEN)], "$M", "Mitigation cost versus avoided cost", 2)
    good = [m for m in measures if (m.get("benefit_cost_ratio") or 0) > 1]
    take = (f"{len(good)} of {len(measures)} measures avoid more outage cost than they cost; the best benefit/cost ratio is "
            f"{fnum(max(m.get('benefit_cost_ratio') or 0 for m in measures), 1)}." if good else "No measure avoids more outage cost than it costs over the horizon.")
    return fig(svg, "Cost of each mitigation measure versus the outage cost it avoids ($M, present value).", take)


def fig_eens_trend(rel):
    rows = ((rel or {}).get("summary") or {}).get("by_year") or []
    if len(rows) < 2:
        return ""
    cats = [str(r["year"]) for r in rows]
    svg = combo(cats, [("Expected unserved energy (MWh)", [r.get("eue_mwh") for r in rows], RED)], ("Downtime (h)", [r.get("downtime_h") for r in rows], NAVY),
                "MWh", "hours", "Annual expected unserved energy", 0)
    return fig(svg, "Expected unserved energy (columns) and downtime hours (line) by year under random outages.",
               f"Expected unserved energy moves from {fnum(rows[0].get('eue_mwh'), 0)} MWh in {rows[0]['year']} to {fnum(rows[-1].get('eue_mwh'), 0)} MWh in {rows[-1]['year']} as demand grows.")


def fig_reliability_scenarios(run):
    codes, data = [], []
    for c in run["results"]:
        rel = R.reliability_for(run["folder"], c)
        if rel and rel.get("summary"):
            codes.append(c)
            data.append(rel["summary"])
    if len(codes) < 2:
        return ""
    specs = [("Downtime (h/yr)", [s.get("lole_h_yr") for s in data], "", 2), ("Unserved energy (MWh/yr)", [s.get("eue_mwh_yr") for s in data], "", 1),
             ("Outage cost ($M/yr)", [currency.mega(s.get("cost_yr") or 0) for s in data], "", 2)]
    svg = panels(codes, specs, "Reliability by scenario")
    best = min(codes, key=lambda c: data[codes.index(c)].get("eue_mwh_yr") or 0)
    return fig(svg, "Expected downtime, unserved energy and outage cost by scenario.",
               f"{best} has the lowest expected unserved energy ({fnum(data[codes.index(best)].get('eue_mwh_yr'), 1)} MWh a year); downtime hours and outage cost are shown alongside.")


# --------------------------------------------------------------------------- figure builders: power flow

def fig_violations(run):
    codes, counts, types = [], [], []
    for c, r in run["results"].items():
        tech = R.technical(r)
        if not tech or str(tech.get("status")).upper() == "NOT_RUN":
            continue
        codes.append(c)
        tally = {}
        for v in tech.get("violations") or []:
            key = str(v.get("type") or "other").replace("_", " ")
            tally[key] = tally.get(key, 0) + 1
            if key not in types:
                types.append(key)
        counts.append(tally)
    if not codes or not types:
        return ""
    palette = [RED, AMBER, PURPLE, BLUE, TEAL, BROWN, GREY]
    series = [(t.capitalize(), [c.get(t, 0) for c in counts], palette[i % len(palette)]) for i, t in enumerate(types)]
    svg = stacked(codes, series, "findings", "Power-flow findings by scenario", 0)
    worst = max(codes, key=lambda c: sum(counts[codes.index(c)].values()))
    return fig(svg, "Power-flow screening findings by scenario and type (normal operation and N-1 cases).",
               f"{worst} has the most findings ({sum(counts[codes.index(worst)].values())}); findings are remarks on the option and corrections are not yet in the NPC.")


def fig_voltage_cases(checks):
    cases = [c for c in (checks or {}).get("cases") or [] if c.get("vmin") is not None and c.get("vmax") is not None]
    if not cases:
        return ""
    rows = [(c.get("label"), c["vmin"], c["vmax"], None) for c in cases]
    svg = ranges(rows, "per unit (pu)", "Voltage range by operating case", bands=[(.95, 1.05, GREEN)], vlines=[(.95, "0.95 pu"), (1.05, "1.05 pu")], decimals=3)
    low = min(cases, key=lambda c: c["vmin"])
    return fig(svg, "Lowest to highest bus voltage in each screened operating case (green band = acceptable 0.95-1.05 pu).",
               f"The lowest voltage is {fnum(low['vmin'], 3)} pu in the {str(low.get('label')).lower()} case; "
               + ("all normal operating cases stay inside the acceptable band (N-1 contingencies are covered by the findings chart)." if min(c["vmin"] for c in cases) >= .95 and max(c["vmax"] for c in cases) <= 1.05 else "at least one operating case leaves the acceptable band."))


def fig_branch_loading(checks):
    cases = [c for c in (checks or {}).get("cases") or [] if c.get("branches")]
    if not cases:
        return ""
    case = max(cases, key=lambda c: c.get("max_loading_pct") or 0)
    items = [(b["id"], b.get("loading_pct")) for b in case["branches"] if b.get("loading_pct") is not None]
    if not items:
        return ""
    svg = hbars(sorted(items, key=lambda i: -i[1]), "% of rating", "Branch and transformer loading", 1, color=BLUE, vlines=[(100, "100%")])
    top = max(items, key=lambda i: i[1])
    return fig(svg, f"Loading of each line and transformer in the most heavily loaded case ({case.get('label')}).",
               f"{top[0]} is the most heavily loaded element at {fnum(top[1], 1)}% of its rating" + (" and exceeds it." if top[1] > 100 else "."))
