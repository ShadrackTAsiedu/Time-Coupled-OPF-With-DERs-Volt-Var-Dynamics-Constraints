"""Historical hourly-shape learning and explicit, all-hour load growth."""

from collections import Counter, defaultdict
import csv
from datetime import datetime, timedelta
import io
import math

import numpy as np

METHODS = [
    ("concave", "Decelerating concave quadratic"),
    ("linear", "Linear annual growth"),
    ("compound", "Compound / exponential growth"),
    ("convex", "Accelerating convex quadratic"),
    ("smoothstep", "Smoothstep S-curve"),
]
SHAPES = [
    ("learned", "Learn historical month / weekday / hour means"),
    ("replay", "Replay historical month / day / hour pattern"),
]
FORMULAS = {
    "concave": "P(y)=B+(T-B)*(2u-u^2), u=min(y/H,1)",
    "linear": "P(y)=B+(T-B)*u, u=min(y/H,1)",
    "compound": "P(y)=B*(T/B)^u, u=min(y/H,1)",
    "convex": "P(y)=B+(T-B)*u^2, u=min(y/H,1)",
    "smoothstep": "P(y)=B+(T-B)*(3u^2-2u^3), u=min(y/H,1)",
}
MAX_SHAPE_EXPONENT = 20.0


def planning_dates(start_year, horizon):
    start, end = datetime(start_year, 1, 1), datetime(start_year + horizon, 1, 1)
    return [start + timedelta(hours=h) for h in range(int((end - start).total_seconds() / 3600))]


def forecast_peaks(elapsed, baseline, target, target_years, method):
    """Annual peak (MW) after `elapsed` years: baseline B at 0, target T from `target_years` (H) onward."""
    if not target_years > 0:
        raise ValueError("Years to reach the target peak must be positive.")
    u = np.minimum(np.asarray(elapsed, dtype=float) / target_years, 1)
    if method == "compound":
        if not (baseline > 0 and target > 0):
            raise ValueError("Compound growth needs positive baseline and target peaks.")
        return baseline * (target / baseline)**u
    curve = {"concave": 2 * u - u**2, "linear": u, "convex": u**2,
             "smoothstep": 3 * u**2 - 2 * u**3}
    if method not in curve:
        raise ValueError("Unknown demand forecasting method.")
    return baseline + (target - baseline) * curve[method]


def parse_csv(text):
    """Read canonical MW CSV or the customer's original utility kW interval export."""
    lines = text.lstrip("\ufeff").splitlines()
    header = next((i for i, line in enumerate(lines)
                   if line.startswith("timestamp,") or line.startswith("Date,Time,")), None)
    if header is None:
        raise ValueError("CSV needs timestamp,load_mw (MW) or a utility Date,Time,meter column (kW).")
    reader = csv.DictReader(lines[header:])
    names = reader.fieldnames or []
    utility = names[:2] == ["Date", "Time"]
    allowed = {"timestamp", "load_mw", "load_max_mw", "load_min_mw", "solar_per_mw", "solar_per_mwdc", "heat_mwth"}
    audit_columns = {"gross_load_mw", "gross_load_max_mw", "gross_load_min_mw", "efficiency_reduction_mw",
                     "planned_solar_available_mw", "planned_wind_available_mw", "planned_bess_mw", "planned_bess_mwh"}
    if not utility and (not {"timestamp", "load_mw"} <= set(names) or set(names) - allowed - audit_columns):
        raise ValueError("CSV needs timestamp,load_mw; optional: load_max_mw,load_min_mw,solar_per_mwdc,heat_mwth.")
    rows = []
    for i, row in enumerate(reader, header + 2):
        if not any(row.values()):
            continue
        try:
            if utility:
                date = datetime.strptime(row["Date"] + " " + row["Time"], "%m/%d/%Y %I:%M %p")
                nums = {"load_mw": float(row[names[2]].replace(",", "")) / 1000}
            else:
                date = datetime.fromisoformat(row["timestamp"])
                nums = {key: float(row[key]) for key in names if key != "timestamp"}
                if "gross_load_mw" in nums:
                    if not {"gross_load_max_mw", "gross_load_min_mw"} <= set(nums):
                        raise ValueError("Reimported audit CSV requires gross mean, maximum and minimum columns.")
                    nums["load_mw"] = nums["gross_load_mw"]
                    nums["load_max_mw"] = nums["gross_load_max_mw"]
                    nums["load_min_mw"] = nums["gross_load_min_mw"]
                nums = {key: value for key, value in nums.items() if key in allowed}
                if "solar_per_mw" in nums:
                    if "solar_per_mwdc" in nums:
                        raise ValueError("Supply only one unit solar resource column.")
                    nums["solar_per_mwdc"] = nums.pop("solar_per_mw")
            if date.tzinfo is not None or date.second or date.microsecond:
                raise ValueError("timestamps must be timezone-free and whole minutes")
            if any(not math.isfinite(x) or x < 0 for x in nums.values()):
                raise ValueError("all values must be finite and nonnegative")
            load = nums["load_mw"]
            if not nums.get("load_min_mw", load) <= load <= nums.get("load_max_mw", load):
                raise ValueError("load_min_mw <= load_mw <= load_max_mw is required")
            if nums.get("solar_per_mwdc", 0) > 2:
                raise ValueError("solar_per_mwdc must be in [0,2]; unit output may exceed STC under high irradiance.")
            rows.append((date, nums))
        except (ValueError, KeyError, TypeError, AttributeError) as exc:
            raise ValueError(f"CSV row {i}: {exc}") from exc
    if not rows:
        raise ValueError("CSV contains no demand records.")
    return rows


MIN_HOURS = 24


def hourly_history(rows, allow_partial=False):
    """Average repeated DST timestamps, fill only the single observed DST hour, aggregate.

    With allow_partial any contiguous period of at least 24 hours is accepted (any start hour);
    otherwise every month/day/hour of one year is required."""
    by_time = defaultdict(list)
    keys = set(rows[0][1])
    for date, nums in rows:
        if set(nums) != keys:
            raise ValueError("All uploaded files must use the same numeric columns.")
        by_time[date].append(nums)
    stamps = sorted(by_time)
    step_minutes = 60
    if len(stamps) > 1:
        diffs = Counter(round((b - a).total_seconds() / 60) for a, b in zip(stamps, stamps[1:]))
        step_minutes = diffs.most_common(1)[0][0]
    if not 1 <= step_minutes <= 60 or 60 % step_minutes:
        raise ValueError(f"Load data intervals of {step_minutes} minutes cannot be aggregated into whole hours; "
                         "supply 1, 2, 3, 4, 5, 6, 10, 12, 15, 20, 30 or 60-minute data.")
    width = 60 // step_minutes
    step = timedelta(minutes=step_minutes)
    start, end = stamps[0], stamps[-1]
    if width == 1 and start.minute:
        raise ValueError("Hourly load data must be stamped on the hour.")
    if not allow_partial and (start.hour or start.minute or end.hour != 23 or end.minute != 60 - step_minutes):
        raise ValueError("Historical data must begin at midnight and end at the last interval of a day.")
    if allow_partial and start.minute:
        raise ValueError("Sub-hourly load data must start on the hour so intervals aggregate into whole hours.")
    count = int((end - start) / step) + 1
    expected = [start + i * step for i in range(count)]
    missing = [i for i, d in enumerate(expected) if d not in by_time]
    if missing and (len(missing) > width or
                    any(b != a + 1 for a, b in zip(missing, missing[1:])) or
                    expected[missing[0]].month != 3 or expected[missing[0]].hour != 2):
        raise ValueError("Historical data have gaps other than a single March DST hour; supply complete data.")
    values = np.array([[np.mean([r[k] for r in by_time[d]]) if d in by_time else np.nan
                        for k in sorted(keys)] for d in expected])
    if missing:
        good = np.flatnonzero(~np.isnan(values[:, 0]))
        for k in range(values.shape[1]):
            values[:, k] = np.interp(np.arange(count), good, values[good, k])
    cols = {key: values[:, i] for i, key in enumerate(sorted(keys))}
    if count % width:
        raise ValueError("Historical intervals do not form complete hours.")
    hours = []
    for i in range(0, count, width):
        segment = slice(i, i + width)
        nums = {key: float(col[segment].mean()) for key, col in cols.items()}
        nums["load_max_mw"] = float(cols.get("load_max_mw", cols["load_mw"])[segment].max())
        nums["load_min_mw"] = float(cols.get("load_min_mw", cols["load_mw"])[segment].min())
        hours.append((expected[i], nums))
    present = {(d.month, d.day, d.hour) for d, _ in hours if not (d.month == 2 and d.day == 29)}
    full_year = len(present) == 8760
    if len(hours) < MIN_HOURS:
        raise ValueError(f"Load data must cover at least {MIN_HOURS} consecutive hours; the file has {len(hours)}.")
    if not full_year and not allow_partial:
        raise ValueError("Historical data must cover every month/day/hour of at least one full year (rolling year allowed).")
    if max(r["load_max_mw"] for _, r in hours) <= 0:
        raise ValueError("Historical demand peak must be positive.")
    audit = dict(raw_records=len(rows), hourly_records=len(hours),
                 duplicated_timestamps_averaged=sum(len(v) - 1 for v in by_time.values()),
                 missing_intervals_interpolated=len(missing), interval_minutes=step_minutes,
                 data_start=str(hours[0][0]), data_end=str(hours[-1][0]), data_hours=len(hours),
                 full_year_coverage=full_year, month_day_hour_slots=len(present))
    return hours, audit


def shift_year(rows, target_year):
    """Move one calendar year of hourly rows onto target_year by month/day/hour (Feb 29 repeats Feb 28)."""
    lookup = {(d.month, d.day, d.hour): nums for d, nums in rows if not (d.month == 2 and d.day == 29)}
    result = []
    for date in planning_dates(target_year, 1):
        key = (date.month, 28 if date.month == 2 and date.day == 29 else date.day, date.hour)
        result.append((date, lookup[key]))
    return result


def imported_rows(text, files, mode, start_year, horizon):
    raw = []
    for source in ([text] if text else []) + [f["content"] for f in files]:
        raw.extend(parse_csv(source))
    if mode == "historical":
        return hourly_history(raw, allow_partial=True)
    raw.sort(key=lambda item: item[0])
    if len(raw) < MIN_HOURS:
        raise ValueError(f"Projected CSV must contain at least {MIN_HOURS} hourly records (a full year is 8,760); "
                         f"it has {len(raw)}.")
    if any(b[0] - a[0] != timedelta(hours=1) for a, b in zip(raw, raw[1:])):
        raise ValueError("Projected CSV must be sorted, hourly, with no gaps or duplicates.")
    if any(set(r) != set(raw[0][1]) for _, r in raw):
        raise ValueError("Projected CSV columns must be consistent.")
    if max(r.get("load_max_mw", r["load_mw"]) for _, r in raw) <= 0:
        raise ValueError("Projected load must have a positive peak.")
    first = raw[0][0]
    by_year = defaultdict(list)
    for item in raw:
        by_year[item[0].year].append(item)
    full_years = []
    if first == datetime(first.year, 1, 1):
        for year in sorted(by_year):
            if year == first.year + len(full_years) and len(by_year[year]) == len(planning_dates(year, 1)):
                full_years.append(by_year[year])
    if not full_years:
        # Not a calendar-aligned projection: the caller treats it as a representative period.
        return raw, dict(hourly_records=len(raw), projected_load_used_directly=False, partial_projection=True,
                         data_start=str(raw[0][0]), data_end=str(raw[-1][0]), data_hours=len(raw))
    used = full_years[:horizon]
    notes = []
    if first.year != start_year:
        notes.append(f"Projected file starts in {first.year}; shifted onto the {start_year} planning calendar by month/day/hour.")
    if len(full_years) > horizon:
        notes.append(f"Projected file has {len(full_years)} full years; only the first {horizon} are used.")
    if sum(len(y) for y in full_years) < len(raw) and len(full_years) < horizon:
        notes.append("Trailing partial year in the projected file was ignored.")
    rows = [item for year_rows, yi in zip(used, range(len(used))) for item in shift_year(year_rows, start_year + yi)]
    for yi in range(len(used), horizon):
        rows.extend(shift_year(used[-1], start_year + yi))
    if len(used) < horizon:
        notes.append(f"Projected file covers {len(used)} year(s) but the horizon is {horizon}; the last projected year "
                     f"is repeated for years {len(used) + 1}-{horizon} (no further growth).")
    return rows, dict(hourly_records=len(rows), projected_load_used_directly=True, notes=notes,
                      data_start=str(raw[0][0]), data_end=str(raw[-1][0]), data_hours=len(raw))


def learn_shape(history, dates, mode):
    """Calendar template per planning hour. Missing calendar keys fall back, in order, to
    weekday/hour, hour-of-day and the overall mean, so partial histories still produce a profile.

    "learned" averages by month/weekday/hour, which flattens the extremes: its peak is below the observed
    peak, so rescaling it to the observed peak would inflate energy (load factor). The load channels are
    therefore re-expanded by the monotone map x -> c*x^p, with c and p chosen so the template peak equals
    the observed peak and the template energy equals the observed energy (the load factor is preserved)."""
    def keys(date, planning):
        if mode == "learned":
            calendar = ((date.month, date.weekday(), date.hour),)
        elif planning and date.month == 2 and date.day == 29:
            calendar = ((2, 29, date.hour), (2, 28, date.hour))
        else:
            calendar = ((date.month, date.day, date.hour),)
        return calendar + (("wd", date.weekday(), date.hour), ("h", date.hour))
    groups = defaultdict(list)
    for date, nums in history:
        for key in keys(date, False):
            groups[key].append(nums)
        groups["all"].append(nums)
    templates = {key: {k: float(np.mean([r[k] for r in rows])) for k in rows[0]}
                 for key, rows in groups.items()}
    hist_peak = max(r["load_max_mw"] for _, r in history)
    hist_mean = float(np.mean([r["load_mw"] for _, r in history]))
    audit = {}
    if mode == "learned":
        on_history = [templates[keys(d, False)[0]] for d, _ in history]
        mean_h = np.array([t["load_mw"] for t in on_history])
        max_h = np.array([t["load_max_mw"] for t in on_history])
        if mean_h.max() > 0 and max_h.max() < hist_peak * (1 - 1e-6):
            ref = mean_h.max()
            z = mean_h / ref

            def calibrated(p):
                c = hist_peak / np.max(max_h * z**(p - 1))
                return c, float(np.mean(mean_h * c * z**(p - 1)))
            lo, hi = 1.0, MAX_SHAPE_EXPONENT
            if calibrated(lo)[1] <= hist_mean:
                p = lo
            elif calibrated(hi)[1] > hist_mean:
                p = hi
            else:
                for _ in range(80):
                    p = (lo + hi) / 2
                    lo, hi = (p, hi) if calibrated(p)[1] > hist_mean else (lo, p)
                p = (lo + hi) / 2
            c = calibrated(p)[0]
            audit.update(shape_exponent=float(p), historical_load_factor=hist_mean / hist_peak,
                         template_load_factor_before=float(mean_h.mean() / max_h.max()))
            for t in templates.values():
                ratio = c * (t["load_mw"] / ref)**(p - 1)
                for k in ("load_mw", "load_max_mw", "load_min_mw"):
                    t[k] *= ratio
    chosen, fallbacks = [], 0
    for date in dates:
        calendar = keys(date, True)
        for level, key in enumerate(calendar + ("all",)):
            if key in templates:
                break
        fallbacks += level >= len(calendar) - 2
        chosen.append(templates[key])
    exact = sum(1 for key in templates if isinstance(key[0], int))
    return chosen, dict(template_groups=exact, shape_method=mode, fallback_hours=fallbacks,
                        historical_peak_mw=hist_peak, historical_mean_mw=hist_mean,
                        historical_min_mw=min(r["load_min_mw"] for _, r in history), **audit)
