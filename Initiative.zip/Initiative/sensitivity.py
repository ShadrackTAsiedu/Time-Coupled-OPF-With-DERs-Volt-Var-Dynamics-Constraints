"""Sensitivity, uncertainty and risk analysis on top of a saved SOLVE run.

One-at-a-time sweeps (tornado), combined adverse/favourable cases and a first-order NPC risk
estimate. Every case re-optimizes the chosen scenario from the saved request, so the result is a
real re-solve (capacities are free to change), not a linear scaling of the base cost.

Routes (see extensions.py):
    GET  /api/x/sensitivity_catalog           parameter catalogue with suggested ranges
    POST /api/x/sensitivity_start             {run_id, scenario, params:[{id,low,high}], workers}
    GET  /api/x/sensitivity_status?run_id=    progress and, when finished, the report
    POST /api/x/sensitivity_stop              {run_id}

Base consistency. The base case is re-solved from the very same saved request (same inputs, horizon, forecast
mode, appraisal extension and scenario overrides; a scenario carried over from an earlier run is re-solved from that
run's request) and compared with the saved NPC; the report states the difference.

Risk statistics. Each parameter's low/high pair is read as the P10/P90 pair of an independent, approximately
normal driver. The one-at-a-time NPC swings give sd_i = (NPC_high - NPC_low)/(2*1.2816) and the portfolio sd is
sqrt(sum sd_i^2). Reported P90 = NPC_base + 1.2816*sd (P10 mirrored), i.e. P50 is the base case. This ignores
correlation between drivers, asymmetry and non-linearity of the NPC response; the combined adverse/favourable solves
are the cross-check. The discount rate is a valuation choice rather than an uncertain physical driver.
"""

import copy
import hashlib
import json
import math
import os
import subprocess
import sys
import time
import traceback
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from statistics import NormalDist

import extensions
import planning_inputs

ROOT = Path(__file__).resolve().parent
Z90 = NormalDist().inv_cdf(.9)
PROCS = {}
BASE_TOLERANCE_PCT = .5
CACHE_SOURCES = ("optimize_generation_mix.py", "generation_app.py", "sensitivity.py", "scenario_inputs.py",
                 "resource_profiles.py", "planning_inputs.py", "planning_tariffs.py",
                 "demand_forecasting.py", "network_topology.py", "lifecycle_costs.py")

FUEL_KEYS = ("ng_fuel_price", "diesel_fuel_price", "biogas_fuel_price", "biomass_fuel_price",
             "ng_chp_fuel_price", "boiler_fuel_price")
H2_KEYS = ("h2_fuel_price", "h2_chp_fuel_price")
GAS_CAPEX = ("ng_capex", "ng_chp_capex", "diesel_capex", "biogas_capex", "biomass_capex", "h2_capex", "h2_chp_capex")

# kind: values = multiply keys by (1+pct/100); abs = set key; data = array scaling; trailer = availability.
# worse = which end of the range is adverse for cost.
CATALOG = [
    dict(id="fuel_price", label="Fuel price (gas, diesel, biogas, biomass)", kind="values", keys=FUEL_KEYS, unit="% change",
         low=-30, high=30, worse="high", group="Prices",
         note="Gas price swings of +/-30% are typical of 5-year forward curves."),
    dict(id="h2_price", label="Hydrogen price", kind="values", keys=H2_KEYS, unit="% change", low=-40, high=40,
         worse="high", group="Prices", note="Green H2 cost is highly uncertain; +/-40% is a common screening range."),
    dict(id="grid_price", label="Grid energy price", kind="values", keys=("blended_kwh", "summer_peak_kwh",
         "summer_mid_kwh", "summer_off_kwh", "winter_peak_kwh", "winter_mid_kwh", "winter_off_kwh"),
         unit="% change", low=-20, high=20, worse="high", group="Prices",
         note="Higher grid prices raise NPC but make on-site generation more attractive."),
    dict(id="carbon_price", label="Carbon price", kind="abs", keys=("carbon_price",), unit="$/tonne", low=0, high=200,
         worse="high", group="Prices", note="0 = no carbon cost; 200 = aggressive policy."),
    dict(id="capex_pv", label="Solar PV capital cost", kind="values", keys=("pv_capex",), unit="% change", low=-25,
         high=25, worse="high", group="Capital cost", note="PV module and balance-of-system uncertainty."),
    dict(id="capex_bess", label="BESS capital cost", kind="values", keys=("bess_power_capex", "bess_energy_capex"),
         unit="% change", low=-30, high=30, worse="high", group="Capital cost", note="Battery prices move quickly."),
    dict(id="capex_wind", label="Wind capital cost", kind="values", keys=("wind_capex",), unit="% change", low=-20,
         high=20, worse="high", group="Capital cost", note=""),
    dict(id="capex_gen", label="Generator capital cost", kind="values", keys=GAS_CAPEX, unit="% change", low=-20,
         high=30, worse="high", group="Capital cost", note="Turbine/engine lead times have pushed costs up."),
    dict(id="discount", label="Discount rate", kind="abs", keys=("discount",), unit="fraction", low=.04, high=.09,
         worse="low", group="Finance", note="Nominal discount rate; a different value changes the NPC itself."),
    dict(id="load_growth", label="Load growth (final-year demand)", kind="data", unit="% change", low=-10, high=10,
         worse="high", group="Demand", note="Scales demand with a linear ramp: 0% in year 1 reaching the entered "
         "% in the final planning year."),
    dict(id="demand_level", label="Demand level (all years)", kind="data", unit="% change", low=-10, high=10,
         worse="high", group="Demand", note="High/low demand case applied to every hour."),
    dict(id="solar_resource", label="Solar resource (P90 / P10 year)", kind="data", unit="% change", low=-6, high=6,
         worse="low", group="Resource", note="Inter-annual solar variability is about 4-5% (1 sigma), so a P90 year "
         "is roughly -6%."),
    dict(id="wind_resource", label="Wind resource (P90 / P10 year)", kind="data", unit="% change", low=-12, high=12,
         worse="low", group="Resource", note="Wind energy varies about 8-10% (1 sigma) between years."),
    dict(id="trailer_availability", label="Mobile trailer daily availability", kind="trailer", unit="fraction",
         low=.25, high=.55, worse="low", group="Resource", note="Fraction of the trailer fleet available on a given day."),
]
BY_ID = {item["id"]: item for item in CATALOG}
DEFAULT_SELECTION = ["fuel_price", "capex_pv", "capex_bess", "load_growth", "solar_resource", "trailer_availability",
                     "grid_price", "carbon_price"]
# Scenario technologies that make a price/cost parameter relevant; absent ids apply to every scenario.
TECH_SCOPE = {"fuel_price": {"ng", "ng_chp", "diesel", "biogas", "biomass"}, "h2_price": {"h2", "h2_chp"},
              "grid_price": {"grid"}, "capex_pv": {"pv"}, "capex_bess": {"bess"}, "capex_wind": {"wind"},
              "capex_gen": {"ng", "ng_chp", "diesel", "biogas", "biomass", "h2", "h2_chp"}}


def inapplicable(pid, request, technologies):
    """Reason a parameter cannot change this scenario's result, or None."""
    scope = TECH_SCOPE.get(pid)
    if scope and not scope & set(technologies):
        return "The scenario has no " + "/".join(sorted(scope)) + " option."
    if pid == "trailer_availability" and not any(
            row.get("technology") == "Mobile Trailers" for row in request.get("planned_generation", [])):
        return "No mobile trailers are entered in Planned Generation."
    if pid == "wind_resource" and "wind" not in technologies and not any(
            row.get("technology") == "Wind" for row in request.get("planned_generation", [])):
        return "The scenario has no wind."
    return None


def apply_data(spec, years, horizon, load, qmax, qmin, solar, solar_resource, planned_solar_resource, wind, wind_resource):
    """Hook called from generation_app.make_data before planned generation is netted."""
    growth = float(spec.get("load_growth", 0)) / 100
    level = float(spec.get("demand_level", 0)) / 100
    ramp = years / (horizon - 1) if horizon > 1 else 1.0
    factor = (1 + growth * ramp) * (1 + level)
    load, qmax, qmin = load * factor, qmax * factor, qmin * factor
    s = 1 + float(spec.get("solar_resource", 0)) / 100
    w = 1 + float(spec.get("wind_resource", 0)) / 100
    return load, qmax, qmin, solar * s, solar_resource * s, planned_solar_resource * s, wind * w, wind_resource * w


def mutate(request, changes):
    """Return a deep copy of the saved request with the changes applied."""
    out = copy.deepcopy(request)
    values, data_spec = out["values"], {}
    for pid, value in changes.items():
        item = BY_ID[pid]
        if item["kind"] == "values":
            for key in item["keys"]:
                if key in values and isinstance(values[key], (int, float)):
                    values[key] = values[key] * (1 + value / 100)
        elif item["kind"] == "abs":
            for key in item["keys"]:
                values[key] = value
        elif item["kind"] == "data":
            data_spec[pid] = value
        elif item["kind"] == "trailer":
            # capacity_mw, bess_mw and energy_mwh are derived from the availability, so re-derive them.
            out["planned_generation"] = [
                planning_inputs.validate_trailer(dict(row, availability=value)) if row.get("technology") == "Mobile Trailers"
                else row for row in out.get("planned_generation", [])]
    if data_spec:
        out["sensitivity"] = data_spec
    return out


def source_folder(folder, code):
    """Run folder whose request produced the saved result (a carried-over scenario was solved in an earlier run)."""
    folder = Path(folder)
    for _ in range(20):
        saved = json.loads((folder / f"result_{code}.json").read_text(encoding="utf-8"))
        provenance = saved.get("provenance") or {}
        origin = provenance.get("from_run")
        if provenance.get("status") != "carried_over" or not origin:
            break
        nxt = folder.parent / origin
        if not (nxt / f"result_{code}.json").is_file() or not (nxt / "request.json").is_file():
            break
        folder = nxt
    return folder


def solve_case(args):
    """Run in a worker process. Returns a compact record for one case."""
    folder, scenario_id, label, changes = args
    import generation_app as app
    started = time.time()
    try:
        request = mutate(app.validate_request(json.loads((Path(folder) / "request.json").read_text(encoding="utf-8"))),
                         changes)
        cfg = app.settings_for(request["values"])
        cfg["topology"] = request["topology"]
        data, _ = app.make_data(request)
        data = app.resource_profiles.extend_appraisal(data, request["values"])
        scenario = next(s for s in request["scenario_definitions"] if s["id"] == scenario_id)
        scenario_base = cfg
        if scenario.get("overrides"):
            scenario_base = app.settings_for(app.clean_overrides(request["values"], scenario))
            scenario_base["topology"] = request["topology"]
        scenario_cfg, tech = app.scenario_inputs.settings(scenario_base, scenario)
        result = app.model.solve_decomposed(data, scenario_id, scenario["name"], tech,
                                            reference=scenario["reference"], settings=scenario_cfg)
        return dict(label=label, changes=changes, ok=True, seconds=time.time() - started, **summarize(result))
    except Exception as exc:
        traceback.print_exc()
        return dict(label=label, changes=changes, ok=False, error=f"{type(exc).__name__}: {exc}",
                    seconds=time.time() - started)



def summarize(result):
    caps = result["caps"]
    return dict(npc=float(result["economics"]["npc"]), pv_mw=float(caps.get("pv_dc_mw", 0)),
                bess_mw=float(caps.get("bess_mw", 0)), bess_mwh=float(caps.get("bess_mwh", 0)),
                generators={k: float(v) for k, v in (caps.get("generators_mw") or {}).items() if v > 1e-6},
                unserved_mwh=float(result["adequacy"].get("unserved_mwh", 0)))


def build_cases(params):
    cases = []
    for p in params:
        item = BY_ID[p["id"]]
        cases.append((f"{item['label']}: low ({p['low']:g} {item['unit']})", {p["id"]: p["low"]}, p["id"], "low"))
        cases.append((f"{item['label']}: high ({p['high']:g} {item['unit']})", {p["id"]: p["high"]}, p["id"], "high"))
    adverse = {p["id"]: p[BY_ID[p["id"]]["worse"]] for p in params}
    favourable = {p["id"]: p["low" if BY_ID[p["id"]]["worse"] == "high" else "high"] for p in params}
    if len(params) > 1:
        cases.append(("Combined adverse case", adverse, None, "adverse"))
        cases.append(("Combined favourable case", favourable, None, "favourable"))
    return cases


def write_status(folder, state, message, **extra):
    path = folder / "sensitivity" / "status.json"
    path.parent.mkdir(exist_ok=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(dict(state=state, message=message, updated=time.time(), **extra), allow_nan=False),
                    encoding="utf-8")
    os.replace(temp, path)


def mix_text(r):
    parts = [f"PV {r['pv_mw']:,.2f} MW", f"BESS {r['bess_mw']:,.2f} MW / {r['bess_mwh']:,.2f} MWh"]
    parts += [f"{k} {v:,.2f} MW" for k, v in r["generators"].items()]
    return ", ".join(parts)


def mix_differs(a, b):
    """True when the installed capacities differ by more than solver noise (0.05 MW or 2 % of the larger value)."""
    def sizes(r):
        return {"pv": r["pv_mw"], "bess_mw": r["bess_mw"], "bess_mwh": r["bess_mwh"],
                **{f"gen_{k}": v for k, v in r["generators"].items()}}
    left, right = sizes(a), sizes(b)
    return any(abs(left.get(k, 0) - right.get(k, 0)) > max(.05, .02 * max(left.get(k, 0), right.get(k, 0)))
               for k in set(left) | set(right))


def report(base, records, params, scenario, saved_npc=None):
    rows, swings = [], []
    ok = {r["label"]: r for r in records if r.get("ok")}
    for p in params:
        item = BY_ID[p["id"]]
        lo = next((r for r in records if r.get("ok") and r["changes"] == {p["id"]: p["low"]}), None)
        hi = next((r for r in records if r.get("ok") and r["changes"] == {p["id"]: p["high"]}), None)
        if not lo or not hi:
            continue
        swings.append(dict(id=p["id"], label=item["label"], unit=item["unit"], low=p["low"], high=p["high"],
                           npc_low=lo["npc"], npc_high=hi["npc"],
                           delta_low=lo["npc"] - base["npc"], delta_high=hi["npc"] - base["npc"],
                           swing=abs(hi["npc"] - lo["npc"]),
                           mix_changes=mix_differs(lo, base) or mix_differs(hi, base)))
    swings.sort(key=lambda s: -s["swing"])
    for r in [dict(label="Base case", changes={}, **base)] + [r for r in records if r.get("ok")]:
        rows.append(dict(label=r["label"], npc=r["npc"], delta_pct=100 * (r["npc"] / base["npc"] - 1) if base["npc"] else 0.0,
                         mix=mix_text(r), unserved_mwh=r["unserved_mwh"],
                         mix_changed=mix_differs(r, base), pv_mw=r["pv_mw"], bess_mw=r["bess_mw"],
                         bess_mwh=r["bess_mwh"], generators=r["generators"]))
    sd = math.sqrt(sum((s["swing"] / (2 * Z90)) ** 2 for s in swings))
    npcs = [base["npc"]] + [r["npc"] for r in ok.values()]
    risk = dict(p50=base["npc"], p10=base["npc"] - Z90 * sd, p90=base["npc"] + Z90 * sd, sd=sd,
                minimum=min(npcs), maximum=max(npcs),
                adverse=ok.get("Combined adverse case", {}).get("npc"),
                favourable=ok.get("Combined favourable case", {}).get("npc"))
    check = None
    if saved_npc:
        diff = 100 * (base["npc"] / saved_npc - 1)
        check = dict(saved_npc=saved_npc, resolved_npc=base["npc"], difference_pct=diff,
                     consistent=abs(diff) <= BASE_TOLERANCE_PCT)
    return dict(scenario=scenario, base=base, swings=swings, table=rows, risk=risk, base_check=check,
                failed=[dict(label=r["label"], error=r["error"]) for r in records if not r.get("ok")],
                method=__doc__.split("Risk statistics.")[1].strip().replace("\n", " "))


def environment_hash():
    digest = hashlib.sha256()
    for name in CACHE_SOURCES:
        path = ROOT / name
        if path.exists():
            digest.update(path.read_bytes())
    return digest.hexdigest()


def case_key(source, scenario_id, changes, env):
    return hashlib.sha256(json.dumps([source, scenario_id, sorted(changes.items()), env]).encode()).hexdigest()


def runner(folder, scenario_id, params, workers):
    folder = Path(folder)
    try:
        cfg = json.loads((folder / "sensitivity" / "job.json").read_text(encoding="utf-8"))
        saved = summarize(json.loads((folder / f"result_{scenario_id}.json").read_text(encoding="utf-8")))
        source = source_folder(folder, scenario_id)
        request_hash = hashlib.sha256((source / "request.json").read_bytes()).hexdigest()
        env = environment_hash()
        cache_file = folder / "sensitivity" / "cache.json"
        try:
            cache = json.loads(cache_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            cache = {}
        cases = [("Base case", {}, None, "base")] + build_cases(params)
        total = len(cases)
        keys = [case_key(request_hash, scenario_id, changes, env) for _, changes, *_ in cases]
        records = {}
        for (label, changes, *_), key in zip(cases, keys):
            if key in cache:
                records[key] = dict(cache[key], label=label, changes=changes)
        started, reused = time.time(), len(records)
        write_status(folder, "running", f"Solving {total - reused} of {total} cases ({reused} reused from cache)...",
                     total=total, done=reused)
        with ProcessPoolExecutor(max_workers=workers) as pool:
            futures = {key: pool.submit(solve_case, (str(source), scenario_id, label, changes))
                       for (label, changes, *_), key in zip(cases, keys) if key not in records}
            for key, future in futures.items():
                record = future.result()
                records[key] = record
                if record.get("ok"):
                    cache[key] = {k: v for k, v in record.items() if k not in ("label", "changes")}
                    atomic = cache_file.with_suffix(".tmp")
                    atomic.write_text(json.dumps(cache, allow_nan=False), encoding="utf-8")
                    os.replace(atomic, cache_file)
                done = len(records)
                remaining = total - done
                elapsed = time.time() - started
                eta = f" About {math.ceil(elapsed / max(done - reused, 1) * remaining / max(workers, 1) / 60)} min left." if remaining else ""
                write_status(folder, "running", f"Solved {done} of {total} cases.{eta}", total=total, done=done)
        ordered = [records[key] for key in keys]
        base_record = ordered[0]
        if not base_record.get("ok"):
            raise RuntimeError(f"The base case could not be re-solved: {base_record.get('error')}")
        base = {k: base_record[k] for k in saved}
        final = report(base, ordered[1:], params, cfg["scenario_name"], saved["npc"])
        final["cases_reused_from_cache"] = reused
        (folder / "sensitivity" / "report.json").write_text(json.dumps(final, allow_nan=False), encoding="utf-8")
        write_status(folder, "complete", f"Completed {total} cases.", total=total, done=total)
    except Exception as exc:
        traceback.print_exc()
        write_status(folder, "failed", f"{type(exc).__name__}: {exc}")


def number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} must be a number.")
    return float(value)


def start(payload):
    folder = extensions.run_folder(payload.get("run_id"))
    status = json.loads((folder / "status.json").read_text(encoding="utf-8"))
    results = (status.get("summary") or {}).get("results") or []
    if status.get("state") != "complete" or not results:
        raise ValueError("Complete a SOLVE with validated scenarios before running a sensitivity analysis.")
    scenario_id = payload.get("scenario")
    names = {r["code"]: r["name"] for r in results}
    if scenario_id not in names or not (folder / f"result_{scenario_id}.json").is_file():
        raise ValueError("Choose a solved scenario.")
    params = []
    source = source_folder(folder, scenario_id)
    request = json.loads((source / "request.json").read_text(encoding="utf-8"))
    technologies = next((s["technologies"] for s in request.get("scenario_definitions", []) if s["id"] == scenario_id), [])
    for p in payload.get("params") or []:
        if p.get("id") not in BY_ID:
            raise ValueError("Unknown sensitivity parameter.")
        item = BY_ID[p["id"]]
        low, high = number(p.get("low"), "Low value"), number(p.get("high"), "High value")
        if low == high:
            raise ValueError(f"{item['label']}: low and high values must differ.")
        reason = inapplicable(item["id"], request, technologies)
        if reason:
            raise ValueError(f"{item['label']} cannot change this scenario. {reason}")
        if item["id"] == "trailer_availability" and not (0 <= low <= 1 and 0 <= high <= 1):
            raise ValueError("Trailer availability must be between 0 and 1.")
        if item["id"] == "discount" and not (0 <= low < 1 and 0 <= high < 1):
            raise ValueError("Discount rate must be a fraction from 0 to below 1 (0.06 = 6 %).")
        if item["id"] == "carbon_price" and (low < 0 or high < 0):
            raise ValueError("Carbon price cannot be negative.")
        if item["unit"] == "% change" and (low <= -95 or high <= -95 or abs(low) > 500 or abs(high) > 500):
            raise ValueError(f"{item['label']}: % changes must be between -95 and 500.")
        params.append(dict(id=p["id"], low=low, high=high))
    if not params or len({p["id"] for p in params}) != len(params):
        raise ValueError("Select at least one parameter, each once.")
    workers = int(max(1, min(4, number(payload.get("workers", 2), "Workers"))))
    current = PROCS.get(folder.name)
    if current and current.poll() is None:
        raise ValueError("A sensitivity analysis is already running for this solve.")
    job = folder / "sensitivity"
    job.mkdir(exist_ok=True)
    (job / "job.json").write_text(json.dumps(dict(scenario=scenario_id, scenario_name=names[scenario_id],
                                                   params=params, workers=workers)), encoding="utf-8")
    (job / "report.json").unlink(missing_ok=True)
    write_status(folder, "running", "Starting...", total=len(build_cases(params)) + 1, done=0)
    flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    with (job / "worker.log").open("w", encoding="utf-8") as log:
        PROCS[folder.name] = subprocess.Popen(
            [sys.executable, str(Path(__file__).resolve()), str(folder)], cwd=ROOT, stdout=log, stderr=log,
            creationflags=flags)
    return dict(id=folder.name, cases=len(build_cases(params)) + 1)


def status(query):
    folder = extensions.run_folder((query.get("run_id") or [""])[0])
    path = folder / "sensitivity" / "status.json"
    if not path.is_file():
        return dict(state="none")
    saved = json.loads(path.read_text(encoding="utf-8"))
    proc = PROCS.get(folder.name)
    if saved["state"] == "running" and proc is not None and proc.poll() is not None:
        saved = json.loads(path.read_text(encoding="utf-8"))  # the worker may have finished since the first read
    if saved["state"] == "running" and proc is not None and proc.poll() is not None:
        saved.update(state="failed", message="The sensitivity worker stopped unexpectedly; see sensitivity\\worker.log.")
    elif saved["state"] == "running" and proc is None and time.time() - saved.get("updated", 0) > 3600:
        saved.update(state="failed", message="Orphaned by an earlier server session.")
    if saved["state"] == "complete":
        saved["report"] = json.loads((folder / "sensitivity" / "report.json").read_text(encoding="utf-8"))
    return saved


def stop(payload):
    folder = extensions.run_folder(payload.get("run_id"))
    proc = PROCS.get(folder.name)
    if proc is not None and proc.poll() is None:
        subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True)
    write_status(folder, "cancelled", "Sensitivity analysis stopped by user.")
    return dict(state="cancelled")


def catalog(query):
    """Parameter catalogue; with run_id and scenario each parameter is flagged when it cannot affect that scenario."""
    parameters = [dict(item) for item in CATALOG]
    run_id, scenario_id = (query.get("run_id") or [""])[0], (query.get("scenario") or [""])[0]
    if run_id and scenario_id:
        try:
            folder = extensions.run_folder(run_id)
            request = json.loads((source_folder(folder, scenario_id) / "request.json").read_text(encoding="utf-8"))
            technologies = next(s["technologies"] for s in request["scenario_definitions"] if s["id"] == scenario_id)
            for item in parameters:
                item["unavailable"] = inapplicable(item["id"], request, technologies)
        except (OSError, ValueError, KeyError, StopIteration):
            pass
    unavailable = {item["id"] for item in parameters if item.get("unavailable")}
    return dict(parameters=parameters, defaults=[i for i in DEFAULT_SELECTION if i not in unavailable],
                seconds_per_case=90)


extensions.POST["sensitivity_start"] = start
extensions.POST["sensitivity_stop"] = stop
extensions.GET["sensitivity_status"] = status
extensions.GET["sensitivity_catalog"] = catalog

if __name__ == "__main__":
    job = json.loads((Path(sys.argv[1]) / "sensitivity" / "job.json").read_text(encoding="utf-8"))
    runner(sys.argv[1], job["scenario"], job["params"], job["workers"])
