import json
import shutil
import socket
import subprocess
import sys
import time
import unittest
from pathlib import Path
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
SOURCE = ROOT / "Application Runs" / "7791be18470745f8af5ef34fa3d208f8"
COPY, RESOLVE = "c0de1111aaaa2222bbbb3333cccc4444", "c0de5555aaaa6666bbbb7777cccc8888"


@unittest.skipUnless(SOURCE.is_dir(), "the reference run is not available")
class WorkflowBrowserTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import workflow
        for name in (COPY, RESOLVE):
            target = ROOT / "Application Runs" / name
            if target.exists():
                shutil.rmtree(target)
            shutil.copytree(SOURCE, target)
        # The copy is re-checked so workflow.json holds the economic ranking with technical remarks.
        workflow.run_check(COPY)
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            cls.port = probe.getsockname()[1]
        cls.server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(cls.port)],
                                      cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        cls.base = f"http://127.0.0.1:{cls.port}"
        for _ in range(150):
            try:
                urlopen(cls.base + "/api/defaults", timeout=.5).close()
                break
            except OSError:
                time.sleep(.1)

    @classmethod
    def tearDownClass(cls):
        cls.server.terminate()
        cls.server.wait(10)
        for name in (COPY, RESOLVE):
            shutil.rmtree(ROOT / "Application Runs" / name, ignore_errors=True)

    def open(self, playwright):
        browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
        page = browser.new_context(viewport={"width": 1700, "height": 1100}).new_page()
        self.errors = []
        page.on("pageerror", lambda exc: self.errors.append(str(exc)))
        page.goto(f"{self.base}/?run={COPY}")
        page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
        page.wait_for_selector("#workflow-panel table", state="attached", timeout=60000)
        page.evaluate("() => switchView('solve')")
        return browser, page

    def test_recommendation_buttons_and_round_trip(self):
        with sync_playwright() as playwright:
            browser, page = self.open(playwright)
            try:
                banner = page.locator("#wf-noncompliant")
                # Automatic compensation is re-screened now, so the recommendation clears FAIL; only the optional warning remains.
                self.assertIn("Lowest-cost option passes the technical check", banner.inner_text())
                self.assertIn("Applying the corrections is optional.", banner.inner_text())
                best = page.locator("#workflow-panel tr.best-row")
                self.assertEqual(best.count(), 1)
                self.assertIn("NG", best.inner_text())
                headers = page.locator("#workflow-panel table").first.locator("th").all_inner_texts()
                self.assertIn("Corrections identified", headers)
                self.assertIn("Still required", headers)
                self.assertIn("Applied", headers)
                self.assertIn("Rank (economic)", headers)
                self.assertTrue(page.locator("#wf-apply-all").is_visible())
                self.assertTrue(page.locator("#wf-review-pf").is_visible())
                self.assertIn("NOT part of the optimization", page.locator("#wf-what-is-this").text_content())

                # (b) review in the Power Flow page, then leave through "Save and re-solve all scenarios".
                jobs = []

                def fake_job(route):
                    if route.request.method == "POST":
                        jobs.append(json.loads(route.request.post_data))
                        route.fulfill(status=200, content_type="application/json", body=json.dumps({"id": RESOLVE}))
                    else:
                        route.continue_()
                page.route("**/api/jobs", fake_job)
                page.route(f"**/api/jobs/{RESOLVE}", lambda route: route.fulfill(
                    status=200, content_type="application/json", body=json.dumps({"id": RESOLVE, "state": "running", "files": []})))
                page.locator("#wf-review-pf").click()
                page.wait_for_function("() => activeView === 'powerflow'")
                page.wait_for_selector("#pfp-save-resolve", timeout=60000)
                page.locator("#pfp-save-resolve").click()
                page.wait_for_function("() => activeView === 'solve'", timeout=60000)
                self.assertEqual(len(jobs), 1)
                info = jobs[0]["workflow"]
                self.assertEqual((info["base_run"], info["mode"]), (COPY, "powerflow"))
                self.assertEqual(len(jobs[0]["scenarios"]), 6)

                # (a) apply corrections to all scenarios: the request carries the applied costs, nothing is solved for real.
                page.evaluate("() => { clearTimeout(polling); }")
                page.goto(f"{self.base}/?run={COPY}")
                page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
                page.wait_for_selector("#workflow-panel table", state="attached", timeout=60000)
                page.evaluate("() => switchView('solve')")
                page.wait_for_selector("#wf-apply-all")
                jobs.clear()
                page.locator("#wf-apply-all").click()
                page.wait_for_function("() => document.getElementById('wf-resolve-status') && !document.getElementById('wf-resolve-status').hidden", timeout=30000)
                page.wait_for_function("() => document.getElementById('wf-resolve-status').textContent.includes('Applying corrections and re-solving')", timeout=10000)
                self.assertIn("Applying corrections and re-solving", page.locator("#wf-resolve-status").inner_text())
                self.assertEqual(len(jobs), 1)
                info = jobs[0]["workflow"]
                self.assertEqual((info["base_run"], info["iteration"], info["mode"]), (COPY, 1, "apply"))
                self.assertGreater(sum(i["cost_usd"] for c in info["applied_costs"].values() for i in c["items"]), 0)
                self.assertEqual(len(jobs[0]["scenarios"]), 6)
                self.assertEqual(self.errors, [])
            finally:
                browser.close()

    def test_iteration_history_and_comparison_use_readable_run_names(self):
        wf_doc = dict(iteration=dict(base_run="a" * 32, iteration=1, base_label="Run 0 - Initial solve (18 Oct 14:02)",
                                     model_changes=["application model code"]),
                      iterations=[dict(iteration=0, run_id="a" * 32, label="Run 0 - Initial solve (18 Oct 14:02)", code="NG", status="FAIL", violations=60, npc=1e8, total_npc=1e8, applied_usd=0, indicative_usd=1e6),
                                  dict(iteration=1, run_id="b" * 32, label="Run 1 - Corrections applied (18 Oct 14:30)", code="P1", status="WARN", violations=1, npc=9e7, total_npc=9.1e7, applied_usd=1e5, indicative_usd=0)],
                      comparison=[dict(code="P1", name="P1", changes={}, npc_before=1e8, npc_after=9e7, npc_delta=-1e7, model_effect=-1e7, corrections_effect=1e5,
                                       total_before=1e8, total_after=9.1e7, status_before="FAIL", status_after="WARN")])

        def inject(route):
            response = route.fetch()
            data = response.json()
            data.update(wf_doc)
            route.fulfill(response=response, body=json.dumps(data))
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
            try:
                page = browser.new_context(viewport={"width": 1700, "height": 1100}).new_page()
                page.route("**/api/x/workflow?*", inject)
                page.goto(f"{self.base}/?run={COPY}")
                page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
                page.wait_for_selector("#wf-history", state="attached", timeout=60000)
                page.evaluate("() => switchView('solve')")
                history = page.locator("#wf-history").inner_text()
                self.assertIn("Run 1 - Corrections applied", history)
                self.assertNotIn("bbbbbbbb", history)
                self.assertIn("b" * 32, page.locator("#wf-history td").nth(7).get_attribute("title"))
                heading = page.locator("#workflow-panel h4", has_text="Before / after comparison").inner_text()
                self.assertIn("Run 0 - Initial solve", heading)
                self.assertNotIn("aaaaaaaa", heading)
                self.assertIn("Inputs/model changed", page.locator(".wf-model-changed").inner_text())
                self.assertIn("Corrections cost effect", page.locator("#workflow-panel").inner_text())
            finally:
                browser.close()

    def test_grid_only_reference_scenario_can_be_excluded_and_restored(self):
        with sync_playwright() as playwright:
            browser, page = self.open(playwright)
            try:
                ids = lambda: page.evaluate("() => readScenarioRows().map(s => s.id)")
                self.assertEqual(ids()[0], "R0")
                self.assertTrue(page.locator("#include-reference").is_checked())
                page.locator("#include-reference").evaluate("e => e.click()")
                self.assertNotIn("R0", ids())
                self.assertEqual(page.locator("#scenario-R0").count(), 0)
                self.assertEqual(page.locator("#financial-reference").input_value(), "")
                request = page.evaluate("() => request(false)")
                self.assertNotIn("R0", request["scenarios"])
                self.assertIsNone(request["comparison_reference"])
                page.locator("#include-reference").evaluate("e => e.click()")
                self.assertEqual(ids()[0], "R0")
                self.assertEqual(page.locator("#scenario-R0").count(), 1)
                # the card's own button removes it too and the checkbox follows
                page.locator("#scenario-rows button", has_text="Remove reference scenario").evaluate("e => e.click()")
                self.assertFalse(page.locator("#include-reference").is_checked())
            finally:
                browser.close()

    def test_check_toggle_off_hides_remarks_and_buttons(self):
        def strip(route):
            response = route.fetch()
            data = response.json()
            data["recommended"]["checked"] = False
            data["recommended"]["banner"] = ""
            for e in data["scenarios"]:
                e["technical_status"] = "NOT_RUN"
            route.fulfill(response=response, body=json.dumps(data))
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
            try:
                page = browser.new_context(viewport={"width": 1700, "height": 1100}).new_page()
                page.route("**/api/x/workflow?*", strip)
                page.goto(f"{self.base}/?run={COPY}")
                page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
                page.wait_for_selector("#workflow-panel table", state="attached", timeout=60000)
                self.assertEqual(page.locator("#wf-apply-all").count(), 0)
                self.assertEqual(page.locator("#wf-review-pf").count(), 0)
                self.assertEqual(page.locator("#wf-noncompliant").count(), 0)
                self.assertNotIn("Technical status", page.locator("#workflow-panel table").first.locator("th").all_inner_texts())
            finally:
                browser.close()


if __name__ == "__main__":
    unittest.main()
