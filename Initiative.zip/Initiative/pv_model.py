"""Irradiance-to-PV conversion: plane-of-array irradiance, cell temperature, losses, inverter limit.

The canonical solar resource is weather (irradiance W/m2, air temperature, wind speed). Per-unit PV output is
computed here for the stated rating basis:

* unit_dc: MW of DC output per MWdc of modules (STC = 1 kW/m2, 25 C cell) before system losses.
* unit_ac: MW of AC output per MWac of inverter capacity = min(DC/AC ratio * unit_dc * retained * degradation, 1).
"""

import math

import numpy as np

import datasources

DEFAULTS = dict(pv_tilt=30.0, pv_azimuth=180.0, pv_temp_coefficient=-0.35, pv_noct=45.0,
                pv_temp_model="faiman", pv_dc_ac_ratio=1.0, pv_latitude=34.0522, pv_longitude=-118.2437,
                pv_utc_offset=-8.0)
FAIMAN_U0, FAIMAN_U1 = 25.0, 6.84
DEFAULT_WIND_MS = 1.0
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def parameters(values):
    """Model parameters from request values, falling back to industry defaults for older runs."""
    out = {key: values.get(key, default) for key, default in DEFAULTS.items()}
    if out["pv_temp_model"] not in ("faiman", "noct"):
        raise ValueError("PV cell-temperature model must be faiman or noct.")
    if not out["pv_dc_ac_ratio"] > 0:
        raise ValueError("PV DC/AC ratio must be positive.")
    return out


def cell_temperature(poa, temp, wind, model="faiman", noct=45.0):
    """Cell temperature (C). Faiman: T + G/(U0+U1*wind). NOCT: T + (NOCT-20)/800*G, wind-independent."""
    if model == "noct":
        return temp + (noct - 20.0) / 800.0 * poa
    wind = np.where(np.isfinite(wind), wind, DEFAULT_WIND_MS)
    return temp + poa / (FAIMAN_U0 + FAIMAN_U1 * wind)


def unit_dc(poa, temp=None, wind=None, params=None):
    """DC output per MWdc from POA W/m2; without a temperature series no thermal correction is applied."""
    p = parameters(params or {})
    out = np.asarray(poa, dtype=float) / 1000.0
    if temp is not None:
        wind = np.full(len(out), DEFAULT_WIND_MS) if wind is None else wind
        cell = cell_temperature(poa, temp, wind, p["pv_temp_model"], p["pv_noct"])
        out = out * (1 + p["pv_temp_coefficient"] / 100.0 * (cell - 25.0))
    return np.clip(out, 0.0, 2.0)


def unit_ac(resource_dc, retained, degradation_factor=1.0, dc_ac_ratio=1.0):
    """AC output per MWac: losses and degradation act on DC, then the inverter clips at its AC rating."""
    return np.minimum(resource_dc * retained * degradation_factor * dc_ac_ratio, 1.0)


def transpose(dates, ghi, dni, dhi, params):
    """GHI (with DNI/DHI, or Erbs-split GHI) to fixed-tilt plane-of-array W/m2 for model-local standard dates."""
    p = parameters(params)
    local = np.array(dates, dtype="datetime64[s]")
    utc = datasources.local_to_utc_hours(local, p["pv_utc_offset"])
    ghi = np.asarray(ghi, dtype=float)
    if dni is None or dhi is None:
        zenith, _, jd = datasources.solar_position(utc, p["pv_latitude"], p["pv_longitude"])
        i0n = 1367.0 * (1 + 0.033 * np.cos(2 * math.pi * ((jd - 2451544.5) % 365.25) / 365.25))
        dni, dhi = datasources.erbs_split(ghi, np.cos(np.radians(zenith)), i0n)
    poa, _ = datasources.poa_irradiance(utc, p["pv_latitude"], p["pv_longitude"], ghi, dni, dhi,
                                        p["pv_tilt"], p["pv_azimuth"])
    return poa


def summary(dates, resource_dc, retained, dc_ac_ratio=1.0):
    """Capacity factor and specific yield of the first full model year, for the user to inspect the conversion."""
    years = np.array([d.year for d in dates])
    mask = years == years[0]
    first = [d for d, m in zip(dates, mask) if m]
    ac = unit_ac(np.asarray(resource_dc)[mask], retained, 1.0, dc_ac_ratio)
    months = np.array([d.month for d in first])
    hours = np.array([d.hour for d in first])
    hours_in_year = len(first)
    return dict(
        annual_capacity_factor_ac=round(float(ac.mean()), 4),
        annual_yield_kwh_per_kwdc=round(float((ac / dc_ac_ratio).mean() * 8760.0), 1),
        clipped_energy_fraction=round(float(1 - ac.sum() / max(np.minimum(
            np.asarray(resource_dc)[mask] * retained * dc_ac_ratio, 99.0).sum(), 1e-9)), 4),
        monthly_capacity_factor=[round(float(ac[months == m].mean()) if (months == m).any() else 0.0, 4)
                                 for m in range(1, 13)],
        diurnal_capacity_factor=[round(float(ac[hours == h].mean()) if (hours == h).any() else 0.0, 4)
                                 for h in range(24)],
        hours=hours_in_year, months=MONTHS, retained_fraction=retained, dc_ac_ratio=dc_ac_ratio,
        basis="MW AC: output per MW of inverter capacity; MW DC = MW AC x DC/AC ratio")
