"""Shared end-to-end harness: a throw-away copy of the application served on a free port.

The copy excludes 'Application Runs' so no user data is read or written.
"""

import json
import math
import os
import shutil
import socket
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
SCRATCH = ROOT / f"_e2e_scratch_{os.getpid()}"
COPY_DIRS = ("generation_ui", "Mobile Trailer Sources", "Solar Profile Inputs", "Load Profile Inputs", "Data Cache")


def make_copy():
    target = SCRATCH / "proj"
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    for item in list(ROOT.glob("*.py")) + list(ROOT.glob("*.cmd")):
        shutil.copy2(item, target / item.name)
    for name in COPY_DIRS:
        if (ROOT / name).is_dir():
            shutil.copytree(ROOT / name, target / name)
    return target


class Server:
    def __init__(self):
        self.folder = make_copy()
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            self.port = probe.getsockname()[1]
        self.proc = subprocess.Popen([sys.executable, str(self.folder / "generation_app.py"), "--port", str(self.port)],
                                     cwd=self.folder, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.base = f"http://127.0.0.1:{self.port}"
        for _ in range(200):
            try:
                urlopen(self.base + "/api/defaults", timeout=.5).close()
                return
            except OSError:
                time.sleep(.1)
        raise RuntimeError("server did not start")

    def restart(self):
        """Stop and relaunch the server on the same project copy (run persistence check)."""
        self.proc.terminate()
        self.proc.wait(10)
        self.proc = subprocess.Popen([sys.executable, str(self.folder / "generation_app.py"), "--port", str(self.port)],
                                     cwd=self.folder, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(200):
            try:
                urlopen(self.base + "/api/defaults", timeout=.5).close()
                return
            except OSError:
                time.sleep(.1)
        raise RuntimeError("server did not restart")

    def close(self):
        self.proc.terminate()
        try:
            self.proc.wait(10)
        except subprocess.TimeoutExpired:
            self.proc.kill()
        shutil.rmtree(SCRATCH, ignore_errors=True)

    def get(self, path):
        with urlopen(self.base + path, timeout=60) as r:
            return json.loads(r.read())

    def post(self, path, payload):
        request = Request(self.base + path, json.dumps(payload).encode("utf-8"), {"Content-Type": "application/json"})
        try:
            with urlopen(request, timeout=120) as r:
                return r.status, json.loads(r.read())
        except HTTPError as exc:
            return exc.code, json.loads(exc.read())

    def solve(self, payload, timeout=240):
        status, body = self.post("/api/jobs", payload)
        if status != 202:
            return None, body
        job = body["id"]
        end = time.time() + timeout
        while time.time() < end:
            saved = self.get(f"/api/jobs/{job}")
            if saved["state"] in ("complete", "failed", "error", "cancelled"):
                return job, saved
            time.sleep(1)
        raise TimeoutError(job)

    def run_folder(self, job):
        return self.folder / "Application Runs" / job


def load_csv(start, hours, base=26.0, peak=44.0):
    lines = ["timestamp,load_mw"]
    for i in range(hours):
        d = start + timedelta(hours=i)
        lines.append(f"{d:%Y-%m-%d %H:%M:%S},{peak if 17 <= d.hour < 21 else base}")
    return "\n".join(lines) + "\n"


def payload(server, scenarios, definitions=None, csv=None, planned=(), **values):
    full = {f["key"]: f["default"] for f in server.get("/api/defaults")["fields"]}
    full.update(trajectory_mode="model", baseline=33.34421, microgrid_min_mw=0, microgrid_max_mw=1e12, start_year=2025,
                horizon_years=1)
    full.update(values)
    body = dict(values=full, scenarios=scenarios, planned_generation=list(planned),
                upload_csv=csv if csv is not None else load_csv(datetime(2025, 3, 3), 168), import_mode="historical")
    if definitions:
        body["scenario_definitions"] = definitions
    return body


def non_finite(node, path=""):
    """Paths of NaN/inf (or their JSON spellings) inside a parsed JSON tree."""
    found = []
    if isinstance(node, float) and not math.isfinite(node):
        found.append(path)
    elif isinstance(node, str) and node in ("NaN", "Infinity", "-Infinity", "nan", "inf"):
        found.append(path)
    elif isinstance(node, dict):
        for k, v in node.items():
            found += non_finite(v, f"{path}/{k}")
    elif isinstance(node, list):
        for i, v in enumerate(node):
            found += non_finite(v, f"{path}[{i}]")
    return found
