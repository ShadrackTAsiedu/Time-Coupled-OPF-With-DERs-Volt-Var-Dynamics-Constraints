# Third-party notices

GenStudio uses the open-source components below. Each remains under its own licence; follow the
licence text published with the package or at the linked project page. Python packages are installed
from PyPI and not redistributed in this folder.

## Bundled with the application

| Component | Version | Licence | Use |
|---|---|---|---|
| [Leaflet](https://leafletjs.com) | 1.9.4 | BSD 2-Clause (full text in `generation_ui\leaflet_LICENSE.txt`) | interactive map (`generation_ui\leaflet.js`, `leaflet.css`, marker and layer images) |

Leaflet (c) 2010-2023 Volodymyr Agafonkin, (c) 2010-2011 CloudMade.

## Python runtime dependencies (`requirements.txt`)

| Package | Licence |
|---|---|
| [HiGHS](https://highs.dev) via `highspy` | MIT |
| [NumPy](https://numpy.org) | BSD 3-Clause |
| [SciPy](https://scipy.org) | BSD 3-Clause |
| [Matplotlib](https://matplotlib.org) | Matplotlib licence (PSF-based, BSD-compatible) |
| [openpyxl](https://openpyxl.readthedocs.io) | MIT |
| [python-docx](https://python-docx.readthedocs.io) | MIT |
| [lxml](https://lxml.de) | BSD 3-Clause |
| [pypdf](https://pypdf.readthedocs.io) | BSD 3-Clause |

## Development and optional components

| Package | Licence | Notes |
|---|---|---|
| [Playwright for Python](https://playwright.dev/python/) | Apache 2.0 | browser tests only (`requirements-dev.txt`) |
| [pandas](https://pandas.pydata.org), [pvlib](https://pvlib-python.readthedocs.io) | BSD 3-Clause | only `download_solar_profile.py` |
| [Gurobi Optimizer / gurobipy](https://www.gurobi.com) | Proprietary | optional; not distributed here; requires the user's own licence |
| PSS/E (Siemens PTI) | Proprietary | optional, used only by `psse_check.py` on machines that have it |

## Data and map services (accessed only when requested)

| Service | Terms |
|---|---|
| OpenStreetMap tiles and data, Nominatim | (c) OpenStreetMap contributors, ODbL; [tile usage policy](https://operations.osmfoundation.org/policies/tiles/) and [Nominatim usage policy](https://operations.osmfoundation.org/policies/nominatim/) |
| NASA POWER | open data; cite NASA POWER |
| PVGIS (EU JRC) | free reuse with attribution |
| NREL ComStock / ResStock (OEDI), NREL PVWatts | CC BY 4.0 for the datasets; PVWatts requires the user's own API key |
| U.S. EIA Open Data (EIA-930) | public domain; requires the user's own API key |
| FCC Area API | public U.S. government service |

Reference values used as defaults are cited in `GENERATION_APP_README.md` (NREL ATB, EPA, EIA, IEA).
