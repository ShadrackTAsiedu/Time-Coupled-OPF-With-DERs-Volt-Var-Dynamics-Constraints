"""Verified suggestion engine: sizes, sign conventions, range rules and the user's failing run (copied, never modified)."""
import json
import shutil
import unittest
from pathlib import Path

import power_flow as pf
import workflow
from test_power_flow import ScreeningTests, diagram, same_kv

ROOT = Path(__file__).parent / "Application Runs"
SOURCE = ROOT / "7791be18470745f8af5ef34fa3d208f8"
COPY = "b00b00b00b00b00b00b00b00b00b00b0"
STD = set(pf.STD_MVA)


def violations(report):
    return [v for c in report["cases"] for v in c["violations"]]


class RangeRuleTests(unittest.TestCase):
    def test_range_rules_drop_lowering(self):
        import pf_suggest
        eng = pf_suggest.Engine.__new__(pf_suggest.Engine)
        eng.cur_max = 10
        mk = lambda key, cur, sug: dict(target=dict(kind="field", key=key), current=cur, suggested=sug, recommended=True)
        eng.rows = {("field", "microgrid_max_mw", None): mk("microgrid_max_mw", 10, 0.05),
                    ("field", "microgrid_min_mw", None): mk("microgrid_min_mw", 8, 0.05)}
        eng.enforce_range_rules()
        self.assertNotIn(("field", "microgrid_max_mw", None), eng.rows)
        eng.rows = {("field", "microgrid_max_mw", None): mk("microgrid_max_mw", 10, 12),
                    ("field", "microgrid_min_mw", None): mk("microgrid_min_mw", 8, 13)}
        eng.enforce_range_rules()
        self.assertEqual(list(eng.rows), [("field", "microgrid_max_mw", None)])

    def test_workflow_never_applies_range(self):
        entry = dict(code="P1", suggestions=[dict(target=dict(kind="field", key="microgrid_max_mw"), recommended=True, current=10, suggested=14, reason="x")])
        self.assertEqual(workflow.fixable_overrides(entry), {})
        self.assertEqual(workflow.range_advisories(entry)[0]["suggested"], 14)


class SyntheticSuggestionTests(unittest.TestCase):
    code = "S1"
    setUp = ScreeningTests.setUp
    tearDown = ScreeningTests.tearDown
    make_run = ScreeningTests.make_run

    def test_transformer_and_line_suggestions_are_sane(self):
        nodes = [("g", "grid"), ("b", "bus"), ("l", "load"), ("pv", "pv")]
        lines = [("w1", "g", "b", 0), ("w2", "b", "l", 0), ("w3", "pv", "b", 3)]
        run = self.make_run(nodes, lines)
        a = dict(nodes=same_kv(["g", "b", "l", "pv"]), lines=dict(w1=dict(rating_mva=1.0), w2=dict(rating_mva=1.0), w3=dict(rating_mva=1.0)))
        report = pf.screen_run(run, self.code, assumptions=a, n1=False)
        self.assertTrue(report["suggestions"])
        for r in report["suggestions"]:
            if r["target"]["kind"] == "line" and r["target"]["key"] in ("mva", "rating_mva"):
                self.assertGreater(r["suggested"], r["current"])
            self.assertFalse(r["target"].get("key") == "microgrid_max_mw" and r["suggested"] < r["current"])
            self.assertFalse(r["target"]["kind"] == "field" and 0 < r["suggested"] < 0.5)
        again = pf.screen_run(run, self.code, assumptions=a, n1=False)
        self.assertEqual(again["status"], report["status"])
    def test_shunt_sign_convention_in_text(self):
        run = self.make_run([("g", "grid"), ("l", "load")], [("w1", "g", "l", 4.0)])
        a = dict(nodes=same_kv(["g", "l"]), lines=dict(w1=dict(rating_mva=50.0, r_ohm_km=0.6, x_ohm_km=0.5)))
        report = pf.screen_run(run, self.code, assumptions=a, n1=False)
        shunts = [r for r in report["suggestions"] if r["target"].get("key") == "shunt_mvar"]
        for r in shunts:
            self.assertIn("capacitor", r["label"].lower())
            self.assertIn("reactor", r["label"].lower())
            if r["violation"] == "voltage_low":
                self.assertGreater(r["suggested"], r["current"])
            if r["violation"] == "voltage_high":
                self.assertLess(r["suggested"], r["current"])


@unittest.skipUnless(SOURCE.exists(), "user's run not available")
class UserRunTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        shutil.copytree(SOURCE, ROOT / COPY, dirs_exist_ok=False)
        # The stored per-bus caps are old automatic sizings (ignored on load); mark them as the user's own to exercise the
        # "user-entered capacitors over-voltage the feeder" advice.
        path = ROOT / COPY / "request.json"
        request = json.loads(path.read_text(encoding="utf-8"))
        for diagram in request["topology"]["diagrams"].values():
            for node in diagram["nodes"]:
                if (node.get("electrical") or {}).get("shunt_mvar", 0) > 0:
                    node["electrical"]["shunt_user"] = True
        path.write_text(json.dumps(request), encoding="utf-8")

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(ROOT / COPY, ignore_errors=True)

    def check_common(self, r):
        for s in r["suggestions"]:
            t = s["target"]
            if t["kind"] == "field":
                if t["key"] == "microgrid_max_mw":
                    self.assertGreaterEqual(s["suggested"], 10, s)
                if t["key"] == "microgrid_min_mw":
                    self.assertLessEqual(s["suggested"], 10, s)
                self.assertGreaterEqual(s["suggested"], 0.5, s)
            self.assertNotEqual(s.get("verified"), False)
            if t["kind"] != "advice":
                self.assertTrue(s["reason"])

    def test_p1_voltage_high_no_junk(self):
        r = pf.screen_scenario(COPY, "P1")
        self.check_common(r)
        shunts = [s for s in r["suggestions"] if s["target"].get("key") == "shunt_mvar"]
        self.assertTrue(shunts)
        self.assertLess(shunts[0]["suggested"], shunts[0]["current"])
        self.assertTrue(shunts[0]["verified"])
        ver = r["verification"]
        self.assertLess(ver["violations_after"], ver["violations_before"])
        self.assertNotEqual(ver["status_after"], "FAIL")

    def test_r0_transformer_standard_size(self):
        r = pf.screen_scenario(COPY, "R0")
        self.check_common(r)
        tr = [s for s in r["suggestions"] if s["target"]["kind"] == "line" and s["target"]["key"] in ("mva", "rating_mva")]
        self.assertTrue(tr)
        self.assertIn(tr[0]["suggested"], STD)
        self.assertTrue(tr[0]["verified"])

    def test_ng_reactive_limit_is_advice_not_junk(self):
        r = pf.screen_scenario(COPY, "NG")
        self.check_common(r)
        # The only NG finding left is the physical N-1 forming-unit overload (advice only, nothing to verify); it is not a cap problem.
        self.assertLessEqual(r["verification"]["violations_after"], r["verification"]["violations_before"])
        self.assertEqual([s["target"]["kind"] for s in r["suggestions"]], ["advice"])

    def test_range_never_lowered_in_any_scenario(self):
        for code in ("H2", "S1", "S2"):
            self.check_common(pf.screen_scenario(COPY, code))


if __name__ == "__main__":
    unittest.main()
