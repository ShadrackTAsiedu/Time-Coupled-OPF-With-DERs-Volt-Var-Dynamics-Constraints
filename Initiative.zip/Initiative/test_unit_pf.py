import math
import unittest

import generation_app as ga
import planning_inputs
import power_flow as pf
import test_power_flow_page as tp
import unit_pf


class QMath(unittest.TestCase):
    def test_mva_and_limits(self):
        self.assertAlmostEqual(unit_pf.rated_mva(9, 0.9), 10.0)
        qmin, qmax = unit_pf.q_limits(10, 0.9, 0.9)
        self.assertAlmostEqual(qmax, 10 * math.tan(math.acos(0.9)), 6)
        self.assertAlmostEqual(qmin, -qmax, 6)

    def test_unity_has_no_q(self):
        self.assertEqual(unit_pf.q_limits(10, 1.0, 1.0), (0.0, 0.0))

    def test_missing_keys_default(self):
        self.assertEqual(unit_pf.for_tech({}, "pv")["pf"], 0.9)
        self.assertEqual(unit_pf.basis_of({}), "per_mw_at_pf")


class CostBasis(unittest.TestCase):
    def settings(self, **extra):
        req = ga.validate_request({"values": extra}) if hasattr(ga, "validate_request") else None
        return ga.settings_for(req["values"])

    def test_default_unchanged_and_per_mva_scaled(self):
        base = self.settings()
        mva = self.settings(cost_basis="per_mva")
        self.assertAlmostEqual(mva["pv_capex"], base["pv_capex"] / 0.9, 3)
        self.assertAlmostEqual(mva["pv_fom"], base["pv_fom"] / 0.9, 3)

    def test_pf_one_is_neutral(self):
        base = self.settings()
        same = self.settings(cost_basis="per_mva", pv_pf=1.0)
        self.assertAlmostEqual(same["pv_capex"], base["pv_capex"], 3)

    def test_pf_range_validated(self):
        with self.assertRaises(Exception):
            ga.validate_request({"values": {"pv_pf": 0.7}})


class PowerFlowPf(unittest.TestCase):
    def net(self, pf_value):
        helper = tp.RawTests("test_sections_fields_and_references")
        nodes = [("g", "grid"), ("sub", "substation"), ("b", "bus"), ("l", "load"), ("pv", "pv")]
        lines = [("w1", "g", "sub", 5), ("t1", "sub", "b", 0), ("w2", "b", "l", 0.5), ("w3", "pv", "b", 0)]
        over = tp.same_kv(["g", "sub"], kv=33.0)
        over.update(tp.same_kv(["b", "l", "pv"], kv=11.0))
        spec = dict(pv=dict(pf=pf_value, pf_lead=pf_value))
        return pf.build_network(tp.diagram(nodes, lines), caps=dict(pv=4.0), assumptions=dict(nodes=over), peak_load_mw=3.0, unit_pf=spec)

    def test_raw_machine_fields(self):
        net = self.net(0.9)
        inj = dict(load_mw=3.0, gens=dict(pv=dict(p=2.5)))
        case = pf.solve_case(net, inj)
        rec = tp.parse_raw(pf.export_raw(net, inj, case))
        row = next(tp.split(r) for r in rec["GENERATOR"] if abs(float(tp.split(r)[2]) - 2.5) < 1e-6)
        qmax = 4.0 * math.tan(math.acos(0.9))
        circle = math.sqrt((4.0 / 0.9) ** 2 - 2.5 ** 2)  # solved case: MVA-circle limit at the dispatched MW, as the solver uses
        self.assertAlmostEqual(float(row[8]), 4.0 / 0.9, places=2)  # MBASE = MVA
        self.assertAlmostEqual(float(row[16]), 4.0, places=2)  # PMAX = MW
        self.assertAlmostEqual(float(row[4]), circle, places=2)  # QT
        self.assertAlmostEqual(float(row[5]), -circle, places=2)  # QB
        full = dict(load_mw=5.0, gens=dict(pv=dict(p=4.0)))  # at rated MW the circle limit equals the rated Q capability
        bare = tp.parse_raw(pf.export_raw(net, full, pf.solve_case(net, full)))
        row = next(tp.split(r) for r in bare["GENERATOR"] if abs(float(tp.split(r)[2]) - 4.0) < 1e-6)
        self.assertAlmostEqual(float(row[4]), qmax, places=2)
        self.assertAlmostEqual(float(row[5]), -qmax, places=2)

    def test_pf_changes_reactive_support_and_voltage(self):
        inj = dict(load_mw=5.0, gens=dict(pv=dict(p=4.0)))
        unity = pf.solve_case(self.net(1.0), inj)
        lag = pf.solve_case(self.net(0.9), inj)
        q = lambda case: next(g for g in case["gens"] if g["tech"] == "pv")["q_mvar"]
        self.assertAlmostEqual(q(unity), 0.0, places=4)
        self.assertGreater(abs(q(lag)), 0.01)
        self.assertGreater(min(b["vm"] for b in lag["buses"]), min(b["vm"] for b in unity["buses"]) - 1e-9)

    def test_q_never_exceeds_capability(self):
        net = self.net(0.9)
        case = pf.solve_case(net, dict(load_mw=3.0, gens=dict(pv=dict(p=4.0))))
        g = next(g for g in case["gens"] if g["tech"] == "pv")
        self.assertLessEqual(abs(g["q_mvar"]), 4.0 * math.tan(math.acos(0.9)) + 1e-6)


class ShuntSizing(unittest.TestCase):
    def test_idle_inverter_still_supplies_q_within_its_mva(self):
        net = PowerFlowPf("test_raw_machine_fields").net(0.9)
        case = pf.solve_case(net, dict(load_mw=3.0, gens=dict(pv=dict(p=0.0))))
        g = next(g for g in case["gens"] if g["tech"] == "pv")
        cap = next(x["cap"] for x in net.gens if x["tech"] == "pv")
        self.assertGreater(g["q_mvar"], 0.0)
        self.assertLessEqual(g["q_mvar"], cap / 0.9 + 1e-6)

    def test_marked_user_shunt_is_kept_and_unmarked_stored_cap_is_ignored(self):
        node = lambda extra: dict(id="b", kind="bus", label="B", x=0, y=0, electrical=dict(shunt_mvar=9.6, **extra))
        d = dict(nodes=[node({})], lines=[])
        self.assertNotIn("electrical", pf._migrate_stale_auto_shunts(d)["nodes"][0])
        self.assertEqual(pf._migrate_stale_auto_shunts(dict(nodes=[node(dict(shunt_user=True))], lines=[]))["nodes"][0]["electrical"]["shunt_mvar"], 9.6)

    def test_planned_pf_validated(self):
        base = dict(name="x", technology="Solar", capacity_mw=1, start_year=2027, end_year=2027)
        self.assertEqual(planning_inputs.validate_projects([base])[0]["pf"], 0.9)
        with self.assertRaises(ValueError):
            planning_inputs.validate_projects([dict(base, pf=0.7)])


class Statement(unittest.TestCase):
    def test_wording(self):
        self.assertIn("costs are per MW at stated pf", unit_pf.statement({}))
        self.assertIn("rated MVA = MW / pf", unit_pf.statement({"cost_basis": "per_mva"}))
        self.assertEqual(unit_pf.mva_text("pv", 9, {}), "10.00 MVA (pf 0.9)")


if __name__ == "__main__":
    unittest.main()
