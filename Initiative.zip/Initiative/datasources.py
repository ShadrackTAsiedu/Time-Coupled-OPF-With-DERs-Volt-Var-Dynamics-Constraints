"""Public-data connectors for GenStudio: solar, wind, weather, thermal proxy and load profiles.

Routes (registered through extensions, served under /api/x/):
    GET  tile?z=&x=&y=            OpenStreetMap raster tile through a validating, caching proxy
    GET  geocode?q=               Nominatim place search (1 request/second, cached)
    GET  ds_locate?lat=&lon=      US state/county (FCC Area API) for load-data quick select
    GET  ds_catalog               sources, turbine curves, building types, states, balancing authorities
    POST ds_fetch                 start a download job -> {"job": id}
    GET  ds_job?id=               job state/progress/result (canonical CSV, statistics, preview, provenance)
    GET  ds_file?name=            a saved dataset or provenance file from Data Cache/datasets

Everything is standard library + numpy. API keys supplied by the user are used for one request only: they
are never written to disk, to the cache key, to provenance or to logs.
"""

import csv
import gzip
import hashlib
import io
import json
import math
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zlib
from collections import deque
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import numpy as np

import extensions

ROOT = Path(__file__).resolve().parent
CACHE = ROOT / "Data Cache"
USER_AGENT = "GenStudio/1.0 (local energy-planning desktop tool; non-commercial planning use)"
_urlopen = urllib.request.urlopen   # replaced by tests
MAX_YEARS = 10
RETRY_DELAYS = (2.0, 6.0)   # seconds before the 2nd and 3rd attempt on transient failures (HTTP 429/5xx, timeouts)

NASA_URL = "https://power.larc.nasa.gov/api/temporal/hourly/point"
PVGIS_URL = "https://re.jrc.ec.europa.eu/api/v5_3/"
PVWATTS_URL = "https://developer.nrel.gov/api/pvwatts/v8.json"
EIA_URL = "https://api.eia.gov/v2/electricity/rto/region-data/data/"
OEDI_BASE = ("https://oedi-data-lake.s3.amazonaws.com/nrel-pds-building-stock/"
             "end-use-load-profiles-for-us-building-stock/2024/")
FCC_URL = "https://geo.fcc.gov/api/census/block/find"
OSM_TILE_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"

LICENCES = {
    "nasa_power": ("NASA POWER (MERRA-2 / CERES SYN1deg). Public data, no restrictions. Acknowledgement: 'These data were "
                   "obtained from the NASA Langley Research Center (LaRC) POWER Project funded through the NASA Earth "
                   "Science/Applied Science Program.'"),
    "pvgis": ("PVGIS (c) European Union, Joint Research Centre; reuse authorised with acknowledgement (CC BY 4.0). "
              "ERA5 reanalysis: Hersbach et al. (2020), Copernicus Climate Change Service; contains modified "
              "Copernicus Climate Change Service information."),
    "pvwatts": ("NREL PVWatts v8 / NSRDB. U.S. Department of Energy/NREL data, free with API key; cite 'NREL PVWatts "
                "Calculator' and Sengupta et al. (2018), The National Solar Radiation Data Base (NSRDB), RSER 89."),
    "eia930": ("U.S. Energy Information Administration, Hourly Electric Grid Monitor (Form EIA-930), public domain; "
               "cite EIA as the source. Values include EIA imputation/adjustment and occasional outliers."),
    "comstock": ("NREL End-Use Load Profiles for the U.S. Building Stock (ComStock/ResStock 2024 release 2, AMY 2018), "
                 "CC BY 4.0. Cite Wilson et al. (2022), NREL/TP-5500-80889, doi:10.2172/1854582."),
    "typical": "Generic typical shapes authored for GenStudio (illustrative; no external data except the chosen weather source).",
}

# Generic 3 MW-class turbine curves: cubic rise between cut-in and rated, flat to cut-out.
# These are idealised illustrative curves, NOT manufacturer data. Rated speeds follow the IEC 61400-1
# class intent (high-wind turbines have smaller rotors and higher rated speed; low-wind turbines large rotors).
TURBINES = {
    "iec1": dict(label="Generic IEC class I, 3 MW (high wind, rated 12.5 m/s)", cut_in=3.0, rated=12.5, cut_out=25.0),
    "iec2": dict(label="Generic IEC class II, 3 MW (medium wind, rated 11.0 m/s)", cut_in=3.0, rated=11.0, cut_out=25.0),
    "iec3": dict(label="Generic IEC class III, 3 MW (low wind, large rotor, rated 10.0 m/s)", cut_in=2.5, rated=10.0,
                 cut_out=22.0),
}

COMSTOCK_TYPES = {
    "fullservicerestaurant": "Full-service restaurant", "hospital": "Hospital", "largehotel": "Large hotel",
    "largeoffice": "Large office", "mediumoffice": "Medium office", "outpatient": "Outpatient healthcare",
    "primaryschool": "Primary school", "quickservicerestaurant": "Quick-service restaurant",
    "retailstandalone": "Retail (standalone)", "retailstripmall": "Retail (strip mall)",
    "secondaryschool": "Secondary school", "smallhotel": "Small hotel", "smalloffice": "Small office",
    "warehouse": "Warehouse"}
RESSTOCK_TYPES = {
    "mobile_home": "Mobile home", "multi-family_with_2_-_4_units": "Multi-family 2-4 units",
    "multi-family_with_5plus_units": "Multi-family 5+ units", "single-family_attached": "Single-family attached",
    "single-family_detached": "Single-family detached"}

# (name, standard-time UTC offset, [principal EIA-930 balancing authorities] - approximate, verify on eia.gov)
STATES = {
    "AL": ("Alabama", -6, ["SOCO", "TVA"]), "AK": ("Alaska", -9, []), "AZ": ("Arizona", -7, ["AZPS", "SRP", "TEPC"]),
    "AR": ("Arkansas", -6, ["MISO", "SWPP"]), "CA": ("California", -8, ["CISO", "LDWP", "BANC", "IID", "TIDC"]),
    "CO": ("Colorado", -7, ["PSCO", "WACM"]), "CT": ("Connecticut", -5, ["ISNE"]), "DE": ("Delaware", -5, ["PJM"]),
    "DC": ("District of Columbia", -5, ["PJM"]), "FL": ("Florida", -5, ["FPL", "FPC", "TEC", "JEA", "TAL", "FMPP"]),
    "GA": ("Georgia", -5, ["SOCO"]), "HI": ("Hawaii", -10, []), "ID": ("Idaho", -7, ["IPCO", "AVA"]),
    "IL": ("Illinois", -6, ["PJM", "MISO"]), "IN": ("Indiana", -5, ["MISO", "PJM"]), "IA": ("Iowa", -6, ["MISO", "SWPP"]),
    "KS": ("Kansas", -6, ["SWPP", "EVRG"]), "KY": ("Kentucky", -5, ["PJM", "LGEE", "TVA"]), "LA": ("Louisiana", -6, ["MISO"]),
    "ME": ("Maine", -5, ["ISNE"]), "MD": ("Maryland", -5, ["PJM"]), "MA": ("Massachusetts", -5, ["ISNE"]),
    "MI": ("Michigan", -5, ["MISO", "PJM"]), "MN": ("Minnesota", -6, ["MISO"]), "MS": ("Mississippi", -6, ["MISO", "SOCO", "TVA"]),
    "MO": ("Missouri", -6, ["MISO", "SWPP", "AECI"]), "MT": ("Montana", -7, ["NWMT"]), "NE": ("Nebraska", -6, ["SWPP"]),
    "NV": ("Nevada", -8, ["NEVP"]), "NH": ("New Hampshire", -5, ["ISNE"]), "NJ": ("New Jersey", -5, ["PJM"]),
    "NM": ("New Mexico", -7, ["PNM", "EPE"]), "NY": ("New York", -5, ["NYIS"]), "NC": ("North Carolina", -5, ["DUK", "CPLE"]),
    "ND": ("North Dakota", -6, ["MISO", "SWPP"]), "OH": ("Ohio", -5, ["PJM"]), "OK": ("Oklahoma", -6, ["SWPP"]),
    "OR": ("Oregon", -8, ["PGE", "BPAT", "PACW"]), "PA": ("Pennsylvania", -5, ["PJM"]), "RI": ("Rhode Island", -5, ["ISNE"]),
    "SC": ("South Carolina", -5, ["SCEG", "SC", "DUK"]), "SD": ("South Dakota", -6, ["SWPP", "WAUW"]),
    "TN": ("Tennessee", -6, ["TVA"]), "TX": ("Texas", -6, ["ERCO", "SWPP"]), "UT": ("Utah", -7, ["PACE"]),
    "VT": ("Vermont", -5, ["ISNE"]), "VA": ("Virginia", -5, ["PJM", "DUK"]),
    "WA": ("Washington", -8, ["BPAT", "SCL", "PSEI", "AVA", "TPWR", "CHPD", "GCPD", "DOPD"]),
    "WV": ("West Virginia", -5, ["PJM"]), "WI": ("Wisconsin", -6, ["MISO", "PJM"]), "WY": ("Wyoming", -7, ["PACE", "WACM"])}
BALANCING = {
    "AECI": ("Associated Electric Cooperative", -6), "AVA": ("Avista", -8), "AZPS": ("Arizona Public Service", -7),
    "BANC": ("Balancing Authority of Northern California", -8), "BPAT": ("Bonneville Power Administration", -8),
    "CHPD": ("Chelan County PUD", -8), "CISO": ("California ISO", -8), "CPLE": ("Duke Energy Progress East", -5),
    "DOPD": ("Douglas County PUD", -8), "DUK": ("Duke Energy Carolinas", -5), "EPE": ("El Paso Electric", -7),
    "ERCO": ("ERCOT (Texas)", -6), "EVRG": ("Evergy", -6), "FMPP": ("Florida Municipal Power Pool", -5),
    "FPC": ("Duke Energy Florida", -5), "FPL": ("Florida Power & Light", -5), "GCPD": ("Grant County PUD", -8),
    "IID": ("Imperial Irrigation District", -8), "IPCO": ("Idaho Power", -7), "ISNE": ("ISO New England", -5),
    "JEA": ("JEA (Jacksonville)", -5), "LDWP": ("Los Angeles Dept. of Water & Power", -8), "LGEE": ("LG&E and KU", -5),
    "MISO": ("Midcontinent ISO", -5), "NEVP": ("NV Energy", -8), "NWMT": ("NorthWestern Energy", -7),
    "NYIS": ("New York ISO", -5), "PACE": ("PacifiCorp East", -7), "PACW": ("PacifiCorp West", -8),
    "PGE": ("Portland General Electric", -8), "PJM": ("PJM Interconnection", -5), "PNM": ("Public Service Co. of New Mexico", -7),
    "PSCO": ("Public Service Co. of Colorado", -7), "PSEI": ("Puget Sound Energy", -8), "SC": ("Santee Cooper", -5),
    "SCEG": ("Dominion Energy South Carolina", -5), "SCL": ("Seattle City Light", -8), "SOCO": ("Southern Company", -5),
    "SRP": ("Salt River Project", -7), "SWPP": ("Southwest Power Pool", -6), "TAL": ("City of Tallahassee", -5),
    "TEC": ("Tampa Electric", -5), "TEPC": ("Tucson Electric Power", -7), "TIDC": ("Turlock Irrigation District", -8),
    "TPWR": ("Tacoma Power", -8), "TVA": ("Tennessee Valley Authority", -6), "WACM": ("WAPA Rocky Mountain", -7),
    "WAUW": ("WAPA Upper Great Plains West", -7)}

# Generic typical-day shapes: (weekday key points, weekend key points) as (hour, fraction of peak), plus weather
# sensitivity (fraction of load per degC above 18 C cooling / below 12 C heating) and a seasonal factor by month.
_FLAT = [(0, 1.0), (24, 1.0)]
TYPICAL = {
    "office": dict(label="Office", wd=[(0, .40), (5, .40), (8, .85), (10, 1.0), (16, 1.0), (19, .65), (22, .45), (24, .40)],
                   we=[(0, .38), (8, .40), (12, .45), (18, .42), (24, .38)], cool=.018, heat=.008, season=None),
    "retail": dict(label="Retail", wd=[(0, .35), (7, .40), (10, .85), (13, 1.0), (20, 1.0), (22, .60), (24, .35)],
                   we=[(0, .35), (7, .40), (10, .90), (13, 1.0), (19, 1.0), (22, .60), (24, .35)], cool=.015, heat=.005, season=None),
    "school": dict(label="School", wd=[(0, .30), (6, .35), (8, .90), (9, 1.0), (15, 1.0), (17, .55), (20, .40), (24, .30)],
                   we=[(0, .28), (24, .30)], cool=.012, heat=.010, season=[1, 1, 1, 1, .95, .55, .45, .60, 1, 1, 1, .95]),
    "hospital": dict(label="Hospital / 24-7 healthcare", wd=[(0, .75), (6, .78), (9, .95), (15, 1.0), (20, .90), (24, .76)],
                     we=[(0, .72), (9, .85), (15, .92), (24, .72)], cool=.010, heat=.006, season=None),
    "hotel": dict(label="Hotel", wd=[(0, .60), (5, .60), (7, .80), (10, .70), (17, .85), (20, 1.0), (23, .75), (24, .60)],
                  we=[(0, .62), (7, .78), (11, .72), (18, .92), (21, 1.0), (24, .65)], cool=.015, heat=.007, season=None),
    "warehouse": dict(label="Warehouse / light industrial (one shift)", wd=[(0, .40), (5, .42), (7, .85), (9, 1.0), (16, 1.0), (18, .60), (22, .42), (24, .40)],
                      we=[(0, .38), (24, .40)], cool=.008, heat=.004, season=None),
    "industrial247": dict(label="Industrial, continuous 24/7 process", wd=[(0, .94), (24, .94)], we=[(0, .92), (24, .92)],
                          cool=.004, heat=.001, season=None),
    "datacenter": dict(label="Data center", wd=[(0, .96), (14, 1.0), (24, .96)], we=[(0, .95), (24, .95)],
                       cool=.010, heat=.0, season=None),
    "grocery": dict(label="Grocery / refrigerated retail", wd=[(0, .72), (6, .75), (9, .92), (16, 1.0), (21, .90), (24, .72)],
                    we=[(0, .72), (9, .92), (15, 1.0), (21, .90), (24, .72)], cool=.012, heat=.003, season=None),
    "residential": dict(label="Residential", wd=[(0, .50), (4, .42), (7, .75), (9, .60), (16, .62), (19, 1.0), (22, .80), (24, .52)],
                        we=[(0, .52), (4, .45), (9, .72), (13, .70), (19, 1.0), (22, .82), (24, .54)], cool=.030, heat=.012, season=None),
    "restaurant": dict(label="Restaurant", wd=[(0, .35), (6, .40), (11, .80), (13, .95), (17, .90), (19, 1.0), (22, .65), (24, .35)],
                       we=[(0, .38), (10, .60), (13, 1.0), (19, 1.0), (22, .70), (24, .38)], cool=.014, heat=.004, season=None),
}


# --------------------------------------------------------------------------------------------- networking
_SECRET = re.compile(r"(api_key=)[^&\s'\"]+", re.I)


def _scrub(text, secrets=()):
    text = _SECRET.sub(r"\1***", str(text))
    for secret in secrets:
        if secret:
            text = text.replace(secret, "***")
    return text


def _service_message(body):
    """Prefer the human-readable message of a JSON error body (PVGIS, NREL, EIA) over the raw payload."""
    try:
        data = json.loads(body)
    except ValueError:
        return body
    if isinstance(data, dict):
        for key in ("message", "error", "errors"):
            if data.get(key):
                return str(data[key])
    return body


def _fetch(url, headers=None, timeout=60, secrets=(), retry=False):
    """GET url and return the body bytes; every failure becomes a user-facing ValueError without secrets.

    With retry=True, transient failures (HTTP 429/5xx, timeouts, connection errors) are retried after RETRY_DELAYS.
    """
    delays = list(RETRY_DELAYS) if retry else []
    while True:
        try:
            return _fetch_once(url, headers, timeout, secrets)
        except _Transient as exc:
            if not delays:
                raise ValueError(str(exc)) from None
            time.sleep(delays.pop(0))


class _Transient(Exception):
    """A failure worth retrying; the message is already user-facing."""


def _fetch_once(url, headers, timeout, secrets):
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, **(headers or {})})
    try:
        with _urlopen(request, timeout=timeout) as response:
            return response.read()
    except urllib.error.HTTPError as exc:
        body = ""
        try:
            body = _service_message(exc.read(600).decode("utf-8", "replace"))
        except Exception:
            pass
        host = urllib.parse.urlparse(url).netloc
        if exc.code == 429:
            raise _Transient(f"{host} rate limit reached (HTTP 429). Wait a minute and try again.") from None
        if exc.code in (401, 403):
            raise ValueError(f"{host} refused the request (HTTP {exc.code}); check the API key or access rights. "
                             + _scrub(body, secrets)[:200]) from None
        message = f"{host} returned HTTP {exc.code}. " + _scrub(body, secrets)[:300]
        raise (_Transient if exc.code >= 500 else ValueError)(message) from None
    except (TimeoutError, OSError) as exc:
        host = urllib.parse.urlparse(url).netloc
        reason = getattr(exc, "reason", exc)
        if isinstance(exc, TimeoutError) or "timed out" in str(reason).lower():
            raise _Transient(f"{host} did not answer within {timeout} s (timeout). Try again later.") from None
        raise _Transient(f"Cannot reach {host}: no internet connection or the server is down "
                         f"({_scrub(reason, secrets)[:120]}).") from None


def _cache_path(key, suffix=".json.gz"):
    return CACHE / "raw" / (hashlib.sha256(key.encode()).hexdigest()[:40] + suffix)


def _cached(key, producer, max_age=None, refresh=False):
    """Disk cache of JSON-serialisable results. `key` must never contain secrets."""
    path = _cache_path(key)
    if not refresh and path.is_file() and (max_age is None or time.time() - path.stat().st_mtime < max_age):
        try:
            return json.loads(gzip.decompress(path.read_bytes()))
        except (OSError, ValueError, zlib.error):
            pass
    value = producer()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_bytes(gzip.compress(json.dumps(value, allow_nan=False).encode()))
    tmp.replace(path)
    return value


def _json(raw, what):
    try:
        return json.loads(raw)
    except ValueError:
        raise ValueError(f"{what} returned something that is not JSON (service outage?).") from None


# ----------------------------------------------------------------------------------------- map tiles/geocode
_tile_slots = threading.BoundedSemaphore(2)   # OSM policy: at most 2 concurrent connections
_tile_log = deque(maxlen=240)
_tile_lock = threading.Lock()
TILE_MAX_AGE = 7 * 86400                      # OSM policy: honour at least 7 days of caching


def _grey_tile():
    def chunk(tag, data):
        body = tag + data
        return len(data).to_bytes(4, "big") + body + zlib.crc32(body).to_bytes(4, "big")
    rows = b"".join(b"\x00" + b"\xdd" * 256 for _ in range(256))
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", (256).to_bytes(4, "big") * 2 + b"\x08\x00\x00\x00\x00")
            + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b""))


def _int_arg(query, key, lo, hi):
    values = query.get(key) or []
    if len(values) != 1 or not re.fullmatch(r"[0-9]{1,8}", values[0]):
        raise ValueError(f"{key} must be a non-negative integer.")
    value = int(values[0])
    if not lo <= value <= hi:
        raise ValueError(f"{key} must be between {lo} and {hi}.")
    return value


def tile(query):
    z = _int_arg(query, "z", 0, 19)
    x = _int_arg(query, "x", 0, 2 ** z - 1)
    y = _int_arg(query, "y", 0, 2 ** z - 1)
    path = CACHE / "tiles" / str(z) / str(x) / f"{y}.png"
    fresh = path.is_file() and time.time() - path.stat().st_mtime < TILE_MAX_AGE
    if fresh:
        return path.read_bytes(), "image/png"
    with _tile_lock:
        now = time.monotonic()
        while _tile_log and now - _tile_log[0] > 60:
            _tile_log.popleft()
        limited = len(_tile_log) >= 200   # at most 200 uncached upstream fetches per minute
        if not limited:
            _tile_log.append(now)
    if not limited:
        try:
            with _tile_slots:
                body = _fetch(OSM_TILE_URL.format(z=z, x=x, y=y), timeout=15)
            if body[:8] != b"\x89PNG\r\n\x1a\n":
                raise ValueError("not a PNG")
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(body)
            return body, "image/png"
        except ValueError:
            pass
    if path.is_file():   # stale tile is better than none
        return path.read_bytes(), "image/png"
    return _grey_tile(), "image/png"


_geo_lock = threading.Lock()
_geo_last = [0.0]


def geocode(query):
    text = " ".join((query.get("q") or [""])[0].split())
    if not 2 <= len(text) <= 200 or any(ord(c) < 32 for c in text):
        raise ValueError("Enter a place to search for (2-200 characters).")
    key = "geocode:" + text.lower()
    path = _cache_path(key)
    if path.is_file():
        return json.loads(gzip.decompress(path.read_bytes()))
    params = urllib.parse.urlencode({"format": "jsonv2", "limit": 6, "addressdetails": 1, "q": text})
    with _geo_lock:   # Nominatim policy: absolute maximum of one request per second
        wait = 1.05 - (time.monotonic() - _geo_last[0])
        if wait > 0:
            time.sleep(wait)
        try:
            raw = _fetch(NOMINATIM_URL + "?" + params, timeout=20)
        finally:
            _geo_last[0] = time.monotonic()
    found = []
    for item in _json(raw, "Nominatim") if raw else []:
        try:
            lat, lon = float(item["lat"]), float(item["lon"])
        except (KeyError, TypeError, ValueError):
            continue
        addr = item.get("address") or {}
        found.append(dict(name=str(item.get("display_name", ""))[:200], lat=lat, lon=lon, type=item.get("type", ""),
                          state=addr.get("state", ""), county=addr.get("county", ""),
                          bbox=[float(v) for v in item.get("boundingbox", [])][:4]))
    result = dict(results=found, attribution="Search results (c) OpenStreetMap contributors (ODbL), via Nominatim.")
    _cached(key, lambda: result)
    return result


def locate(query):
    lat, lon = _coordinates(query)
    key = f"fcc:{lat:.4f},{lon:.4f}"

    def produce():
        data = _json(_fetch(FCC_URL + "?" + urllib.parse.urlencode(
            {"latitude": lat, "longitude": lon, "format": "json", "showall": "false"}), timeout=20), "FCC Area API")
        county, state = data.get("County") or {}, data.get("State") or {}
        if not county.get("FIPS"):
            return dict(us=False)
        return dict(us=True, county_fips=county["FIPS"], county_name=county.get("name", ""),
                    state=state.get("code", ""), state_name=state.get("name", ""))
    info = _cached(key, produce)
    if info.get("us") and info["state"] in STATES:
        info["utc_offset"] = STATES[info["state"]][1]
        info["balancing_authorities"] = STATES[info["state"]][2]
    info["default_utc_offset"] = info.get("utc_offset", default_offset(lon))
    return info


def default_offset(lon):
    return int(max(-12, min(14, round(lon / 15.0))))


def _coordinates(source):
    def pick(key):
        value = source.get(key)
        if isinstance(value, list):
            value = value[0] if value else None
        try:
            number = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"{key} must be a number.") from None
        if not math.isfinite(number):
            raise ValueError(f"{key} must be a finite number.")
        return number
    lat, lon = pick("lat"), pick("lon")
    if not -90 <= lat <= 90 or not -180 <= lon <= 180:
        raise ValueError("Latitude must be in [-90, 90] and longitude in [-180, 180].")
    return lat, lon


# ----------------------------------------------------------------------------------------- hourly containers
class Hourly:
    """Hourly series on a local-standard-time grid. `shift` = hours from the label to the middle of the interval."""

    def __init__(self, times, data, utc_offset, shift=0.5, missing=None):
        self.times, self.data, self.utc_offset, self.shift = times, data, utc_offset, shift
        self.missing = missing or {}
        self.elevation_m = None


def year_grid(first, last):
    return np.arange(np.datetime64(f"{first}-01-01T00", "h"), np.datetime64(f"{last + 1}-01-01T00", "h"))


def place(grid, times, values):
    out = np.full(len(grid), np.nan)
    pos = (times - grid[0]).astype("timedelta64[h]").astype(np.int64)
    ok = (pos >= 0) & (pos < len(grid))
    out[pos[ok]] = values[ok]
    return out


def fill_gaps(values, max_gap=6):
    """Interpolate short gaps; longer gaps get the mean of the same hour of day. Returns (values, missing_fraction)."""
    values = np.asarray(values, float).copy()
    bad = ~np.isfinite(values)
    fraction = float(bad.mean()) if len(values) else 0.0
    if not bad.any():
        return values, 0.0
    if bad.all():
        raise ValueError("The source returned no valid values for this location and period.")
    idx = np.arange(len(values))
    good = ~bad
    interp = np.interp(idx, idx[good], values[good])
    start = 0
    while start < len(values):
        if bad[start]:
            end = start
            while end < len(values) and bad[end]:
                end += 1
            if end - start <= max_gap and start > 0 and end < len(values):
                values[start:end] = interp[start:end]
            start = end
        else:
            start += 1
    left = ~np.isfinite(values)
    if left.any():
        hour = idx % 24
        means = np.array([np.nanmean(values[(hour == h)]) if np.isfinite(values[hour == h]).any() else 0.0
                          for h in range(24)])
        values[left] = means[hour[left]]
    return values, fraction


def local_to_utc_hours(times, utc_offset):
    return times - np.timedelta64(int(utc_offset), "h")


def year_range(payload, lo=2001, hi=None):
    hi = hi or datetime.now(timezone.utc).year
    try:
        first = int(payload.get("start_year", payload.get("year", hi - 1)))
        last = int(payload.get("end_year", first))
    except (TypeError, ValueError):
        raise ValueError("Years must be whole numbers.") from None
    if first > last or first < lo or last > hi:
        raise ValueError(f"Choose years between {lo} and {hi}, first <= last.")
    if last - first + 1 > MAX_YEARS:
        raise ValueError(f"At most {MAX_YEARS} years per download.")
    return first, last


# ------------------------------------------------------------------------------------------ source fetchers
def nasa_power(lat, lon, first, last, utc_offset, progress=None, refresh=False):
    """NASA POWER hourly (UTC) -> Hourly on a local-standard-time grid. One request per year."""
    names = {"ALLSKY_SFC_SW_DWN": "ghi", "ALLSKY_SFC_SW_DNI": "dni", "ALLSKY_SFC_SW_DIFF": "dhi",
             "T2M": "temp", "WS10M": "ws10", "WS50M": "ws50", "PS": "ps"}
    grid = year_grid(first, last)
    arrays = {v: np.full(len(grid), np.nan) for v in names.values()}
    now_year = datetime.now(timezone.utc).year
    # UTC data are requested one day either side so the first/last local hours are complete
    for number, year in enumerate(range(first, last + 1)):
        if progress:
            progress(f"NASA POWER {year} ({number + 1}/{last - first + 1})", .1 + .6 * number / (last - first + 1))
        start, end = date(year, 1, 1) - timedelta(days=1), date(year, 12, 31) + timedelta(days=1)
        end = min(end, datetime.now(timezone.utc).date() - timedelta(days=2))
        url = NASA_URL + "?" + urllib.parse.urlencode({
            "parameters": ",".join(names), "community": "RE", "longitude": f"{lon:.4f}", "latitude": f"{lat:.4f}",
            "start": start.strftime("%Y%m%d"), "end": end.strftime("%Y%m%d"), "format": "JSON", "time-standard": "UTC"})
        data = _cached(url, lambda: _json(_fetch(url, timeout=90, retry=True), "NASA POWER"),
                       max_age=86400 if year >= now_year else None, refresh=refresh)
        params = (data.get("properties") or {}).get("parameter")
        if not params:
            messages = data.get("messages") or data.get("errors") or data
            raise ValueError("NASA POWER returned no data: " + _scrub(json.dumps(messages)[:300]))
        fill = float((data.get("header") or {}).get("fill_value", -999))
        for api, key in names.items():
            series = params.get(api) or {}
            if not series:
                continue
            stamps = np.array([f"{k[:4]}-{k[4:6]}-{k[6:8]}T{k[8:10]}" for k in series], dtype="datetime64[h]")
            values = np.array(list(series.values()), float)
            values[(values <= fill + 0.5)] = np.nan
            local = stamps + np.timedelta64(int(utc_offset), "h")
            part = place(grid, local, values)
            take = np.isfinite(part)
            arrays[key][take] = part[take]
    if not np.isfinite(arrays["ps"]).any():
        del arrays["ps"]   # optional: only used for the wind air-density correction
    return Hourly(grid, arrays, utc_offset, shift=.5)


def _pvgis_time(label):
    return np.datetime64(f"{label[:4]}-{label[4:6]}-{label[6:8]}T{label[9:11]}", "h")


def pvgis_series(lat, lon, first, last, utc_offset, params=None, progress=None, refresh=False):
    """PVGIS-ERA5 seriescalc; with pv params also returns PVGIS's own PV power (P, W per kWp)."""
    query = {"lat": f"{lat:.4f}", "lon": f"{lon:.4f}", "startyear": first, "endyear": last,
             "raddatabase": "PVGIS-ERA5", "outputformat": "json", "pvcalculation": 0}
    query.update(params or {})
    if progress:
        progress("PVGIS-ERA5 hourly series", .2)
    url = PVGIS_URL + "seriescalc?" + urllib.parse.urlencode(query)
    data = _cached(url, lambda: _json(_fetch(url, timeout=120, retry=True), "PVGIS"), refresh=refresh)
    rows = (data.get("outputs") or {}).get("hourly")
    if not rows:
        raise ValueError("PVGIS returned no hourly data (location outside coverage or years not available; "
                         "PVGIS-ERA5 covers about 2005 to two years ago).")
    grid = year_grid(first, last)
    times = np.array([_pvgis_time(r["time"]) for r in rows]) + np.timedelta64(int(utc_offset), "h")
    arrays = {}
    for source, key in (("P", "pvgis_power_w"), ("G(i)", "poa"), ("T2m", "temp"), ("WS10m", "ws10")):
        if source in rows[0]:
            arrays[key] = place(grid, times, np.array([float(r[source]) for r in rows]))
    hourly = Hourly(grid, arrays, utc_offset, shift=.5)
    hourly.elevation_m = ((data.get("inputs") or {}).get("location") or {}).get("elevation")
    return hourly


def _is_leap_day(label):
    return label[4:8] == "0229"


def pvgis_tmy(lat, lon, utc_offset, label_year, progress=None, refresh=False):
    """PVGIS-ERA5 typical meteorological year, shifted to local standard time and labelled label_year."""
    if progress:
        progress("PVGIS typical meteorological year", .2)
    url = PVGIS_URL + "tmy?" + urllib.parse.urlencode({"lat": f"{lat:.4f}", "lon": f"{lon:.4f}", "outputformat": "json"})
    data = _cached(url, lambda: _json(_fetch(url, timeout=120, retry=True), "PVGIS"), refresh=refresh)
    rows = (data.get("outputs") or {}).get("tmy_hourly")
    rows = [r for r in rows or [] if not _is_leap_day(r.get("time(UTC)") or r.get("time:UTC") or r["time"])]
    if len(rows) < 8760:
        raise ValueError("PVGIS returned no typical meteorological year for this location.")
    rows = rows[:8760]
    shift = float(((data.get("inputs") or {}).get("location") or {}).get("irradiance_time_offset", .5))
    cols = {"G(h)": "ghi", "Gb(n)": "dni", "Gd(h)": "dhi", "T2m": "temp", "WS10m": "ws10"}
    index = np.empty(len(rows), int)
    for i, row in enumerate(rows):
        label = row.get("time(UTC)") or row.get("time:UTC") or row["time"]
        index[i] = (date(2001, int(label[4:6]), int(label[6:8])) - date(2001, 1, 1)).days * 24 + int(label[9:11])
    series = {}
    for src, key in cols.items():
        if src in rows[0]:
            arr = np.full(8760, np.nan)
            arr[index] = [float(r[src]) for r in rows]
            series[key] = arr
    return _typical_year(series, utc_offset, label_year, shift)


def _typical_year(series, utc_offset, label_year, shift):
    """series: 8760 UTC values from a non-leap year -> local standard-time grid for label_year."""
    local = {k: np.roll(v, int(utc_offset)) for k, v in series.items()}
    grid = year_grid(label_year, label_year)
    src = np.array([_non_leap_index(t) for t in grid])
    return Hourly(grid, {k: v[src] for k, v in local.items()}, utc_offset, shift=shift)


def _non_leap_index(t):
    d = t.astype("datetime64[D]").astype(object)
    hour = int((t - t.astype("datetime64[D]")).astype("timedelta64[h]").astype(int))
    day = date(2001, d.month, 28 if (d.month == 2 and d.day == 29) else d.day)
    return (day - date(2001, 1, 1)).days * 24 + hour


def _pvwatts_module_type(gamma_pct):
    """PVWatts module classes: 0 standard (-0.47 %/K), 1 premium (-0.35 %/K), 2 thin film (-0.20 %/K); nearest to gamma."""
    return min(((0, -0.47), (1, -0.35), (2, -0.20)), key=lambda item: abs(item[1] - gamma_pct))[0]


def pvwatts(lat, lon, api_key, params, utc_offset, label_year, progress=None, refresh=False):
    """NREL PVWatts v8 (NSRDB/Intl TMY). The key travels in a header and never reaches cache keys or logs."""
    if not api_key or not re.fullmatch(r"[A-Za-z0-9]{20,64}", api_key):
        raise ValueError("Enter a valid NREL developer API key (free at developer.nrel.gov/signup).")
    query = {"lat": f"{lat:.4f}", "lon": f"{lon:.4f}", "system_capacity": 1000, "timeframe": "hourly",
             "module_type": _pvwatts_module_type(params.pop("gamma_pct", -0.35)), "dataset": params.get("dataset", "nsrdb")}
    query.update({k: v for k, v in params.items() if k != "dataset"})
    if progress:
        progress("NREL PVWatts v8", .3)
    url = PVWATTS_URL + "?" + urllib.parse.urlencode(query)
    raw = _fetch(url, headers={"X-Api-Key": api_key}, timeout=90, secrets=(api_key,), retry=True)
    data = _json(raw, "PVWatts")
    if data.get("errors"):
        raise ValueError("PVWatts: " + _scrub("; ".join(map(str, data["errors"])), (api_key,))[:300])
    out = data.get("outputs") or {}
    dc = out.get("dc")
    if not dc or len(dc) != 8760:
        raise ValueError("PVWatts did not return 8760 hourly values.")
    series = {"pv": np.array(dc, float) / (query["system_capacity"] * 1000.0)}
    if out.get("tamb"):
        series["temp"] = np.array(out["tamb"], float)
    if out.get("poa"):
        series["poa"] = np.array(out["poa"], float)
    if out.get("wspd"):
        series["ws10"] = np.array(out["wspd"], float)
    hourly = _typical_year(series, 0, label_year, .5)   # PVWatts arrays already run in local standard time
    hourly.utc_offset = utc_offset
    hourly.station = (data.get("station_info") or {})
    return hourly


def eia930(api_key, respondent, first, last, utc_offset, progress=None, refresh=False):
    if not api_key or not re.fullmatch(r"[A-Za-z0-9]{20,64}", api_key):
        raise ValueError("Enter a valid EIA Open Data API key (free at eia.gov/opendata/register.php).")
    if not re.fullmatch(r"[A-Z0-9]{2,8}", respondent or ""):
        raise ValueError("Choose a balancing authority code such as CISO or PJM.")
    grid = year_grid(first, last)
    start = (grid[0] - np.timedelta64(int(utc_offset), "h") - np.timedelta64(24, "h")).astype(str)[:13]
    end = (grid[-1] - np.timedelta64(int(utc_offset), "h") + np.timedelta64(24, "h")).astype(str)[:13]
    base = {"frequency": "hourly", "data[0]": "value", "facets[respondent][]": respondent, "facets[type][]": "D",
            "start": start, "end": end, "sort[0][column]": "period", "sort[0][direction]": "asc", "length": 5000}
    values, stamps, offset, total = [], [], 0, None
    while total is None or offset < total:
        query = urllib.parse.urlencode({**base, "offset": offset})
        key = "eia:" + EIA_URL + "?" + query     # api_key is appended afterwards and is not part of the cache key
        url = EIA_URL + "?" + query + "&api_key=" + urllib.parse.quote(api_key)
        page = _cached(key, lambda: _json(_fetch(url, timeout=60, secrets=(api_key,), retry=True), "EIA"), refresh=refresh,
                       max_age=86400)
        body = page.get("response") or {}
        if "error" in page and not body:
            raise ValueError("EIA: " + _scrub(page["error"], (api_key,))[:200])
        total = int(body.get("total", 0))
        data = body.get("data") or []
        if not data:
            break
        for row in data:
            try:
                stamps.append(np.datetime64(row["period"][:13], "h"))
                values.append(float(row["value"]) if row.get("value") not in (None, "") else np.nan)
            except (KeyError, TypeError, ValueError):
                continue
        offset += len(data)
        if progress:
            progress(f"EIA-930 {respondent}: {min(offset, total):,} of {total:,} hours", .2 + .5 * min(1, offset / max(total, 1)))
    if not values:
        raise ValueError(f"EIA returned no hourly demand for {respondent} in {first}-{last}. Check the code and years "
                         "(EIA-930 hourly data start in mid-2015).")
    local = np.array(stamps) + np.timedelta64(int(utc_offset), "h")
    demand = place(grid, local, np.array(values))
    return Hourly(grid, {"demand": demand}, utc_offset)


def _stream_csv_hourly(url, wanted, shift_minutes=15):
    """Stream a (large) CSV and sum `wanted` column into hourly buckets. Returns {hour_iso: sum}."""
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        stream = _urlopen(request, timeout=120)
    except urllib.error.HTTPError as exc:
        if exc.code in (403, 404):
            raise ValueError("This building type is not available for that county/state in the NREL dataset.") from None
        raise ValueError(f"NREL data lake returned HTTP {exc.code}.") from None
    except (TimeoutError, OSError) as exc:
        raise ValueError(f"Cannot reach the NREL OEDI data lake ({_scrub(getattr(exc, 'reason', exc))[:100]}).") from None
    sums, tail, header = {}, "", None
    ti = vi = None
    with stream:
        while True:
            try:
                block = stream.read(1 << 20)
            except (TimeoutError, OSError) as exc:
                raise ValueError("The NREL download stalled; try again.") from None
            if not block:
                break
            text = tail + block.decode("utf-8", "replace")
            lines = text.split("\n")
            tail = lines.pop()
            for line in lines:
                if header is None:
                    header = next(csv.reader([line]))
                    if "timestamp" not in header or wanted not in header:
                        raise ValueError(f"Unexpected NREL file layout (missing {wanted}).")
                    ti, vi = header.index("timestamp"), header.index(wanted)
                    continue
                parts = line.rstrip("\r").split(",")
                if len(parts) <= max(ti, vi):
                    continue
                stamp = datetime.fromisoformat(parts[ti]) - timedelta(minutes=shift_minutes)
                key = stamp.strftime("%Y-%m-%dT%H")
                sums[key] = sums.get(key, 0.0) + float(parts[vi])
        if tail.strip() and header is not None:
            parts = tail.rstrip("\r").split(",")
            if len(parts) > max(ti, vi):
                key = (datetime.fromisoformat(parts[ti]) - timedelta(minutes=shift_minutes)).strftime("%Y-%m-%dT%H")
                sums[key] = sums.get(key, 0.0) + float(parts[vi])
    if not sums:
        raise ValueError("The NREL file contained no data rows.")
    return sums


def nrel_stock_hourly(stock, geo_id, btype, progress=None, refresh=False):
    """Hourly mean MW (stock total) for one building type, 2018 AMY, as an 8760 list."""
    column = "out.electricity.total.energy_consumption.kwh"
    if stock == "comstock":
        url = (OEDI_BASE + f"comstock_amy2018_release_2/timeseries_aggregates/by_county/upgrade=0/county={geo_id}/"
               f"up00-{geo_id.lower()}-{btype}.csv")
    else:
        url = (OEDI_BASE + f"resstock_amy2018_release_2/timeseries_aggregates/by_state/upgrade=0/state={geo_id}/"
               f"up00-{geo_id.lower()}-{btype}.csv")

    def produce():
        sums = _stream_csv_hourly(url, column)
        out = np.full(8760, np.nan)
        base = np.datetime64("2018-01-01T00", "h")
        for key, kwh in sums.items():
            index = int((np.datetime64(key, "h") - base).astype(int))
            if 0 <= index < 8760:
                out[index] = kwh / 1000.0
        if np.isnan(out).mean() > .02:
            raise ValueError("The NREL file does not cover a full 2018 year.")
        out, _ = fill_gaps(out)
        return [round(float(v), 6) for v in out]
    return np.array(_cached("nrel:" + url, produce, refresh=refresh), float)


# ------------------------------------------------------------------------------------------------- physics
def solar_position(times_utc, lat, lon):
    """Zenith and azimuth (deg from north, clockwise) for numpy datetime64 UTC instants; ~0.05 degree accuracy."""
    jd = times_utc.astype("datetime64[s]").astype(np.int64) / 86400.0 + 2440587.5
    n = jd - 2451545.0
    mean_lon = (280.460 + 0.9856474 * n) % 360
    g = np.radians((357.528 + 0.9856003 * n) % 360)
    ecl = np.radians(mean_lon + 1.915 * np.sin(g) + 0.020 * np.sin(2 * g))
    eps = np.radians(23.439 - 0.0000004 * n)
    dec = np.arcsin(np.sin(eps) * np.sin(ecl))
    ra = np.arctan2(np.cos(eps) * np.sin(ecl), np.cos(ecl))
    gmst = (18.697374558 + 24.06570982441908 * n) % 24
    ha = np.radians(gmst * 15 + lon) - ra
    phi = math.radians(lat)
    cosz = np.clip(math.sin(phi) * np.sin(dec) + math.cos(phi) * np.cos(dec) * np.cos(ha), -1, 1)
    az = np.arctan2(np.sin(ha), np.cos(ha) * math.sin(phi) - np.tan(dec) * math.cos(phi)) + math.pi
    return np.degrees(np.arccos(cosz)), np.degrees(az) % 360, jd


def poa_irradiance(times_utc, lat, lon, ghi, dni, dhi, tilt, azimuth, tracking="fixed", albedo=.2, max_angle=60.0):
    """Plane-of-array irradiance (W/m2), Hay-Davies sky diffuse; tracking: fixed|single_axis|vertical_axis|two_axis.

    azimuth is compass degrees (180 = south). Single-axis tracking is a horizontal north-south axis without
    backtracking. Returns (poa_w_m2, cos_zenith).
    """
    zen, az, jd = solar_position(times_utc, lat, lon)
    z, a = np.radians(zen), np.radians(az)
    cosz = np.cos(z)
    sun = np.stack([np.sin(z) * np.sin(a), np.sin(z) * np.cos(a), cosz])
    if tracking == "fixed":
        b, g = math.radians(tilt), math.radians(azimuth)
        normal = np.array([math.sin(b) * math.sin(g), math.sin(b) * math.cos(g), math.cos(b)])[:, None] * np.ones(len(z))
    elif tracking == "single_axis":
        theta = np.clip(np.arctan2(sun[0], np.maximum(sun[2], 1e-6)), -math.radians(max_angle), math.radians(max_angle))
        normal = np.stack([np.sin(theta), np.zeros_like(theta), np.cos(theta)])
    elif tracking == "vertical_axis":
        b = math.radians(tilt)
        normal = np.stack([math.sin(b) * np.sin(a), math.sin(b) * np.cos(a), math.cos(b) * np.ones_like(a)])
    elif tracking == "two_axis":
        normal = sun
    else:
        raise ValueError("Unknown tracking mode.")
    cos_aoi = np.clip((normal * sun).sum(axis=0), 0, 1)
    cos_tilt = np.clip(normal[2], -1, 1)
    doy = (jd - 2451544.5) % 365.25
    i0n = 1367.0 * (1 + 0.033 * np.cos(2 * math.pi * doy / 365.25))
    ai = np.clip(dni / i0n, 0, 1)
    rb = cos_aoi / np.maximum(cosz, 0.087)
    diffuse = dhi * (ai * rb + (1 - ai) * (1 + cos_tilt) / 2)
    ground = ghi * albedo * (1 - cos_tilt) / 2
    poa = dni * cos_aoi + diffuse + ground
    poa = np.where(cosz > 0.0, np.maximum(poa, 0), 0.0)
    return poa, cosz


def erbs_split(ghi, cosz, doy_i0n):
    """Erbs diffuse fraction decomposition for sources that provide GHI only."""
    i0h = np.maximum(doy_i0n * cosz, 1e-6)
    kt = np.clip(ghi / i0h, 0, 1.2)
    df = np.where(kt <= .22, 1 - .09 * kt,
                  np.where(kt <= .8, .9511 - .1604 * kt + 4.388 * kt**2 - 16.638 * kt**3 + 12.336 * kt**4, .165))
    dhi = np.where(cosz > .02, ghi * np.clip(df, 0, 1), 0.0)
    dni = np.where(cosz > .087, np.clip((ghi - dhi) / np.maximum(cosz, .087), 0, 1100), 0.0)
    return dni, dhi


def pv_unit_output(poa, temp, wind, temperature_effect=True, gamma=-0.0035, losses_pct=0.0):
    """Per-unit DC output (MW per MWdc at STC) from POA W/m2: Faiman cell temperature, linear power-temperature derate."""
    out = poa / 1000.0
    if temperature_effect:
        wind = np.where(np.isfinite(wind), wind, 1.0)
        cell = temp + poa / (25.0 + 6.84 * wind)
        out = out * (1 + gamma * (cell - 25.0))
    return np.clip(out * (1 - losses_pct / 100.0), 0, 2)


def wind_hub_speed(ws_ref, ref_height, hub_height, method="power", alpha=1 / 7, z0=0.03, ws_lower=None, lower_height=10.0):
    if method == "two_height" and ws_lower is not None:
        with np.errstate(divide="ignore", invalid="ignore"):
            shear = np.log(ws_ref / ws_lower) / math.log(ref_height / lower_height)
        shear = np.where(np.isfinite(shear) & (ws_lower > .5), np.clip(shear, 0.0, 0.6), alpha)
        return ws_ref * (hub_height / ref_height) ** shear
    if method == "log":
        if not 0 < z0 < min(ref_height, hub_height):
            raise ValueError("Roughness length must be positive and below both heights.")
        return ws_ref * math.log(hub_height / z0) / math.log(ref_height / z0)
    return ws_ref * (hub_height / ref_height) ** alpha


def turbine_power(speed, curve):
    spec = TURBINES.get(curve)
    if spec is None:
        raise ValueError("Unknown turbine curve.")
    vi, vr, vo = spec["cut_in"], spec["rated"], spec["cut_out"]
    ramp = (speed**3 - vi**3) / (vr**3 - vi**3)
    out = np.where(speed < vi, 0.0, np.where(speed < vr, ramp, 1.0))
    return np.where(speed >= vo, 0.0, np.clip(out, 0, 1))


STANDARD_AIR_DENSITY = 1.225   # kg/m3, the density power curves are quoted at (ISA sea level, 15 C)


def isa_pressure_kpa(elevation_m):
    return 101.325 * (1 - 2.25577e-5 * elevation_m) ** 5.25588


def air_density(temp_c, pressure_kpa, hub_height, sensor_height=2.0):
    """Air density (kg/m3) at hub height from surface temperature and pressure (ideal gas, standard lapse 6.5 K/km)."""
    t_surface = np.asarray(temp_c, float) + 273.15
    t_hub = t_surface - 0.0065 * (hub_height - sensor_height)
    p_hub = np.asarray(pressure_kpa, float) * (t_hub / t_surface) ** 5.25588
    return p_hub * 1000.0 / (287.05 * t_hub)


def density_adjusted_speed(speed, density):
    """IEC 61400-12-1 normalisation: the power curve at standard density responds to v * (rho / 1.225)^(1/3)."""
    return speed * (density / STANDARD_AIR_DENSITY) ** (1.0 / 3.0)


def shape_profile(kind, weekday_flag):
    spec = TYPICAL[kind]
    pts = spec["wd" if weekday_flag else "we"]
    hours = np.arange(24) + .5
    return np.interp(hours, [p[0] for p in pts], [p[1] for p in pts])


def typical_load(weights, times, temp):
    """Weather-adjusted generic typical load shape (per unit of peak) on a local grid."""
    total = np.zeros(len(times))
    days = times.astype("datetime64[D]")
    hour = (times - days).astype("timedelta64[h]").astype(int)
    weekday = (days.astype("int64") + 3) % 7 < 5   # 1970-01-01 was a Thursday
    months = days.astype("datetime64[M]").astype(int) % 12
    for kind, share in weights.items():
        spec = TYPICAL[kind]
        base = np.where(weekday, shape_profile(kind, True)[hour], shape_profile(kind, False)[hour])
        sens = 1 + spec["cool"] * np.maximum(0, temp - 18) + spec["heat"] * np.maximum(0, 12 - temp)
        season = np.array(spec["season"])[months] if spec["season"] else 1.0
        series = base * sens * season
        total += share * series / series.max()
    return total / total.max()


def thermal_proxy(temp, mode, balance_c, design_c, base_fraction, peak_mwth):
    if mode == "heating":
        degree, span = np.maximum(0, balance_c - temp), balance_c - design_c
    else:
        degree, span = np.maximum(0, temp - balance_c), design_c - balance_c
    if span <= 1:
        raise ValueError("Design temperature must differ from the balance temperature by more than 1 degC.")
    return peak_mwth * np.clip(base_fraction + (1 - base_fraction) * degree / span, 0, 1)


def remap_calendar(values8760, src_year, target_year, align_weekdays=True):
    """Relabel a one-year hourly series to target_year. Optionally pick source days with the same weekday (+-3 days)."""
    values = np.asarray(values8760, float).reshape(365, 24)
    out = []
    first = date(target_year, 1, 1)
    for n in range((date(target_year + 1, 1, 1) - first).days):
        d = first + timedelta(days=n)
        src = date(src_year, d.month, 28 if (d.month == 2 and d.day == 29) else d.day)
        index = (src - date(src_year, 1, 1)).days
        if align_weekdays:
            index = (index + ((d.weekday() - src.weekday() + 3) % 7) - 3) % 365
        out.append(values[index])
    return np.concatenate(out)


# ---------------------------------------------------------------------------------------------- pipeline
def _num(payload, key, default, lo, hi, integer=False):
    value = payload.get(key, default)
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{key} must be a number.") from None
    if not math.isfinite(number) or not lo <= number <= hi:
        raise ValueError(f"{key} must be between {lo} and {hi}.")
    return int(round(number)) if integer else number


def _choice(payload, key, default, allowed):
    value = payload.get(key, default)
    if value not in allowed:
        raise ValueError(f"{key} must be one of {', '.join(sorted(allowed))}.")
    return value


def _stamps(times):
    return [str(t).replace("T", " ") + ":00:00" for t in times]


def csv_text(times, columns):
    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator="\n")
    names = list(columns)
    writer.writerow(["timestamp"] + names)
    stamps = _stamps(times)
    for i, stamp in enumerate(stamps):
        writer.writerow([stamp] + [f"{columns[n][i]:.6g}" if abs(columns[n][i]) < 1e5 else f"{columns[n][i]:.3f}" for n in names])
    return buffer.getvalue()


def statistics(kind, times, values, missing, extra=None):
    values = np.asarray(values, float)
    peak = float(values.max())
    days = times.astype("datetime64[D]")
    day_ids, inv = np.unique(days, return_inverse=True)
    daily = np.bincount(inv, weights=values) / np.bincount(inv)
    hours = (times - days).astype("timedelta64[h]").astype(int)
    months = days.astype("datetime64[M]").astype(int) % 12
    stats = dict(rows=int(len(values)), first=_stamps(times[:1])[0], last=_stamps(times[-1:])[0],
                 mean=float(values.mean()), peak=peak, minimum=float(values.min()),
                 missing_pct=round(100.0 * missing, 3), years=round(len(values) / 8766.0, 2))
    if kind in ("solar", "wind"):
        stats["capacity_factor"] = stats["mean"]
        stats["annual_full_load_hours"] = stats["mean"] * 8766.0
    if kind in ("load",):
        stats["load_factor"] = stats["mean"] / peak if peak else 0.0
    stats.update(extra or {})
    preview = dict(daily=[round(float(v), 5) for v in daily], first_day=str(day_ids[0]),
                   diurnal=[round(float(values[hours == h].mean()), 5) for h in range(24)],
                   monthly=[round(float(values[months == m].mean()), 5) if (months == m).any() else None for m in range(12)])
    return stats, preview


def _safe_name(*parts):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", "_".join(str(p) for p in parts)).strip("_")[:120]


def _finish(kind, source, hourly_times, values, missing, column, payload, provenance, warnings, columns=None):
    csv_columns = columns or {column: values}
    text = csv_text(hourly_times, csv_columns)
    stats, preview = statistics(kind, hourly_times, values, missing, provenance.pop("_stats", None))
    digest = hashlib.sha256(text.encode()).hexdigest()
    stem = _safe_name(kind, source, payload.get("lat_tag", ""), digest[:8])
    folder = CACHE / "datasets"
    folder.mkdir(parents=True, exist_ok=True)
    provenance.update(retrieved_utc=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%SZ"), rows=stats["rows"],
                      sha256=digest, column=column, warnings=warnings, statistics=stats,
                      note="Planning proxy; see caveats. API keys are never stored.")
    (folder / (stem + ".csv")).write_text(text, encoding="utf-8")
    (folder / (stem + ".provenance.json")).write_text(json.dumps(provenance, indent=2, default=str), encoding="utf-8")
    return dict(file=dict(name=stem + ".csv", content=text), stats=stats, preview=preview, provenance=provenance,
                warnings=warnings, saved=dict(csv=stem + ".csv", provenance=stem + ".provenance.json"))


def _fill_hourly(hourly, names):
    missing, filled = 0.0, {}
    for name in names:
        if name in hourly.data:
            filled[name], fraction = fill_gaps(hourly.data[name])
            missing = max(missing, fraction)
    return filled, missing


def _location_tag(lat, lon):
    return f"{lat:.3f}_{lon:.3f}"


def weather_for(payload, lat, lon, source, utc_offset, progress, refresh):
    first, last = year_range(payload, 2005 if source == "pvgis" else 2001)
    label_year = _num(payload, "label_year", 2025, 2000, 2100, True)
    if source == "nasa_power":
        return nasa_power(lat, lon, first, last, utc_offset, progress, refresh), first, last, "NASA POWER hourly (MERRA-2/CERES)"
    if source == "pvgis":
        return (pvgis_series(lat, lon, first, last, utc_offset, None, progress, refresh), first, last,
                "PVGIS-ERA5 hourly series")
    if source == "pvgis_tmy":
        return pvgis_tmy(lat, lon, utc_offset, label_year, progress, refresh), label_year, label_year, \
            "PVGIS-ERA5 typical meteorological year"
    raise ValueError("Unknown weather source.")


def build_solar(payload, progress, refresh):
    lat, lon = _coordinates(payload)
    source = _choice(payload, "source", "nasa_power", {"nasa_power", "pvgis", "pvgis_tmy", "pvwatts"})
    offset = _num(payload, "utc_offset", default_offset(lon), -12, 14, True)
    label_year = _num(payload, "label_year", 2025, 2000, 2100, True)
    warnings = []
    params = dict(source=source, utc_offset_hours=offset)
    provenance = dict(kind="solar", latitude=lat, longitude=lon, parameters=params, caveats=[
        "Weather and irradiance resource only: satellite/reanalysis values, not measured at the site. "
        "PV output is computed afterwards by GenStudio from the PV parameters entered in the Solar PV inputs "
        "(tilt, azimuth, temperature coefficient, losses, DC/AC ratio, degradation).",
        "Hour labels are local STANDARD time (no daylight saving), UTC offset " + str(offset) + "."])
    payload = dict(payload, lat_tag=_location_tag(lat, lon))
    first, last = year_range(payload, 2005 if source == "pvgis" else 2001)
    names = ["ghi", "dni", "dhi", "temp", "ws10"]
    if source == "pvwatts":
        tracking = _choice(payload, "tracking", "fixed", {"fixed", "single_axis", "two_axis"})
        tilt = _num(payload, "tilt", min(60.0, abs(lat) * .76 + 3.1), 0, 90)
        azimuth = _num(payload, "azimuth", 180.0 if lat >= 0 else 0.0, 0, 360)
        types = {"fixed": 0, "single_axis": 3, "two_axis": 4}
        hourly = pvwatts(lat, lon, str(payload.get("api_key", "")).strip(),
                         dict(array_type=types[tracking], tilt=tilt, azimuth=azimuth % 360, losses=0.0, gamma_pct=-0.35,
                              dataset=_choice(payload, "dataset", "nsrdb", {"nsrdb", "intl"})),
                         offset, label_year, progress, refresh)
        hourly.data["poa_plane"] = hourly.data.pop("poa")
        names = ["poa_plane", "temp", "ws10"]
        first = last = label_year
        params.update(tracking=tracking, tilt_deg=tilt, azimuth_deg=azimuth)
        provenance.update(source="NREL PVWatts v8 (weather outputs)", url_pattern=PVWATTS_URL + "?lat&lon&system_capacity&array_type&tilt&azimuth&timeframe=hourly",
                          method="NSRDB/Intl typical meteorological year: plane-of-array irradiance, ambient temperature and wind speed "
                                 "as returned by PVWatts for the entered array geometry. No PVWatts power output is used.",
                          years=[label_year], licence=LICENCES["pvwatts"])
        warnings.append("PVWatts returns irradiance on the array plane (tilt, azimuth and tracking entered here). Enter the same "
                        "geometry in the Solar PV inputs; no GHI/DNI/DHI is available from this source.")
    elif source == "pvgis":
        hourly = pvgis_series(lat, lon, first, last, offset, dict(angle=0, aspect=0), progress, refresh)
        hourly.data["ghi"] = hourly.data.pop("poa")
        names = ["ghi", "temp", "ws10"]
        provenance.update(source="PVGIS-ERA5 seriescalc (horizontal plane)", url_pattern=PVGIS_URL + "seriescalc?lat&lon&startyear&endyear&angle=0&aspect=0&raddatabase=PVGIS-ERA5",
                          method="Hourly global horizontal irradiance G(h), air temperature and 10 m wind speed. Beam and diffuse "
                                 "components are derived at model time (Erbs split).",
                          licence=LICENCES["pvgis"], years=[first, last])
    elif source == "nasa_power":
        hourly = nasa_power(lat, lon, first, last, offset, progress, refresh)
        provenance.update(source="NASA POWER hourly point API", url_pattern=NASA_URL + "?parameters=ALLSKY_SFC_SW_DWN,ALLSKY_SFC_SW_DNI,ALLSKY_SFC_SW_DIFF,T2M,WS10M&community=RE&time-standard=UTC",
                          method="Hourly all-sky GHI, DNI and DHI, air temperature and 10 m wind speed, shifted to local standard time.",
                          licence=LICENCES["nasa_power"], years=[first, last])
        warnings.append("NASA POWER irradiance is satellite-derived at about 0.5 degree; expect biases of several percent "
                        "and smoothed local clouds. Prefer measured/site data for investment decisions.")
    else:
        hourly = pvgis_tmy(lat, lon, offset, label_year, progress, refresh)
        first = last = label_year
        provenance.update(source="PVGIS-ERA5 typical meteorological year", url_pattern=PVGIS_URL + "tmy?lat&lon&outputformat=json",
                          method="Typical-year GHI, DNI, DHI, air temperature and 10 m wind speed, shifted to local standard time.",
                          licence=LICENCES["pvgis"], years=[label_year])
        warnings.append("Typical meteorological year: not observed weather in the labelled year.")
    filled, missing = _fill_hourly(hourly, names)
    headers = {"ghi": "ghi_w_m2", "dni": "dni_w_m2", "dhi": "dhi_w_m2", "poa_plane": "poa_irradiance_w_m2",
               "temp": "temperature_c", "ws10": "wind_speed_10m_ms"}
    columns = {headers[k]: filled[k] for k in names if k in filled}
    if not any(k in columns for k in ("ghi_w_m2", "poa_irradiance_w_m2")):
        raise ValueError("The source returned no irradiance.")
    lead = columns.get("ghi_w_m2", columns.get("poa_irradiance_w_m2"))
    provenance["site"] = dict(latitude=lat, longitude=lon, utc_offset=offset)
    provenance["_stats"] = dict(annual_irradiation_kwh_m2=float(lead.sum() / 1000.0 * 8766.0 / len(lead)),
                                mean_temperature_c=float(columns["temperature_c"].mean()) if "temperature_c" in columns else None)
    if missing > .02:
        warnings.append(f"{missing * 100:.1f} % of hours were missing and were interpolated / diurnally filled.")
    result = _finish("solar_resource", source, hourly.times, lead, missing, next(iter(columns)), payload, provenance, warnings,
                     columns=columns)
    result["site"] = provenance["site"]
    return result


def build_wind(payload, progress, refresh):
    lat, lon = _coordinates(payload)
    source = _choice(payload, "source", "nasa_power", {"nasa_power", "pvgis"})
    offset = _num(payload, "utc_offset", default_offset(lon), -12, 14, True)
    hub = _num(payload, "hub_height", 100.0, 10, 200)
    curve = _choice(payload, "turbine", "iec2", set(TURBINES))
    method = _choice(payload, "shear_method", "two_height" if source == "nasa_power" else "power", {"two_height", "power", "log"})
    alpha = _num(payload, "shear_alpha", 1 / 7, 0, 0.6)
    z0 = _num(payload, "roughness_m", 0.03, 0.0001, 5)
    losses = _num(payload, "losses_pct", 0.0, 0, 60)
    density_on = bool(payload.get("density_correction", True))
    first, last = year_range(payload, 2005 if source == "pvgis" else 2001)
    pressure_kpa = None
    if source == "nasa_power":
        hourly = nasa_power(lat, lon, first, last, offset, progress, refresh)
        speed50, speed10 = fill_gaps(hourly.data["ws50"]), fill_gaps(hourly.data["ws10"])
        (ref, missing), (lower, _) = speed50, speed10
        values = wind_hub_speed(ref, 50.0, hub, method, alpha, z0, lower, 10.0)
        if "ps" in hourly.data:
            pressure_kpa = fill_gaps(hourly.data["ps"])[0]
    else:
        if method == "two_height":
            raise ValueError("Two-height shear needs NASA POWER (50 m and 10 m); choose power-law or log for PVGIS.")
        hourly = pvgis_series(lat, lon, first, last, offset, None, progress, refresh)
        ref, missing = fill_gaps(hourly.data["ws10"])
        values = wind_hub_speed(ref, 10.0, hub, method, alpha, z0)
        if hourly.elevation_m is not None:
            pressure_kpa = np.full(len(values), isa_pressure_kpa(float(hourly.elevation_m)))
    density = None
    equivalent = values
    if density_on and pressure_kpa is not None and "temp" in hourly.data:
        density = air_density(fill_gaps(hourly.data["temp"])[0], pressure_kpa, hub)
        equivalent = density_adjusted_speed(values, density)
    power = np.clip(turbine_power(equivalent, curve) * (1 - losses / 100.0), 0, 1)
    payload = dict(payload, lat_tag=_location_tag(lat, lon))
    spec = TURBINES[curve]
    caveats = ["Reanalysis wind speeds are spatial averages at tens of km and smooth turbulence and local terrain: "
               "capacity factors can be biased by 10 % or more. Use on-site measurements (met mast/lidar, >= 1 year) "
               "for any investment decision.",
               "Generic idealised power curve, not a manufacturer curve; no wake, icing, availability or "
               "turbulence effects unless entered as losses.",
               "Hour labels are local STANDARD time, UTC offset " + str(offset) + "."]
    density_text = ("; air-density correction v*(rho/1.225)^(1/3) with hub-height density from surface temperature and "
                    "pressure (mean %.4f kg/m3)" % float(np.mean(density)) if density is not None else
                    "; no air-density correction")
    provenance = dict(kind="wind", latitude=lat, longitude=lon, caveats=caveats,
                      source="NASA POWER hourly (WS50M/WS10M)" if source == "nasa_power" else "PVGIS-ERA5 seriescalc (WS10m)",
                      url_pattern=(NASA_URL + "?parameters=WS50M,WS10M,T2M,PS&community=RE&time-standard=UTC") if source == "nasa_power"
                      else PVGIS_URL + "seriescalc?lat&lon&startyear&endyear&raddatabase=PVGIS-ERA5",
                      method=f"{method} extrapolation to {hub:g} m, generic turbine curve {spec['label']} "
                             f"(cut-in {spec['cut_in']}, rated {spec['rated']}, cut-out {spec['cut_out']} m/s)" + density_text,
                      parameters=dict(hub_height_m=hub, shear_method=method, shear_alpha=alpha, roughness_m=z0, turbine=curve,
                                      losses_pct=losses, density_correction=density is not None, utc_offset_hours=offset),
                      years=[first, last], licence=LICENCES["nasa_power" if source == "nasa_power" else "pvgis"],
                      _stats=dict(mean_hub_wind_speed_ms=float(np.mean(values)),
                                  mean_reference_wind_speed_ms=float(np.mean(ref))))
    warnings = [caveats[0]]
    if density_on and density is None:
        warnings.append("Air-density correction skipped: the source returned no pressure/elevation or temperature.")
    if missing > .02:
        warnings.append(f"{missing * 100:.1f} % of hours were missing and were interpolated / diurnally filled.")
    return _finish("wind", source, hourly.times, power, missing, "wind_per_mw", payload, provenance, warnings)


def build_weather(payload, progress, refresh):
    lat, lon = _coordinates(payload)
    source = _choice(payload, "source", "nasa_power", {"nasa_power", "pvgis", "pvgis_tmy"})
    offset = _num(payload, "utc_offset", default_offset(lon), -12, 14, True)
    hourly, first, last, label = weather_for(payload, lat, lon, source, offset, progress, refresh)
    names = {"temp": "temperature_c", "ghi": "ghi_w_m2", "dni": "dni_w_m2", "dhi": "dhi_w_m2",
             "ws10": "wind_speed_10m_ms", "ws50": "wind_speed_50m_ms", "poa": "poa_irradiance_w_m2"}
    columns, missing = {}, 0.0
    for key, header in names.items():
        if key in hourly.data:
            columns[header], fraction = fill_gaps(hourly.data[key])
            missing = max(missing, fraction)
    if not columns:
        raise ValueError("The source returned no weather variables.")
    provenance = dict(kind="weather", latitude=lat, longitude=lon, source=label, years=[first, last],
                      parameters=dict(utc_offset_hours=offset), licence=LICENCES["nasa_power" if source == "nasa_power" else "pvgis"],
                      url_pattern=NASA_URL if source == "nasa_power" else PVGIS_URL,
                      method="Downloaded unchanged except for unit labelling, gap filling and time shift to local standard time.",
                      caveats=["Reanalysis/satellite weather, not station observations."])
    first_col = next(iter(columns))
    payload = dict(payload, lat_tag=_location_tag(lat, lon))
    result = _finish("weather", source, hourly.times, columns["temperature_c"] if "temperature_c" in columns else columns[first_col],
                     missing, first_col, payload, provenance, [], columns=columns)
    return result


def build_thermal(payload, progress, refresh):
    lat, lon = _coordinates(payload)
    source = _choice(payload, "source", "pvgis_tmy", {"nasa_power", "pvgis", "pvgis_tmy"})
    offset = _num(payload, "utc_offset", default_offset(lon), -12, 14, True)
    mode = _choice(payload, "mode", "heating", {"heating", "cooling"})
    peak = _num(payload, "peak_mwth", 1.0, 0.0001, 100000)
    balance = _num(payload, "balance_c", 15.0 if mode == "heating" else 18.0, -20, 40)
    hourly, first, last, label = weather_for(payload, lat, lon, source, offset, progress, refresh)
    temp, missing = fill_gaps(hourly.data["temp"])
    design = payload.get("design_c")
    if design in (None, ""):
        design = float(np.percentile(temp, 1 if mode == "heating" else 99))
    else:
        design = _num(payload, "design_c", 0.0, -60, 60)
    base = _num(payload, "base_fraction", .1 if mode == "heating" else 0.0, 0, .9)
    values = thermal_proxy(temp, mode, balance, design, base, peak)
    provenance = dict(kind="thermal", latitude=lat, longitude=lon, source=label, years=[first, last],
                      licence=LICENCES["nasa_power" if source == "nasa_power" else "pvgis"], url_pattern=PVGIS_URL if "pvgis" in source else NASA_URL,
                      method=f"{mode} degree-hour PROXY: heat = peak * (base + (1-base) * degree-hours / design degree-hours)",
                      parameters=dict(mode=mode, peak_mwth=peak, balance_c=balance, design_c=design, base_fraction=base,
                                      utc_offset_hours=offset),
                      caveats=["PROXY only: derived from outdoor temperature, not a metered or simulated thermal load. "
                               "No occupancy, process or storage effects; replace with the customer's heat data when available."])
    payload = dict(payload, lat_tag=_location_tag(lat, lon))
    return _finish("thermal", source, hourly.times, values, missing, "heat_mwth", payload, provenance,
                   [provenance["caveats"][0]])


def _scale_load(values, payload):
    peak = _num(payload, "peak_mw", 1.0, 0.0001, 1e6)
    basis = _choice(payload, "scale_basis", "peak", {"peak", "mean"})
    reference = float(values.max()) if basis == "peak" else float(values.mean())
    if reference <= 0:
        raise ValueError("The source profile is all zero.")
    return values * peak / reference, peak, basis


def build_load(payload, progress, refresh):
    source = _choice(payload, "source", "eia930", {"eia930", "comstock", "typical"})
    label_year = _num(payload, "label_year", 2025, 2000, 2100, True)
    align = bool(payload.get("align_weekdays", True))
    warnings = ["PROXY for planning only: not the customer's metered load. Replace with their own interval data when available."]
    if source == "eia930":
        respondent = str(payload.get("respondent", "")).strip().upper()
        offset = _num(payload, "utc_offset", BALANCING.get(respondent, ("", -5))[1], -12, 14, True)
        first, last = year_range(payload, 2016)
        hourly = eia930(str(payload.get("api_key", "")).strip(), respondent, first, last, offset, progress, refresh)
        demand = hourly.data["demand"].copy()
        demand[demand <= 0] = np.nan
        good = demand[np.isfinite(demand)]
        outliers = 0
        if len(good):
            limit = 3 * np.percentile(good, 99)
            outliers = int((demand > limit).sum())
            demand[demand > limit] = np.nan
        values, missing = fill_gaps(demand)
        values, peak, basis = _scale_load(values, payload)
        provenance = dict(kind="load", source=f"EIA-930 hourly demand, balancing authority {respondent}",
                          url_pattern=EIA_URL + "?frequency=hourly&facets[respondent][]=<BA>&facets[type][]=D&start&end (api_key not stored)",
                          method=f"Demand scaled so that annual {basis} = {peak:g} MW; EIA UTC periods shifted to local standard time "
                                 f"(UTC{offset:+d}); outliers above 3x the 99th percentile removed ({outliers}).",
                          parameters=dict(respondent=respondent, peak_mw=peak, scale_basis=basis, utc_offset_hours=offset),
                          years=[first, last], licence=LICENCES["eia930"],
                          caveats=["Balancing-authority demand covers a whole utility/ISO area, not one customer or site; "
                                   "shape is a proxy and the scale is yours."],
                          _stats=dict(outliers_removed=outliers))
        warnings.append("Whole-balancing-authority demand shape scaled to your peak.")
        payload = dict(payload, lat_tag=respondent)
        times = hourly.times
    elif source == "comstock":
        geo = str(payload.get("county_fips", "")).strip()
        state = str(payload.get("state", "")).strip().upper()
        comm, res = payload.get("commercial_types") or {}, payload.get("residential_types") or {}
        if not isinstance(comm, dict) or not isinstance(res, dict) or not (comm or res):
            raise ValueError("Select at least one building type and its share.")
        if len(comm) + len(res) > 6:
            raise ValueError("Select at most 6 building types per download (each file is 10-15 MB).")
        if comm and not re.fullmatch(r"[0-9]{5}", geo):
            raise ValueError("Enter the 5-digit county FIPS code (e.g. 06037 for Los Angeles County).")
        if res and state not in STATES:
            raise ValueError("Residential profiles are available by state; choose a state.")
        items, total_share = [], 0.0
        for stock, mapping, valid in (("comstock", comm, COMSTOCK_TYPES), ("resstock", res, RESSTOCK_TYPES)):
            for name, share in mapping.items():
                if name not in valid:
                    raise ValueError(f"Unknown building type {name}.")
                share = float(share)
                if not 0 < share <= 1000:
                    raise ValueError("Each building-type share must be positive.")
                items.append((stock, name, share))
                total_share += share
        mixed = np.zeros(8760)
        for number, (stock, name, share) in enumerate(items):
            if progress:
                progress(f"NREL {stock} {name} ({number + 1}/{len(items)}) - large file, please wait", .15 + .6 * number / len(items))
            geo_id = f"G{geo[:2]}0{geo[2:]}0" if stock == "comstock" else state
            series = nrel_stock_hourly(stock, geo_id, name, progress, refresh)
            mixed += series / series.sum() * share / total_share   # share = fraction of annual energy
        values = remap_calendar(mixed, 2018, label_year, align)
        times = year_grid(label_year, label_year)
        values, peak, basis = _scale_load(values, payload)
        missing = 0.0
        provenance = dict(kind="load", source="NREL End-Use Load Profiles (ComStock/ResStock 2024 R2, AMY 2018), aggregate timeseries",
                          url_pattern=OEDI_BASE + "comstock_amy2018_release_2/timeseries_aggregates/by_county/upgrade=0/county=<GEOID>/up00-<geoid>-<type>.csv "
                                      "(residential: resstock_amy2018_release_2/.../by_state/...)",
                          method=("Hourly means of 15-minute interval-ending kWh (local standard time) summed over the county's "
                                  "building stock of each type, each normalised to unit annual energy and mixed by your shares; "
                                  f"relabelled to {label_year}" + (" choosing days with the same weekday (+-3 days of season shift)" if align else "")
                                  + f"; scaled so annual {basis} = {peak:g} MW."),
                          parameters=dict(county_fips=geo, state=state, commercial_types=comm, residential_types=res, peak_mw=peak,
                                          scale_basis=basis, label_year=label_year, align_weekdays=align),
                          years=[2018], licence=LICENCES["comstock"],
                          caveats=["Simulated building stock under 2018 actual weather, not metered data; whole-county aggregate "
                                   "shape; holidays are not modelled."])
        warnings.append("Modelled 2018 building-stock shape (not observed load), relabelled to the chosen year.")
        payload = dict(payload, lat_tag=geo or state)
    else:
        lat, lon = _coordinates(payload)
        offset = _num(payload, "utc_offset", default_offset(lon), -12, 14, True)
        weights = payload.get("building_mix") or {}
        if not isinstance(weights, dict) or not weights:
            raise ValueError("Choose at least one typical building type.")
        clean = {}
        for name, share in weights.items():
            if name not in TYPICAL:
                raise ValueError(f"Unknown typical building type {name}.")
            if not 0 < float(share) <= 1000:
                raise ValueError("Each share must be positive.")
            clean[name] = float(share) / sum(float(s) for s in weights.values())
        weather_source = _choice(payload, "weather_source", "pvgis_tmy", {"pvgis_tmy", "nasa_power"})
        hourly, first, last, label = weather_for(dict(payload, label_year=label_year), lat, lon, weather_source, offset,
                                                 progress, refresh)
        temp, missing = fill_gaps(hourly.data["temp"])
        shape = typical_load(clean, hourly.times, temp)
        values, peak, basis = _scale_load(shape, payload)
        times = hourly.times
        provenance = dict(kind="load", source="Generic typical building load shapes + " + label,
                          url_pattern=(PVGIS_URL + "tmy?lat&lon") if weather_source == "pvgis_tmy" else NASA_URL,
                          method="Authored piece-wise typical weekday/weekend shapes per building type x simple cooling/heating "
                                 "temperature sensitivity from outdoor temperature, mixed by shares, scaled to peak.",
                          parameters=dict(building_mix=clean, peak_mw=peak, scale_basis=basis, weather_source=weather_source,
                                          utc_offset_hours=offset), years=[first, last],
                          licence=LICENCES["typical"] + " Weather: " + LICENCES["pvgis" if "pvgis" in weather_source else "nasa_power"],
                          caveats=["Illustrative generic shapes, not derived from a specific building; no holidays or special events."])
        warnings.append("Generic illustrative shape; the last-resort fallback when no better source is available.")
        payload = dict(payload, lat_tag=_location_tag(lat, lon))
    columns = {"load_mw": values}
    return _finish("load", source, times, values, missing, "load_mw", payload, provenance, warnings, columns=columns)


BUILDERS = {"solar": build_solar, "wind": build_wind, "weather": build_weather, "thermal": build_thermal, "load": build_load}


# ------------------------------------------------------------------------------------------------- jobs
_jobs = {}
_jobs_lock = threading.Lock()


def _run_job(job_id, kind, payload):
    def progress(message, fraction):
        with _jobs_lock:
            _jobs[job_id].update(message=message, progress=round(float(fraction), 3))
    try:
        result = BUILDERS[kind](payload, progress, bool(payload.get("refresh")))
        with _jobs_lock:
            _jobs[job_id].update(state="done", progress=1.0, message="Done.", result=result)
    except ValueError as exc:
        with _jobs_lock:
            _jobs[job_id].update(state="error", error=_scrub(exc, [str(payload.get("api_key", ""))]))
    except Exception as exc:   # unexpected: keep the server alive and the message free of secrets
        with _jobs_lock:
            _jobs[job_id].update(state="error", error=_scrub(f"{type(exc).__name__}: {exc}", [str(payload.get("api_key", ""))]))


def start_job(payload):
    kind = payload.get("kind")
    if kind not in BUILDERS:
        raise ValueError("kind must be one of " + ", ".join(BUILDERS) + ".")
    with _jobs_lock:
        for key in [k for k, v in _jobs.items() if time.time() - v["created"] > 3600]:
            del _jobs[key]
        if sum(1 for v in _jobs.values() if v["state"] == "running") >= 3:
            raise ValueError("Three downloads are already running; wait for one to finish.")
        job_id = uuid.uuid4().hex
        _jobs[job_id] = dict(state="running", progress=0.0, message="Starting...", created=time.time(), kind=kind)
    secret = dict(payload)
    threading.Thread(target=_run_job, args=(job_id, kind, secret), daemon=True).start()
    return dict(job=job_id)


def job_status(query):
    job_id = (query.get("id") or [""])[0]
    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        raise ValueError("Invalid job id.")
    with _jobs_lock:
        job = _jobs.get(job_id)
        if job is None:
            raise ValueError("Unknown or expired download job.")
        return {k: v for k, v in job.items() if k != "created"}


def dataset_file(query):
    name = (query.get("name") or [""])[0]
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,160}\.(csv|json)", name) or ".." in name:
        raise ValueError("Invalid file name.")
    path = CACHE / "datasets" / name
    if not path.is_file():
        raise ValueError("File not found.")
    return path.read_bytes(), "text/csv; charset=utf-8" if name.endswith(".csv") else "application/json"


def catalog(query=None):
    try:
        import pyarrow  # noqa: F401
        arrow = True
    except ImportError:
        arrow = False
    return dict(
        pyarrow_installed=arrow,
        turbines={k: dict(v) for k, v in TURBINES.items()},
        comstock_types=COMSTOCK_TYPES, resstock_types=RESSTOCK_TYPES,
        typical_types={k: v["label"] for k, v in TYPICAL.items()},
        states={k: dict(name=v[0], utc_offset=v[1], balancing_authorities=v[2]) for k, v in STATES.items()},
        balancing_authorities={k: dict(name=v[0], utc_offset=v[1]) for k, v in BALANCING.items()},
        licences=LICENCES,
        max_years=MAX_YEARS, current_year=datetime.now(timezone.utc).year,
        note="Parquet is not needed: NREL aggregate time series are read from the public CSV files.")


extensions.GET["tile"] = tile
extensions.GET["geocode"] = geocode
extensions.GET["ds_locate"] = locate
extensions.GET["ds_catalog"] = catalog
extensions.GET["ds_job"] = job_status
extensions.GET["ds_file"] = dataset_file
extensions.POST["ds_fetch"] = start_job
