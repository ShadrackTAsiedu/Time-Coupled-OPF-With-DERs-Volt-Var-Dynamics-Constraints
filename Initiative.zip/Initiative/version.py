"""Single source of truth for the product name, release version and build date."""

PRODUCT = "GenStudio"
VERSION = "1.0.0"
BUILD_DATE = "2026-10-17"


def label():
    return f"{PRODUCT} {VERSION} (build {BUILD_DATE})"
