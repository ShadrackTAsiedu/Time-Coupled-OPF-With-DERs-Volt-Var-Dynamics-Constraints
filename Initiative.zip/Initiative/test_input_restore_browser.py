"""Regression: existing/planned trailer inputs survive saved runs, drafts and technology switches (real Edge)."""

import json
from pathlib import Path
import socket
import subprocess
import sys
import time
import unittest
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
USER_RUN = "7791be18470745f8af5ef34fa3d208f8"
ROWS = """id => [...document.getElementById(id).children].map(card => Object.fromEntries(
    [...card.querySelectorAll('[data-key]')].map(i => [i.dataset.key, i.value])))"""


class TrailerInputRestoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        cls.base = f"http://127.0.0.1:{port}"
        cls.server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)],
                                      cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(100):
            try:
                urlopen(cls.base + "/api/defaults", timeout=.5).close()
                break
            except OSError:
                time.sleep(.1)
        cls.playwright = sync_playwright().start()
        cls.browser = cls.playwright.chromium.launch(executable_path=EDGE, headless=True)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()
        cls.server.terminate()
        cls.server.wait(10)

    def open(self, query=""):
        page = self.browser.new_context(viewport={"width": 1600, "height": 1000}).new_page()
        page.goto(self.base + "/" + query)
        page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=60000)
        return page

    def trailers(self, page, container):
        return [r for r in page.evaluate(ROWS, container) if r["technology"] == "Mobile Trailers"]

    def test_user_run_shows_existing_and_planned_trailers(self):
        if not (ROOT / "Application Runs" / USER_RUN / "run_configuration.json").exists():
            self.skipTest("user run not present")
        page = self.open("?run=" + USER_RUN)
        existing, planned = self.trailers(page, "existing-rows"), self.trailers(page, "planned-rows")
        self.assertEqual((existing[0]["pv_kw"], existing[0]["bess_kw"], existing[0]["bess_kwh"]), ("192", "480", "2240"))
        self.assertEqual((planned[0]["pv_kw"], planned[0]["bess_kw"], planned[0]["bess_kwh"]), ("840", "6342", "29600"))
        planned_solar = [r for r in page.evaluate(ROWS, "planned-rows") if r["technology"] == "Solar"]
        self.assertEqual([r["capacity_mw"] for r in planned_solar][:2], ["0.5", "10"])

    def test_saved_draft_with_zeroed_trailer_is_repaired_without_losing_entries(self):
        page = self.open()
        page.evaluate("""() => { const s = JSON.parse(JSON.stringify(schema));
            s.planned_generation = s.planned_generation.filter(r => r.technology !== 'Mobile Trailers' || r.status === 'existing')
              .map(r => r.technology === 'Mobile Trailers' ? {...r, name: 'Existing generation', pv_kw: 0, bess_kw: 0, bess_kwh: 2240} : r);
            restore({values: {}, application_version: 7, planned_generation: s.planned_generation}); }""")
        existing, planned = self.trailers(page, "existing-rows"), self.trailers(page, "planned-rows")
        self.assertEqual(len(existing), 1)
        self.assertEqual(existing[0]["name"], "Existing generation")
        self.assertEqual((existing[0]["pv_kw"], existing[0]["bess_kw"], existing[0]["bess_kwh"]), ("192", "480", "2240"))
        self.assertEqual(planned[0]["pv_kw"], "840")

    def test_current_schema_keeps_deliberately_removed_trailers(self):
        page = self.open()
        page.evaluate("""() => restore({values: {}, application_version: 7, planned_schema: PLANNED_SCHEMA,
            planned_generation: schema.planned_generation.filter(r => r.technology !== 'Mobile Trailers')}); """)
        self.assertEqual(self.trailers(page, "existing-rows") + self.trailers(page, "planned-rows"), [])
        self.assertEqual(page.evaluate("() => readPlanned()").__len__(), 3)
        self.assertEqual(page.evaluate("() => request(false).planned_schema"), 2)

    def test_technology_switch_keeps_entered_trailer_values(self):
        page = self.open()
        set_value = """([selector, value, event]) => { const el = document.querySelector(selector);
            el.value = value; el.dispatchEvent(new Event(event, {bubbles: true})); }"""
        card = "#existing-rows .input-row:first-child "
        page.evaluate(set_value, [card + "[data-key=pv_kw]", "321", "input"])
        page.evaluate(set_value, [card + "[data-key=technology]", "Solar", "change"])
        self.assertEqual(page.locator("#existing-rows [data-key=pv_kw]").count(), 0)
        page.evaluate(set_value, [card + "[data-key=technology]", "Mobile Trailers", "change"])
        self.assertEqual(page.eval_on_selector("#existing-rows [data-key=pv_kw]", "e => e.value"), "321")
        self.assertEqual(page.eval_on_selector("#existing-rows [data-key=bess_kwh]", "e => e.value"), "2240")


if __name__ == "__main__":
    unittest.main()
