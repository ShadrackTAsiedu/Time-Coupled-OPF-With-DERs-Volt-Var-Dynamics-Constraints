"""Validated independent hourly solar and thermal profiles, replayed by calendar."""

from collections import defaultdict
import csv
from datetime import datetime, timedelta
import io
import math

import numpy as np


def read_profile(file, dates, kind):
    columns = {"solar": ("solar_per_mw", "poa_irradiance_w_m2"),
               "wind": ("wind_per_mw",), "thermal": ("heat_mwth",),
               "poa": ("poa_irradiance_w_m2",), "ghi": ("ghi_w_m2",), "dni": ("dni_w_m2",), "dhi": ("dhi_w_m2",),
               "temperature": ("temperature_c", "temp_c", "air_temperature_c"),
               "windspeed": ("wind_speed_ms", "wind_speed_10m_ms")}[kind]
    rows = list(csv.DictReader(io.StringIO(file["content"].lstrip("\ufeff"))))
    if not rows or "timestamp" not in rows[0]:
        raise ValueError(f"{kind}: provide timestamp and one of {', '.join(columns)}.")
    available = [key for key in columns if key in rows[0]]
    if not available:
        raise ValueError(f"{kind}: missing {', '.join(columns)}.")
    key = available[0]
    limits = {"poa_irradiance_w_m2": 2000, "ghi_w_m2": 1500, "dni_w_m2": 1500, "dhi_w_m2": 1500,
              "wind_speed_ms": 80, "wind_speed_10m_ms": 80}
    seen, groups, exact = set(), defaultdict(list), {}
    for index, row in enumerate(rows, 2):
        try:
            date = datetime.fromisoformat(row["timestamp"])
            value = float(row[key])
        except (ValueError, KeyError, TypeError) as exc:
            raise ValueError(f"{kind} row {index}: invalid timestamp or {key}.") from exc
        if date.tzinfo or date.minute or date.second or date.microsecond or date in seen:
            raise ValueError(f"{kind} row {index}: use unique timezone-free hourly timestamps.")
        if (not math.isfinite(value) or (kind != "temperature" and value < 0) or
                (kind == "temperature" and not -90 <= value <= 70) or
                (key == "solar_per_mw" and value > 2) or
                (key == "wind_per_mw" and value > 1) or
                value > limits.get(key, math.inf)):
            raise ValueError(f"{kind} row {index}: invalid nonnegative {key}.")
        if key == "poa_irradiance_w_m2" and kind == "solar":
            value /= 1000
        seen.add(date)
        exact[date] = value
        groups[(date.month, date.day, date.hour)].append(value)
    if all(date in exact for date in dates):
        result = np.array([exact[date] for date in dates])
        mode = "exact timestamps"
    else:
        expected = {(d.month, d.day, d.hour) for d in
                    (datetime(2001, 1, 1) + timedelta(hours=h)
                     for h in range(8760))}
        if not expected <= groups.keys():
            raise ValueError(f"{kind}: provide a complete calendar/rolling year or the full forecast horizon.")
        template = {k: float(np.mean(v)) for k, v in groups.items()}
        result = np.array([template[(d.month, 28 if d.month == 2 and d.day == 29 and
                                    (2, 29, d.hour) not in template else d.day, d.hour)]
                           for d in dates])
        mode = "calendar replay; leap day repeats February 28 if absent"
    return result, dict(name=file["name"], column=key, rows=len(rows), mapping=mode,
                        conversion="POA W/m2 / 1000; no AC clipping; derate/degradation applied separately"
                        if kind == "solar" else "MW per installed MW" if kind == "wind" else "MW thermal")


def read_wind(file, dates, curve="iec2"):
    """Wind resource -> unit output per MW. wind_per_mw is used as uploaded; hub-height wind_speed_ms is run through a power curve."""
    import datasources

    header = next(csv.reader(io.StringIO(file["content"].lstrip("\ufeff"))), [])
    if "wind_per_mw" in header or not any(c in header for c in ("wind_speed_ms", "wind_speed_10m_ms")):
        return read_profile(file, dates, "wind")
    speed, audit = read_profile(file, dates, "windspeed")
    audit.update(conversion=f"hub-height wind speed through the generic {datasources.TURBINES[curve]['label']} power curve; "
                 "use hub-height speeds, derate and degradation applied separately")
    return np.clip(datasources.turbine_power(speed, curve), 0, 1), audit


def read_solar(file, dates, values):
    """Hourly solar resource -> (unit DC output per MWdc, audit, converted).

    A unit PV profile (solar_per_mw) is used as given (converted=False). Irradiance files (POA, or GHI with optional
    DNI/DHI) plus optional air temperature and wind speed are converted with pv_model (converted=True).
    """
    import pv_model

    header = next(csv.reader(io.StringIO(file["content"].lstrip("\ufeff"))), [])
    if "solar_per_mw" in header:
        resource, audit = read_profile(file, dates, "solar")
        audit.update(basis="uploaded unit PV profile", conversion="MW per MW as uploaded; no irradiance conversion; "
                     "derate and degradation applied separately")
        return resource, audit, False
    params = pv_model.parameters(values)
    if "poa_irradiance_w_m2" in header:
        poa, audit = read_profile(file, dates, "poa")
        basis = "plane-of-array irradiance used directly"
    elif "ghi_w_m2" in header:
        ghi, audit = read_profile(file, dates, "ghi")
        optional = {name: read_profile(file, dates, name)[0] if column in header else None
                    for name, column in (("dni", "dni_w_m2"), ("dhi", "dhi_w_m2"))}
        full = optional["dni"] is not None and optional["dhi"] is not None
        poa = pv_model.transpose(dates, ghi, optional["dni"] if full else None, optional["dhi"] if full else None, params)
        basis = (f"GHI{'/DNI/DHI' if full else ' (Erbs split)'} transposed to {params['pv_tilt']:g} deg tilt, "
                 f"{params['pv_azimuth']:g} deg azimuth at {params['pv_latitude']:g}, {params['pv_longitude']:g}")
    else:
        raise ValueError("solar: provide solar_per_mw, poa_irradiance_w_m2, or ghi_w_m2 (+ optional dni_w_m2, dhi_w_m2).")
    names = ("temperature_c", "temp_c", "air_temperature_c")
    temp = read_profile(file, dates, "temperature")[0] if any(n in header for n in names) else None
    wind_columns = ("wind_speed_ms", "wind_speed_10m_ms")
    wind = read_profile(file, dates, "windspeed")[0] if any(n in header for n in wind_columns) else None
    resource = pv_model.unit_dc(poa, temp, wind, params)
    audit.update(basis=basis, conversion=(
        f"cell temperature ({params['pv_temp_model']}, coefficient {params['pv_temp_coefficient']:g} %/C) -> DC per MWdc; "
        f"then system-loss derate, degradation and inverter limit at DC/AC {params['pv_dc_ac_ratio']:g}" if temp is not None else
        "no air temperature in the file: no thermal correction; DC per MWdc = POA/1000, then derate, degradation and "
        "inverter limit"), temperature_used=temp is not None, wind_used=wind is not None,
        mean_poa_w_m2=round(float(np.mean(poa)), 4))
    return resource, audit, True


def extend_appraisal(data, values):
    """Repeat final forecast gross load; redispatch each tail year with physical aging."""
    from demand_forecasting import planning_dates
    from planning_inputs import planned_profiles, apply_planned_net_load
    from planning_tariffs import tariffs

    years = int(values["horizon_years"])
    appraisal = int(values["appraisal_years"]) if values.get("extended_appraisal") else years
    if appraisal <= years:
        return data
    dates = planning_dates(data["dates"][0].year, appraisal)
    last = { (d.month, d.day, d.hour): i for i, d in enumerate(data["dates"])
            if d.year == data["dates"][-1].year }
    def source(d):
        if d <= data["dates"][-1]:
            return int((d - dates[0]).total_seconds() // 3600)
        return last[(d.month, 28 if d.month == 2 and d.day == 29 and
                     (2, 29, d.hour) not in last else d.day, d.hour)]
    ids = np.array([source(d) for d in dates])
    out = dict(data)
    out.update(dates=dates, years=np.array([d.year - dates[0].year for d in dates]),
               months=np.array([d.month for d in dates]),
               di=np.array([(d - dates[0]).days for d in dates]))
    out["mi"] = out["years"] * 12 + out["months"] - 1
    for key in ("gross_load", "gross_qmax", "gross_qmin", "solar_resource",
                "planned_solar_resource", "heat", "baseline_load"):
        out[key] = data[key][ids]
    out["load"], out["qmax"], out["qmin"] = (
        out[k].copy() for k in ("gross_load", "gross_qmax", "gross_qmin"))
    solar_age = out["years"] % int(values["pv_life"]) if values["include_replacements"] else out["years"]
    out["solar"] = (out["solar_resource"] * values["solar_derate"] *
                    (1 - values["solar_degradation"])**solar_age)
    if data.get("pv_dc_ac_ratio"):
        out["solar"] = np.minimum(out["solar"] * data["pv_dc_ac_ratio"], 1.0)
    if "wind_resource" in data:
        out["wind_resource"] = data["wind_resource"][ids]
        age = out["years"] % int(values["wind_life"]) if values["include_replacements"] else out["years"]
        out["wind"] = out["wind_resource"] * values["wind_derate"] * (1-values["wind_degradation"])**age
    out.update(tariffs(dates, values))
    planned_profiles(out, data["forecast_audit"]["planned_generation"], values["solar_degradation"])
    apply_planned_net_load(out)
    out["forecast_horizon_years"] = years
    out["appraisal_years"] = appraisal
    return out
