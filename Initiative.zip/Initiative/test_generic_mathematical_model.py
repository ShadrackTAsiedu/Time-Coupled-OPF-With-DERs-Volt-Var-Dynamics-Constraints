"""Independent identities and implementation checks for the symbolic formulation."""

from datetime import datetime, timedelta
import math
import unittest

import numpy as np

import demand_forecasting as forecasting
import optimize_generation_mix as model
import scenario_analysis as finance


def synthetic_block():
    n = 24
    hours = np.arange(n)
    load = np.where((hours >= 16) & (hours < 21), 9.0, 4.0)
    return dict(
        dates=[datetime(2040, 1, 1) + timedelta(hours=int(t)) for t in hours],
        years=np.zeros(n, dtype=int), months=np.ones(n, dtype=int),
        mi=np.zeros(n, dtype=int), di=np.zeros(n, dtype=int),
        peak_window=hours >= 16, load=load, qmax=load + .4, qmin=load - .3,
        solar=np.maximum(0, np.sin((hours - 6) * math.pi / 12)),
        heat=np.full(n, 2.0), grid_energy=np.where(hours >= 16, 170., 37.),
        facility=np.full(12, 120.), tou=np.zeros(12), fixed=np.zeros(12),
    )


class GenericMathematicsTests(unittest.TestCase):
    def test_all_forecast_endpoints_and_normalized_hourly_extrema(self):
        q = np.array([.3, .8, 1., .6])
        for method, _ in forecasting.METHODS:
            np.testing.assert_allclose(
                forecasting.forecast_peaks([0, 1, 2], 7., 13., 1, method), [7, 13, 13])
            envelope = forecasting.forecast_peaks(np.arange(1, 5) / 4, 7., 13., 1, method)
            alpha = 13 * envelope / np.max(q * envelope)
            mean, lower, upper = alpha * q * .8, alpha * q * .6, alpha * q
            self.assertAlmostEqual(max(upper), 13)
            self.assertTrue(np.all(lower <= mean))
            self.assertTrue(np.all(mean <= upper))
            self.assertTrue(np.all(alpha > 0))

    def test_committed_renewable_partition(self):
        load = np.array([0., 3., 5., 7.])
        renewable = np.array([4., 2., 5., 9.])
        direct = np.minimum(load, renewable)
        residual = np.maximum(load - renewable, 0)
        surplus = np.maximum(renewable - load, 0)
        np.testing.assert_allclose(direct + residual, load)
        np.testing.assert_allclose(direct + surplus, renewable)

    def test_cyclic_battery_conservation_arbitrary_duration(self):
        for dt in (.2, .75, 1.5):
            eta_c, eta_d, charging = .91, .94, 3.7
            discharging = eta_c * eta_d * charging
            states = np.array([5., 5 + eta_c * charging * dt, 5.])
            change = np.array([eta_c * charging * dt, -discharging * dt / eta_d])
            np.testing.assert_allclose(np.diff(states), change)
            self.assertAlmostEqual(discharging * dt, eta_c * eta_d * charging * dt)

    def test_nominal_npv_identity_and_payback(self):
        inflation, discount = .021, .073
        ref_initial, alt_initial = 12., 18.
        ref_base, alt_base = np.array([11., 12., 13.]), np.array([6., 7., 8.])
        years = np.arange(1, 4)
        nominal_ref = ref_base * (1 + inflation)**years
        nominal_alt = alt_base * (1 + inflation)**years
        ref_npc = ref_initial + np.sum(nominal_ref / (1 + discount)**years)
        alt_npc = alt_initial + np.sum(nominal_alt / (1 + discount)**years)
        cashflows = [ref_initial - alt_initial, *(nominal_ref - nominal_alt)]
        metrics = finance.incremental_metrics(cashflows, discount)
        self.assertAlmostEqual(metrics["npv"], ref_npc - alt_npc)
        self.assertAlmostEqual(finance.payback([-9., 6., 6.]), 1.5)

    def test_objective_dimensions(self):
        # Exponents of (currency, electrical power, time).
        add = lambda a, b: tuple(x + y for x, y in zip(a, b))
        currency, power, time, energy = (1, 0, 0), (0, 1, 0), (0, 0, 1), (0, 1, 1)
        price_energy, capex_power, capex_energy = (1, -1, -1), (1, -1, 0), (1, -1, -1)
        self.assertEqual(add(price_energy, add(power, time)), currency)
        self.assertEqual(add(capex_power, power), currency)
        self.assertEqual(add(capex_energy, energy), currency)
        self.assertEqual(add(power, time), energy)

    def test_actual_dispatch_against_independently_written_equations(self):
        data = synthetic_block()
        cfg = model.default_settings()
        cfg.update(grid_limit=7.2, allow_unserved=True)
        caps = np.array([1.1, 3.2, 10.7, 2.4])
        block = model.MonthlyDispatch(data, 0, ["ng_chp"], False, data["solar"], settings=cfg)
        value, _ = block.evaluate(caps)
        op = block.operation()
        eta = math.sqrt(cfg["round_trip_efficiency"])
        np.testing.assert_allclose(op["grid"] + op["pv"] + op["gen"] + op["discharge"]
                                   - op["charge"] + op["shortfall"], data["load"], atol=1e-7)
        previous = np.r_[.5 * caps[2], op["soc"][:-1]]
        np.testing.assert_allclose(op["soc"] - previous,
                                   eta * op["charge"] - op["discharge"] / eta, atol=1e-7)
        self.assertAlmostEqual(op["soc"][-1], .5 * caps[2])
        self.assertAlmostEqual(op["discharge"].sum(),
                               cfg["round_trip_efficiency"] * op["charge"].sum())
        self.assertLess(np.minimum(op["charge"], op["discharge"]).max(), 1e-7)
        upper_margin, lower_margin = data["qmax"] - data["load"], data["load"] - data["qmin"]
        upper_ratio, lower_ratio = upper_margin / data["load"], lower_margin / data["load"]
        estimated_peak = op["grid"] + upper_margin - upper_ratio * op["shortfall"]
        self.assertLessEqual(estimated_peak.max(), cfg["grid_limit"] + 1e-7)
        self.assertGreaterEqual(np.min(op["grid"] + lower_ratio * op["shortfall"]
                                       - lower_margin), -1e-7)
        self.assertTrue(np.all(op["heat"] <= data["heat"] + 1e-7))
        spec = cfg["technology_parameters"]["ng_chp"]
        self.assertTrue(np.all(op["heat"] <= spec["ratio"] * op["gen"] + 1e-7))
        w = (1 + cfg["inflation"]) / (1 + cfg["discount"])
        cash = (op["grid"] @ data["grid_energy"] + data["facility"][0] * estimated_peak.max()
                + (spec["fuel"] + spec["vom"] + spec["carbon"]) * op["gen"].sum()
                - cfg["boiler_credit"] * op["heat"].sum())
        penalty = cfg["shortfall_priority_usd_mwh"] * (
            op["shortfall"].sum() + .25 * op["peak_only_shortfall"].sum())
        self.assertAlmostEqual(value * 1e6,
                               w * (cash + .01 * op["discharge"].sum()) + penalty, places=5)

    def test_actual_dual_cut_is_global_lower_support(self):
        data = synthetic_block()
        cfg = model.default_settings()
        cfg.update(grid_limit=7.2, allow_unserved=True)
        block = model.MonthlyDispatch(data, 0, ["ng_chp"], False, data["solar"], settings=cfg)
        anchor = np.array([1.1, 3.2, 10.7, 2.4])
        value, gradient = block.evaluate(anchor)
        rng = np.random.default_rng(7641)
        for _ in range(12):
            trial = anchor * rng.uniform(.6, 1.5, len(anchor))
            trial_value, _ = block.evaluate(trial)
            self.assertGreaterEqual(trial_value + 1e-7, value + gradient @ (trial - anchor))


class DocumentBuildTests(unittest.TestCase):
    def test_document_builds_and_documents_current_features(self):
        import export_generic_mathematical_model as exporter
        report = exporter.build_document()
        text = " ".join(p.text for p in report.doc.paragraphs)
        for needed in ("opt-in technology", "DC/AC ratio", "pro rata", "export is enabled", "cycling cost"):
            self.assertIn(needed, text.replace("Opt-in technology", "opt-in technology"))
        for stale in ("exports earn no credit", "no separate DC/AC", "No generator unit commitment"):
            self.assertNotIn(stale, text)
        for forbidden in exporter.FORBIDDEN_TEXT:
            self.assertNotIn(forbidden, text)


if __name__ == "__main__":
    unittest.main()
