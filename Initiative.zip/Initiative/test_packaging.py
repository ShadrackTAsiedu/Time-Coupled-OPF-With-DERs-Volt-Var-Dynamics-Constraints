"""Packaging checks: declared dependencies cover the imports, launcher and notices exist, trailer workbook is consistent."""
import ast
import re
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PACKAGE_FOR_MODULE = {"docx": "python-docx", "highspy": "highspy", "lxml": "lxml", "pypdf": "pypdf", "numpy": "numpy",
                      "scipy": "scipy", "matplotlib": "matplotlib", "openpyxl": "openpyxl", "cycler": "matplotlib",
                      "pptx": "python-pptx", "PIL": "pillow", "fitz": "pymupdf"}
OPTIONAL = {"gurobipy", "pandas", "pvlib", "pyarrow", "playwright", "psspy"}


def requirement_names(name):
    names = set()
    for line in (ROOT / name).read_text(encoding="utf-8").splitlines():
        line = line.split("#")[0].strip()
        if line and not line.startswith("-"):
            names.add(re.split(r"[<>=!~ ]", line)[0].lower())
    return names


def top_level_imports(path):
    found = set()
    for node in ast.parse(path.read_text(encoding="utf-8")).body:
        if isinstance(node, ast.Import):
            found.update(a.name.split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            found.add(node.module.split(".")[0])
    return found


class PackagingTests(unittest.TestCase):
    def test_runtime_requirements_cover_application_imports(self):
        local = {p.stem for p in ROOT.glob("*.py")}
        stdlib = set(sys.stdlib_module_names)
        declared = requirement_names("requirements.txt")
        needed = set()
        for path in ROOT.glob("*.py"):
            if path.name.startswith(("test_", "_", "scratch")) or path.name in ("psse_check.py", "download_solar_profile.py"):
                continue
            for module in top_level_imports(path) - local - stdlib - OPTIONAL:
                needed.add(PACKAGE_FOR_MODULE.get(module, module))
        self.assertLessEqual(needed, declared, f"Undeclared runtime dependencies: {sorted(needed - declared)}")

    def test_dev_requirements_include_runtime_and_playwright(self):
        text = (ROOT / "requirements-dev.txt").read_text(encoding="utf-8")
        self.assertIn("-r requirements.txt", text)
        self.assertIn("playwright", requirement_names("requirements-dev.txt"))

    def test_launcher_and_notices_exist(self):
        launcher = (ROOT / "GenStudio.cmd").read_text(encoding="utf-8")
        self.assertIn("generation_app.py", launcher)
        self.assertIn("requirements.txt", launcher)
        notices = (ROOT / "THIRD_PARTY_NOTICES.md").read_text(encoding="utf-8")
        for name in ("Leaflet", "HiGHS", "OpenStreetMap", "Gurobi"):
            self.assertIn(name, notices)
        self.assertTrue((ROOT / "generation_ui" / "leaflet_LICENSE.txt").is_file())

    def test_readme_references_existing_files(self):
        readme = (ROOT / "GENERATION_APP_README.md").read_text(encoding="utf-8")
        for name in set(re.findall(r"`([A-Za-z_]+\.(?:py|cmd|txt))`", readme)):
            if name.startswith("result_"):
                continue
            self.assertTrue((ROOT / name).exists(), f"README mentions missing file {name}")

    def test_trailer_workbook_values(self):
        import build_trailer_workbook as builder
        from openpyxl import load_workbook
        original = builder.FOLDER
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            builder.FOLDER = Path(folder) / "sources"
            try:
                builder.main()
            finally:
                builder.FOLDER = original
            book = load_workbook(Path(folder) / "sources" / "mobile_trailer_capacity.xlsx")
        ratings = book["Per-unit ratings"]
        self.assertEqual(ratings["C4"].value, "=C3*B4/B3")
        self.assertAlmostEqual(1200 * 15 / 70, 257.142857, places=5)
        fleet = book["Fleet capacity"]
        self.assertEqual(fleet["G2"].value, "=(C2*'Per-unit ratings'!$B$3+D2*'Per-unit ratings'!$C$3)/1000")
        self.assertEqual(fleet["K4"].value, "=SUM(K2:K3)")


if __name__ == "__main__":
    unittest.main()
