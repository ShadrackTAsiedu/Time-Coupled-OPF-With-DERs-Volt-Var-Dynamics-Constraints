import csv
from datetime import datetime, timedelta
import io
from pathlib import Path
import tempfile
import unittest

import numpy as np

import demand_forecasting as forecasting
import generation_app as app
import optimize_generation_mix as model
import planning_inputs as planning
import scenario_analysis as finance
from test_generation_optimization import small_inputs


def short_data():
    data = small_inputs()
    return {k: v[:12] if k in ("facility", "tou", "fixed") else v[:288] for k, v in data.items()}


def csv_year(year, value):
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["timestamp", "load_mw"])
    for date in forecasting.planning_dates(year, 1):
        writer.writerow([str(date), value])
    return output.getvalue()


class ClientPlanningTests(unittest.TestCase):
    def request(self, **kwargs):
        return app.validate_request({"values": kwargs, "scenarios": ["R0", "P1", "CHP"]})

    def test_demand_audit_explains_every_megawatt_and_fails_loudly_on_a_deviation(self):
        request = self.request(horizon_years=2)
        request["planned_generation"] = planning.validate_projects([
            dict(name="PV", technology="Solar", capacity_mw=5, start_year=2027, end_year=2027),
            dict(name="EE", technology="Energy Efficiency", capacity_mw=1, start_year=2027, end_year=2027)])
        data, _ = app.make_data(request)
        report = data["forecast_audit"]["demand_audit"]
        self.assertLess(report["energy_balance_gap_mwh"], 1e-6)
        self.assertAlmostEqual(report["built_energy_mwh"] - report["efficiency_energy_mwh"] - report["planned_direct_energy_mwh"],
                               report["optimizer_energy_mwh"], places=3)
        self.assertGreater(report["efficiency_energy_mwh"], 0)
        np.testing.assert_allclose(data["gross_load"] - data["efficiency_reduction"], data["service_load"], atol=1e-9)
        planning.audit_demand(data, data["gross_load"])
        tampered = dict(data, load=data["load"] * 0.9)
        with self.assertRaisesRegex(ValueError, "deviates from the built load profile"):
            planning.audit_demand(tampered)
        with self.assertRaisesRegex(ValueError, "built profile"):
            planning.audit_demand(data, data["gross_load"] * 1.01)

    def test_exact_client_targets_plateau_and_every_hour_changes(self):
        request = self.request()
        data, _ = app.make_data(request)
        peaks = [data["gross_qmax"][data["years"] == yi].max() for yi in range(10)]
        expected = [34.5, 36, 37, 38, 41.5, 43.5, 45, 45, 45, 45]
        np.testing.assert_allclose(peaks, expected, rtol=0, atol=1e-9)
        self.assertEqual(len(data["load"]), 87672)
        self.assertLess(max(peaks), 56.49)
        self.assertEqual(data["annual_trajectory"][0]["peak_mw"], 33.34)
        for method, _ in forecasting.METHODS:
            request = self.request(horizon_years=1, forecast_method=method, shape_method="replay")
            shaped, _ = app.make_data(request)
            self.assertAlmostEqual(shaped["gross_qmax"].max(), 34.5)
            self.assertTrue(np.all(shaped["gross_load"] > shaped["baseline_load"]))
            self.assertTrue(np.all(shaped["qmin"] <= shaped["load"]))
            self.assertTrue(np.all(shaped["load"] <= shaped["qmax"]))

    def test_sparse_and_yoy_milestones(self):
        points = planning.milestone_csv("year,peak_mw,growth_percent,description\n"
            "2026,33.34,,Baseline\n2027,,5,EV rollout\n2028,,0,Hold\n2033,45,,Target\n")
        self.assertAlmostEqual(points[1]["peak_mw"], 33.34 * 1.05)
        self.assertAlmostEqual(points[2]["peak_mw"], points[1]["peak_mw"])
        for mode, _ in planning.INTERPOLATIONS:
            curve = planning.annual_trajectory(points, 10, mode)
            self.assertEqual(curve[-1]["peak_mw"], 45)
            self.assertAlmostEqual(curve[1]["peak_mw"], 35.007)
        with self.assertRaisesRegex(ValueError, "immediately preceding"):
            planning.milestone_csv("year,peak_mw,growth_percent\n2026,33.34,\n2030,,3\n")
        for text in ("year,peak_mw\n2026,nan\n2030,45", "year,peak_mw\n2026,33\n2026,35"):
            with self.assertRaises(ValueError):
                planning.milestone_csv(text)

    def test_separate_and_combined_uploads(self):
        history, projected = csv_year(2025, 10), csv_year(2027, 12)
        request = self.request(horizon_years=1)
        request.update(historical_files=[dict(name="history.csv", content=history)],
                       forecast_files=[dict(name="forecast.csv", content=projected)], planned_generation=[])
        data, _ = app.make_data(request)
        self.assertTrue(np.all(data["historical"]["load"] == 10))
        self.assertTrue(np.all(data["load"] == 12))
        self.assertEqual(data["annual_trajectory"][-1]["peak_mw"], 12)
        for explicit in (False, True):
            stream = io.StringIO()
            writer = csv.writer(stream)
            writer.writerow(["timestamp", "load_mw"] + (["profile_type"] if explicit else []))
            for text, kind in ((history, "historical"), (projected, "forecast")):
                for row in list(csv.reader(io.StringIO(text)))[1:]:
                    writer.writerow(row + ([kind] if explicit else []))
            request.update(historical_files=[], forecast_files=[],
                combined_files=[dict(name="combined.csv", content=stream.getvalue())])
            data, _ = app.make_data(request)
            self.assertTrue(np.all(data["load"] == 12))
            self.assertTrue(np.all(data["historical"]["load"] == 10))
        request["historical_files"] = [dict(name="also.csv", content=history)]
        with self.assertRaisesRegex(ValueError, "combined CSV or separate"):
            app.make_data(request)

    def test_project_commissioning_efficiency_and_vintage_degradation(self):
        request = self.request(horizon_years=3)
        request["planned_generation"] = [p for p in planning.PROJECTS if p["technology"] != "Mobile Trailers"]
        data, _ = app.make_data(request)
        rows = data["planned_annual"]
        np.testing.assert_allclose([r["solar_dc_mw"] for r in rows], [3.833333333333, 7.166666666667, 10.5])
        np.testing.assert_allclose([r["incremental_efficiency_peak_mw"] for r in rows], [.2, .4, .6])
        for yi, reduction in enumerate((.2, .4, .6)):
            sel = data["years"] == yi
            self.assertAlmostEqual(data["gross_qmax"][sel].max() -
                                   (data["qmax"][sel] + data["planned_solar_available"][sel]).max(), reduction)
            self.assertTrue(np.all(data["efficiency_reduction"][sel] >= 0))
        idx = np.flatnonzero((data["years"] == 1) & (data["solar"] > 0))[0]
        raw_resource = data["solar_resource"][idx]
        expected = (.5 + 10 / 3) * .995 + 10 / 3
        self.assertAlmostEqual(data["planned_solar_available"][idx], raw_resource * expected * .85)
        self.assertEqual(len(request["planned_generation"]), 3)
        self.assertNotIn("Micro-Grid", str(request["planned_generation"]))

    def test_mobile_trailers_existing_and_future_fleets(self):
        defaults = [p for p in planning.PROJECTS if p["technology"] == "Mobile Trailers"]
        rows = planning.validate_projects(defaults)
        self.assertAlmostEqual(rows[0]["capacity_mw"], 32 * 6 / 1000 * .4)
        self.assertAlmostEqual(rows[0]["energy_mwh"], 32 * 70 / 1000 * .4)
        self.assertAlmostEqual(rows[1]["capacity_mw"], (80 * 6 + 20 * 18) / 1000 * .4)
        self.assertAlmostEqual(rows[1]["energy_mwh"], (80 * 70 + 20 * 1200) / 1000 * .4)
        request = self.request(horizon_years=2)
        request["planned_generation"] = rows
        data, _ = app.make_data(request)
        first = data["years"] == 0
        stamps = np.array(data["dates"])
        before = first & (stamps < datetime(2027, 6, 1))
        after = data["years"] == 1
        self.assertAlmostEqual(data["planned_bess_mwh"][before].max(), rows[0]["energy_mwh"])
        self.assertAlmostEqual(data["planned_bess_mwh"][after].max(), rows[0]["energy_mwh"] + rows[1]["energy_mwh"])
        self.assertGreater(data["planned_solar_available"][after].max(), data["planned_solar_available"][before].max())

    def test_planned_bess_wind_and_reference_cost_exclusion(self):
        data = short_data()
        projects = planning.validate_projects([
            dict(name="Free PV", technology="Solar", capacity_mw=4, start_year=2027, end_year=2027),
            dict(name="Free battery", technology="BESS", capacity_mw=2, energy_mwh=8, start_year=2027, end_year=2027),
            dict(name="Wind sensitivity", technology="Wind", capacity_mw=2, capacity_factor=.3,
                 start_year=2027, end_year=2027)])
        planning.planned_profiles(data, projects, .005)
        cfg = app.settings_for(self.request(horizon_years=1)["values"])
        result = model.solve_decomposed(data, "R0", "Reference with plans", "none", reference=True, settings=cfg)
        self.assertEqual(result["caps"]["microgrid_total_ac_mw"], 0)
        self.assertEqual(result["economics"]["capex"], 0)
        self.assertEqual(result["economics"]["fixed_om_pv"], 0)
        self.assertEqual(result["economics"]["variable_om_pv"], 0)
        self.assertGreater(result["dispatch"]["pv"].sum(), 0)
        self.assertGreater(result["dispatch"]["discharge"].sum(), 0)
        self.assertLess(result["validation"]["max_constraint_violation_mw"], 5e-5)
        self.assertEqual(result["adequacy"]["unserved_hours"], 0)

    def test_bess_throughput_cost_is_cash_opex_and_reduces_cycling(self):
        base = app.settings_for(self.request(horizon_years=1)["values"])
        priced = dict(base, bess_throughput_cost=50.0)
        free = dict(base, bess_throughput_cost=0.0)
        a = model.solve_decomposed(short_data(), "P1", "Additional microgrid", "none", settings=priced)
        b = model.solve_decomposed(short_data(), "P1", "Additional microgrid", "none", settings=free)
        da, db = a["dispatch"]["discharge"].sum(), b["dispatch"]["discharge"].sum()
        self.assertLessEqual(da, db + 1e-6)
        row = a["economics"]["annual"][0]
        self.assertGreaterEqual(row["variable"], da * 50.0 * (1 + priced["inflation"]) - 1e-6)

    def test_microgrid_nameplate_and_low_grid_shortage(self):
        cfg = app.settings_for(self.request(horizon_years=1, grid_limit=.1)["values"])
        result = model.solve_decomposed(short_data(), "P1", "Additional microgrid", "none", settings=cfg)
        caps = result["caps"]
        total = caps["pv_dc_mw"] + caps["bess_mw"] + caps["generator_mw"]
        self.assertGreaterEqual(total, 8 - 1e-7)
        self.assertLessEqual(total, 10 + 1e-7)
        self.assertAlmostEqual(total, caps["microgrid_total_ac_mw"])
        self.assertGreater(result["adequacy"]["unserved_mwh"], 0)
        self.assertLessEqual(result["validation"]["max_quarter_hour_grid_mw"], .10005)

    def test_planned_bess_dual_cuts_remain_valid(self):
        data = short_data()
        data["planned_bess_mw"] = np.full(len(data["load"]), 2.0)
        data["planned_bess_mwh"] = np.full(len(data["load"]), 8.0)
        data["planned_solar_available"] = 3 * data["solar"]
        cfg = app.settings_for(self.request()["values"])
        sub = model.MonthlyDispatch(data, 0, "none", False, data["solar"], settings=cfg)
        caps = np.array([4, 2, 8, 0], dtype=float)
        cost, gradient = sub.evaluate(caps)
        for trial in (np.array([3, 1, 4, 0.]), np.array([5, 3, 12, 0.])):
            other, _ = sub.evaluate(trial)
            self.assertGreaterEqual(other + 1e-6, cost + gradient @ (trial - caps))

    def test_financial_metrics_and_emissions(self):
        metrics = finance.incremental_metrics([-100, 60, 60], .06)
        self.assertAlmostEqual(metrics["npv"], -100 + 60 / 1.06 + 60 / 1.06**2)
        self.assertAlmostEqual(metrics["irr"], .1306623863)
        self.assertAlmostEqual(metrics["simple_payback_years"], 1 + 40 / 60)
        self.assertIsNone(finance.incremental_metrics([70, 5, 5], .06)["irr"])
        self.assertIsNone(finance.incremental_metrics([70, -5, -5], .06)["irr"])
        self.assertIsNone(finance.incremental_metrics([-100, 5, 5], .06)["simple_payback_years"])
        self.assertIsNone(finance.incremental_metrics([-100, 230, -132], .06)["irr"])
        self.assertIn("Multiple IRRs", finance.incremental_metrics([-100, 230, -132], .06)["irr_note"])
        self.assertAlmostEqual(finance.payback([-100, 120, -50, 120]), 2.25)
        data = short_data()
        request = self.request(horizon_years=1, grid_emissions_t_mwh=.2, h2_emissions_kgco2_kg=11)
        cfg = app.settings_for(request["values"])
        reference = model.solve_decomposed(data, "R0", "Reference", "none", reference=True, settings=cfg)
        alternative = model.solve_decomposed(data, "A5", "Gas CHP", "ng_chp", settings=cfg)
        rows = finance.analyze([reference, alternative], request["values"])
        self.assertAlmostEqual(rows[1]["npv"], reference["economics"]["npc"] - alternative["economics"]["npc"])
        self.assertAlmostEqual(rows[0]["supply_co2e_t"], data["load"].sum() * .2)
        self.assertAlmostEqual(rows[0]["lcoe_usd_mwh"],
            reference["economics"]["npc"] / (data["load"].sum() / 1.06))
        request["values"]["emission_factors_confirmed"] = False
        self.assertIsNone(finance.analyze([reference], request["values"])[0]["supply_co2e_t"])
        unavailable = model.solve_decomposed(data, "R0", "Unknown emissions", "none", reference=True,
            settings=app.settings_for(request["values"]))
        self.assertIsNone(unavailable["economics"]["annual"][0]["grid_co2_t"])
        self.assertIsNone(finance.analyze([unavailable], request["values"])[0]["supply_co2e_t"])
        request["values"]["emission_factors_confirmed"] = True
        with tempfile.TemporaryDirectory() as directory:
            report = finance.publish(Path(directory), [reference, alternative], request["values"])
            self.assertEqual(len(report["metrics"]), 2)
            self.assertEqual(len(report["columns"]), len(report["rows"][0]))
            for value in report["rows"][1]:
                if isinstance(value, float):
                    self.assertEqual(value, round(value, 4))
            self.assertTrue((Path(directory) / "economic_analysis.docx").exists())
            self.assertTrue((Path(directory) / "economic_analysis.xlsx").exists())
        cfg["technology_parameters"]["h2"]["fuel"] = 0
        caps = dict(pv_dc_mw=0, bess_mw=0, bess_mwh=0, generator_mw=1)
        dispatch = {key: np.zeros(len(data["load"])) for key in ("gen", "heat", "pv", "grid", "discharge")}
        dispatch["gen"][:] = 1
        dispatch["grid"] = data["load"] - 1
        econ = model.economics(data, caps, dispatch, "h2", False, cfg)
        self.assertAlmostEqual(econ["annual"][0]["hydrogen_upstream_co2e_t"],
            len(data["load"]) / (33.33 * .35) * 11)

    def test_shortage_metrics_and_no_double_efficiency_on_reimport(self):
        request = self.request(horizon_years=1)
        data, _ = app.make_data(request)
        stream = io.StringIO()
        writer = csv.writer(stream)
        writer.writerow(app.HOURLY_COLUMNS)
        for i in range(len(data["load"])):
            writer.writerow(app.profile_row(data, i))
        imported = self.request(horizon_years=1)
        imported["forecast_files"] = [dict(name="export.csv", content=stream.getvalue())]
        roundtrip, _ = app.make_data(imported)
        np.testing.assert_allclose(roundtrip["load"], data["load"])
        np.testing.assert_allclose(roundtrip["gross_load"], data["gross_load"])
        cfg = app.settings_for(self.request(horizon_years=1, grid_limit=0)["values"])
        result = model.solve_decomposed(short_data(), "P1", "Shortage", "none", settings=cfg)
        metrics = finance.analyze([result], request["values"])[0]
        self.assertIsNone(metrics["npv"])
        self.assertIsNone(metrics["irr"])
        self.assertIn("Unserved demand", metrics["irr_note"])


if __name__ == "__main__":
    unittest.main()
