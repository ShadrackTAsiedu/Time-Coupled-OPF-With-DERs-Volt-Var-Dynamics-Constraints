"""Real Edge integration: input workspace, diagram, autosave, wind solve and PDF."""

import csv
import io
import json
import re
from pathlib import Path
import socket
import subprocess
import sys
import time
import unittest
from urllib.request import urlopen

from playwright.sync_api import sync_playwright
from pypdf import PdfReader

import demand_forecasting as forecast

ROOT = Path(__file__).resolve().parent
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"


class BrowserWorkflowTests(unittest.TestCase):
    def test_upload_build_solve_analyze_and_downloads(self):
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)],
                                  cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try:
                    with urlopen(base + "/api/defaults", timeout=.5) as response:
                        self.assertEqual(json.load(response)["application_version"], 7)
                    break
                except OSError:
                    time.sleep(.1)
            else:
                self.fail("Test server failed readiness.")
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
                context = browser.new_context(viewport={"width": 1600, "height": 1000}, accept_downloads=True)
                headers = {"Sec-Fetch-Site":"cross-site", "Sec-Fetch-Mode":"navigate", "Sec-Fetch-Dest":"document"}
                self.assertEqual(context.request.get(base + "/", headers=headers).status, 200)
                self.assertEqual(context.request.get(base + "/api/defaults", headers=headers).status, 403)
                self.assertEqual(context.request.post(base + "/api/summary-pdf", headers=headers, data={}).status, 403)
                page = context.new_page()
                errors = []
                page.on("pageerror", lambda exc: errors.append(str(exc)))
                def ready():
                    page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
                def menu(title, sub=None):
                    group = page.locator("#input-navigation details").filter(
                        has=page.locator("summary").filter(has_text=re.compile("^"+re.escape(title)+"$")))
                    if group.get_attribute("open") is None:
                        group.locator("summary").click()
                    if sub:
                        group.get_by_role("button", name=sub, exact=True).click()
                page.goto(base + "/")
                ready()
                self.assertEqual(page.locator("#input-navigation summary", has_text="Solver").count(), 0)
                self.assertFalse(page.locator("#solver_method").is_visible())
                self.assertNotIn("future provision", page.locator("body").inner_text())
                menu("Existing/Planned Generation","Existing")
                self.assertEqual(page.locator("#existing-rows [data-key=technology]").evaluate_all(
                    "els=>els.filter(e=>e.value==='Mobile Trailers').length"),1)
                self.assertEqual(page.locator("#trailer-ribbon, #add-trailer, #trailer-availability").count(),0)
                self.assertEqual(page.locator("#existing-rows [data-key=pv_kw]").first.input_value(),"192")
                self.assertEqual(page.locator("#existing-rows [data-key=bess_kwh]").first.input_value(),"2240")
                self.assertEqual(page.locator("#planned-rows [data-key=pv_kw]").first.input_value(),"840")
                self.assertEqual(page.locator("#planned-rows [data-key=bess_kw]").first.input_value(),"6342")
                self.assertEqual(page.locator("#planned-rows [data-key=bess_kwh]").first.input_value(),"29600")
                menu("Demand")
                page.locator("#add-load").click()
                page.locator("#demand-workflow").select_option("generate")
                page.locator("#horizon_years").fill("1")
                self.assertTrue(page.locator("#forecast-controls").is_visible())
                self.assertTrue(page.locator("#forecast-upload-options").is_hidden())
                self.assertEqual(page.locator("aside #horizon_years").count(), 0)
                menu("Financial", "Discounting and appraisal period")
                page.locator("#appraisal_years").fill("2")
                menu("Grid and tariff", "Energy tariff")
                page.locator("#tariff_mode").select_option("tou")
                page.locator("#summer_same").uncheck()
                self.assertTrue(page.locator("#summer_peak_kwh").is_visible())
                page.locator("#tariff_mode").select_option("blended")
                menu("Scenarios", "Define scenarios")
                card = page.locator("#scenario-rows .input-row").nth(1)
                card.locator("[data-tech=wind]").check()
                card.locator("[data-key=name]").fill("Grid + PV + BESS + Wind")
                self.assertTrue(card.locator("[data-tech=wind]").is_enabled())
                menu("Scenarios", "Scenarios to optimize")
                for checkbox in page.locator("#scenarios input").all():
                    checkbox.set_checked(checkbox.get_attribute("id") in ("scenario-R0", "scenario-P1"))
                menu("Wind", "Costs and maintenance")
                page.locator("#wind_capex").fill("100000")
                menu("Wind", "Hourly resource")
                stream = io.StringIO()
                writer = csv.writer(stream)
                writer.writerow(["timestamp", "wind_per_mw"])
                writer.writerows((str(date), .5 if date.hour < 18 else .1)
                                 for date in forecast.planning_dates(2026, 1))
                page.locator("#wind-csv").set_input_files(dict(name="wind.csv", mimeType="text/csv",
                                                              buffer=stream.getvalue().encode()))
                page.wait_for_function("() => document.querySelector('#wind-file-status').textContent.includes('wind.csv')")
                menu("Demand")
                combined = io.StringIO()
                writer = csv.writer(combined)
                writer.writerow(["timestamp", "load_mw"])
                for year, value in ((2026, 10), (2027, 12)):
                    writer.writerows((str(date), value) for date in forecast.planning_dates(year, 1))
                page.locator("#demand-workflow").select_option("upload")
                page.locator("#combined-csv").set_input_files(dict(name="combined.csv", mimeType="text/csv",
                    buffer=combined.getvalue().encode()))
                page.wait_for_function("() => document.querySelector('#profile-uploads').textContent.includes('combined.csv')")
                menu("Microgrid", "Topology / single-line diagram")
                page.locator("#topology-sync").click()
                self.assertEqual(page.locator("#topology-svg [data-node]").count(), 5)
                # Connect each technology directly to Load through actual UI controls.
                page.locator("#topology-connect").click()
                nodes = page.locator("#topology-svg [data-node]")
                ids = nodes.evaluate_all("(items)=>items.map(e=>e.getAttribute('data-node'))")
                for key in ids[1:]:
                    page.locator(f"[data-node='{ids[0]}']").click()
                    page.locator(f"[data-node='{key}']").click()
                page.locator("#topology-connect").click()
                self.assertEqual(page.locator("#topology-svg [data-line]").count(), 4)
                page.locator("[data-topology-key=length_km]").fill("1.25")
                page.locator("[data-topology-key=length_km]").blur()
                page.locator("[data-topology-key=cost_per_km]").fill("12000")
                page.locator("[data-topology-key=cost_per_km]").blur()
                page.locator("#topology-enabled").check()
                first_node=page.locator(f"[data-node='{ids[0]}']")
                before=first_node.get_attribute("transform")
                box=first_node.bounding_box()
                cx,cy=box["x"]+box["width"]/2,box["y"]+box["height"]/2
                page.mouse.move(cx,cy)
                page.mouse.down();page.mouse.move(cx+80,cy+60,steps=8);page.mouse.up()
                self.assertNotEqual(first_node.get_attribute("transform"), before)
                # Manually route a wire via the canvas, then move its corner and segment handles.
                page.locator("#topology-connect").click()
                page.locator(f"[data-node='{ids[1]}'] [data-port=right]").click()
                canvas=page.locator("#topology-svg").bounding_box()
                page.mouse.click(canvas["x"]+canvas["width"]*.7,canvas["y"]+canvas["height"]*.8)
                page.locator(f"[data-node='{ids[2]}'] [data-port=bottom]").click()
                page.locator("#topology-select").click()
                self.assertEqual(page.locator("#topology-svg [data-line]").count(), 5)
                bend=page.locator("#topology-svg [data-bend]").first
                box=bend.bounding_box()
                page.mouse.move(box["x"]+6,box["y"]+6);page.mouse.down()
                page.mouse.move(box["x"]+40,box["y"]+26,steps=4);page.mouse.up()
                self.assertGreater(page.locator("#topology-svg [data-segment]").count(),0)
                segment=page.locator("#topology-svg [data-segment]").first
                box=segment.bounding_box()
                page.mouse.move(box["x"]+6,box["y"]+6);page.mouse.down()
                page.mouse.move(box["x"]+46,box["y"]+26,steps=4);page.mouse.up()
                segment=page.locator("#topology-svg [data-segment]").last
                box=segment.bounding_box()
                page.mouse.move(box["x"]+6,box["y"]+6);page.mouse.down(button="right")
                page.mouse.move(box["x"]+26,box["y"]+46,steps=4);page.mouse.up(button="right")
                page.locator("#topology-svg [data-bend]").first.click(button="right")
                self.assertTrue(page.get_by_role("button",name="Remove bend",exact=True).is_visible())
                page.get_by_role("button",name="Remove bend",exact=True).click()
                page.locator("#topology-undo").click();page.locator("#topology-redo").click()
                # Diagram-created technology changes scenario eligibility and edits canonical inputs.
                page.locator("[data-palette=diesel]").click()
                self.assertTrue(card.locator("[data-tech=diesel]").is_checked())
                page.locator("[data-linked-input=diesel_capex]").fill("12345")
                self.assertEqual(page.locator("#diesel_capex").input_value(),"12345")
                page.locator("#topology-delete").click()
                self.assertFalse(card.locator("[data-tech=diesel]").is_checked())
                # A user-created scenario starts with Load and Grid, follows added components, then can be deleted.
                page.locator("#topology-new").click()
                self.assertEqual(page.locator("#topology-svg [data-node]").count(),2)
                page.locator("[data-palette=pv]").click()
                self.assertTrue(page.evaluate("readScenarioRows().some(s=>s.name==='New scenario'&&s.technologies.includes('pv'))"))
                self.assertGreaterEqual(page.locator("#topology-tables tr").count(),4)
                page.locator("#topology-delete-scenario").click()
                self.assertFalse(page.evaluate("readScenarioRows().some(s=>s.name==='New scenario')"))
                # Each scenario keeps its own diagram and costs.
                page.locator("#topology-scenario").select_option("R0")
                page.locator("#topology-autodraw").click()
                self.assertEqual(page.locator("#topology-svg [data-node]").count(),3)
                self.assertEqual(page.locator("#topology-svg [data-line]").count(),2)
                # Renaming a defined scenario preserves its saved drawing.
                page.locator("#topology-scenario").select_option("NG")
                page.locator("#topology-autodraw").click()
                menu("Scenarios","Define scenarios")
                ng=page.locator("#scenario-rows .input-row").nth(3)
                ng.locator("[data-key=id]").fill("GAS");ng.locator("[data-key=id]").blur()
                menu("Microgrid","Topology / single-line diagram")
                self.assertEqual(page.locator("#topology-scenario").input_value(),"GAS")
                self.assertEqual(page.locator("#topology-svg [data-node]").count(),6)
                self.assertTrue(page.evaluate("!Object.hasOwn(topologyEditor.value().diagrams,'NG')"))
                page.locator("#topology-scenario").select_option("P1")
                self.assertEqual(page.locator("#topology-svg [data-line]").count(),5)
                # Input form changes are reflected when inspecting its diagram component.
                wind_id=page.evaluate("topologyEditor.value().diagrams.P1.nodes.find(n=>n.kind==='wind').id")
                page.locator(f"[data-node='{wind_id}']").click()
                page.locator("[data-linked-input=wind_capex]").fill("110000")
                menu("Wind","Costs and maintenance")
                self.assertEqual(page.locator("#wind_capex").input_value(),"110000")
                page.locator("#wind_capex").fill("120000")
                menu("Microgrid","Topology / single-line diagram")
                self.assertEqual(page.locator("[data-linked-input=wind_capex]").input_value(),"120000")
                # Pan and fit change only the view, not saved engineering coordinates.
                before_view=page.locator("#topology-svg").get_attribute("viewBox")
                page.locator("#topology-pan").click()
                page.locator("#topology-svg").scroll_into_view_if_needed()
                canvas=page.locator("#topology-svg").bounding_box()
                page.mouse.move(canvas["x"]+canvas["width"]*.5,canvas["y"]+canvas["height"]*.8)
                page.mouse.down();page.mouse.move(canvas["x"]+canvas["width"]*.5+40,canvas["y"]+canvas["height"]*.8+30);page.mouse.up()
                self.assertNotEqual(page.locator("#topology-svg").get_attribute("viewBox"),before_view)
                page.locator("#topology-select").click()
                page.mouse.move(canvas["x"]+canvas["width"]*.5,canvas["y"]+canvas["height"]*.5)
                zoom_before=page.locator("#topology-svg").evaluate("s=>s.viewBox.baseVal.width")
                page.mouse.wheel(0,-300)
                self.assertLess(page.locator("#topology-svg").evaluate("s=>s.viewBox.baseVal.width"),zoom_before)
                page.locator("#topology-fit").click()
                first,second=page.locator("#topology-svg [data-node]").nth(0),page.locator("#topology-svg [data-node]").nth(1)
                first.click();second.click(modifiers=["Control"])
                self.assertEqual(page.locator("#topology-svg .diagram-node.selected").count(),2)
                xs=page.evaluate("topologyEditor.value().diagrams.P1.nodes.map(n=>n.x+','+n.y)")
                box=first.bounding_box();page.mouse.move(box["x"]+box["width"]/2,box["y"]+box["height"]/2)
                page.mouse.down();page.mouse.move(box["x"]+box["width"]/2+60,box["y"]+box["height"]/2+40,steps=4);page.mouse.up()
                self.assertNotEqual(xs[:2],page.evaluate("topologyEditor.value().diagrams.P1.nodes.map(n=>n.x+','+n.y)")[:2])
                page.locator("#topology-fit").click();page.locator("#topology-select").click()
                page.locator("#save-draft").click()
                page.wait_for_function("() => document.querySelector('#draft-status').textContent.startsWith('Saved locally')")
                page.reload();ready()
                menu("Microgrid", "Topology / single-line diagram")
                self.assertEqual(page.locator("#topology-svg [data-line]").count(), 5)
                self.assertTrue(page.locator("#topology-enabled").is_checked())
                menu("Wind", "Hourly resource")
                self.assertIn("restored local draft", page.locator("#wind-file-status").inner_text())
                menu("Save & load")
                with page.expect_download() as settings_download:
                    page.locator("#save-inputs").click()
                settings = json.loads(Path(settings_download.value.path()).read_text(encoding="utf-8"))
                self.assertEqual(len(settings["topology"]["diagrams"]["P1"]["lines"]), 5)
                self.assertEqual(len(settings["topology"]["diagrams"]["R0"]["lines"]), 2)
                self.assertEqual(settings["wind_file"]["name"], "wind.csv")
                self.assertEqual(len(settings["combined_files"]), 1)
                page.locator("#tab-load").click()
                page.locator("#preview").click()
                page.wait_for_function("() => !document.querySelector('#preview').disabled", timeout=120000)
                self.assertTrue(page.locator("#error").is_hidden(), page.locator("#error").inner_text())
                self.assertEqual(page.locator("#load-plots img").count(), 2)
                self.assertTrue(page.locator("#download-forecast").is_visible())
                self.assertIn("hourly_projected_load.csv", page.locator("#download-forecast").get_attribute("href"))
                page.locator("#tab-solve").click()
                page.locator("#solve").click()
                self.assertEqual(page.locator("#solver-choice option").count(), 3)
                page.locator("#solver-choice").select_option("interior_point")
                page.locator("#confirm-solve").click()
                page.wait_for_function("() => !document.querySelector('#solve').disabled", timeout=300000)
                self.assertTrue(page.locator("#error").is_hidden(), page.locator("#error").inner_text())
                self.assertEqual(page.locator("#result-table tr").count(), 3)
                self.assertIn("Wind MW", page.locator("#result-table").inner_text())
                job = page.url.split("run=")[1]
                status = context.request.get(base + "/api/jobs/" + job).json()
                self.assertEqual(len(status["summary"]["results"]), 2, status.get("failures"))
                self.assertFalse(status["failures"], status["failures"])
                config = context.request.get(base + f"/files/{job}/run_configuration.json").json()
                self.assertEqual(len(config["request"]["topology"]["diagrams"]["P1"]["lines"]), 5)
                self.assertTrue(any(edge["points"] for edge in config["request"]["topology"]["diagrams"]["P1"]["lines"]))
                self.assertEqual(config["request"]["profile_file_hashes"]["wind_file"][0]["name"], "wind.csv")
                # Date controls and both plots are visible directly in Solve, not only Summary.
                self.assertTrue(page.locator("#dispatch-explorer").is_visible())
                page.wait_for_function("() => document.querySelectorAll('#dispatch-full svg path').length > 0")
                page.locator("#dispatch-period").select_option("month")
                page.locator("#dispatch-month").select_option("2")
                page.wait_for_function("() => document.querySelector('#dispatch-status').textContent.includes('672 saved hours')")
                self.assertTrue(page.locator("#dispatch-micro svg").is_visible())
                page.locator("#dispatch-boundary").select_option("grid-planned")
                page.locator("#tab-analyze").click();page.locator("#analyze").click()
                page.wait_for_function("() => !document.querySelector('#analyze').disabled", timeout=120000)
                self.assertTrue(page.locator("#error").is_hidden(), page.locator("#error").inner_text())
                page.locator("#tab-summary").click()
                self.assertEqual(page.locator("#summary-financial tr").count(), 3)
                page.wait_for_function("() => document.querySelectorAll('#dispatch-full svg path').length > 0")
                self.assertGreater(page.locator("#dispatch-micro svg path").count(),0)
                page.locator("#dispatch-start").fill("2027-02-01T00:00")
                page.locator("#dispatch-end").fill("2027-02-02T23:00")
                page.locator("#dispatch-apply").click()
                page.wait_for_function("() => document.querySelector('#dispatch-status').textContent.includes('48 saved hours')")
                self.assertTrue(page.locator("#dispatch-error").is_hidden())
                page.locator("#dispatch-all").click()
                page.wait_for_function("() => document.querySelector('#dispatch-status').textContent.includes('8,760 saved hours')")
                self.assertIn("mean MW bins",page.locator("#dispatch-status").inner_text())
                invalid=context.request.get(base+f"/api/dispatch?run={job}&scenario=P1&start=2028-01-01&end=2028-01-02")
                self.assertEqual(invalid.status,400)
                self.assertIn("explicit forecast horizon",invalid.json()["error"])
                with page.expect_download(timeout=60000) as download:
                    page.locator("#export-summary-pdf").click()
                pdf=Path(download.value.path())
                self.assertTrue(pdf.read_bytes().startswith(b"%PDF"))
                self.assertIn("Recommended option", "\n".join(p.extract_text() for p in PdfReader(pdf).pages))
                # An edit made after a saved solve must survive a reload at that run URL.
                menu("Wind", "Costs and maintenance")
                page.locator("#wind_capex").fill("123456")
                page.locator("#save-draft").click()
                page.wait_for_function("() => document.querySelector('#draft-status').textContent.startsWith('Saved locally')")
                page.reload();ready();menu("Wind", "Costs and maintenance")
                self.assertEqual(page.locator("#wind_capex").input_value(), "123456")
                # Interrupt a new worker; earlier saved solve/analysis remain accessible.
                page.locator("#tab-solve").click()
                page.locator("#solve").click();page.locator("#confirm-solve").click()
                page.wait_for_function("() => !document.querySelector('#stop-run').hidden")
                interrupted=page.url.split("run=")[1]
                page.locator("#stop-run").click()
                page.wait_for_function("() => !document.querySelector('#solve').disabled",timeout=30000)
                stopped=context.request.get(base+"/api/jobs/"+interrupted).json()
                self.assertEqual(stopped["state"],"cancelled")
                page.locator("#tab-summary").click()
                self.assertIn(job,page.locator("#summary-best").inner_text())
                page.reload();ready()
                page.locator("#tab-summary").click()
                self.assertIn(job,page.locator("#summary-best").inner_text())
                self.assertFalse(errors, errors)
                print("Verified workspace, diagram persistence, hourly Wind, saved solve/analysis and PDF:", job)
                browser.close()
        finally:
            server.terminate()
            server.wait(timeout=10)


if __name__ == "__main__":
    unittest.main()
