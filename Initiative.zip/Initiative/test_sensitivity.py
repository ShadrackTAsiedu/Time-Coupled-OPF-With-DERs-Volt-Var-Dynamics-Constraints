"""Sensitivity analysis: parameter mutation, base reproducibility inputs, risk statistics, applicability, caching."""
import json
import math
import tempfile
import unittest
from pathlib import Path
from statistics import NormalDist

import numpy as np

import planning_inputs
import sensitivity

ROOT = Path(__file__).resolve().parent


def record(label, npc, pv=5.0, bess=1.0, mwh=4.0, gens=None, changes=None):
    return dict(label=label, changes=changes or {}, ok=True, npc=npc, pv_mw=pv, bess_mw=bess, bess_mwh=mwh,
                generators=gens or {}, unserved_mwh=0.0)


class MutationTests(unittest.TestCase):
    def request(self):
        trailer = planning_inputs.validate_trailer(dict(name="T", status="planned", start_year=2027, pv_kw=1000,
                                                        bess_kw=2000, bess_kwh=8000, availability=.4))
        return dict(values=dict(ng_fuel_price=8, diesel_fuel_price=0, pv_capex=1e6, discount=.06, carbon_price=100),
                    planned_generation=[trailer, dict(technology="Solar", capacity_mw=1.0)])

    def test_percentage_and_absolute_changes(self):
        out = sensitivity.mutate(self.request(), dict(fuel_price=25, discount=.09, capex_pv=-20))
        self.assertAlmostEqual(out["values"]["ng_fuel_price"], 10.0)
        self.assertEqual(out["values"]["diesel_fuel_price"], 0)
        self.assertAlmostEqual(out["values"]["pv_capex"], 8e5)
        self.assertEqual(out["values"]["discount"], .09)

    def test_original_request_untouched(self):
        request = self.request()
        sensitivity.mutate(request, dict(fuel_price=50, trailer_availability=.9))
        self.assertEqual(request["values"]["ng_fuel_price"], 8)
        self.assertAlmostEqual(request["planned_generation"][0]["availability"], .4)

    def test_trailer_availability_rederives_capacities(self):
        out = sensitivity.mutate(self.request(), dict(trailer_availability=.8))
        trailer, solar = out["planned_generation"]
        self.assertAlmostEqual(trailer["capacity_mw"], 1.0 * .8)
        self.assertAlmostEqual(trailer["bess_mw"], 2.0 * .8)
        self.assertAlmostEqual(trailer["energy_mwh"], 8.0 * .8)
        self.assertEqual(solar, dict(technology="Solar", capacity_mw=1.0))

    def test_load_growth_ramp_is_zero_in_first_and_full_in_last_year(self):
        years = np.array([0, 0, 1, 2, 3])
        load = np.ones(5)
        out = sensitivity.apply_data(dict(load_growth=10), years, 4, load, load, load, load, load, load, load, load)[0]
        self.assertTrue(np.allclose(out, [1, 1, 1 + .1 / 3, 1 + .2 / 3, 1.1]))
        single = sensitivity.apply_data(dict(load_growth=10), np.zeros(2, int), 1, np.ones(2), np.ones(2), np.ones(2),
                                        np.ones(2), np.ones(2), np.ones(2), np.ones(2), np.ones(2))[0]
        self.assertTrue(np.allclose(single, 1.1))

    def test_demand_level_and_resource_scaling(self):
        ones = np.ones(3)
        load, qmax, qmin, solar, sres, psres, wind, wres = sensitivity.apply_data(
            dict(demand_level=-10, solar_resource=-6, wind_resource=12), np.zeros(3, int), 1, ones, ones, ones, ones,
            ones, ones, ones, ones)
        self.assertTrue(np.allclose([load[0], qmax[0], qmin[0]], .9))
        self.assertTrue(np.allclose([solar[0], sres[0], psres[0]], .94))
        self.assertTrue(np.allclose([wind[0], wres[0]], 1.12))


class ApplicabilityTests(unittest.TestCase):
    def test_reasons(self):
        request = dict(planned_generation=[dict(technology="Solar")])
        self.assertIn("mobile trailers", sensitivity.inapplicable("trailer_availability", request, ["grid"]))
        self.assertIsNone(sensitivity.inapplicable("trailer_availability",
                                                   dict(planned_generation=[dict(technology="Mobile Trailers")]), ["grid"]))
        self.assertIsNotNone(sensitivity.inapplicable("fuel_price", request, ["grid", "pv", "bess"]))
        self.assertIsNone(sensitivity.inapplicable("fuel_price", request, ["grid", "ng"]))
        self.assertIsNotNone(sensitivity.inapplicable("capex_bess", request, ["grid", "pv"]))
        self.assertIsNone(sensitivity.inapplicable("load_growth", request, ["grid"]))
        self.assertIsNotNone(sensitivity.inapplicable("wind_resource", request, ["grid"]))

    def test_defaults_skip_unavailable(self):
        self.assertTrue(set(sensitivity.catalog(dict())["defaults"]) <= set(sensitivity.DEFAULT_SELECTION))


class SourceFolderTests(unittest.TestCase):
    def test_carried_result_resolves_to_original_run(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
            runs = Path(tmp)
            for name, provenance in (("a" * 32, None), ("b" * 32, dict(status="carried_over", from_run="a" * 32)),
                                     ("c" * 32, dict(status="carried_over", from_run="b" * 32)),
                                     ("d" * 32, dict(status="re_solved", from_run="a" * 32))):
                folder = runs / name
                folder.mkdir()
                (folder / "request.json").write_text("{}", encoding="utf-8")
                (folder / "result_NG.json").write_text(json.dumps(dict(provenance=provenance) if provenance else {}),
                                                       encoding="utf-8")
            self.assertEqual(sensitivity.source_folder(runs / ("c" * 32), "NG"), runs / ("a" * 32))
            self.assertEqual(sensitivity.source_folder(runs / ("d" * 32), "NG"), runs / ("d" * 32))


class RiskStatisticsTests(unittest.TestCase):
    def test_z_value(self):
        self.assertAlmostEqual(sensitivity.Z90, NormalDist().inv_cdf(.9), places=12)
        self.assertAlmostEqual(sensitivity.Z90, 1.28155, places=4)

    def test_p10_p90_match_independent_normal_sum(self):
        base = record("Base case", 100e6)
        params = [dict(id="fuel_price", low=-30, high=30), dict(id="capex_pv", low=-25, high=25)]
        records = [record("f-", 90e6, changes=dict(fuel_price=-30)), record("f+", 112e6, changes=dict(fuel_price=30)),
                   record("p-", 97e6, changes=dict(capex_pv=-25)), record("p+", 103e6, changes=dict(capex_pv=25)),
                   record("Combined adverse case", 118e6), record("Combined favourable case", 87e6)]
        out = sensitivity.report({k: base[k] for k in ("npc", "pv_mw", "bess_mw", "bess_mwh", "generators", "unserved_mwh")},
                                 records, params, "NG", saved_npc=100.2e6)
        z = NormalDist().inv_cdf(.9)
        sd = math.hypot(22e6 / (2 * z), 6e6 / (2 * z))
        self.assertAlmostEqual(out["risk"]["sd"], sd, places=3)
        self.assertAlmostEqual(out["risk"]["p90"], 100e6 + z * sd, places=3)
        self.assertAlmostEqual(out["risk"]["p10"], 100e6 - z * sd, places=3)
        # a normal variable with that sd has 80 % of its mass between P10 and P90
        self.assertAlmostEqual(NormalDist(100e6, sd).cdf(out["risk"]["p90"]) - NormalDist(100e6, sd).cdf(out["risk"]["p10"]), .8, places=9)
        self.assertEqual([s["id"] for s in out["swings"]], ["fuel_price", "capex_pv"])
        self.assertEqual(out["risk"]["minimum"], 87e6)
        self.assertEqual(out["risk"]["maximum"], 118e6)
        self.assertTrue(out["base_check"]["consistent"])
        self.assertAlmostEqual(out["base_check"]["difference_pct"], 100 * (100e6 / 100.2e6 - 1))

    def test_base_check_flags_large_mismatch_and_minimum_includes_base(self):
        base = record("Base case", 394e6)
        out = sensitivity.report({k: base[k] for k in ("npc", "pv_mw", "bess_mw", "bess_mwh", "generators", "unserved_mwh")},
                                 [record("x", 400e6, changes=dict(fuel_price=30)), record("y", 410e6, changes=dict(fuel_price=-30))],
                                 [dict(id="fuel_price", low=-30, high=30)], "NG", saved_npc=219e6)
        self.assertFalse(out["base_check"]["consistent"])
        self.assertEqual(out["risk"]["minimum"], 394e6)

    def test_mix_change_ignores_solver_noise(self):
        a = record("a", 1, pv=6.683, bess=2.554, mwh=9.72, gens={"ng": .7626})
        self.assertFalse(sensitivity.mix_differs(a, record("b", 1, pv=6.69, bess=2.55, mwh=9.73, gens={"ng": .7626})))
        self.assertTrue(sensitivity.mix_differs(a, record("c", 1, pv=8.0, bess=2.554, mwh=9.72, gens={"ng": .7626})))
        self.assertTrue(sensitivity.mix_differs(a, record("d", 1, pv=6.683, bess=2.554, mwh=9.72, gens={})))


class CaseTests(unittest.TestCase):
    def test_combined_cases_use_adverse_and_favourable_ends(self):
        cases = sensitivity.build_cases([dict(id="fuel_price", low=-30, high=30), dict(id="solar_resource", low=-6, high=6),
                                         dict(id="discount", low=.04, high=.09)])
        by_label = {c[0]: c[1] for c in cases}
        self.assertEqual(by_label["Combined adverse case"], dict(fuel_price=30, solar_resource=-6, discount=.04))
        self.assertEqual(by_label["Combined favourable case"], dict(fuel_price=-30, solar_resource=6, discount=.09))
        self.assertEqual(len(cases), 8)

    def test_cache_key_depends_on_inputs(self):
        k = sensitivity.case_key("h", "NG", dict(fuel_price=30, capex_pv=5), "env")
        self.assertEqual(k, sensitivity.case_key("h", "NG", dict(capex_pv=5, fuel_price=30), "env"))
        self.assertNotEqual(k, sensitivity.case_key("h2", "NG", dict(fuel_price=30, capex_pv=5), "env"))
        self.assertNotEqual(k, sensitivity.case_key("h", "NG", dict(fuel_price=31, capex_pv=5), "env"))


if __name__ == "__main__":
    unittest.main()
