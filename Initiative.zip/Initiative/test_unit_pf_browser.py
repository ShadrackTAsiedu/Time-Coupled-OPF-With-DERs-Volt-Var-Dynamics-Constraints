"""Real Edge check of the operating-power-factor inputs (form fields, derived MVA/Mvar text, planned entries)."""

import json
from pathlib import Path
import socket
import subprocess
import sys
import time
import unittest
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"


class PfInputBrowser(unittest.TestCase):
    def test_pf_fields_derived_text_and_planned_entry(self):
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)],
                                  cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try:
                    with urlopen(base + "/api/defaults", timeout=.5) as response:
                        json.load(response)
                    break
                except OSError:
                    time.sleep(.1)
            else:
                self.fail("Test server failed readiness.")
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(executable_path=EDGE, headless=True)
                page = browser.new_context(viewport={"width": 1600, "height": 1000}).new_page()
                errors = []
                page.on("pageerror", lambda exc: errors.append(str(exc)))
                page.goto(base + "/")
                page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=30000)
                self.assertEqual(page.locator("#pv_pf").input_value(), "0.9")
                self.assertIn("1.111 MVA", page.locator("#pv_pf-derived").text_content())
                self.assertIn("0.484 Mvar", page.locator("#pv_pf-derived").text_content())
                page.locator("#pv_pf").evaluate("e => { e.value = '1'; e.dispatchEvent(new Event('input', {bubbles: true})); }")
                self.assertIn("1.000 MVA", page.locator("#pv_pf-derived").text_content())
                page.locator("#pv_pf").evaluate("e => { e.value = '0.7'; e.dispatchEvent(new Event('input', {bubbles: true})); }")
                self.assertIn("0.8 to 1.0", page.locator("#pv_pf-derived").text_content())
                self.assertEqual(page.locator("#cost_basis").input_value(), "per_mw_at_pf")
                self.assertGreaterEqual(page.locator("#bess_pf, #wind_pf, #ng_pf").count(), 3)
                self.assertEqual(errors, [])
                browser.close()
        finally:
            server.terminate()
            server.wait(timeout=10)


if __name__ == "__main__":
    unittest.main()
