"""Create the Mobile Trailer Sources folder: sources note and the gross/net capacity workbook."""
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

FOLDER = Path(__file__).with_name("Mobile Trailer Sources")
SOURCE = ("https://www.prnewswire.com/news-releases/universal-production-services--hollywood-trucks-partner-on-"
          "worlds-first-solar-off-grid-trailer-fleet-supporting-studio-grid-infrastructure-302749533.html")

NOTES = f"""MOBILE TRAILER SOURCES AND ASSUMPTIONS
=====================================

PRIMARY SOURCE (verified by reading the text)
  Universal Production Services and Hollywood Trucks, PR Newswire, 22 April 2026
  {SOURCE}
  - 53 ft Ecoluxe trailers: "over 1.2 MWh of battery storage and 18 kW of solar".
  - 40 ft Ecoluxe trailers: "70 kWh of battery storage and 6 kW of solar each".

SECONDARY / UNCONFIRMED (web summaries; spec-sheet PDFs on universalstudioslot.com are image-only)
  - 40 ft unit: 15 kW inverter and 5.5 kW emergency generator.
  - Treated here as the 40 ft BESS power rating (15 kW).

ASSUMPTIONS TO CONFIRM WITH THE SUPPLIER
  - 53 ft BESS power rating is NOT published. 257.1 kW is the 40 ft power/energy ratio (15 kW / 70 kWh)
    applied to 1,200 kWh. Replace it with the datasheet value.
  - "Over 1.2 MWh" is used as 1,200 kWh (conservative).
  - The user brief states 70 kWh and 6 kW PV for each trailer; the published 53 ft values are larger and are used
    for the 20 x 53 ft units.
  - Fleet: existing 32 x 40 ft (2026); future 80 x 40 ft + 20 x 53 ft (May-June 2027, modelled from 1 June 2027).
  - 40% of units are available on any given day (editable in the app).

MODEL TREATMENT
  - Net capacity = gross units x per-unit rating x availability.
  - Trailer PV uses the planned-solar hourly profile with derate and degradation; its output is deducted from load.
  - Trailer BESS is pooled with other committed BESS and dispatched physically; no cost is charged.
"""


def main():
    FOLDER.mkdir(exist_ok=True)
    (FOLDER / "sources_and_assumptions.txt").write_text(NOTES, encoding="utf-8")
    wb = Workbook()
    ws = wb.active
    ws.title = "Per-unit ratings"
    bold, fill = Font(bold=True), PatternFill("solid", fgColor="FFF2CC")
    ws.append(["Parameter", "40 ft", "53 ft", "Source / status"])
    ws.append(["PV kW per trailer", 6, 18, "PR Newswire 22 Apr 2026"])
    ws.append(["BESS kWh per trailer", 70, 1200, "PR Newswire; 53 ft is 'over 1.2 MWh'"])
    ws.append(["BESS kW per trailer", 15, "=C3*B4/B3", "40 ft: inverter rating (secondary); 53 ft ASSUMED by scaling"])
    ws.append(["Daily availability", 0.4, 0.4, "User input (editable)"])
    for cell in ws[1]:
        cell.font = bold
    for row in ws["B2:C5"]:
        for cell in row:
            cell.fill = fill
    ws2 = wb.create_sheet("Fleet capacity")
    ws2.append(["Fleet", "Commissioning", "40 ft units", "53 ft units", "Gross PV MW", "Gross BESS MW",
                "Gross BESS MWh", "Availability", "Net PV MW", "Net BESS MW", "Net BESS MWh"])
    for r, (name, date, n40, n53) in enumerate([("Existing", "2026-01-01", 32, 0),
                                               ("Future", "2027-06-01", 80, 20)], start=2):
        ws2.append([name, date, n40, n53,
                    f"=(C{r}*'Per-unit ratings'!$B$2+D{r}*'Per-unit ratings'!$C$2)/1000",
                    f"=(C{r}*'Per-unit ratings'!$B$4+D{r}*'Per-unit ratings'!$C$4)/1000",
                    f"=(C{r}*'Per-unit ratings'!$B$3+D{r}*'Per-unit ratings'!$C$3)/1000",
                    "='Per-unit ratings'!$B$5", f"=E{r}*H{r}", f"=F{r}*H{r}", f"=G{r}*H{r}"])
    ws2.append(["Total after future fleet", "", "=SUM(C2:C3)", "=SUM(D2:D3)", "=SUM(E2:E3)", "=SUM(F2:F3)",
                "=SUM(G2:G3)", "", "=SUM(I2:I3)", "=SUM(J2:J3)", "=SUM(K2:K3)"])
    for cell in ws2[1]:
        cell.font = bold
    for sheet in (ws, ws2):
        for column in sheet.columns:
            sheet.column_dimensions[column[0].column_letter].width = 26
    wb.save(FOLDER / "mobile_trailer_capacity.xlsx")


if __name__ == "__main__":
    main()
