import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import generation_app as app
import scenario_inputs


def values(**overrides):
    v = {f["key"]: f["default"] for f in app.FIELDS}
    v.update(trajectory_mode="model", baseline=33.34, target=45, target_years=10, horizon_years=1,
             extended_appraisal=False, microgrid_min_mw=0, microgrid_max_mw=1e12)
    v.update(overrides)
    return v


class ZeroGridLimitTests(unittest.TestCase):
    base = dict(grid_limit=0, topology={})

    def test_non_reference_zero_limit_is_islanded(self):
        cfg, _ = scenario_inputs.settings(dict(self.base), dict(id="G", technologies=["grid", "ng"]))
        self.assertTrue(cfg["islanded"])

    def test_reference_keeps_grid_semantics(self):
        cfg, _ = scenario_inputs.settings(dict(self.base), dict(id="R0", technologies=["grid"], reference=True))
        self.assertFalse(cfg.get("islanded", False))

    def test_positive_limit_not_islanded(self):
        cfg, _ = scenario_inputs.settings(dict(self.base, grid_limit=10), dict(id="G", technologies=["grid", "ng"]))
        self.assertFalse(cfg.get("islanded", False))


class StatusFileRaceTests(unittest.TestCase):
    def test_atomic_json_retries_permission_error(self):
        real = app.os.replace
        calls = []

        def flaky(src, dst):
            calls.append(1)
            if len(calls) < 3:
                raise PermissionError("in use")
            return real(src, dst)

        with tempfile.TemporaryDirectory() as d, mock.patch.object(app.os, "replace", flaky):
            path = Path(d) / "status.json"
            app.atomic_json(path, dict(state="running"))
            self.assertEqual(json.loads(path.read_text(encoding="utf-8")), dict(state="running"))
        self.assertEqual(len(calls), 3)

    def test_read_json_retry_survives_transient_errors(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "s.json"
            path.write_text('{"a": 1}', encoding="utf-8")
            real = Path.read_text
            calls = []

            def flaky(self, *a, **k):
                calls.append(1)
                if len(calls) == 1:
                    raise PermissionError("in use")
                if len(calls) == 2:
                    return "{"
                return real(self, *a, **k)

            with mock.patch.object(Path, "read_text", flaky):
                self.assertEqual(app.read_json_retry(path), {"a": 1})


class ZeroGridLimitSolveTest(unittest.TestCase):
    def test_ng_serves_load_when_grid_limit_zero(self):
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d) / ("c" * 32)
            folder.mkdir()
            request = dict(
                values=values(grid_limit=0),
                scenarios=["R0", "G"],
                scenario_definitions=[dict(id="R0", name="Ref", technologies=["grid"], reference=True),
                                      dict(id="G", name="NG", technologies=["grid", "ng"])],
                planned_generation=[])
            (folder / "request.json").write_text(json.dumps(request), encoding="utf-8")
            app.worker(folder)
            status = json.loads((folder / "status.json").read_text(encoding="utf-8"))
            self.assertEqual(status["state"], "complete", status.get("message"))
            result = {r["code"]: r for r in status["summary"]["results"]}["G"]
            self.assertLess(result["adequacy"].get("unserved_mwh", 0) or 0, 1e-3)
            self.assertLess(result["validation"]["hourly_balance_error_mw"], 1e-3)
            self.assertGreater(result["economics"]["npc"], 0)


if __name__ == "__main__":
    unittest.main()
