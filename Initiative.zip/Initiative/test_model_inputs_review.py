"""Model-input contracts: range messages, cross-field checks and unit-consistent help text."""

import unittest

import generation_app as app


class ModelInputReviewTests(unittest.TestCase):
    def request(self, **values):
        return app.validate_request(dict(values=values, scenarios=["R0", "P1"]))

    def test_range_message_uses_units_and_no_scientific_notation(self):
        with self.assertRaisesRegex(ValueError, r"Capacity fade must be between 0 and 0\.1 fraction/year"):
            self.request(bess_fade_per_year=.5)
        with self.assertRaisesRegex(ValueError, r"Installed capital cost must be at least 0 \$/MW AC"):
            self.request(pv_capex=-1)
        with self.assertRaises(ValueError) as caught:
            self.request(upgrade_cost=-5)
        self.assertNotIn("e+", str(caught.exception))

    def test_export_requires_positive_limit(self):
        with self.assertRaisesRegex(ValueError, "export limit is 0 MW"):
            self.request(export_enabled=True, export_limit_mw=0)
        self.request(export_enabled=True, export_limit_mw=2)

    def test_efficiency_help_names_the_heating_value_basis_per_technology(self):
        notes = {f["key"]: f["note"] for f in app.FIELDS if f["key"].endswith("_efficiency")}
        self.assertIn("lower-heating-value", notes["h2_efficiency"])
        self.assertIn("lower-heating-value", notes["h2_chp_efficiency"])
        self.assertIn("higher-heating-value", notes["ng_efficiency"])
        self.assertIn("higher-heating-value", notes["ng_chp_efficiency"])

    def test_every_numeric_default_lies_inside_its_limits(self):
        for f in app.FIELDS:
            if f["kind"] == "number":
                self.assertTrue(f["min"] <= f["default"] <= f["max"], f["key"])


if __name__ == "__main__":
    unittest.main()
