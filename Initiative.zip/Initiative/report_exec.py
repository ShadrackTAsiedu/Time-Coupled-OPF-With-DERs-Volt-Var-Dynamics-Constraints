"""Executive-level content of the client report: key-takeaway boxes and the one-page decision dashboard."""

import currency
import report as R
import report_charts as C

esc = R.esc


def box(items):
    items = [i for i in items if i]
    if not items:
        return ""
    return '<div class="takeaways"><div class="tk-title">Key takeaways</div><ul>' + "".join(f"<li>{esc(i)}</li>" for i in items) + "</ul></div>"


def _summary(run):
    """Result-summary data shared with the in-app dashboard (None when it cannot be built)."""
    if "_summary" not in run:
        try:
            import summary_data
            run["_summary"] = summary_data.build(run["run_id"], run)
        except Exception:
            run["_summary"] = None
    return run["_summary"]


def peak_and_share(run, code):
    import summary_data
    r = run["results"][code]
    return summary_data.peak_grid_import(r), summary_data.renewable_share(r), summary_data.grid_limit(run, r)


def sens_state(run, code, sens):
    """('PASS'|'WARN'|'NOT RUN', detail) for the probabilistic cost range of this option against the reference base NPC."""
    if not sens:
        return "NOT RUN", "Not run"
    rep = sens["report"]
    risk = rep.get("risk") or {}
    other = bool(sens.get("scenario_id")) and sens["scenario_id"] != code
    ref = run["results"].get(run["reference"])
    if risk.get("p90") is None:
        return "WARN" if other else "PASS", "Tornado analysis only" + ("; run for another scenario" if other else "")
    text = f"P50 {R.mil(risk['p50'], 1)}, P90 {R.mil(risk['p90'], 1)}"
    if other:
        return "WARN", text + f"; run for {sens['scenario_id']}"
    if ref and ref["code"] != code and risk["p90"] > ref["economics"]["npc"]:
        return "WARN", text + "; P90 above the reference base NPC"
    return "PASS", text


def economic_state(run, code):
    r = run["results"][code]
    em = R.economic_rows(run).get(code)
    if not R.is_feasible(r):
        return "FAIL", "Demand not fully served"
    if not em:
        return "NOT RUN", "Financial metrics unavailable"
    ref = run["results"].get(run["reference"])
    if em.get("warnings"):
        return "WARN", "See the notes in the economic analysis"
    if ref and ref["code"] != code and r["economics"]["npc"] > ref["economics"]["npc"]:
        return "WARN", "NPC higher than the reference"
    return "PASS", "Fully served, cost not above the reference" if ref and ref["code"] != code else "Reference case"


def chips(run, code, rel, sens):
    tech = R.technical(run["results"][code]) or {}
    pf = str(tech.get("status") or "NOT_RUN").upper()
    verdict = R.reliability_verdict(rel)
    summary = rel.get("summary") if rel else {}
    s = tech.get("summary") or {}
    econ, econ_text = economic_state(run, code)
    sens_status, sens_text = sens_state(run, code, sens)
    return [("Economic", econ, econ_text),
            ("Sensitivity", sens_status, sens_text),
            ("Reliability", verdict or "NOT RUN", f"{R.num(summary.get('lole_h_yr'), 1)} h/yr downtime, {R.num(summary.get('eue_mwh_yr'), 0)} MWh/yr unserved" if summary else "Not run"),
            ("Power flow", pf.replace("_", " "), f"{s.get('violations', 0)} findings; voltage {R.num(s.get('vmin'), 3)}-{R.num(s.get('vmax'), 3)} pu" if s else "Not run")]


def tile(label, value, note, level=""):
    note = str(note or "").replace("undefined", "not defined")
    return f'<div class="tile {level}"><span class="tl">{esc(label)}</span><b>{esc(value)}</b><span class="tn">{esc(note)}</span></div>'


def kpi_tiles(run, code):
    data = _summary(run)
    if data and data["recommended"]["code"] == code:
        keep = ["npc", "upfront", "lcoe", "npv", "renewable", "co2", "peak", "unserved"]
        by = {k["key"]: k for k in data["kpis"]}
        return "".join(tile(by[k]["label"], by[k]["value"], by[k].get("note", ""), by[k].get("level", "")) for k in keep if k in by)
    e = run["results"][code]["economics"]
    peak, share, limit = peak_and_share(run, code)
    unserved = e.get("unserved_mwh") or 0
    return "".join([tile("Net present cost", R.mil(e["npc"]), ""), tile("Upfront capital", R.mil(e["capex"]), ""),
                    tile("Levelized supply cost", f"${R.num(e.get('levelized_supply_cost_usd_mwh'), 1)}/MWh", ""),
                    tile("Renewable share", "n/a" if share is None else R.pct(100 * share, 1), "solar + wind + planned, of demand"),
                    tile("Peak grid import", f"{R.num(peak, 2)} MW", f"Limit {R.num(limit, 2)} MW" if limit else ""),
                    tile("Unserved energy", f"{R.num(unserved, 2)} MWh", "", "pass" if unserved < 1e-3 else "fail")])


def decision_box(run, code, best, feasible, info):
    r = run["results"][code]
    e, ref = r["economics"], run["results"].get(run["reference"])
    if feasible and code == best:
        head = f"Recommended option: {code} - {r['name']}"
    elif feasible:
        head = f"Reported option: {code} - {r['name']} (lowest-cost fully served option is {best})"
    else:
        head = f"No scenario serves all demand; {code} - {r['name']} is shown for completeness"
    lines = [f"<strong>Builds:</strong> {esc(R.caps_text(r['caps']))}."]
    if ref and ref["code"] != code:
        d = e["npc"] - ref["economics"]["npc"]
        lines.append(f"<strong>Cost:</strong> NPC {R.mil(e['npc'])}, {R.mil(abs(d))} {'below' if d <= 0 else 'above'} the reference {esc(ref['code'])} ({R.num(abs(100 * d / ref['economics']['npc']), 1)}%).")
    else:
        lines.append(f"<strong>Cost:</strong> NPC {R.mil(e['npc'])}.")
    if info and info.get("summary"):
        lines.append(f"<strong>Why:</strong> {esc(info['summary'][0])}")
    return f'<div class="decision"><div class="eyebrow">Decision at a glance</div><div class="dtitle">{esc(head)}</div>' + "".join(f"<p>{x}</p>" for x in lines) + "</div>"


def chip_cards(run, code, rel, sens):
    cards = "".join(f'<div class="chipcard"><div class="cn">{esc(name)}</div>{R.badge(status, R.status_kind(status))}<div class="cd">{esc(text)}</div></div>'
                    for name, status, text in chips(run, code, rel, sens))
    return ('<div class="chips">' + cards + "</div><p class='small muted'>PASS: criteria met. WARN: met with concerns or incomplete evidence (for example the option costs more than the reference, "
            "the P90 cost exceeds the reference, or a finding needs correction). FAIL: a criterion is violated, such as unserved energy. NOT RUN: the analysis was not run.</p>")


def exec_section(run, code, best, feasible, info, rel, sens, risks, steps):
    top = [x for x in risks if x["rating"] == "High"] or [x for x in risks if x["rating"] == "Medium"]
    out = [decision_box(run, code, best, feasible, info), '<div class="tiles">' + kpi_tiles(run, code) + "</div>",
           "<h3>Verification status</h3>" + chip_cards(run, code, rel, sens),
           '<div class="twocol"><div><h4>Key risks</h4>' + R.bullets([f"{x['cat']}: {x['risk']}" for x in top[:3]]) + "</div>"
           '<div><h4>Next steps</h4><ol>' + "".join(f"<li>{esc(s)}</li>" for s in steps[:3]) + "</ol></div></div>"]
    data = _summary(run)
    warns = [w for w in (data or {}).get("warnings", []) if w["level"] in ("fail", "warn")]
    if warns:
        out.append('<div class="warning"><strong>Points to note</strong>' + R.bullets([w["text"] for w in warns[:4]]) + "</div>")
    out.append("<h3>Why this option</h3>" + R.bullets(info["summary"]) if info and info.get("summary") else "")
    return "".join(out)


def facts(run, code):
    """Headline numbers reused by several sections."""
    r = run["results"][code]
    annual = r["economics"].get("annual") or []
    return dict(r=r, e=r["economics"], annual=annual, em=R.economic_rows(run).get(code), tech=R.technical(r) or {}, ref=run["results"].get(run["reference"]))


def takeaways(key, run, code, best, feasible, rel, sens, risks):
    f = facts(run, code)
    r, e, annual, em, tech = f["r"], f["e"], f["annual"], f["em"], f["tech"]
    codes = list(run["results"])
    planning = run["config"].get("planning") or {}
    values = run["values"]
    if key == "intro":
        return [f"The study compares {len(codes)} supply scenarios ({', '.join(codes)}) over {planning.get('horizon_years', 'the')} years and recommends the lowest-cost option that serves all demand.",
                "Results are planning-level: they support a decision on direction and size, not final design.",
                "Sections follow the workflow from data to verification; the Design report holds the engineering detail."]
    if key == "data":
        out = []
        if len(annual) > 1:
            a, b = annual[0], annual[-1]
            out.append(f"The forecast peak grows from {R.num(a.get('forecast_peak_mw'), 1)} MW in {a['year']} to {R.num(b.get('forecast_peak_mw'), 1)} MW in {b['year']}.")
            out.append(f"Annual energy to be supplied rises from {R.num(a.get('served_mwh', a.get('demand_mwh')) / 1e3, 0)} GWh to {R.num(b.get('served_mwh', b.get('demand_mwh')) / 1e3, 0)} GWh.")
        try:
            import summary_data
            hours = summary_data.history_hours(run)
            if hours:
                out.append(f"The forecast is based on {R.num(hours / 8760, 1)} year(s) of hourly history" + ("; a short history limits how well seasons and year-to-year swings are represented." if hours < 8000 * 2 else "."))
        except Exception:
            pass
        return out
    if key == "basis":
        return [f"Costs are discounted at {R.num(100 * values.get('discount', .06), 1)}% with {R.num(100 * values.get('inflation', .03), 1)}% inflation over a {planning.get('appraisal_years') or 'multi'}-year appraisal.",
                "Every input is listed with its source (user-set or program default) in Appendix A.",
                "Existing and planned projects are deducted from demand rather than costed."]
    if key == "method":
        return ["The model chooses the cheapest set of equipment and then dispatches it hour by hour, so seasonal and daily patterns drive the sizing.",
                "Every solution is checked for hourly power balance and objective reconstruction before it is reported.",
                "Technical findings (network, reliability) are remarks on an option; their corrections are not part of the cost ranking."]
    if key == "results":
        excluded = [c for c, x in run["results"].items() if not R.is_feasible(x)]
        out = [f"{best} has the lowest net present cost among the scenarios that serve all demand ({R.mil(run['results'][best]['economics']['npc'])})."]
        if excluded:
            out.append(f"{', '.join(excluded)} leave demand unserved and are not equivalent in service, so they are not ranked on cost.")
        out.append("Grid energy and demand charges dominate every scenario's cost; on-site equipment mainly reduces that line.")
        return out
    if key == "solution":
        peak, share, limit = peak_and_share(run, code)
        return [f"{code} builds: {R.caps_text(r['caps'])}.",
                f"Renewables supply {R.num(100 * share, 0)}% of demand over the horizon." if share is not None else "",
                f"Peak grid import is {R.num(peak, 1)} MW" + (f" against a {R.num(limit, 1)} MW limit." if limit else ".")]
    if key == "economic":
        if not em:
            return ["Financial metrics have not been computed for this solve."]
        out = [f"NPC is {R.mil(e['npc'])} with {R.mil(e['capex'])} of upfront capital; the levelized supply cost is {currency.money(em['lcoe'], 1, 1, '/MWh')}."]
        if em["status"] != "reference":
            out.append(f"Versus the reference, the net present value is {R.mil(em['npv'])}; payback is {R.fmt_pb(em, 'simple_payback')}.")
            if em.get("co2e_avoided_t") is not None:
                out.append(f"The option avoids {R.num(abs(em['co2e_avoided_t']) / 1e3, 1)} kt of CO2e over the horizon.")
        return out
    if key == "sensitivity":
        if not sens:
            return ["Sensitivity analysis has not been run for this solve; the cost range is therefore untested."]
        rep = sens["report"]
        top = max(rep["swings"], key=lambda s: s["swing"])
        out = [f"The largest cost driver tested is {top['label'].lower()}, moving NPC by {R.mil(top['swing'], 1)} across its range."]
        risk = rep.get("risk") or {}
        if risk.get("p50") is not None:
            out.append(f"The NPC is most likely between {R.mil(risk['p10'], 1)} and {R.mil(risk['p90'], 1)} (median {R.mil(risk['p50'], 1)}).")
        return out
    if key == "reliability":
        if not rel:
            return ["Reliability analysis has not been run for this option."]
        s = rel.get("summary") or {}
        out = [f"Overall verdict {R.reliability_verdict(rel) or 'n/a'}: about {R.num(s.get('lole_h_yr'), 1)} hours of downtime and {R.num(s.get('eue_mwh_yr'), 0)} MWh unserved per year under random outages."]
        if s.get("cost_yr") is not None:
            out.append(f"Expected outage cost is {R.mil(s['cost_yr'], 2)} a year.")
        if s.get("best_measure"):
            out.append(f"Best mitigation identified: {s['best_measure']}.")
        return out
    if key == "powerflow":
        if not tech or str(tech.get("status")).upper() == "NOT_RUN":
            return ["Power-flow screening has not been run; network feasibility of the option is unverified."]
        s = tech.get("summary") or {}
        return [f"Overall status {str(tech.get('status')).upper()} with {s.get('violations', 0)} finding(s) across normal and N-1 cases.",
                f"Bus voltages range {R.num(s.get('vmin'), 3)}-{R.num(s.get('vmax'), 3)} pu; the highest loading is {R.num(s.get('max_loading_pct'), 1)}%.",
                "Findings are remarks; the suggested corrections are not yet in the NPC."]
    if key == "design":
        return ["The single-line diagram shows how the selected equipment connects to the grid.",
                "Voltage levels, transformer size and fault level below are screening values; the Design report holds the schedule, bill of quantities and protection scheme."]
    if key == "risk":
        high = [x for x in risks if x["rating"] == "High"]
        return [f"{len(high)} of {len(risks)} registered risks are rated High." if risks else "",
                "Technical verification statuses are shown next to the cost ranking for every scenario.",
                "This is a planning-level screening, not an investment certification."]
    if key == "conclusions":
        return [f"{code} - {r['name']} is {'the recommended option' if code == best and feasible else 'the reported option'} at {R.mil(e['npc'])} NPC.",
                "Confirm demand, tariff and cost assumptions, then progress the verification items listed below."]
    return []
