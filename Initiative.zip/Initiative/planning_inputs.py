"""Client milestones, calendar interpolation and cost-excluded planned assets."""

import csv
from datetime import datetime
import io
import math

import numpy as np
from scipy.interpolate import PchipInterpolator

import demand_forecasting as forecast
import unit_pf
ANNUAL_POINTS = [
    dict(year=2026, peak_mw=33.34, description="Baseline year (metered)"),
    dict(year=2027, peak_mw=34.5, description="Tech Building and EV load"),
    dict(year=2028, peak_mw=36.0, description="Client milestone"),
    dict(year=2029, peak_mw=37.0, description="Client milestone"),
    dict(year=2030, peak_mw=38.0, description="Client milestone"),
    dict(year=2031, peak_mw=41.5, description="P131 load"),
    dict(year=2032, peak_mw=43.5, description="P131 load"),
    dict(year=2033, peak_mw=45.0, description="Forecast target"),
    dict(year=2036, peak_mw=45.0, description="Plateau 2033-2036"),
]
TRAILER_SPECS = dict(pv_kw_40ft=6, pv_kw_53ft=18, bess_kwh_40ft=70, bess_kwh_53ft=1200,
                     bess_kw_40ft=15, bess_kw_53ft=257.1)
PROJECTS = [
    dict(name="Mobile Trailers - existing", technology="Mobile Trailers", status="existing", start_year=2026, start_month=1,
         end_year=2026, pv_kw=192, bess_kw=480, bess_kwh=2240, availability=.4, derate_factor=.85, degradation=.005),
    dict(name="Mobile Trailers - future", technology="Mobile Trailers", status="planned", start_year=2027, start_month=6,
         end_year=2027, pv_kw=840, bess_kw=6342, bess_kwh=29600, availability=.4, derate_factor=.85, degradation=.005),
    dict(name="Solar Tech Services Building", technology="Solar", status="planned", capacity_mw=.5,
         energy_mwh=0, start_year=2027, end_year=2027, capacity_factor=0, derate_factor=.85, degradation=.005),
    dict(name="Solar Theme Park Parking Structure", technology="Solar", status="planned", capacity_mw=10,
         energy_mwh=0, start_year=2027, end_year=2029, capacity_factor=0, derate_factor=.85, degradation=.005),
    dict(name="Energy Efficiency Projects", technology="Energy Efficiency", status="planned", capacity_mw=1,
         energy_mwh=0, start_year=2025, end_year=2029, capacity_factor=0, derate_factor=1, degradation=0),
]
INTERPOLATIONS = [("linear", "Linear between client annual points"),
                  ("pchip", "Shape-preserving cubic between annual points")]


def finite(value, label, low=0, high=1e12):
    if isinstance(value, bool):
        raise ValueError(f"{label} must be numeric.")
    try:
        value = float(value)
    except (ValueError, TypeError) as exc:
        raise ValueError(f"{label} must be numeric.") from exc
    if not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f"{label} must be finite and in [{low}, {high}].")
    return value


def validate_points(points, baseline_year=2026):
    if not isinstance(points, list) or not points:
        raise ValueError("Provide at least the 2026 baseline and one annual milestone.")
    result = []
    for row in points:
        if not isinstance(row, dict):
            raise ValueError("Annual milestones must be objects.")
        year = finite(row.get("year"), "Milestone year", baseline_year, 2200)
        if year != int(year):
            raise ValueError("Milestone years must be integers.")
        peak = row.get("peak_mw")
        growth = row.get("growth_percent")
        if (peak is None or peak == "") == (growth is None or growth == ""):
            raise ValueError(f"{int(year)}: supply peak_mw OR year-on-year growth_percent, not both.")
        result.append(dict(year=int(year),
                           peak_mw=finite(peak, "Annual peak MW", .001) if peak not in (None, "") else None,
                           growth_percent=finite(growth, "Year-on-year growth %", -99, 1000)
                           if growth not in (None, "") else None,
                           description=str(row.get("description", ""))[:2000]))
    result.sort(key=lambda r: r["year"])
    if len({r["year"] for r in result}) != len(result):
        raise ValueError("Annual milestone years cannot be duplicated.")
    if result[0]["year"] != baseline_year or result[0]["peak_mw"] is None or len(result) < 2:
        raise ValueError(f"Annual milestones require an explicit {baseline_year} baseline peak and a later point.")
    for i, row in enumerate(result):
        if row["growth_percent"] is not None:
            if i == 0 or result[i - 1]["year"] != row["year"] - 1:
                raise ValueError("Year-on-year growth needs the immediately preceding year. Add missing years "
                                 "or specify an absolute peak for sparse milestones.")
            row["peak_mw"] = result[i - 1]["peak_mw"] * (1 + row["growth_percent"] / 100)
            row["input_growth_percent"] = row["growth_percent"]
            row["growth_percent"] = None
    return result


def milestone_csv(text, baseline_year=2026):
    reader = csv.DictReader(io.StringIO(text.lstrip("\ufeff")))
    if not {"year"} <= set(reader.fieldnames or []):
        raise ValueError("Milestone CSV: year,peak_mw,growth_percent,description. Use MW or growth % per row.")
    return validate_points(list(reader), baseline_year)


def annual_trajectory(points, horizon, interpolation, start_year=2027):
    points = validate_points(points, start_year - 1)
    xp = np.array([p["year"] for p in points])
    fp = np.array([p["peak_mw"] for p in points])
    years = np.arange(start_year - 1, start_year + horizon)
    if interpolation == "linear":
        peaks = np.interp(years, xp, fp)
    elif interpolation == "pchip":
        peaks = PchipInterpolator(xp, fp, extrapolate=False)(np.clip(years, xp[0], xp[-1]))
    else:
        raise ValueError("Unknown annual milestone interpolation.")
    for i, year in enumerate(years):
        if year in xp:
            peaks[i] = fp[np.flatnonzero(xp == year)[0]]
        elif year > xp[-1]:
            peaks[i] = fp[-1]
    return [dict(year=int(y), peak_mw=float(p), description=next(
        (r["description"] for r in points if r["year"] == y), "Interpolated / hold last point"))
            for y, p in zip(years, peaks)]


def validate_trailer(item):
    row = dict(name=str(item.get("name", "Mobile Trailers"))[:500], technology="Mobile Trailers",
               status="planned" if item.get("status") == "planned" else "existing")
    year = finite(item.get("start_year"), "Trailer commissioning year", 2000, 2100)
    month = finite(item.get("start_month", 1), "Trailer commissioning month", 1, 12)
    if year != int(year) or month != int(month):
        raise ValueError("Trailer commissioning year and month must be integers.")
    row.update(start_year=int(year), end_year=int(year), start_month=int(month))
    if "pv_kw" in item:
        totals = {key: finite(item[key], key, 0, 1e9) for key in ("pv_kw", "bess_kw", "bess_kwh")}
    else:
        s = {key: finite(item.get(key, default), key, 0, 1e6) for key, default in TRAILER_SPECS.items()}
        n40 = finite(item.get("units_40ft", 0), "units_40ft", 0, 1e5)
        n53 = finite(item.get("units_53ft", 0), "units_53ft", 0, 1e5)
        totals = dict(pv_kw=n40 * s["pv_kw_40ft"] + n53 * s["pv_kw_53ft"],
                      bess_kw=n40 * s["bess_kw_40ft"] + n53 * s["bess_kw_53ft"],
                      bess_kwh=n40 * s["bess_kwh_40ft"] + n53 * s["bess_kwh_53ft"])
    row.update(totals)
    row["availability"] = finite(item.get("availability", .4), "Trailer daily availability fraction", 0, 1)
    row["derate_factor"] = finite(item.get("derate_factor", .85), "Trailer PV retained fraction", 0, 1)
    row["degradation"] = finite(item.get("degradation", .005), "Trailer PV annual degradation", 0, .5)
    a = row["availability"]
    row["gross_pv_mw"] = row["pv_kw"] / 1000
    row["gross_bess_mw"] = row["bess_kw"] / 1000
    row["gross_bess_mwh"] = row["bess_kwh"] / 1000
    row.update(capacity_mw=row["gross_pv_mw"] * a, bess_mw=row["gross_bess_mw"] * a,
               energy_mwh=row["gross_bess_mwh"] * a, capacity_factor=0)
    return row


def validate_projects(projects):
    if not isinstance(projects, list):
        raise ValueError("Planned Generation must be a list.")
    out = []
    for item in projects:
        if isinstance(item, dict) and item.get("technology") == "Mobile Trailers":
            out.append(validate_trailer(item))
            continue
        if not isinstance(item, dict) or item.get("technology") not in ("Solar", "Energy Efficiency", "BESS", "Wind"):
            raise ValueError("Planned technology must be Solar, Energy Efficiency, BESS, Wind or Mobile Trailers.")
        row = dict(name=str(item.get("name", "Planned project"))[:500], technology=item["technology"],
                   status="existing" if item.get("status") == "existing" else "planned")
        for key in ("start_year", "end_year"):
            year = finite(item.get(key), key, 2000, 2100)
            if year != int(year):
                raise ValueError("Project years must be integers.")
            row[key] = int(year)
        if row["end_year"] < row["start_year"]:
            raise ValueError("Project end year cannot precede start year.")
        row["capacity_mw"] = finite(item.get("capacity_mw"), "Project MW")
        row["energy_mwh"] = finite(item.get("energy_mwh", 0), "BESS nameplate MWh")
        row["capacity_factor"] = finite(item.get("capacity_factor", 0), "Wind capacity factor", 0, 1)
        row["derate_factor"] = finite(item.get("derate_factor", 1), "Planned output retained fraction", 0, 1)
        row["degradation"] = finite(item.get("degradation", 0), "Planned annual degradation", 0, .5)
        row["pf"] = finite(item.get("pf", unit_pf.DEFAULT_PF), "Operating power factor", unit_pf.PF_MIN, unit_pf.PF_MAX)
        if row["technology"] != "BESS" and row["energy_mwh"] != 0:
            raise ValueError("Only a planned BESS can have a nameplate MWh input.")
        if row["technology"] != "Wind" and row["capacity_factor"] != 0:
            raise ValueError("The planned capacity-factor input is for Wind only; solar uses the hourly solar profile.")
        if row["technology"] == "BESS" and ((row["capacity_mw"] > 0) != (row["energy_mwh"] > 0)):
            raise ValueError("Planned BESS requires both MW and positive nameplate MWh.")
        if row["technology"] == "Wind" and row["capacity_mw"] > 0 and row["capacity_factor"] <= 0:
            raise ValueError("Planned Wind needs an explicit capacity factor; no site resource is assumed.")
        out.append(row)
    return out


def installed_fraction(year, start, end):
    """Equal commissioning tranches at January 1 in each inclusive year."""
    return max(0, min(1, (year - start + 1) / (end - start + 1)))


def planned_profiles(data, projects, solar_degradation):
    n = len(data["load"])
    solar_cap = np.zeros(n)
    solar_available = np.zeros(n)
    wind_output = np.zeros(n)
    power = np.zeros(n)
    energy = np.zeros(n)
    efficiency = np.zeros(n)
    annual = []
    for yi in sorted(set(data["years"])):
        start_year = data["dates"][0].year
        year = start_year + int(yi)
        s = data["years"] == yi
        for p in projects:
            if p["technology"] == "Mobile Trailers":
                if year < p["start_year"]:
                    continue
                on = s & (np.array([d >= datetime(p["start_year"], p["start_month"], 1) for d in data["dates"]])
                          if year == p["start_year"] else True)
                vintage = (1 - p["degradation"])**(year - p["start_year"])
                resource = data.get("planned_solar_resource", data.get(
                    "solar_resource", data["solar"] / (1 - solar_degradation)**data["years"]))
                solar_cap[on] += p["capacity_mw"]
                solar_available[on] += resource[on] * p["capacity_mw"] * vintage * p["derate_factor"]
                power[on] += p["bess_mw"]
                energy[on] += p["energy_mwh"]
                continue
            fraction = installed_fraction(year, p["start_year"], p["end_year"])
            cap = p["capacity_mw"] * fraction
            vintage_fraction = sum(1 / (p["end_year"] - p["start_year"] + 1) *
                (1 - p.get("degradation", 0))**(year - commissioning)
                for commissioning in range(p["start_year"], min(year, p["end_year"]) + 1))
            effective_cap = p["capacity_mw"] * vintage_fraction * p.get("derate_factor", 1)
            if p["technology"] == "Solar":
                solar_cap[s] += cap
                resource = data.get("planned_solar_resource", data.get(
                    "solar_resource", data["solar"] / (1 - solar_degradation)**data["years"]))
                solar_available[s] += resource[s] * effective_cap
            elif p["technology"] == "Wind":
                wind_output[s] += effective_cap * p["capacity_factor"]
            elif p["technology"] == "BESS":
                power[s] += effective_cap
                energy[s] += p["energy_mwh"] * vintage_fraction * p.get("derate_factor", 1)
            else:
                # Pre-baseline efficiency is already embedded in metering.
                incremental = sum((1 - p.get("degradation", 0))**(year - commissioning) /
                    (p["end_year"] - p["start_year"] + 1)
                    for commissioning in range(max(start_year, p["start_year"]), min(year, p["end_year"]) + 1))
                efficiency[s] += p["capacity_mw"] * incremental * p.get("derate_factor", 1)
        annual.append(dict(year=year, solar_dc_mw=float(solar_cap[s].max()),
                           wind_mw_mean=float(wind_output[s].max()), bess_mw=float(power[s].max()),
                           bess_mwh=float(energy[s].max()), incremental_efficiency_peak_mw=float(efficiency[s].max())))
    gross = data["load"].copy()
    # Efficiency is a proportional annual-peak reduction, not constant night-time generation.
    annual_peaks = {yi: float(data["qmax"][data["years"] == yi].max()) for yi in set(data["years"])}
    reduction = np.array([min(1, e / annual_peaks[yi]) for e, yi in zip(efficiency, data["years"])])
    for key in ("load", "qmax", "qmin"):
        data[key] = data[key] * (1 - reduction)
    data.update(gross_load=gross, efficiency_reduction=gross - data["load"],
                planned_solar_mw=solar_cap, planned_solar_available=solar_available, planned_wind=wind_output,
                planned_bess_mw=power, planned_bess_mwh=energy, planned_annual=annual)


def apply_planned_net_load(data):
    """Use committed renewables first; preserve surplus for physical storage dispatch."""
    available = data["planned_solar_available"] + data["planned_wind"]
    data["service_load"] = data["load"].copy()
    data["planned_direct_supply"] = np.minimum(available, data["load"])
    data["planned_surplus"] = np.maximum(available - data["load"], 0)
    solar_direct = np.minimum(data["planned_solar_available"], data["load"])
    wind_direct = data["planned_direct_supply"] - solar_direct
    data["planned_solar_direct"] = solar_direct
    data["planned_wind_direct"] = wind_direct
    data["planned_solar_surplus"] = data["planned_solar_available"] - solar_direct
    data["planned_wind_surplus"] = data["planned_wind"] - wind_direct
    for key in ("load", "qmax", "qmin"):
        data[key] = np.maximum(data[key] - available, 0)
    data["planned_netted"] = True


def audit_demand(data, built=None, tol=1e-6):
    """Fail loudly unless the demand handed to the optimizer equals the built profile less the explained adjustments.

    Explained adjustments: efficiency (gross - served), then committed solar/wind used directly (served - net).
    `built` is the profile as built or imported when it is used unchanged (projected mode). Returns a summary with
    the energy and peak of every step, so the reduction can be reported and traced hour by hour.
    """
    gross, served, net = (np.asarray(data[k], float) for k in ("gross_load", "service_load", "load"))
    efficiency = np.asarray(data["efficiency_reduction"], float)
    direct = np.asarray(data["planned_direct_supply"], float)
    if not (len(gross) == len(served) == len(net) == len(data["dates"])):
        raise ValueError("Demand audit failed: the optimizer demand array and the built profile cover different hours.")
    if not (np.isfinite(gross).all() and np.isfinite(net).all()):
        raise ValueError("Demand audit failed: the demand contains missing or non-finite values.")
    checks = [("efficiency", np.abs(gross - efficiency - served).max()),
              ("planned direct supply", np.abs(served - direct - net).max())]
    if built is not None:
        checks.append(("built profile", np.abs(np.asarray(built, float) - gross).max()))
    bad = [f"{name} (largest hourly gap {gap:.4g} MW)" for name, gap in checks if gap > tol]
    if bad or net.min() < -tol or (net > served + tol).any():
        raise ValueError("Demand audit failed: the demand handed to the optimizer deviates from the built load profile "
                         "beyond the explained adjustments: " + ", ".join(bad or ["negative or increased net load"]) + ".")
    hours = float(len(gross))
    return dict(hours=int(hours), built_mean_mw=float(gross.mean()), built_peak_mw=float(gross.max()),
                built_energy_mwh=float(gross.sum()), efficiency_energy_mwh=float(efficiency.sum()),
                planned_direct_energy_mwh=float(direct.sum()), optimizer_mean_mw=float(net.mean()),
                optimizer_peak_mw=float(net.max()), optimizer_energy_mwh=float(net.sum()),
                energy_balance_gap_mwh=float(abs(gross.sum() - efficiency.sum() - direct.sum() - net.sum())))


def synthetic_solar(dates):
    cloud = np.random.default_rng(20261014).uniform(.55, 1, 366)
    result = []
    for date in dates:
        day = datetime(2024, date.month, date.day).timetuple().tm_yday
        season = math.cos(2 * math.pi * (day - 172) / 366)
        length = 12 + 2.2 * season
        noon = 12.2 + .5 * season
        phase = (date.hour + .5 - noon + length / 2) / length
        result.append(max(0, math.sin(math.pi * phase))**1.15 * cloud[day - 1] if 0 < phase < 1 else 0)
    return np.array(result)


def profile_sources(request, horizon, start_year=2027):
    """Keep historical, forecast and combined uploads independent; no implicit overwrite."""
    historical = list(request.get("historical_files", []))
    projected = list(request.get("forecast_files", []))
    combined = request.get("combined_files", [])
    if combined and (historical or projected):
        raise ValueError("Use a combined CSV or separate historical/forecast files, not both.")
    audit = {}
    if combined:
        rows = []
        for file in combined:
            reader = csv.DictReader(io.StringIO(file["content"].lstrip("\ufeff")))
            if "timestamp" not in (reader.fieldnames or []):
                raise ValueError("Combined CSV needs timestamp,load_mw; optional profile_type=historical or forecast.")
            for row in reader:
                kind = row.pop("profile_type", "")
                if not kind:
                    try:
                        kind = "historical" if datetime.fromisoformat(row["timestamp"]).year < start_year else "forecast"
                    except (KeyError, ValueError, TypeError) as exc:
                        raise ValueError("Combined CSV contains an invalid timestamp.") from exc
                if kind not in ("historical", "forecast"):
                    raise ValueError("Combined profile_type must be historical or forecast.")
                rows.append((kind, row))
        for kind, target in (("historical", historical), ("forecast", projected)):
            picked = [r for k, r in rows if k == kind]
            if not picked:
                continue
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=list(picked[0]))
            writer.writeheader()
            writer.writerows(picked)
            target.append(dict(name="combined-" + kind + ".csv", content=output.getvalue()))
    history_rows = forecast_rows = None
    if historical:
        history_rows, audit["historical"] = forecast.imported_rows("", historical, "historical", start_year, horizon)
    if projected:
        forecast_rows, audit["forecast"] = forecast.imported_rows("", projected, "projected", start_year, horizon)
    return history_rows, forecast_rows, audit
