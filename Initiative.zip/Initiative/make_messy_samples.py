"""Generate deliberately messy CSVs for trying the Data Preparation feature.

Run: py -3 make_messy_samples.py   (writes to the 'Data Preparation Samples' folder; seeded, repeatable)
Truth: the clean hourly files in 'Load Profile Inputs' and the Los Angeles solar file.
"""
import csv
import math
import random
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "Data Preparation Samples"
OUT.mkdir(exist_ok=True)
rng = random.Random(2026)


def load_truth():
    for path in sorted((ROOT / "Load Profile Inputs").glob("*.csv")):
        with path.open(encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
        if rows and "timestamp" in rows[0] and "load_mw" in rows[0] and len(rows) >= 8700:
            return [(datetime.fromisoformat(r["timestamp"][:19]), float(r["load_mw"])) for r in rows][:8760]
    # fallback synthetic year
    start = datetime(2025, 9, 1)
    return [(start + timedelta(hours=h), 24 + 6 * math.sin((h % 24 - 6) / 24 * 2 * math.pi)) for h in range(8760)]


def write(name, text):
    (OUT / name).write_text(text, encoding="utf-8", newline="")
    print("wrote", OUT / name)


def messy_load_utility(truth):
    """15-minute utility export in kW: preamble, 'MM/DD/YYYY' + 'hh:mm AM/PM', thousands commas,
    duplicates, out-of-order rows, blanks, N/A, negatives, zero drop-outs, spikes, a 2-day gap, partial first day."""
    lines = ["Consumption Usage Report\t", "", "Report Date: 09/15/2026 12:34:02 PM Time Period: messy sample", "",
             "Date,Time,8019405139,Billed/Unbilled"]
    records = []
    for t, mw in truth + [(a + timedelta(days=365), b) for a, b in truth[:10]]:
        for q in range(4):
            stamp = t + timedelta(minutes=15 * q)
            if timedelta(days=40) <= stamp - truth[0][0] < timedelta(days=42):
                continue
            records.append([stamp, mw * 1000 * (1 + rng.uniform(-.01, .01))])
    for r in rng.sample(records, 40):
        r[1] = rng.choice(["", "N/A", "-", "#VALUE!"])
    for r in rng.sample(records, 6):
        r[1] = -abs(float(r[1] or 1000)) if isinstance(r[1], float) else r[1]
    for k in range(3):
        start = rng.randrange(1000, len(records) - 100)
        for r in records[start:start + 12 * 4]:
            r[1] = 0.0
    for r in rng.sample(records, 25):
        if isinstance(r[1], float):
            r[1] *= 6
    dup = rng.sample(records, 30)
    records += [list(r) for r in dup]
    rng.shuffle(records[:200])
    records[100:400] = sorted(records[100:400], key=lambda r: r[0], reverse=True)
    for stamp, value in records:
        text = value if isinstance(value, str) else f"{value:,.2f}"
        lines.append(f'{stamp:%m/%d/%Y},{stamp:%I:%M %p},"{text}",Unbilled')
    return "\n".join(lines) + "\n"


def messy_load_generic(truth):
    """Hourly European-style export: semicolon-delimited, DD.MM.YYYY, ISO timezone suffix, comma decimals, kWh, status column."""
    lines = ["Timestamp (UTC);Energy kWh;Quality;Notes"]
    for i, (t, mw) in enumerate(truth):
        if 3000 <= i < 3002 or i % 997 == 5:
            continue
        value = f"{mw * 1000:.1f}".replace(".", ",")
        lines.append(f"{t:%d.%m.%Y %H:%M}Z;{value};{rng.choice(['OK', 'OK', 'OK', 'EST'])};")
    return "\n".join(lines) + "\n"


def truth_solar():
    out = []
    t = datetime(2025, 1, 1)
    for h in range(8760):
        d = t + timedelta(hours=h)
        sun = max(0, math.sin((d.hour - 6) / 12 * math.pi)) * (0.8 + .15 * math.sin(d.timetuple().tm_yday / 365 * 2 * math.pi))
        out.append((d, sun * rng.uniform(.6, 1)))
    return out


def messy_solar():
    lines = ["# Weather station export", "# columns: time, GHI (kW/m2)", "time,GHI (kW/m2),flag"]
    for d, v in truth_solar():
        if d.hour in (0, 1, 2) and rng.random() < .01:
            continue
        val = "" if rng.random() < .004 else f"{v:.3f}"
        lines.append(f"{d:%Y-%m-%dT%H:%M:%S}+00:00,{val},0")
    return "\n".join(lines) + "\n"


def messy_wind():
    lines = ["Date,Time,Wind Power (kW),Wind speed m/s"]
    t = datetime(2025, 1, 1)
    for h in range(8760):
        d = t + timedelta(hours=h)
        kw = max(0, 1500 * (.5 + .4 * math.sin(h / 37) + rng.uniform(-.15, .15)))
        if h % 700 == 0:
            kw = 99999
        lines.append(f"{d:%m/%d/%Y},{d:%H:%M},{kw:.1f},{rng.uniform(3, 12):.1f}")
    return "\n".join(lines) + "\n"


def messy_thermal():
    lines = ["timestamp,heat_demand_kWth"]
    t = datetime(2025, 1, 1)
    for h in range(8760):
        d = t + timedelta(hours=h)
        if 200 <= h < 204:
            continue
        lines.append(f'{d:%Y/%m/%d %H:%M},"{800 + 300 * math.sin(h / 24 * 2 * math.pi) + rng.uniform(-40, 40):,.0f}"')
    return "\n".join(lines) + "\n"


if __name__ == "__main__":
    truth = load_truth()
    write("messy_load_utility_15min_kW.csv", messy_load_utility(truth))
    write("messy_load_european_hourly_kWh.csv", messy_load_generic(truth))
    write("messy_solar_ghi_kWm2.csv", messy_solar())
    write("messy_wind_power_kW.csv", messy_wind())
    write("messy_thermal_kWth.csv", messy_thermal())
