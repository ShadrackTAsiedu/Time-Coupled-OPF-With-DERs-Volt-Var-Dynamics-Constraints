"use strict";
let schema, uploadFiles = [], currentRun = null, polling = null, busy = false;
let profileUploads = {historical_files: [], forecast_files: [], combined_files: []}, canAnalyze = false;
let resourceUploads = {solar_file:null, planned_solar_file:null, thermal_file:null, wind_file:null};
let solveRun = null, solveSnapshot = null, analysisSnapshot = null, activeView = "load";
let workflowRuns = {}, workflowStatuses = {};
let priorSolveState = null, cancelling = false, interruptRun = null, mergeFrom = null;
const byId = id => document.getElementById(id);
function node(tag, text, className) {
  const el = document.createElement(tag);
  if (text !== undefined) el.textContent = text;
  if (className) el.className = className;
  return el;
}
function values() {
  return Object.fromEntries(schema.fields.map(f => {
    const input = byId(f.key);
    return [f.key, f.kind === "checkbox" ? input.checked : f.kind === "select" ? input.value : unitsUi.canonical(input)];
  }));
}
function request(solve, plan) {
  if (byId("demand-workflow").value === "generate" && profileUploads.combined_files.length)
    throw new Error("Clear the combined upload and load its historical CSV separately before generating a replacement forecast.");
  const uploads = byId("demand-workflow").value === "generate" ?
    {...profileUploads, forecast_files: [], combined_files: []} : profileUploads;
  const rerun = solve && plan && !plan.pending ? plan : null;
  const known = new Set(readScenarioRows().map(s => s.id));
  return {values: values(), solve, upload_files: [], import_mode: "historical", merge_from: solve && !rerun ? mergeFrom : null,
    technical_check: byId("technical-check").checked,
    technical_islanded: byId("technical-islanded").checked,
    workflow: rerun ? {base_run: rerun.base, iteration: rerun.iteration, changes: rerun.changes, mode: rerun.mode || "", applied_costs: rerun.applied_costs || {}} : null,
    application_version: schema.application_version,
    demand_source: byId("demand-workflow").value,
    ...uploads, ...resourceUploads, planned_solar_profile_enabled:byId("planned-solar-enabled").checked,
    milestones: readRows("milestone-rows"), planned_generation: readPlanned(), planned_schema: PLANNED_SCHEMA,
    scenario_definitions: readScenarioRows(),
    topology:topologyEditor.value(),
    comparison_reference:byId("financial-reference").value || null,
    scenarios: rerun ? rerun.scenarios.filter(code => known.has(code)) :
      [...byId("scenarios").querySelectorAll("input:checked")].map(input => input.value)};
}
function showError(error) {
  const box = byId("error");
  box.replaceChildren(document.createTextNode(error || ""));
  box.hidden = !error;
  box.classList.remove("clickable"); box.removeAttribute("tabindex"); box.removeAttribute("title");
  errorGuide.set(error || "");
}
const errorGuide = (() => {
  let current = null;
  const GROUP_HINTS = [[/wind/i,"Wind"],[/bess|batter|state.of.charge/i,"BESS"],[/solar|\bpv\b|photovoltaic/i,"Solar PV"],
    [/hydrogen|\bh2\b/i,"Hydrogen turbine"],[/natural gas|\bng\b/i,"Natural gas turbine"],[/diesel/i,"Diesel generator"],
    [/biogas/i,"Biogas generator"],[/biomass/i,"Biomass generator"],[/thermal|boiler/i,"Thermal load"],
    [/tariff|grid|import limit|export/i,"Grid and tariff"],[/emission|carbon/i,"Carbon emissions"],
    [/apprais|discount|inflation|escalation|replacement/i,"Financial"],[/microgrid/i,"Microgrid"]];
  const num = key => unitsUi.canonical(key);
  const has = key => !!byId(key);
  function resolve(text) {
    const tech = (/^\s*([a-z0-9_]+):/i.exec(text) || [])[1]?.toLowerCase();
    if (tech && has(tech + "_capex") || tech && has(tech + "_efficiency")) {
      if (/cannot exceed 100/i.test(text) && has(tech + "_heat_efficiency"))
        return {fields: [tech + "_efficiency", tech + "_heat_efficiency"],
          guide: "Lower the electrical or recovered-heat efficiency so that together they do not exceed 1.0 (100%).",
          valid: () => num(tech + "_efficiency") + num(tech + "_heat_efficiency") <= 1};
      const fields = [tech + "_capex", tech + "_efficiency", tech + "_confirmed"].filter(has);
      return {fields, guide: "Enter a positive equipment CAPEX and efficiency, then tick the confirmation of your project-specific fuel, maintenance and emissions assumptions.",
        valid: () => (!has(tech + "_capex") || num(tech + "_capex") > 0) && (!has(tech + "_efficiency") || num(tech + "_efficiency") > 0) &&
          (!has(tech + "_confirmed") || byId(tech + "_confirmed").checked)};
    }
    if (/microgrid (min|max)/i.test(text) || /microgrid minimum/i.test(text))
      return {fields: ["microgrid_min_mw", "microgrid_max_mw"], guide: "Raise the maximum or lower the minimum optimized microgrid so that minimum ≤ maximum.",
        valid: () => num("microgrid_min_mw") <= num("microgrid_max_mw")};
    if (/duration and state-of-charge|duration.*state.of.charge/i.test(text))
      return {fields: ["duration_min", "duration_max", "soc_min", "soc_max"], guide: "Make minimum duration ≤ maximum duration and minimum state of charge < maximum state of charge.",
        valid: () => num("duration_min") <= num("duration_max") && num("soc_min") < num("soc_max")};
    if (/Target must be at least baseline/i.test(text))
      return {fields: ["baseline", "target"], guide: "Set the target peak to at least the baseline peak.", valid: () => num("target") >= num("baseline")};
    if (/Financial appraisal must cover/i.test(text))
      return {fields: ["appraisal_years", "horizon_years"], guide: "Make the appraisal period at least as long as the optimization horizon.",
        valid: () => !byId("extended_appraisal").checked || num("appraisal_years") >= num("horizon_years")};
    if (/Confirm emissions factors/i.test(text))
      return {fields: ["emission_factors_confirmed"], guide: "Tick 'Use entered screening factors' after reviewing the emissions factors, or switch off the emissions limit.",
        valid: () => byId("emission_factors_confirmed").checked || !byId("emissions_limit_enabled").checked};
    if (/solar footprint/i.test(text))
      return {fields: ["solar_acres_per_mw"], guide: "Enter a positive solar footprint in acres/MW, or switch off the solar land limit.",
        valid: () => num("solar_acres_per_mw") > 0 || !byId("solar_land_enabled").checked};
    if (/BESS power and\/or energy footprint/i.test(text))
      return {fields: ["bess_acres_per_mw", "bess_acres_per_mwh"], guide: "Enter a positive BESS footprint per MW and/or per MWh, or switch off the BESS land limit.",
        valid: () => num("bess_acres_per_mw") + num("bess_acres_per_mwh") > 0 || !byId("bess_land_enabled").checked};
    if (/wind footprint/i.test(text))
      return {fields: ["wind_acres_per_mw"], guide: "Enter a positive wind footprint in acres/MW, or switch off the wind land limit.",
        valid: () => num("wind_acres_per_mw") > 0 || !byId("wind_land_enabled").checked};
    if (/tariff|peak.*(hour|band)|summer first month/i.test(text))
      return {fields: ["summer_start_month", "summer_end_month", "peak_start_hour", "peak_end_hour", "mid_start_hour", "mid_end_hour"],
        guide: "Use whole numbers, a first month not after the last month, a start hour before each end hour, and non-overlapping Peak and Mid-peak bands.", any: true};
    const byLabel = schema.fields.filter(f => f.label.length > 5 && text.toLowerCase().includes(f.label.toLowerCase()))
      .sort((a, b) => b.label.length - a.label.length)[0];
    if (byLabel) {
      const range = /between ([^ ]+) and ([^ .]+)/.exec(text);
      const guide = byLabel.kind === "number" ?
        (range ? `Enter a number between ${range[1]} and ${range[2]}${byLabel.unit ? " " + byLabel.unit : ""}.` : "Enter a valid number.") :
        "Choose a valid value.";
      return {fields: [byLabel.key], guide, valid: byLabel.kind === "number" ? () => byId(byLabel.key).checkValidity() && Number.isFinite(num(byLabel.key)) : null, any: byLabel.kind !== "number"};
    }
    if (/upload|csv|timestamp|forecast|historical|profile/i.test(text)) {
      const id = /planned/i.test(text) && /solar/i.test(text) ? "planned-solar-upload" : /wind/i.test(text) ? "wind-upload" :
        /thermal|heat/i.test(text) ? "thermal-upload" : /solar/i.test(text) ? "solar-upload" : "demand-import";
      return {elements: [id], guide: "Select a valid CSV (timestamp plus load/profile columns, complete hours, correct units), or choose a different demand source, then run again.", any: true};
    }
    if (/scenario|comparison baseline|eligible technolog/i.test(text)) {
      const pick = /comparison baseline/i.test(text) ? "financial-reference" : /at least one valid scenario/i.test(text) ? "scenarios" : "scenario-rows";
      return {elements: [pick], guide: "Fix the scenario definition (unique ID, a name, at least one eligible technology, an override within its range) or select a scenario to solve.", any: true};
    }
    for (const [pattern, group] of GROUP_HINTS)
      if (pattern.test(text)) return {group, guide: `Review the inputs in the "${group}" group and correct the value mentioned in the message.`, any: true};
    return null;
  }
  function targets(rule) {
    return [...(rule.fields || []).map(byId), ...(rule.elements || []).map(byId)].filter(Boolean);
  }
  function clear() {
    if (!current) return;
    current.nodes.forEach(n => n.remove());
    current.marked.forEach(n => n.classList.remove("error-field"));
    current = null;
  }
  function set(text) {
    clear();
    const rule = text ? resolve(text) : null;
    if (!rule) return;
    const elements = targets(rule), nodes = [], marked = [];
    const guideText = "What to do: " + rule.guide;
    const hosts = elements.map(el => el.closest("label") || el);
    hosts.forEach(h => { h.classList.add("error-field"); marked.push(h); });
    if (hosts.length) {
      const small = node("small", guideText, "error-guide"); small.setAttribute("role", "note");
      hosts[0].after(small); nodes.push(small);
    }
    const box = byId("error");
    box.append(document.createTextNode(" "), node("strong", `${guideText} (click this message to go to the input)`));
    box.classList.add("clickable"); box.tabIndex = 0; box.title = "Click to open and highlight the input";
    current = {rule, elements, nodes, marked};
  }
  function go() {
    if (!current) return;
    const {rule, elements} = current;
    if (elements[0]) inputWorkspace.reveal(elements[0]);
    else if (rule.group) inputWorkspace.openGroup(rule.group);
    const first = elements.find(el => el.offsetParent !== null) || elements[0];
    if (first) {
      first.scrollIntoView({behavior: "smooth", block: "center"});
      const control = first.matches("input,select,button") ? first : first.querySelector("input,select:not(.unit-select),button");
      control?.focus({preventScroll: true});
    }
  }
  function recheck(event) {
    if (!current) return;
    const {rule, elements} = current;
    const inside = elements.some(el => el.contains(event.target)) ||
      (rule.group && event.target.closest?.(`[data-group="${rule.group}"]`));
    if (!inside) return;
    if (rule.any || !rule.valid || rule.valid()) {
      clear();
      byId("error").hidden = true; byId("error").replaceChildren();
    }
  }
  document.addEventListener("input", recheck, true);
  document.addEventListener("change", recheck, true);
  document.addEventListener("click", event => {
    if (event.target.closest?.("#error.clickable")) go();
    else if (current?.rule.any && event.target.closest?.("button") && current.elements.some(el => el.contains(event.target))) recheck(event);
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Enter" && event.target.id === "error" && current) go();
  });
  return {set, resolve};
})();
function setBusy(value) {
  busy = value;
  byId("solve").disabled = value;
  byId("preview").disabled = value;
  byId("analyze").disabled = value || !canAnalyze;
  byId("status").classList.toggle("busy", value);
  byId("stop-run").hidden = !value || !interruptRun;
  byId("stop-run").disabled = cancelling;
}
function panelError(view, error) {
  console.error(error);
  const host = byId("view-" + view) || byId("view-" + activeView);
  if (!host) return;
  let box = host.querySelector(":scope > .panel-error");
  if (!box) {
    box = node("div", undefined, "notice panel-error"); box.setAttribute("role", "alert");
    host.prepend(box);
  }
  box.textContent = `This panel hit an error and part of it may be incomplete: ${error?.message || error}. Other tabs are unaffected; switch tabs or reload to retry.`;
  box.hidden = false;
}
function guardPanel(view, fn) {
  try {
    const result = fn();
    if (result && typeof result.catch === "function") result.catch(error => panelError(view, error));
    return result;
  } catch (error) { panelError(view, error); }
}
window.addEventListener("error", event => panelError(activeView, event.error || event.message));
window.addEventListener("unhandledrejection", event => panelError(activeView, event.reason));
function switchView(view) {
  guardPanel(activeView, () => inputWorkspace.close());
  activeView = view;
  for (const name of ["load","solve","analyze","summary","powerflow","design"]) {
    byId("view-" + name).hidden = name !== view;
    byId("tab-" + name).classList.toggle("secondary", name !== view);
    byId("tab-" + name).setAttribute("aria-selected", String(name === view));
  }
  byId("view-" + view).querySelector(":scope > .panel-error")?.remove();
  if (view === "summary") guardPanel(view, renderSummary);
  if (view === "powerflow") guardPanel(view, () => window.powerFlowPage?.show());
  if (view === "design") guardPanel(view, () => window.designPage?.show());
  if (["summary","solve"].includes(view)) {
    guardPanel(view, () => {
      byId(view === "summary" ? "summary-dispatch-slot" : "solve-dispatch-slot").append(byId("dispatch-explorer"));
      if(solveSnapshot?.summary)dispatchExplorer.show(solveRun,solveSnapshot.summary.results||[]);
    });
    if (view === "solve") guardPanel(view, () => window.reportUi?.refresh());
  }
}
function renderSummary() {
  if (!solveSnapshot?.summary) return;
  window.summaryDashboard?.show(solveRun);
  byId("summary-dispatch-slot").append(byId("dispatch-explorer"));
  const summary = solveSnapshot.summary;
  const results = summary.results || [];
  byId("export-summary-pdf").disabled = !results.length;
  const reliable = results.filter(r => !r.adequacy.unserved_hours && r.adequacy.stress_unserved_mwh <= .00005);
  const sorted = [...(reliable.length ? reliable : results)].sort((a,b) => reliable.length ?
    a.economics.npc-b.economics.npc : a.adequacy.unserved_mwh-b.adequacy.unserved_mwh || a.economics.npc-b.economics.npc);
  const adjusted = window.workflowUi?.recommended(results);
  const best = adjusted?.best || results.find(r => r.is_recommended) || sorted[0];
  byId("summary-best").textContent = best ?
    `Saved solve ${solveRun}: ${results.length} scenarios, ${best.economics.annual.length} appraisal years. ` +
    (analysisSnapshot ? "Financial analysis uses the same saved solve." : "Open Analyze to add the financial tables below.") :
    "No validated scenario results.";
  const table = namedGeneratorTable(summary);
  displayTable("summary-capacities",table.columns,table.rows);
  if (analysisSnapshot) displayTable("summary-financial",analysisSnapshot.columns,analysisSnapshot.rows);
  else byId("summary-financial").replaceChildren();
  byId("summary-plots").replaceChildren();
  for (const name of ["annual_gross_forecast.png","generation_mix.png","cost_comparison.png"]) {
    if (!solveSnapshot.files?.includes(name)) continue;
    const live = window.resultCharts?.build(name, {summary: solveSnapshot.summary, status: solveSnapshot}); if (live) { byId("summary-plots").append(live); continue; }
    const img = document.createElement("img"); img.src = `/files/${solveRun}/${name}`;
    img.alt = name.replaceAll("_"," "); byId("summary-plots").append(img);
  }
  dispatchExplorer.show(solveRun, results);
  window.reportUi?.refresh();
}
let pvTimer = null, pvKey = "";
const PV_KEYS = ["solar_derate", "pv_dc_ac_ratio", "pv_temp_coefficient", "pv_temp_model", "pv_noct", "pv_tilt", "pv_azimuth",
  "pv_latitude", "pv_longitude", "pv_utc_offset", "start_year"];
function pvPreview() {
  clearTimeout(pvTimer);
  pvTimer = setTimeout(async () => {
    const box = byId("pv-preview"), file = resourceUploads.solar_file;
    if (!file || !byId("solar_profile_enabled").checked) { box.hidden = true; pvKey = ""; return; }
    const all = values(), picked = Object.fromEntries(PV_KEYS.filter(k => k in all).map(k => [k, all[k]]));
    const key = JSON.stringify([file.name, file.content.length, picked]);
    if (key === pvKey) return;
    pvKey = key;
    const text = byId("pv-preview-text"), charts = byId("pv-preview-charts");
    try {
      const response = await fetch("/api/pv-preview", {method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({solar_file: file, values: picked})});
      const out = await response.json();
      if (!response.ok) throw new Error(out.error || "Cannot preview the solar resource.");
      const clip = out.converted ? ` Inverter clipping removes ${GS.fmt(out.clipped_energy_fraction * 100, 2)} % of energy.` : "";
      text.textContent = `${out.converted ? "Computed from irradiance" : "Uploaded unit PV profile"} (${out.basis}). ` +
        `Annual capacity factor ${GS.fmt(out.annual_capacity_factor_ac * 100, 2)} % of MW AC; specific yield ${GS.fmt(out.annual_yield_kwh_per_kwdc, 0)} kWh/kWdc/yr ` +
        `after ${GS.fmt((1 - out.retained_fraction) * 100, 1)} % system losses, before degradation.${clip} Basis: ${out.ac_basis}.`;
      const bars = (title, labels, values, id) => GS.chart({kind: "bars", title, filename: id, height: 240, yTitle: "Capacity factor (%)", unit: "%",
        catTitle: id === "pv_monthly" ? "Month" : "Hour of day", categories: labels.map(l => ({key: String(l), label: String(l)})),
        series: [{key: "cf", label: "Capacity factor", color: "#E08A1E", values: values.map(v => v * 100)}], vFmt: v => GS.fmt(v, 1)}).el;
      charts.replaceChildren(bars("Unit PV capacity factor by month", out.months, out.monthly_capacity_factor, "pv_monthly"),
        bars("Unit PV capacity factor by hour of day (annual mean)", [...Array(24).keys()], out.diurnal_capacity_factor, "pv_diurnal"));
      box.hidden = false;
    } catch (error) { text.textContent = error.message; charts.replaceChildren(); box.hidden = false; }
  }, 400);
}
function edited() {
  byId("stale").hidden = !currentRun;
  pvPreview();
  for (const key of ["baseline", "target", "target_years"]) byId(key).disabled = byId("trajectory_mode").value === "milestones";
  visibility();
  landSummary();
  planningHeader();
  inputWorkspace.visibilityChanged();
  inputWorkspace.schedule();
}
function planningHeader() {
  const years = Number(byId("horizon_years").value);
  if (!Number.isInteger(years) || years < 1 || years > 30) {
    byId("planning-hours").textContent = "Select a valid planning horizon";
    return;
  }
  const firstYear = Number(byId("start_year").value);
  const hours = (Date.UTC(firstYear + years, 0, 1) - Date.UTC(firstYear, 0, 1)) / 3600000;
  byId("planning-hours").textContent = `${hours.toLocaleString()} economic-horizon hours · ${years} year${years === 1 ? "" : "s"} · forecast ${byId("forecast_mode")?.value === "none" ? "off (data used as-is)" : "on (grown to horizon)"}`;
  byId("planning-range").textContent = `LOCAL ENERGY PLANNING / ${firstYear}-${firstYear + years - 1}`;
}
function landSummary() {
  const v = values();
  const solar = v.solar_land_enabled ?
    (v.solar_acres_per_mw > 0 ? `${(v.solar_acres / v.solar_acres_per_mw).toFixed(3)} MW solar land ceiling.` :
      "Enabled: supply a positive solar footprint before solving.") : "Solar land constraint is off.";
  const bess = v.bess_land_enabled ?
    `${v.bess_acres_per_mw} × battery MW + ${v.bess_acres_per_mwh} × nameplate MWh ≤ ${v.bess_acres} acres.` :
    "BESS land constraint is off; total microgrid rating and battery duration constrain sizing.";
  byId("land-summary").replaceChildren(node("strong", "Active site constraints"),
    node("div", `Alternatives: grid import ≤ ${v.grid_limit} MW, no upgrade. ${solar}`),
    node("div", "R0: upgraded grid plus common plans; no additional microgrid."),
    node("div", `${bess} Land limits exclude separately planned projects.`),
    node("div", `Additional microgrid: ${v.microgrid_min_mw}-${v.microgrid_max_mw} MW = solar + wind + BESS discharge power + selected fuel generators. Not firm continuous output.`));
}
function visibility() {
  const generating = byId("demand-workflow").value === "generate";
  byId("forecast-controls").hidden = !generating;
  byId("forecast-upload-options").hidden = generating;
  byId("forecast-instruction").textContent = generating ?
    "Select historical inputs, enter annual targets or baseline/future values, then Build." :
    "Load a forecast or combined CSV. Its values are used directly without forecast-model adjustments.";
  byId("milestone-panel").hidden = byId("trajectory_mode").value !== "milestones";
  const tou = byId("tariff_mode").value === "tou";
  byId("tariff-warning").hidden = tou || Number(byId("blended_kwh").value) !== 0;
  byId("blended_kwh").closest("label").hidden = tou;
  for (const key of ["summer_start_month","summer_end_month","peak_start_hour","peak_end_hour",
    "mid_start_hour","mid_end_hour","weekend_mid_peak", "summer_same", "winter_same"])
    byId(key).closest("label").hidden = !tou;
  for (const season of ["summer", "winter"]) for (const band of ["off","mid","peak"])
    byId(`${season}_${band}_kwh`).closest("label").hidden = !tou || (band !== "off" && byId(season + "_same").checked);
  const selected = new Set([...byId("scenarios").querySelectorAll("input:checked")].map(i => i.value));
  const technologies = new Set(readScenarioRows().filter(s => selected.has(s.id)).flatMap(s => s.technologies));
  const groups = {"Solar PV":"pv", "BESS":"bess", "Hydrogen turbine":"h2","Hydrogen CHP":"h2_chp",
    "Natural gas turbine":"ng", "Natural gas CHP":"ng_chp", "Grid and tariff":"grid","Wind":"wind",
    "Diesel generator":"diesel","Biogas generator":"biogas","Biomass generator":"biomass"};
  for (const [group, technology] of Object.entries(groups))
    document.querySelector(`[data-group="${group}"]`).hidden = !technologies.has(technology) &&
      !((technology === "bess" ? "BESS" : technology === "pv" ? "Solar" : "") &&
        readPlanned().some(p => p.technology === (technology === "bess" ? "BESS" : "Solar")));
  byId("solar-upload").hidden = !byId("solar_profile_enabled").checked;
  byId("planned-solar-upload").hidden = !byId("planned-solar-enabled").checked;
  const thermal = byId("thermal_enabled").checked;
  byId("thermal-upload").hidden = !thermal || !byId("thermal_profile_enabled").checked;
  for (const key of ["thermal_profile_enabled","heat_mean","boiler_efficiency","boiler_fuel_price"])
    byId(key).closest("label").hidden = !thermal;
  byId("heat_mean").closest("label").hidden = !thermal || byId("thermal_profile_enabled").checked;
  const planned = new Set(readPlanned().map(p => p.technology));
  const used = new Set(technologies);
  if (thermal) used.add("ng");
  if (planned.has("Solar") || planned.has("Mobile Trailers")) used.add("pv");
  if (planned.has("BESS") || planned.has("Mobile Trailers")) used.add("bess");
  if (planned.has("Wind")) used.add("wind");
  const carbonFields = {grid_emissions_t_mwh:["grid"], h2_emissions_kgco2_kg:["h2","h2_chp"], ng_emissions_t_mmbtu:["ng","ng_chp"],
    diesel_emissions_t_mmbtu:["diesel"], biogas_emissions_t_mmbtu:["biogas"], biomass_emissions_t_mmbtu:["biomass"],
    pv_emissions_t_mwh:["pv"], bess_emissions_t_mwh:["bess"], wind_emissions_t_mwh:["wind"]};
  for (const [key, techs] of Object.entries(carbonFields))
    byId(key).closest("label").hidden = !techs.some(t => used.has(t));
  byId("emissions_limit_t_year").closest("label").hidden = !byId("emissions_limit_enabled").checked;
  byId("appraisal_years").closest("label").hidden = !byId("extended_appraisal").checked;
  const dependents = {reactive_enabled:["reactive_rate","reactive_ratio"], export_enabled:["export_limit_mw","export_price"],
    solar_land_enabled:["solar_acres","solar_acres_per_mw"], wind_land_enabled:["wind_acres","wind_acres_per_mw"],
    bess_land_enabled:["bess_acres","bess_acres_per_mw","bess_acres_per_mwh"],
    include_replacements:["pv_life","wind_life","bess_life","generator_life","grid_life","replacement_fraction"]};
  for (const tech of ["h2","h2_chp","ng","ng_chp","diesel","biogas","biomass"])
    dependents[tech + "_tc_enabled"] = [tech + "_min_load", tech + "_ramp", tech + "_startup"];
  for (const [flag, keys] of Object.entries(dependents))
    for (const key of keys) byId(key).closest("label").hidden = !byId(flag).checked;
}
function readScenarioRows() {
  return [...byId("scenario-rows").children].map(card => ({
    id: card.querySelector("[data-key='id']").value,
    name: card.querySelector("[data-key='name']").value,
    reference: card.dataset.reference === "true",
    technologies: [...card.querySelectorAll("[data-tech]:checked")].map(input => input.dataset.tech),
    ...(card.dataset.overrides ? {overrides: JSON.parse(card.dataset.overrides)} : {})
  })).filter(s => !(s.reference && !s.technologies.includes("grid")));
}
function namedGeneratorTable(summary) {
  const results = summary.results || [];
  const catalog = schema.technologies.filter(([key]) => ["wind","h2","h2_chp","ng","ng_chp","diesel","biogas","biomass"].includes(key));
  const selected = catalog.filter(([key]) => results.some(r =>
    (r.eligible_technologies || (Array.isArray(r.tech) ? r.tech : [r.tech])).includes(key)));
  const removed = new Set(["Generator MW", ...catalog.flatMap(([,name]) => [name+" MW",name+" MWh"])]);
  const technologies = new Set(results.flatMap(r=>r.eligible_technologies || ["grid","pv","bess"]));
  if (!technologies.has("grid")) removed.add("Grid peak import MW");
  if (!technologies.has("pv")) removed.add("Solar MW");
  if (!technologies.has("bess")) { removed.add("BESS MW"); removed.add("BESS MWh"); }
  const retained = summary.columns.map((name,index) => ({name,index})).filter(c => !removed.has(c.name));
  const columns = retained.map(c => c.name);
  const insert = columns.includes("BESS MWh") ? columns.indexOf("BESS MWh")+1 : 2;
  columns.splice(insert,0,...selected.flatMap(([,name]) => [name+" MW",name+" MWh"]));
  const rows = summary.rows.map(row => {
    const result = results.find(r => r.code === row[0]);
    const values = retained.map(c => row[c.index]);
    values.splice(insert,0,...selected.flatMap(([key]) => [
      result?.caps?.generators_mw?.[key] ?? (result?.tech === key ? result.caps.generator_mw : 0),
      (result?.economics?.annual || []).reduce((sum,a) => sum +
        (a[key+"_generation_mwh"] ?? (result.tech === key ? a.gen_mwh : 0) ?? 0),0)
    ]));
    return values;
  });
  return {columns,rows};
}
function refreshScenarioChoices(selected) {
  selected ??= [...byId("scenarios").querySelectorAll("input:checked")].map(i => i.value);
  byId("scenarios").replaceChildren();
  for (const s of readScenarioRows()) {
    const input = document.createElement("input"), label = node("label");
    input.type = "checkbox"; input.id = "scenario-" + s.id; input.value = s.id;
    input.checked = selected.includes(s.id); input.onchange = edited;
    const names = s.technologies.map(t => schema.technologies.find(([id]) => id === t)?.[1] || t).join(" + ");
    label.append(input, document.createTextNode(`${s.id}: ${s.name} — eligible: ${names}${s.reference ? " (upgrade)" : ""}`));
    byId("scenarios").append(label);
  }
  const reference = byId("financial-reference"), old = reference.value || "R0";
  reference.replaceChildren(new Option("No incremental comparison baseline",""));
  for (const s of readScenarioRows()) reference.append(new Option(`${s.id}: ${s.name}`,s.id));
  reference.value = [...reference.options].some(o=>o.value === old) ? old : "";
  const include = byId("include-reference");
  if (include) include.checked = readScenarioRows().some(s => s.reference);
}
// Adds or removes the grid-only (R0) reference scenario; without it incremental NPV/IRR use another baseline or none.
function toggleReferenceScenario(on) {
  const cards = [...byId("scenario-rows").children].filter(c => c.dataset.reference === "true");
  if (on && !cards.length) {
    addScenario({id:"R0",name:"Grid with substation upgrade",technologies:["grid"],reference:true});
    const card = byId("scenario-rows").lastElementChild;
    byId("scenario-rows").prepend(card);
    refreshScenarioChoices([...byId("scenarios").querySelectorAll("input:checked")].map(i=>i.value).concat("R0"));
  } else if (!on) {
    cards.forEach(c => c.remove());
    refreshScenarioChoices();
  }
  edited();
}
function addScenario(row) {
  const card = node("div", undefined, "input-row"); card.dataset.reference = String(row.reference === true);
  for (const [key, title] of [["id","Scenario ID"],["name","Scenario name"]]) {
    const label = node("label", title), input = document.createElement("input");
    input.type = "text"; input.dataset.key = key; input.value = row[key] || "";
    input.disabled = row.reference === true;
    let previous=input.value;
    input.onchange = () => {
      if(key==="id"&&!topologyEditor.renameScenario(previous,input.value)){input.value=previous;return;}
      previous=input.value;refreshScenarioChoices(); edited();
    };
    label.append(input); card.append(label);
  }
  for (const [key, title] of schema.technologies) {
    const input = document.createElement("input"), label = node("label");
    input.type = "checkbox"; input.dataset.tech = key; input.checked = row.technologies.includes(key);
    input.disabled = row.reference === true && key !== "grid";
    input.onchange = () => {refreshScenarioChoices(); edited();};
    label.append(input, document.createTextNode(title)); card.append(label);
  }
  {
    const remove = node("button", row.reference ? "Remove reference scenario" : "Remove scenario", "secondary");
    remove.onclick = () => {card.remove(); refreshScenarioChoices(); edited();}; card.append(remove);
  }
  byId("scenario-rows").append(card);
  if (row.overrides && Object.keys(row.overrides).length) { card.dataset.overrides = JSON.stringify(row.overrides); window.workflowUi?.paintOverrides(card); }
}
function addInputRow(containerId, row, fields) {
  const card = node("div", undefined, "input-row");
  for (const [key, title, type, options] of fields) {
    const label = node("label", title);
    const input = document.createElement(type === "select" ? "select" : "input");
    input.dataset.key = key;
    if (type === "select") {
      for (const value of options) {
        const option = node("option", value); option.value = value; input.append(option);
      }
    } else {
      input.type = type; if (type === "number") input.step = "any";
    }
    input.value = row[key] ?? "";
    input.oninput = edited;
    label.append(input); card.append(label);
    if (type === "number") unitsUi.decorateRow(key, input);
  }
  const remove = node("button", "Remove row", "secondary");
  remove.type = "button";
  remove.onclick = () => { card.remove(); edited(); };
  card.append(remove); byId(containerId).append(card);
}
const PLANNED_TECHS = ["Mobile Trailers", "Solar", "Wind", "BESS", "Energy Efficiency"];
const milestoneFields = [["year", "Year", "number"], ["peak_mw", "Gross annual peak MW (or leave blank)", "number"],
  ["growth_percent", "Year-on-year growth % (or leave blank)", "number"]];
const projectFields = [["name", "Project name", "text"], ["technology", "Technology", "select", PLANNED_TECHS],
  ["capacity_mw", "Committed capacity MW (EE: peak reduction)", "number"],
  ["energy_mwh", "BESS nameplate MWh (other technologies: 0)", "number"],
  ["start_year", "First commissioning year", "number"], ["end_year", "Last commissioning year (same year for a single date)", "number"],
  ["capacity_factor", "Wind screening capacity factor (other technologies: 0)", "number"],
  ["derate_factor", "Retained-output derate (0.85 retains 85%)", "number"],
  ["degradation", "Annual degradation after commissioning (fraction)", "number"],
  ["pf", "Operating power factor (0.8-1.0; MW is at this pf, rated MVA = MW / pf)", "number"]];
const trailerFields = [["name","Fleet name","text"],["technology","Technology","select",PLANNED_TECHS],
  ["start_year","Commissioning year","number"],["start_month","Commissioning month (1-12)","number"],
  ["pv_kw","Total PV capacity (kW)","number"],["bess_kw","Total BESS power (kW)","number"],
  ["bess_kwh","Total BESS energy (kWh)","number"],["availability","Share available on a given day (0.4 = 40%)","number"],
  ["derate_factor","PV retained-output derate","number"],["degradation","PV annual degradation (fraction)","number"]];
const PLANNED_SCHEMA = 2;
const TRAILER_FALLBACK = {pv_kw:0, bess_kw:0, bess_kwh:0, availability:.4, derate_factor:.85, degradation:.005, start_month:1};
// Server-side default trailer fleet for the existing or the planned bucket (engineering values from the source sheet).
function trailerDefault(existing) {
  const row = schema.planned_generation.find(r => r.technology === "Mobile Trailers" && (r.status === "existing") === existing);
  return row ? {...row} : {...TRAILER_FALLBACK};
}
function plannedDefaults(technology, existing) {
  const year = Number(byId("start_year").value);
  if (technology === "Mobile Trailers") return {...trailerDefault(existing), start_year:existing ? year-1 : year};
  return {capacity_mw:0, energy_mwh:0, start_year:existing ? year-1 : year, end_year:existing ? year-1 : year,
    capacity_factor:0, derate_factor:technology === "Solar" ? .85 : 1, degradation:technology === "Solar" ? .005 : 0, pf:.9};
}
// Each card remembers what was typed under every technology so switching the selector never discards entered values.
function addPlannedRow(containerId, row, memory = {}) {
  addInputRow(containerId, row, row.technology === "Mobile Trailers" ? trailerFields : projectFields);
  const card = byId(containerId).lastElementChild, select = card.querySelector("[data-key=technology]");
  card.dataset.technology = row.technology;
  select.onchange = () => {
    const current = Object.fromEntries([...card.querySelectorAll("[data-key]")].map(input =>
      [input.dataset.key, input.type === "number" ? (input.value === "" ? null : input.valueAsNumber) : input.value]));
    memory[card.dataset.technology] = {...current, technology:card.dataset.technology};
    const technology = select.value, name = current.name;
    addPlannedRow(containerId, memory[technology] ??
      {...plannedDefaults(technology, containerId === "existing-rows"), name, technology}, memory);
    card.replaceWith(byId(containerId).lastElementChild); trailerSummary(); edited();
  };
}
// Drafts and runs saved before PLANNED_SCHEMA could lose the trailer fleets (technology switch reset the inputs, or
// the rows were missing altogether); complete them from the defaults without touching values the user entered.
function repairTrailerRows(rows) {
  const isFuture = row => /future/i.test(row.name || "") || row.status === "planned";
  const repaired = rows.map(row => {
    if (row.technology !== "Mobile Trailers" || Number(row.pv_kw) || Number(row.bess_kw)) return row;
    const base = trailerDefault(!isFuture(row));
    return {...base, ...Object.fromEntries(Object.entries(row).filter(([, v]) => v !== null && v !== "" && v !== 0)),
      status:row.status};
  });
  const out = [];
  for (const existing of [true, false])
    if (!repaired.some(r => r.technology === "Mobile Trailers" && isFuture(r) !== existing))
      out.push({...trailerDefault(existing), status:existing ? "existing" : "planned"});
  return [...out.filter(r => r.status === "existing"), ...repaired, ...out.filter(r => r.status === "planned")];
}
function readPlanned() {
  return [...readRows("existing-rows").map(r => ({...r, status:"existing"})),
          ...readRows("planned-rows").map(r => ({...r, status:"planned"}))];
}function trailerSummary() {}
function readRows(id) {
  return [...byId(id).children].map(card => Object.fromEntries([...card.querySelectorAll("[data-key]")].map(input =>
    [input.dataset.key, input.type === "number" ? (input.value === "" ? null : unitsUi.canonical(input)) : input.value])));
}
function restoreRows(settings) {
  byId("milestone-rows").replaceChildren();
  byId("planned-rows").replaceChildren(); byId("existing-rows").replaceChildren();
  for (const row of settings.milestones ?? schema.milestones) addInputRow("milestone-rows", row, milestoneFields);
  let rows = (settings.planned_generation ?? schema.planned_generation).map(row => ({...row}));
  if (!rows.some(r => r.status))
    rows = [...schema.planned_generation.filter(r => r.technology === "Mobile Trailers"),
            ...rows.filter(r => r.technology !== "Mobile Trailers")];
  for (const row of rows) {
    if (row.technology === "Mobile Trailers" && row.pv_kw === undefined) {
      const n40 = row.units_40ft || 0, n53 = row.units_53ft || 0;
      row.pv_kw = n40*(row.pv_kw_40ft ?? 6) + n53*(row.pv_kw_53ft ?? 18);
      row.bess_kw = n40*(row.bess_kw_40ft ?? 15) + n53*(row.bess_kw_53ft ?? 257.1);
      row.bess_kwh = n40*(row.bess_kwh_40ft ?? 70) + n53*(row.bess_kwh_53ft ?? 1200);
    }
  }
  if (settings.planned_schema !== PLANNED_SCHEMA && settings.planned_generation) rows = repairTrailerRows(rows);
  for (const row of rows) {
    const future = row.technology === "Mobile Trailers" && /future/i.test(row.name || "");
    const existing = !future && (row.status === "existing" || (!row.status && row.technology === "Mobile Trailers"));
    addPlannedRow(existing ? "existing-rows" : "planned-rows", {...plannedDefaults(row.technology, existing), ...row});
  }
  trailerSummary();
}
function displayTable(id, columns, rows) {
  const table = node("table", undefined, "xl"), head = node("tr");
  for (const column of columns) head.append(node("th", column));
  table.append(head);
  for (const row of rows) {
    const tr = node("tr");
    for (const value of row) tr.append(node("td", typeof value === "number" ?
      value.toLocaleString(undefined, {maximumFractionDigits: 4}) : value ?? "N/A"));
    table.append(tr);
  }
  byId(id).replaceChildren(table);
}
function buildForm() {
  const groups = new Map();
  for (const f of schema.fields) {
    if (f.group !== "Scenarios" && !groups.has(f.group)) {
      const details = node("details");
      details.open = ["Demand", "Solar PV", "BESS", "Microgrid", "Financial"].includes(f.group);
      details.append(node("summary", f.group));
      details.dataset.group = f.group;
      groups.set(f.group, details);
      byId("fields").append(details);
    }
    const label = node("label");
    const input = document.createElement(f.kind === "select" ? "select" : "input");
    input.id = f.key;
    if (f.kind !== "select") input.type = f.kind;
    if (f.kind === "checkbox") {
      input.checked = f.default;
      label.append(input, document.createTextNode(f.label));
    } else if (f.kind === "select") {
      for (const [value, name] of f.options) {
        const option = node("option", name);
        option.value = value;
        input.append(option);
      }
      input.value = f.default;
      label.append(node("span", f.label), input);
    } else {
      input.min = f.min;
      input.max = f.max;
      input.step = "any";
      input.value = f.default;
      const unitSpan = node("span", f.unit, "unit");
      label.append(node("span", f.label), unitSpan, input);
      unitsUi.decorateField(f, input, unitSpan);
    }
    if (f.note) label.append(node("small", f.note, "hint"));
    if (/_pf(_lead)?$/.test(f.key)) {
      const derived = node("small", "", "hint pf-derived");
      derived.id = `${f.key}-derived`;
      label.append(derived);
      const show = () => {
        const pf = Number(input.value);
        if (!(pf >= 0.8 && pf <= 1)) { derived.textContent = "Operating pf must be 0.8 to 1.0."; return; }
        const q = Math.tan(Math.acos(pf));
        derived.textContent = `Per 1 MW: rated ${(1 / pf).toFixed(3)} MVA, ${f.key.endsWith("_lead") ? "absorbs" : "supplies"} up to ${q.toFixed(3)} Mvar.`;
      };
      input.addEventListener("input", show);
      show();
    }
    input.addEventListener("input", edited);
    if (f.group === "Demand" && ["start_year","horizon_years","forecast_mode","economic_growth","annualize_partial"].includes(f.key)) byId("planning-fields").append(label);
    else if (f.group === "Demand") byId("forecast-fields").append(label);
    else if (f.group === "Scenarios") byId("add-scenario").after(label);
    else groups.get(f.group).append(label);
  }
  groups.get("Demand").append(byId("demand-import"));
  groups.get("Solar PV").append(byId("solar-upload"));
  groups.get("Wind").append(byId("wind-upload"));
  groups.get("Thermal load").append(byId("thermal-upload"));
  groups.get("Demand").after(groups.get("Thermal load"));
  groups.get("Financial").append(byId("financial-reference-input"));
  byId("financial-reference").onchange = edited;
  for (const row of schema.scenario_definitions) addScenario(row);
  refreshScenarioChoices(defaultScenarios());
  byId("limitations").textContent = schema.limitations;
  restoreRows({});
  topologyEditor.init();
  for (const key of ["baseline", "target", "target_years"]) byId(key).disabled = byId("trajectory_mode").value === "milestones";
  for (const [name, url] of Object.entries(schema.references)) {
    const a = node("a", name + " benchmark reference");
    a.href = url;
    a.target = "_blank";
    a.rel = "noreferrer";
    const p = node("p");
    p.append(a);
    byId("references").append(p);
  }
  landSummary();
  planningHeader();
  visibility();
}
async function fetchJson(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || response.statusText);
  return data;
}
function fileUrl(name) { return `/files/${currentRun}/${encodeURIComponent(name)}`; }
function renderStatus(status) {
  workflowStatuses[currentRun] = status;
  byId("status").textContent = status.message;
  if (status.summary?.results?.length) {
    canAnalyze = true; solveRun = currentRun; solveSnapshot = status;
    window.dispatchEvent(new Event("solve-complete"));
    workflowRuns.solve = currentRun;
    if (!status.analysis && analysisSnapshot?.solve_id !== currentRun) analysisSnapshot = null;
  }
  const renderLoad = !workflowRuns.load || workflowRuns.load === currentRun;
  if (status.annual_trajectory && renderLoad) {
    const points = status.annual_trajectory;
    displayTable("annual-guide-table", ["Year", "Gross peak MW", "Annual increment MW", "Growth %"],
      points.map((p, i) => [p.year, p.peak_mw, i ? p.peak_mw - points[i - 1].peak_mw : null,
        i ? 100 * (p.peak_mw / points[i - 1].peak_mw - 1) : null]));
    byId("annual-guide-plot").src = fileUrl("annual_gross_forecast.png");
    byId("annual-guide-plot").hidden = false;
    byId("annual-guide-live")?.remove();
    const liveGuide = window.resultCharts?.build("annual_gross_forecast.png", {summary: {}, status});
    if (liveGuide) { liveGuide.id = "annual-guide-live"; byId("annual-guide-plot").after(liveGuide); byId("annual-guide-plot").hidden = true; }
  }
  if (status.planned_annual?.length && renderLoad) {
    displayTable("planned-audit", Object.keys(status.planned_annual[0]), status.planned_annual.map(Object.values));
  }
  if (status.analysis) {
    analysisSnapshot = {...status.analysis, solve_id:currentRun};
    workflowRuns.analyze = currentRun;
    displayTable("analysis-table", status.analysis.columns, status.analysis.rows);
    byId("analysis-notes").textContent = status.analysis.notes;
    byId("analysis-charts").replaceChildren();
    const liveAnalysis = window.resultCharts?.analysis(status.analysis, status.summary?.results || solveSnapshot?.summary?.results, status);
    if (liveAnalysis) byId("analysis-charts").append(liveAnalysis);
    else for (const name of ["lcoe_comparison.png", "economic_carbon_comparison.png"]) {
      const image = document.createElement("img"); image.src = fileUrl(name); image.alt = name.replaceAll("_", " ");
      byId("analysis-charts").append(image);
    }
    byId("analysis").hidden = false;
  }
  if (status.analysis_error) showError(status.analysis_error);
  if (status.planning) byId("run-planning").textContent =
    `Saved run: ${status.planning.start_year}-${status.planning.end_year}, ${status.planning.planning_hours.toLocaleString()} hours. ` +
    `${status.summary?.results?.[0]?.solver?.label || "HiGHS (legacy run)"}. Header reflects current input horizon.`;
  if (status.planning?.appraisal_years > status.planning?.horizon_years)
    byId("run-planning").textContent += ` Lifecycle optimization also redispatches final-year-load extrapolations through ${status.planning.appraisal_years} appraisal years (${status.planning.appraisal_dispatch_hours.toLocaleString()} total dispatch hours).`;
  if (status.source && renderLoad) byId("profile-source").textContent = status.source;
  if (status.charts && renderLoad && byId("load-plots").dataset.run !== currentRun) {
    byId("load-plots").replaceChildren();
    const table = node("table", undefined, "xl"), header = node("tr");
    for (const text of ["Year", "Hours", "Net minimum MW", "Net mean MW", "Net peak MW", "Net energy MWh", "Mean / baseline mean"]) header.append(node("th", text));
    table.append(header);
    for (const c of status.charts) {
      const card = node("article", undefined, "plot-card");
      card.append(node("h3", c.historical ? `${c.year} - Historical starting case` : String(c.year)));
      if (c.note) card.append(node("p", c.note, "muted"));
      card.append(node("div", `${c.hours.toLocaleString()} hours · mean ${c.mean_mw?.toFixed(3) ?? "N/A"} MW · peak ${c.peak_mw.toFixed(3)} MW · ${c.energy_mwh.toLocaleString(undefined, {maximumFractionDigits: 0})} MWh`, "plot-meta"));
      const image = document.createElement("img");
      image.src = fileUrl(c.image);
      image.alt = `${c.year} ${c.historical ? "historical starting-case" : "projected"} hourly demand profile`;
      image.loading = "lazy";
      card.append(image);
      byId("load-plots").append(card);
      const row = node("tr");
      for (const value of [c.historical ? `${c.year} (historical)` : String(c.year), c.hours, c.min_mw, c.mean_mw, c.peak_mw, c.energy_mwh, c.growth_factor]) {
        row.append(node("td", typeof value === "number" ? value.toLocaleString(undefined, {maximumFractionDigits: 4}) : value ?? "N/A"));
      }
      table.append(row);
    }
    byId("forecast-table").replaceChildren(table);
    byId("load-plots").dataset.run = currentRun;
  }
  if (status.files) {
    const forecast = byId("download-forecast");
    if (renderLoad && status.files.includes("hourly_projected_load.csv")) {
      forecast.href = fileUrl("hourly_projected_load.csv");
      forecast.download = "hourly_projected_load.csv";
      forecast.hidden = false;
    }
  }
  if (status.summary) {
    const table = node("table", undefined, "xl"), head = node("tr");
    const named = namedGeneratorTable(status.summary), columns = named.columns;
    const addSavedGridColumn = !columns.includes("Grid peak import MW") &&
      status.summary.results.some(r => (r.eligible_technologies || ["grid"]).includes("grid"));
    const gridColumnIndex = columns.findIndex(name => name.startsWith("Upfront investment"));
    if (addSavedGridColumn) columns.splice(gridColumnIndex, 0, "Grid peak import MW");
    const view = unitsUi.adaptColumns(columns);
    columns.forEach((c, ci) => {
      const cell = node("th", view.columns[ci]);
      if (c === "Grid peak import MW") cell.title =
        "Maximum modeled within-hour grid draw over the normal planning horizon, not the interconnection rating or average import.";
      head.append(cell);
    });
    const techByColumn = {"Solar MW": "pv", "BESS MW": "bess", ...Object.fromEntries(schema.technologies.filter(([key]) => key !== "grid" && key !== "pv" && key !== "bess").map(([key, name]) => [name + " MW", key]))};
    table.append(head);
    for (const row of named.rows) {
      const tr = node("tr");
      const displayRow = [...row];
      if (addSavedGridColumn) {
        const result = (status.summary.results || []).find(r => r.code === row[0]);
        displayRow.splice(gridColumnIndex, 0, result?.validation?.max_quarter_hour_grid_mw ?? null);
      }
      const result = (status.summary.results || []).find(r => r.code === row[0]);
      displayRow.forEach((value, ci) => {
        const td = node("td", typeof value === "number" ?
          (value * view.factors[ci]).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 4}) : value ?? "N/A");
        const tech = techByColumn[columns[ci]];
        if (tech && result && typeof value === "number" && value <= 1e-6 && (result.eligible_technologies || []).includes(tech)) {
          td.classList.add("unbuilt");
          td.textContent = "0 (not selected)";
          td.title = "Eligible in this scenario but not built: the optimizer found it uneconomic.";
        }
        tr.append(td);
      });
      table.append(tr);
    }
    byId("result-table").replaceChildren(table);
    byId("failures").replaceChildren();
    byId("adequacy-warnings").replaceChildren();
    for (const r of status.summary.results || []) {
      const a = r.adequacy;
      if (a && (a.unserved_hours > 0 || a.stress_unserved_mwh > 0.00005)) {
        byId("adequacy-warnings").append(node("div",
          `${r.code}: ${unitsUi.scaleEnergy(a.unserved_mwh).toLocaleString(undefined, {maximumFractionDigits: 3})} ${unitsUi.label.energy()} unserved in ${a.unserved_hours.toLocaleString()} hours; peak hourly shortfall ${unitsUi.scalePower(a.peak_unserved_mw).toFixed(3)} ${unitsUi.label.power()}. Stress-month unserved: ${unitsUi.scaleEnergy(a.stress_unserved_mwh).toFixed(3)} ${unitsUi.label.energy()}. This case does not meet all demand; do not compare its lower cash cost as an equivalent-service saving.`, "notice"));
      }
    }
    for (const r of status.summary.results || []) {
      const p = r.provenance;
      if (p?.status) byId("failures").append(node("div", `${r.code}: ${p.status === "re_solved" ? "re-solved in this run" : "carried over unchanged from run " + p.from_run}.`, "notice"));
    }
    for (const f of status.summary.failures) {
      byId("failures").append(node("div", `${f.code}: no validated solution. ${f.error}`, "failure"));
    }
    byId("solve-dispatch-slot").append(byId("dispatch-explorer"));
    byId("result-charts").replaceChildren();
    for (const name of ["cost_comparison.png", "generation_mix.png", "annual_costs.png", "peak_dispatch.png", "unserved_load.png"]) {
      if (!status.files?.includes(name)) continue;
      if(name==="peak_dispatch.png") {
        byId("result-charts").append(byId("dispatch-explorer"));
        dispatchExplorer.show(currentRun,status.summary.results||[]);
        continue;
      }
      const live = window.resultCharts?.build(name, {summary: status.summary, status});
      if (live) { byId("result-charts").append(live); continue; }
      const image = document.createElement("img");
      image.src = fileUrl(name);
      image.alt = name.replaceAll("_", " ");
      byId("result-charts").append(image);
    }
    byId("results").hidden = false;
  }
  localStorage.setItem("generation-workflow-runs",JSON.stringify(workflowRuns));
  if (activeView === "summary") renderSummary();
  window.reportUi?.refresh();
}
async function poll() {
  try {
    const status = await fetchJson(`/api/jobs/${currentRun}`);
    guardPanel(activeView, () => renderStatus(status));
    const running = ["running", "queued"].includes(status.state);
    interruptRun=running?currentRun:null;
    setBusy(running);
    if (running) polling = setTimeout(poll, 1800);
    if (status.state === "failed") showError(status.message);
    if (status.state === "complete" && !running) window.workflowUi?.complete(currentRun, status).catch(error => console.error(error));
    if (status.state === "cancelled" || status.state === "interrupted") {
      if(priorSolveState?.snapshot) {
        solveRun=priorSolveState.run;solveSnapshot=priorSolveState.snapshot;analysisSnapshot=priorSolveState.analysis;
      }
      canAnalyze=!!solveSnapshot?.summary?.results?.length;
      byId("analyze").disabled=!canAnalyze;
      if(solveSnapshot){byId("results").hidden=false;if(analysisSnapshot)byId("analysis").hidden=false;}
    }
  } catch (error) {
    setBusy(false);
    showError(`Cannot read run status: ${error.message}. Run ${currentRun} is saved locally. Reload to reconnect.`);
  }
}
async function stopRun() {
    if(!busy||!interruptRun||cancelling)return;
    cancelling=true;byId("stop-run").disabled=true;
    byId("status").textContent="Stopping the local worker...";
    if(polling)clearTimeout(polling);
    try {
      await fetchJson("/api/cancel",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({id:interruptRun})});
      await poll();
    }catch(error) {
      showError("Could not stop run: "+error.message);
      await poll();
    }finally{cancelling=false;byId("stop-run").disabled=false;}
  }
async function start(solve, plan) {
  if (busy) return;
  if (solve && !plan && mergeFrom && !byId("quick-rerun").checked)
    plan = {pending: true, base: mergeFrom, codes: [...byId("scenarios").querySelectorAll("input:checked")].map(input => input.value)};
  showError("");
  for (const f of schema.fields) {
    if (!byId(f.key).reportValidity()) return;
  }
  interruptRun=null;setBusy(true);
  byId("status").textContent = solve ? "Submitting optimization run..." : "Submitting hourly profile run...";
  try {
    if (plan?.pending) plan = await window.workflowUi.resolvePlan(plan);
    const payload = request(solve, plan);
    const job = await fetchJson("/api/jobs", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(payload)});
    currentRun = job.id;
    interruptRun=job.id;
    if (!solve) workflowRuns.load = currentRun;
    else {
      priorSolveState={run:solveRun,snapshot:solveSnapshot,analysis:analysisSnapshot};
      // Keep the last complete solve as the results source until the new worker publishes results.
    }
    history.replaceState(null, "", `?run=${currentRun}`);
    localStorage.setItem("generation-run", currentRun);
    localStorage.setItem("generation-settings", JSON.stringify({...payload, upload_files: [], upload_csv: "",
      historical_files: [], forecast_files: [], combined_files: [],
      solar_file:null, planned_solar_file:null, thermal_file:null,wind_file:null,
      solar_resource_name:resourceUploads.solar_file?.name,
      planned_solar_resource_name:resourceUploads.planned_solar_file?.name}));
    byId("stale").hidden = false;
    byId("stale").textContent = "This run uses the inputs captured when submitted. Edits during a run apply only to the next run.";
    if (solve) { canAnalyze = false; byId("results").hidden = true; byId("analysis").hidden = true; }
    if (polling) clearTimeout(polling);
    await poll();
  } catch (error) {
    setBusy(false);
    showError(error.message);
  }
}
function defaultScenarios() {
  return schema.scenario_definitions.filter(s => !s.technologies.some(t => t.endsWith("_chp"))).map(s => s.id);
}
function restore(settings) {
  unitsUi.begin();
  resourceUploads = {solar_file:null, planned_solar_file:null, thermal_file:null,wind_file:null};
  for (const id of ["solar-file-status","planned-solar-file-status","thermal-file-status","wind-file-status"])
    byId(id).textContent = "Reselect the resource CSV for a new run, or use the Los Angeles TMY button.";
  const migrated = {...settings.values};
  if (migrated.pv_fom !== undefined && migrated.pv_fom_fraction === undefined)
    migrated.pv_fom_fraction = migrated.pv_fom / (migrated.pv_capex || 2500000);
  for (const tech of ["ng","ng_chp","h2","h2_chp"]) {
    if (migrated[tech+"_fom"] !== undefined && migrated[tech+"_fom_fraction"] === undefined)
      migrated[tech+"_fom_fraction"] = migrated[tech+"_fom"] / (migrated[tech+"_capex"] ||
        schema.fields.find(f=>f.key === tech+"_capex").default);
    migrated[tech+"_fuel_price"] ??= migrated[tech.startsWith("h2") ? "hydrogen_price" : "gas_price"] ??
      schema.fields.find(f=>f.key === tech+"_fuel_price").default;
  }
  for (const f of schema.fields) {
    const value = migrated[f.key] ?? f.default;
    if (f.kind === "checkbox") byId(f.key).checked = value === true;
    else byId(f.key).value = value;
  }
  byId("scenario-rows").replaceChildren();
  const definitions = settings.application_version >= 4 ? settings.scenario_definitions ?? schema.scenario_definitions : schema.scenario_definitions;
  for (const s of definitions) addScenario(s);
  refreshScenarioChoices(settings.application_version >= 4 ? settings.scenarios : defaultScenarios());
  byId("financial-reference").value = settings.comparison_reference === null ? "" : settings.comparison_reference || "R0";
  byId("demand-workflow").value = settings.demand_source || "upload";
  byId("technical-check").checked = settings.technical_check !== false;
  byId("technical-islanded").checked = settings.technical_islanded === true;
  byId("planned-solar-enabled").checked = settings.planned_solar_profile_enabled === true;
  restoreRows(settings);
  topologyEditor.restore(settings.topology);
  unitsUi.restore(settings.display_units);
  edited();
}
async function analyzeRun() {
  if (busy || !canAnalyze) return;
  showError(""); interruptRun=null;setBusy(true);
  try {
    await fetchJson("/api/analyze", {method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({id: solveRun})});
    currentRun = solveRun;
    await poll();
  } catch (error) { setBusy(false); showError(error.message); }
}
async function loadSolarDefault(planned=false) {
  const response = await fetch("/solar-inputs/los_angeles_solar_hourly_2025_2026.csv");
  if (!response.ok) throw new Error("Cannot load Los Angeles solar CSV.");
  const file = {name:"los_angeles_solar_hourly_2025_2026.csv",content:await response.text()};
  const key = planned ? "planned_solar_file" : "solar_file";
  resourceUploads[key] = file;
  byId(planned ? "planned-solar-enabled" : "solar_profile_enabled").checked = true;
  byId(planned ? "planned-solar-file-status" : "solar-file-status").textContent = file.name + " — TMY, fixed PST, not observed 2025–2026.";
  edited();
}
async function selectProfiles(event, key) {
  try {
    const files = [...event.target.files];
    let loaded = await Promise.all(files.map(async file => ({name: file.name, content: await file.text()})));
    let note = "";
    if ((key === "historical_files" || key === "forecast_files") && loaded.length) {
      const checked = await dataPrep.review("load", loaded);
      if (!checked) { event.target.value = ""; return; }
      if (checked.report) note = `corrected automatically (quality ${checked.report.score}/100, ${checked.report.repaired_hours.toLocaleString()} hours repaired)`;
      loaded = checked.files;
    }
    const next = {...profileUploads, [key]: loaded};
    if (key === "combined_files" && loaded.length) {
      next.historical_files = []; next.forecast_files = [];
      byId("historical-csv").value = ""; byId("forecast-csv").value = "";
    } else if (loaded.length) { next.combined_files = []; byId("combined-csv").value = ""; }
    if (Object.values(next).flat().reduce((total, f) => total + new Blob([f.content]).size, 0) > 24000000)
      throw new Error("Combined profile uploads exceed 24 MB.");
    profileUploads = next;
    if (next.forecast_files.length || next.combined_files.length) byId("demand-workflow").value = "upload";
    byId("profile-uploads").textContent = Object.entries(next).map(([k, list]) =>
      `${k}: ${list.map(f => f.name).join(", ") || "none"}`).join(" | ") + (note ? " — " + note : "");
    edited();
  } catch (error) { event.target.value = ""; showError(error.message); }
}
async function checkSolvers() {
  try {
    const response = await fetch("/api/x/solvers");
    if (!response.ok) return;
    const info = await response.json();
    const gurobi = info.gurobi, option = [...byId("solver").options].find(o => o.value === "gurobi");
    if (!option || !gurobi || (gurobi.installed && gurobi.licensed)) return;
    option.disabled = true;
    option.textContent += ` - unavailable: ${gurobi.message || (gurobi.installed ? "no licence" : "gurobipy not installed")}`;
    if (byId("solver").value === "gurobi") byId("solver").value = "highs";
  } catch (error) { console.warn("Solver availability unknown", error); }
}
async function init() {
  try {
    schema = await fetchJson("/api/defaults");
    byId("app-version").textContent = schema.version?.label ?? "";
    buildForm();
    checkSolvers();
    for (const button of document.querySelectorAll("[data-view]"))
      button.onclick = () => switchView(button.dataset.view);
    const saved = localStorage.getItem("generation-settings");
    let restoredSettings = saved ? JSON.parse(saved) : null;
    if (saved) restore(JSON.parse(saved));
    const solverOptions = schema.fields.find(f=>f.key === "solver_method").options;
    for (const [value,label] of solverOptions) {
      const option = node("option",label); option.value = value;
      byId("solver-choice").append(option);
    }
    byId("solve").onclick = () => {
      if (busy) return;
      byId("solver-choice").value = byId("solver_method").value;
      byId("solver-dialog").showModal();
    };
    byId("cancel-solve").onclick = () => byId("solver-dialog").close();
    byId("confirm-solve").onclick = () => {
      byId("solver_method").value = byId("solver-choice").value;
      byId("solver-dialog").close(); edited(); start(true);
    };
    byId("preview").onclick = () => start(false);
    byId("analyze").onclick = analyzeRun;
    byId("export-summary-pdf").onclick = async () => {
      const button=byId("export-summary-pdf");
      button.disabled=true;showError("");
      try {
        const report=await fetchJson("/api/summary-pdf",{method:"POST",headers:{"Content-Type":"application/json"},
          body:JSON.stringify({id:solveRun})});
        const link=node("a");link.href=report.url;link.download="results_summary.pdf";link.click();
      } catch(error){showError("PDF export failed: "+error.message);}
      finally {button.disabled=false;}
    };
    byId("demand-workflow").onchange = edited;
    byId("planned-solar-enabled").onchange = edited;
    byId("use-la-solar").onclick = () => loadSolarDefault().catch(e=>showError(e.message));
    byId("use-la-planned").onclick = () => loadSolarDefault(true).catch(e=>showError(e.message));
    for (const [id,key,status] of [["solar-csv","solar_file","solar-file-status"],["wind-csv","wind_file","wind-file-status"],
      ["planned-solar-csv","planned_solar_file","planned-solar-file-status"],
      ["thermal-csv","thermal_file","thermal-file-status"]]) {
      byId(id).onchange = async event => {
        try {
          const file = event.target.files[0];
          let loaded = file ? {name:file.name,content:await file.text()} : null;
          let note = "";
          if (loaded) {
            const kind = key === "wind_file" ? "wind" : key === "thermal_file" ? "thermal" : "solar";
            const resourceFile = kind === "solar" && /(^|,)(ghi_w_m2|dni_w_m2|dhi_w_m2)(,|$)/.test((loaded.content.split(/\r?\n/, 1)[0] || "").replace(/\s/g, ""));
            const checked = resourceFile ? {files: [loaded]} : await dataPrep.review(kind, [loaded]);
            if (!checked) { event.target.value = ""; byId(status).textContent = "No resource selected."; resourceUploads[key] = null; edited(); return; }
            if (checked.report) { loaded = {name:file.name, content:checked.files[0].content}; note = " — corrected automatically"; }
          }
          resourceUploads[key] = loaded;
          byId(status).textContent = loaded ? file.name + note : "No resource selected.";
          edited();
        } catch (error) { showError(error.message); }
      };
    }
    byId("include-reference").onchange = event => toggleReferenceScenario(event.target.checked);
    byId("add-scenario").onclick = () => {
      const ids = new Set(readScenarioRows().map(s => s.id));
      let n = 1; while (ids.has("S" + n)) n++;
      addScenario({id:"S"+n,name:"New scenario",technologies:["grid","pv","bess"]});
      refreshScenarioChoices([...byId("scenarios").querySelectorAll("input:checked")].map(i=>i.value).concat("S"+n)); edited();
    };
    byId("add-load").onclick = () => { byId("load-import-panel").hidden = !byId("load-import-panel").hidden; };
    byId("project-loads").onclick = async () => {
      showError("");
      try {
        const names = ["historical_hourly_2026.csv", "customer_forecast_hourly_2027_2036.csv"];
        const files = await Promise.all(names.map(async name => {
          const response = await fetch("/load-inputs/" + name);
          if (!response.ok) throw new Error("Cannot load project file " + name);
          return {name, content:await response.text()};
        }));
        profileUploads = {historical_files:[files[0]], forecast_files:[files[1]], combined_files:[]};
        byId("start_year").value = 2027; byId("horizon_years").value = 10;
        byId("demand-workflow").value = "upload";
        byId("load-import-panel").hidden = false;
        for (const id of ["historical-csv","forecast-csv","combined-csv"]) byId(id).value = "";
        byId("profile-uploads").textContent = names.join(" + ");
        edited();
      } catch (error) { showError(error.message); }
    };
    byId("add-milestone").onclick = () => {
      const year = Math.max(Number(byId("start_year").value)-2,
        ...readRows("milestone-rows").map(row=>Number(row.year))) + 1;
      addInputRow("milestone-rows", {year}, milestoneFields); edited();
    };
    byId("add-existing").onclick = () => { addPlannedRow("existing-rows", {name:"Existing generation",
      technology:"Solar", ...plannedDefaults("Solar", true)}); trailerSummary(); edited(); };
    byId("existing-rows").addEventListener("input", trailerSummary);
    byId("planned-rows").addEventListener("input", trailerSummary);
    byId("add-project").onclick = () => { addPlannedRow("planned-rows", {name:"Planned asset", technology:"Solar",
      ...plannedDefaults("Solar", false)}); edited(); };
    for (const [id, key] of [["historical-csv", "historical_files"], ["forecast-csv", "forecast_files"], ["combined-csv", "combined_files"]])
      byId(id).onchange = event => selectProfiles(event, key);
    byId("clear-profiles").onclick = () => {
      profileUploads = {historical_files: [], forecast_files: [], combined_files: []};
      for (const id of ["historical-csv", "forecast-csv", "combined-csv"]) byId(id).value = "";
      byId("profile-uploads").textContent = "No separate or combined uploads selected."; edited();
    };
    byId("milestone-csv").onchange = async event => {
      try {
        const response = await fetchJson("/api/milestones", {method:"POST", headers:{"Content-Type":"application/json"},
          body: JSON.stringify({csv: await event.target.files[0].text(), baseline_year:Number(byId("start_year").value)-1})});
        byId("milestone-rows").replaceChildren();
        for (const row of response.milestones) addInputRow("milestone-rows", row, milestoneFields);
        edited(); showError("");
      } catch (error) { showError("Milestone CSV rejected: " + error.message); }
    };
    byId("reset").onclick = () => {
      restore({values: {}, application_version:4, scenarios: defaultScenarios()});
      byId("clear-profiles").click();
      byId("demand-workflow").value = "generate";
      edited();
    };
    byId("save-inputs").onclick = () => {
      const settings = inputWorkspace.snapshot();
      const url = URL.createObjectURL(new Blob([JSON.stringify(settings, null, 2)], {type: "application/json"}));
      const a = node("a"); a.href = url; a.download = "generation_input_settings.json"; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    };
    byId("settings-file").onchange = async event => {
      try {
        const settings=JSON.parse(await event.target.files[0].text());
        restore(settings);inputWorkspace.applyUploads(settings);edited();
      }
      catch (error) { showError("Cannot restore settings: " + error.message); }
    };
    const linkedRun = new URLSearchParams(location.search).get("run");
    const inputDraft = await inputWorkspace.load();
    workflowRuns = JSON.parse(localStorage.getItem("generation-workflow-runs") || "{}");
    if (linkedRun) {
      const linkedStatus=await fetchJson(`/api/jobs/${linkedRun}`);
      if(!["cancelled","interrupted"].includes(linkedStatus.state))workflowRuns={solve:linkedRun};
    }
    currentRun = linkedRun || localStorage.getItem("generation-run");
    if (currentRun) {
      if (linkedRun) {
        const status = await fetchJson(`/api/jobs/${currentRun}`);
        if (status.files?.includes("run_configuration.json")) {
          const configuration = await fetchJson(fileUrl("run_configuration.json"));
          restore(configuration.request);
          restoredSettings = configuration.request;
          if (!configuration.application_version) {
            byId("adequacy-warnings").append(node("div",
              "This is an earlier saved run. Its reference included planned PV and its horizon/forecast rules may differ. Click SOLVE for the updated grid-only reference and selectable forecast.", "notice"));
          }
        }
      }
      byId("stale").hidden = false;
      byId("stale").textContent = "Restored saved run. An uploaded CSV is not retained by the form after reload; reselect it for a new run. Saved reports still use the original run input.";
      await poll();
    } else byId("status").textContent = "Load your historical and forecast CSVs under Demand, or select Generate a forecast.";
    const latestRun = currentRun;
    if (workflowRuns.load && workflowRuns.load !== currentRun) {
      currentRun = workflowRuns.load;
      renderStatus(await fetchJson(`/api/jobs/${currentRun}`));
    }
    if (workflowRuns.solve && workflowRuns.solve !== currentRun) {
      currentRun = workflowRuns.solve;
      renderStatus(await fetchJson(`/api/jobs/${currentRun}`));
    }
    currentRun = latestRun;
    if (inputDraft && (!linkedRun || inputDraft.source_run === linkedRun)) {
      restore(inputDraft);inputWorkspace.applyUploads(inputDraft);restoredSettings=inputDraft;
      byId("draft-status").textContent="Restored autosaved local inputs and uploaded profiles";
    }
    if (!restoredSettings || restoredSettings.application_version < 5) {
      await loadSolarDefault(); await loadSolarDefault(true);
    }
    if (restoredSettings?.application_version >= 5) {
      const resourceNames = restoredSettings;
      const solarName = resourceNames.solar_resource_name || resourceNames.profile_file_hashes?.solar_file?.[0]?.name;
      const plannedName = resourceNames.planned_solar_resource_name || resourceNames.profile_file_hashes?.planned_solar_file?.[0]?.name;
      if (!resourceUploads.solar_file && solarName === "los_angeles_solar_hourly_2025_2026.csv" &&
          byId("solar_profile_enabled").checked) await loadSolarDefault();
      if (!resourceUploads.planned_solar_file && plannedName === "los_angeles_solar_hourly_2025_2026.csv" &&
          byId("planned-solar-enabled").checked) await loadSolarDefault(true);
    }
    inputWorkspace.init();
    byId("stop-run").onclick=stopRun;
    byId("explore-dispatch").onclick=()=>{
      switchView("summary");byId("dispatch-explorer").scrollIntoView({block:"start",behavior:"smooth"});
    };
    switchView(solveSnapshot ? (analysisSnapshot ? "summary" : "solve") : "load");
    document.body.dataset.ready = "true";
  } catch (error) { showError("Application initialization failed: " + error.message); }
}
init();
