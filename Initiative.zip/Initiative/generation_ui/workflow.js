"use strict";
// Two-step workflow UI: economic ranking by total NPC with technical remarks, technical-check control, apply-corrections-and-re-solve
// loop (max 3 iterations), rerun-from-Power-Flow (full re-solve with per-scenario overrides) and before/after comparison.
(() => {
  const SUFFIXES = ["_capex", "_fom_fraction", "_vom", "_fuel_price", "_efficiency", "_heat_efficiency", "_min_load", "_ramp",
    "_startup", "_acres", "_acres_per_mw", "_acres_per_mwh", "_land_enabled", "_tc_enabled", "_throughput_cost"];
  const KEYS = ["microgrid_min_mw", "microgrid_max_mw", "duration_min", "duration_max", "soc_min", "soc_max", "round_trip_efficiency", "daily_cycles"];
  const MAX_ITER = 3;
  const state = {data: null, run: null, loading: null, timer: null, loop: null};
  const $ = id => document.getElementById(id);
  const h = (tag, text, cls) => { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; if (cls) e.className = cls; return e; };
  const money = v => v === null || v === undefined ? "-" : currencyUi.money(v, 2, true);
  const delta = v => v === null || v === undefined ? "-" : (v > 0 ? "+" : v < 0 ? "-" : "") + money(Math.abs(v));
  const overridable = key => KEYS.includes(key) || (SUFFIXES.some(s => key.endsWith(s)) && !key.startsWith("hydrogen") && !key.startsWith("gas_"));
  const badge = status => h("span", status || "NOT_RUN", "badge " + ({PASS: "pass", WARN: "warn", FAIL: "fail"}[status] || ""));

  function recommended(results) {
    const wf = state.data;
    if (!wf || wf.run_id !== solveRun || !wf.recommended?.code) return null;
    const best = (results || []).find(r => r.code === wf.recommended.code);
    return best ? {best, feasible: !!wf.recommended.fully_supplied, adjusted: !!wf.recommended.checked} : null;
  }
  const recommendedCode = () => state.data?.run_id === solveRun ? state.data.recommended?.code || null : null;
  const checked = () => !!(state.data?.run_id === solveRun && state.data.recommended?.checked);

  async function load(run) {
    if (!run) return null;
    if (state.loading === run) return state.data;
    state.loading = run;
    try {
      const data = await fetchJson(`/api/x/workflow?run_id=${run}`);
      state.data = data; state.run = run;
      render();
      window.dispatchEvent(new Event("workflow-updated"));
      clearTimeout(state.timer);
      if (data.check?.state === "running") state.timer = setTimeout(() => { state.loading = null; load(run); }, 1500);
      return data;
    } catch (error) { console.error(error); return null; } finally { state.loading = null; }
  }

  const UNIT_DEFAULTS = {capacitor_usd_per_kvar: 25, reactor_usd_per_kvar: 20, transformer_usd_per_mva: 12000,
    line_upgrade_usd_per_mva: 40000, reactive_capability_usd_per_kvar: 60};

  function explainer(wf) {
    const u = {...UNIT_DEFAULTS, ...(wf.unit_costs || {})};
    const box = h("div", undefined, "wf-explain");
    box.append(h("p", "Ranking is economic: the lowest total NPC (CAPEX, OPEX, fuel and variable cost, replacements, upgrades and any network equipment already applied) among scenarios that serve all load. " +
      "The technical check only adds a PASS/WARN/FAIL remark, notes and the indicative cost of the corrections still required.", "muted wf-info"));
    const d = h("details", undefined, "wf-what"); d.id = "wf-what-is-this";
    d.append(h("summary", "What is this? (corrections and the indicative-corrections column)"));
    const list = h("ul");
    for (const t of [
      "A correction is equipment that must be added so the scenario works on the network: shunt capacitor banks or reactors (voltage), transformer or line upgrades (overloads), or extra reactive capability on a generator or inverter.",
      "Corrections are NOT part of the optimization. The optimizer picks the mix purely on economics. After the solve, the power-flow check finds problems and the corrections are priced at unit costs for information only.",
      `Unit costs used: capacitor bank ${money(u.capacitor_usd_per_kvar)}/kvar, reactor ${money(u.reactor_usd_per_kvar)}/kvar, transformer ${money(u.transformer_usd_per_mva)}/MVA, line upgrade ${money(u.line_upgrade_usd_per_mva)}/MVA of added rating, extra reactive capability ${money(u.reactive_capability_usd_per_kvar)}/kvar.`,
      "Effect on ranking: none. 'NPC incl. indicative corrections' is informational. Use 'Apply corrections to all scenarios & re-solve' to add the corrections to every scenario's inputs, re-solve and re-rank; the cost of applied corrections is then included in the total NPC and moves from 'Still required' to 'Applied' (the identified total is kept). Microgrid size limits are never lowered automatically; widening them is advisory only."]) list.append(h("li", t));
    d.append(list);
    box.append(d);
    return box;
  }

  function notesFor(e, wf) {
    const notes = [];
    if (e.is_recommended) notes.push(e.technical_status === "FAIL" ? "Recommended (lowest total NPC); not yet technically compliant" : "Recommended (lowest total NPC)");
    if (!e.feasible) notes.push("does not serve all load");
    for (const t of e.unbuilt || []) notes.push(`${t.label} eligible but not selected by the optimizer (uneconomic)`);
    if (e.same_mix_as?.length) notes.push(`same mix as ${e.same_mix_as.join(", ")}`);
    if (e.tie_with?.length) notes.push(e.is_recommended && e.is_leader ? `within 0.05% of ${e.tie_with.join(", ")}; simpler option preferred` : `within 0.05% of ${e.tie_with.join(", ")}`);
    if (e.technical_status === "NOT_RUN") notes.push("NOT technically checked: " + (e.check_message || "the check did not run"));
    if (wf.recommended?.checked && e.technical_status !== "PASS" && !e.costed && e.technical_status !== "NOT_RUN") notes.push("corrections not costed");
    if (e.applied_cost_usd) notes.push(`includes ${money(e.applied_cost_usd)} of corrections already applied`);
    if (e.shunt && (e.shunt.mvar || e.shunt.cost_usd)) notes.push(`shunt ${e.shunt.mvar != null ? e.shunt.mvar + " Mvar" : ""}${e.shunt.cost_usd != null ? " (" + money(e.shunt.cost_usd) + ")" : ""}`.replace("shunt  ", "shunt "));
    if (e.fix_items?.length) notes.push("corrections needed: " + e.fix_items.filter(i => i.cost_usd).map(i => `${i.label} ${money(i.cost_usd)}`).join(", "));
    if (Object.keys(e.overrides || {}).length) notes.push("overrides: " + Object.entries(e.overrides).map(([k, v]) => `${k}=${v}`).join(", "));
    if (e.islanded?.enabled) notes.push(`${e.islanded.chip} (informational, not used for the recommendation)`);
    return notes.filter(n => !/^corrections needed: $/.test(n));
  }

  function rankingTable(wf) {
    const wrap = h("div", undefined, "table-scroll");
    const t = h("table", undefined, "wf-table xl");
    const head = h("tr");
    const tech = !!wf.recommended?.checked;
    for (const x of tech ? ["Scenario", "Rank (economic)", "NPC (total)", "Technical status", "Violations", "Corrections identified", "Applied", "Still required", "NPC incl. still-required corrections (informational)", "Notes"] :
      ["Scenario", "Rank (economic)", "NPC (total)", "Notes"]) head.append(h("th", x));
    t.append(head);
    const rows = [...wf.scenarios].sort((a, b) => (a.rank ?? 1e9) - (b.rank ?? 1e9) || a.order - b.order);
    for (const e of rows) {
      const tr = h("tr", undefined, e.is_recommended ? "best-row" : "");
      tr.append(h("td", `${e.code} - ${e.name || ""}`), h("td", e.rank ?? "-"), h("td", money(e.total_npc ?? e.npc)));
      if (tech) {
        const status = h("td"); status.append(badge(e.technical_status));
        if (e.technical_status === "NOT_RUN" && e.check_message) status.title = e.check_message;
        const found = h("td", e.costed || e.applied_cost_usd ? money(e.identified_cost_usd ?? e.fix_cost_usd) : "-");
        found.title = (e.identified_items || []).map(i => `${i.label}: ${money(i.cost_usd)} (${i.state})`).join("\n");
        tr.append(status, h("td", e.technical_status === "NOT_RUN" ? "-" : e.violation_count ?? (e.violations || []).length), found,
          h("td", money(e.applied_cost_usd || 0)), h("td", e.costed ? money(e.fix_cost_usd) : "-"), h("td", money(e.adjusted_npc)));
      }
      tr.append(h("td", notesFor(e, wf).join("; ")));
      t.append(tr);
    }
    wrap.append(t);
    return wrap;
  }

  function iterationTable(wf) {
    const wrap = h("div", undefined, "table-scroll"); wrap.id = "wf-history";
    wrap.append(h("h4", "Iteration history"));
    const t = h("table", undefined, "wf-table xl");
    const head = h("tr");
    for (const x of ["Run", "Recommended", "Technical status", "Violations", "Total NPC", "Corrections applied", "Corrections still required"]) head.append(h("th", x));
    t.append(head);
    for (const i of wf.iterations) {
      const tr = h("tr");
      const label = h("td", i.label || `Run ${i.iteration}`); label.title = `Run id ${i.run_id || ""}`;
      tr.append(label);
      for (const v of [`${i.code || "-"}${i.name ? " - " + i.name : ""}`, i.status || "-", i.violations ?? "-",
        money(i.total_npc ?? i.npc), money(i.applied_usd || 0), money(i.indicative_usd || 0)]) tr.append(h("td", v));
      t.append(tr);
    }
    wrap.append(t);
    return wrap;
  }

  // Buttons beside the technical check: apply corrections everywhere and re-solve, or review them on the Power Flow page.
  function actionButtons(wf) {
    const rec = wf.recommended || {}, bar = h("div", undefined, "wf-actions"); bar.id = "wf-actions";
    const needs = wf.scenarios.some(e => ["FAIL", "WARN"].includes(e.technical_status) && e.corrections?.count);
    if (!rec.checked || !needs) return null;
    const apply = h("button", "Apply corrections to all scenarios & re-solve"); apply.id = "wf-apply-all"; apply.type = "button";
    apply.disabled = busy || wf.check?.state === "running";
    apply.onclick = () => applyAll(wf).catch(error => { state.loop = null; showError(error.message); });
    const review = h("button", "Review & edit in Power Flow page", "secondary"); review.id = "wf-review-pf"; review.type = "button";
    review.onclick = () => window.powerFlowStatus?.open?.(rec.code);
    bar.append(apply, review);
    return bar;
  }

  async function applyAll(wf) {
    const plan = await fetchJson(`/api/x/workflow_corrections?run_id=${solveRun}`);
    const codes = Object.keys(plan.scenarios || {});
    if (!codes.length) throw new Error("No verified corrections are available to apply.");
    const changes = {}, applied = {}, notes = [];
    for (const code of codes) {
      const c = plan.scenarios[code];
      if (c.diagram && window.topologyEditor?.setDiagram) window.topologyEditor.setDiagram(code, c.diagram);
      if (Object.keys(c.patch?.nodes || {}).length || Object.keys(c.patch?.lines || {}).length) window.topologyEditor?.setElectrical?.(code, structuredClone(c.patch));
      if (Object.keys(c.fields || {}).length) { setOverrides(code, c.fields); changes[code] = Object.fromEntries(Object.entries(c.fields).map(([k, v]) => [k, {from: null, to: v}])); }
      applied[code] = {items: c.items || []};
      if (c.shunt_mvar) (changes[code] ||= {}).shunt_mvar = {from: 0, to: c.shunt_mvar};
      for (const k of Object.keys(c.patch?.nodes || {})) (changes[code] ||= {})[`node ${k}`] = {from: "-", to: "corrected"};
    }
    for (const a of plan.advisories || []) notes.push(`${a.code}: ${a.key} ${a.current ?? "-"} -> ${a.suggested} is advisory only (not applied).`);
    state.loop = {active: true, stopped: false, mode: "apply-all", base: solveRun, run: null, warnings: notes, iteration: (wf.iteration?.iteration ?? 0) + 1};
    edited();
    await start(true, {base: solveRun, iteration: (wf.iteration?.iteration ?? 0) + 1, scenarios: wf.scenarios.map(e => e.code), changes,
      applied_costs: applied, mode: "apply"});
  }

  // Range changes (microgrid_max_mw) belong to the client: never applied automatically. Raising a maximum is offered as an explicit action.
  function advisoryBox(wf) {
    const items = [];
    for (const e of wf.scenarios || []) if (["FAIL", "WARN"].includes(e.technical_status)) items.push(...(e.corrections?.advisories || []));
    if (!items.length) return null;
    const box = h("div", undefined, "notice wf-advisories"); box.id = "wf-advisories";
    box.append(h("strong", "Suggested changes to your own limits (not applied automatically)"));
    const list = h("ul");
    for (const a of items) list.append(h("li", `${a.code}: ${a.key} ${a.current ?? "-"} -> ${a.suggested}${a.reason ? ". " + a.reason : ""}${a.actionable ? "" : " (not offered as a one-click change)"}`));
    box.append(list);
    const actionable = items.filter(a => a.actionable);
    if (actionable.length) {
      const apply = h("button", "Apply " + actionable.map(a => `${a.code} ${a.key} ${a.current} -> ${a.suggested}`).join(", ") + " & re-solve", "secondary");
      apply.id = "wf-apply-advisory"; apply.type = "button";
      apply.disabled = busy || wf.check?.state === "running";
      apply.onclick = () => applyAdvisories(wf, actionable).catch(error => { state.loop = null; showError(error.message); });
      box.append(apply);
    }
    return box;
  }

  async function applyAdvisories(wf, items) {
    const changes = {};
    for (const a of items) {
      setOverrides(a.code, {[a.key]: a.suggested});
      (changes[a.code] ||= {})[a.key] = {from: a.current, to: a.suggested};
    }
    const iteration = (wf.iteration?.iteration ?? 0) + 1;
    state.loop = {active: true, stopped: false, mode: "apply-all", base: solveRun, run: null, warnings: [], iteration};
    edited();
    await start(true, {base: solveRun, iteration, scenarios: wf.scenarios.map(e => e.code), changes, applied_costs: {}, mode: "apply"});
  }

  function comparisonTable(wf) {
    const wrap = h("div", undefined, "table-scroll");
    const it = wf.iteration || {};
    const heading = h("h4", `Before / after comparison with ${it.base_label || `run ${it.base_run?.slice(0, 8)}`}`);
    heading.title = `Run id ${it.base_run || ""}`;
    wrap.append(heading);
    if (it.model_changes?.length) wrap.append(h("p", `Inputs/model changed between the runs (${it.model_changes.join(", ")}). The NPC change is split into the model/input effect and the effect of the corrections.`, "muted wf-model-changed"));
    const t = h("table", undefined, "wf-table xl");
    const head = h("tr");
    for (const x of ["Scenario", "Changes applied", "NPC before (optimizer)", "NPC after (optimizer)", "Model/input effect", "Corrections cost effect", "Total NPC before", "Total NPC after", "Total delta", "Status before", "Status after"]) head.append(h("th", x));
    t.append(head);
    for (const c of wf.comparison) {
      const changes = Object.entries(c.changes || {}).map(([k, v]) => v && typeof v === "object" ? `${k}: ${v.from} -> ${v.to}` : `${k} = ${v}`).join("; ") || "none";
      t.append(Object.assign(h("tr"), {}));
      const tr = t.lastChild;
      for (const v of [c.code, changes, money(c.npc_before), money(c.npc_after), delta(c.model_effect ?? c.npc_delta), delta(c.corrections_effect),
        money(c.total_before ?? c.adjusted_before), money(c.total_after ?? c.adjusted_after), delta((c.total_after ?? c.adjusted_after) - (c.total_before ?? c.adjusted_before)),
        c.status_before || "-", c.status_after || "-"]) tr.append(h("td", v));
    }
    wrap.append(t);
    return wrap;
  }

  function render() {
    const host = $("workflow-panel");
    const wf = state.data;
    if (!host) return;
    const results = solveSnapshot?.summary?.results || [];
    if (!wf || wf.run_id !== solveRun || !wf.scenarios?.length) { host.hidden = true; renderSummaryHost(); renderRecoNote(); return; }
    host.hidden = false;
    host.replaceChildren(h("h3", "Technical check and ranking"));
    const c = wf.check || {};
    const line = h("p", undefined, "muted"); line.id = "wf-check-status";
    line.textContent = c.state === "running" ? `Technical check running: ${c.done || 0}/${c.total || "?"}. ${c.message || ""}` :
      c.state === "error" ? `Technical check failed: ${c.message || ""}` :
      wf.recommended?.checked ? (wf.scenarios.some(e => e.technical_status === "NOT_RUN") ?
        `Technical check done, but could NOT run for: ${wf.scenarios.filter(e => e.technical_status === "NOT_RUN").map(e => e.code).join(", ")} (reasons in the table). Ranking is by total NPC; the technical status is a remark; unchecked options are not verified.` :
        `Technical power-flow check done for all scenarios. Ranking is by total NPC; the technical status, violations and indicative corrections are remarks.`) :
      "Technical check not run: ranking uses total NPC only. Run it here or from the Power Flow page.";
    host.append(line);
    const run = h("button", wf.recommended?.checked ? "Re-run technical check" : "Run technical check now", "secondary"); run.id = "wf-run-check"; run.type = "button";
    run.disabled = c.state === "running" || busy;
    run.onclick = async () => {
      run.disabled = true;
      try { await fetchJson("/api/x/workflow_check", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({run_id: solveRun})}); }
      catch (error) { showError(error.message); }
      state.loading = null; await load(solveRun);
    };
    host.append(run);
    const rec = wf.recommended || {};
    if (rec.checked && rec.banner) {
      const warn = h("div", rec.banner, "notice wf-noncompliant" + (rec.technical_status === "FAIL" ? " failure" : "")); warn.id = "wf-noncompliant"; warn.setAttribute("role", "status");
      host.append(warn);
    }
    const loop = state.loop;
    if (loop?.active && (busy || loop.run === null || loop.run === solveRun)) {
      const label = loop.mode === "powerflow" ? "Re-solving after power-flow edits..." :
        `Applying corrections and re-solving (iteration ${loop.iteration ?? 1} of ${MAX_ITER})...`;
      const status = h("div", label, "notice wf-loop"); status.id = "wf-loop-status"; status.setAttribute("role", "status");
      host.append(status);
    }
    const buttons = actionButtons(wf);
    if (buttons) host.append(buttons);
    const advice = advisoryBox(wf);
    if (advice) host.append(advice);
    const d = wf.decision;
    if (d) {
      const banner = h("div", d.banner, "notice wf-banner"); banner.id = "wf-banner"; banner.setAttribute("role", "status");
      if (d.final_status === "needs_manual_review" || d.winner_status === "FAIL") banner.classList.add("failure");
      host.append(banner);
      const info = h("p", `Iteration ${wf.iteration?.iteration ?? 0} of ${MAX_ITER}. ${d.reason}`, "muted"); info.id = "wf-iteration";
      host.append(info);
      if (d.final_status === "needs_manual_review" && d.advisories?.length && !$("wf-advisories"))
        host.append(h("div", "Suggested changes to your limits: " + d.advisories.map(a => `${a.key} ${a.current ?? "-"} -> ${a.suggested}`).join("; "), "notice"));
      if (state.loop?.active && busy === false && state.loop.run === solveRun && d.action === "iterate") {
        const stop = h("button", "Stop auto-iteration", "secondary"); stop.id = "wf-stop"; stop.type = "button";
        stop.onclick = () => { state.loop.stopped = true; stop.disabled = true; info.textContent = "Auto-iteration stopped by user."; };
        host.append(stop);
      }
    }
    if (state.loop?.warnings?.length) host.append(h("div", state.loop.warnings.join(" "), "notice"));
    host.append(rankingTable(wf));
    host.append(explainer(wf));
    if (wf.iterations?.length > 1) host.append(iterationTable(wf));
    if (wf.comparison?.length) host.append(comparisonTable(wf));
    renderSummaryHost();
    renderRecoNote();
  }

  // Plain-words warnings about the recommended option (unbuilt technology, ties, unchecked), shown directly under the best-option card.
  function renderRecoNote() {
    let note = $("wf-reco-note");
    const wf = state.data;
    const warnings = wf && wf.run_id === solveRun ? wf.recommended?.warnings || [] : [];
    if (!note) { note = h("div", undefined, "wf-reco-note"); note.id = "wf-reco-note"; }
    const card = $("best-option-card"), anchor = $("result-table");
    if (card) card.after(note); else if (anchor) anchor.before(note); else return;
    note.replaceChildren(...warnings.map(w => h("div", w, "notice")));
    note.hidden = !warnings.length;
  }

  function renderSummaryHost() {
    const host = $("summary-ranking");
    if (!host) return;
    const wf = state.data;
    host.replaceChildren();
    if (wf && wf.run_id === solveRun && wf.scenarios?.length) {
      host.append(h("h3", "All scenarios: total NPC, technical status and indicative corrections"), rankingTable(wf));
      if (!wf.recommended?.checked) host.append(h("p", "Technical check not run: the recommendation is based on total NPC only.", "muted"));
    }
  }

  // ---- per-scenario overrides stored on the scenario cards (persisted with the saved settings)
  function setOverrides(code, values, replace) {
    const card = [...$("scenario-rows").children].find(c => c.querySelector("[data-key='id']").value === code);
    if (!card) return false;
    const next = replace ? values : {...JSON.parse(card.dataset.overrides || "{}"), ...values};
    if (Object.keys(next).length) card.dataset.overrides = JSON.stringify(next); else delete card.dataset.overrides;
    paintOverrides(card);
    return true;
  }
  function paintOverrides(card) {
    card.querySelector(".override-note")?.remove();
    const ov = JSON.parse(card.dataset.overrides || "{}");
    if (!Object.keys(ov).length) return;
    const note = h("p", undefined, "muted override-note");
    note.append(document.createTextNode("Scenario-only input overrides: " + Object.entries(ov).map(([k, v]) => `${k} = ${v}`).join(", ") + ". "));
    const clear = h("button", "Clear overrides", "secondary"); clear.type = "button";
    clear.onclick = () => { delete card.dataset.overrides; paintOverrides(card); edited(); };
    note.append(clear);
    card.append(note);
  }

  async function baseValues(base) {
    const response = await fetch(`/files/${base}/run_configuration.json`);
    if (!response.ok) throw new Error("The base run's saved assumptions could not be read.");
    return (await response.json()).request.values;
  }

  // A Power Flow "re-run selected scenarios" arrives as a partial selection plus changed global inputs.
  // Convert it to a full re-solve with the changed overridable inputs applied only to the selected scenarios.
  async function resolvePlan(plan) {
    const base = plan.base;
    const prior = await baseValues(base);
    const current = values();
    const codes = (solveSnapshot?.summary?.results || []).map(r => r.code);
    const changes = {}, shared = [];
    for (const f of schema.fields) {
      const a = prior[f.key], b = current[f.key];
      if (a === undefined || a === b || (typeof a === "number" && Math.abs(a - b) < 1e-12)) continue;
      if (overridable(f.key)) {
        for (const code of plan.codes) (changes[code] ||= {})[f.key] = {from: a, to: b};
        const input = $(f.key);
        if (input) { if (f.kind === "checkbox") input.checked = a; else unitsUi.setCanonical(input, a); }
      } else shared.push(f.key);
    }
    for (const [code, ch] of Object.entries(changes)) setOverrides(code, Object.fromEntries(Object.entries(ch).map(([k, v]) => [k, v.to])));
    state.loop = {active: true, stopped: false, mode: "powerflow", base, run: null, warnings: shared.length ?
      [`These changed inputs are shared by all scenarios and cannot be overridden per scenario, so they apply to every scenario in this re-run: ${shared.join(", ")}.`] : []};
    edited();
    switchView("solve");
    return {base, iteration: 0, scenarios: codes.length ? codes : plan.codes, changes, mode: "powerflow", applied_costs: plan.applied_costs || takeApplied()};
  }

  // Corrections accepted on the Power Flow page are charged to the next solve's total NPC.
  const noted = {};
  function noteApplied(code, label, cost) {
    if (!code || !(cost > 0)) return;
    ((noted[code] ||= {items: []}).items).push({label: label || "Correction", cost_usd: cost});
  }
  function takeApplied() {
    const out = JSON.parse(JSON.stringify(noted));
    for (const k of Object.keys(noted)) delete noted[k];
    return out;
  }

  // The Power Flow page starts a re-solve itself (full scope): mark the loop so the Solve page shows and tracks it.
  function expectReSolve(source) {
    state.loop = {active: true, stopped: false, mode: source === "powerflow" ? "powerflow" : "apply-all", base: solveRun, run: null, warnings: []};
    loopStatus();
  }

  function loopStatus() {
    let el = $("wf-resolve-status");
    const loop = state.loop;
    const show = !!(loop?.active && busy);
    if (!el) {
      const anchor = $("status");
      if (!anchor) return;
      el = h("div", undefined, "notice wf-loop"); el.id = "wf-resolve-status"; el.setAttribute("role", "status");
      anchor.after(el);
    }
    el.hidden = !show;
    if (show) el.textContent = loop.mode === "powerflow" ? "Re-solving after power-flow edits... the technical check re-runs automatically when the solve finishes." :
      `Applying corrections and re-solving (iteration ${loop.iteration ?? 1} of ${MAX_ITER})... the technical check and ranking re-run automatically.`;
  }
  setInterval(loopStatus, 600);

  async function complete(run, status) {
    if (!status.summary?.results?.length) return;
    const wf = await load(run);
    const loop = state.loop;
    if (!wf || !loop?.active) return;
    if (loop.run === null && run !== loop.base) loop.run = run;
    if (loop.run !== run) return;
    const d = wf.decision;
    if (!d) { loop.active = false; return; }
    loop.iteration = wf.iteration?.iteration ?? loop.iteration;
    if (loop.mode === "apply-all" && d.action === "iterate" && !loop.stopped) {
      loop.iteration = (wf.iteration?.iteration ?? 0) + 1;
      loop.run = null;
      await applyAll(wf);
      return;
    }
    loop.active = false;
    loopStatus();
    render();
  }

  function hint(host) {
    const note = h("p", undefined, "notice wf-hint");
    const update = () => {
      note.hidden = !solveRun || checked();
      note.textContent = "The technical power-flow check has not been run for this solve, so the default option is the lowest total NPC without technical remarks. " +
        "Run the technical check (Solve page, or Power Flow page) to see the technical status of the recommended option.";
    };
    update();
    window.addEventListener("workflow-updated", update);
    window.addEventListener("solve-complete", update);
    host.prepend(note);
    return note;
  }

  window.workflowUi = {recommended, recommendedCode, checked, load, resolvePlan, complete, hint, setOverrides, paintOverrides, overridable, rankingTable,
    applyAll: () => applyAll(state.data), noteApplied, expectReSolve, cancelReSolve: () => { state.loop = null; loopStatus(); },
    get data() { return state.data; }, get loop() { return state.loop; }};
  window.addEventListener("workflow-updated", () => { if (activeView === "summary" && solveSnapshot) guardPanel("summary", renderSummary); window.reportUi?.refresh(); });
  window.addEventListener("solve-complete", () => { if (solveRun && state.run !== solveRun && state.loading !== solveRun) load(solveRun); });
})();
