"use strict";
// Sub-menu inside ANALYZE: Economic analysis | Sensitivity analysis | Reliability.
// Other modules populate their own pane and listen with analysisTabs.onShow(name, callback).
const analysisTabs = (() => {
  const listeners = {};
  let current = "economic";
  function show(name) {
    current = name;
    for (const pane of document.querySelectorAll(".analysis-pane")) pane.hidden = pane.id !== "analysis-pane-" + name;
    for (const button of document.querySelectorAll("#analysis-tabs button")) {
      const active = button.dataset.pane === name;
      button.classList.toggle("secondary", !active);
      button.setAttribute("aria-selected", String(active));
    }
    for (const callback of listeners[name] || []) callback();
  }
  function onShow(name, callback) { (listeners[name] ||= []).push(callback); }
  window.addEventListener("load", () => {
    for (const button of document.querySelectorAll("#analysis-tabs button")) button.onclick = () => show(button.dataset.pane);
    show("economic");
  });
  return {show, onShow, current: () => current, pane: name => document.getElementById("analysis-pane-" + name)};
})();
