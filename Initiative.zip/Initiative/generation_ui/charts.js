"use strict";
/* GenStudio chart system: dependency-free SVG charts (bars, grouped/stacked bars, zoomable time series) with a
   shared toolbar (PNG at 3x, SVG, CSV, zoom reset, full screen). Everything is built from SVG attributes (no inline
   style attributes, no blob/data images) so it satisfies the app's CSP. PNG export rasterises the SVG tree onto a canvas. */
window.GS = (() => {
  const NS = "http://www.w3.org/2000/svg";
  const FONT = '"Segoe UI",system-ui,-apple-system,Roboto,Arial,sans-serif';
  const INK = "#173441", MUTED = "#5b7280", GRID = "#e3ebef", AXIS = "#9db1bb";
  const SCENARIO_COLORS = ["#2F6DB5", "#E08A1E", "#2A9D8F", "#B05A9C", "#5FA8D3", "#C8553D", "#8C8C3C", "#7A6BC4", "#3F9E5A", "#A0522D"];
  const TECH_COLORS = {grid: "#7C8B99", pv: "#E8A91D", bess: "#2B7BBA", wind: "#2A9D8F", h2: "#8E6BBF", h2_chp: "#C27BA0",
    ng: "#D1603D", ng_chp: "#4F6D9A", diesel: "#A67C37", biogas: "#4C9F50", biomass: "#7B8A3A", planned: "#5FB49C",
    planned_renewable: "#5FB49C", unserved: "#C0392B", other: "#9AA9B3"};
  const TECH_NAMES = {pv: "Additional solar", bess: "BESS", wind: "Wind", h2: "Hydrogen", h2_chp: "Hydrogen CHP", ng: "Natural gas",
    ng_chp: "Natural gas CHP", diesel: "Diesel", biogas: "Biogas", biomass: "Biomass", grid: "Grid"};
  const scenarioMap = new Map([["R0", "#6B7A86"]]);

  const techColor = key => TECH_COLORS[key] || TECH_COLORS.other;
  function scenarioColor(code) {
    if (!scenarioMap.has(code)) scenarioMap.set(code, SCENARIO_COLORS[(scenarioMap.size - 1 + SCENARIO_COLORS.length) % SCENARIO_COLORS.length]);
    return scenarioMap.get(code);
  }
  const registerScenarios = codes => codes.forEach(scenarioColor);

  const fmt = (v, max = 4) => {
    if (v === null || v === undefined || typeof v !== "number" || !isFinite(v)) return "–";
    const a = Math.abs(v), d = Math.min(max, a >= 1000 ? 1 : a >= 100 ? 2 : a >= 1 ? 3 : 4);
    const s = new Intl.NumberFormat("en-US", {maximumFractionDigits: d}).format(v);
    return s === "-0" ? "0" : s;
  };
  const fixed = (v, d) => new Intl.NumberFormat("en-US", {minimumFractionDigits: d, maximumFractionDigits: d}).format(Math.abs(v) < 1e-12 ? 0 : v);

  const mctx = document.createElement("canvas").getContext("2d");
  function measure(text, size, weight) { mctx.font = `${weight || 400} ${size}px ${FONT}`; return mctx.measureText(String(text)).width; }
  function wrap(text, width, size, weight) {
    const lines = [];
    for (const para of String(text ?? "").split("\n")) {
      let line = "";
      for (const word of para.split(/\s+/)) {
        const t = line ? line + " " + word : word;
        if (line && measure(t, size, weight) > width) { lines.push(line); line = word; } else line = t;
      }
      lines.push(line);
    }
    return lines.filter((l, i) => l || i === 0);
  }

  function ellipsize(text, width, size, weight) {
    let t = String(text);
    if (measure(t, size, weight) <= width) return t;
    while (t.length > 1 && measure(t + "…", size, weight) > width) t = t.slice(0, -1);
    return t.trimEnd() + "…";
  }

  const svgEl = (tag, attrs, text) => {
    const e = document.createElementNS(NS, tag);
    for (const k in attrs) if (attrs[k] !== undefined && attrs[k] !== null) e.setAttribute(k, attrs[k]);
    if (text !== undefined) e.textContent = text;
    return e;
  };
  const html = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };
  const label = (parent, x, y, s, o = {}) => parent.append(svgEl("text", {x, y, "font-family": FONT, "font-size": o.size || 12,
    "font-weight": o.weight || 400, fill: o.fill || INK, "text-anchor": o.anchor || "start", transform: o.rot ? `rotate(${o.rot} ${x} ${y})` : undefined,
    "data-s": o.s}, s));

  function niceTicks(lo, hi, n, integer) {
    if (!isFinite(lo) || !isFinite(hi)) { lo = 0; hi = 1; }
    if (hi - lo < 1e-12) { hi = lo + (Math.abs(lo) || 1); }
    const raw = (hi - lo) / Math.max(1, n), p = 10 ** Math.floor(Math.log10(raw)), f = raw / p;
    let step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p;
    if (integer) step = Math.max(1, Math.round(step));
    const first = Math.floor(lo / step + 1e-9) * step, ticks = [];
    for (let v = first; ; v += step) { ticks.push(Math.round(v / step) * step); if (v >= hi - step * 1e-9 && ticks.length >= 2) break; }
    return {ticks, min: ticks[0], max: ticks[ticks.length - 1], step};
  }
  const tickFormatter = step => { const d = Math.min(4, Math.max(0, Math.ceil(-Math.log10(step) - 1e-9))); return v => fixed(v, d); };

  const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const pad2 = n => String(n).padStart(2, "0");
  const fullTime = t => { const d = new Date(t); return `${d.getUTCFullYear()}-${pad2(d.getUTCMonth() + 1)}-${pad2(d.getUTCDate())} ${pad2(d.getUTCHours())}:${pad2(d.getUTCMinutes())}`; };
  function timeTicks(a, b, n) {
    const H = 3600e3, D = 24 * H, span = b - a, target = span / Math.max(2, n), out = [];
    const sub = [H, 2 * H, 3 * H, 6 * H, 12 * H, D, 2 * D, 7 * D, 14 * D].find(s => s >= target);
    if (sub) {
      const off = sub >= 7 * D ? 4 * D : 0;
      for (let t = Math.ceil((a - off) / sub) * sub + off; t <= b; t += sub) out.push(t);
      return {ticks: out, format: t => { const d = new Date(t);
        return sub < D ? (d.getUTCHours() === 0 ? `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}` : `${pad2(d.getUTCHours())}:00`) : `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}`; }};
    }
    const m = [1, 2, 3, 6, 12, 24, 60, 120, 240].find(s => s * 30.4 * D >= target) || 240, start = new Date(a);
    let idx = start.getUTCFullYear() * 12 + start.getUTCMonth();
    idx = Math.ceil(idx / m) * m;
    for (let t = Date.UTC(Math.floor(idx / 12), idx % 12, 1); t <= b; idx += m, t = Date.UTC(Math.floor(idx / 12), idx % 12, 1)) if (t >= a) out.push(t);
    return {ticks: out, format: t => { const d = new Date(t); return m >= 12 ? String(d.getUTCFullYear()) : `${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}`; }};
  }

  function download(blob, name) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = name; a.hidden = true;
    document.body.append(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
  }
  const slug = s => String(s || "chart").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "").slice(0, 60) || "chart";
  const csvCell = v => v === null || v === undefined ? "" : typeof v === "number" ? String(v) : /[",\n]/.test(String(v)) ? `"${String(v).replaceAll('"', '""')}"` : String(v);

  /* ---------- SVG tree -> canvas (PNG export without data/blob images) ---------- */
  function walk(node, ctx, root) {
    if (!(node instanceof SVGElement) || node.hasAttribute("data-gs-ui")) return;
    const tag = node.localName;
    if (["defs", "style", "title", "desc", "clipPath", "mask", "pattern", "foreignObject", "marker", "linearGradient", "radialGradient", "image", "script"].includes(tag)) return;
    const cs = getComputedStyle(node);
    if (cs.display === "none" || cs.visibility === "hidden") return;
    ctx.save();
    const tr = node.transform && node.transform.baseVal && node.transform.baseVal.numberOfItems ? node.transform.baseVal.consolidate() : null;
    if (tr) { const m = tr.matrix; ctx.transform(m.a, m.b, m.c, m.d, m.e, m.f); }
    const clip = /url\(["']?#([^"')]+)/.exec(node.getAttribute("clip-path") || "");
    if (clip) {
      const shape = root.querySelector(`[id="${clip[1]}"]`)?.firstElementChild;
      if (shape && shape.localName === "rect") { ctx.beginPath(); ctx.rect(+shape.getAttribute("x") || 0, +shape.getAttribute("y") || 0, +shape.getAttribute("width"), +shape.getAttribute("height")); ctx.clip(); }
    }
    const op = parseFloat(cs.opacity); if (isFinite(op)) ctx.globalAlpha *= op;
    const paint = path => {
      const fill = cs.fill;
      if (fill && fill !== "none" && !fill.startsWith("url")) {
        ctx.save(); ctx.globalAlpha *= parseFloat(cs.fillOpacity) || (cs.fillOpacity === "0" ? 0 : 1); ctx.fillStyle = fill;
        ctx.fill(path, cs.fillRule === "evenodd" ? "evenodd" : "nonzero"); ctx.restore();
      }
      const stroke = cs.stroke, w = parseFloat(cs.strokeWidth);
      if (stroke && stroke !== "none" && !stroke.startsWith("url") && w > 0) {
        ctx.save(); ctx.globalAlpha *= parseFloat(cs.strokeOpacity) || (cs.strokeOpacity === "0" ? 0 : 1);
        ctx.strokeStyle = stroke; ctx.lineWidth = w; ctx.lineCap = cs.strokeLinecap === "round" ? "round" : cs.strokeLinecap === "square" ? "square" : "butt";
        ctx.lineJoin = cs.strokeLinejoin === "round" ? "round" : cs.strokeLinejoin === "bevel" ? "bevel" : "miter";
        const dash = cs.strokeDasharray;
        ctx.setLineDash(dash && dash !== "none" ? dash.split(/[ ,]+/).map(parseFloat).filter(isFinite) : []);
        ctx.stroke(path); ctx.restore();
      }
    };
    const num = (n, d = 0) => { const v = parseFloat(node.getAttribute(n)); return isFinite(v) ? v : d; };
    if (["g", "svg", "a", "switch"].includes(tag)) for (const c of node.children) walk(c, ctx, root);
    else if (tag === "rect") {
      const p = new Path2D(), x = num("x"), y = num("y"), w = num("width"), h = num("height"), r = Math.min(num("rx", num("ry")), w / 2, h / 2);
      if (r > 0) { p.moveTo(x + r, y); p.arcTo(x + w, y, x + w, y + h, r); p.arcTo(x + w, y + h, x, y + h, r); p.arcTo(x, y + h, x, y, r); p.arcTo(x, y, x + w, y, r); p.closePath(); }
      else p.rect(x, y, w, h);
      paint(p);
    } else if (tag === "line") { const p = new Path2D(); p.moveTo(num("x1"), num("y1")); p.lineTo(num("x2"), num("y2")); paint(p); }
    else if (tag === "circle") { const p = new Path2D(); p.arc(num("cx"), num("cy"), num("r"), 0, 7); paint(p); }
    else if (tag === "ellipse") { const p = new Path2D(); p.ellipse(num("cx"), num("cy"), num("rx"), num("ry"), 0, 0, 7); paint(p); }
    else if (tag === "path") paint(new Path2D(node.getAttribute("d") || ""));
    else if (tag === "polyline" || tag === "polygon") {
      const pts = (node.getAttribute("points") || "").trim().split(/[\s,]+/).map(Number), p = new Path2D();
      for (let i = 0; i + 1 < pts.length; i += 2) i ? p.lineTo(pts[i], pts[i + 1]) : p.moveTo(pts[i], pts[i + 1]);
      if (tag === "polygon") p.closePath();
      paint(p);
    } else if (tag === "text") {
      ctx.font = `${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
      ctx.textAlign = cs.textAnchor === "middle" ? "center" : cs.textAnchor === "end" ? "right" : "left";
      const db = cs.dominantBaseline;
      ctx.textBaseline = db === "middle" || db === "central" ? "middle" : db === "hanging" ? "top" : "alphabetic";
      let x = num("x"), y = num("y");
      const draw = (el, text) => {
        if (!text) return;
        const ecs = getComputedStyle(el);
        ctx.save();
        ctx.fillStyle = ecs.fill === "none" ? "#000" : ecs.fill;
        if (ecs.fill !== "none") ctx.fillText(text, x, y);
        if (ecs.stroke && ecs.stroke !== "none" && parseFloat(ecs.strokeWidth) > 0) { ctx.strokeStyle = ecs.stroke; ctx.lineWidth = parseFloat(ecs.strokeWidth); ctx.lineJoin = "round"; ctx.strokeText(text, x, y); ctx.fillText(text, x, y); }
        ctx.restore();
      };
      x += parseFloat(node.getAttribute("dx")) || 0; y += parseFloat(node.getAttribute("dy")) || 0;
      const spans = [...node.children].filter(c => c.localName === "tspan");
      if (!spans.length) draw(node, node.textContent);
      else for (const s of spans) {
        if (s.hasAttribute("x")) x = parseFloat(s.getAttribute("x")); if (s.hasAttribute("y")) y = parseFloat(s.getAttribute("y"));
        x += parseFloat(s.getAttribute("dx")) || 0; y += parseFloat(s.getAttribute("dy")) || 0;
        draw(s, s.textContent);
      }
    }
    ctx.restore();
  }
  function svgToCanvas(svg, scale = 3, title) {
    const vb = svg.viewBox && svg.viewBox.baseVal && svg.viewBox.baseVal.width ? svg.viewBox.baseVal : (() => { const r = svg.getBoundingClientRect(); return {x: 0, y: 0, width: r.width, height: r.height}; })();
    const head = title ? 46 : 0, canvas = document.createElement("canvas");
    canvas.width = Math.round(vb.width * scale); canvas.height = Math.round((vb.height + head) * scale);
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.scale(scale, scale);
    if (title) { ctx.fillStyle = INK; ctx.font = `700 20px ${FONT}`; ctx.textBaseline = "alphabetic"; ctx.fillText(title, 16, 30); }
    ctx.translate(-vb.x, head - vb.y);
    for (const c of svg.children) walk(c, ctx, svg);
    return canvas;
  }
  const canvasBlob = canvas => new Promise(res => canvas.toBlob(res, "image/png"));
  const INLINE = ["fill", "stroke", "stroke-width", "stroke-dasharray", "stroke-linecap", "stroke-linejoin", "opacity", "fill-opacity", "stroke-opacity", "font-family", "font-size", "font-weight", "font-style", "text-anchor", "dominant-baseline", "display", "visibility"];
  function svgString(svg, title) {
    const clone = svg.cloneNode(true), a = [svg, ...svg.querySelectorAll("*")], b = [clone, ...clone.querySelectorAll("*")];
    a.forEach((src, i) => {
      if (src.hasAttribute && src.hasAttribute("data-gs-ui")) { b[i].setAttribute("data-gs-remove", "1"); return; }
      const cs = getComputedStyle(src);
      if (i) for (const p of INLINE) b[i].setAttribute(p, cs.getPropertyValue(p));
    });
    clone.querySelectorAll("[data-gs-remove]").forEach(e => e.remove());
    const vb = svg.viewBox.baseVal.width ? svg.viewBox.baseVal : {x: 0, y: 0, width: svg.clientWidth, height: svg.clientHeight};
    clone.setAttribute("width", vb.width); clone.setAttribute("height", vb.height);
    if (!clone.getAttribute("viewBox")) clone.setAttribute("viewBox", `0 0 ${vb.width} ${vb.height}`);
    clone.insertBefore(svgEl("rect", {x: vb.x, y: vb.y, width: vb.width, height: vb.height, fill: "#ffffff"}), clone.firstChild);
    if (title) clone.insertBefore(svgEl("title", {}, title), clone.firstChild);
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + new XMLSerializer().serializeToString(clone);
  }

  /* ---------- Chart ---------- */
  function chart(initial) {
    initial = window.unitsUi ? window.unitsUi.adaptChart(initial) : initial;
    let spec = initial, hidden = new Set(), domain = null, curW = 0, curH = 0, info = null, frame = 0, raf = 0;
    const root = html("div", "gs-chart"), tools = html("div", "gs-toolbar"), stage = html("div", "gs-stage"), tip = html("div", "gs-tip");
    tip.hidden = true;
    root.append(tools, stage); stage.append(tip);
    const btn = (action, text, title, handler) => {
      const b = html("button", "gs-btn", text); b.type = "button"; b.dataset.gsAction = action; b.title = title; b.setAttribute("aria-label", title);
      b.onclick = handler; tools.append(b); return b;
    };
    const fileName = ext => `${slug(spec.filename || spec.title)}.${ext}`;
    btn("zoom-in", "+", "Zoom in", () => zoomBy(0.6)).classList.add("gs-zoom");
    btn("zoom-out", "−", "Zoom out", () => zoomBy(1 / 0.6)).classList.add("gs-zoom");
    btn("reset", "Reset zoom", "Reset zoom to the full range", () => { domain = null; draw(); }).classList.add("gs-zoom");
    btn("png", "PNG", "Download high-resolution PNG (3x, white background)", async () => {
      const {svg, holder} = renderOffscreen();
      try { download(await canvasBlob(svgToCanvas(svg, 3)), fileName("png")); } finally { holder.remove(); }
    });
    btn("svg", "SVG", "Download vector SVG", () => {
      const {svg, holder} = renderOffscreen();
      try { download(new Blob([svgString(svg, spec.title)], {type: "image/svg+xml"}), fileName("svg")); } finally { holder.remove(); }
    });
    btn("csv", "CSV", "Download plotted data as CSV", () => download(new Blob(["\ufeff" + toCSV()], {type: "text/csv;charset=utf-8"}), fileName("csv")));
    btn("fullscreen", "Full screen", "Toggle full screen", () => { if (document.fullscreenElement === root) document.exitFullscreen(); else root.requestFullscreen?.(); });

    function renderOffscreen() {
      const holder = html("div", "gs-offscreen"), saved = info;
      document.body.append(holder);
      const {svg} = build(spec.exportWidth || 1200, Math.max(spec.height || 380, 420), true);
      info = saved; holder.append(svg);
      return {svg, holder};
    }
    function toCSV() {
      const rows = [];
      if (spec.kind === "time") {
        rows.push([spec.xTitle || "x", ...spec.series.map(s => s.label)]);
        spec.x.forEach((x, i) => rows.push([spec.xKind === "time" ? fullTime(x).replace(" ", "T") : x, ...spec.series.map(s => s.values[i])]));
      } else {
        rows.push([spec.catTitle || "Category", ...spec.series.map(s => s.label), ...(spec.lines || []).map(l => l.label)]);
        spec.categories.forEach((c, i) => rows.push([c.label, ...spec.series.map(s => s.values[i]), ...(spec.lines || []).map(l => l.values[i])]));
      }
      return rows.map(r => r.map(csvCell).join(",")).join("\r\n") + "\r\n";
    }
    const visible = () => spec.series.filter(s => !hidden.has(s.key));
    const isTime = () => spec.kind === "time";
    function fullDomain() {
      const x = spec.x, a = x[0], b = x[x.length - 1];
      if (!(b > a)) { const h = spec.xKind === "time" ? 1800e3 : 0.5; return [a - h, a + h]; }
      const p = spec.xKind === "time" ? 0 : (b - a) * 0.03;
      return [a - p, b + p];
    }
    function zoomBy(f, anchor = 0.5) {
      if (!isTime() || !spec.x.length) return;
      const [fa, fb] = fullDomain(), [a, b] = domain || [fa, fb], span = Math.max((b - a) * f, (spec.x[1] - spec.x[0] || 1) * 4), c = a + (b - a) * anchor;
      setDomain(c - span * anchor, c + span * (1 - anchor));
    }
    function notifyDomain() { if (spec.onDomain) spec.onDomain(domain); }
    function setDomain(a, b) {
      const [fa, fb] = fullDomain(), span = b - a;
      if (span >= fb - fa) { domain = null; } else {
        if (a < fa) { a = fa; b = fa + span; } if (b > fb) { b = fb; a = fb - span; }
        domain = [Math.max(a, fa), Math.min(b, fb)];
      }
      schedule(); notifyDomain();
    }
    const schedule = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; draw(); }); };

    /* Lays out and draws the whole chart (title, legend, axes, marks, footnote) as one SVG. */
    function build(W, H, forExport) {
      const bars = !isTime(), horizontal = bars && spec.horizontal, pad = 16;
      const svg = svgEl("svg", {viewBox: `0 0 ${W} ${H}`, width: W, height: H, role: "img", "aria-label": spec.title || "Chart", "font-family": FONT});
      const ui = svgEl("g", {"data-gs-ui": "1"});
      const vis = visible(), legend = [];
      if (spec.series.length > 1) for (const s of spec.series) legend.push({key: s.key, label: s.label, color: s.color, dash: s.dash, line: isTime() && !s.area, toggle: true, off: hidden.has(s.key)});
      for (const l of spec.lines || []) legend.push({key: l.key, label: l.label, color: l.color, dash: l.dash, line: true, toggle: true, off: hidden.has(l.key)});
      for (const l of spec.legendItems || []) legend.push(l);
      // header
      let y = pad;
      svg.append(svgEl("rect", {x: 0, y: 0, width: W, height: H, fill: "#ffffff"}));
      for (const line of wrap(spec.title, W - 2 * pad, 18, 700)) { label(svg, pad, y + 16, line, {size: 18, weight: 700}); y += 23; }
      if (spec.subtitle) for (const line of wrap(spec.subtitle, W - 2 * pad, 12.5)) { label(svg, pad, y + 11, line, {size: 12.5, fill: MUTED}); y += 17; }
      y += 6;
      // legend rows
      if (legend.length) {
        let x = pad, row = 0;
        for (const item of legend) {
          const w = 24 + measure(item.label, 12) + 16;
          if (x + w > W - pad && x > pad) { x = pad; row++; }
          const g = svgEl("g", {transform: `translate(${x},${y + row * 21})`, cursor: item.toggle ? "pointer" : "default", opacity: item.off ? 0.35 : 1, "data-legend": item.key || ""});
          g.append(svgEl("rect", {x: -3, y: -4, width: w - 6, height: 20, fill: "#fff", opacity: 0}));
          if (item.band) g.append(svgEl("rect", {x: 0, y: 1, width: 16, height: 10, fill: item.color, rx: 2}));
          else if (item.line) g.append(svgEl("line", {x1: 0, x2: 16, y1: 6, y2: 6, stroke: item.color, "stroke-width": 3, "stroke-dasharray": item.dash || "none", "stroke-linecap": "round"}));
          else g.append(svgEl("rect", {x: 0, y: 1, width: 14, height: 10, rx: 2, fill: item.color, "fill-opacity": item.faded ? 0.45 : 1, stroke: item.faded ? item.color : "none", "stroke-dasharray": item.faded ? "3 2" : "none"}));
          label(g, 22, 11, item.label, {size: 12, fill: item.off ? MUTED : INK});
          if (item.toggle && !forExport) {
            const flip = () => { if (hidden.has(item.key)) hidden.delete(item.key); else hidden.add(item.key); draw(); stage.querySelector(`[data-legend="${CSS.escape(item.key)}"]`)?.focus(); };
            g.setAttribute("tabindex", "0"); g.setAttribute("role", "button"); g.setAttribute("aria-pressed", String(!item.off));
            g.setAttribute("aria-label", `${item.label}: ${item.off ? "hidden" : "shown"}. Press Enter to toggle.`);
            g.onkeydown = e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); flip(); } };
            g.onclick = flip;
            g.ondblclick = e => { e.preventDefault(); const all = [...spec.series, ...(spec.lines || [])], only = all.every(s => s.key === item.key || hidden.has(s.key)); hidden = only ? new Set() : new Set(all.filter(s => s.key !== item.key).map(s => s.key)); draw(); };
            g.onmouseenter = () => emphasise(item.key); g.onmouseleave = () => emphasise(null);
          }
          svg.append(g);
          x += w;
        }
        y += (row + 1) * 21;
      }
      if (isTime() ? !(spec.x && spec.x.length) : !(spec.categories && spec.categories.length)) {
        const eh = y + 130;
        label(svg, W / 2, y + 70, "No data to display", {size: 14, fill: MUTED, anchor: "middle"});
        svg.setAttribute("viewBox", `0 0 ${W} ${eh}`); svg.setAttribute("height", eh); svg.firstChild.setAttribute("height", eh);
        info = null;
        return {svg, info: null};
      }
      // footnote
      const foot = spec.footnote ? wrap(spec.footnote, W - 2 * pad, 11) : [];
      const footH = foot.length ? foot.length * 14 + 8 : 0;
      // value domain
      const dom = valueDomain(vis, domain);
      const labelsOn = bars && spec.valueLabels && !spec.stack ? true : false;
      const probe = niceTicks(dom.lo, dom.hi, 9, false), probeFmt = (spec.yFmt || tickFormatter(probe.step));
      const barText = (v, s, i) => spec.barLabel ? spec.barLabel(v, s, i) : (spec.vFmt || fmt)(v);
      const labelWidths = neg => spec.categories.flatMap((c, i) => spec.series.map(s => { const v = s.values[i];
        return v === null || v === undefined || !isFinite(v) || (v < 0) !== neg ? 0 : measure(barText(v, s, i), 11, 600) + 10; }));
      const totalWidths = spec.stack && spec.totals ? spec.categories.map((c, i) => measure((spec.vFmt || fmt)(spec.series.reduce((a, s) => a + (s.values[i] || 0), 0)), 11, 700) + 10) : [];
      let left, right = pad + (horizontal && spec.valueLabels ? Math.max(0, ...labelWidths(false)) + 6 : horizontal && totalWidths.length ? Math.max(...totalWidths) + 6 : 6), top = y + (labelsOn && !horizontal || bars && spec.totals && !horizontal ? 14 : 4);
      let catLabels = bars ? spec.categories.map(c => (c.highlight ? "★ " : "") + c.label) : [];
      if (horizontal) {
        const catW = Math.max(...catLabels.map(l => measure(l, 12, 500))), maxLeft = Math.floor(W * 0.4);
        left = pad + Math.min(maxLeft, catW) + 12;
        if (catW > maxLeft) catLabels = catLabels.map(l => ellipsize(l, maxLeft, 12, 500));
      }
      else {
        const yw = Math.max(...probe.ticks.map(t => measure(probeFmt(t), 11)));
        left = pad + (spec.yTitle ? 20 : 0) + yw + 10;
      }
      const pw = Math.max(80, W - left - right);
      // x-axis label geometry
      let xAxisH = 0, rot = 0, lines = null;
      if (bars && !horizontal) {
        const band = pw / Math.max(1, catLabels.length);
        const maxw = Math.max(...catLabels.map(l => measure(l, 12, 500)));
        if (maxw <= band - 6) { xAxisH = 22; lines = catLabels.map(l => [l]); }
        else if (spec.thinLabels && catLabels.length > 12) { const step = Math.ceil((maxw + 10) / band); xAxisH = 22; lines = catLabels.map((l, i) => i % step === 0 ? [l] : []); }
        else {
          lines = catLabels.map(l => wrap(l, band - 6, 12, 500));
          if (lines.some(l => l.length > 2 || l.some(s => measure(s, 12, 500) > band - 4))) { rot = -38; xAxisH = Math.ceil(maxw * Math.sin(38 * Math.PI / 180)) + 18; }
          else xAxisH = Math.max(...lines.map(l => l.length)) * 14 + 8;
        }
      } else xAxisH = horizontal ? 22 : 24;
      const xTitleH = spec.xTitle ? 22 : 0;
      const bottom = H - footH - xTitleH - xAxisH - 8;
      const ph = Math.max(120, bottom - top);
      const realH = Math.max(H, top + ph + xAxisH + xTitleH + footH + 8);
      if (realH !== H) { svg.setAttribute("viewBox", `0 0 ${W} ${realH}`); svg.setAttribute("height", realH); svg.firstChild.setAttribute("height", realH); H = realH; }
      const plot = {l: left, t: top, w: pw, h: ph, r: left + pw, b: top + ph};
      const valLen = horizontal ? pw : ph;
      let T = niceTicks(dom.lo, !horizontal && !isTime() && dom.hi > 0 ? dom.hi * 1.09 : dom.hi, Math.max(3, Math.floor(valLen / (horizontal ? 90 : 46))), false);
      const negNeed = horizontal && spec.valueLabels ? Math.max(0, ...labelWidths(true)) : 0;
      if (negNeed && negNeed < pw * 0.6) {
        const lo = (dom.lo * pw - negNeed * T.max) / (pw - negNeed);
        T = niceTicks(Math.min(lo, dom.lo), T.max, Math.max(3, Math.floor(valLen / 90)), false);
      }
      const tf = spec.yFmt || tickFormatter(T.step);
      const vMin = isTime() ? T.min : T.min, vMax = T.max;
      const vPos = v => horizontal ? plot.l + (v - vMin) / (vMax - vMin) * pw : plot.b - (v - vMin) / (vMax - vMin) * ph;
      info = {plot, vPos, W, H, horizontal, bars, vMin, vMax};
      const gridG = svgEl("g"), markG = svgEl("g"), axisG = svgEl("g");
      svg.append(gridG, markG, axisG);
      // value-axis grid + labels
      for (const t of T.ticks) {
        const p = vPos(t);
        if (horizontal) { gridG.append(svgEl("line", {x1: p, x2: p, y1: plot.t, y2: plot.b, stroke: t === 0 ? AXIS : GRID, "stroke-width": 1})); label(axisG, p, plot.b + 16, tf(t), {size: 11, fill: MUTED, anchor: "middle"}); }
        else { gridG.append(svgEl("line", {x1: plot.l, x2: plot.r, y1: p, y2: p, stroke: t === 0 && (bars || spec.zeroLine) ? AXIS : GRID, "stroke-width": t === 0 && spec.zeroLine ? 1.6 : 1})); label(axisG, plot.l - 8, p + 4, tf(t), {size: 11, fill: MUTED, anchor: "end"}); }
      }
      if (spec.yTitle && !horizontal) label(axisG, pad + 6, plot.t + ph / 2, spec.yTitle, {size: 12, fill: MUTED, anchor: "middle", weight: 600, rot: -90});
      if (spec.xTitle) label(axisG, plot.l + pw / 2, plot.b + xAxisH + 16, spec.xTitle, {size: 12, fill: MUTED, anchor: "middle", weight: 600});
      if (foot.length) foot.forEach((l, i) => label(svg, pad, H - footH + 14 + i * 14, l, {size: 11, fill: MUTED}));
      info.catPos = null;
      if (bars) drawBars(markG, axisG, plot, vPos, horizontal, vis, catLabels, lines, rot, xAxisH, vMin, vMax);
      else drawTime(markG, axisG, plot, vPos, vis, forExport);
      axisG.append(svgEl("line", {x1: plot.l, x2: plot.r, y1: plot.b, y2: plot.b, stroke: AXIS}));
      if (horizontal) axisG.append(svgEl("line", {x1: vPos(Math.max(vMin, 0)), x2: vPos(Math.max(vMin, 0)), y1: plot.t, y2: plot.b, stroke: AXIS}));
      svg.append(ui);
      info.ui = ui; info.svg = svg;
      return {svg, info};
    }

    /* Cumulative lower/upper edge of each stacked-area series at every x: positives stack up from zero, negatives down. */
    function stackLevels(list) {
      const n = spec.x.length, pos = new Array(n).fill(0), neg = new Array(n).fill(0);
      return list.map(s => {
        const lo = new Array(n), hi = new Array(n);
        for (let i = 0; i < n; i++) {
          const v = s.values[i], x = v === null || v === undefined || !isFinite(v) ? 0 : v;
          if (x >= 0) { lo[i] = pos[i]; pos[i] += x; hi[i] = pos[i]; } else { hi[i] = neg[i]; neg[i] += x; lo[i] = neg[i]; }
        }
        return {s, lo, hi};
      });
    }
    function valueDomain(vis, dom) {
      let lo = 0, hi = 0;
      if (isTime()) {
        const [a, b] = dom || fullDomain(); let any = false; lo = Infinity; hi = -Infinity;
        for (const s of vis) for (let i = lowerBound(spec.x, a); i < spec.x.length && spec.x[i] <= b; i++) {
          const v = s.values[i]; if (v === null || v === undefined || !isFinite(v)) continue; any = true; lo = Math.min(lo, v); hi = Math.max(hi, v);
        }
        if (!any) { lo = 0; hi = 1; }
        const stacked = vis.filter(s => s.area);
        if (stacked.length) {
          const levels = stackLevels(stacked);
          for (const L of levels) for (let i = lowerBound(spec.x, a); i < spec.x.length && spec.x[i] <= b; i++) { hi = Math.max(hi, L.hi[i]); lo = Math.min(lo, L.lo[i]); }
        }
        if (spec.zeroBase !== false && lo > 0 && lo < hi * 0.5 + 1e-9) lo = 0;
        if (spec.zeroBase !== false && hi < 0) hi = 0;
        const padv = (hi - lo || Math.abs(hi) || 1) * 0.05;
        return {lo: lo === 0 ? 0 : lo - padv, hi: hi + padv};
      }
      const n = spec.categories.length;
      for (let i = 0; i < n; i++) {
        if (spec.floating) { const c = spec.categories[i]; hi = Math.max(hi, c.from, c.to); lo = Math.min(lo, c.from, c.to); continue; }
        if (spec.stack) {
          let pos = 0, neg = 0;
          for (const s of vis) { const v = s.values[i] || 0; if (v >= 0) pos += v; else neg += v; }
          hi = Math.max(hi, pos); lo = Math.min(lo, neg);
        } else for (const s of vis) { const v = s.values[i]; if (v !== null && v !== undefined && isFinite(v)) { hi = Math.max(hi, v); lo = Math.min(lo, v); } }
      }
      for (const l of spec.lines || []) if (!hidden.has(l.key)) for (const v of l.values) if (v !== null && v !== undefined && isFinite(v)) { hi = Math.max(hi, v); lo = Math.min(lo, v); }
      if (spec.refLines) for (const r of spec.refLines) { hi = Math.max(hi, r.value); lo = Math.min(lo, r.value); }
      if (hi === 0 && lo === 0) hi = 1;
      return {lo, hi};
    }
    const lowerBound = (arr, v) => { let a = 0, b = arr.length; while (a < b) { const m = (a + b) >> 1; if (arr[m] < v) a = m + 1; else b = m; } return Math.max(0, a - 1); };

    function drawBars(markG, axisG, plot, vPos, horizontal, vis, catLabels, lines, rot, xAxisH, vMin, vMax) {
      const n = spec.categories.length, bandLen = (horizontal ? plot.h : plot.w) / Math.max(1, n);
      const catStart = i => (horizontal ? plot.t : plot.l) + i * bandLen;
      info.catPos = {n, bandLen, start: catStart};
      const gapFrac = n > 1 ? 0.28 : 0.5, groupLen = bandLen * (1 - gapFrac), perBar = spec.stack || vis.length <= 1 ? groupLen : groupLen / vis.length;
      const rect = (cat, off, len, v0, v1, fill, extra) => {
        const a = vPos(v0), b = vPos(v1);
        const attrs = horizontal ? {x: Math.min(a, b), y: catStart(cat) + bandLen * gapFrac / 2 + off, width: Math.max(0, Math.abs(b - a)), height: len}
          : {x: catStart(cat) + bandLen * gapFrac / 2 + off, y: Math.min(a, b), width: len, height: Math.max(0, Math.abs(b - a))};
        return svgEl("rect", {...attrs, fill, rx: 1.5, ...extra});
      };
      spec.categories.forEach((c, i) => {
        if (c.highlight) markG.append(svgEl("rect", horizontal ? {x: plot.l - 6, y: catStart(i), width: plot.w + 6, height: bandLen, fill: "#FFF1BF", rx: 4} :
          {x: catStart(i), y: plot.t - 2, width: bandLen, height: plot.h + 2, fill: "#FFF1BF", rx: 4}));
      });
      spec.categories.forEach((c, i) => {
        let pos = 0, neg = 0;
        if (spec.floating) {
          const a = c.from, b = c.to, cx = catStart(i) + bandLen / 2, w = groupLen, x0 = catStart(i) + bandLen * gapFrac / 2;
          const top = vPos(Math.max(a, b)), h = Math.max(1.5, Math.abs(vPos(a) - vPos(b)));
          markG.append(svgEl("rect", {x: x0, y: top, width: w, height: h, fill: c.color, rx: 1.5, "data-c": i, "data-s": "v"}));
          if (c.text) label(markG, cx, top - 5, c.text, {size: 11, weight: 700, anchor: "middle"});
          if (i < n - 1) markG.append(svgEl("line", {x1: x0 + w, x2: x0 + bandLen, y1: vPos(b), y2: vPos(b), stroke: AXIS, "stroke-dasharray": "3 3"}));
        } else vis.forEach((s, si) => {
          const v = s.values[i]; if (v === null || v === undefined || !isFinite(v)) return;
          const fill = c.color && !spec.stack ? c.color : s.color, off = spec.stack ? 0 : si * perBar + (spec.stack ? 0 : 0);
          const faded = c.faded && !spec.stack, ex = {"data-s": s.key, "data-c": i, "fill-opacity": faded ? 0.5 : 1,
            stroke: faded ? fill : (spec.stack ? "#ffffff" : "none"), "stroke-width": faded ? 1.8 : 0.8, "stroke-dasharray": faded ? "5 3" : "none"};
          let v0 = 0, v1 = v;
          if (spec.stack) { if (v >= 0) { v0 = pos; v1 = pos + v; pos = v1; } else { v0 = neg; v1 = neg + v; neg = v1; } }
          if (Math.abs(v1 - v0) < 1e-12) return;
          markG.append(rect(i, off, perBar, v0, v1, fill, ex));
          if (spec.valueLabels && !spec.stack) {
            const txt = spec.barLabel ? spec.barLabel(v, s, i) : (spec.vFmt || fmt)(v), tw = measure(txt, 11, 600), p = vPos(v1);
            if (horizontal) label(markG, p + (v >= 0 ? 6 : -6), catStart(i) + bandLen * gapFrac / 2 + off + perBar / 2 + 4, txt, {size: 11, weight: 600, anchor: v >= 0 ? "start" : "end"});
            else if (tw <= perBar + 14) label(markG, catStart(i) + bandLen * gapFrac / 2 + off + perBar / 2, v >= 0 ? p - 5 : p + 14, txt, {size: 11, weight: 600, anchor: "middle"});
          }
        });
        if (spec.stack && spec.totals) {
          const total = vis.reduce((a, s) => a + (s.values[i] || 0), 0), p = vPos(pos), txt = (spec.vFmt || fmt)(total);
          if (horizontal) label(markG, p + 6, catStart(i) + bandLen / 2 + 4, txt, {size: 11, weight: 700});
          else label(markG, catStart(i) + bandLen / 2, p - 6, txt, {size: 11, weight: 700, anchor: "middle"});
        }
        const mid = catStart(i) + bandLen / 2;
        if (horizontal) label(axisG, plot.l - 8, mid + 4, catLabels[i], {size: 12, weight: c.highlight ? 700 : 500, anchor: "end", fill: c.highlight ? "#7a5600" : INK});
        else {
          const col = c.highlight ? "#7a5600" : INK, w = c.highlight ? 700 : 500;
          if (rot) label(axisG, mid + 4, plot.b + 16, catLabels[i], {size: 12, weight: w, anchor: "end", fill: col, rot});
          else lines[i].forEach((ln, k) => label(axisG, mid, plot.b + 17 + k * 14, ln, {size: 12, weight: w, anchor: "middle", fill: col}));
        }
      });
      if (!horizontal) for (const l of spec.lines || []) {
        if (hidden.has(l.key)) continue;
        let d = "";
        l.values.forEach((v, i) => { if (v === null || v === undefined || !isFinite(v)) return; d += `${d ? "L" : "M"}${(catStart(i) + bandLen / 2).toFixed(2)},${vPos(v).toFixed(2)}`; });
        markG.append(svgEl("path", {d, fill: "none", stroke: l.color, "stroke-width": l.width || 2.4, "stroke-dasharray": l.dash || "none", "stroke-linejoin": "round", "data-s": l.key}));
        l.values.forEach((v, i) => { if (v !== null && v !== undefined && isFinite(v)) markG.append(svgEl("circle", {cx: catStart(i) + bandLen / 2, cy: vPos(v), r: 3, fill: "#fff", stroke: l.color, "stroke-width": 1.8, "data-s": l.key})); });
      }
      for (const r of spec.refLines || []) {
        const p = vPos(r.value);
        markG.append(svgEl("line", horizontal ? {x1: p, x2: p, y1: plot.t, y2: plot.b, stroke: r.color || "#C0392B", "stroke-dasharray": "6 4", "stroke-width": 1.5} :
          {x1: plot.l, x2: plot.r, y1: p, y2: p, stroke: r.color || "#C0392B", "stroke-dasharray": "6 4", "stroke-width": 1.5}));
        if (r.label) label(markG, horizontal ? p + 4 : plot.r - 4, horizontal ? plot.t + 12 : p - 5, r.label, {size: 11, fill: r.color || "#C0392B", anchor: horizontal ? "start" : "end"});
      }
    }

    function drawTime(markG, axisG, plot, vPos, vis, forExport) {
      const [a, b] = domain || fullDomain(), xs = spec.x, xPos = x => plot.l + (x - a) / (b - a) * plot.w;
      info.xPos = xPos; info.a = a; info.b = b;
      const clipId = "gsclip" + Math.random().toString(36).slice(2, 8);
      const defs = svgEl("defs"); defs.append(svgEl("clipPath", {id: clipId}, undefined)); defs.firstChild.append(svgEl("rect", {x: plot.l, y: plot.t - 4, width: plot.w, height: plot.h + 8}));
      markG.append(defs);
      const g = svgEl("g", {"clip-path": `url(#${clipId})`}); markG.append(g);
      // x ticks
      let ticks, f;
      if (spec.xKind === "time") { const t = timeTicks(a, b, Math.max(2, Math.floor(plot.w / 110))); ticks = t.ticks; f = t.format; }
      else { const t = niceTicks(a, b, Math.max(2, Math.floor(plot.w / 80)), spec.xInteger !== false); ticks = t.ticks.filter(v => v >= a && v <= b); const tf = spec.xFmt || (v => String(Math.round(v * 1e6) / 1e6)); f = tf; }
      for (const t of ticks) {
        const p = xPos(t);
        markG.insertBefore(svgEl("line", {x1: p, x2: p, y1: plot.t, y2: plot.b, stroke: "#f0f4f6"}), g);
        axisG.append(svgEl("line", {x1: p, x2: p, y1: plot.b, y2: plot.b + 4, stroke: AXIS}));
        label(axisG, p, plot.b + 18, f(t), {size: 11, fill: MUTED, anchor: "middle"});
      }
      const i0 = lowerBound(xs, a), i1 = Math.min(xs.length - 1, lowerBound(xs, b) + 1);
      const count = i1 - i0 + 1, bucketed = count > plot.w * 2;
      const stacked = vis.filter(s => s.area);
      if (stacked.length) {
        const step = Math.max(1, Math.floor(count / (plot.w * 2)));
        for (const L of stackLevels(stacked)) {
          const idx = []; for (let i = i0; i <= i1; i += step) idx.push(i);
          if (idx[idx.length - 1] !== i1) idx.push(i1);
          const up = idx.map(i => `${xPos(xs[i]).toFixed(2)},${vPos(L.hi[i]).toFixed(2)}`), down = idx.slice().reverse().map(i => `${xPos(xs[i]).toFixed(2)},${vPos(L.lo[i]).toFixed(2)}`);
          g.append(svgEl("polygon", {points: up.concat(down).join(" "), fill: L.s.color, "fill-opacity": 0.82, stroke: L.s.color, "stroke-width": 0.4, "data-s": L.s.key}));
        }
      }
      for (const s of vis) {
        if (s.area) continue;
        let d = "";
        const yv = i => vPos(s.values[i]);
        if (!bucketed) {
          let pen = false;
          for (let i = i0; i <= i1; i++) {
            const v = s.values[i];
            if (v === null || v === undefined || !isFinite(v)) { pen = false; continue; }
            const px = xPos(xs[i]).toFixed(2), py = yv(i).toFixed(2);
            if (spec.step && pen) d += `H${px}V${py}`; else d += `${pen ? "L" : "M"}${px},${py}`;
            pen = true;
          }
        } else {
          const nb = Math.floor(plot.w); let cur = -1, mn, mx, imn, imx, first = true;
          const flush = () => { if (cur < 0) return; const x = (plot.l + cur).toFixed(2), lo = yv(imn).toFixed(2), hi = yv(imx).toFixed(2); const pair = imn <= imx ? [lo, hi] : [hi, lo];
            d += `${first ? "M" : "L"}${x},${pair[0]}L${x},${pair[1]}`; first = false; };
          for (let i = i0; i <= i1; i++) {
            const v = s.values[i]; if (v === null || v === undefined || !isFinite(v)) continue;
            const bk = Math.max(0, Math.min(nb, Math.floor(xPos(xs[i]) - plot.l)));
            if (bk !== cur) { flush(); cur = bk; mn = mx = v; imn = imx = i; } else { if (v < mn) { mn = v; imn = i; } if (v > mx) { mx = v; imx = i; } }
          }
          flush();
        }
        if (d) g.append(svgEl("path", {d, fill: "none", stroke: s.color, "stroke-width": s.width || 2, "stroke-dasharray": s.dash || "none", "stroke-linejoin": "round", "stroke-linecap": "round", "data-s": s.key}));
        if (!bucketed && count <= 60 && spec.markers !== false) for (let i = i0; i <= i1; i++) {
          const v = s.values[i]; if (v === null || v === undefined || !isFinite(v)) continue;
          g.append(svgEl("circle", {cx: xPos(xs[i]), cy: yv(i), r: 3.2, fill: "#fff", stroke: s.color, "stroke-width": 1.8, "data-s": s.key}));
        }
      }
      for (const pt of spec.points || []) {
        if (pt.x < a || pt.x > b || hidden.has(pt.key)) continue;
        const cx = xPos(pt.x), cy = vPos(pt.y), r = 6.5;
        g.append(svgEl("polygon", {points: `${cx},${cy - r} ${cx + r},${cy} ${cx},${cy + r} ${cx - r},${cy}`, fill: pt.color, stroke: "#fff", "stroke-width": 1.6, "data-s": pt.key}));
      }
      for (const r of spec.refLines || []) {
        const p = vPos(r.value);
        g.append(svgEl("line", {x1: plot.l, x2: plot.r, y1: p, y2: p, stroke: r.color || "#C0392B", "stroke-dasharray": "6 4", "stroke-width": 1.5}));
        if (r.label) label(markG, plot.r - 4, p - 5, r.label, {size: 11, fill: r.color || "#C0392B", anchor: "end"});
      }
    }

    function emphasise(key) {
      if (!info?.svg) return;
      for (const e of info.svg.querySelectorAll("[data-s]")) e.setAttribute("opacity", key && e.getAttribute("data-s") !== key ? 0.18 : 1);
    }

    /* ---------- interaction ---------- */
    const tipRows = (title, rows, extra) => {
      tip.replaceChildren(html("div", "gs-tip-h", title));
      for (const r of rows) {
        const line = html("div", "gs-tip-r" + (r.strong ? " gs-strong" : "")), sw = html("span", "gs-sw");
        if (r.color) sw.style.background = r.color; else sw.classList.add("gs-sw-none");
        line.append(sw, html("span", "gs-tip-l", r.label), html("span", "gs-tip-v", r.value)); tip.append(line);
      }
      for (const e of extra || []) tip.append(html("div", "gs-tip-x", e));
    };
    const placeTip = e => {
      const r = stage.getBoundingClientRect(); tip.hidden = false;
      let x = e.clientX - r.left + 16, y = e.clientY - r.top + 12;
      if (x + tip.offsetWidth > r.width - 4) x = e.clientX - r.left - tip.offsetWidth - 16;
      if (y + tip.offsetHeight > r.height - 4) y = Math.max(4, r.height - tip.offsetHeight - 4);
      tip.style.left = Math.max(4, x) + "px"; tip.style.top = Math.max(4, y) + "px";
    };
    function attach(svg) {
      const {plot} = info, ui = info.ui;
      const overlay = svgEl("rect", {x: plot.l, y: plot.t - 4, width: plot.w, height: plot.h + 4, fill: "#ffffff", opacity: 0, cursor: isTime() ? "crosshair" : "default"});
      ui.append(overlay);
      const local = e => { const r = svg.getBoundingClientRect(), k = info.W / r.width; return {x: (e.clientX - r.left) * k, y: (e.clientY - r.top) * k}; };
      const hover = svgEl("g", {"pointer-events": "none"}); ui.append(hover);
      if (!isTime()) {
        overlay.onpointermove = e => {
          const p = local(e), {n, bandLen, start} = info.catPos, along = info.horizontal ? p.y - plot.t : p.x - plot.l, i = Math.floor(along / bandLen);
          hover.replaceChildren();
          if (i < 0 || i >= n) { tip.hidden = true; return; }
          const c = spec.categories[i], vis = visible();
          hover.append(svgEl("rect", info.horizontal ? {x: plot.l, y: start(i), width: plot.w, height: bandLen, fill: "#173441", opacity: 0.07} : {x: start(i), y: plot.t, width: bandLen, height: plot.h, fill: "#173441", opacity: 0.07}));
          const vf = spec.vFmt || fmt, u = spec.unit ? " " + spec.unit : "";
          const rows = spec.floating ? [...(c.tip || [])] : vis.map(s => ({color: s.color, label: s.label, value: s.tips?.[i] ?? (s.values[i] === null || s.values[i] === undefined ? "–" : vf(s.values[i]) + u)}));
          for (const l of spec.lines || []) if (!hidden.has(l.key) && l.values[i] !== null && l.values[i] !== undefined) rows.push({color: l.color, label: l.label, value: vf(l.values[i]) + (l.unit ? " " + l.unit : u)});
          if (spec.stack && vis.length > 1) rows.push({label: "Total", value: vf(vis.reduce((a, s) => a + (s.values[i] || 0), 0)) + (spec.unit ? " " + spec.unit : ""), strong: true});
          tipRows((c.highlight ? "★ " : "") + c.label, rows, [c.highlight ? "Recommended option" : "", ...(c.notes || [])].filter(Boolean));
          placeTip(e);
        };
        overlay.onpointerleave = () => { hover.replaceChildren(); tip.hidden = true; };
        return;
      }
      let drag = null;
      const xAt = px => info.a + (px - plot.l) / plot.w * (info.b - info.a);
      overlay.onpointermove = e => {
        const p = local(e);
        if (drag) {
          if (drag.pan) { const dx = (p.x - drag.x) / plot.w * (drag.b - drag.a); setDomain(drag.a - dx, drag.b - dx); return; }
          const x0 = Math.min(drag.x, p.x), x1 = Math.max(drag.x, p.x);
          hover.replaceChildren(svgEl("rect", {x: x0, y: plot.t, width: x1 - x0, height: plot.h, fill: "#2F6DB5", opacity: 0.14, stroke: "#2F6DB5", "stroke-width": 1}));
          return;
        }
        const xv = xAt(p.x), i0 = lowerBound(spec.x, xv); let i = i0;
        if (i + 1 < spec.x.length && Math.abs(spec.x[i + 1] - xv) < Math.abs(spec.x[i] - xv)) i++;
        hover.replaceChildren(); const cx = info.xPos(spec.x[i]);
        hover.append(svgEl("line", {x1: cx, x2: cx, y1: plot.t, y2: plot.b, stroke: "#173441", "stroke-width": 1, "stroke-dasharray": "4 3", opacity: 0.7}));
        const rows = [], vf = spec.vFmt || fmt;
        for (const s of visible()) {
          const v = s.values[i]; if (v === null || v === undefined || !isFinite(v)) continue;
          hover.append(svgEl("circle", {cx, cy: info.vPos(v), r: 4.5, fill: s.color, stroke: "#fff", "stroke-width": 1.5}));
          rows.push({color: s.color, label: s.label, value: vf(v) + (spec.unit ? " " + spec.unit : "")});
        }
        tipRows(spec.xKind === "time" ? fullTime(spec.x[i]) : (spec.xFmt ? spec.xFmt(spec.x[i]) : fmt(spec.x[i])), rows, spec.tipExtra ? [spec.tipExtra(i)].filter(Boolean) : []);
        placeTip(e);
      };
      overlay.onpointerdown = e => {
        overlay.setPointerCapture(e.pointerId); const p = local(e), [a, b] = [info.a, info.b];
        drag = {x: p.x, a, b, pan: e.shiftKey || e.button === 1 || e.button === 2}; tip.hidden = true;
      };
      overlay.onpointerup = e => {
        if (!drag) return; const p = local(e), d = drag; drag = null; hover.replaceChildren();
        if (!d.pan && Math.abs(p.x - d.x) > 8) setDomain(xAt(Math.min(d.x, p.x)), xAt(Math.max(d.x, p.x)));
      };
      overlay.onpointerleave = () => { if (!drag) { hover.replaceChildren(); tip.hidden = true; } };
      overlay.oncontextmenu = e => e.preventDefault();
      overlay.ondblclick = () => { domain = null; draw(); };
      overlay.onwheel = e => { e.preventDefault(); const p = local(e); zoomBy(e.deltaY < 0 ? 0.75 : 1 / 0.75, Math.max(0, Math.min(1, (p.x - plot.l) / plot.w))); };
    }

    function draw() {
      const w = Math.max(320, Math.floor(stage.clientWidth || root.clientWidth || 900));
      const full = document.fullscreenElement === root;
      const h = full ? Math.max(360, stage.clientHeight || 600) : (spec.height || 380);
      const holderless = build(w, h, false);
      stage.querySelectorAll("svg").forEach(s => s.remove());
      stage.prepend(holderless.svg);
      curW = w; curH = h;
      if (holderless.info) attach(holderless.svg);
      root.classList.toggle("gs-zoomable", isTime());
      root.classList.toggle("gs-zoomed", !!domain);
      tools.querySelectorAll(".gs-zoom").forEach(b => { b.hidden = !isTime(); });
      const reset = tools.querySelector('[data-gs-action="reset"]'); if (reset) reset.disabled = !domain;
      tip.hidden = true;
    }
    const observer = new ResizeObserver(() => {
      const w = Math.floor(stage.clientWidth);
      if (!w || (Math.abs(w - curW) < 3 && document.fullscreenElement !== root)) return;
      schedule();
    });
    observer.observe(stage);
    document.addEventListener("fullscreenchange", () => { if (root.isConnected) schedule(); });
    draw();
    return {el: root, update(next) { spec = window.unitsUi ? window.unitsUi.adaptChart(next) : next; hidden = new Set([...hidden].filter(k => spec.series.some(s => s.key === k) || (spec.lines || []).some(l => l.key === k))); domain = null; draw(); },
      csv: toCSV, redraw: draw, get spec() { return spec; }};
  }

  /* ---------- toolbars for existing SVG diagrams / PNG figures ---------- */
  const LEGACY = "svg.tornado,svg.rel-chart,svg.waterfall,svg.ds-chart,svg#pfp-svg,#dsg-sld-box>svg";
  function legacyTitle(svg) {
    if (svg.getAttribute("aria-label")) return svg.getAttribute("aria-label");
    for (let e = svg; e && e !== document.body; e = e.parentElement) {
      for (let p = e.previousElementSibling; p; p = p.previousElementSibling) if (/^H[1-4]$/.test(p.tagName)) return p.textContent.trim();
    }
    return "chart";
  }
  function decorateSvg(svg) {
    if (svg.dataset.gsTools || !svg.parentNode) return;
    svg.dataset.gsTools = "1";
    const prev = svg.previousElementSibling; if (prev && prev.classList.contains("gs-legacy-tools")) prev.remove();
    const bar = html("div", "gs-legacy-tools"), title = legacyTitle(svg), name = slug(title);
    const add = (action, text, tip, fn) => { const b = html("button", "gs-btn", text); b.type = "button"; b.dataset.gsAction = action; b.title = tip; b.onclick = fn; bar.append(b); };
    add("png", "PNG", "Download high-resolution PNG (3x, white background)", async () => download(await canvasBlob(svgToCanvas(svg, 3, title)), name + ".png"));
    add("svg", "SVG", "Download vector SVG", () => download(new Blob([svgString(svg, title)], {type: "image/svg+xml"}), name + ".svg"));
    add("fullscreen", "Full screen", "Toggle full screen", () => { const t = svg.parentElement; if (document.fullscreenElement === t) document.exitFullscreen(); else t.requestFullscreen?.(); });
    svg.parentNode.insertBefore(bar, svg);
  }
  const IMAGES = "#load-plots img,.plot-card img,#annual-guide-plot";
  function decorateImg(img) {
    if (img.dataset.gsTools || !img.parentNode || !img.getAttribute("src")) return;
    img.dataset.gsTools = "1";
    const bar = html("div", "gs-legacy-tools"), b = html("button", "gs-btn", "Download PNG"); b.type = "button"; b.dataset.gsAction = "png";
    b.title = "Download this figure as PNG"; b.onclick = () => { const a = document.createElement("a"); a.href = img.getAttribute("src"); a.download = decodeURIComponent(a.pathname.split("/").pop() || "figure.png"); document.body.append(a); a.click(); a.remove(); };
    bar.append(b); img.parentNode.insertBefore(bar, img);
  }
  function scan(root) {
    if (root.matches?.(LEGACY)) decorateSvg(root);
    root.querySelectorAll?.(LEGACY).forEach(decorateSvg);
    if (root.matches?.(IMAGES)) decorateImg(root);
    root.querySelectorAll?.(IMAGES).forEach(decorateImg);
  }
  function watch() {
    scan(document.body);
    new MutationObserver(records => { for (const r of records) for (const n of r.addedNodes) if (n.nodeType === 1) scan(n); }).observe(document.body, {childList: true, subtree: true});
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", watch); else watch();

  return {chart, fmt, fixed, scenarioColor, techColor, registerScenarios, TECH_NAMES, TECH_COLORS, download, svgToCanvas, svgString, niceTicks, timeTicks, decorateSvg};
})();
