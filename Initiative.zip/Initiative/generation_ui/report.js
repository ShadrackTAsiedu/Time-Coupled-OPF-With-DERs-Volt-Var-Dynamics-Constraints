"use strict";
// Best-option highlight (SOLVE), economic / sensitivity / reliability digest (RESULTS SUMMARY) and client report export.
window.reportUi = (() => {
  const money = v => v == null ? "n/a" : `${v < 0 ? "-" : ""}${currencyUi.prefix()}${(Math.abs(v) * currencyUi.fx() / 1e6).toLocaleString(undefined, {maximumFractionDigits: 2})}M`;
  const fixed = (v, d = 1) => v == null ? "n/a" : Number(v).toLocaleString(undefined, {maximumFractionDigits: d});
  const kind = s => ({PASS: "pass", WARN: "warn", FAIL: "fail"})[String(s || "").toUpperCase()] || "";
  let digestCache = {run: null, data: null, pending: null};

  function isFeasible(r) {
    const a = r.adequacy || {};
    return !a.unserved_hours && (a.stress_unserved_mwh || 0) <= 5e-5;
  }
  // Lowest NPC among fully served scenarios (the reference wins only if it is cheapest);
  // when none is fully served, the least unserved energy.
  function pickBest(results) {
    const tagged = results.find(r => r.is_recommended);  // set by the server from the run's workflow ranking
    if (tagged) return {best: tagged, feasible: isFeasible(tagged)};
    const adjusted = window.workflowUi?.recommended(results);  // economic recommendation (technical status is a remark)
    if (adjusted) return adjusted;
    const feasible = results.filter(isFeasible);
    if (feasible.length) return {best: feasible.reduce((a, b) => b.economics.npc < a.economics.npc ? b : a), feasible: true};
    if (!results.length) return {best: null, feasible: false};
    return {best: results.reduce((a, b) => (b.adequacy.unserved_mwh - a.adequacy.unserved_mwh || b.economics.npc - a.economics.npc) < 0 ? b : a), feasible: false};
  }
  function badge(text, cls) { return node("span", text, "badge " + (cls || "")); }
  function mixText(c) {
    const parts = [];
    if (c.pv_dc_mw > .05) parts.push(`${fixed(c.pv_dc_mw)} MW PV`);
    if (c.bess_mw > .05) parts.push(`${fixed(c.bess_mw)} MW / ${fixed(c.bess_mwh)} MWh BESS`);
    for (const [k, v] of Object.entries(c.generators_mw || {})) if (v > .05) parts.push(`${fixed(v)} MW ${k}`);
    return parts.join(", ") || "no new on-site equipment";
  }

  async function digest(force) {
    if (!solveRun) return null;
    if (!force && digestCache.run === solveRun && digestCache.data) return digestCache.data;
    if (!force && digestCache.run === solveRun && digestCache.pending) return digestCache.pending;
    digestCache = {run: solveRun, data: null, pending: fetchJson(`/api/x/report_summary?run_id=${solveRun}`).then(d => {
      digestCache.data = d; digestCache.pending = null; return d;
    }).catch(() => { digestCache.pending = null; return null; })};
    return digestCache.pending;
  }

  const SECTION_CHOICES = [["exec", "Executive summary"], ["intro", "Introduction and scope"], ["data", "Data and demand forecast"], ["basis", "Basis of design and assumptions"],
    ["method", "Methodology"], ["results", "Scenario results and comparison"], ["solution", "Recommended solution"], ["economic", "Economic analysis"],
    ["sensitivity", "Sensitivity and uncertainty"], ["reliability", "Reliability and resilience"], ["powerflow", "Network / power-flow verification"],
    ["design", "Design summary (single-line diagram, key parameters)"], ["risk", "Risks and compliance summary"], ["conclusions", "Conclusions and recommendations"],
    ["app_inputs", "Appendix: input parameters"], ["app_equations", "Appendix: key equations"], ["app_quality", "Appendix: data quality and cleaning log"],
    ["app_dispatch", "Appendix: dispatch charts"], ["app_glossary", "Appendix: glossary and abbreviations"], ["app_refs", "Appendix: references"]];
  const TEXT_FIELDS = [["project_name", "Project name",], ["project_number", "Project number"], ["client_name", "Client name"], ["client_contact", "Client contact"],
    ["consulting_company", "Consulting company name"], ["prepared_by", "Prepared by"], ["reviewed_by", "Reviewed by"], ["approved_by", "Approved by"],
    ["document_number", "Document number"], ["revision", "Revision (e.g. A or 0)"], ["site", "Site / location"], ["revision_description", "Revision description"]];
  const PURPOSES = ["For information", "For review", "For approval", "For construction"];
  const STORE_KEY = "genstudio.report.meta.v1";
  const LOGO_TYPES = ["image/png", "image/jpeg", "image/gif", "image/webp"];
  let dialogState = null;

  function loadStored() {
    try { return JSON.parse(localStorage.getItem(STORE_KEY)) || {}; } catch (error) { return {}; }
  }
  function today() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }
  function field(labelText, control, hint) {
    const wrap = node("div", undefined, "report-field");
    const label = node("label", labelText);
    control.id = control.id || "rf-" + Math.random().toString(36).slice(2, 8);
    label.htmlFor = control.id;
    wrap.append(label, control);
    if (hint) wrap.append(node("small", hint, "muted"));
    return wrap;
  }

  function friendly(error) {
    return /failed to fetch|networkerror|load failed/i.test(error.message || "") ? "could not reach the GenStudio server - check that it is still running and try again." : error.message;
  }
  function showSummaryError(text) {
    const target = document.getElementById("export-summary-pdf")?.parentElement;
    if (!target) return;
    let note = document.getElementById("summary-pdf-error");
    if (!note) { note = node("p", "", "muted"); note.id = "summary-pdf-error"; note.setAttribute("role", "alert"); target.append(note); }
    note.textContent = text;
  }
  async function downloadSummaryPdf(button) {
    if (!solveRun) return;
    const label = button.textContent; button.disabled = true; button.textContent = "Building PDF...";
    showSummaryError("");
    try {
      const response = await fetch("/api/x/summary_pdf", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({run_id: solveRun})});
      if (!response.ok) { let msg = response.statusText; try { msg = (await response.json()).error || msg; } catch (error) { /* not JSON */ } throw new Error(msg); }
      const link = node("a");
      link.href = URL.createObjectURL(await response.blob()); link.download = "results_summary.pdf";
      document.body.append(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(link.href), 5000);
    } catch (error) { showSummaryError("PDF export failed: " + friendly(error)); }
    button.disabled = false; button.textContent = label;
  }
  document.addEventListener("click", event => {
    const button = event.target.closest && event.target.closest("#export-summary-pdf");
    if (!button) return;
    event.stopImmediatePropagation(); event.preventDefault();
    downloadSummaryPdf(button);
  }, true);

  const pptxName = project => {
    const clean = String(project || "").replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 60);
    return `${clean ? clean + "_" : ""}Executive_Presentation`;
  };

  async function downloadPresentation(button) {
    if (!solveRun) return;
    const stored = loadStored();
    const label = button.textContent; button.disabled = true; button.textContent = "Preparing presentation...";
    try {
      const meta = {...stored, date: today(), scenario: ""};
      const response = await fetch("/api/x/report_pptx", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({run_id: solveRun, meta})});
      if (!response.ok) { let msg = response.statusText; try { msg = (await response.json()).error || msg; } catch (error) { /* not JSON */ } throw new Error(msg); }
      const link = node("a");
      link.href = URL.createObjectURL(await response.blob()); link.download = `${pptxName(stored.project_name)}.pptx`;
      document.body.append(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(link.href), 5000);
    } catch (error) { window.alert("Presentation export failed: " + friendly(error)); }
    button.disabled = false; button.textContent = label;
  }

  function presentationButton(id) {
    const button = node("button", "Download executive presentation (PowerPoint)");
    button.id = id; button.type = "button"; button.classList.add("report-extract");
    button.title = "Download an editable executive PowerPoint built from the same results, using the details last entered in the report form.";
    button.onclick = () => downloadPresentation(button);
    return button;
  }

  function buildDialog() {
    const dialog = node("dialog", undefined, "report-dialog");
    dialog.id = "report-dialog";
    dialog.setAttribute("aria-labelledby", "report-dialog-title");
    const form = node("form"); form.id = "report-form"; form.noValidate = true;
    const inputs = {};
    const title = node("h3", "Extract project report"); title.id = "report-dialog-title";
    const grid = node("div", undefined, "report-grid");
    for (const [key, labelText] of TEXT_FIELDS) {
      const input = node("input"); input.type = "text"; input.name = key; input.maxLength = 160; input.autocomplete = "off";
      inputs[key] = input; grid.append(field(labelText, input));
    }
    const purpose = node("select"); purpose.name = "issue_purpose";
    const blank = node("option", "Not specified"); blank.value = ""; purpose.append(blank);
    for (const p of PURPOSES) { const o = node("option", p); o.value = p; purpose.append(o); }
    inputs.issue_purpose = purpose; grid.append(field("Issue purpose", purpose));
    const date = node("input"); date.type = "date"; date.name = "date"; inputs.date = date; grid.append(field("Report date", date));
    const scenario = node("select"); scenario.name = "scenario"; inputs.scenario = scenario; grid.append(field("Scenario to report", scenario, "Defaults to the best option."));
    const detail = node("select"); detail.name = "detail";
    for (const [value, text] of [["equivalent", "Equivalent (PSS/E study)"], ["detailed", "Detailed (per-block, for construction)"]]) {
      const o = node("option", text); o.value = value; detail.append(o);
    }
    inputs.detail = detail; grid.append(field("Design detail (single-line diagram and design report)", detail, "Equivalent is the default."));
    const logo = node("input"); logo.type = "file"; logo.accept = LOGO_TYPES.join(","); logo.name = "logo_file";
    const logoPreview = node("p", "Logo attached - it will appear on the cover page.", "muted"); logoPreview.hidden = true;
    const logoClear = node("button", "Remove logo", "secondary"); logoClear.type = "button"; logoClear.hidden = true;
    const logoField = field("Company logo (PNG, JPEG, GIF or WebP, up to 1 MB)", logo); logoField.classList.add("wide");
    logoField.append(logoPreview, logoClear);
    grid.append(logoField);
    const confid = node("textarea"); confid.name = "confidentiality"; confid.rows = 2; confid.maxLength = 800; inputs.confidentiality = confid;
    const confField = field("Confidentiality statement", confid); confField.classList.add("wide"); grid.append(confField);
    const notes = node("textarea"); notes.name = "notes"; notes.rows = 4; notes.maxLength = 6000; inputs.notes = notes;
    const notesField = field("Notes / scope of the study", notes, "Appears in the Introduction. Plain text only."); notesField.classList.add("wide"); grid.append(notesField);

    const fieldset = node("fieldset", undefined, "report-sections");
    fieldset.append(node("legend", "Sections to include"));
    const checks = {};
    for (const [key, text] of SECTION_CHOICES) {
      const row = node("label", undefined, "report-check");
      const box = node("input"); box.type = "checkbox"; box.value = key; box.checked = true; checks[key] = box;
      row.append(box, " " + text); fieldset.append(row);
    }
    const toggles = node("div", undefined, "report-toggles");
    const all = node("button", "Select all", "secondary"); all.type = "button";
    const none = node("button", "Clear all", "secondary"); none.type = "button";
    all.onclick = () => Object.values(checks).forEach(c => { c.checked = true; });
    none.onclick = () => Object.values(checks).forEach(c => { c.checked = false; });
    toggles.append(all, none); fieldset.append(toggles);

    const designRow = node("label", undefined, "report-check");
    const designBox = node("input"); designBox.type = "checkbox"; designBox.id = "report-also-design"; designBox.name = "also_design";
    designRow.append(designBox, " Also download the technical design report (design basis, equipment schedule, BOQ, power flow, protection, assumptions)");
    const pptxRow = node("label", undefined, "report-check");
    const pptxBox = node("input"); pptxBox.type = "checkbox"; pptxBox.id = "report-also-pptx"; pptxBox.name = "also_pptx"; pptxBox.checked = true;
    pptxRow.append(pptxBox, " Also download the executive presentation (editable PowerPoint: process, results, implications and recommended actions)");
    const wordRow = node("label", undefined, "report-check");
    const wordBox = node("input"); wordBox.type = "checkbox"; wordBox.id = "report-also-word"; wordBox.name = "also_word";
    wordRow.append(wordBox, " Also download an editable Word version (.docx) with a live table of contents, figure and table lists and page numbers");
    const status = node("p", "", "report-status"); status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite");
    const actions = node("div", undefined, "report-actions");
    const cancel = node("button", "Cancel", "secondary"); cancel.type = "button"; cancel.onclick = () => dialog.close();
    const submit = node("button", "Generate and download report"); submit.type = "submit"; submit.id = "report-generate";
    actions.append(cancel, submit);
    form.append(title, node("p", "All fields are optional - blank entries are left out of the report. If no section is ticked, every section is included. Entries are remembered on this computer.", "muted"),
      grid, fieldset, node("p", "The report is downloaded as a PDF (needs Edge or Chrome installed; takes about 15 seconds). Tick the options below for other formats.", "muted"), wordRow, pptxRow, designRow, status, actions);
    dialog.append(form);
    document.body.append(dialog);

    let logoData = "";
    const setLogo = data => {
      logoData = data || "";
      logoPreview.hidden = logoClear.hidden = !logoData;
      if (!logoData) logo.value = "";
    };
    logoClear.onclick = () => setLogo("");
    logo.onchange = () => {
      const file = logo.files[0];
      if (!file) return setLogo("");
      if (!LOGO_TYPES.includes(file.type) || file.size > 1024 * 1024) {
        status.textContent = "Logo must be a PNG, JPEG, GIF or WebP image of at most 1 MB.";
        return setLogo("");
      }
      status.textContent = "";
      const reader = new FileReader();
      reader.onload = () => setLogo(String(reader.result));
      reader.readAsDataURL(file);
    };
    form.onsubmit = async event => {
      event.preventDefault();
      if (!solveRun) return;
      const meta = {};
      for (const [key, input] of Object.entries(inputs)) meta[key] = input.value;
      meta.logo = logoData;
      meta.sections = Object.entries(checks).filter(([, c]) => c.checked).map(([k]) => k);
      const remember = {...meta}; delete remember.date; delete remember.scenario;
      try { localStorage.setItem(STORE_KEY, JSON.stringify(remember)); } catch (error) { /* storage full or blocked */ }
      submit.disabled = true; status.textContent = "Generating report...";
      try {
        const base = (meta.document_number || meta.project_name || "GenStudio_report").replace(/[^A-Za-z0-9._-]+/g, "_").slice(0, 60);
        const rev = (meta.revision || "").replace(/[^A-Za-z0-9]+/g, "") ? "_Rev" + meta.revision.replace(/[^A-Za-z0-9]+/g, "") : "";
        const fetchDoc = async route => {
          const response = await fetch(`/api/x/${route}`, {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({run_id: solveRun, meta})});
          if (!response.ok) { let msg = response.statusText; try { msg = (await response.json()).error || msg; } catch (error) { /* not JSON */ } throw new Error(msg); }
          return response.blob();
        };
        const saveBlob = (blob, name) => {
          const link = node("a");
          link.href = URL.createObjectURL(blob); link.download = name;
          document.body.append(link); link.click(); link.remove();
          setTimeout(() => URL.revokeObjectURL(link.href), 5000);
        };
        const extras = [];
        let pdfNote = "";
        status.textContent = "Generating PDF report (this takes a moment)...";
        saveBlob(await fetchDoc("report_pdf"), `${base}${rev}.pdf`);
        if (wordBox.checked) {
          status.textContent = "Generating editable Word report...";
          try { saveBlob(await fetchDoc("report_docx"), `${base}${rev}.docx`); extras.push("Word document"); }
          catch (error) { pdfNote += " The Word document could not be created: " + friendly(error); }
        }
        if (designBox.checked) {
          status.textContent = "Generating technical design report...";
          saveBlob(await fetchDoc("design_report_pdf"), `${base}_technical_design${rev}.pdf`);
          if (wordBox.checked) { try { saveBlob(await fetchDoc("design_report_docx"), `${base}_technical_design${rev}.docx`); } catch (error) { pdfNote += " The design Word document could not be created: " + friendly(error); } }
          extras.push("technical design report");
        }
        if (pptxBox.checked) {
          status.textContent = "Generating executive presentation...";
          saveBlob(await fetchDoc("report_pptx"), `${pptxName(meta.project_name)}.pptx`);
          extras.push("executive presentation (PowerPoint)");
        }
        status.textContent = `PDF report${extras.length ? " and " + extras.join(" and ") : ""} downloaded.${pdfNote}`;
      } catch (error) { status.textContent = "Report export failed: " + friendly(error); }
      submit.disabled = false;
    };
    dialogState = {dialog, inputs, checks, setLogo, status};
    return dialogState;
  }

  function openReportForm(preferred) {
    if (!solveRun) return;
    const state = dialogState || buildDialog();
    const results = solveSnapshot?.summary?.results || [];
    const best = results.length ? pickBest(results).best : null;
    const stored = loadStored();
    for (const [key, input] of Object.entries(state.inputs)) {
      if (key in stored && key !== "scenario" && key !== "date") input.value = stored[key];
    }
    state.inputs.date.value = today();
    state.inputs.scenario.replaceChildren(...results.map(r => {
      const o = node("option", `${r.code} - ${r.name}${best && r.code === best.code ? " (best option)" : ""}`); o.value = r.code; return o;
    }));
    state.inputs.scenario.value = results.some(r => r.code === preferred) ? preferred : best ? best.code : "";
    if (Array.isArray(stored.sections)) for (const [k, box] of Object.entries(state.checks)) box.checked = stored.sections.includes(k);
    state.setLogo(stored.logo || "");
    state.status.textContent = "";
    state.dialog.showModal();
    state.inputs.project_name.focus();
  }

  function extractButton(id) {
    const button = node("button", "Extract project report");
    button.id = id; button.type = "button"; button.classList.add("report-extract");
    button.title = "Enter the project details and download the professional PDF report (Word and PowerPoint editions optional).";
    button.onclick = () => openReportForm();
    return button;
  }

  function highlightSolveTable() {
    const results = solveSnapshot?.summary?.results || [];
    const host = byId("result-table");
    if (!host || !results.length) return;
    const {best, feasible} = pickBest(results);
    for (const row of host.querySelectorAll("tr")) {
      const code = row.cells[0]?.textContent;
      row.classList.toggle("best-row", !!best && code === best.code);
      row.querySelector(".best-badge")?.remove();
      if (best && code === best.code && row.cells.length > 1 && row.cells[0].tagName === "TD") {
        const tag = badge(feasible ? "Best option" : "Least shortage", "best best-badge");
        row.cells[1].prepend(tag, " ");
      }
    }
    let card = byId("best-option-card");
    if (!card) {
      card = node("section", undefined, "best-card"); card.id = "best-option-card";
      host.before(card);
    }
    if (!best) { card.hidden = true; return; }
    card.hidden = false;
    const ref = results.find(r => r.code === "R0");
    const e = best.economics, notes = [];
    const head = node("div", undefined, "best-card-head");
    head.append(badge(feasible ? "Best option" : "No fully supplied option", feasible ? "best" : "warn"),
      node("strong", `${best.code} - ${best.name}`), node("span", `NPC $${fixed(e.npc / 1e6, 2)}M`, "muted"));
    const line = node("p", `${mixText(best.caps)}.` + (ref && ref !== best ? ` ${e.npc - ref.economics.npc <= 0 ? "Saves" : "Costs"} ${money(Math.abs(e.npc - ref.economics.npc))} versus ${ref.code} over the appraisal period.` : ""));
    const flags = node("div", undefined, "best-card-flags");
    const tech = best.technical_status;
    const techStatus = tech?.status && tech.status !== "NOT_RUN" ? tech.status : null;
    flags.append(badge("Power flow: " + (techStatus || "not run"), kind(techStatus)));
    const relFlag = badge("Reliability: checking...", ""); flags.append(relFlag);
    if (!feasible) notes.push("No scenario serves all demand; the lowest-shortage case is shown, not an equivalent-service optimum.");
    if (["WARN", "FAIL"].includes(String(techStatus).toUpperCase())) notes.push(`Power-flow screening reports ${techStatus} for this option; review network violations before relying on it.`);
    const noteBox = node("div"); noteBox.className = "best-card-notes";
    const draw = () => { noteBox.replaceChildren(...notes.map(n => node("div", n, "notice"))); };
    draw();
    const buttons = node("div", undefined, "best-card-actions");
    buttons.append(extractButton("export-client-report-solve"));
    buttons.lastChild.onclick = () => openReportForm(best.code);
    buttons.append(presentationButton("download-presentation-solve"));
    card.replaceChildren(head, line, flags, noteBox, buttons);
    digest().then(d => {
      const item = d?.scenarios?.find(s => s.code === best.code);
      const verdict = item?.reliability?.verdict;
      relFlag.textContent = "Reliability: " + (verdict || "not run");
      relFlag.className = "badge " + kind(verdict);
      if (["WARN", "FAIL"].includes(String(verdict).toUpperCase())) {
        notes.push(`Reliability screening reports ${verdict} for this option; see ANALYZE > Reliability.`);
        draw();
      }
    });
  }

  function openAnalysis(pane) {
    switchView("analyze");
    analysisTabs.show(pane);
  }
  function card(title, pane) {
    const c = node("div", undefined, "analysis-card");
    const h = node("h4", title);
    c.append(h);
    if (pane) {
      const b = node("button", "Open " + title.toLowerCase(), "secondary link-button");
      b.type = "button"; b.onclick = () => openAnalysis(pane); c.append(b);
    }
    return c;
  }
  function kv(pairs) {
    const dl = node("dl", undefined, "analysis-kv");
    for (const [k, v] of pairs) { dl.append(node("dt", k), node("dd", v)); }
    return dl;
  }

  async function renderSummaryCards() {
    const results = solveSnapshot?.summary?.results || [];
    let host = byId("summary-analyses");
    if (!host) {
      host = node("section", undefined, "analysis-cards"); host.id = "summary-analyses";
      byId("summary-best").after(host);
      const bar = byId("export-summary-pdf").parentElement;
      bar.classList.add("report-bar");
      bar.insertBefore(extractButton("extract-project-report"), byId("export-summary-pdf"));
      bar.insertBefore(presentationButton("download-executive-presentation"), byId("export-summary-pdf"));
    }
    const prior = byId("report-scenario");
    if (prior) prior.remove();
    if (!results.length) { host.replaceChildren(); return; }
    const {best, feasible} = pickBest(results);
    byId("extract-project-report").disabled = false;
    host.replaceChildren(node("p", "Loading analysis results...", "muted"));
    const d = await digest(true);
    if (!d) { host.replaceChildren(node("p", "Analysis digest unavailable.", "muted")); return; }
    const item = d.scenarios.find(s => s.code === best.code) || {};
    const cards = [];

    const eco = card("Economic analysis", "economic");
    const e = item.economic;
    const fmtIrr = (x, k) => x.status === "reference" ? "- (reference case)" : x[k] == null ? "n/a" : (100 * x[k]).toLocaleString(undefined, {maximumFractionDigits: 4}) + "%";
    const fmtPb = (x, k) => x.status === "reference" ? "- (reference case)" : x[k + "_years"] == null ? "not within horizon" : x[k + "_years"] <= 0 ? "Immediate" : fixed(x[k + "_years"], 2) + " yr";
    if (e && e.status) {
      eco.append(kv([["Scenario", `${best.code}${feasible ? " (best option)" : ""}`], ["NPC", money(best.total_npc ?? best.economics.npc)],
        [`Incremental NPV vs ${d.reference}`, e.status === "reference" ? "- (reference case)" : money(e.npv)],
        ["IRR (net of avoided reference capex)", fmtIrr(e, "irr")], ["Simple payback", fmtPb(e, "simple_payback")], ["Discounted payback", fmtPb(e, "discounted_payback")],
        ["IRR (operating savings only)", fmtIrr(e, "op_irr")], ["Payback (operating savings only)", fmtPb(e, "op_simple_payback")],
        ["Levelized supply cost", e.lcoe == null ? "n/a" : `$${fixed(e.lcoe, 4)}/MWh`], ["Net CO2e (appraisal)", e.co2 == null ? "n/a" : fixed(e.co2 / 1e3, 0) + " kt"]]));
      for (const note of [e.reason, e.irr_note, e.op_irr_note, ...(e.warnings || [])]) if (note) eco.append(node("p", note, "muted"));
      const all = d.scenarios.filter(s => s.economic && s.economic.status);
      const t = node("table", undefined, "xl"), head = node("tr");
      for (const h of ["Scenario", "NPV vs " + d.reference, "IRR", "Simple payback", "Discounted payback", "IRR (operating only)", "Payback (operating only)"]) head.append(node("th", h));
      t.append(head);
      for (const s of all) {
        const x = s.economic, tr = node("tr");
        for (const v of [s.code, x.status === "reference" ? "-" : money(x.npv), fmtIrr(x, "irr"), fmtPb(x, "simple_payback"), fmtPb(x, "discounted_payback"), fmtIrr(x, "op_irr"), fmtPb(x, "op_simple_payback")]) tr.append(node("td", v));
        t.append(tr);
      }
      const wrap = node("div", undefined, "table-scroll"); wrap.append(t); eco.append(wrap);
      eco.append(node("p", "Basis and equations: Analyze > Economic analysis > 'How this is computed'.", "muted"));
    } else eco.append(node("p", "No financial metrics available for this solve.", "muted"));
    cards.push(eco);

    const sens = card("Sensitivity analysis", "sensitivity");
    if (d.sensitivity) {
      const s = d.sensitivity;
      if (s.scenario && s.scenario !== best.code) sens.append(node("p", `Run for ${s.scenario} (${s.name}), not the best option.`, "notice"));
      if (s.risk) sens.append(kv([["P10 / P50 / P90 NPC", `${money(s.risk.p10)} / ${money(s.risk.p50)} / ${money(s.risk.p90)}`]]));
      sens.append(kv(s.top.slice(0, 3).map(t => [t.label, `swing ${money(t.swing)}`])));
    } else sens.append(node("p", "Not run. Use the Sensitivity tab to test price, cost and demand ranges.", "muted"));
    cards.push(sens);

    const rel = card("Reliability", "reliability");
    if (item.reliability) {
      const v = item.reliability.verdict;
      const s = item.reliability.summary || {}, det = item.reliability.detail || {};
      const last = (item.reliability.rows || []).slice(-1)[0] || {};
      const lole = s.lole_h_yr ?? last.lole_hours, eue = s.eue_mwh_yr ?? last.eue_mwh;
      const n1 = det.local_n1_secure ?? last.n1_pass;
      rel.append(badge(v || "n/a", kind(v)), kv([["Verdict", v || "n/a"], ["Expected downtime (LOLE)", lole == null ? "n/a" : fixed(lole, 2) + " h/yr"],
        ["Expected unserved (EUE)", eue == null ? "n/a" : fixed(eue, 1) + " MWh/yr"], ["Load served", s.load_served_pct == null ? "n/a" : fixed(s.load_served_pct, 3) + "%"],
        ["Reserve margin", last.reserve_margin_pct == null ? "n/a" : fixed(last.reserve_margin_pct) + "%"],
        ["N-1 (local resources)", n1 == null ? "n/a" : n1 ? "Secure" : "Not secure"],
        ["N-1 (grid loss)", det.grid_n1_secure == null ? "n/a" : det.grid_n1_secure ? "Secure" : "Not secure"]]));
    } else rel.append(node("p", "Not run for the best option. Use the Reliability tab.", "muted"));
    cards.push(rel);

    const pf = card("Power-flow check");
    const t = item.technical;
    if (t && t.status && t.status !== "NOT_RUN") pf.append(badge(t.status, kind(t.status)), kv([["N-1", t.n1 || "n/a"], ["Violations", String(t.violations)]]));
    else pf.append(node("p", "Not run for the best option.", "muted"));
    cards.push(pf);

    host.replaceChildren(node("h3", "Economic, sensitivity and reliability results"), ...cards);
  }

  function refresh() {
    try {
      highlightSolveTable();
      if (activeView === "summary") renderSummaryCards();
    } catch (error) { console.error(error); }
  }
  window.addEventListener("load", () => setTimeout(refresh, 0));
  return {refresh, pickBest, openReportForm};
})();
