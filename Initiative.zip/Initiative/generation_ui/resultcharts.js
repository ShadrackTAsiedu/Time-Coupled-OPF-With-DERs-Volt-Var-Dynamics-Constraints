"use strict";
/* Interactive replacements for the static Solve/Analyze result PNGs. Each builder returns a DOM element or null
   (null => the caller keeps showing the server-rendered PNG, which is still produced for the reports). */
window.resultCharts = (() => {
  const G = window.GS, fmt = G.fmt;
  const FLAG_TEXT = "* Unserved energy: not equivalent service. Do not compare its lower cost as a saving.";
  const nameOf = (tech, names) => names?.[tech] || G.TECH_NAMES[tech] || tech;
  const served = r => r.adequacy?.status === "ALL LOAD SERVED";
  const flagged = r => !served(r);

  // total_npc = optimizer NPC + corrections already applied; the server tags it with is_recommended (single source of truth).
  const totalNpc = r => r.total_npc ?? r.economics.npc;
  function recommended(results) {
    const tagged = results.find(r => r.is_recommended);
    if (tagged) return tagged.code;
    const wf = window.workflowUi?.recommended?.(results)?.best;
    if (wf) return wf.code;
    const ok = results.filter(r => !r.adequacy.unserved_hours && r.adequacy.stress_unserved_mwh <= 5e-5);
    const pool = ok.length ? ok : results;
    return pool.length ? pool.reduce((a, b) => (totalNpc(b) < totalNpc(a) ? b : a)).code : null;
  }
  function categories(results, rec) {
    return results.map(r => ({key: r.code, label: r.code + (flagged(r) ? " *" : ""), color: G.scenarioColor(r.code), faded: flagged(r),
      highlight: r.code === rec, notes: [r.name, flagged(r) ? `Unserved ${fmt(r.adequacy.unserved_mwh)} MWh: not equivalent service` : ""].filter(Boolean)}));
  }
  const legendFor = (results, rec) => [
    ...(results.some(r => r.code === rec) ? [{label: "★ Recommended option", color: "#FFF1BF", band: true}] : []),
    ...(results.some(flagged) ? [{label: "* Unserved energy (hatched outline): not equivalent service", color: "#7C8B99", faded: true}] : [])];
  const footnoteFor = results => (results.some(flagged) ? FLAG_TEXT : "");
  const years = results => (results[0]?.economics?.annual || []).map(a => a.year);
  const wrapper = (...charts) => {
    const box = document.createElement("div"); box.className = charts.length > 1 ? "gs-grid" : "gs-single";
    for (const c of charts) box.append(c.el);
    return box;
  };
  const sumAnnual = (r, key) => (r.economics.annual || []).reduce((a, y) => a + (y[key] || 0), 0);

  function costs(results, ctx) {
    const rec = recommended(results), base = ctx.baseYear, n = years(results).length;
    return [G.chart({kind: "bars", horizontal: true, valueLabels: true, title: "Optimized costs", filename: "optimized_costs",
      subtitle: "Total net present cost (NPC) per scenario, including corrections already applied; lower is better.", xTitle: `${n}-year NPC (${base} $ million)`, unit: "$ M",
      catTitle: "Scenario", categories: categories(results, rec), height: 130 + results.length * 40, vFmt: v => fmt(v, 2),
      series: [{key: "npc", label: "Total NPC ($ M)", color: "#2F6DB5", values: results.map(r => totalNpc(r) / 1e6)}],
      legendItems: legendFor(results, rec), footnote: footnoteFor(results)}),
    G.chart({kind: "bars", stack: true, totals: true, title: "Net present cost breakdown", filename: "npc_breakdown",
      subtitle: "Discounted cost components; heat credit is shown below zero.", yTitle: `$ million (${base} $)`, unit: "$ M",
      categories: categories(results, rec), height: 420, vFmt: v => fmt(v, 2), footnote: footnoteFor(results),
      legendItems: legendFor(results, rec),
      series: (() => {
        const parts = [["Investment", "#2B7BBA", e => e.capex + e.upgrade_pv], ["Grid", "#7C8B99", e => e.grid_pv], ["Fuel", "#D1603D", e => e.fuel_pv],
          ["O&M", "#E8A91D", e => e.fixed_om_pv + e.variable_om_pv + e.upgrade_om_pv], ["Carbon allowance", "#8E6BBF", e => e.carbon_pv],
          ["Useful heat credit", "#4C9F50", e => -e.heat_credit_pv]];
        const out = parts.map(([label, color, f]) => ({key: label, label, color, values: results.map(r => (f(r.economics) || 0) / 1e6)}));
        out.push({key: "applied", label: "Applied network corrections", color: "#B07AA1", values: results.map(r => (totalNpc(r) - r.economics.npc) / 1e6)});
        const rest = results.map(r => (r.economics.npc - parts.reduce((a, p) => a + (p[2](r.economics) || 0), 0)) / 1e6);
        if (rest.some(v => Math.abs(v) > 5e-4)) out.push({key: "other", label: "Replacements and other", color: "#9AA9B3", values: rest});
        return out.filter(s => s.values.some(v => Math.abs(v) > 1e-9));
      })()})];
  }

  function mix(results, ctx) {
    const rec = recommended(results), names = ctx.names;
    const techs = [...new Set(results.flatMap(r => Object.keys(r.caps.generators_mw || {})))].filter(t => t !== "none");
    const gen = (r, t) => r.caps.generators_mw?.[t] || 0;
    const cap = [];
    const pvAc = r => Math.max(0, r.caps.microgrid_total_ac_mw - r.caps.bess_mw - techs.reduce((a, t) => a + gen(r, t), 0));
    cap.push({key: "pv", label: "Additional solar (AC)", color: G.techColor("pv"), values: results.map(pvAc)});
    cap.push({key: "bess", label: "BESS power", color: G.techColor("bess"), values: results.map(r => r.caps.bess_mw)});
    for (const t of techs) cap.push({key: t, label: nameOf(t, names), color: G.techColor(t), values: results.map(r => gen(r, t))});
    const supply = [{key: "grid", label: "Grid", color: G.techColor("grid"), values: results.map(r => sumAnnual(r, "grid_mwh") / 1000)},
      {key: "planned", label: "Planned renewables", color: G.techColor("planned"), values: results.map(r => sumAnnual(r, "planned_renewable_mwh") / 1000)},
      {key: "pv", label: "Microgrid solar", color: G.techColor("pv"), values: results.map(r => sumAnnual(r, "optimized_solar_mwh") / 1000)}];
    for (const t of techs) supply.push({key: t, label: nameOf(t, names), color: G.techColor(t),
      values: results.map(r => (r.economics.annual || []).reduce((a, y) => a + (y[t + "_generation_mwh"] ?? (r.tech === t ? y.gen_mwh : 0) ?? 0), 0) / 1000)});
    const keep = s => s.values.some(v => Math.abs(v) > 1e-9);
    const cats = categories(results, rec), n = years(results).length;
    return [G.chart({kind: "bars", stack: true, totals: true, title: "Additional optimized microgrid capacity", filename: "microgrid_capacity",
      subtitle: "Common planned assets excluded.", yTitle: "Capacity (MW AC)", unit: "MW", categories: cats, height: 420, vFmt: v => fmt(v, 3),
      series: cap.filter(keep), legendItems: legendFor(results, rec), footnote: footnoteFor(results)}),
    G.chart({kind: "bars", stack: true, totals: true, title: `${n}-year energy supply`, filename: "energy_supply",
      subtitle: "Supply before storage losses.", yTitle: "Energy (GWh)", unit: "GWh", categories: cats, height: 420, vFmt: v => fmt(v, 2),
      series: supply.filter(keep), legendItems: legendFor(results, rec), footnote: footnoteFor(results)})];
  }

  function annualCosts(results, ctx) {
    const ys = years(results); if (!ys.length) return [];
    const rec = recommended(results);
    return [G.chart({kind: "time", xKind: "number", title: "Annual operating cost", filename: "annual_operating_cost",
      subtitle: "Nominal net operating cost per year; the recommended option is drawn thicker.", xTitle: "Year", yTitle: "Operating cost ($ million / year)", unit: "$ M",
      x: ys, height: 400, vFmt: v => fmt(v, 2), footnote: footnoteFor(results),
      series: results.map(r => ({key: r.code, label: r.code + (flagged(r) ? " *" : ""), color: G.scenarioColor(r.code), dash: flagged(r) ? "6 4" : undefined,
        width: r.code === rec ? 3.6 : 2.2, values: r.economics.annual.map(a => a.net_opex / 1e6)}))})];
  }

  function unserved(results) {
    const rec = recommended(results), out = [];
    out.push(G.chart({kind: "bars", valueLabels: true, title: "Unserved energy by scenario", filename: "unserved_energy",
      subtitle: "Zero means all modeled normal-profile load is served.", yTitle: "Unserved energy (MWh)", unit: "MWh", categories: categories(results, rec),
      height: 360, series: [{key: "u", label: "Unserved energy (MWh)", color: "#C0392B", values: results.map(r => r.adequacy.unserved_mwh)}],
      legendItems: legendFor(results, rec), footnote: footnoteFor(results)}));
    const shorted = results.filter(r => (r.economics.annual || []).some(a => (a.unserved_mwh || 0) > 1e-9));
    if (shorted.length) out.push(G.chart({kind: "time", xKind: "number", title: "Annual unserved energy", filename: "annual_unserved_energy",
      subtitle: "Scenarios with shortfall only.", xTitle: "Year", yTitle: "Unserved energy (MWh / year)", unit: "MWh", x: years(results), height: 360,
      series: shorted.map(r => ({key: r.code, label: r.code, color: G.scenarioColor(r.code), values: r.economics.annual.map(a => a.unserved_mwh || 0)}))}));
    return out;
  }

  function forecast(status) {
    const pts = status.annual_trajectory;
    if (!pts?.length) return [];
    return [G.chart({kind: "time", xKind: "number", title: "Annual gross-demand guide", filename: "annual_gross_demand",
      subtitle: "Default intermediate points are approximate.", xTitle: "Year", yTitle: "Annual gross peak (MW)", unit: "MW", x: pts.map(p => p.year), height: 360,
      vFmt: v => fmt(v, 2), zeroBase: true,
      tipExtra: i => (i ? `Change ${fmt(100 * (pts[i].peak_mw / pts[i - 1].peak_mw - 1), 2)} % vs previous year. ` : "") + (pts[i].description || ""),
      series: [{key: "peak", label: "Annual gross peak", color: "#B63E3E", values: pts.map(p => p.peak_mw)}]})];
  }

  function build(name, ctx) {
    const results = ctx.summary?.results || [];
    try {
      G.registerScenarios(results.map(r => r.code));
      ctx = {...ctx, baseYear: (ctx.status?.planning?.start_year ?? years(results)[0] ?? 0) - 1};
      let charts = [];
      if (name === "annual_gross_forecast.png") charts = forecast(ctx.status || {});
      else if (!results.length) return null;
      else if (name === "cost_comparison.png") charts = costs(results, ctx);
      else if (name === "generation_mix.png") charts = mix(results, ctx);
      else if (name === "annual_costs.png") charts = annualCosts(results, ctx);
      else if (name === "unserved_load.png") charts = unserved(results, ctx);
      return charts.length ? wrapper(...charts) : null;
    } catch (error) { console.error("Interactive chart failed; showing the saved image.", error); return null; }
  }

  function analysis(table, results, status) {
    try {
      if (!table?.rows?.length) return null;
      const col = n => table.columns.indexOf(n), id = col("ID"), lcoe = col("Levelized supplied electricity $/MWh"), npv = col("Incremental NPV $m");
      const supply = col("Total supply CO2e t"), net = col("Net after boiler credit CO2e t"), direct = col("Direct generator CO2 t");
      G.registerScenarios(table.rows.map(r => r[id]));
      const base = (status?.planning?.start_year ?? 2027) - 1, byCode = Object.fromEntries((results || []).map(r => [r.code, r]));
      const rec = recommended(results || []);
      const cat = r => { const res = byCode[r[id]], bad = res ? flagged(res) : false;
        return {key: r[id], label: r[id] + (bad ? " *" : ""), color: G.scenarioColor(r[id]), faded: bad, highlight: r[id] === rec, notes: [res?.name, bad ? "Unserved energy: not equivalent service" : ""].filter(Boolean)}; };
      const lrows = table.rows.filter(r => r[lcoe] !== null && r[lcoe] !== undefined), charts = [];
      const rr = (results || []).filter(r => lrows.some(x => x[id] === r.code));
      if (lrows.length) charts.push(G.chart({kind: "bars", valueLabels: true, title: "Levelized supplied electricity", filename: "lcoe_comparison",
        subtitle: "Whole-system cost per discounted MWh served; shortage cases are not equivalent service.", yTitle: `${base} $ / discounted MWh served`, unit: "$/MWh",
        categories: lrows.map(cat), height: 380, vFmt: v => fmt(v, 2), series: [{key: "lcoe", label: "LCOE", color: "#2F6DB5", values: lrows.map(r => r[lcoe])}],
        legendItems: legendFor(rr, rec), footnote: footnoteFor(rr)}));
      const nrows = table.rows.filter(r => r[npv] !== null && r[npv] !== undefined);
      if (nrows.length) charts.push(G.chart({kind: "bars", valueLabels: true, title: "Incremental NPV vs reference", filename: "incremental_npv",
        subtitle: "Only cases with equivalent service.", yTitle: `${base} $ million`, unit: "$ M", categories: nrows.map(cat), height: 380, vFmt: v => fmt(v, 2),
        series: [{key: "npv", label: "Incremental NPV", color: "#2A9D8F", values: nrows.map(r => r[npv])}]}));
      const withSupply = table.rows.some(r => r[supply] !== null && r[supply] !== undefined);
      const series = withSupply ? [{key: "s", label: "Supply", color: "#8E6BBF", values: table.rows.map(r => r[supply])},
        {key: "n", label: "After boiler credit", color: "#2A9D8F", values: table.rows.map(r => r[net])}]
        : [{key: "d", label: "Direct generator CO2", color: "#8E6BBF", values: table.rows.map(r => r[direct])}];
      charts.push(G.chart({kind: "bars", valueLabels: !withSupply, title: withSupply ? "Screening CO2e emissions" : "Direct generator CO2 only", filename: "carbon_comparison",
        subtitle: withSupply ? "Not a total site inventory." : "Supply totals unavailable: emission factors not confirmed.", yTitle: "tonnes CO2e", unit: "t",
        categories: table.rows.map(cat), height: 380, vFmt: v => fmt(v, 1), series}));
      return wrapper(...charts);
    } catch (error) { console.error("Interactive analysis charts failed.", error); return null; }
  }
  return {build, analysis, recommended};
})();
