"use strict";
/* Display-unit layer. The canonical (model) unit of every quantity never changes: dropdowns only change how a value is
   shown or typed. Values are converted back to canonical before they leave the form (values(), readRows(), snapshot). */
const unitsUi = (() => {
  const GJ = 1.055056, MWH_PER_MMBTU = 0.29307107, ACRE_M2 = 4046.8564224;
  const clean = v => Number.isFinite(v) ? Number(v.toPrecision(12)) : v;
  // option: [label, canonical-units-per-one-displayed-unit, tag]. Tag "p:kW" / "e:kWh" ties it to the global setting.
  const power = (s, t) => [["W" + s, 1e-6, "p:W"], ["kW" + s, 1e-3, "p:kW"], ["MW" + s, 1, "p:MW"], ["GW" + s, 1e3, "p:GW"]]
    .map(o => (o[0] = o[0] + (t || ""), o));
  const energy = [["Wh", 1e-6], ["kWh", 1e-3, "e:kWh"], ["MWh", 1, "e:MWh"], ["GWh", 1e3]];
  const perPower = s => [["$/kW" + s, 1e3, "p:kW"], ["$/MW" + s, 1, "p:MW"], ["k$/MW" + s, 1e3, "p:MW"], ["M$/MW" + s, 1e6, "p:MW"]];
  const perEnergy = [["$/MWh", 1, "e:MWh"], ["$/kWh", 1e3, "e:kWh"], ["\u00a2/kWh", 10, "e:kWh"], ["$/GWh", 1e-3]];
  const SPECS = {
    "MW": power(""), "MW AC": power("", " AC"), "MW thermal": power("", " thermal"),
    "kW": [["W", 1e-3, "p:W"], ["kW", 1, "p:kW"], ["MW", 1e3, "p:MW"]],
    "MWh": energy, "kWh": [["Wh", 1e-3], ["kWh", 1, "e:kWh"], ["MWh", 1e3, "e:MWh"]],
    "$": [["$", 1], ["k$", 1e3], ["M$", 1e6]],
    "$/MW": perPower(""), "$/MW AC": perPower(" AC"), "$/MW per start": perPower(" per start"),
    "$/kWh": [["$/kWh", 1, "e:kWh"], ["\u00a2/kWh", .01, "e:kWh"], ["$/MWh", .001, "e:MWh"]],
    "$/MWh": perEnergy, "$/MWh discharged": perEnergy.map(o => [o[0] + " discharged", o[1], o[2]]),
    "$/kVar-month": [["$/kVar-month", 1], ["$/MVar-month", 1e-3]],
    "$/MMBtu HHV": [["$/MMBtu HHV", 1], ["$/GJ HHV", GJ], ["$/MWh HHV (thermal)", MWH_PER_MMBTU], ["$/kWh HHV (thermal)", MWH_PER_MMBTU * 1e3], ["$/therm HHV", 10]],
    "$/kg H2": [["$/kg H2", 1], ["$/t H2", 1e-3]],
    "$/tonne CO2": [["$/tonne CO2", 1], ["$/kg CO2", 1e3]],
    "t CO2e/MWh": [["t CO2e/MWh", 1], ["kg CO2e/MWh", 1e-3], ["kg CO2e/kWh", 1], ["g CO2e/kWh", 1e-3]],
    "t CO2e/MMBtu HHV": [["t CO2e/MMBtu HHV", 1], ["kg CO2e/MMBtu HHV", 1e-3], ["kg CO2e/GJ HHV", GJ / 1000]],
    "t CO2e/year": [["t CO2e/year", 1], ["kg CO2e/year", 1e-3], ["kt CO2e/year", 1e3], ["Mt CO2e/year", 1e6]],
    "acres": [["acres", 1], ["ha", 10000 / ACRE_M2], ["m\u00b2", 1 / ACRE_M2], ["km\u00b2", 1e6 / ACRE_M2]],
    "acres/MW": [["acres/MW", 1, "p:MW"], ["ha/MW", 10000 / ACRE_M2, "p:MW"], ["m\u00b2/kW", 1e3 / ACRE_M2, "p:kW"]],
    "acres/MWh": [["acres/MWh", 1, "e:MWh"], ["ha/MWh", 10000 / ACRE_M2, "e:MWh"], ["m\u00b2/kWh", 1e3 / ACRE_M2, "e:kWh"]]
  };
  // Row inputs (milestones, existing/planned generation) carry their unit in the key, not in a schema.
  const ROW_UNITS = {peak_mw: "MW", capacity_mw: "MW", energy_mwh: "MWh", pv_kw: "kW", bess_kw: "kW", bess_kwh: "kWh"};
  const GLOBAL_KEY = "genstudio-display-units";
  let global = {power: "default", energy: "default"};
  try { Object.assign(global, JSON.parse(localStorage.getItem(GLOBAL_KEY) || "{}")); } catch (e) { /* ignore */ }

  const opts = unit => (SPECS[unit] || []).map(([label, f, tag]) => ({label, f, tag}));
  const canonOption = unit => opts(unit).find(o => o.f === 1);
  const find = (unit, label) => opts(unit).find(o => o.label === label);
  // Convert a displayed number between two options of a unit family; clean() removes binary-float noise.
  function convert(value, unit, fromLabel, toLabel) {
    const a = find(unit, fromLabel), b = find(unit, toLabel);
    if (!a || !b || !Number.isFinite(value)) return value;
    return clean(value * a.f / b.f);
  }
  const isMoney = unit => String(unit || "").includes("$");
  const fxOf = unit => isMoney(unit) && window.currencyUi ? currencyUi.fx() : 1;
  const toCanonical = (value, unit, label) => clean(convert(value, unit, label, canonOption(unit)?.label) / fxOf(unit));
  const fromCanonical = (value, unit, label) => clean(convert(value, unit, canonOption(unit)?.label, label) * fxOf(unit));

  const all = () => [...document.querySelectorAll("[data-unit-canon]")];
  const current = input => input.dataset.unitLabel || canonOption(input.dataset.unitCanon).label;
  function pickGlobal(unit) {
    const options = opts(unit);
    for (const [group, tagPrefix] of [["power", "p:"], ["energy", "e:"]]) {
      const wanted = global[group];
      if (wanted === "default") continue;
      const hit = options.find(o => o.tag === tagPrefix + wanted) || (tagPrefix === "p:" && wanted === "kW" ? null : null);
      if (hit && options.some(o => o.tag?.startsWith(tagPrefix))) return hit.label;
    }
    return canonOption(unit).label;
  }

  function paintTitle(input) {
    const label = input.closest("label");
    if (!label || !input.dataset.unitTitle || !label.firstChild || label.firstChild.nodeType !== 3) return;
    const text = input.dataset.unitTitle.replace(input.dataset.unitCanon.replace(/ .*/, ""), current(input).replace(/ .*/, ""));
    label.firstChild.textContent = isMoney(input.dataset.unitCanon) && window.currencyUi ? currencyUi.label(text) : text;
  }
  function applyBounds(input) {
    const unit = input.dataset.unitCanon, f = find(unit, current(input)).f / canonOption(unit).f;
    for (const [attr, key] of [["min", "unitMin"], ["max", "unitMax"]])
      if (input.dataset[key] !== undefined && input.dataset[key] !== "") input[attr] = clean(Number(input.dataset[key]) * fxOf(unit) / f);
  }
  const shownLabel = (unit, text) => isMoney(unit) && window.currencyUi ? currencyUi.label(text) : text;
  function paintOptions(input) {
    const select = input.parentElement?.querySelector(`select.unit-select[data-for="${input.dataset.unitId}"]`);
    if (select) for (const o of select.options) o.textContent = shownLabel(input.dataset.unitCanon, o.value);
  }
  function setLabel(input, label, convertValue) {
    const unit = input.dataset.unitCanon, from = current(input);
    if (!find(unit, label)) return;
    if (convertValue && input.value !== "") input.value = convert(input.valueAsNumber, unit, from, label);
    input.dataset.unitLabel = label;
    applyBounds(input);
    const select = input.parentElement?.querySelector(`select.unit-select[data-for="${input.dataset.unitId}"]`);
    if (select) { select.value = label; select.classList.toggle("unit-changed", label !== canonOption(unit).label); }
    paintTitle(input);
  }
  // Re-express money inputs after the currency or rate changed. rebase = keep the typed numbers (rate correction).
  function syncMoney(rebase) {
    const now = window.currencyUi ? currencyUi.fx() : 1;
    for (const input of all()) {
      if (!isMoney(input.dataset.unitCanon)) continue;
      const was = Number(input.dataset.unitFx || 1);
      if (was !== now && !rebase && input.value !== "" && Number.isFinite(input.valueAsNumber)) input.value = clean(input.valueAsNumber * now / was);
      input.dataset.unitFx = now;
      applyBounds(input); paintOptions(input); paintTitle(input);
    }
  }
  let counter = 0;
  function attach(input, unit, host, mode) {
    if (!SPECS[unit] || input.dataset.unitCanon) return null;
    input.dataset.unitCanon = unit; input.dataset.unitId = "u" + (++counter);
    input.dataset.unitMin = input.min ?? ""; input.dataset.unitMax = input.max ?? "";
    const select = document.createElement("select");
    select.className = "unit-select"; select.dataset.for = input.dataset.unitId;
    select.title = "Display unit. The model always stores and solves in " + canonOption(unit).label + "; this only changes how the number is shown and entered.";
    select.setAttribute("aria-label", "Display unit");
    for (const o of opts(unit)) { const e = document.createElement("option"); e.value = o.label; e.textContent = shownLabel(unit, o.label); select.append(e); }
    select.value = canonOption(unit).label;
    input.dataset.unitFx = isMoney(unit) && window.currencyUi ? currencyUi.fx() : 1;
    select.addEventListener("change", () => {
      input.dataset.unitExplicit = "1";
      setLabel(input, select.value, true); input.dispatchEvent(new Event("input", {bubbles: true}));
    });
    if (mode === "replace") host.replaceWith(select); else input.after(select);
    const label = input.closest("label");
    if (label?.firstChild?.nodeType === 3) input.dataset.unitTitle = label.firstChild.textContent;
    const preferred = suppress ? canonOption(unit).label : pickGlobal(unit);
    if (preferred !== canonOption(unit).label) setLabel(input, preferred, true);
    return select;
  }
  const decorateField = (f, input, unitSpan) => f.kind === "number" ? attach(input, f.unit, unitSpan, "replace") : null;
  const decorateRow = (key, input) => ROW_UNITS[key] ? attach(input, ROW_UNITS[key], null, "after") : null;

  // Canonical value of an input (works for plain inputs too).
  function canonical(target) {
    const input = typeof target === "string" ? document.getElementById(target) : target;
    if (!input) return NaN;
    const v = input.valueAsNumber;
    return input.dataset.unitCanon ? toCanonical(v, input.dataset.unitCanon, current(input)) : v;
  }
  function setCanonical(target, value) {
    const input = typeof target === "string" ? document.getElementById(target) : target;
    if (!input) return;
    input.value = input.dataset.unitCanon && Number.isFinite(Number(value)) ? fromCanonical(Number(value), input.dataset.unitCanon, current(input)) : value;
  }
  // Put every dropdown back on its canonical unit without touching the numbers (caller writes canonical values next).
  function resetAll(keepGlobal) {
    for (const input of all()) {
      const canon = canonOption(input.dataset.unitCanon).label;
      delete input.dataset.unitExplicit;
      if (isMoney(input.dataset.unitCanon)) input.dataset.unitFx = 1;
      setLabel(input, canon, false);
    }
  }
  function resetToDefault() {
    for (const input of all()) {
      delete input.dataset.unitExplicit;
      if (current(input) !== canonOption(input.dataset.unitCanon).label) setLabel(input, canonOption(input.dataset.unitCanon).label, true);
    }
    setGlobal({power: "default", energy: "default"}, false);
    changed();
  }
  // Push the global default onto every field, including the ones the user set explicitly.
  function applyToAll() {
    for (const input of all()) { delete input.dataset.unitExplicit; setLabel(input, pickGlobal(input.dataset.unitCanon), true); }
    changed();
  }
  const changed = () => { if (typeof edited === "function") edited(); };

  function snapshot() {
    const fields = {}, rows = {};
    for (const input of all()) {
      const label = current(input);
      if (label === canonOption(input.dataset.unitCanon).label) continue;
      const row = input.dataset.key ? input.closest("#milestone-rows,#planned-rows,#existing-rows") : null;
      if (row) {
        const idx = [...row.children].indexOf(input.closest(".input-row"));
        (rows[row.id] ||= {})[idx] = {...(rows[row.id][idx] || {}), [input.dataset.key]: label};
      } else if (input.id) fields[input.id] = label;
    }
    return {global: {...global}, fields, rows, explicit: all().filter(i => i.id && i.dataset.unitExplicit).map(i => i.id)};
  }
  // Called after canonical values were written into the form.
  let suppress = false;
  const begin = () => { suppress = true; resetAll(); };
  function restore(state) {
    suppress = false;
    resetAll();
    syncMoney(false);
    window.currencyUi?.refreshHint();
    if (!state) return;
    if (state.global) setGlobal(state.global, false);
    for (const [key, label] of Object.entries(state.fields || {})) {
      const input = document.getElementById(key);
      if (input?.dataset.unitCanon) {
        setLabel(input, label, true);
        // Older drafts have no explicit list: a saved non-default unit counts as the user's choice.
        if (!state.explicit || state.explicit.includes(key)) input.dataset.unitExplicit = "1";
      }
    }
    for (const [id, rows] of Object.entries(state.rows || {})) {
      const host = document.getElementById(id);
      for (const [idx, map] of Object.entries(rows)) {
        const card = host?.children[Number(idx)];
        for (const [key, label] of Object.entries(map))
          { const input = card?.querySelector(`[data-key="${key}"]`); if (input?.dataset.unitCanon) setLabel(input, label, true); }
      }
    }
  }

  /* ---- global display units (inputs + result presentation) ---- */
  function setGlobal(next, applyToInputs) {
    global = {power: next.power || "default", energy: next.energy || "default"};
    try { localStorage.setItem(GLOBAL_KEY, JSON.stringify(global)); } catch (e) { /* ignore */ }
    for (const [id, v] of [["units-power", global.power], ["units-energy", global.energy]]) { const s = document.getElementById(id); if (s) s.value = v; }
    if (applyToInputs) for (const input of all()) if (!input.dataset.unitExplicit) setLabel(input, pickGlobal(input.dataset.unitCanon), true);
    window.dispatchEvent(new Event("units-changed"));
  }
  const showKw = () => global.power === "kW", showKwh = () => global.energy === "kWh";
  const pref = () => ({power: showKw() ? "kW" : "MW", energy: showKwh() ? "kWh" : "MWh"});
  const MW_TOKEN = /(^|[\s(\/])MW(?=$|[\s)\/,]|AC)/, MWH_TOKEN = /(^|[\s(\/])MWh(?=$|[\s)\/,])/;
  // A text label that names a power or energy unit -> factor to apply to its numbers and the relabelled text.
  function adaptName(name) {
    const base = adaptEnergyPower(name);
    if (window.currencyUi && !currencyUi.isUsd() && base.text.includes("$"))
      return {text: currencyUi.label(base.text), factor: base.factor * currencyUi.fx()};
    return base;
  }
  function adaptEnergyPower(name) {
    const text = String(name);
    if (/\$\/MWh|\$\/MW\b/.test(text)) {
      if (showKwh() && /\$\/MWh/.test(text)) return {text: text.replace("$/MWh", "$/kWh"), factor: 1e-3};
      if (showKw() && /\$\/MW\b/.test(text)) return {text: text.replace("$/MW", "$/kW"), factor: 1e-3};
      return {text, factor: 1};
    }
    if (showKwh() && MWH_TOKEN.test(text)) return {text: text.replace(MWH_TOKEN, "$1kWh"), factor: 1e3};
    if (showKw() && MW_TOKEN.test(text) && !/\bMWh\b/.test(text)) return {text: text.replace(MW_TOKEN, "$1kW"), factor: 1e3};
    return {text, factor: 1};
  }
  // Table helper: returns {columns, factors}; numeric cells of column i are multiplied by factors[i].
  function adaptColumns(columns) {
    const adapted = columns.map(adaptName);
    return {columns: adapted.map(a => a.text), factors: adapted.map(a => a.factor)};
  }
  function unitOfChart(unit) { return /^MWh(\/yr)?$/.test(unit || "") ? {from: "MWh", to: "kWh"} : /^MW( AC)?$/.test(unit || "") ? {from: "MW", to: "kW"} : null; }
  // Chart helper: returns an adapted copy of a chart spec (axis, labels, values) honouring the display unit.
  function adaptChart(spec) {
    const money = !!(window.currencyUi && !currencyUi.isUsd() && /\$/.test(spec?.unit || ""));
    const u = unitOfChart(spec?.unit);
    if (money) {
      const L = t => typeof t === "string" ? currencyUi.label(t) : t, fx = spec.currencyScaled ? 1 : currencyUi.fx();
      const scaleM = list => (list || []).map(s => ({...s, label: L(s.label), values: s.values.map(v => typeof v === "number" ? clean(v * fx) : v)}));
      const next = {...spec, unit: L(spec.unit), series: scaleM(spec.series), title: L(spec.title), subtitle: L(spec.subtitle), yTitle: L(spec.yTitle),
        xTitle: L(spec.xTitle), catTitle: L(spec.catTitle), valueTitle: L(spec.valueTitle)};
      if (spec.lines) next.lines = scaleM(spec.lines);
      return next;
    }
    if (!u || (u.from === "MW" ? !showKw() : !showKwh())) return spec;
    const swap = t => typeof t === "string" ? t.replace(u.from === "MW" ? /\bMW\b/g : /\bMWh\b/g, u.to) : t;
    const scale = list => (list || []).map(s => ({...s, label: swap(s.label), values: s.values.map(v => typeof v === "number" ? clean(v * 1e3) : v)}));
    const next = {...spec, unit: spec.unit.replace(u.from, u.to), series: scale(spec.series), yTitle: swap(spec.yTitle), xTitle: swap(spec.xTitle),
      catTitle: swap(spec.catTitle), valueTitle: swap(spec.valueTitle)};
    if (spec.lines) next.lines = scale(spec.lines);
    if (spec.band) next.band = spec.band;
    return next;
  }
  // Format an energy / power number for text (value given in MWh / MW).
  const fixed = (v, d) => Number(v).toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: d});
  const mw = (v, d = 3) => showKw() ? fixed(v * 1e3, Math.max(0, d - 3)) + " kW" : fixed(v, d) + " MW";
  const mwh = (v, d = 2) => showKwh() ? fixed(v * 1e3, Math.max(0, d - 3)) + " kWh" : fixed(v, d) + " MWh";
  const label = {power: () => showKw() ? "kW" : "MW", energy: () => showKwh() ? "kWh" : "MWh"};
  const scalePower = v => showKw() ? v * 1e3 : v, scaleEnergy = v => showKwh() ? v * 1e3 : v;

  function buildControl() {
    const host = document.querySelector("header .badges");
    if (!host || document.getElementById("units-control")) return;
    const wrap = document.createElement("span");
    wrap.id = "units-control"; wrap.className = "units-control";
    const make = (id, text, choices) => {
      const label = document.createElement("label"); label.textContent = text + " ";
      const select = document.createElement("select"); select.id = id; select.className = "unit-select";
      for (const [value, name] of choices) { const o = document.createElement("option"); o.value = value; o.textContent = name; select.append(o); }
      label.append(select); return [label, select];
    };
    const title = document.createElement("strong"); title.textContent = "Display units";
    const HINT = "The Power and Energy settings are the default display unit for every field and result. A unit you pick on an individual field stays " +
      "(field choice wins over this default). 'Apply to all fields' pushes the default onto every field; 'Reset units' returns all fields to the model units. " +
      "The model always works in canonical units (MW, MWh, $/MW...).";
    wrap.title = HINT; title.title = HINT;
    const [pl, ps] = make("units-power", "Power", [["default", "As defined"], ["kW", "kW"], ["MW", "MW"]]);
    const [el, es] = make("units-energy", "Energy", [["default", "As defined"], ["kWh", "kWh"], ["MWh", "MWh"]]);
    const apply = document.createElement("button"); apply.type = "button"; apply.className = "secondary"; apply.id = "units-apply-all"; apply.textContent = "Apply to all fields";
    apply.title = "Set every field to the Power / Energy default above, replacing units chosen on individual fields.";
    apply.addEventListener("click", applyToAll);
    const reset = document.createElement("button"); reset.type = "button"; reset.className = "secondary"; reset.id = "units-reset"; reset.textContent = "Reset units";
    reset.title = "Return every field and the defaults to the model units.";
    reset.addEventListener("click", resetToDefault);
    const onchange = () => { setGlobal({power: ps.value, energy: es.value}, true); changed(); };
    ps.addEventListener("change", onchange); es.addEventListener("change", onchange);
    ps.value = global.power; es.value = global.energy;
    wrap.append(title, pl, el, apply, reset); host.append(wrap);
  }
  const init = () => { buildControl(); if (global.power !== "default" || global.energy !== "default") window.dispatchEvent(new Event("units-changed")); };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", buildControl); else buildControl();

  // Re-render the cached results so tables and charts honour a changed display unit.
  window.addEventListener("units-changed", () => {
    try {
      if (typeof workflowStatuses !== "undefined" && typeof currentRun !== "undefined" && workflowStatuses[currentRun]) renderStatus(workflowStatuses[currentRun]);
    } catch (e) { /* results not ready yet */ }
  });

  return {SPECS, ROW_UNITS, convert, toCanonical, fromCanonical, canonical, setCanonical, decorateField, decorateRow, attach, syncMoney, applyToAll,
    snapshot, begin, restore, resetAll, resetToDefault, setGlobal, global: () => ({...global}), pref, adaptName, adaptColumns, adaptChart,
    mw, mwh, label, scalePower, scaleEnergy, clean, current};
})();
window.unitsUi = unitsUi;
