"use strict";
// Executive decision dashboard on the Result Summary page. All numbers arrive pre-formatted from
// GET /api/x/summary_dashboard (summary_data.py), so the page matches the Summary PDF exactly.
const summaryDashboard = (() => {
  let requested = 0;

  function open(analysis) {
    if (analysis.key === "technical") switchView("powerflow");
    else {
      switchView("analyze");
      analysisTabs.show(analysis.pane);
    }
  }

  function chip(text, level) {
    return node("span", text, "badge " + (level === "pass" ? "ok" : level));
  }

  function section(title, hint) {
    const block = node("section", undefined, "sd-block");
    block.append(node("h3", title));
    if (hint) block.append(node("p", hint, "muted"));
    return block;
  }

  function recommendation(data) {
    const rec = data.recommended;
    const block = node("section", undefined, "sd-hero");
    const head = node("div", undefined, "sd-hero-head");
    head.append(node("span", rec.is_reference ? "Best option is the reference" : "Recommended option", "sd-eyebrow"),
      node("h3", `${rec.code} - ${rec.name}`));
    const meta = node("p", undefined, "sd-hero-meta");
    meta.append(node("span", rec.rank ? `Rank ${rec.rank} of ${rec.count} by total NPC` : "Not ranked", "badge best"),
      node("span", `NPC ${rec.npc}`, "badge"), node("span", rec.mix, "sd-mix"));
    head.append(meta);
    block.append(head);
    const why = node("div", undefined, "sd-why");
    why.append(node("h4", "Why this option"));
    const list = node("ul");
    for (const line of rec.why) list.append(node("li", line));
    why.append(list);
    block.append(why);
    return block;
  }

  function kpis(data) {
    const grid = node("div", undefined, "sd-kpis");
    for (const kpi of data.kpis) {
      const card = node("div", undefined, "sd-kpi" + (kpi.level ? " " + kpi.level : ""));
      card.dataset.kpi = kpi.key;
      card.append(node("span", kpi.label, "sd-kpi-label"), node("strong", kpi.value, "sd-kpi-value"),
        node("span", kpi.note, "sd-kpi-note"));
      grid.append(card);
    }
    return grid;
  }

  function analyses(data) {
    const block = section("Analyses", "One line per analysis. Ranking is by total NPC; the technical result is a remark and corrections are applied afterwards.");
    const list = node("div", undefined, "sd-analyses");
    for (const analysis of data.analyses) {
      const row = node("div", undefined, "sd-analysis");
      row.dataset.analysis = analysis.key;
      row.append(chip(analysis.state === "done" ? (analysis.level === "info" ? "Done" : analysis.level.toUpperCase()) : "Not run", analysis.state === "done" ? analysis.level : "none"));
      const text = node("div", undefined, "sd-analysis-text");
      text.append(node("strong", analysis.label), node("span", analysis.headline), node("small", analysis.detail, "muted"));
      row.append(text);
      const button = node("button", analysis.state === "done" ? "Open" : analysis.action, analysis.state === "done" ? "secondary" : "");
      button.type = "button";
      button.onclick = () => open(analysis);
      row.append(button);
      list.append(row);
    }
    block.append(list);
    return block;
  }

  // Dashboard numbers are converted on the server using the currency saved with the run.
  let sym = "$";
  const cs = t => t.replace(/\$/g, sym);
  function money(v, d = 2) { return `${v < 0 ? "−" : ""}${sym}${GS.fmt(Math.abs(v), d)}M`; }

  function detailBlock(title, lines, charts) {
    const block = section(title);
    if (!lines.length) { block.append(node("p", "Not run for this study. Use the Open/Run button above.", "muted")); return block; }
    const list = node("ul");
    for (const line of lines) list.append(node("li", line));
    block.append(list);
    const grid = node("div", undefined, "gs-grid");
    for (const c of charts) if (c) grid.append(c.el);
    block.append(grid);
    return block;
  }

  function economicDetail(data) {
    const rows = data.detail.economic.rows;
    if (!rows.length) return detailBlock("Economic analysis", [], []);
    const best = rows.find(r => r.recommended) || rows[0];
    const lines = [`${best.name} has the lowest total NPC among the options that serve all load: ${money(best.npc)} (upfront ${money(best.upfront)}).`];
    if (best.npv !== null) lines.push(`NPV against ${data.detail.economic.basis || "the reference"}: ${money(best.npv)}.`);
    for (const kpi of data.kpis.filter(k => ["npv", "npv_op"].includes(k.key))) lines.push(`${kpi.label}: ${kpi.value}; ${kpi.note}.`);
    const cats = rows.map(r => ({key: r.code, label: r.code, color: GS.scenarioColor(r.code), notes: [r.name]}));
    const npc = GS.chart({kind: "bars", valueLabels: true, title: "Net present cost by option", filename: "summary_npc", subtitle: "Lowest total NPC ranks first.",
      yTitle: cs("NPC ($ million)"), unit: cs("$ M"), currencyScaled: true, catTitle: "Scenario", categories: cats, height: 320, vFmt: v => GS.fmt(v, 2),
      series: [{key: "npc", label: "NPC", color: "#2F6DB5", values: rows.map(r => r.npc)}]});
    const up = GS.chart({kind: "bars", valueLabels: true, title: "Upfront investment by option", filename: "summary_upfront", subtitle: "Equipment plus any grid upgrade at year 0.",
      yTitle: cs("Upfront ($ million)"), unit: cs("$ M"), currencyScaled: true, catTitle: "Scenario", categories: cats, height: 320, vFmt: v => GS.fmt(v, 2),
      series: [{key: "upfront", label: "Upfront", color: "#E08A1E", values: rows.map(r => r.upfront)}]});
    return detailBlock("Economic analysis", lines, [npc, up]);
  }

  function sensitivityDetail(data) {
    const s = data.detail.sensitivity;
    if (!s) return detailBlock("Sensitivity analysis", [], []);
    const top = s.swings[0], risk = s.risk || {};
    const lines = [`Run on ${s.scenario}; base NPC ${money(s.base_npc)}.`,
      `Largest driver: ${top.label.replace(" *", "")} (${top.range}) moves NPC from ${money(top.low, 2)} to ${money(top.high, 2)} versus base.`];
    if (risk.p50 !== undefined && risk.p50 !== null) lines.push(`Probabilistic NPC: P50 ${money(risk.p50 / 1e6)}, P10 ${money(risk.p10 / 1e6)}, P90 ${money(risk.p90 / 1e6)}.`);
    if (s.swings.some(x => x.label.endsWith("*"))) lines.push("* The best equipment mix changes inside that parameter's range.");
    const chart = GS.chart({kind: "bars", horizontal: true, valueLabels: true, title: "Tornado: change in NPC versus base", filename: "summary_tornado",
      subtitle: `${s.scenario}; bars to the left lower the NPC, to the right raise it.`, xTitle: cs("Change in NPC ($ million)"), unit: cs("$ M"), currencyScaled: true, catTitle: "Parameter",
      height: 170 + 40 * s.swings.length, categories: s.swings.map(x => ({key: x.label, label: x.label, notes: [`Tested range: ${x.range}`]})),
      series: [{key: "low", label: "Low value", color: "#2F6DB5", values: s.swings.map(x => x.low)},
        {key: "high", label: "High value", color: "#E08A1E", values: s.swings.map(x => x.high)}], vFmt: v => GS.fmt(v, 2), refLines: [{value: 0, color: "#173441"}]});
    return detailBlock("Sensitivity analysis", lines, [chart]);
  }

  function reliabilityDetail(data) {
    const rows = data.detail.reliability;
    if (!rows.length) return detailBlock("Reliability analysis", [], []);
    const lines = rows.map(r => `${r.code}: LOLE ${GS.fmt(r.lole, 2)} h/yr, EENS ${GS.fmt(r.eens, 1)} MWh/yr, outage cost ${money(r.cost, 3)}/yr`
      + (r.verdict ? ` (${r.verdict})` : "") + (r.best_measure ? `; best measure: ${r.best_measure}` : "") + ".");
    const cats = rows.map(r => ({key: r.code, label: r.code, color: GS.scenarioColor(r.code), notes: [r.name]}));
    const one = (key, title, y, unit, color, field) => GS.chart({kind: "bars", valueLabels: true, title, filename: "summary_" + key, yTitle: y, unit, catTitle: "Scenario",
      categories: cats, height: 300, currencyScaled: true, vFmt: v => GS.fmt(v, 3), series: [{key, label: title, color, values: rows.map(r => r[field])}]});
    return detailBlock("Reliability analysis", lines, [one("lole", "Loss-of-load hours per year", "Hours per year", "h/yr", "#E08A1E", "lole"),
      one("eens", "Expected unserved energy", "MWh per year", "MWh/yr", "#8E6BBF", "eens"),
      one("cost", "Expected outage cost", cs("$ million per year"), cs("$ M/yr"), "#C0392B", "cost")]);
  }

  function comparison(data) {
    const block = section("Options compared", `Reference: ${data.reference.name || "none"}${data.reference.npc ? " (NPC " + data.reference.npc + ")" : ""}. Lowest total NPC ranks first.`);
    const wrap = node("div", undefined, "table-scroll");
    const table = node("table", undefined, "sd-table");
    const columns = ["Rank", "Option", "Equipment", "NPC", ...(data.show_adjusted ? ["Total NPC with corrections"] : []),
      "NPC vs reference", "Upfront", "NPV (net)", "Unserved", "Technical", "Status"];
    const head = node("tr");
    for (const name of columns) head.append(node("th", name));
    const thead = node("thead");
    thead.append(head);
    table.append(thead);
    const body = node("tbody");
    for (const row of data.table) {
      const tr = node("tr", undefined, row.recommended ? "sd-best" : "");
      const technical = node("td");
      technical.append(chip(row.technical, row.technical_level));
      tr.append(node("td", row.rank ?? "-"), node("td", `${row.code} - ${row.name}`), node("td", row.mix), node("td", row.npc));
      if (data.show_adjusted) tr.append(node("td", row.adjusted));
      tr.append(node("td", row.versus), node("td", row.upfront), node("td", row.npv), node("td", row.unserved), technical, node("td", row.status));
      body.append(tr);
    }
    table.append(body);
    wrap.append(table);
    block.append(wrap);
    return block;
  }

  function notes(data) {
    const grid = node("div", undefined, "sd-two");
    const warnings = section("Warnings and remarks");
    if (!data.warnings.length) warnings.append(node("p", "No warnings.", "muted"));
    else {
      const list = node("ul", undefined, "sd-warnings");
      for (const item of data.warnings) {
        const li = node("li", undefined, "sd-" + item.level);
        li.append(chip(item.level === "fail" ? "Action" : item.level === "warn" ? "Caution" : "Note", item.level), node("span", " " + item.text));
        list.append(li);
      }
      warnings.append(list);
    }
    const assumptions = section("Key assumptions");
    const table = node("table", undefined, "sd-table sd-assumptions");
    const body = node("tbody");
    for (const [name, value] of data.assumptions) {
      const tr = node("tr");
      tr.append(node("th", name), node("td", value));
      body.append(tr);
    }
    table.append(body);
    assumptions.append(table);
    grid.append(warnings, assumptions);
    return grid;
  }

  async function show(run) {
    const host = byId("summary-dashboard");
    if (!host) return;
    const ticket = ++requested;
    if (!run) { host.replaceChildren(); return; }
    try {
      const data = await fetchJson(`/api/x/summary_dashboard?run_id=${encodeURIComponent(run)}`);
      if (ticket !== requested) return;
      sym = data.currency || "$";
      host.replaceChildren(recommendation(data), kpis(data), analyses(data), comparison(data), economicDetail(data), sensitivityDetail(data),
        reliabilityDetail(data), notes(data));
    } catch (error) {
      if (ticket !== requested) return;
      host.replaceChildren(node("p", `Executive summary unavailable: ${error.message}`, "notice"));
    }
  }

  return {show};
})();
window.summaryDashboard = summaryDashboard;
