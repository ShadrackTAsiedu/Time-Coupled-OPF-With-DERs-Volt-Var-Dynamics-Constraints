"use strict";
// PSS/E-style component properties dialog and global power-flow settings, shared by the Topology and Power Flow pages.
// Values are stored in the scenario drawing (node/line `electrical`, diagram `pf_settings`); blank = not set (assumed value is used).
const pfProps = (() => {
  const $ = id => document.getElementById(id);
  const h = (tag, text, cls) => {
    const e = document.createElement(tag);
    if (text !== undefined) e.textContent = text;
    if (cls) e.className = cls;
    return e;
  };
  const r4 = v => (v === null || v === undefined || v === "" || !Number.isFinite(Number(v))) ? "" : String(Math.round(Number(v) * 10000) / 10000);
  const GEN = ["pv", "bess", "wind", "ng", "ng_chp", "h2", "h2_chp", "diesel", "biogas", "biomass"];
  const names = {};
  let dialog = null, opener = null, ctx = null;

  // [electrical key, label, unit, type, describe key (resolved/assumed value)]
  const BUS = [["bus_number", "Bus number", "", "int", "num"], ["bus_name", "Bus name (max 12 chars)", "", "text", "name"],
    ["kv", "Base voltage", "kV", "num", "kv"], ["bus_type", "Bus type", "", ["pq", "pv", "swing"], null],
    ["area", "Area", "", "int", null], ["zone", "Zone", "", "int", null],
    ["vmin_pu", "Vmin normal", "pu", "num", "vmin_pu"], ["vmax_pu", "Vmax normal", "pu", "num", "vmax_pu"],
    ["vmin_emerg_pu", "Vmin emergency (N-1)", "pu", "num", "vmin_emerg_pu"], ["vmax_emerg_pu", "Vmax emergency (N-1)", "pu", "num", "vmax_emerg_pu"]];
  const GRID = [["sc_mva", "Short-circuit level", "MVA", "num", "sc_mva"], ["xr", "X/R ratio", "", "num", "xr"],
    ["vset", "Voltage setpoint", "pu", "num", "vset"]];
  const MACHINE = [["cap_mw", "Rating (from model; override optional)", "MW", "num", "cap"], ["pmin_mw", "Pmin", "MW", "num", "pmin"],
    ["pmax_mw", "Pmax", "MW", "num", "pmax"], ["q_min_mvar", "Qmin", "Mvar", "num", "q_min"], ["q_max_mvar", "Qmax", "Mvar", "num", "q_max"],
    ["vset", "Voltage setpoint", "pu", "num", "vset"], ["control", "Reactive control", "", ["pf", "voltage", "q"], "control"],
    ["pf", "Set-point pf (only when control = pf; default = operating pf)", "", "num", "pf"], ["pf_mode", "Set-point direction", "", ["lag", "lead"], "pf_mode"],
    ["rated_pf", "Operating power factor (unit rating; lagging)", "pf", "num", "rated_pf"], ["rated_pf_lead", "Leading power factor limit", "pf", "num", "rated_pf_lead"],
    ["mbase_mva", "MBASE (blank = MW / operating pf)", "MVA", "num", "rated_mva"], ["xd2_pu", "X''d (subtransient)", "pu", "num", "xd2"]];
  const LOAD = [["load_mw", "Load", "MW", "num", "load_mw"], ["load_mvar", "Load reactive (blank = from power factor)", "Mvar", "num", "load_mvar"],
    ["pf", "Power factor", "", "num", "pf"]];
  const SHUNT = [["shunt_mvar", "Shunt (+ capacitive)", "Mvar", "num", "shunt_mvar"], ["shunt_steps", "Switched steps", "", "int", null],
    ["shunt_step_mvar", "Mvar per step", "Mvar", "num", null]];
  const LINE = [["type", "Construction", "", ["overhead", "cable"], "type"], ["circuits", "Circuits", "", "int", "circuits"],
    ["r_ohm_km", "R", "ohm/km", "num", "r_ohm_km"], ["x_ohm_km", "X", "ohm/km", "num", "x_ohm_km"], ["b_us_km", "B", "uS/km", "num", "b_us_km"],
    ["rating_mva", "Rating", "MVA", "num", "rating_mva"], ["ampacity_a", "Ampacity", "A", "num", null]];
  const XFMR = [["mva", "Rating", "MVA", "num", "mva"], ["z_pct", "Impedance %Z", "%", "num", "z_pct"], ["xr", "X/R", "", "num", "xr"],
    ["hv_kv", "HV winding", "kV", "num", null], ["lv_kv", "LV winding", "kV", "num", null],
    ["tap", "Tap position", "pu", "num", "tap"], ["tap_min", "Tap minimum", "pu", "num", null], ["tap_max", "Tap maximum", "pu", "num", null],
    ["tap_steps", "Tap steps", "", "int", null], ["vector_group", "Vector group", "", "text", null], ["cooling", "Cooling class", "", "text", null]];
  const SETTINGS = [["vmin_pu", "Voltage minimum, normal", "pu", "vmin"], ["vmax_pu", "Voltage maximum, normal", "pu", "vmax"],
    ["vmin_emerg_pu", "Voltage minimum, emergency (N-1)", "pu", "vmin_e"], ["vmax_emerg_pu", "Voltage maximum, emergency (N-1)", "pu", "vmax_e"],
    ["thermal_limit_pct", "Loading limit", "%", "thermal_limit_pct"], ["high_loading_pct", "High-loading warning", "%", "high_loading_pct"],
    ["base_mva", "System base (RAW SBASE)", "MVA", "base_mva"], ["grid_sc_mva", "Default grid short-circuit level", "MVA", "grid_sc_mva"],
    ["grid_xr", "Default grid X/R", "", "grid_xr"], ["load_pf", "Default load power factor", "", "load_pf"]];

  function numbering(graph) {
    const out = {};
    for (const n of graph?.nodes || []) {
      const e = n.electrical || {}, c = names[n.id] || {};
      const num = e.bus_number ?? c.num, name = e.bus_name ?? c.name;
      if (num !== undefined) out[n.id] = {num, name: name || ""};
    }
    return out;
  }
  function remember(desc) {
    if (!desc) return;
    for (const n of desc.nodes || []) names[n.id] = {num: n.num, name: n.name, display: n.display};
  }

  async function post(body) {
    const response = await fetch("/api/x/powerflow", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)});
    const data = await response.json();
    if (!response.ok || data.error) throw new Error(data.error || "Power-flow request failed.");
    return data;
  }
  async function describe(code) {
    const body = {action: "solve", scenario: code, topology: topologyEditor.value(), operating: {load_mw: 0, gens: {}}};
    if (typeof solveRun !== "undefined" && solveRun && (solveSnapshot?.summary?.results || []).some(r => r.code === code)) {
      delete body.operating; body.run_id = solveRun;
    }
    return (await post(body)).assumptions;
  }

  function ensureDialog() {
    if (dialog) return dialog;
    dialog = h("div", undefined, "pfprops-backdrop");
    dialog.id = "pfprops-dialog"; dialog.hidden = true;
    dialog.addEventListener("keydown", e => {
      if (e.key === "Escape") { e.preventDefault(); close(); return; }
      if (e.key !== "Tab") return;
      const items = [...dialog.querySelectorAll("button, input, select")].filter(x => !x.disabled && !x.hidden);
      if (!items.length) return;
      const first = items[0], last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
    dialog.addEventListener("pointerdown", e => { if (e.target === dialog) close(); });
    document.body.append(dialog);
    return dialog;
  }
  function close() {
    if (!dialog) return;
    dialog.hidden = true; dialog.replaceChildren(); ctx = null;
    if (opener && document.contains(opener)) opener.focus();
  }

  function fieldRow(def, stored, resolved, tags) {
    const [key, label, unit, type] = def;
    const row = h("div", undefined, "pfprops-row");
    const id = "pfprops-" + key;
    const l = h("label", label + (unit ? ` (${unit})` : "")); l.htmlFor = id;
    let input;
    if (Array.isArray(type)) {
      input = h("select");
      input.append(new Option("(default)", ""));
      for (const o of type) input.append(new Option(o, o));
    } else {
      input = h("input");
      input.type = type === "text" ? "text" : "number";
      if (type !== "text") input.step = type === "int" ? "1" : "any";
      if (type === "text") input.maxLength = key === "bus_name" ? 12 : 24;
      if (resolved !== undefined && resolved !== null && resolved !== "") input.placeholder = type === "text" ? String(resolved) : r4(resolved);
    }
    input.id = id; input.dataset.key = key;
    if (stored !== undefined) input.value = String(stored);
    const tag = h("span", undefined, "pfprops-tag");
    const paint = () => {
      const set = input.value !== "";
      tag.textContent = set ? "user-set" : (tags && tags[key]) || (key === "cap_mw" ? "from model" : "assumed");
      tag.dataset.source = tag.textContent.replace(" ", "-");
    };
    input.addEventListener("input", paint); input.addEventListener("change", paint); paint();
    row.append(l, input, tag);
    return row;
  }

  // Accepted ranges (inclusive) per electrical key; values outside them are rejected before they reach the solver.
  const RANGE = {bus_number: [1, 999997], kv: [0.1, 1000], area: [1, 9999], zone: [1, 9999], vmin_pu: [0.5, 1.2], vmax_pu: [0.8, 1.5], vmin_emerg_pu: [0.5, 1.2],
    vmax_emerg_pu: [0.8, 1.5], sc_mva: [1, 1e6], xr: [0.01, 100], vset: [0.9, 1.1], cap_mw: [0, 1e5], pmin_mw: [0, 1e5], pmax_mw: [0, 1e5], pf: [0.1, 1], rated_pf: [0.8, 1], rated_pf_lead: [0.8, 1],
    mbase_mva: [0.01, 1e5], xd2_pu: [0.01, 2], load_mw: [0, 1e5], shunt_steps: [1, 1000], circuits: [1, 20], r_ohm_km: [0, 100], x_ohm_km: [0, 100], b_us_km: [0, 1e4],
    rating_mva: [0.01, 1e5], ampacity_a: [1, 1e5], mva: [0.01, 1e5], z_pct: [0.1, 50], hv_kv: [0.1, 1000], lv_kv: [0.1, 1000], tap: [0.5, 1.5], tap_min: [0.5, 1.5],
    tap_max: [0.5, 1.5], tap_steps: [1, 200], thermal_limit_pct: [10, 300], high_loading_pct: [10, 300], base_mva: [1, 10000], grid_sc_mva: [1, 1e6], grid_xr: [0.01, 100],
    load_pf: [0.1, 1], shunt_step_mvar: [0, 1e5]};
  const LABEL = {bus_number: "Bus number", kv: "Base voltage", pf: "Power factor", z_pct: "Impedance %Z", tap: "Tap position", xr: "X/R"};
  const range = key => RANGE[key];
  const SIGNED = new Set(["q_min_mvar", "q_max_mvar", "load_mvar", "shunt_mvar"]);

  function validate(out) {
    for (const [key, v] of Object.entries(out)) {
      if (typeof v === "string" && key === "bus_name" && v.length > 12) throw new Error("Bus name must be at most 12 characters.");
      if (typeof v !== "number" || SIGNED.has(key) || !RANGE[key]) continue;
      const [lo, hi] = RANGE[key];
      if (v < lo || v > hi) throw new Error(`${LABEL[key] || key} must be between ${lo} and ${hi}.`);
    }
    if (out.pmin_mw != null && out.pmax_mw != null && out.pmin_mw > out.pmax_mw) throw new Error("Pmin must not exceed Pmax.");
    if (out.q_min_mvar != null && out.q_max_mvar != null && out.q_min_mvar > out.q_max_mvar) throw new Error("Qmin must not exceed Qmax.");
    if (out.vmin_pu != null && out.vmax_pu != null && out.vmin_pu >= out.vmax_pu) throw new Error("Vmin must be below Vmax.");
    if (out.tap_min != null && out.tap_max != null && out.tap_min > out.tap_max) throw new Error("Tap minimum must not exceed tap maximum.");
    if (out.tap != null && out.tap_min != null && out.tap < out.tap_min) throw new Error("Tap position is below the tap minimum.");
    if (out.tap != null && out.tap_max != null && out.tap > out.tap_max) throw new Error("Tap position is above the tap maximum.");
    return out;
  }

  function collect(defs) {
    const out = {};
    for (const [key, , , type] of defs) {
      const input = $("pfprops-" + key);
      if (!input) continue;
      const raw = input.value.trim();
      if (raw === "") { out[key] = null; continue; }
      if (type === "text" || Array.isArray(type)) out[key] = raw;
      else {
        const v = Number(raw);
        if (!Number.isFinite(v)) throw new Error(`${LABEL[key] || key} must be a number.`);
        out[key] = type === "int" ? Math.round(v) : v;
      }
    }
    return validate(out);
  }

  function shell(title, subtitle) {
    const box = ensureDialog();
    box.replaceChildren();
    const card = h("div", undefined, "pfprops-card");
    card.setAttribute("role", "dialog"); card.setAttribute("aria-modal", "true"); card.setAttribute("aria-labelledby", "pfprops-title");
    const head = h("h3", title); head.id = "pfprops-title";
    card.append(head);
    if (subtitle) card.append(h("p", subtitle, "muted"));
    const err = h("p", undefined, "notice"); err.id = "pfprops-error"; err.hidden = true; err.setAttribute("role", "alert");
    card.append(err);
    box.append(card);
    box.hidden = false;
    return {card, err};
  }
  const buttons = (card, onSave, onReset) => {
    const bar = h("div", undefined, "pfprops-actions");
    const save = h("button", "OK"); save.type = "button"; save.id = "pfprops-ok";
    const reset = h("button", "Reset to assumed", "secondary"); reset.type = "button"; reset.id = "pfprops-reset";
    const cancel = h("button", "Cancel", "secondary"); cancel.type = "button"; cancel.id = "pfprops-cancel";
    save.onclick = onSave; reset.onclick = onReset; cancel.onclick = close;
    bar.append(save, reset, cancel);
    card.append(bar);
  };
  const fail = (box, e) => { box.textContent = e.message || String(e); box.hidden = false; };

  async function open(opts) {
    const {kind, id, scenario: code} = opts;
    opener = document.activeElement;
    let desc = null, problem = "";
    try {
      if (typeof pfPageEnsure === "function") await pfPageEnsure(code);
      if (!topologyEditor.hasDrawing(code)) throw new Error(`Scenario ${code} has no drawing; draw it under Inputs > Microgrid > Topology first.`);
      desc = await describe(code);
      remember(desc);
    } catch (e) { problem = e.message || String(e); }
    if (kind === "settings") return openSettings(code, desc, problem);
    const comp = topologyEditor.component(code, id);
    if (!comp) return;
    const isLine = "source" in comp;
    const info = isLine ? (desc?.branches || []).find(b => b.id === id) || {} : (desc?.nodes || []).find(n => n.id === id) || {};
    const elec = comp.electrical || {};
    let defs;
    if (isLine) defs = info.kind === "transformer" ? XFMR : info.kind === "tie" ? [XFMR[0]] : LINE;
    else if (comp.kind === "load") defs = [...LOAD, ...SHUNT, ...BUS];
    else if (comp.kind === "grid") defs = [...GRID, ...BUS];
    else if (GEN.includes(comp.kind)) defs = [...MACHINE, ...SHUNT, ...BUS];
    else defs = [...SHUNT, ...BUS];
    const {card, err} = shell(`${comp.label} - ${isLine ? "branch" : "bus"} properties`,
      isLine ? `${info.name || ""} ${info.from_id || ""} - ${info.to_id || ""}`.trim() : `${info.display || comp.label}. Leave a field blank to use the assumed value shown as a hint.`);
    if (problem) fail(err, new Error(problem + " Values shown as hints are unavailable."));
    const name = h("div", undefined, "pfprops-row");
    const nl = h("label", "Component name"); nl.htmlFor = "pfprops-label";
    const ni = h("input"); ni.id = "pfprops-label"; ni.type = "text"; ni.value = comp.label; ni.maxLength = 120;
    name.append(nl, ni); card.append(name);
    if (isLine) {
      const row = h("div", undefined, "pfprops-row");
      const ll = h("label", "Length (km)"); ll.htmlFor = "pfprops-length";
      const li = h("input"); li.id = "pfprops-length"; li.type = "number"; li.step = "any"; li.min = 0; li.value = comp.length_km;
      row.append(ll, li, h("span", "from drawing", "pfprops-tag")); card.append(row);
    }
    const grid = h("div", undefined, "pfprops-grid");
    for (const def of defs) {
      let resolved = def[4] ? info[def[4]] : undefined;
      if (def[0] === "cap_mw") resolved = info.cap;
      const stored = elec[def[0]];
      const row = fieldRow(def, stored, resolved, null);
      if (def[0] === "shunt_mvar" && elec.shunt_auto) { const tag = row.querySelector(".pfprops-tag"); tag.textContent = "Auto-sized by technical check"; tag.dataset.source = "auto-sized"; }
      grid.append(row);
    }
    {
      const row = h("div", undefined, "pfprops-row");
      const l = h("label", "In service"); l.htmlFor = "pfprops-in_service";
      const s = h("select"); s.id = "pfprops-in_service";
      s.append(new Option("(default)", ""), new Option("in service", "1"), new Option("out of service", "0"));
      s.value = elec.in_service === true ? "1" : elec.in_service === false ? "0" : "";
      row.append(l, s); grid.append(row);
    }
    card.append(grid);
    if (GEN.includes(comp.kind)) {
      const ctl = $("pfprops-control");
      const showSetpoint = () => {
        const on = (ctl.value || info.control) === "pf";
        for (const k of ["pf", "pf_mode"]) { const el = $("pfprops-" + k); if (el) el.parentElement.hidden = !on; }
      };
      ctl.addEventListener("change", showSetpoint); showSetpoint();
    }
    if (GEN.includes(comp.kind)) {
      const derived = h("p", undefined, "muted"); derived.id = "pfprops-derived";
      const refresh = () => {
        const num = key => { const el = $("pfprops-" + key); const v = el && el.value.trim() !== "" ? Number(el.value) : NaN; return v; };
        const mw = Number.isFinite(num("cap_mw")) ? num("cap_mw") : info.cap, lag = Number.isFinite(num("rated_pf")) ? num("rated_pf") : info.rated_pf;
        const lead = Number.isFinite(num("rated_pf_lead")) ? num("rated_pf_lead") : info.rated_pf_lead;
        if (!(mw > 0) || !(lag >= 0.8 && lag <= 1) || !(lead >= 0.8 && lead <= 1)) { derived.textContent = "Derived MVA / Mvar capability: enter a rating and a power factor between 0.8 and 1."; return; }
        const tan = pf => Math.tan(Math.acos(pf));
        derived.textContent = `Derived: ${mw.toFixed(2)} MW at pf ${lag} = ${(mw / lag).toFixed(2)} MVA; Qmax (lagging) ${(mw * tan(lag)).toFixed(2)} Mvar, Qmin (leading) ${(-mw * tan(lead)).toFixed(2)} Mvar. MW is the active rating at this power factor.`;
      };
      grid.addEventListener("input", refresh); refresh();
      card.append(derived);
    }
    const apply = patch => {
      const label = $("pfprops-label").value.trim();
      const out = {electrical: patch};
      if (label && label !== comp.label) out.label = label;
      if (isLine) { const len = Number($("pfprops-length").value); if (Number.isFinite(len) && len >= 0) out.length_km = len; }
      const svc = $("pfprops-in_service").value;
      patch.in_service = svc === "" ? null : svc === "1";
      if (typeof patch.shunt_mvar === "number") {
        if (elec.shunt_auto && patch.shunt_mvar === elec.shunt_mvar) patch.shunt_auto = true; else patch.shunt_user = true;
      }
      topologyEditor.updateComponent(code, id, out);
      close();
      document.dispatchEvent(new CustomEvent("pfprops-changed", {detail: {scenario: code, id}}));
    };
    buttons(card, () => { try { apply(collect(defs)); } catch (e) { fail(err, e); } },
      () => { for (const [key] of defs) { const i = $("pfprops-" + key); if (i) { i.value = ""; i.dispatchEvent(new Event("input")); } } $("pfprops-in_service").value = ""; });
    (grid.querySelector("input,select") || ni).focus();
  }

  function openSettings(code, desc, problem) {
    const {card, err} = shell(`Power-flow settings - scenario ${code}`,
      "Apply to every bus, line and source of this scenario unless a component overrides them. Blank = assumed default.");
    if (problem) fail(err, new Error(problem));
    const stored = topologyEditor.settings(code), base = desc?.base || {};
    const resolved = {vmin_pu: base.voltage_limits?.[0], vmax_pu: base.voltage_limits?.[1], vmin_emerg_pu: base.n1_voltage_limits?.[0],
      vmax_emerg_pu: base.n1_voltage_limits?.[1]};
    const grid = h("div", undefined, "pfprops-grid");
    const defs = SETTINGS.map(([key, label, unit]) => [key, label, unit, "num"]);
    for (const def of defs) {
      const key = def[0], value = resolved[key] !== undefined ? resolved[key] : base[key];
      grid.append(fieldRow(def, stored[key], value, null));
    }
    card.append(grid);
    buttons(card, () => {
      try {
        const patch = collect(defs);
        const lo = patch.vmin_pu ?? resolved.vmin_pu, hi = patch.vmax_pu ?? resolved.vmax_pu;
        if (lo >= hi) throw new Error("Voltage minimum must be below the maximum.");
        if (patch.high_loading_pct != null && patch.thermal_limit_pct != null && patch.high_loading_pct > patch.thermal_limit_pct) throw new Error("High-loading warning must not exceed the loading limit.");
        topologyEditor.setSettings(code, patch);
        close();
        document.dispatchEvent(new CustomEvent("pfprops-changed", {detail: {scenario: code, settings: true}}));
      } catch (e) { fail(err, e); }
    }, () => { for (const [key] of defs) { const i = $("pfprops-" + key); i.value = ""; i.dispatchEvent(new Event("input")); } });
    grid.querySelector("input").focus();
  }

  return {open, close, numbering, remember, describe, range};
})();
