"use strict";
/* Currency layer. The model always works in USD. The user picks a display currency and an exchange rate (units of that
   currency per 1 USD); money inputs are shown/typed in the chosen currency and converted back to USD before they leave
   the form (see units.js), and money results are presented in the chosen currency with its symbol. */
const currencyUi = (() => {
  let table = {};
  const byId = id => document.getElementById(id);
  const code = () => byId("currency_code")?.value || "USD";
  const rate = () => {
    if (code() === "USD") return 1;
    const r = Number(byId("currency_rate")?.value);
    return r > 0 && Number.isFinite(r) ? r : 1;
  };
  const isUsd = () => code() === "USD";
  const symbol = () => isUsd() ? "$" : (table[code()]?.symbol || code());
  const prefix = () => { const s = symbol(); return s + (/[A-Za-z]$/.test(s) ? " " : ""); };
  // "$M" -> "\u20acM", "$/MWh" -> "\u00a3/MWh"; text without a dollar sign is returned unchanged.
  const label = text => isUsd() || typeof text !== "string" ? text : text.replace(/\$/g, symbol());
  const fixed = (v, d) => Number(v).toLocaleString(undefined, {minimumFractionDigits: d, maximumFractionDigits: d});
  // Canonical USD amount -> text in the display currency; scale 1e6 gives "M" suffix style values.
  function money(usd, digits = 2, auto = true) {
    if (usd === null || usd === undefined || !Number.isFinite(Number(usd))) return "-";
    const v = Number(usd) * rate(), sign = v < 0 ? "-" : "", a = Math.abs(v);
    if (auto && a >= 1e6) return `${sign}${prefix()}${fixed(a / 1e6, digits)}M`;
    return `${sign}${prefix()}${fixed(a, auto ? 0 : digits)}`;
  }
  // Millions of canonical USD -> millions of the display currency (number).
  const mega = usdMillions => usdMillions === null || usdMillions === undefined ? usdMillions : usdMillions * rate();
  const scaled = usd => usd === null || usd === undefined ? usd : usd * rate();
  const statement = () => isUsd() ? "" :
    `Money shown in ${table[code()]?.name || code()} (${code()}) at ${rate()} ${code()} per 1 USD (the model solves in USD).`;

  function refreshHint() {
    const field = byId("currency_rate");
    if (!field) return;
    field.readOnly = isUsd();
    const note = table[code()] ? "Indicative rate, update before use. " : "";
    field.title = (isUsd() ? "USD is the model currency: the rate is fixed at 1. " : note) +
      "Money inputs are shown and typed in the chosen currency and converted to USD at this rate when sent to the model. " +
      "Changing the currency converts the numbers shown (the USD value stays the same); editing the rate afterwards keeps the numbers you typed.";
    byId("currency_code")?.setAttribute("title", "Currency for all money inputs and results. The optimizer always works in USD.");
  }
  function onCurrencyChange() {
    const entry = table[code()];
    const r = byId("currency_rate");
    if (r) r.value = isUsd() ? 1 : (entry?.rate ?? 1);
    refreshHint();
    if (window.unitsUi) unitsUi.syncMoney(false);
    window.dispatchEvent(new Event("units-changed"));
    if (typeof edited === "function") edited();
  }
  function onRateInput() {
    if (window.unitsUi) unitsUi.syncMoney(true);
    window.dispatchEvent(new Event("units-changed"));
  }
  document.addEventListener("change", event => { if (event.target?.id === "currency_code") onCurrencyChange(); });
  document.addEventListener("input", event => { if (event.target?.id === "currency_rate") onRateInput(); });

  fetch("/api/x/currencies").then(r => r.ok ? r.json() : null).then(data => {
    if (!data) return;
    table = Object.fromEntries((data.currencies || []).map(c => [c.code, c]));
    refreshHint();
    if (window.unitsUi) unitsUi.syncMoney(true);
    if (!isUsd()) window.dispatchEvent(new Event("units-changed"));
  }).catch(() => { /* offline or route missing: USD only behaviour */ });

  // Move the currency and rate fields next to the Power / Energy selectors in the header (ids and listeners are kept).
  function dock() {
    const host = byId("units-control"), codeInput = byId("currency_code"), rateInput = byId("currency_rate");
    if (!host || !codeInput || !rateInput || host.contains(codeInput)) return host?.contains(codeInput) || false;
    const codeLabel = codeInput.closest("label"), rateLabel = rateInput.closest("label");
    if (!codeLabel || !rateLabel) return false;
    const hints = [...codeLabel.querySelectorAll("small.hint"), ...rateLabel.querySelectorAll("small.hint"), ...rateLabel.querySelectorAll("span.unit")];
    hints.forEach(h => h.remove());
    codeLabel.firstElementChild.textContent = "Currency";
    rateLabel.firstElementChild.textContent = "1 USD =";
    codeInput.classList.add("unit-select", "currency-select");
    rateInput.classList.add("currency-rate");
    const anchor = byId("units-apply-all");
    host.insertBefore(codeLabel, anchor); host.insertBefore(rateLabel, anchor);
    refreshHint();
    return true;
  }
  const watcher = new MutationObserver(() => { if (dock()) watcher.disconnect(); });
  watcher.observe(document.body, {childList: true, subtree: true});
  dock();

  new MutationObserver(refreshHint).observe(document.body, {attributes: true, attributeFilter: ["data-ready"]});

  return {code, rate, fx: rate, isUsd, symbol, prefix, label, money, mega, scaled, statement, refreshHint, table: () => table};
})();
  window.currencyUi = currencyUi;
