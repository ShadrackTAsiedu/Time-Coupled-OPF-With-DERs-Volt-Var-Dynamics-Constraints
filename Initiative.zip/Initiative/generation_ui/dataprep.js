"use strict";
// Automatic data-integrity check for uploaded CSVs. dataPrep.review(kind, files) resolves to
// {files:[...]} (cleaned or original) or null when the user cancels. It is silent when the data are already fine.
const dataPrep = (() => {
  const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
  const fmt = v => v == null ? "—" : Number(v).toLocaleString(undefined, {maximumFractionDigits: 3});
  const LABELS = {load: "load profile", solar: "solar resource", wind: "wind resource", thermal: "thermal load"};
  const CHANGING = new Set(["bad_timestamps", "bad_values", "timezone", "trim", "clipping"]);

  async function request(kind, files, options) {
    const response = await fetch("/api/prepare", {method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({kind, files, options})});
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Cleaning failed.");
    return data;
  }
  function needsReview(report, kind) {
    if (report.repaired_hours > 0 || report.notes.some(n => n.level === "warning")) return true;
    if (report.steps.some(s => CHANGING.has(s.id) && s.count > 0)) return true;
    if (kind === "load") return report.original_ok === false;
    const f = report.files[0];
    return f.value_column !== report.column || f.timestamp_columns.join() !== "timestamp";
  }
  function chart(daily) {
    const w = 720, h = 190, pad = 36;
    const vals = daily.flatMap(d => [d.before, d.after]).filter(v => v != null);
    const lo = Math.min(...vals), hi = Math.max(...vals), span = hi - lo || 1;
    const x = i => pad + (w - 2 * pad) * i / Math.max(1, daily.length - 1);
    const y = v => h - pad - (h - 2 * pad) * (v - lo) / span;
    const path = key => {
      let d = "", pen = false;
      daily.forEach((p, i) => { if (p[key] == null) { pen = false; return; } d += (pen ? "L" : "M") + x(i).toFixed(1) + " " + y(p[key]).toFixed(1); pen = true; });
      return d;
    };
    return `<svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}" role="img" aria-label="Daily mean before and after cleaning">
      <path d="${path("before")}" fill="none" stroke="#d98a00" stroke-width="1.5"/><path d="${path("after")}" fill="none" stroke="#1565c0" stroke-width="1.5"/>
      <text x="${pad}" y="14" font-size="11" fill="#d98a00">Before (breaks = missing)</text><text x="${pad + 170}" y="14" font-size="11" fill="#1565c0">After correction</text>
      <text x="4" y="${y(hi) + 4}" font-size="10">${fmt(hi)}</text><text x="4" y="${y(lo) + 4}" font-size="10">${fmt(lo)}</text>
      <text x="${pad}" y="${h - 8}" font-size="10">${esc(daily[0].date)}</text><text x="${w - pad - 60}" y="${h - 8}" font-size="10">${esc(daily.at(-1).date)}</text></svg>`;
  }
  function download(name, text) {
    const url = URL.createObjectURL(new Blob([text], {type: "text/csv"}));
    const a = Object.assign(document.createElement("a"), {href: url, download: name});
    document.body.append(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }

  function review(kind, files) {
    return new Promise(async resolve => {
      const options = {unit: "auto", disabled: []};
      let dialog = null;
      const finish = value => { dialog?.close(); dialog?.remove(); resolve(value); };
      const original = {files};
      const show = (html, buttons) => {
        if (!dialog) {
          dialog = document.createElement("dialog");
          dialog.id = "data-check-dialog";
          dialog.style.cssText = "max-width:min(980px,94vw);width:100%;max-height:90vh;overflow:auto;padding:1.2rem;border:1px solid #9bb;border-radius:8px";
          dialog.addEventListener("cancel", e => { e.preventDefault(); finish(null); });
          document.body.append(dialog);
          dialog.showModal();
        }
        dialog.innerHTML = html + `<div class="button-row">` +
          buttons.map((b, i) => `<button type="button" data-b="${i}" class="${b.cls || "secondary"}">${esc(b.label)}</button>`).join("") + `</div>`;
        const row = dialog.querySelector(".button-row");
        Object.assign(row.style, {marginTop: "1rem", display: "flex", gap: ".6rem", flexWrap: "wrap"});
        buttons.forEach((b, i) => dialog.querySelector(`[data-b="${i}"]`).onclick = b.run);
      };
      const names = files.map(f => f.name).join(", ");
      async function attempt() {
        let data;
        try { data = await request(kind, files, options); }
        catch (error) {
          const needCapacity = /capacity/i.test(error.message);
          show(`<h3>Data check: ${esc(names)}</h3><p class="warning">The ${LABELS[kind]} could not be corrected automatically: ${esc(error.message)}</p>` +
            (needCapacity ? `<label>${kind === "solar" ? "Solar" : "Wind"} plant capacity, MW<input id="prep-cap" type="number" min="0" step="any"></label>` : ""),
            [...(needCapacity ? [{label: "Retry with capacity", cls: "", run: () => {
              options[kind === "solar" ? "solar_capacity_mw" : "wind_capacity_mw"] = Number(dialog.querySelector("#prep-cap").value) || undefined; attempt(); }}] : []),
             {label: "Use original file anyway", run: () => finish(original)}, {label: "Cancel upload", run: () => finish(null)}]);
          return;
        }
        const r = data.report;
        if (!dialog && !needsReview(r, kind)) { finish(original); return; }
        const visibleSteps = r.steps.filter(s => s.count > 0 || s.optional);
        show(`<h3>Data check: ${esc(names)}</h3>
          <p><strong>Quality ${r.score}/100 (grade ${r.grade})</strong> — ${r.hours.toLocaleString()} hours, ${esc(r.start)} to ${esc(r.end)}; ${r.repaired_hours.toLocaleString()} hours will be corrected.</p>
          ${r.notes.map(n => `<p class="${n.level === "warning" ? "warning" : "muted"}">${esc(n.text)}</p>`).join("")}
          <div class="table-scroll"><table><thead><tr><th>Apply</th><th>Issue / action</th><th>Count</th><th>Result</th><th>Detail</th></tr></thead><tbody>` +
          visibleSteps.map(s => `<tr><td>${s.optional ? `<input type="checkbox" data-step="${s.id}" ${s.enabled ? "checked" : ""} aria-label="Apply ${esc(s.title)}">` : "✓"}</td>
            <td>${esc(s.title)}</td><td>${s.count.toLocaleString()}</td><td>${esc(s.action)}</td><td>${esc(s.detail)}</td></tr>`).join("") +
          `</tbody></table></div><p class="muted">Untick an optional correction to keep the original values; the check re-runs.</p>` + chart(r.daily) +
          `<details><summary>Changed hours (first 300 of ${r.changes_total.toLocaleString()})</summary><div class="table-scroll"><table><thead><tr><th>Timestamp</th><th>Issue</th><th>Original</th><th>Corrected</th></tr></thead><tbody>` +
          r.changes.map(c => `<tr><td>${esc(c.timestamp)}</td><td>${esc(c.step)}</td><td>${fmt(c.original)}</td><td>${fmt(c.new)}</td></tr>`).join("") + `</tbody></table></div></details>`,
          [{label: "Accept corrections and continue", cls: "", run: () => finish({files: [{name: r.file_name, content: data.csv}], report: r})},
           {label: "Download corrected CSV", run: () => download(r.file_name, data.csv)},
           {label: "Download change log", run: () => download("change_log_" + r.file_name, data.changes_csv)},
           {label: "Use original file", run: () => finish(original)}, {label: "Cancel upload", run: () => finish(null)}]);
        dialog.querySelectorAll("[data-step]").forEach(box => box.onchange = () => {
          box.checked ? options.disabled = options.disabled.filter(x => x !== box.dataset.step) : options.disabled.push(box.dataset.step);
          attempt();
        });
      }
      await attempt();
    });
  }
  return {review};
})();
