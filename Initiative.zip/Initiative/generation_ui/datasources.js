"use strict";
/* Public data sources + map: downloads solar / wind / weather / thermal-proxy / load profiles and hands the
   result to the normal upload inputs (same code path and data-check dialog as a user-selected CSV file).
   API keys are kept in this closure only (never localStorage, never logged). */
(function () {
  const MapProviders = {
    // Provider abstraction: add e.g. a "google" entry (needs a paid key) without touching the dialog code.
    osm: {
      label: "OpenStreetMap (via local proxy)",
      tileUrl: "/api/x/tile?z={z}&x={x}&y={y}",
      geocode: q => "/api/x/geocode?q=" + encodeURIComponent(q),
      attribution: "&copy; <a href=\"https://www.openstreetmap.org/copyright\">OpenStreetMap</a> contributors",
      maxZoom: 19
    }
  };
  const provider = MapProviders.osm;
  const sessionKeys = {};          // memory only
  const TARGETS = [
    { section: "solar-upload", kinds: ["solar", "weather"], input: "solar-csv", enable: "solar_profile_enabled", status: "solar-file-status" },
    { section: "planned-solar-upload", kinds: ["solar"], input: "planned-solar-csv", enable: "planned-solar-enabled", status: "planned-solar-file-status" },
    { section: "wind-upload", kinds: ["wind", "weather"], input: "wind-csv", status: "wind-file-status" },
    { section: "thermal-upload", kinds: ["thermal", "weather"], input: "thermal-csv", status: "thermal-file-status" },
    { section: "demand-import", kinds: ["load"], input: "historical-csv" }
  ];
  const KIND_LABEL = { solar: "Solar irradiance and weather", wind: "Wind profile", weather: "Weather (download only)",
    thermal: "Thermal load proxy (degree hours)", load: "Electric load profile (USA)" };
  const SOURCES = {
    solar: [["nasa_power", "NASA POWER hourly irradiance + weather (no key)"], ["pvgis", "PVGIS-ERA5 hourly irradiance + weather (no key)"],
      ["pvgis_tmy", "PVGIS typical year irradiance + weather (TMY, no key)"], ["pvwatts", "NREL PVWatts v8 irradiance + weather (your free API key)"]],
    wind: [["nasa_power", "NASA POWER 50 m / 10 m wind (no key)"], ["pvgis", "PVGIS-ERA5 10 m wind (no key)"]],
    weather: [["nasa_power", "NASA POWER hourly (no key)"], ["pvgis", "PVGIS-ERA5 hourly (no key)"], ["pvgis_tmy", "PVGIS typical year (TMY)"]],
    thermal: [["pvgis_tmy", "PVGIS typical year (TMY)"], ["nasa_power", "NASA POWER hourly"], ["pvgis", "PVGIS-ERA5 hourly"]],
    load: [["typical", "Typical building-type shapes (no key, offline-capable)"],
      ["comstock", "NREL ComStock / ResStock county or state (no key, large download)"],
      ["eia930", "EIA-930 balancing-authority demand (your free API key)"]]
  };
  let catalog = null, map = null, marker = null, dialog = null, frame = null, ctx = null, result = null, job = null;
  const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const svg = (tag, attrs) => { const e = document.createElementNS("http://www.w3.org/2000/svg", tag); for (const k in attrs) e.setAttribute(k, attrs[k]); return e; };
  const api = async (path, body) => {
    const res = await fetch(path, body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : undefined);
    const text = await res.text();
    let data; try { data = JSON.parse(text); } catch (_) { data = { error: text.slice(0, 200) }; }
    if (!res.ok) throw new Error(data.error || ("HTTP " + res.status));
    return data;
  };

  // ---- launch buttons -------------------------------------------------------------------------
  function inject() {
    for (const target of TARGETS) {
      const section = document.getElementById(target.section);
      if (!section || section.querySelector(".ds-launch")) continue;
      const row = el("div", "ds-launch");
      const button = el("button", "secondary ds-open", "Get data from a public source / map…");
      button.type = "button";
      button.dataset.target = target.section;
      button.addEventListener("click", () => open(target));
      row.append(button, el("span", "muted", " NASA POWER, PVGIS, NREL, EIA - no upload needed."));
      section.append(row);
    }
  }

  // ---- dialog ---------------------------------------------------------------------------------
  function buildDialog() {
    dialog = el("dialog", "ds-dialog");
    dialog.id = "ds-dialog";
    dialog.setAttribute("aria-label", "Public data sources");
    dialog.innerHTML = `
      <form method="dialog" class="ds-head"><h3 id="ds-title">Public data source</h3><button class="secondary" id="ds-close" value="close">Close</button></form>
      <div class="ds-body">
        <div class="ds-left">
          <div class="ds-search"><input id="ds-q" type="search" placeholder="Search address, city, county, state" aria-label="Search place">
            <button type="button" class="secondary" id="ds-find">Search</button></div>
          <ul id="ds-results" class="ds-results"></ul>
          <div id="ds-map" class="ds-map" role="application" aria-label="Map"></div>
          <p class="ds-attrib muted">Click the map or drag the pin to set the location. Map &copy; OpenStreetMap contributors (tiles cached locally, usage-policy limits apply).</p>
          <div class="ds-coords"><label>Latitude<input id="ds-lat" type="number" step="any" min="-90" max="90"></label>
            <label>Longitude<input id="ds-lon" type="number" step="any" min="-180" max="180"></label>
            <button type="button" class="secondary" id="ds-last">Use my last location</button></div>
          <p id="ds-where" class="muted"></p>
        </div>
        <div class="ds-right">
          <div id="ds-form" class="ds-form"></div>
          <div class="ds-actions"><button type="button" id="ds-fetch">Download and preview</button>
            <label class="ds-refresh"><input type="checkbox" id="ds-refresh">Ignore cache</label></div>
          <progress id="ds-progress" max="1" value="0" hidden></progress>
          <p id="ds-msg" class="ds-msg" role="status"></p>
          <div id="ds-out" class="ds-out" hidden></div>
        </div>
      </div>`;
    document.body.append(dialog);
    if (window.windowFrame) frame = window.windowFrame.attach(dialog, {key: "ds-dialog", handle: dialog.querySelector(".ds-head"),
      minWidth: 560, minHeight: 420, onResize: () => { if (map) map.invalidateSize(); }});
    dialog.querySelector("#ds-close").addEventListener("click", () => dialog.close());
    dialog.querySelector("#ds-find").addEventListener("click", search);
    dialog.querySelector("#ds-q").addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); search(); } });
    dialog.querySelector("#ds-last").addEventListener("click", useLast);
    dialog.querySelector("#ds-fetch").addEventListener("click", startFetch);
    for (const id of ["ds-lat", "ds-lon"]) dialog.querySelector("#" + id).addEventListener("change", () => {
      const lat = parseFloat(val("ds-lat")), lon = parseFloat(val("ds-lon"));
      if (isFinite(lat) && isFinite(lon)) setLocation(lat, lon, false, true);
    });
  }
  const $ = id => dialog.querySelector("#" + id);
  const val = id => $(id).value;

  function initMap() {
    if (map) return;
    if (!window.L) { $("ds-map").textContent = "Map library not loaded: enter latitude / longitude manually."; return; }
    L.Util.emptyImageUrl = "/leaflet_layers.png";   // Leaflet's default is a data: GIF, which the CSP (img-src 'self') blocks
    map = L.map($("ds-map"), { center: [39, -98], zoom: 4, worldCopyJump: true });
    L.tileLayer(provider.tileUrl, { maxZoom: provider.maxZoom, attribution: provider.attribution }).addTo(map);
    const icon = L.icon({ iconUrl: "/leaflet_marker.png", iconRetinaUrl: "/leaflet_marker_2x.png", shadowUrl: "/leaflet_marker_shadow.png",
      iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41] });
    marker = L.marker([39, -98], { draggable: true, icon });
    marker.on("dragend", () => { const p = marker.getLatLng(); setLocation(p.lat, p.lng, false); });
    map.on("click", e => setLocation(e.latlng.lat, e.latlng.lng, false));
  }

  let locateTimer = 0;
  function setLocation(lat, lon, fly, fromInput) {
    lat = Math.max(-90, Math.min(90, lat)); lon = ((lon + 540) % 360) - 180;
    if (!fromInput) { $("ds-lat").value = lat.toFixed(5); $("ds-lon").value = lon.toFixed(5); }
    if (map) {
      marker.setLatLng([lat, lon]).addTo(map);
      if (fly) map.setView([lat, lon], Math.max(map.getZoom(), 9)); else if (fromInput) map.panTo([lat, lon]);
    }
    try { localStorage.setItem("genstudio_last_location", JSON.stringify({ lat, lon })); } catch (_) { /* optional */ }
    clearTimeout(locateTimer);
    $("ds-where").textContent = "Looking up state and county...";
    locateTimer = setTimeout(async () => {
      try {
        const info = await api(`/api/x/ds_locate?lat=${lat}&lon=${lon}`);
        ctx.place = info;
        $("ds-where").textContent = info.us ? `${info.county_name || "?"}, ${info.state_name || info.state} (county FIPS ${info.county_fips || "?"}, standard UTC${info.default_utc_offset >= 0 ? "+" : ""}${info.default_utc_offset})`
          : "Outside the USA (or lookup unavailable): solar / wind / weather still work; load needs the USA sources or typical shapes.";
        applyPlace(info);
      } catch (e) { $("ds-where").textContent = "Location lookup unavailable: " + e.message; ctx.place = null; }
    }, 350);
  }
  function applyPlace(info) {
    const form = $("ds-form");
    const utc = form.querySelector("[name=utc_offset]");
    if (utc && info.default_utc_offset != null && !utc.dataset.touched) utc.value = info.default_utc_offset;
    const state = form.querySelector("[name=state]");
    if (state && info.state && !state.dataset.touched) { state.value = info.state; state.dispatchEvent(new Event("change")); }
    const county = form.querySelector("[name=county_fips]");
    if (county) county.value = info.county_fips || "";
  }
  function useLast() {
    try {
      const last = JSON.parse(localStorage.getItem("genstudio_last_location") || "null");
      if (last && isFinite(last.lat)) return setLocation(last.lat, last.lon, true);
    } catch (_) { /* fall through */ }
    $("ds-msg").textContent = "No previous location saved yet.";
  }
  async function search() {
    const q = val("ds-q").trim(), list = $("ds-results");
    if (!q) return;
    list.replaceChildren(el("li", "muted", "Searching..."));
    try {
      const data = await api(provider.geocode(q));
      list.replaceChildren();
      if (!data.results.length) list.append(el("li", "muted", "No match. Try a fuller name, e.g. 'Fresno, California'."));
      for (const r of data.results) {
        const li = el("li"), b = el("button", "link", r.name);
        b.type = "button";
        b.addEventListener("click", () => {
          setLocation(r.lat, r.lon, false);
          if (map && r.bbox) map.fitBounds([[r.bbox[0], r.bbox[2]], [r.bbox[1], r.bbox[3]]], { maxZoom: 12 }); else if (map) map.setView([r.lat, r.lon], 10);
          list.replaceChildren();
        });
        li.append(b); list.append(li);
      }
    } catch (e) { list.replaceChildren(el("li", "ds-error", e.message)); }
  }

  // ---- form -----------------------------------------------------------------------------------
  function field(label, name, kind, def, extra = {}) {
    const wrap = el("label", "ds-field");
    wrap.append(label + " ");
    let input;
    if (kind === "select") {
      input = el("select");
      for (const [v, t] of extra.options) { const o = el("option", null, t); o.value = v; input.append(o); }
    } else { input = el("input"); input.type = kind; if (extra.step) input.step = extra.step; if (extra.min != null) input.min = extra.min; if (extra.max != null) input.max = extra.max; }
    input.name = name;
    if (kind === "checkbox") input.checked = !!def; else if (def != null) input.value = def;
    if (extra.placeholder) input.placeholder = extra.placeholder;
    input.addEventListener("change", () => { input.dataset.touched = "1"; });
    wrap.append(input);
    if (extra.hint) wrap.append(el("small", "muted ds-hint", extra.hint));
    if (extra.sources) wrap.dataset.sources = extra.sources.join(" ");
    return wrap;
  }
  function checklist(title, name, options, defaults) {
    const box = el("fieldset", "ds-checks"); box.dataset.checks = name;
    box.append(el("legend", null, title));
    for (const [key, text] of Object.entries(options)) {
      const l = el("label"), c = el("input");
      c.type = "checkbox"; c.value = key; c.checked = defaults.includes(key);
      l.append(c, " " + text); box.append(l);
    }
    return box;
  }
  function buildForm(kind) {
    const form = $("ds-form"); form.replaceChildren();
    const src = SOURCES[kind];
    form.append(field("Data source", "source", "select", src[0][0], { options: src }));
    const year = new Date().getFullYear() - 2;
    if (kind !== "load") {
      form.append(field("First year", "start_year", "number", Math.min(year, 2023), { min: 2001, max: year, sources: ["nasa_power", "pvgis"], hint: "NASA POWER from 2001, PVGIS from 2005. Several years are averaged into a typical year." }));
      form.append(field("Last year", "end_year", "number", Math.min(year, 2023), { min: 2001, max: year, sources: ["nasa_power", "pvgis"] }));
      form.append(field("UTC offset (standard time)", "utc_offset", "number", "", { step: 1, min: -12, max: 14, placeholder: "auto", hint: "Hour labels use local STANDARD time without daylight saving." }));
    }
    if (kind === "solar") {
      form.append(field("Array tracking", "tracking", "select", "fixed", { options: [["fixed", "Fixed tilt"], ["single_axis", "Single-axis (backtracking)"], ["two_axis", "Two-axis"]], sources: ["pvwatts"], hint: "PVWatts returns irradiance on the array plane. Other sources return horizontal irradiance; tilt and azimuth are set in the Solar PV inputs." }));
      form.append(field("Tilt (deg)", "tilt", "number", "", { step: "any", min: 0, max: 90, placeholder: "auto (~latitude)", sources: ["pvwatts"] }));
      form.append(field("Azimuth (deg, 180 = south)", "azimuth", "number", "", { step: "any", min: 0, max: 360, placeholder: "auto", sources: ["pvwatts"] }));
      form.append(field("NREL API key", "api_key", "password", sessionKeys.nrel || "", { sources: ["pvwatts"], hint: "Free at developer.nrel.gov. Kept in this page's memory only." }));
      form.append(el("p", "muted", "Downloads irradiance (GHI, DNI, DHI), air temperature and wind speed. GenStudio computes the PV output from them using the Solar PV parameters."));
    } else if (kind === "wind") {
      const t = Object.entries(catalog.turbines).map(([k, v]) => [k, v.label]);
      form.append(field("Turbine power curve", "turbine", "select", "iec2", { options: t }));
      form.append(field("Hub height (m)", "hub_height", "number", 100, { min: 10, max: 200, step: "any" }));
      form.append(field("Height extrapolation", "shear_method", "select", "two_height", { options: [["two_height", "Fit from 10 m and 50 m (NASA only)"], ["power", "Power law"], ["log", "Logarithmic"]] }));
      form.append(field("Shear exponent", "shear_alpha", "number", 0.143, { step: "any", min: 0, max: 0.6 }));
      form.append(field("Roughness length (m)", "roughness_m", "number", 0.03, { step: "any" }));
      form.append(field("Air-density correction", "density_correction", "checkbox", true));
      form.append(field("Losses (wake, availability) %", "losses_pct", "number", 0, { step: "any", min: 0, max: 60 }));
    } else if (kind === "thermal") {
      form.append(field("Mode", "mode", "select", "heating", { options: [["heating", "Heating degree hours"], ["cooling", "Cooling degree hours"]] }));
      form.append(field("Peak thermal demand (MWth)", "peak_mwth", "number", 1, { step: "any", min: 0.0001 }));
      form.append(field("Balance temperature (C)", "balance_c", "number", 15, { step: "any" }));
      form.append(field("Base (non-weather) fraction", "base_fraction", "number", 0.1, { step: "any", min: 0, max: 0.9 }));
    } else if (kind === "load") {
      form.append(field("Peak load (MW)", "peak_mw", "number", 5, { step: "any", min: 0.0001, hint: "The shape is scaled to this value. It is a proxy, not your metered load." }));
      form.append(field("Scale so that this is the", "scale_basis", "select", "peak", { options: [["peak", "annual peak"], ["mean", "annual mean"]] }));
      form.append(field("Target calendar year", "label_year", "number", new Date().getFullYear(), { min: 2000, max: 2100 }));
      form.append(field("First year (EIA)", "start_year", "number", 2023, { sources: ["eia930"] }));
      form.append(field("Last year (EIA)", "end_year", "number", 2023, { sources: ["eia930"] }));
      const states = [["", "(from map location)"], ...Object.entries(catalog.states).map(([k, v]) => [k, v.name])];
      form.append(field("State", "state", "select", "", { options: states, sources: ["comstock", "eia930"] }));
      form.append(field("County FIPS", "county_fips", "text", "", { sources: ["comstock"], hint: "Filled from the map location; empty = state / region." }));
      form.append(field("Balancing authority", "respondent", "text", "", { sources: ["eia930"], placeholder: "e.g. CISO, ERCO, PJM", hint: "Suggestions follow the state; see eia.gov/electricity/gridmonitor." }));
      form.append(field("EIA API key", "eia_key", "password", sessionKeys.eia || "", { sources: ["eia930"], hint: "Free at eia.gov/opendata. Kept in this page's memory only." }));
      const mixes = [["typical", "building_mix", "Typical building types", catalog.typical_types, ["office", "retail"]],
        ["comstock", "commercial_types", "ComStock commercial types", catalog.comstock_types, ["mediumoffice", "retailstandalone"]],
        ["comstock", "residential_types", "ResStock residential types (state level)", catalog.resstock_types, []]];
      for (const [s, n, title, opts, defs] of mixes) { const c = checklist(title, n, opts, defs); c.dataset.sources = s; form.append(c); }
    }
    const sel = form.querySelector("[name=source]");
    const sync = () => {
      const s = sel.value;
      for (const f of form.querySelectorAll("[data-sources]")) f.hidden = !f.dataset.sources.split(" ").includes(s);
      const sh = form.querySelector("[name=shear_method]");
      if (sh) sh.querySelector("option[value=two_height]").disabled = s !== "nasa_power";
      if (sh && s !== "nasa_power" && sh.value === "two_height") sh.value = "power";
    };
    sel.addEventListener("change", sync); sync();
    const resp = form.querySelector("[name=respondent]"), st = form.querySelector("[name=state]");
    if (st && resp) st.addEventListener("change", () => {
      const bas = (catalog.states[st.value] || {}).balancing_authorities || [];
      if (bas.length && !resp.dataset.touched) resp.value = bas[0];
      resp.title = bas.length ? "Likely balancing authorities: " + bas.join(", ") : "";
    });
    if (ctx && ctx.place) applyPlace(ctx.place);
  }
  function collect(kind) {
    const form = $("ds-form"), payload = { kind, lat: parseFloat(val("ds-lat")), lon: parseFloat(val("ds-lon")), refresh: $("ds-refresh").checked };
    if (!isFinite(payload.lat) || !isFinite(payload.lon)) throw new Error("Pick a location on the map or type latitude and longitude first.");
    for (const input of form.querySelectorAll("[name]")) {
      const holder = input.closest("[data-sources]");
      if (holder && holder.hidden) continue;
      if (input.type === "checkbox") payload[input.name] = input.checked;
      else if (input.value !== "") payload[input.name] = input.type === "number" ? Number(input.value) : input.value;
    }
    for (const box of form.querySelectorAll("[data-checks]")) {
      if (box.hidden) continue;
      const picked = [...box.querySelectorAll("input:checked")].map(c => c.value);
      payload[box.dataset.checks] = Object.fromEntries(picked.map(k => [k, 1]));
    }
    if (payload.api_key != null) sessionKeys.nrel = payload.api_key;
    if (payload.eia_key != null) { payload.api_key = payload.eia_key; sessionKeys.eia = payload.eia_key; delete payload.eia_key; }
    const none = name => !Object.keys(payload[name] || {}).length;
    if (kind === "load" && payload.source === "comstock" && none("commercial_types") && none("residential_types")) throw new Error("Tick at least one building type.");
    if (kind === "load" && payload.source === "typical" && none("building_mix")) throw new Error("Tick at least one building type.");
    return payload;
  }

  // ---- fetch + results --------------------------------------------------------------------------
  async function startFetch() {
    const msg = $("ds-msg"), btn = $("ds-fetch"), bar = $("ds-progress");
    result = null; $("ds-out").hidden = true; msg.className = "ds-msg";
    let payload;
    try { payload = collect(ctx.kind); } catch (e) { msg.textContent = e.message; msg.classList.add("ds-error"); return; }
    btn.disabled = true; bar.hidden = false; bar.value = 0; msg.textContent = "Starting download...";
    try {
      const started = await api("/api/x/ds_fetch", payload);
      job = started.job;
      for (;;) {
        await new Promise(r => setTimeout(r, 700));
        if (!dialog.open) return;
        const s = await api("/api/x/ds_job?id=" + job);
        bar.value = s.progress || 0; msg.textContent = s.message || "Working...";
        if (s.state === "error") throw new Error(s.error || "Download failed.");
        if (s.state === "done") { result = s.result; break; }
      }
      msg.textContent = "Done."; show(result);
    } catch (e) { msg.textContent = e.message; msg.classList.add("ds-error"); }
    finally { btn.disabled = false; bar.hidden = true; }
  }

  function chartTitle(root, title, unit, max) {
    const t = svg("text", { x: 2, y: 9, "font-size": 9, fill: "#4a5560" }); t.textContent = title + " (" + unit + ")"; root.append(t);
    const m = svg("text", { x: 2, y: 22, "font-size": 8, fill: "#4a5560" }); m.textContent = max.toPrecision(3); root.append(m);
  }
  function line(values, title, unit, w = 300, h = 90) {
    const nums = values.filter(v => v != null && isFinite(v)), max = Math.max(...nums, 1e-9), min = Math.min(0, ...nums);
    const root = svg("svg", { viewBox: `0 0 ${w} ${h}`, class: "ds-chart", role: "img", "aria-label": title });
    const pts = values.map((v, i) => `${(i / Math.max(1, values.length - 1) * (w - 34) + 32).toFixed(1)},${(h - 14 - ((v - min) / (max - min || 1)) * (h - 24)).toFixed(1)}`);
    root.append(svg("polyline", { points: pts.join(" "), fill: "none", stroke: "#0b6bcb", "stroke-width": "1.2" }));
    chartTitle(root, title, unit, max);
    return root;
  }
  function bars(values, title, unit, labels, w = 300, h = 90) {
    const max = Math.max(...values, 1e-9), root = svg("svg", { viewBox: `0 0 ${w} ${h}`, class: "ds-chart", role: "img", "aria-label": title });
    const bw = (w - 34) / values.length;
    values.forEach((v, i) => root.append(svg("rect", { x: 32 + i * bw + 1, y: h - 14 - (v / max) * (h - 24), width: Math.max(1, bw - 2), height: (v / max) * (h - 24), fill: "#0b6bcb" })));
    chartTitle(root, title, unit, max);
    const a = svg("text", { x: 32, y: h - 3, "font-size": 8, fill: "#4a5560" }); a.textContent = labels[0];
    const b = svg("text", { x: w - 4, y: h - 3, "font-size": 8, fill: "#4a5560", "text-anchor": "end" }); b.textContent = labels[1];
    root.append(a, b); return root;
  }
  const num = (v, d = 4) => (typeof v === "number" ? v.toLocaleString("en-US", { maximumFractionDigits: d }) : String(v));
  function show(r) {
    const out = $("ds-out"); out.replaceChildren(); out.hidden = false;
    const unit = { solar: "W/m2 irradiance", wind: "per MW", thermal: "per MWth", load: "MW", weather: "" }[ctx.kind];
    const s = r.stats, rows = [["Rows", s.rows], ["Period", `${s.first} to ${s.last}`], ["Mean", num(s.mean)], ["Peak", num(s.peak)],
      ["Missing data", num(s.missing_pct, 2) + " %"]];
    if (s.annual_irradiation_kwh_m2 != null) rows.splice(3, 0, ["Annual irradiation", num(s.annual_irradiation_kwh_m2, 0) + " kWh/m2"]);
    if (s.mean_temperature_c != null) rows.push(["Mean air temperature", num(s.mean_temperature_c, 1) + " C"]);
    if (s.capacity_factor != null) rows.splice(3, 0, ["Capacity factor", num(s.capacity_factor * 100, 1) + " %"]);
    if (s.annual_full_load_hours != null) rows.push(["Full-load hours / year", num(s.annual_full_load_hours, 0)]);
    const table = el("table", "ds-stats");
    for (const [k, v] of rows) { const tr = el("tr"); tr.append(el("th", null, k), el("td", null, v)); table.append(tr); }
    out.append(table);
    const charts = el("div", "ds-charts"), p = r.preview || {};
    if (p.daily) charts.append(line(p.daily, "Daily mean, 1 Jan - 31 Dec", unit));
    if (p.diurnal) charts.append(bars(p.diurnal, "Average day by hour", unit, ["00h", "23h"]));
    if (p.monthly) charts.append(bars(p.monthly, "Monthly mean", unit, ["Jan", "Dec"]));
    out.append(charts);
    if (r.warnings && r.warnings.length) { const ul = el("ul", "ds-warn"); for (const w of r.warnings) ul.append(el("li", null, w)); out.append(ul); }
    const prov = r.provenance || {}, det = el("details", "ds-prov"); det.append(el("summary", null, "Provenance and licence"));
    const pre = el("pre", null, ["source", "url_pattern", "method", "latitude", "longitude", "years", "retrieved_utc", "licence", "note"]
      .filter(k => prov[k] != null).map(k => `${k}: ${typeof prov[k] === "object" ? JSON.stringify(prov[k]) : prov[k]}`).join("\n") +
      "\nparameters: " + JSON.stringify(prov.parameters || {}) + "\ncaveats:\n - " + (prov.caveats || []).join("\n - "));
    det.append(pre); out.append(det);
    const acts = el("div", "ds-actions");
    const use = el("button", null, ctx.kind === "weather" ? "Weather is download-only" : "Use in GenStudio (runs the data check)");
    use.type = "button"; use.id = "ds-use"; use.disabled = ctx.kind === "weather";
    use.addEventListener("click", () => applyToApp(r));
    acts.append(use);
    if (r.saved) {
      const a = el("a", "ds-link", "Download CSV"); a.href = "/api/x/ds_file?name=" + encodeURIComponent(r.saved.csv); a.download = r.saved.csv;
      const b = el("a", "ds-link", "Download provenance"); b.href = "/api/x/ds_file?name=" + encodeURIComponent(r.saved.provenance); b.download = r.saved.provenance;
      acts.append(a, b);
    }
    out.append(acts);
  }

  // Same path as a user-picked file: set the input's FileList and fire "change" (app.js then runs dataPrep.review).
  function applyToApp(r) {
    const t = ctx.target, input = document.getElementById(t.input);
    if (!input) return;
    if (t.enable) { const box = document.getElementById(t.enable); if (box && !box.checked) { box.checked = true; box.dispatchEvent(new Event("change", { bubbles: true })); } }
    const transfer = new DataTransfer();
    transfer.items.add(new File([r.file.content], r.file.name, { type: "text/csv" }));
    dialog.close();
    const site = r.site || (r.provenance && r.provenance.site);
    if (site && ctx.kind === "solar") {
      for (const [id, value] of [["pv_latitude", site.latitude], ["pv_longitude", site.longitude], ["pv_utc_offset", site.utc_offset]]) {
        const field = document.getElementById(id);
        if (field && value != null) { field.value = Number(value).toFixed(4).replace(/\.?0+$/, ""); field.dispatchEvent(new Event("input", { bubbles: true })); }
      }
    }
    input.files = transfer.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  async function open(target) {
    if (!dialog) buildDialog();
    if (!catalog) { try { catalog = await api("/api/x/ds_catalog"); } catch (e) { window.alert("Public data sources are unavailable: " + e.message); return; } }
    const kind = target.kinds[0];
    ctx = { target, kind, place: ctx && ctx.place };
    dialog.showModal();
    if (frame) frame.opened();
    const old = dialog.querySelector(".ds-kind");
    if (old) old.remove();
    if (target.kinds.length > 1) {
      const wrap = el("label", "ds-field ds-kind", "Dataset "), sel = el("select");
      sel.id = "ds-kind";
      for (const k of target.kinds) { const o = el("option", null, KIND_LABEL[k]); o.value = k; sel.append(o); }
      wrap.append(sel); $("ds-form").before(wrap);
      sel.addEventListener("change", () => { ctx.kind = sel.value; $("ds-title").textContent = KIND_LABEL[ctx.kind]; buildForm(ctx.kind); $("ds-out").hidden = true; });
    }
    $("ds-title").textContent = KIND_LABEL[kind];
    $("ds-out").hidden = true; $("ds-msg").textContent = ""; $("ds-msg").className = "ds-msg";
    buildForm(kind);
    initMap();
    if (map) setTimeout(() => map.invalidateSize(), 50);
    if (!val("ds-lat")) { try { const last = JSON.parse(localStorage.getItem("genstudio_last_location") || "null"); if (last && isFinite(last.lat)) setLocation(last.lat, last.lon, true); } catch (_) { /* none */ } }
  }

  window.dataSources = { open: kind => { const t = TARGETS.find(x => x.kinds.includes(kind)); if (t) return open(Object.assign({}, t, { kinds: [kind] })); }, providers: MapProviders };

  function ensureLeaflet() {
    if (window.L || document.querySelector("script[data-leaflet]")) return;
    if (!document.querySelector("link[data-leaflet]")) { const l = document.createElement("link"); l.rel = "stylesheet"; l.href = "/leaflet.css"; l.dataset.leaflet = "1"; document.head.append(l); }
    const s = document.createElement("script"); s.src = "/leaflet.js"; s.dataset.leaflet = "1"; document.head.append(s);
  }
  window.addEventListener("load", () => { ensureLeaflet(); inject(); });
})();
