﻿"use strict";
const inputWorkspace = (() => {
  let pages=[], active=null, initialized=false, timer=null, database=null, revision=0;
  const $=id=>document.getElementById(id);
  function category(name, contents) {
    const section=document.createElement("section");section.className="input-category";
    const title=document.createElement("h3");title.textContent=name;section.append(title);
    for(const item of contents)section.append(item);
    return section;
  }
  function open(page,index=0) {
    active={page,index};$("input-editor").hidden=false;
    for(const view of document.querySelectorAll(".workflow-view"))view.hidden=true;
    for(const p of pages) {
      p.element.hidden=p!==page;
      p.buttons.forEach((button,i)=>button.classList.toggle("active",p===page && i===index));
      p.sections.forEach((section,i)=>section.hidden=p!==page||i!==index);
    }
    page.element.open=true;page.navigation.open=true;
    $("input-title").textContent=page.names[index];$("input-breadcrumb").textContent="MODEL INPUTS / "+page.title;
    $("input-next").replaceChildren();
    for(const [offset,label] of [[-1,"Previous category"],[1,"Next category"]]) {
      const target=index+offset;
      if(target<0 || target>=page.sections.length)continue;
      const button=document.createElement("button");button.className="secondary";button.textContent=label;
      button.onclick=()=>open(page,target);$("input-next").append(button);
    }
    topologyEditor.refresh();
    $("input-editor").scrollIntoView({behavior:"smooth",block:"start"});
  }
  function register(element,title,sections,names) {
    element.classList.add("input-page");element.open=true;
    element.querySelector(":scope > summary")?.setAttribute("hidden","");
    for(const section of sections)element.append(section);
    $("input-pages").append(element);element.hidden=true;
    const navigation=document.createElement("details");navigation.className="input-nav";
    const summary=document.createElement("summary");summary.textContent=title;navigation.append(summary);
    const ICONS={"Scenarios":"\u2630","Demand":"\u2301","Thermal load":"\u2668","Grid and tariff":"\u26A1","Existing/Planned Generation":"\u25A6",
      "Microgrid":"\u25C9","Solar PV":"\u2600","BESS":"\u25AE","Wind":"\u2318","Hydrogen turbine":"\u25CE","Hydrogen CHP":"\u25CE",
      "Natural gas turbine":"\u2742","Natural gas CHP":"\u2742","Diesel generator":"\u25B2","Biogas generator":"\u2766","Biomass generator":"\u2766",
      "Financial":"$","Carbon emissions":"\u2601","Save & load":"\u2193"};
    summary.dataset.icon=ICONS[title]||"\u25CF";
    const page={element,title,sections,names,navigation,buttons:[]};
    sections.forEach((section,i)=>{
      const button=document.createElement("button");button.className="input-link";button.textContent=names[i];
      button.onclick=()=>open(page,i);navigation.append(button);page.buttons.push(button);
    });
    summary.onclick=e=>{e.preventDefault();const wasOpen=navigation.open;
      for(const p of pages)p.navigation.open=false;
      navigation.open=!wasOpen;
      if(navigation.open)open(page,0);
    };
    $("input-navigation").append(navigation);pages.push(page);
  }
  function bucketName(title,key) {
    if(title==="Grid and tariff")
      return /^(grid_limit|reference_grid_limit|upgrade_)/.test(key)?"Grid connection and upgrade":
        /^(reactive_|export_)/.test(key)?"Reactive-demand charge and export":"Energy tariff";
    if(title==="Financial")return /^currency_/.test(key)?"Currency":/life$|replacement/.test(key)?"Service life and replacement":"Discounting and appraisal period";
    if(title==="Carbon emissions")return /^emissions_limit/.test(key)?"Annual emissions limit":"Carbon price and emission factors";
    if(/land|acres/.test(key))return "Land constraints";
    if(/capex|fom|vom|fuel_price/.test(key))return "Costs and maintenance";
    if(/profile_enabled/.test(key))return "Hourly resource";
    return "Design and operating parameters";
  }
  function init() {
    const nav=document.createElement("nav");nav.id="input-navigation";nav.setAttribute("aria-label","Model input categories");
    const aside=document.querySelector("aside");aside.querySelector("h2").after(nav);
    const scenarios=$("scenario-section");
    const selection=document.createElement("section");
    let marker=scenarios.querySelector("h3");
    while(marker){const next=marker.nextSibling;selection.append(marker);marker=next;}
    const description=[...scenarios.children].filter(e=>e.tagName!=="SUMMARY");
    register(scenarios,"Scenarios",[category("Eligible technologies and scenario definitions",description),
      category("Select scenarios to optimize",[selection])],["Define scenarios","Scenarios to optimize"]);
    for(const element of document.querySelectorAll("#fields > details")) {
      const title=element.dataset.group;
      if(title==="Solver"){element.hidden=true;continue;}
      let sections=[],names=[];
      const labels=[...element.querySelectorAll(":scope > label")];
      if(title==="Demand") {
        sections=[category("Demand data and forecasting",[$("demand-import")])];names=["Load profiles & forecast"];
      } else {
        const buckets=new Map();
        for(const label of labels) {
          const key=label.querySelector("input,select:not(.unit-select)")?.id||"";
          const name=bucketName(title,key);
          if(!buckets.has(name))buckets.set(name,[]);
          buckets.get(name).push(label);
        }
        const extraIds={"Solar PV":"solar-upload","Wind":"wind-upload","Thermal load":"thermal-upload","Financial":"financial-reference-input"};
        if(extraIds[title]) {
          const name=title==="Financial"?"Comparison baseline":"Hourly resource";
          if(!buckets.has(name))buckets.set(name,[]);
          buckets.get(name).push($(extraIds[title]));
        }
        for(const [name,items] of buckets){sections.push(category(name,items));names.push(name);}
        if(title==="Microgrid"){sections.push(category("Microgrid topology",[$("topology-panel")]));names.push("Topology / single-line diagram");}
      }
      for(const section of sections)if(section.querySelector(":scope > label"))section.classList.add("field-category");
      register(element,title,sections,names);
    }
    const planned=$("planned-section");
    register(planned,"Existing/Planned Generation",[category("Existing generation",[$("existing-block")]),
      category("Planned generation",[$("planned-block")])],["Existing","Planned"]);
    const save=$("save-inputs").closest("details"),saveContent=[...save.children].filter(e=>e.tagName!=="SUMMARY");
    register(save,"Save & load",[category("Portable assumptions and project defaults",saveContent)],["Save / restore JSON"]);
    const order=["Scenarios","Demand","Thermal load","Grid and tariff","Existing/Planned Generation","Microgrid",
      "BESS","Solar PV","Wind","Hydrogen turbine","Natural gas turbine","Natural gas CHP","Hydrogen CHP",
      "Diesel generator","Biogas generator","Biomass generator","Financial","Carbon emissions","Save & load"];
    const rank=p=>{const i=order.indexOf(p.title);return i<0?order.length:i;};
    pages.sort((a,b)=>rank(a)-rank(b));
    const microgridAt=order.indexOf("Microgrid"),financialAt=order.indexOf("Financial");
    for(const page of pages) {
      $("input-navigation").append(page.navigation);
      const at=order.indexOf(page.title);
      page.navigation.classList.toggle("nested",at>microgridAt&&at<financialAt);
    }
    $("close-input").onclick=()=>{close();switchView(activeView);};
    $("save-draft").onclick=()=>saveNow();
    document.addEventListener("visibilitychange",()=>{if(document.hidden && timer)saveNow();});
    window.addEventListener("beforeunload",event=>{
      if(timer){event.preventDefault();event.returnValue="Inputs are still being saved.";}
    });
    initialized=true;visibilityChanged();
  }
  function visibilityChanged() {
    if(!initialized)return;
    const selectedIds=new Set([...document.querySelectorAll("#scenarios input:checked")].map(i=>i.value));
    const technologies=new Set(readScenarioRows().filter(s=>selectedIds.has(s.id)).flatMap(s=>s.technologies));
    const techGroups={"Solar PV":"pv","BESS":"bess","Wind":"wind","Hydrogen turbine":"h2","Hydrogen CHP":"h2_chp",
      "Natural gas turbine":"ng","Natural gas CHP":"ng_chp","Grid and tariff":"grid",
      "Diesel generator":"diesel","Biogas generator":"biogas","Biomass generator":"biomass"};
    const planned=readPlanned();
    for(const page of pages) {
      const key=techGroups[page.title];
      page.navigation.hidden=!!key && !technologies.has(key) &&
        !planned.some(p=>p.technology===({pv:"Solar",bess:"BESS"}[key]));
      page.element.hidden=!active||active.page!==page;
    }
    topologyEditor.refresh();
  }
  function close() { $("input-editor").hidden=true;for(const page of pages)page.element.hidden=true;active=null; }
  function db() {
    if(database)return database;
    database=new Promise((resolve,reject)=>{
      const request=indexedDB.open("genstudio-input-drafts",1);
      request.onupgradeneeded=()=>request.result.createObjectStore("drafts");
      request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);
    });
    return database;
  }
  function capture() {
    return {values:values(),application_version:schema.application_version,demand_source:$("demand-workflow").value,
      ...profileUploads,...resourceUploads,milestones:readRows("milestone-rows"),      planned_generation:readPlanned(),planned_schema:PLANNED_SCHEMA,
      planned_solar_profile_enabled:$("planned-solar-enabled").checked,scenario_definitions:readScenarioRows(),
      scenarios:[...document.querySelectorAll("#scenarios input:checked")].map(i=>i.value),
      comparison_reference:$("financial-reference").value||null,topology:topologyEditor.value(),source_run:currentRun,
      display_units:unitsUi.snapshot()};
  }
  async function saveNow() {
    clearTimeout(timer);
    timer=null;
    const current=++revision;
    try {
      const data=capture(),store=await db();
      await new Promise((resolve,reject)=>{
        const transaction=store.transaction("drafts","readwrite");transaction.objectStore("drafts").put(data,"current");
        transaction.oncomplete=resolve;transaction.onerror=()=>reject(transaction.error);transaction.onabort=()=>reject(transaction.error);
      });
      if(current===revision)$("draft-status").textContent="Saved locally at "+new Date().toLocaleTimeString();
    } catch(error) {
      $("draft-status").textContent="NOT saved: "+error.message;
      showError("Cannot save local input draft: "+error.message+". Export settings JSON before closing.");
    }
  }
  function schedule() {
    if(!initialized)return;
    $("draft-status").textContent="Unsaved changes - saving...";
    clearTimeout(timer);timer=setTimeout(saveNow,450);
  }
  async function load() {
    const store=await db();
    return await new Promise((resolve,reject)=>{
      const request=store.transaction("drafts").objectStore("drafts").get("current");
      request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);
    });
  }
  function applyUploads(settings) {
    for(const key of Object.keys(profileUploads))profileUploads[key]=settings[key]||[];
    for(const key of Object.keys(resourceUploads))resourceUploads[key]=settings[key]||null;
    for(const [key,id] of [["solar_file","solar-file-status"],["planned_solar_file","planned-solar-file-status"],
      ["wind_file","wind-file-status"],["thermal_file","thermal-file-status"]])
      if(resourceUploads[key])$(id).textContent=resourceUploads[key].name+" - restored local draft";
    $("profile-uploads").textContent=Object.values(profileUploads).flat().map(f=>f.name).join(", ")||"No demand uploads selected.";
  }
  return {init,close,visibilityChanged,schedule,saveNow,load,applyUploads,snapshot:capture,
    openGroup:title=>{const page=pages.find(p=>p.title===title);if(page)open(page,0);return !!page;},
    reveal:element=>{
      for(const page of pages) {
        const index=page.sections.findIndex(s=>s.contains(element));
        if(index>=0){open(page,index);page.element.hidden=false;return true;}
      }
      return false;
    }};
})();
