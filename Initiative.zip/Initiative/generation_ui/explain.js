"use strict";
// "Why this mix" explanation and NPC waterfall, shown in the Economic Analysis pane.
const explainUi = (() => {
  const el = (tag, text, cls) => node(tag, text, cls);
  let panel = null;

  function ensure() {
    if (panel) return;
    panel = el("section", undefined, "explain-panel"); panel.id = "explain-panel";
    const head = el("h2", "Why this mix?"), bar = el("div", undefined, "sens-controls");
    const sel = el("select"); sel.id = "explain-scenario";
    const go = el("button", "Explain", "secondary"); go.type = "button"; go.onclick = run;
    bar.append(sel, go);
    const out = el("div"); out.id = "explain-out";
    panel.append(head, bar, out);
    analysisTabs.pane("economic").append(panel);
    sel.onchange = run;
  }

  function fill() {
    const sel = byId("explain-scenario"), prior = sel.value;
    const results = solveSnapshot?.summary?.results || [];
    sel.replaceChildren(...results.filter(r => r.code !== "R0").map(r => {
      const o = el("option", `${r.code} - ${r.name}`); o.value = r.code; return o;
    }));
    if (prior) sel.value = prior;
    panel.hidden = !results.length;
  }

  function waterfall(r) {
    const g = window.GS, m = v => `${currencyUi.prefix()}${g.fmt(v * currencyUi.fx() / 1e6, 2)}M`, sm = v => `${v >= 0 ? "+" : "−"}${m(Math.abs(v))}`;
    const cats = [{key: "start", label: r.reference, color: "#2F6DB5", from: 0, to: r.start, text: m(r.start), tip: [{color: "#2F6DB5", label: "NPC", value: m(r.start)}]}];
    let run = r.start;
    for (const s of r.steps) {
      const to = run + s.delta, up = s.delta > 0, color = up ? "#C0392B" : "#3F9E5A";
      cats.push({key: s.label, label: s.label, color, from: run, to, text: sm(s.delta), tip: [{color, label: up ? "Increases NPC" : "Reduces NPC", value: sm(s.delta)}, {color: "#8A97A0", label: "Running NPC", value: m(to)}]});
      run = to;
    }
    cats.push({key: "end", label: r.name, color: "#2F6DB5", from: 0, to: r.end, text: m(r.end), tip: [{color: "#2F6DB5", label: "NPC", value: m(r.end)}]});
    return g.chart({kind: "bars", floating: true, valueLabels: true, title: `NPC waterfall: ${r.reference} to ${r.name}`, filename: "npc_waterfall",
      subtitle: "Net present cost. Red steps raise cost, green steps reduce it.", yTitle: "Net present cost (USD)", unit: "USD", catTitle: "Step",
      categories: cats, series: [{key: "npc", label: "NPC", color: "#2F6DB5", values: cats.map(c => c.to)}], height: 460, vFmt: v => m(v),
      yFmt: v => m(v), legendItems: [{label: "Total NPC", color: "#2F6DB5"}, {label: "Raises cost", color: "#C0392B"}, {label: "Reduces cost", color: "#3F9E5A"}]}).el;
  }

  async function run() {
    showError("");
    const out = byId("explain-out");
    try {
      const r = await fetchJson(`/api/x/explain?run_id=${solveRun}&scenario=${encodeURIComponent(byId("explain-scenario").value)}`);
      const list = el("ul");
      for (const line of r.summary) list.append(el("li", line));
      out.replaceChildren(list);
      if (r.reference && r.steps.length) out.append(waterfall(r));
    } catch (error) { showError(error.message); }
  }

  window.addEventListener("load", () => {
    ensure();
    analysisTabs.onShow("economic", () => { fill(); if (!panel.hidden && byId("explain-scenario").value) run(); });
  });
  return {};
})();
