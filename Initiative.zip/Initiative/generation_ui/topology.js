"use strict";
const topologyEditor = (() => {
  let root={enabled:false,nodes:[],lines:[],diagrams:{}}, code=null, selected=null;
  let mode="select", wire=null, drag=null, undo=[], redo=[], counter=0, signature="", mirrors=[];
  let animationFrame=null;
  const $=id=>document.getElementById(id), NS="http://www.w3.org/2000/svg";
  const groups={grid:"Grid and tariff",pv:"Solar PV",bess:"BESS",wind:"Wind",h2:"Hydrogen turbine",
    h2_chp:"Hydrogen CHP",ng:"Natural gas turbine",ng_chp:"Natural gas CHP",diesel:"Diesel generator",
    biogas:"Biogas generator",biomass:"Biomass generator",load:"Demand",substation:"Microgrid"};
  const EXTRA=["load","bus","substation","shunt"];
  // Nominal kV when a component has no electrical.kv; mirrors power_flow.DEFAULTS["kv_by_kind"] (test_topo_editor checks it).
  const KV_DEFAULT={grid:33,substation:33,bus:11,load:11,pv:11,bess:11,wind:11,ng:11,ng_chp:11,h2:11,h2_chp:11,diesel:11,biogas:11,biomass:11};
  const LEVELS=[[100,"kv-hv","\u2265 100 kV"],[20,"kv-sub","20 - 100 kV"],[1,"kv-mv","1 - 20 kV"],[0,"kv-lv","< 1 kV"]];
  const kvOf=node=>node.electrical?.kv??KV_DEFAULT[node.kind]??11;
  const levelOf=kv=>LEVELS.find(([min])=>kv>=min)||LEVELS.at(-1);
  const kvText=kv=>`${Number(kv.toFixed(4)).toLocaleString("en-US",{maximumFractionDigits:4})} kV`;
  const numText=value=>Number(value).toLocaleString("en-US",{maximumFractionDigits:4});
  // Same rule as power_flow.build_network: a wire between different nominal kV is a transformer, a zero-length one a bus tie.
  function branchKind(edge,a,b) {
    if(edge.electrical?.kind)return edge.electrical.kind;
    if(Math.abs(kvOf(a)-kvOf(b))>1e-9)return "transformer";
    return edge.length_km>0?"line":"tie";
  }
  const name=kind=>schema.technologies.find(([key])=>key===kind)?.[1]||({load:"Load",bus:"Bus",substation:"Substation",shunt:"Shunt"}[kind]||kind);
  const id=prefix=>prefix+Date.now().toString(36)+(counter++);
  const diagram=()=>code ? root.diagrams[code] : root;
  const scenario=()=>readScenarioRows().find(row=>row.id===code);
  const snap=value=>Math.max(20,Math.min(1580,Math.round(value/20)*20));
  const position=p=>({x:snap(p.x),y:Math.max(20,Math.min(880,Math.round(p.y/20)*20))});
  function el(tag, attrs={},text) {
    const item=document.createElementNS(NS,tag);
    for(const [key,value] of Object.entries(attrs))item.setAttribute(key,value);
    if(text!==undefined)item.textContent=text;
    return item;
  }
  function raw(event) {
    const p=$("topology-svg").createSVGPoint();p.x=event.clientX;p.y=event.clientY;
    return p.matrixTransform($("topology-svg").getScreenCTM().inverse());
  }
  function point(event) {return position(raw(event));}
  // PSS/E v33 naming: bus number 1..999997 unique; bus name <=12 chars, A-Z 0-9 space _-.+/ only, unique.
  function cleanElectrical(graph,itemId,values) {
    const out={...values},notes=[],rejected=[];
    const others=graph.nodes.filter(n=>n.id!==itemId);
    if(out.bus_number!==undefined&&out.bus_number!==null) {
      const n=Number(out.bus_number),clash=others.find(o=>Number(o.electrical?.bus_number)===n);
      if(!Number.isInteger(n)||n<1||n>999997){rejected.push(`Bus number must be a whole number from 1 to 999997.`);delete out.bus_number;}
      else if(clash){rejected.push(`Bus number ${n} is already used by ${clash.label}; choose another.`);delete out.bus_number;}
      else out.bus_number=n;
    }
    if(out.bus_name!==undefined&&out.bus_name!==null) {
      let text=String(out.bus_name).toUpperCase().replace(/[^A-Z0-9 _.+\/-]/g,"").trim().slice(0,12).trim();
      if(!text)delete out.bus_name;
      else {
        const used=new Set(others.map(o=>String(o.electrical?.bus_name||"").toUpperCase()));
        const base=text;let n=1;
        while(used.has(text)){n++;text=base.slice(0,12-String(n).length-1)+"_"+n;}
        if(text!==String(values.bus_name))notes.push(`Bus name set to ${text} (PSS/E: max 12 characters, unique, no quotes).`);
        out.bus_name=text;
      }
    }
    return {out,notes,rejected};
  }
  function numberingIssues(graph) {
    const issues=[];
    for(const field of ["bus_number","bus_name"]) {
      const seen=new Map();
      for(const n of graph.nodes) {
        const v=n.electrical?.[field];if(v===undefined||v===null||v==="")continue;
        const key=String(v).toUpperCase();
        if(seen.has(key))issues.push({level:"error",target:n.id,
          text:`Duplicate ${field==="bus_number"?"bus number":"bus name"} ${v} on ${seen.get(key)} and ${n.label}.`});
        else seen.set(key,n.label);
      }
    }
    return issues;
  }
  // Live electrical/connectivity checks shown under the drawing; every message selects the offending component or wire.
  function diagramChecks(graph) {
    const issues=[],byId=new Map(graph.nodes.map(n=>[n.id,n]));
    const label=key=>byId.get(key)?.label||key,wires=key=>graph.lines.filter(e=>e.source===key||e.target===key);
    if(!graph.nodes.some(n=>n.kind==="load"))issues.push({level:"error",text:"Add a Load node: every scenario needs the demand it serves."});
    const pairs=new Map();
    for(const node of graph.nodes) {
      const attached=wires(node.id);
      if(!attached.length&&graph.nodes.length>1)issues.push({level:"warning",target:node.id,text:`${node.label} is not connected to any wire.`});
      if(node.kind==="shunt"&&attached.length>1)issues.push({level:"error",target:node.id,text:`${node.label}: a shunt connects to exactly one bus.`});
    }
    for(const edge of graph.lines) {
      const a=byId.get(edge.source),b=byId.get(edge.target);if(!a||!b)continue;
      const pair=[edge.source,edge.target].sort().join("|");
      if(pairs.has(pair))issues.push({level:"warning",target:edge.id,
        text:`Parallel wires join ${a.label} and ${b.label}; use Circuits on one wire for a double circuit.`});
      pairs.set(pair,edge.id);
      if(a.kind==="shunt"||b.kind==="shunt")continue;
      const kind=branchKind(edge,a,b),differ=Math.abs(kvOf(a)-kvOf(b))>1e-9;
      if(differ&&kind!=="transformer")issues.push({level:"error",target:edge.id,
        text:`Wire ${a.label} - ${b.label} joins ${kvText(kvOf(a))} and ${kvText(kvOf(b))} buses but is set as a ${kind}; make it a transformer or equalise the kV.`});
    }
    const through=new Set(["bus","substation","load"]);
    const loads=graph.nodes.filter(n=>n.kind==="load");
    for(const start of graph.nodes.filter(n=>schema.technologies.some(([key])=>key===n.kind))) {
      const seen=new Set([start.id]),stack=[start.id];
      while(stack.length) {
        const current=stack.pop();
        for(const edge of wires(current)) {
          const next=edge.source===current?edge.target:edge.source;
          if(!seen.has(next)&&through.has(byId.get(next)?.kind)){seen.add(next);stack.push(next);}
        }
      }
      if(loads.length&&!loads.some(l=>seen.has(l.id)))issues.push({level:"error",target:start.id,
        text:`${start.label} has no wired path to the Load: connect it through a bus or substation.`});
    }
    return [...issues,...numberingIssues(graph)];
  }
  function renderChecks(graph) {
    let box=$("topology-checks");
    if(!box){box=document.createElement("div");box.id="topology-checks";$("topology-message").after(box);}
    const issues=diagramChecks(graph);
    box.hidden=!issues.length;
    box.replaceChildren(...issues.map(issue=>{
      const row=document.createElement(issue.target?"button":"div");row.className=`topology-check ${issue.level}`;
      row.textContent=(issue.level==="error"?"Error: ":"Warning: ")+issue.text;
      if(issue.target){row.type="button";row.onclick=()=>select(issue.target);}
      return row;
    }));
  }
  function snapshot() {
    return JSON.stringify({root,code,scenarios:readScenarioRows(),
      selectedScenarios:[...$("scenarios").querySelectorAll("input:checked")].map(input=>input.value)});
  }
  function remember() {undo.push(snapshot());if(undo.length>60)undo.shift();redo=[];}
  function changed(rebuild=false) {render();if(rebuild)properties();edited();}
  function reconcile(graph,definition) {
    const allowed=new Set(definition?.technologies||[]);
    const removed=new Set(graph.nodes.filter(n=>schema.technologies.some(([key])=>key===n.kind)&&!allowed.has(n.kind)).map(n=>n.id));
    graph.nodes=graph.nodes.filter(n=>!removed.has(n.id));
    graph.lines=graph.lines.filter(e=>!removed.has(e.source)&&!removed.has(e.target));
    if(graph.nodes.length)for(const kind of allowed)if(!graph.nodes.some(n=>n.kind===kind))
      graph.nodes.push(component(kind,{x:180+(graph.nodes.length%5)*280,y:140+Math.floor(graph.nodes.length/5)*180}));
    if(removed.has(selected)){selected=null;properties();}
  }
  function setTech(kind,enabled) {
    if(!schema.technologies.some(([key])=>key===kind))return true;
    const card=[...$("scenario-rows").children].find(row=>row.querySelector("[data-key=id]").value===code);
    const input=card?.querySelector(`[data-tech="${kind}"]`);
    if(!input || input.disabled && input.checked!==enabled) {
      showError("The upgraded-grid reference can contain only Grid. Choose or define an alternative scenario.");return false;
    }
    input.checked=enabled;refreshScenarioChoices();
    return true;
  }
  function component(kind,p) {
    const node={id:id("n"),kind,label:kind==="shunt"?"Shunt capacitor":name(kind),...position(p),rotation:0,scale:.7,
      owner:schema.technologies.some(([key])=>key===kind)?kind:"shared",capital_cost:0};
    if(kind==="shunt")node.electrical={shunt_mvar:1};
    return node;
  }
  function add(kind,p) {
    const graph=diagram();if(!graph || !scenario()){showError("Select a defined scenario first.");return;}
    if(graph.nodes.some(node=>node.kind===kind)&&!EXTRA.includes(kind)) {
      select(graph.nodes.find(node=>node.kind===kind).id);return;
    }
    remember();
    if(!setTech(kind,true)){undo.pop();return;}
    const node=component(kind,p||{x:180+(graph.nodes.length%5)*280,y:140+Math.floor(graph.nodes.length/5)*180});
    graph.nodes.push(node);selected=node.id;changed(true);
  }
  function autoDraw(options={}) {
    const definition=scenario();if(!definition||!diagram())return false;
    remember();
    const old=diagram(), byKind=new Map(old.nodes.map(node=>[node.kind,node]));
    // Clear drawing also unticks the scenario's technologies; restore the remembered set so the full topology comes back.
    let kinds=[...definition.technologies];
    if(!kinds.length&&!definition.reference) {
      kinds=(old.autodraw_technologies||[]).filter(kind=>schema.technologies.some(([key])=>key===kind));
      if(!kinds.length)kinds=["grid"];
      for(const kind of kinds)if(!setTech(kind,true)){undo.pop();return false;}
    }
    delete old.autodraw_technologies;
    // Layout must stay identical to network_topology.autodraw (technology row, single bus, load below).
    const bus=byKind.get("bus")||component("bus",{x:800,y:400});
    bus.x=800;bus.y=400;
    const load=byKind.get("load")||component("load",{x:800,y:620});load.x=800;load.y=620;
    const nodes=[load,bus];
    const step=Math.min(240,1300/Math.max(1,kinds.length-1));
    kinds.forEach((kind,i)=>{
      const node=byKind.get(kind)||component(kind,{x:100,y:140});
      node.x=kinds.length===1?800:snap(800+(i-(kinds.length-1)/2)*step);node.y=140;nodes.push(node);
    });
    const lines=[];
    function connect(a,b,owner) {
      const prior=old.lines.find(line=>{
        const source=old.nodes.find(n=>n.id===line.source)?.kind,target=old.nodes.find(n=>n.id===line.target)?.kind;
        return source===a.kind&&target===b.kind||source===b.kind&&target===a.kind;
      });
      lines.push({id:prior?.id||id("l"),source:a.id,target:b.id,source_port:"bottom",target_port:"top",
        owner:prior?.owner||owner,length_km:prior?.length_km||0,cost_per_km:prior?.cost_per_km||0,
        points:[]});
    }
    connect(bus,load,"shared");
    for(const node of nodes.slice(2))connect(node,bus,node.kind);
    // Keep user-added auxiliary equipment; autodraw rearranges only the core scenario.
    const auxiliary=old.nodes.filter(n=>!nodes.some(core=>core.id===n.id)&&EXTRA.includes(n.kind));
    const auxiliaryIds=new Set(auxiliary.map(n=>n.id)), allIds=new Set([...nodes,...auxiliary].map(n=>n.id));
    lines.push(...old.lines.filter(edge=>(auxiliaryIds.has(edge.source)||auxiliaryIds.has(edge.target))&&
      allIds.has(edge.source)&&allIds.has(edge.target)));
    const requested=Number.isFinite(options?.shunt_mvar)?options.shunt_mvar:null;
    if(requested!==null) {
      const attached=auxiliary.filter(n=>n.kind==="shunt"&&lines.some(e=>[e.source,e.target].includes(n.id)&&[e.source,e.target].includes(bus.id)));
      if(requested===0) {
        const drop=new Set(attached.map(n=>n.id));
        auxiliary.splice(0,auxiliary.length,...auxiliary.filter(n=>!drop.has(n.id)));
        lines.splice(0,lines.length,...lines.filter(e=>!drop.has(e.source)&&!drop.has(e.target)));
      } else {
        let shunt=attached[0];
        if(!shunt) {
          shunt=component("shunt",{x:960,y:560});auxiliary.push(shunt);
          lines.push({id:id("l"),source:bus.id,target:shunt.id,source_port:"bottom",target_port:"top",owner:"shared",
            length_km:0,cost_per_km:0,points:[]});
        }
        shunt.electrical={...(shunt.electrical||{}),shunt_mvar:requested};
        if(bus.electrical?.kv&&!shunt.electrical.kv)shunt.electrical.kv=bus.electrical.kv;
        shunt.label=requested<0?"Shunt reactor":"Shunt capacitor";
      }
    }
    root.diagrams[code]={enabled:old.enabled,nodes:[...nodes,...auxiliary],lines};
    if(old.pf_settings)root.diagrams[code].pf_settings=old.pf_settings;
    selected=null;multi.clear();wire=null;changed(true);fit();
    $("topology-message").textContent="Scenario autodrawn. Existing matching line costs and auxiliary equipment retained. Undo restores the previous layout.";
    return true;
  }
  function switchScenario(next) {
    code=next;root.active_scenario=code;selected=null;multi.clear();wire=null;drag=null;
    if(!root.diagrams[code]) {
      const eligible=new Set(scenario()?.technologies||[]);
      const nodes=structuredClone(root.nodes.filter(n=>!groups[n.kind]||n.kind==="load"||
        ["bus","substation"].includes(n.kind)||eligible.has(n.kind)));
      const ids=new Set(nodes.map(n=>n.id));
      root.diagrams[code]={enabled:root.enabled,nodes,lines:structuredClone(root.lines.filter(e=>ids.has(e.source)&&ids.has(e.target)))};
    }
    reconcile(diagram(),scenario());
    $("topology-enabled").checked=diagram().enabled;
    $("topology-scenario").value=code;render();properties();palette();fit();inputWorkspace.schedule();
  }
  function palette() {
    const parent=$("topology-palette");parent.replaceChildren();
    for(const kind of [...EXTRA,...schema.technologies.map(([key])=>key)]) {
      const button=document.createElement("button");button.textContent="+ "+name(kind);button.className="secondary";
      if(kind==="shunt")button.title="Shunt capacitor bank (+Mvar) or reactor (-Mvar) connected to a bus";
      button.draggable=true;button.dataset.palette=kind;
      button.disabled=!!scenario()?.reference&&!["load","bus","substation","shunt","grid"].includes(kind);
      button.onclick=()=>add(kind);button.ondragstart=e=>e.dataTransfer.setData("text/plain","genstudio:"+kind);
      parent.append(button);
    }
  }
  function refresh() {
    const definitions=readScenarioRows(), nextSignature=JSON.stringify(definitions);
    if(signature!==nextSignature) {
      signature=nextSignature;
      $("topology-scenario").replaceChildren(...definitions.map(s=>new Option(`${s.id}: ${s.name}`,s.id)));
      if(!definitions.some(s=>s.id===code)) {
        const initial=definitions.find(s=>s.id===root.active_scenario)||definitions.find(s=>!s.reference)||definitions[0];
        if(initial)switchScenario(initial.id);
      }
      $("topology-scenario").value=code;palette();
      // External eligibility edits remove only their terminal; unrelated routed wires survive.
      const graph=diagram();
      if(graph) {
        for(const definition of definitions)if(root.diagrams[definition.id])reconcile(root.diagrams[definition.id],definition);
        render();
      }
    }
    syncMirrors();
  }
  const rotated=node=>{const angle=(node.rotation||0)*Math.PI/180;return [Math.cos(angle),Math.sin(angle)];};
  // A bus is a bar: wires arriving at its top/bottom side land on the bar at the wire's own coordinate and the bar grows
  // to span them, so feeders drop straight onto the busbar instead of converging on its centre.
  function barLanding(edge,end) {
    const graph=diagram(),node=graph.nodes.find(n=>n.id===edge[end]),side=edge[end+"_port"];
    if(node?.kind!=="bus"||!["top","bottom"].includes(side))return null;
    const bends=edge.points||[],otherEnd=end==="source"?"target":"source";
    let neighbour=bends.length?(end==="source"?bends[0]:bends.at(-1)):null;
    if(!neighbour) {
      const other=graph.nodes.find(n=>n.id===edge[otherEnd]);
      if(!other||other.kind==="bus")return null;
      neighbour=port(other,edge[otherEnd+"_port"]);
    }
    const [cx,cy]=rotated(node);
    return Math.round((neighbour.x-node.x)*cx+(neighbour.y-node.y)*cy);
  }
  function barHalf(node) {
    let half=75*(node.scale||.8);
    for(const edge of diagram().lines) {
      for(const end of ["source","target"])if(edge[end]===node.id) {
        const along=barLanding(edge,end);if(along!==null)half=Math.max(half,Math.abs(along)+24);
      }
    }
    return Math.round(half);
  }
  function port(node,side,along=0) {
    const s=node.scale||.8,bus=node.kind==="bus";
    const reach=bus?barHalf(node):70*s,depth=bus?7*s:38*s;
    const vectors={top:[along,-depth],bottom:[along,depth],left:[-reach,0],right:[reach,0]},v=vectors[side]||[0,0];
    const [cos,sin]=rotated(node);
    return {x:Math.round(node.x+v[0]*cos-v[1]*sin),y:Math.round(node.y+v[0]*sin+v[1]*cos)};
  }
  function orthogonal(points,verticalFirst=false) {
    const route=[];
    for(const p of points) {
      const previous=route.at(-1);
      if(previous&&previous.x!==p.x&&previous.y!==p.y)
        route.push(verticalFirst?{x:previous.x,y:p.y}:{x:p.x,y:previous.y});
      if(!previous||previous.x!==p.x||previous.y!==p.y)route.push({...p});
    }
    return route;
  }
  function route(edge) {
    const graph=diagram(),a=graph.nodes.find(n=>n.id===edge.source),b=graph.nodes.find(n=>n.id===edge.target);
    if(!a||!b)return [];
    const start=port(a,edge.source_port,barLanding(edge,"source")||0),end=port(b,edge.target_port,barLanding(edge,"target")||0);
    return orthogonal([start,...(edge.points||[]),end],true);
  }
  const path=points=>points.map((p,i)=>`${i?"L":"M"}${p.x},${p.y}`).join(" ");
  function beginWire(node,side) {
    if(!wire) {wire={source:node.id,source_port:side,points:[]};render();message();return;}
    if(wire.source===node.id){showError("A wire cannot connect a component to itself.");return;}
    const source=diagram().nodes.find(n=>n.id===wire.source);
    if(diagram().lines.some(l=>l.source===source.id&&l.target===node.id||l.source===node.id&&l.target===source.id)) {
      showError("These components are already wired; use Circuits on the existing wire for a parallel circuit.");return;
    }
    for(const end of [source,node])if(end.kind==="shunt"&&diagram().lines.some(l=>l.source===end.id||l.target===end.id)) {
      showError("A shunt connects to exactly one bus; it already has a wire.");return;
    }
    if(source.kind==="shunt"&&node.kind==="shunt"){showError("Wire a shunt to a bus, not to another shunt.");return;}
    remember();
    const owner=[source.kind,node.kind].find(kind=>schema.technologies.some(([key])=>key===kind)&&kind!=="grid")||
      ([source.kind,node.kind].includes("grid")?"grid":"shared");
    const line={id:id("l"),...wire,target:node.id,target_port:side,owner,length_km:0,cost_per_km:0};
    diagram().lines.push(line);
    line.points=route(line).slice(1,-1);
    selected=line.id;wire=null;changed(true);
    const kinds=[kvOf(source),kvOf(node)];
    message();
    if(source.kind!=="shunt"&&node.kind!=="shunt"&&Math.abs(kinds[0]-kinds[1])>1e-9)
      $("topology-message").textContent=`Wire joins ${kvText(kinds[0])} and ${kvText(kinds[1])} buses: it is modelled as a transformer.`;
  }
  function message() {
    $("topology-message").textContent=wire?"Drawing wire: click empty space for corners; click a component port to finish. Escape cancels. Right-click opens wire actions.":
      mode==="wire"?"Wire tool: click a component port to start, click to place corners, then click another port.":
      mode==="pan"?"Pan tool: hold and drag empty canvas to move the view. Use Zoom or Fit to adjust magnification.":
      "Select a component to edit its linked inputs. Hold and drag to move; double-click opens properties. Select a wire to drag its bend/segment handles. Right-click for actions.";
  }
  let multi=new Set();
  function toggleMulti(id) {
    if(!multi.size&&selected&&selected!==id)multi.add(selected);
    if(multi.has(id))multi.delete(id);else multi.add(id);
    selected=multi.size===1?[...multi][0]:null;render();properties();
  }
  function select(key) {multi.clear();selected=key;render();properties();}
  function capture(event,details) {
    event.preventDefault();event.stopPropagation();remember();
    drag={...details,origin:point(event),original:structuredClone(diagram())};
    $("topology-svg").setPointerCapture(event.pointerId);
  }
  function tables() {
    const graph=diagram(),box=$("topology-tables");if(!graph||!box)return;
    const rows=(title,head,items)=>{
      const table=document.createElement("table"),caption=document.createElement("caption");caption.textContent=title;table.append(caption);
      const header=document.createElement("tr");for(const h of head){const th=document.createElement("th");th.textContent=h;header.append(th);}
      table.append(header);
      for(const [key,...cells] of items){
        const tr=document.createElement("tr");tr.tabIndex=0;if(key===selected)tr.className="selected-row";
        for(const c of cells){const td=document.createElement("td");td.textContent=c;tr.append(td);}
        tr.onclick=()=>select(key);table.append(tr);
      }
      return table;
    };
    const label=key=>graph.nodes.find(n=>n.id===key)?.label||key;
    box.replaceChildren(
      rows("Components",["Type","Label","Cost owner"],graph.nodes.map(n=>[n.id,name(n.kind),n.label,n.owner])),
      rows("Branches",["From","To","km","$/km","Cost owner"],
        graph.lines.map(e=>[e.id,label(e.source),label(e.target),e.length_km,e.cost_per_km,e.owner])));
  }
  function newScenario(copy) {
    const rows=readScenarioRows(),ids=new Set(rows.map(s=>s.id));
    let n=1;while(ids.has("S"+n))n++;
    const key="S"+n,source=copy?scenario():null;
    remember();
    const technologies=source&&!source.reference?[...source.technologies]:["grid"];
    addScenario({id:key,name:source?source.name+" copy":"New scenario",technologies});
    refreshScenarioChoices([...$("scenarios").querySelectorAll("input:checked")].map(i=>i.value).concat(key));
    root.diagrams[key]=copy&&diagram()?structuredClone(diagram()):{enabled:false,
      nodes:[component("load",{x:800,y:700}),component("grid",{x:800,y:160})],lines:[]};
    if(copy&&source?.reference)root.diagrams[key]={enabled:false,nodes:[component("load",{x:800,y:700}),component("grid",{x:800,y:160})],lines:[]};
    signature="";refresh();switchScenario(key);edited();
    $("topology-message").textContent=`Scenario ${key} created. Draw or edit its components; eligible technologies follow the drawing.`;
  }
  function deleteScenario() {
    const rows=readScenarioRows(),current=scenario();
    if(!current||current.reference||rows.length<2){showError("The upgraded-grid reference and the last scenario cannot be deleted.");return;}
    remember();
    [...$("scenario-rows").children].find(row=>row.querySelector("[data-key=id]").value===code)?.remove();
    delete root.diagrams[code];code=null;refreshScenarioChoices();signature="";refresh();edited();
  }
  function clearDrawing() {
    const graph=diagram();if(!graph)return;remember();
    graph.autodraw_technologies=[...(scenario()?.technologies||[])];
    for(const node of graph.nodes)if(schema.technologies.some(([key])=>key===node.kind)&&!scenario()?.reference)setTech(node.kind,false);
    graph.nodes=scenario()?.reference?graph.nodes.filter(n=>n.kind==="grid"):[];graph.lines=[];
    selected=null;changed(true);
  }
  function longestSegment(points) {
    let best=0,longest=-1;
    for(let i=0;i<points.length-1;i++) {
      const length=Math.hypot(points[i+1].x-points[i].x,points[i+1].y-points[i].y);
      if(length>longest){longest=length;best=i;}
    }
    return best;
  }
  function wrapLabel(text,limit=14) {
    const lines=[];let current="";
    for(const word of String(text).split(/\s+/).filter(Boolean)) {
      if(current&&(current+" "+word).length>limit){lines.push(current);current=word;}
      else current=current?current+" "+word:word;
    }
    if(current)lines.push(current);
    return lines.slice(0,3);
  }
  // Half width/height of a symbol in its own (unscaled, unrotated) units.
  function symbolHalf(node) {
    if(node.kind==="bus")return [barHalf(node)/(node.scale||.8),6];
    return {substation:[65,36],shunt:[30,38],load:[20,38]}[node.kind]||[35,35];
  }
  // IEC 60617 / IEEE 315 style symbols; all line work uses the CSS classes electrical-symbol (stroke only) and sym-solid (filled).
  function drawSymbol(symbol,node,size) {
    const line=d=>el("path",{d,class:"electrical-symbol"});
    if(node.kind==="bus")
      symbol.append(el("rect",{x:-barHalf(node)/size,y:-6,width:2*barHalf(node)/size,height:12,rx:2,class:`bus-bar ${levelOf(kvOf(node))[1]}`}));
    else if(node.kind==="substation") {
      symbol.append(el("rect",{x:-65,y:-36,width:130,height:72,rx:4}),el("circle",{cx:-13,cy:0,r:22}),el("circle",{cx:13,cy:0,r:22}));
    } else if(node.kind==="shunt") {
      const reactor=(node.electrical?.shunt_mvar??0)<0;
      symbol.append(line(reactor?"M0,-38 L0,-24 a7,7 0 0 1 0,14 a7,7 0 0 1 0,14 a7,7 0 0 1 0,14 L0,18":"M0,-38 L0,-6 M-24,-6 L24,-6 M-24,6 L24,6 M0,6 L0,18"),
        line("M-22,18 L22,18 M-14,26 L14,26 M-6,34 L6,34"));
    } else if(node.kind==="load")
      symbol.append(line("M0,-38 L0,14"),el("path",{d:"M-12,12 L0,36 L12,12 Z",class:"electrical-symbol sym-solid"}));
    else if(node.kind==="bess")
      symbol.append(el("rect",{x:-35,y:-35,width:70,height:70,rx:4}),
        line("M0,-35 L0,-14 M-22,-14 L22,-14 M-22,5 L22,5 M0,14 L0,35"),
        el("path",{d:"M-12,-5 L12,-5 M-12,14 L12,14",class:"electrical-symbol battery-plate"}),
        line("M-28,-26 L-20,-26 M-24,-30 L-24,-22"));
    else if(node.kind==="pv")
      symbol.append(el("rect",{x:-35,y:-35,width:70,height:70}),
        line("M-35,35 L35,-35 M-26,-20 L-8,-20 M-26,-13 L-8,-13 M6,18 q5,-8 10,0 t10,0"));
    else if(node.kind==="wind")
      symbol.append(el("circle",{cx:0,cy:0,r:35}),line("M0,0 L0,-24 M0,0 L20.8,12 M0,0 L-20.8,12"),el("circle",{cx:0,cy:0,r:4,class:"sym-solid"}));
    else if(node.kind==="grid")
      symbol.append(el("circle",{cx:0,cy:0,r:35}),line("M-20,0 q10,-16 20,0 t20,0"));
    else
      symbol.append(el("circle",{cx:0,cy:0,r:35}),el("text",{x:0,y:-8,class:"unit-symbol"},"G"),line("M-12,14 q6,-9 12,0 t12,0"));
  }
  function render() {
    tables();
    if(animationFrame){cancelAnimationFrame(animationFrame);animationFrame=null;}
    const svg=$("topology-svg"), graph=diagram();if(!graph)return;
    const controls=el("g",{class:"wire-controls"});
    svg.replaceChildren();
    const defs=el("defs"),pattern=el("pattern",{id:"diagram-grid",width:20,height:20,patternUnits:"userSpaceOnUse"});
    pattern.append(el("circle",{cx:1,cy:1,r:1,fill:"#c9dce4"}));defs.append(pattern);svg.append(defs);
    svg.classList.toggle("wiring",mode==="wire"||!!wire);
    svg.append(el("rect",{x:0,y:0,width:1600,height:900,fill:"url(#diagram-grid)",class:"diagram-background","data-gs-ui":1}));
    for(const edge of graph.lines) {
      const points=route(edge),g=el("g",{"data-line":edge.id,class:"diagram-edge"+(selected===edge.id||multi.has(edge.id)?" selected":""),tabindex:0,role:"button","aria-label":"Connection wire"});
      const a=graph.nodes.find(n=>n.id===edge.source),b=graph.nodes.find(n=>n.id===edge.target);
      const d=path(points),transformer=!!(a&&b)&&branchKind(edge,a,b)==="transformer"&&a.kind!=="shunt"&&b.kind!=="shunt";
      const seg=points.length>1?longestSegment(points):0,from=points[seg],to=points[seg+1]||from;
      const mid=from?{x:(from.x+to.x)/2,y:(from.y+to.y)/2}:null;
      const levelA=levelOf(kvOf(a?.kind==="shunt"?b:a||{}))[1],levelB=levelOf(kvOf(b||{}))[1];
      if(transformer&&mid) {
        const len=Math.hypot(to.x-from.x,to.y-from.y)||1,ux=(to.x-from.x)/len,uy=(to.y-from.y)/len,gap=Math.min(23,len/2);
        g.append(el("path",{d:path([...points.slice(0,seg+1),{x:mid.x-ux*gap,y:mid.y-uy*gap}]),class:`wire-visible ${levelA}`}),
          el("path",{d:path([{x:mid.x+ux*gap,y:mid.y+uy*gap},...points.slice(seg+1)]),class:`wire-visible ${levelB}`}));
      } else g.append(el("path",{d,class:`wire-visible ${levelA}`}));
      g.append(el("path",{d,class:"edge-hit","data-gs-ui":1}));
      if(mid) {
        const vertical=from.x===to.x;
        if(transformer) {
          const symbol=el("g",{transform:`translate(${mid.x},${mid.y}) rotate(${Math.atan2(to.y-from.y,to.x-from.x)*180/Math.PI})`,class:"xf-symbol"});
          symbol.append(el("circle",{cx:-9,cy:0,r:14,class:`xf-circle ${levelA}`}),el("circle",{cx:9,cy:0,r:14,class:`xf-circle ${levelB}`}));
          g.append(symbol);
          const hv=Math.max(kvOf(a),kvOf(b)),lv=Math.min(kvOf(a),kvOf(b)),rating=edge.electrical?.mva;
          const text=`${numText(hv)}/${numText(lv)} kV`+(rating?` \u00b7 ${numText(rating)} MVA`:"");
          g.append(el("text",vertical?{x:mid.x+26,y:mid.y+5,class:"edge-label edge-label-start"}:{x:mid.x,y:mid.y-24,class:"edge-label"},text));
        } else if(edge.length_km>0)
          g.append(el("text",vertical?{x:mid.x+10,y:mid.y+5,class:"edge-label edge-label-start"}:{x:mid.x,y:mid.y-10,class:"edge-label"},`${numText(edge.length_km)} km`));
      }
      g.onclick=e=>{e.stopPropagation();select(edge.id);};
      g.onkeydown=e=>{if(e.key==="Enter")select(edge.id);};
      g.ondblclick=e=>{e.preventDefault();e.stopPropagation();select(edge.id);openProperties("line",edge.id);};
      g.oncontextmenu=e=>context(e,{type:"line",id:edge.id,p:point(e)});
      svg.append(g);
      if(selected===edge.id) {
        points.slice(1,-1).forEach((p,i)=>{
          const handle=el("rect",{x:p.x-6,y:p.y-6,width:12,height:12,class:"wire-handle","data-bend":i,"data-gs-ui":1});
          handle.onpointerdown=e=>{if(e.button!==0)return;capture(e,{type:"bend",id:edge.id,index:i+1,points});};
          handle.oncontextmenu=e=>context(e,{type:"bend",id:edge.id,index:i+1,p});
          controls.append(handle);
        });
        for(let i=0;i<points.length-1;i++) {
          const a=points[i],b=points[i+1];if(Math.hypot(a.x-b.x,a.y-b.y)<24)continue;
          const handle=el("circle",{cx:(a.x+b.x)/2,cy:(a.y+b.y)/2,r:6,class:"segment-handle","data-segment":i,"data-gs-ui":1});
          handle.onpointerdown=e=>{if(![0,2].includes(e.button))return;capture(e,{type:"segment",id:edge.id,index:i,points});};
          handle.oncontextmenu=e=>e.preventDefault();controls.append(handle);
        }
      }
    }
    for(const node of graph.nodes) {
      const g=el("g",{"data-node":node.id,transform:`translate(${node.x},${node.y})`,class:"diagram-node"+(selected===node.id||multi.has(node.id)?" selected":""),
        tabindex:0,role:"button","aria-label":node.label});
      const size=node.scale||.8,vertical=(node.rotation||0)%180===90,half=symbolHalf(node);
      const [hw,hh]=vertical?[half[1]*size,half[0]*size]:[half[0]*size,half[1]*size];
      g.append(el("rect",{x:-hw-8,y:-hh-8,width:2*hw+16,height:2*hh+16,class:"node-hit","data-gs-ui":1}));
      const symbol=el("g",{transform:`scale(${size}) rotate(${node.rotation||0})`});
      drawSymbol(symbol,node,size);
      g.append(symbol);
      const tag=(typeof pfProps!=="undefined"&&pfProps.numbering(graph)[node.id]);
      const kv=node.kind==="shunt"?node.electrical?.kv:kvOf(node);
      const fontSize=Math.max(15,Math.min(22,22*size)),lines=wrapLabel(node.label).map(text=>({text,size:fontSize,class:"node-label"}));
      if(node.kind==="shunt")lines.push({text:`${numText(node.electrical?.shunt_mvar??0)} Mvar`,size:fontSize*.85,class:"node-sub"});
      if(kv!==undefined)lines.push({text:kvText(kv),size:fontSize*.85,class:"node-sub"});
      if(tag)lines.push({text:`${tag.num} ${tag.name}`,size:fontSize*.8,class:"bus-number-tag"});
      const belowBar=node.kind==="bus"&&!vertical,lead=lines.reduce((sum,l)=>sum+l.size*1.2,0);
      let y=belowBar?hh+8:-lead/2;
      for(const line of lines) {
        y+=line.size*1.2;
        const label=el("text",{x:belowBar?-hw:hw+10,y:y-line.size*.25,class:`${line.class} node-text`},line.text);
        label.style.fontSize=line.size+"px";g.append(label);
      }
      if(selected===node.id) {
        const grip=el("circle",{cx:-70*size,cy:40*size,r:8,class:"resize-handle","data-gs-ui":1});
        grip.onpointerdown=e=>{if(e.button!==0)return;capture(e,{type:"resize",id:node.id});};
        g.append(grip);
      }
      for(const side of ["top","bottom","left","right"]) {
        const p=port(node,side),connection=el("circle",{cx:p.x-node.x,cy:p.y-node.y,r:6,class:"connection-port","data-port":side,"data-gs-ui":1});
        connection.onpointerdown=e=>{
          if(e.button!==0)return;e.preventDefault();e.stopPropagation();
          if(mode==="wire"||wire)beginWire(node,side);else select(node.id);
        };g.append(connection);
      }
      g.onpointerdown=e=>{
        if(e.button!==0)return;
        if(mode==="wire"||wire){e.preventDefault();e.stopPropagation();beginWire(node,"bottom");return;}
        if(e.ctrlKey||e.metaKey){e.preventDefault();e.stopPropagation();toggleMulti(node.id);return;}
        if(multi.size>1&&multi.has(node.id)){capture(e,{type:"group",ids:[...multi]});return;}
        multi.clear();selected=node.id;capture(e,{type:"node",id:node.id});render();properties();
      };
      g.ondblclick=e=>{e.preventDefault();e.stopPropagation();select(node.id);openProperties("node",node.id);};
      g.oncontextmenu=e=>{
        if(e.ctrlKey||e.metaKey){e.preventDefault();e.stopPropagation();toggleMulti(node.id);return;}
        context(e,{type:"node",id:node.id,p:point(e)});
      };
      g.onkeydown=e=>{
        if(e.key==="Enter")select(node.id);
        if(["ArrowLeft","ArrowRight","ArrowUp","ArrowDown"].includes(e.key)){
          e.preventDefault();remember();const p=position({x:node.x+(e.key==="ArrowLeft"?-20:e.key==="ArrowRight"?20:0),
            y:node.y+(e.key==="ArrowUp"?-20:e.key==="ArrowDown"?20:0)});Object.assign(node,p);changed();
        }
      };svg.append(g);
    }
    svg.append(controls);
    if(wire) {
      const a=graph.nodes.find(n=>n.id===wire.source);
      svg.append(el("path",{d:path(orthogonal([port(a,wire.source_port),...wire.points,...(wire.cursor?[wire.cursor]:[])],true)),class:"wire-preview"}));
    }
    document.dispatchEvent(new CustomEvent("topology-render"));
    $("topology-enabled").checked=graph.enabled;
    $("topology-undo").disabled=!undo.length;$("topology-redo").disabled=!redo.length;$("topology-delete").disabled=!selected&&!multi.size;
    renderChecks(graph);
    drawLegend(svg,graph);
    $("topology-connect").classList.toggle("tool-active",mode==="wire");
    $("topology-select").classList.toggle("tool-active",mode==="select");
    $("topology-pan").classList.toggle("tool-active",mode==="pan");
    const totals={};
    for(const edge of graph.lines)totals[edge.owner]=(totals[edge.owner]||0)+edge.length_km*edge.cost_per_km;
    for(const node of graph.nodes)if(node.kind==="substation")totals[node.owner]=(totals[node.owner]||0)+node.capital_cost;
    displayTable("topology-costs",["Scenario cost owner","Route / substation CAPEX $"],
      Object.entries(totals).map(([key,value])=>[key==="shared"?"Shared":name(key),value]));
  }
  function insertBend(edge,p) {
    remember();const points=route(edge);
    let best=0,distance=Infinity;
    for(let i=0;i<points.length-1;i++){
      const a=points[i],b=points[i+1],d=Math.hypot(p.x-Math.max(Math.min(a.x,b.x),Math.min(Math.max(a.x,b.x),p.x)),
        p.y-Math.max(Math.min(a.y,b.y),Math.min(Math.max(a.y,b.y),p.y)));
      if(d<distance){distance=d;best=i;}
    }
    const a=points[best],b=points[best+1],before=points.slice(0,best+1),after=points.slice(best+1);
    const jog=a.x===b.x?[{x:p.x,y:a.y},{x:p.x,y:b.y}]:[{x:a.x,y:p.y},{x:b.x,y:p.y}];
    edge.points=[...before,...jog,...after].slice(1,-1);selected=edge.id;changed(true);
  }
  function syncMirrors() {
    for(const {original,input} of mirrors) {
      input.disabled=original.disabled;
      const label=input.closest("label"),field=schema.fields.find(f=>f.key===original.id);
      label.hidden=original.closest("label")?.hidden||false;
      if(field?.group==="Demand"&&!["start_year","horizon_years","forecast_mode","economic_growth","annualize_partial"].includes(field.key))
        label.hidden=$("demand-workflow").value!=="generate";
      if(original.id==="solar-csv")label.hidden=!$("solar_profile_enabled").checked;
      if(["forecast-csv","combined-csv"].includes(original.id))label.hidden=$("demand-workflow").value==="generate";
      if(input===document.activeElement||input.type==="file")continue;
      if(input.type==="checkbox")input.checked=original.checked;else input.value=original.value;
    }
  }
  function linkedControl(original,parent) {
    if(!original)return;
    const field=schema.fields.find(f=>f.key===original.id),label=document.createElement("label");
    label.textContent=field ? field.label+(field.unit?" ("+field.unit+")":"") :
      original.closest("label")?.childNodes[0]?.textContent?.trim()||original.id;
    const input=original.cloneNode(true);input.removeAttribute("id");input.removeAttribute("hidden");input.dataset.linkedInput=original.id;
    if(original.type==="file"){input.value="";input.multiple=original.multiple;}
    input.addEventListener(input.type==="file"||input.tagName==="SELECT"||input.type==="checkbox"?"change":"input",()=>{
      if(input.type==="file") {
        original.files=input.files;original.dispatchEvent(new Event("change",{bubbles:true}));return;
      }
      if(input.type==="number"&&!input.checkValidity())return;
      if(input.type==="checkbox")original.checked=input.checked;else original.value=input.value;
      original.dispatchEvent(new Event("input",{bubbles:true}));
      if(original.tagName==="SELECT"||original.type==="checkbox")original.dispatchEvent(new Event("change",{bubbles:true}));
    });
    label.append(input);if(field?.note){const hint=document.createElement("small");hint.className="hint";hint.textContent=field.note;label.append(hint);}
    mirrors.push({original,input});parent.append(label);
  }
  function properties() {
    const graph=diagram(),item=graph?.nodes.find(n=>n.id===selected)||graph?.lines.find(e=>e.id===selected);
    const parent=$("topology-properties");parent.replaceChildren();mirrors=[];
    $("topology-property-title").textContent=item?("source" in item?"Wire properties":`${item.label} - linked model inputs`):"Component / wire inspector";
    if(!item){parent.textContent="Select a component or wire. Component parameters are shared with the model input forms, not separate diagram-only copies.";return;}
    const isLine="source" in item, fields=isLine?
      [["source","From","endpoint"],["target","To","endpoint"],["length_km","Physical route length (km)","number"],
        ["cost_per_km","Installed cost ($/km)","number"],["owner","Cost owner","owner"]]:
      [["label","Drawing name","text"],["rotation","Symbol rotation","rotation"],["scale","Symbol size (0.3-3; drag the corner handle)","number"],
        ...(item.kind==="substation"?[["capital_cost","Substation CAPEX ($)","number"],["owner","Cost owner","owner"]]:[])];
    for(const [key,title,type] of fields) {
      const label=document.createElement("label");label.textContent=title;
      const input=document.createElement(["endpoint","owner","rotation"].includes(type)?"select":"input");input.dataset.topologyKey=key;
      if(type==="endpoint")for(const node of graph.nodes)input.add(new Option(node.label,node.id));
      else if(type==="owner")for(const owner of ["shared",...schema.technologies.map(([key])=>key)])input.add(new Option(owner==="shared"?"Shared":name(owner),owner));
      else if(type==="rotation")for(const value of [0,90,180,270])input.add(new Option(String(value),String(value)));
      else {input.type=type;if(type==="number"){input.min=0;input.step="any";}}
      input.value=item[key]??(key==="scale"?.8:0);input.onchange=()=>{
        if(!input.reportValidity())return;
        if(type==="endpoint"&&input.value===item[key==="source"?"target":"source"]){showError("Choose two different endpoints.");input.value=item[key];return;}
        remember();item[key]=type==="number"?input.valueAsNumber:type==="rotation"?Number(input.value):input.value;changed();
      };label.append(input);parent.append(label);
    }
    const pfButton=()=>{
      if(typeof pfProps==="undefined")return;
      const button=document.createElement("button");button.textContent="Power-flow properties...";button.className="secondary";
      button.onclick=()=>openProperties(isLine?"line":"node",item.id);parent.append(button);
    };
    if(isLine) {
      const nodes=diagram().nodes,a=nodes.find(n=>n.id===item.source),b=nodes.find(n=>n.id===item.target);
      const kind=a&&b&&a.kind!=="shunt"&&b.kind!=="shunt"?branchKind(item,a,b):null;
      const note=document.createElement("p");note.className="muted";
      note.textContent=(kind?`Power-flow branch: ${kind} (${kvText(kvOf(a))} to ${kvText(kvOf(b))}). `:"")+
        "Square handles move bends; round handles move entire wire segments left/right or up/down. Double-click a wire to add a jog; right-click a bend to remove it. Physical cost length is independent of drawing length.";
      parent.append(note);pfButton();return;
    }
    const hint=document.createElement("p");hint.className="notice";
    hint.textContent="Changes below update the actual Model inputs immediately, and vice versa. Technology parameters are shared across scenarios; only connections and layout are scenario-specific. Capacities remain optimized, not set by the symbol size.";
    parent.append(hint);
    if(item.kind==="shunt") {
      for(const [key,title,min] of [["shunt_mvar","Shunt Mvar (+ capacitor, - reactor)",-1000],["shunt_steps","Switched steps (0 = fixed)",0],
        ["shunt_step_mvar","Mvar per step",-1000],["kv","Nominal kV",0]]) {
        const label=document.createElement("label");label.textContent=title;
        const input=document.createElement("input");input.type="number";input.step="any";input.min=min;input.dataset.electricalKey=key;
        input.value=item.electrical?.[key]??"";
        input.onchange=()=>{
          if(!input.reportValidity())return;remember();
          const next={...(item.electrical||{})};
          if(input.value==="")delete next[key];else next[key]=input.valueAsNumber;
          item.electrical=next;if(key==="shunt_mvar"&&next.shunt_mvar!==undefined&&/^Shunt (capacitor|reactor)$/.test(item.label))item.label=next.shunt_mvar<0?"Shunt reactor":"Shunt capacitor";
          changed(true);
        };
        label.append(input);parent.append(label);
      }
      pfButton();
      return;
    }
    const group=groups[item.kind];
    const factors={pv:["pv_emissions_t_mwh","pv_life"],wind:["wind_emissions_t_mwh","wind_life"],
      bess:["bess_emissions_t_mwh","bess_life"],grid:["grid_emissions_t_mwh"],
      diesel:["diesel_emissions_t_mmbtu","generator_life"],biogas:["biogas_emissions_t_mmbtu","generator_life"],
      biomass:["biomass_emissions_t_mmbtu","generator_life"],ng:["ng_emissions_t_mmbtu","generator_life"],
      ng_chp:["ng_emissions_t_mmbtu","generator_life"],h2:["h2_emissions_kgco2_kg","generator_life"],
      h2_chp:["h2_emissions_kgco2_kg","generator_life"]};
    for(const field of schema.fields.filter(f=>f.group===group||(factors[item.kind]||[]).includes(f.key)))
      linkedControl($(field.key),parent);
    const uploads={pv:["solar-csv"],wind:["wind-csv"],load:["demand-workflow","historical-csv","forecast-csv","combined-csv"]};
    for(const key of uploads[item.kind]||[])linkedControl($(key),parent);
    if(item.kind==="load") {
      const button=document.createElement("button");button.textContent="Open demand milestones and profile options";button.className="secondary";
      button.onclick=()=>inputWorkspace.openGroup("Demand");parent.append(button);
    }
    pfButton();
    syncMirrors();
  }
  function context(event,target) {
    event.preventDefault();event.stopPropagation();
    if(target.id){selected=target.id;render();properties();}
    const menu=$("topology-context");menu.replaceChildren();
    const actions=[["Power-flow properties...",()=>openProperties(target.type==="line"?"line":"node",target.id)],
      ["Edit properties",()=>{properties();$("topology-inspector").scrollIntoView({block:"nearest"});}]];
    if(target.type==="canvas")actions.shift();
    if(target.type==="canvas"||target.type==="bend")actions.unshift(["Power-flow settings...",()=>openProperties("settings")]);
    if(target.type==="node")actions.push(["Rotate 90 degrees",()=>{remember();const n=diagram().nodes.find(n=>n.id===target.id);n.rotation=((n.rotation||0)+90)%360;changed(true);}]);
    if(target.type==="line")actions.push(["Add wire bend / jog",()=>insertBend(diagram().lines.find(e=>e.id===target.id),target.p)]);
    if(target.type==="bend")actions.push(["Remove bend",()=>{remember();const edge=diagram().lines.find(e=>e.id===target.id),points=route(edge);points.splice(target.index,1);edge.points=points.slice(1,-1);changed(true);}]);
    if(target.id)actions.push(["Delete selected",remove]);
    if(wire)actions.push(["Cancel wire",()=>{wire=null;render();message();}]);
    for(const [title,action] of actions){const button=document.createElement("button");button.textContent=title;button.onclick=()=>{menu.hidden=true;action();};menu.append(button);}
    menu.style.left=Math.min(event.clientX,window.innerWidth-240)+"px";
    menu.style.top=Math.min(event.clientY,window.innerHeight-230)+"px";menu.hidden=false;
  }
  function remove() {
    if(multi.size>1) {
      remember();const ids=new Set(multi),graph=diagram();
      for(const node of graph.nodes.filter(n=>ids.has(n.id)))if(!setTech(node.kind,false))ids.delete(node.id);
      graph.nodes=graph.nodes.filter(n=>!ids.has(n.id));
      graph.lines=graph.lines.filter(e=>!ids.has(e.id)&&!ids.has(e.source)&&!ids.has(e.target));
      multi.clear();selected=null;changed(true);return;
    }
    if(!selected)return;const graph=diagram(),node=graph.nodes.find(n=>n.id===selected);
    remember();
    if(node&&!setTech(node.kind,false)){undo.pop();return;}
    graph.nodes=graph.nodes.filter(n=>n.id!==selected);
    graph.lines=graph.lines.filter(e=>e.id!==selected&&e.source!==selected&&e.target!==selected);
    selected=null;changed(true);
  }
  function fit() {
    const box=contentBounds(diagram());
    $("topology-svg").setAttribute("viewBox",box?`${box.x} ${box.y} ${box.w} ${box.h}`:"0 0 1600 900");
  }
  // Bounds of nodes plus label margins; the legend sits in the top-left corner inside this box.
  function contentBounds(graph) {
    const nodes=graph?.nodes||[];if(!nodes.length)return null;
    const x0=Math.min(...nodes.map(n=>n.x))-150,y0=Math.min(...nodes.map(n=>n.y))-100;
    const x1=Math.max(...nodes.map(n=>n.x))+260,y1=Math.max(...nodes.map(n=>n.y))+150;
    const w=Math.max(700,x1-x0),h=Math.max(450,y1-y0);
    return {x:x0,y:y0,w,h};
  }
  function drawLegend(svg,graph) {
    svg.querySelector(".kv-legend")?.remove();
    const box=contentBounds(graph);if(!box)return;
    const used=new Map();
    for(const node of graph.nodes)if(node.kind!=="shunt"){const level=levelOf(kvOf(node));used.set(level[1],level[2]);}
    if(!used.size)return;
    const g=el("g",{class:"kv-legend",transform:`translate(${box.x+16},${box.y+16})`});
    let y=0;
    for(const [cls,text] of used) {
      g.append(el("rect",{x:0,y:y,width:26,height:8,class:`legend-swatch ${cls}`}),el("text",{x:34,y:y+9,class:"legend-text"},text));
      y+=22;
    }
    svg.append(g);
  }
  function zoom(factor) {
    const b=$("topology-svg").viewBox.baseVal, w=Math.max(300,Math.min(3200,b.width*factor)),h=w*b.height/b.width;
    $("topology-svg").setAttribute("viewBox",`${b.x+(b.width-w)/2} ${b.y+(b.height-h)/2} ${w} ${h}`);
  }
  function travel(from,to) {
    if(!from.length)return;to.push(snapshot());
    const saved=JSON.parse(from.pop());root=saved.root;code=saved.code;signature="";
    $("scenario-rows").replaceChildren();for(const row of saved.scenarios)addScenario(row);
    refreshScenarioChoices(saved.selectedScenarios);selected=null;wire=null;refresh();
    changed(true);
  }
  function init() {
    $("topology-scenario").onchange=()=>{switchScenario($("topology-scenario").value);edited();};
    $("topology-autodraw").onclick=()=>autoDraw();
    $("topology-new").onclick=()=>newScenario(false);$("topology-duplicate").onclick=()=>newScenario(true);
    $("topology-delete-scenario").onclick=deleteScenario;$("topology-clear").onclick=clearDrawing;
    $("topology-enabled").onchange=()=>{remember();diagram().enabled=$("topology-enabled").checked;changed();};
    $("topology-select").onclick=()=>{mode="select";wire=null;render();message();};
    $("topology-pan").onclick=()=>{mode="pan";wire=null;render();message();};
    $("topology-connect").onclick=()=>{mode=mode==="wire"?"select":"wire";wire=null;render();message();};
    $("topology-undo").onclick=()=>travel(undo,redo);$("topology-redo").onclick=()=>travel(redo,undo);
    $("topology-sync").onclick=()=>{for(const kind of ["load",...(scenario()?.technologies||[])])if(!diagram().nodes.some(n=>n.kind===kind))add(kind);};
    $("topology-fit").onclick=fit;$("topology-delete").onclick=remove;
    $("topology-zoom-in").onclick=()=>zoom(.8);$("topology-zoom-out").onclick=()=>zoom(1.25);
    const svg=$("topology-svg");
    svg.addEventListener("pointerdown",e=>{
      if(mode!=="pan"&&e.button!==1)return;
      e.preventDefault();e.stopPropagation();const box=svg.viewBox.baseVal;
      drag={type:"pan",clientX:e.clientX,clientY:e.clientY,view:[box.x,box.y,box.width,box.height],
        rect:svg.getBoundingClientRect()};svg.setPointerCapture(e.pointerId);
    },true);
    svg.ondragover=e=>e.preventDefault();svg.ondrop=e=>{
      e.preventDefault();const kind=e.dataTransfer.getData("text/plain").replace("genstudio:","");
      if([...EXTRA,...schema.technologies.map(([key])=>key)].includes(kind))add(kind,point(e));
    };
    svg.onpointerdown=e=>{
      if(e.button!==0&&e.button!==1)return;
      if(e.target.classList.contains("diagram-background")) {
        if(wire){wire.points.push(point(e));wire.cursor=null;render();}
        else if(mode==="select") {
          e.preventDefault();const origin=raw(e),additive=e.ctrlKey||e.metaKey||e.shiftKey;
          if(!additive){multi.clear();selected=null;render();properties();}
          drag={type:"marquee",origin,current:origin,additive,base:new Set(multi)};svg.setPointerCapture(e.pointerId);
        } else {multi.clear();selected=null;render();properties();}
      }
    };
    svg.addEventListener("wheel",e=>{
      e.preventDefault();const b=svg.viewBox.baseVal,p=raw(e),factor=e.deltaY<0?.87:1.15;
      const w=Math.max(200,Math.min(6400,b.width*factor)),h=w*b.height/b.width,k=w/b.width;
      svg.setAttribute("viewBox",`${p.x-(p.x-b.x)*k} ${p.y-(p.y-b.y)*k} ${w} ${h}`);
    },{passive:false});
    svg.onpointermove=e=>{
      if(drag?.type==="marquee") {
        drag.current=raw(e);svg.querySelector(".marquee")?.remove();
        const x=Math.min(drag.origin.x,drag.current.x),y=Math.min(drag.origin.y,drag.current.y);
        svg.append(el("rect",{x,y,width:Math.abs(drag.current.x-drag.origin.x),height:Math.abs(drag.current.y-drag.origin.y),class:"marquee"}));return;
      }
      if(drag?.type==="group") {
        const q=point(e),step=v=>Math.round(v/20)*20,ids=new Set(drag.ids),graph=diagram();
        const members=[...drag.original.nodes.filter(n=>ids.has(n.id)),...drag.original.lines.filter(l=>ids.has(l.source)&&ids.has(l.target)).flatMap(l=>l.points||[])];
        const bound=(v,key,max)=>Math.max(20-Math.min(...members.map(m=>m[key])),Math.min(max-Math.max(...members.map(m=>m[key])),step(v)));
        const sx=bound(q.x-drag.origin.x,"x",1580),sy=bound(q.y-drag.origin.y,"y",880);
        for(const node of graph.nodes.filter(n=>ids.has(n.id))) {
          const old=drag.original.nodes.find(n=>n.id===node.id);node.x=old.x+sx;node.y=old.y+sy;
        }
        for(const edge of graph.lines) {
          if(!ids.has(edge.source)||!ids.has(edge.target))continue;
          const old=drag.original.lines.find(l=>l.id===edge.id);
          edge.points=(old.points||[]).map(pt=>({x:pt.x+sx,y:pt.y+sy}));
        }
        if(!animationFrame)animationFrame=requestAnimationFrame(()=>{animationFrame=null;render();});return;
      }
      if(drag?.type==="pan") {
        const [x,y,w,h]=drag.view,scale=Math.max(w/drag.rect.width,h/drag.rect.height);
        svg.setAttribute("viewBox",`${x-(e.clientX-drag.clientX)*scale} ${y-(e.clientY-drag.clientY)*scale} ${w} ${h}`);return;
      }
      const p=point(e);
      if(wire&&!drag){
        wire.cursor=p;
        const a=diagram().nodes.find(n=>n.id===wire.source);
        svg.querySelector(".wire-preview")?.setAttribute("d",path(orthogonal([port(a,wire.source_port),...wire.points,p],true)));
        return;
      }
      if(!drag)return;
      const dx=p.x-drag.origin.x,dy=p.y-drag.origin.y;
      if(drag.type==="resize") {
        const node=diagram().nodes.find(n=>n.id===drag.id),r=svg.createSVGPoint();r.x=e.clientX;r.y=e.clientY;
        const q=r.matrixTransform(svg.getScreenCTM().inverse());
        node.scale=Math.max(.3,Math.min(3,Math.round(Math.hypot(q.x-node.x,q.y-node.y)/80.6*20)/20));
      } else if(drag.type==="node") {
        const old=drag.original.nodes.find(n=>n.id===drag.id),node=diagram().nodes.find(n=>n.id===drag.id);
        Object.assign(node,position({x:old.x+dx,y:old.y+dy}));
      } else {
        const points=structuredClone(drag.points),edge=diagram().lines.find(e=>e.id===drag.id),i=drag.index;
        if(drag.type==="bend")points[i]=p;
        else {
          const a=points[i],b=points[i+1];
          if(a.x===b.x){a.x=snap(a.x+dx);b.x=snap(b.x+dx);}else {a.y=position({x:0,y:a.y+dy}).y;b.y=a.y;}
          if(i===0)points.unshift(drag.points[0]);
          if(i===drag.points.length-2)points.push(drag.points.at(-1));
        }
        edge.points=points.slice(1,-1);
      }
      if(!animationFrame)animationFrame=requestAnimationFrame(()=>{animationFrame=null;render();});
    };
    svg.onpointerup=()=>{
      if(drag?.type==="marquee") {
        const x1=Math.min(drag.origin.x,drag.current.x),x2=Math.max(drag.origin.x,drag.current.x),
          y1=Math.min(drag.origin.y,drag.current.y),y2=Math.max(drag.origin.y,drag.current.y),graph=diagram(),
          moved=Math.hypot(x2-x1,y2-y1)>6;
        const found=new Set(drag.additive?drag.base:[]);
        if(moved) {
          const hit=(ax,ay,bx,by)=>{ // segment touches rectangle (Liang-Barsky)
            let t0=0,t1=1;const dx=bx-ax,dy=by-ay;
            for(const [p,q] of [[-dx,ax-x1],[dx,x2-ax],[-dy,ay-y1],[dy,y2-ay]]) {
              if(p===0){if(q<0)return false;continue;}
              const r=q/p;if(p<0){if(r>t1)return false;t0=Math.max(t0,r);}else{if(r<t0)return false;t1=Math.min(t1,r);}
            }
            return true;
          };
          for(const n of graph.nodes) {
            const s=n.scale||.8,half=Math.abs((n.rotation||0)%180)===90?[40*s,75*s]:[75*s,40*s];
            if(n.x+half[0]>=x1&&n.x-half[0]<=x2&&n.y+half[1]>=y1&&n.y-half[1]<=y2)found.add(n.id);
          }
          for(const edge of graph.lines) {
            const pts=route(edge);
            for(let i=0;i<pts.length-1;i++)if(hit(pts[i].x,pts[i].y,pts[i+1].x,pts[i+1].y)){found.add(edge.id);break;}
          }
        }
        multi.clear();for(const key of found)multi.add(key);
        drag=null;
        if(multi.size===1){selected=[...multi][0];multi.clear();}else selected=null;
        render();properties();return;
      }
      if(drag){const pan=drag.type==="pan";drag=null;if(!pan)changed();}
    };
    svg.onpointercancel=svg.onpointerup;
    svg.oncontextmenu=e=>{if(!drag)context(e,{type:"canvas",p:point(e)});else e.preventDefault();};
    document.addEventListener("pointerdown",event=>{if(!$("topology-context").contains(event.target))$("topology-context").hidden=true;});
    document.addEventListener("input",syncMirrors);
    svg.onkeydown=e=>{
      const accel=e.ctrlKey||e.metaKey;
      if(e.key==="Escape"){wire=null;mode="select";multi.clear();render();message();}
      if(e.key==="Delete"){e.preventDefault();remove();}
      if(accel&&!e.shiftKey&&e.key.toLowerCase()==="z"){e.preventDefault();travel(undo,redo);}
      if(accel&&(e.key.toLowerCase()==="y"||e.shiftKey&&e.key.toLowerCase()==="z")){e.preventDefault();travel(redo,undo);}
    };
    const link=document.createElement("link");link.rel="stylesheet";link.href="/topology.css";document.head.append(link);
    for(const [format,text] of [["png","Export PNG"],["svg","Export SVG"]]) {
      const button=document.createElement("button");button.id=`topology-export-${format}`;button.className="secondary";button.textContent=text;
      button.title=format==="png"?"Download the drawing as a 3x resolution PNG":"Download the drawing as a vector SVG";
      button.onclick=()=>exportDrawing(format);
      $("topology-delete").after(button);
    }
    refresh();message();
  }
  // The exported image shows the whole drawing without selection or editing handles, whatever the current zoom.
  async function exportDrawing(format) {
    const graph=diagram(),box=contentBounds(graph);
    if(!graph||!box){showError("Nothing to export: the scenario has no drawing.");return;}
    const svg=$("topology-svg"),view=svg.getAttribute("viewBox"),keep=[selected,new Set(multi)];
    selected=null;multi.clear();render();
    svg.setAttribute("viewBox",`${box.x} ${box.y} ${box.w} ${box.h}`);
    drawLegend(svg,graph);
    const title=`${scenario()?.name||code} - single-line diagram`,file=`single_line_diagram_${String(code).toLowerCase()}`;
    try {
      if(format==="svg")GS.download(new Blob([GS.svgString(svg,title)],{type:"image/svg+xml"}),file+".svg");
      else GS.download(await new Promise(done=>GS.svgToCanvas(svg,3,title).toBlob(done,"image/png")),file+".png");
    } finally {
      svg.setAttribute("viewBox",view);[selected]=keep;multi=keep[1];render();
    }
  }
  function openProperties(kind,itemId) {
    if(typeof pfProps==="undefined"||!code)return;
    pfProps.open({kind,id:itemId,scenario:code});
  }
  function item(scenarioCode,itemId) {
    const graph=root.diagrams[scenarioCode]||(scenarioCode===code?diagram():null);
    return graph?{graph,item:graph.nodes.find(n=>n.id===itemId)||graph.lines.find(e=>e.id===itemId)}:{};
  }
  return {init,refresh,
    autodraw:(scenarioCode,options)=>{if(scenarioCode&&scenarioCode!==code)switchScenario(scenarioCode);const ok=autoDraw(options||{});if(ok)edited();return ok;},
    cleanElectrical:(scenarioCode,itemId,values)=>{const graph=(root.diagrams[scenarioCode]||(scenarioCode===code?diagram():null));return graph?cleanElectrical(graph,itemId,values):null;},
    hasDrawing:scenarioCode=>{const graph=root.diagrams[scenarioCode]||(scenarioCode===code?diagram():null);return !!(graph&&graph.nodes.length);},
    component:(scenarioCode,itemId)=>{const found=item(scenarioCode,itemId).item;return found?structuredClone(found):null;},
    graph:scenarioCode=>{const graph=root.diagrams[scenarioCode]||(scenarioCode===code?diagram():null);return graph?structuredClone(graph):null;},
    // patch: {label?, length_km?, electrical?: {key: value | null (remove)}}
    updateComponent:(scenarioCode,itemId,patch)=>{
      const found=item(scenarioCode,itemId).item;if(!found)return false;
      if(patch.electrical&&!("source" in found)) {
        const checked=cleanElectrical(item(scenarioCode,itemId).graph,itemId,patch.electrical);
        if(checked.rejected.length){showError(checked.rejected.join(" "));return false;}
        if(checked.notes.length)$("topology-message").textContent=checked.notes.join(" ");
        patch={...patch,electrical:checked.out};
      }
      remember();
      if(typeof patch.label==="string"&&patch.label.trim())found.label=patch.label.trim().slice(0,120);
      if(Number.isFinite(patch.length_km)&&"source" in found)found.length_km=patch.length_km;
      if(patch.electrical){
        const next={...(found.electrical||{})};
        for(const [key,value] of Object.entries(patch.electrical))if(value===null||value===undefined)delete next[key];else next[key]=value;
        if(Object.keys(next).length)found.electrical=next;else delete found.electrical;
      }
      if(scenarioCode===code){render();properties();}edited();return true;
    },
    settings:scenarioCode=>{const graph=root.diagrams[scenarioCode]||(scenarioCode===code?diagram():null);return structuredClone(graph?.pf_settings||{});},
    setSettings:(scenarioCode,patch)=>{
      const graph=root.diagrams[scenarioCode]||(scenarioCode===code?diagram():null);if(!graph)return false;
      remember();const next={...(graph.pf_settings||{})};
      for(const [key,value] of Object.entries(patch||{}))if(value===null||value===undefined)delete next[key];else next[key]=value;
      if(Object.keys(next).length)graph.pf_settings=next;else delete graph.pf_settings;
      if(scenarioCode===code)render();edited();return true;
    },
    setElectrical:(scenarioCode,patch)=>{
      const graph=root.diagrams[scenarioCode]||(scenarioCode===code?diagram():null);if(!graph)return false;
      for(const [list,key] of [["nodes","nodes"],["lines","lines"]])for(const [itemId,values] of Object.entries(patch?.[key]||{})){
        const item=graph[list].find(x=>x.id===itemId);
        if(item&&list==="nodes"){const checked=cleanElectrical(graph,itemId,values);if(checked.rejected.length)showError(checked.rejected.join(" "));
          if(checked.notes.length)$("topology-message").textContent=checked.notes.join(" ");Object.assign(values,checked.out);
          for(const key of ["bus_number","bus_name"])if(key in values&&!(key in checked.out))delete values[key];}
        if(item)item.electrical={...(item.electrical||{}),...values};
      }
      if(scenarioCode===code){render();properties();}edited();return true;
    },
    setDiagram:(scenarioCode,graph)=>{
      if(!graph||!Array.isArray(graph.nodes)||!Array.isArray(graph.lines))return false;
      const old=root.diagrams[scenarioCode]||(scenarioCode===code?diagram():null);
      remember();const next=structuredClone(graph);
      if(old?.pf_settings&&!next.pf_settings)next.pf_settings=old.pf_settings;
      if(old&&"enabled" in old)next.enabled=old.enabled;
      root.diagrams[scenarioCode]=next;
      signature="";if(scenarioCode===code){render();properties();}edited();return true;
    },
    geometry:()=>{const graph=diagram();return graph?{code,nodes:graph.nodes.map(n=>({...n})),lines:graph.lines.map(l=>({id:l.id,source:l.source,target:l.target,route:route(l)}))}:null;},
    renameScenario:(previous,next)=>{
      if(!next||next===previous)return true;
      if(root.diagrams[next]){showError("That scenario ID already has a saved drawing. Use a unique ID.");return false;}
      if(root.diagrams[previous]){root.diagrams[next]=root.diagrams[previous];delete root.diagrams[previous];}
      if(code===previous){code=next;root.active_scenario=next;}signature="";return true;
    },
    value:()=>{const out=structuredClone(root);out.active_scenario=code;return out;},
    restore:value=>{
      root=structuredClone(value||{enabled:false,nodes:[],lines:[]});root.diagrams??={};code=null;
      selected=null;multi.clear();wire=null;undo=[];redo=[];signature="";refresh();properties();
    }};
})();
