"use strict";
// Reliability pane (ANALYZE > Reliability): hour-by-hour N-1 contingency simulation, downtime cost and mitigations.
const reliabilityUi = (() => {
  const el = (tag, text, cls) => node(tag, text, cls);
  const G = () => window.GS;
  const pane = () => analysisTabs.pane("reliability");
  let built = false, info = null, data = null, loadedRun = null, failedRun = null, busy = false, pollTimer = null;
  const FIELDS = ["voll", "outage_hours", "grid_for", "gen_for", "bess_for", "pv_for", "derate_remaining_pct",
    "gen_units", "critical_fraction", "start", "soc_start"];

  const money = v => {
    if (v == null) return "-";
    const a = Math.abs(v) * currencyUi.fx(), f = (x, d) => Number(x).toLocaleString(undefined, {maximumFractionDigits: d, minimumFractionDigits: 0}), p = currencyUi.prefix(), w = v * currencyUi.fx();
    return a >= 999995 ? `${p}${f(w / 1e6, 2)}M` : a >= 1e3 ? `${p}${f(w / 1e3, 1)}k` : `${p}${f(w, 0)}`;
  };
  const num = (v, d = 1) => v == null ? "-" : Number(v).toLocaleString(undefined, {maximumFractionDigits: d, minimumFractionDigits: 0});
  const badge = v => el("span", v, `rel-badge rel-${String(v).toLowerCase()}`);
  const verdictText = d => {
    if (!d || typeof d !== "object") return d || "";
    const parts = [];
    if (d.lole_h_yr != null) parts.push(`LOLE ${num(d.lole_h_yr, 2)} h/yr`);
    if (d.local_n1_secure != null) parts.push(`local N-1 ${d.local_n1_secure ? "secure" : "not secure"}`);
    if (d.grid_n1_secure != null) parts.push(`grid N-1 ${d.grid_n1_secure ? "secure" : "not secure"}`);
    return parts.join("; ");
  };

  function table(headers, rows) {
    const t = el("table", undefined, "sens-table"), h = el("tr");
    for (const x of headers) h.append(el("th", x));
    t.append(h);
    for (const r of rows) {
      const tr = el("tr");
      for (const c of r) { const td = el("td"); if (c instanceof Node) td.append(c); else td.textContent = c; tr.append(td); }
      t.append(tr);
    }
    return t;
  }

  function explain() {
    const d = el("details", undefined, "callout rel-how"); d.open = true;
    d.append(el("summary", "How the contingencies are run (plain language)"));
    const ol = el("ol");
    for (const s of info.method) ol.append(el("li", s));
    d.append(ol, el("p", "Verdict criteria: " + info.criteria, "hint"));
    const a = el("details"); a.append(el("summary", "Assumptions and caveats"));
    const ul = el("ul"); for (const s of info.assumptions) ul.append(el("li", s)); a.append(ul);
    d.append(a);
    return d;
  }

  function field(key) {
    const lab = info.labels[key], l = el("label", `${lab.label} (${lab.unit}) `);
    const i = el("input"); i.id = "rel-" + key; i.className = "narrow";
    if (key === "soc_start") {
      const s = el("select"); s.id = i.id;
      for (const o of ["stored", "full"]) s.append(new Option(o, o));
      l.append(s); return l;
    }
    i.type = key === "start" ? "text" : "number"; i.step = "any";
    const dv = info.defaults[key]; i.value = dv == null ? "" : dv;
    if (key === "start") i.placeholder = "optional, e.g. 2030-07-15 14:00";
    l.append(i); return l;
  }

  function build() {
    const root = pane();
    const head = el("div");
    root.replaceChildren(el("h2", "Reliability: contingency (N-1) simulation"), head);
    const bar = el("div", undefined, "sens-controls");
    const sl = el("label", "Detail for "), sel = el("select"); sel.id = "rel-scenario"; sl.append(sel);
    sel.onchange = renderDetail;
    const go = el("button", "Run contingency simulation"); go.id = "rel-run"; go.type = "button"; go.onclick = () => run(true);
    bar.append(sl, ...FIELDS.map(field), go);
    const status = el("p", "", "hint"); status.id = "rel-status";
    const out = el("div"); out.id = "rel-results";
    head.append(explain());
    root.append(bar, status, out);
    window.workflowUi?.hint(root);
    built = true;
  }

  function params() {
    const p = {};
    for (const k of FIELDS) {
      const v = byId("rel-" + k).value;
      if (v === "") continue;
      p[k] = ["start", "soc_start"].includes(k) ? v : Number(v);
    }
    return p;
  }

  function setStatus(t) { const s = byId("rel-status"); if (s) s.textContent = t || ""; }

  async function run(force) {
    if (busy) return;
    const run_id = typeof solveRun !== "undefined" ? solveRun : null;
    if (!run_id) { setStatus("Run SOLVE first; the simulation replays a saved solve."); return; }
    busy = true; byId("rel-run").disabled = true; setStatus("Simulating every outage start for every scenario...");
    try {
      data = await fetchJson("/api/x/reliability", {method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({run_id, scenario: "all", ...params()})});
      loadedRun = run_id; failedRun = null; setStatus(""); render();
    } catch (e) { failedRun = run_id; setStatus(""); showError(e.message); }
    finally { busy = false; byId("rel-run").disabled = false; }
  }

  async function load() {
    if (!built) {
      try { info = await fetchJson("/api/x/reliability_info"); } catch (e) { showError(e.message); return; }
      build();
    }
    const run_id = typeof solveRun !== "undefined" ? solveRun : null;
    if (!run_id) { setStatus("Run SOLVE first; the simulation replays a saved solve."); return; }
    if (run_id === loadedRun && data) return;
    try {
      const s = await fetchJson(`/api/x/reliability_saved?run_id=${encodeURIComponent(run_id)}`);
      if (s.results.length) { data = s; loadedRun = run_id; render(); return; }
    } catch (e) { /* fall through to a fresh run */ }
    data = null; byId("rel-results").replaceChildren();
    await run(false);
  }

  function pageVisible() { const p = pane(), v = byId("view-analyze"); return !!p && !p.hidden && !!v && !v.hidden; }

  function comparison() {
    const rows = data.comparison.map(c => [c.scenario + " " + (c.name || ""), badge(c.verdict), num(c.lole_h_yr), num(c.eue_mwh_yr, 0),
      num(c.load_served_pct, 3) + "%", num(c.interruptions_yr), money(c.cost_yr), money(c.cost_pv),
      c.worst_event ? `${c.worst_event.name}: ${num(c.worst_event.mwh, 0)} MWh` : "-", c.best_measure || "-"]);
    return table(["Scenario", "Verdict", "Downtime h/yr", "Unserved MWh/yr", "Load served", "Interruptions/yr", "Cost/yr", "Cost PV",
      "Worst event", "Best measure"], rows);
  }

  function render() {
    const sel = byId("rel-scenario"), keep = sel.value;
    sel.replaceChildren(...data.results.map(r => new Option(`${r.scenario} - ${r.name}`, r.scenario)));
    const rec = window.workflowUi?.recommendedCode();
  if (data.results.some(r => r.scenario === keep)) sel.value = keep;
  else if (data.results.some(r => r.scenario === rec)) sel.value = rec;
    const out = byId("rel-results"), v = data.results[0]?.params?.voll;
    out.replaceChildren(el("h3", `All scenarios (VOLL ${money(v)}/MWh = $${num(v / 1000, 2)}/kWh)`), comparison(), data.comparison.length > 1 ? scenarioCharts() : el("div"), el("div"));
    out.lastChild.id = "rel-detail";
    renderDetail();
  }

  // Money scaled to the largest value so tick labels and bar labels stay short ($, $ thousand or $ million).
  const moneyScale = max => max >= 1e6 ? {div: 1e6, unit: "$ million", short: "M"} : max >= 1e3 ? {div: 1e3, unit: "$ thousand", short: "k"} : {div: 1, unit: "$", short: ""};
  const moneyLabel = (sc, v) => `${currencyUi.prefix()}${G().fmt(v * currencyUi.fx() / sc.div, 2)}${sc.short}`;
  const wrapCharts = charts => { const box = document.createElement("div"); box.className = charts.length > 1 ? "gs-grid" : "gs-single"; for (const c of charts) box.append(c.el); return box; };

  function barChart(rows) {
    const g = G(), list = rows.slice().sort((a, b) => b.cost_yr - a.cost_yr), sc = moneyScale(Math.max(1, ...list.map(r => r.cost_yr)));
    const cats = list.map(r => ({key: r.name, label: r.name, color: r.cost_yr > 0 ? "#C0392B" : "#3F9E5A",
      notes: [`Lost capacity ${g.fmt(r.lost_mw, 2)} MW, ${g.fmt(r.events_per_year, 2)} events/yr`, `Downtime ${g.fmt(r.downtime_h_yr, 2)} h/yr`,
        `Unserved energy ${g.fmt(r.eue_mwh_yr, 2)} MWh/yr`, `Worst outage ${g.fmt(r.worst_all_years_mwh, 1)} MWh`]}));
    const h = 170 + 36 * list.length;
    const cost = g.chart({kind: "bars", horizontal: true, valueLabels: true, title: "Downtime cost by contingency", filename: "reliability_downtime_cost",
      subtitle: "Expected value of lost load per year for every single outage tested (N-1).", xTitle: `Expected downtime cost (${sc.unit} per year)`, unit: sc.unit + "/yr",
      catTitle: "Contingency", categories: cats, height: h, vFmt: v => g.fmt(v, 3),
      series: [{key: "cost", label: "Downtime cost", color: "#C0392B", values: list.map(r => r.cost_yr / sc.div)}],
      barLabel: (v, s, i) => `${moneyLabel(sc, list[i].cost_yr)}/yr · ${g.fmt(list[i].downtime_h_yr, 2)} h/yr`,
      legendItems: [{label: "Causes unserved load", color: "#C0392B"}, {label: "No unserved load", color: "#3F9E5A"}]});
    const hours = g.chart({kind: "bars", horizontal: true, valueLabels: true, title: "Downtime by contingency (LOLE-style)", filename: "reliability_downtime_hours",
      subtitle: "Hours per year with unserved load.", xTitle: "Downtime (hours per year)", unit: "h/yr", catTitle: "Contingency",
      categories: cats, height: h, vFmt: v => g.fmt(v, 2), series: [{key: "h", label: "Downtime (h/yr)", color: "#E08A1E", values: list.map(r => r.downtime_h_yr)}]});
    const eens = g.chart({kind: "bars", horizontal: true, valueLabels: true, title: "Expected unserved energy (EENS) by contingency", filename: "reliability_eens",
      subtitle: "Energy not served per year.", xTitle: "Unserved energy (MWh per year)", unit: "MWh/yr", catTitle: "Contingency",
      categories: cats, height: h, vFmt: v => g.fmt(v, 2), series: [{key: "e", label: "Unserved energy (MWh/yr)", color: "#8E6BBF", values: list.map(r => r.eue_mwh_yr)}]});
    return [wrapCharts([cost]), wrapCharts([hours, eens])];
  }

  function windowChart(rows, worst, r) {
    const g = G(), WIN = [["pv_wind_mw", "PV / wind", g.techColor("pv")], ["grid_mw", "Grid", g.techColor("grid")], ["gen_mw", "Generators", "#D1603D"],
      ["bess_discharge_mw", "Battery discharge", g.techColor("bess")], ["shed_mw", "Shed (non-critical) load", "#B05A9C"], ["unserved_mw", "Unserved load", g.techColor("unserved")]];
    const series = WIN.map(([k, label, color]) => ({key: k, label, color, values: rows.map(x => x[k] || 0)})).filter(s => s.values.some(v => v > 1e-9));
    const hour = (t, i) => { const h = t.slice(11, 13) + "h"; return i === 0 || h === "00h" ? `${t.slice(5, 10)} ${h}` : h; };
    return g.chart({kind: "bars", stack: true, thinLabels: true, title: `Worst outage window: ${worst.name}`, filename: "reliability_worst_window",
      subtitle: `${r.scenario}: ${r.params.outage_hours} h outage starting ${worst.worst_event_start}. Bars show what supplies the load each hour; the line is demand.`,
      xTitle: "Hour of the outage window (local planning clock)", yTitle: "Power (MW)", unit: "MW", catTitle: "Hour", height: 420, vFmt: v => g.fmt(v, 3),
      categories: rows.map((x, i) => ({key: x.timestamp, label: hour(x.timestamp, i), notes: [x.timestamp.replace("T", " ")]})), series,
      lines: [{key: "load", label: "Load", color: "#173441", values: rows.map(x => x.load_mw)}]});
  }

  function mitigationChart(measures, r) {
    const g = G(), sc = moneyScale(Math.max(1, ...measures.flatMap(m => [m.cost_pv, m.avoided_cost_pv].map(v => v || 0))));
    return g.chart({kind: "bars", horizontal: true, valueLabels: true, title: "Mitigation measures: cost versus avoided downtime cost", filename: "reliability_mitigation",
      subtitle: `${r.scenario}: present value over ${r.params.pv_years} years. A measure pays off when the avoided cost exceeds its cost.`,
      xTitle: `Present value (${sc.unit})`, unit: sc.unit, catTitle: "Measure", height: 170 + 58 * measures.length, vFmt: v => g.fmt(v, 3),
      categories: measures.map(m => ({key: m.name, label: `#${m.rank} ${m.name}`, notes: [`Benefit/cost ${g.fmt(m.benefit_cost_ratio, 2)}`,
        `Avoided downtime ${g.fmt(m.avoided_downtime_h_yr, 2)} h/yr`, m.payback_years == null ? "" : `Payback ${g.fmt(m.payback_years, 2)} y`].filter(Boolean)})),
      series: [{key: "cost", label: "Cost (PV)", color: "#C8553D", values: measures.map(m => (m.cost_pv || 0) / sc.div)},
        {key: "avoided", label: "Avoided downtime cost (PV)", color: "#2A9D8F", values: measures.map(m => (m.avoided_cost_pv || 0) / sc.div)}],
      barLabel: (v, s, i) => moneyLabel(sc, v * sc.div)});
  }

  function scenarioCharts() {
    const g = G(), rows = data.comparison, sc = moneyScale(Math.max(1, ...rows.map(c => c.cost_yr || 0)));
    g.registerScenarios(rows.map(c => c.scenario));
    const cats = rows.map(c => ({key: c.scenario, label: c.scenario, color: g.scenarioColor(c.scenario), notes: [c.name, `Verdict ${c.verdict}`].filter(Boolean)}));
    const one = (title, filename, yTitle, unit, values, color, vFmt, subtitle) => g.chart({kind: "bars", valueLabels: true, title, filename, subtitle, yTitle, unit,
      catTitle: "Scenario", categories: cats, height: 340, vFmt, series: [{key: filename, label: title, color, values}]});
    return wrapCharts([
      one("Downtime by scenario", "reliability_lole_by_scenario", "Downtime (h/yr)", "h/yr", rows.map(c => c.lole_h_yr), "#E08A1E", v => g.fmt(v, 2), "Expected hours per year with unserved load."),
      one("Unserved energy by scenario", "reliability_eens_by_scenario", "Unserved energy (MWh/yr)", "MWh/yr", rows.map(c => c.eue_mwh_yr), "#8E6BBF", v => g.fmt(v, 2), "Expected energy not served per year."),
      one("Downtime cost by scenario", "reliability_cost_by_scenario", `Cost (${sc.unit}/yr)`, sc.unit + "/yr", rows.map(c => (c.cost_yr || 0) / sc.div), "#C0392B", v => g.fmt(v, 3), "Expected value of lost load per year.")]);
  }

  function coptCharts(c) {
    const g = G(), x = c.map(r => r.year);
    return wrapCharts([
      g.chart({kind: "time", xKind: "number", title: "COPT screen: peak load vs dependable capacity", filename: "reliability_copt_capacity", subtitle: "Dependable capacity after forced outages must stay above the peak.",
        xTitle: "Year", yTitle: "Power (MW)", unit: "MW", x, height: 340, vFmt: v => g.fmt(v, 2), series: [{key: "peak", label: "Peak load", color: "#173441", values: c.map(r => r.peak_mw)},
          {key: "dep", label: "Dependable capacity", color: "#2A9D8F", values: c.map(r => r.dependable_mw)}]}),
      g.chart({kind: "bars", valueLabels: true, title: "COPT screen: loss-of-load expectation by year", filename: "reliability_copt_lole", subtitle: "Hours per year in which capacity is short.",
        yTitle: "LOLE (hours/yr)", unit: "h", catTitle: "Year", height: 340, vFmt: v => g.fmt(v, 2), categories: c.map(r => ({key: String(r.year), label: String(r.year), notes: [`EUE ${g.fmt(r.eue_mwh, 1)} MWh`, `Reserve margin ${g.fmt(r.reserve_margin_pct, 1)} %`]})),
        series: [{key: "lole", label: "LOLE (h)", color: "#E08A1E", values: c.map(r => r.lole_hours)}]})]);
  }

  function renderDetail() {
    const r = data.results.find(x => x.scenario === byId("rel-scenario").value) || data.results[0];
    const box = byId("rel-detail");
    if (!r) { box.replaceChildren(); return; }
    const s = r.summary, kp = el("div", undefined, "kpis");
    for (const [l, v] of [["Downtime (LOLE-style) h/yr", num(s.lole_h_yr)], ["Expected unserved MWh/yr", num(s.eue_mwh_yr, 0)],
      ["Interruptions/yr", num(s.interruptions_yr)], ["Avg interruption h", num(s.caidi_like_h)], ["Load served", num(s.load_served_pct, 3) + "%"],
      ["Downtime cost/yr", money(s.cost_yr)], [`Cost PV (${r.params.pv_years} y @ ${num((r.discount_rate || 0) * 100, 1)}%)`, money(s.cost_pv)]]) {
      const k = el("div", undefined, "kpi"); k.append(el("span", l), el("strong", v)); kp.append(k);
    }
    const verdict = el("p"); verdict.append(badge(r.verdict), " " + verdictText(r.verdict_detail));
    const cont = r.contingencies;
    const ct = table(["Contingency", "Lost MW", "Events/yr", "Worst outage MWh", "Peak shortfall MW", "Worst load served", "Downtime h/yr", "Unserved MWh/yr", "Cost/yr", "Cost PV"],
      cont.map(c => [c.name, num(c.lost_mw), num(c.events_per_year, 2), num(c.worst_all_years_mwh, 1), num(c.worst_event_peak_mw), num(c.worst_load_served_pct, 1) + "%",
        num(c.downtime_h_yr, 2), num(c.eue_mwh_yr, 1), money(c.cost_yr), money(c.cost_pv)]));
    const worst = cont.slice().sort((a, b) => b.worst_event_mwh - a.worst_event_mwh)[0];
    const mt = table(["#", "Measure", "Size", "Capex", "Annual opex", "Downtime avoided h/yr", "Cost avoided PV", "Cost PV", "Benefit/cost", "Payback y", "Covers local / grid"],
      r.measures.map(m => [m.rank, m.name, m.size_mw ? `${num(m.size_mw)} MW${m.size_mwh ? " / " + num(m.size_mwh) + " MWh" : ""}` : "-", money(m.capex), money(m.annual_opex),
        num(m.avoided_downtime_h_yr, 2), money(m.avoided_cost_pv), money(m.cost_pv), num(m.benefit_cost_ratio, 2), m.payback_years == null ? "-" : num(m.payback_years),
        `${m.covers_local == null ? "n/a" : m.covers_local ? "yes" : "no"} / ${m.covers_grid == null ? "n/a" : m.covers_grid ? "yes" : "no"}`]));
    const items = [el("h3", `${r.scenario} - ${r.name}`), verdict, kp,
      el("h4", "Contingencies (every outage start of " + r.params.outage_hours + " h tested)"), ct,       ...barChart(cont)];
          if (worst && worst.worst_window?.length) items.push(windowChart(worst.worst_window, worst, r).el);
    if (r.largest_unit_n1) items.push(el("p", "Largest-unit N-1: " + `${r.largest_unit_n1.name}: worst outage ${num(r.largest_unit_n1.worst_event_mwh, 0)} MWh, ${money(r.largest_unit_n1.cost_yr)}/yr`, "hint"));
    items.push(el("h4", "Mitigation measures (ranked by net present benefit)"),
      r.measures.length ? mt : el("p", "No contingency causes unserved load, so no mitigation is needed.", "hint"));
    if (r.measures.length) items.push(mitigationChart(r.measures, r).el);
    if (r.measures.length) items.push(el("p", "Costs use this scenario's capex inputs where available, otherwise documented defaults (" + `BESS ${money(r.unit_costs?.bess_mw)}/MW + ${money(r.unit_costs?.bess_mwh)}/MWh; genset ${money(r.unit_costs?.gen?.capex)}/MW` + ").", "hint"));
    if (r.qualitative_measures?.length) { const ul = el("ul"); for (const q of r.qualitative_measures) ul.append(el("li", typeof q === "string" ? q : `${q.name}: ${q.text || q.description || ""}`)); items.push(el("h4", "Other measures (not quantified)"), ul); }
    const c = r.copt?.rows || [];
    if (c.length) items.push(el("h4", "Secondary: capacity-outage-probability (COPT) screen"),
      table(["Year", "Peak MW", "Dependable MW", "Reserve %", "LOLE h", "EUE MWh", "N-1 capacity pass"], c.map(x => [x.year, num(x.peak_mw), num(x.dependable_mw), num(x.reserve_margin_pct), num(x.lole_hours), num(x.eue_mwh, 0), x.n1_pass ? "yes" : "no"])), coptCharts(c));
    if (r.model_check) items.push(el("p", `Model check: replaying the saved dispatch with no contingency gives ${num(r.model_check.replay_unserved_mwh, 2)} MWh unserved versus ${num(r.model_check.saved_unserved_mwh, 2)} MWh saved by the optimizer.`, "hint"));
    box.replaceChildren(...items);
  }

  function onShow() { load(); startPoll(); }
  function startPoll() {
    clearInterval(pollTimer);
    pollTimer = setInterval(() => {
      if (!pageVisible()) { clearInterval(pollTimer); return; }
      if (typeof solveRun !== "undefined" && solveRun && solveRun !== loadedRun && solveRun !== failedRun) load();
    }, 2000);
  }
  window.addEventListener("solve-complete", () => { data = null; loadedRun = null; failedRun = null; if (built && pageVisible()) load(); });
  analysisTabs.onShow("reliability", onShow);
  return {load, run};
})();
