"use strict";
// Sensitivity analysis pane (ANALYZE > Sensitivity). Talks to /api/x/sensitivity_*.
const sensitivityUi = (() => {
  let catalog = null, polling = null, built = false;
  const pane = () => analysisTabs.pane("sensitivity");
  const money = v => `${currencyUi.prefix()}${(v * currencyUi.fx() / 1e6).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}M`;
  const el = (tag, text, cls) => node(tag, text, cls);

  function build() {
    const root = pane();
    root.replaceChildren();
    root.append(el("h2", "Sensitivity and uncertainty analysis"));
    window.workflowUi?.hint(root);
    root.append(
      el("p", "Pick the inputs you are unsure about and a low/high range for each. The chosen scenario is " +
        "re-optimized for every case (capacities are free to change), then ranked in a tornado chart. Ranges are " +
        "suggestions; edit them freely. Each case takes about 1.5 minutes; cases already solved for the same inputs are " +
        "reused, so adding a parameter later only solves the new cases. Start with 3-5 parameters.", "hint"));
    const controls = el("div", undefined, "sens-controls");
    const scenarioLabel = el("label", "Scenario to test ");
    const select = el("select"); select.id = "sens-scenario"; scenarioLabel.append(select);
    const workersLabel = el("label", " Parallel solves ");
    const w = el("input"); w.id = "sens-workers"; w.type = "number"; w.min = 1; w.max = 4; w.value = 2;
    w.className = "narrow"; w.oninput = updateEstimate; workersLabel.append(w);
    controls.append(scenarioLabel, workersLabel);
    for (const [label, ids] of [["Quick (4)", ["fuel_price", "capex_bess", "load_growth", "solar_resource"]],
        ["Suggested (8)", null], ["Clear", []]]) {
      const b = el("button", label, "secondary"); b.type = "button";
      b.onclick = () => preset(ids); controls.append(b);
    }
    root.append(controls);
    const table = el("table", undefined, "sens-params");
    table.id = "sens-params";
    const head = el("thead"), hr = el("tr");
    for (const t of ["Use", "Parameter", "Low", "High", "Unit", "Why this range"]) hr.append(el("th", t));
    head.append(hr); table.append(head);
    const body = el("tbody");
    let group = "";
    for (const item of catalog.parameters) {
      if (item.group !== group) {
        group = item.group;
        const tr = el("tr", undefined, "group"), td = el("td", group); td.colSpan = 6; tr.append(td); body.append(tr);
      }
      const tr = el("tr"); tr.dataset.id = item.id;
      const use = el("input"); use.type = "checkbox"; use.onchange = updateEstimate;
      const lo = el("input"), hi = el("input");
      for (const [input, v] of [[lo, item.low], [hi, item.high]]) {
        input.type = "number"; input.step = "any"; input.value = v; input.className = "narrow";
      }
      const cells = [el("td"), el("td", item.label), el("td"), el("td"), el("td", item.unit), el("td", item.note)];
      cells[0].append(use); cells[2].append(lo); cells[3].append(hi); tr.append(...cells); body.append(tr);
    }
    table.append(body);
    root.append(table);
    const run = el("div", undefined, "sens-run");
    const go = el("button", "Run sensitivity analysis"); go.id = "sens-run"; go.type = "button"; go.onclick = start;
    const stop = el("button", "Stop", "secondary"); stop.id = "sens-stop"; stop.type = "button"; stop.hidden = true;
    stop.onclick = stopRun;
    const estimate = el("span", "", "hint"); estimate.id = "sens-estimate";
    run.append(go, stop, estimate);
    const status = el("p", "", "hint"); status.id = "sens-status";
    const results = el("div"); results.id = "sens-results";
    root.append(run, status, results);
    preset(catalog.defaults);
    built = true;
  }

  function preset(ids) {
    for (const tr of pane().querySelectorAll("#sens-params tbody tr[data-id]")) {
      const box = tr.querySelector("input[type=checkbox]");
      box.checked = !box.disabled && (ids === null ? catalog.defaults : ids).includes(tr.dataset.id);
    }
    updateEstimate();
  }

  async function refreshAvailability() {
    const code = byId("sens-scenario")?.value;
    if (!solveRun || !code) return;
    try {
      const c = await fetchJson(`/api/x/sensitivity_catalog?run_id=${encodeURIComponent(solveRun)}&scenario=${encodeURIComponent(code)}`);
      for (const tr of pane().querySelectorAll("#sens-params tbody tr[data-id]")) {
        const item = c.parameters.find(p => p.id === tr.dataset.id), reason = item?.unavailable;
        const box = tr.querySelector("input[type=checkbox]"), note = tr.lastChild;
        note.dataset.note ??= note.textContent;
        box.disabled = !!reason;
        if (reason) box.checked = false;
        tr.classList.toggle("unavailable", !!reason);
        note.textContent = reason ? `Not applicable to this scenario: ${reason}` : note.dataset.note;
      }
    } catch (error) { showError(error.message); }
    updateEstimate();
  }

  function selected() {
    return [...pane().querySelectorAll("#sens-params tbody tr[data-id]")].filter(tr =>
      tr.querySelector("input[type=checkbox]").checked).map(tr => {
      const [lo, hi] = tr.querySelectorAll("input[type=number]");
      return {id: tr.dataset.id, low: lo.valueAsNumber, high: hi.valueAsNumber};
    });
  }

  function updateEstimate() {
    const n = selected().length, cases = n ? 2 * n + (n > 1 ? 2 : 0) : 0;
    const workers = Math.max(1, Number(byId("sens-workers")?.value) || 1);
    byId("sens-estimate").textContent = n ?
      `${cases} re-optimizations, about ${Math.ceil(cases * catalog.seconds_per_case / workers / 60)} min.` : "";
  }

  function fillScenarios() {
    const select = byId("sens-scenario"), prior = select.value;
    const results = (solveSnapshot?.summary?.results || []).filter(r => r.code !== "R0");
    select.replaceChildren(...results.map(r => {
      const o = el("option", `${r.code} - ${r.name}`); o.value = r.code; return o;
    }));
    const npc = r => r.npc ?? r.economics?.npc ?? 1e99;
    const best = [...results].sort((a, b) => npc(a) - npc(b))[0];
    const recommended = window.workflowUi?.recommendedCode();
    const preferred = results.some(r => r.code === recommended) ? recommended : best?.code;
    select.value = select.dataset.user && prior ? prior : preferred || "";
    select.onchange = () => { select.dataset.user = "1"; refreshAvailability(); };
  }

  async function start() {
    showError("");
    try {
      if (!solveRun) throw new Error("Run SOLVE first; the sensitivity analysis re-optimizes a saved solve.");
      const params = selected();
      if (!params.length) throw new Error("Tick at least one parameter.");
      if (params.some(p => !Number.isFinite(p.low) || !Number.isFinite(p.high))) throw new Error("Enter low and high values.");
      await fetchJson("/api/x/sensitivity_start", {method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({run_id: solveRun, scenario: byId("sens-scenario").value, params,
          workers: Number(byId("sens-workers").value) || 2})});
      byId("sens-results").replaceChildren();
      poll();
    } catch (error) { showError(error.message); }
  }

  async function stopRun() {
    try {
      await fetchJson("/api/x/sensitivity_stop", {method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({run_id: solveRun})});
      poll();
    } catch (error) { showError(error.message); }
  }

  async function poll() {
    clearTimeout(polling);
    if (!solveRun) return;
    try {
      const s = await fetchJson(`/api/x/sensitivity_status?run_id=${solveRun}`);
      const running = s.state === "running";
      byId("sens-run").disabled = running;
      byId("sens-stop").hidden = !running;
      byId("sens-status").textContent = s.state === "none" ? "" : s.message || s.state;
      if (s.state === "complete" && s.report) render(s.report);
      if (running) polling = setTimeout(poll, 3000);
    } catch (error) { showError(error.message); }
  }

  const G = () => window.GS;
  const valText = (v, unit) => { const f = G().fmt(v); return unit.startsWith("%") ? `${f} %` : unit === "fraction" ? f : `${f} ${unit}`; };
  const signedM = (v, d = 2) => `${v >= 0 ? "+" : "−"}${currencyUi.prefix()}${G().fmt(Math.abs(v), d)}M`;
  const cl = t => currencyUi.label(t);

  function tornado(swings, base, scenario) {
    const g = G(), M = 1e6 / currencyUi.fx(), n = swings.length, mix = swings.some(s => s.mix_changes);
    const text = (s, which) => valText(which === "low" ? s.low : s.high, s.unit);
    const series = [["low", "Low value", "#2F6DB5", "delta_low"], ["high", "High value", "#E08A1E", "delta_high"]].map(([key, label, color, field]) => ({
      key, label, color, values: swings.map(s => s[field] / M),
      tips: swings.map(s => `${text(s, key)}: NPC ${signedM(s[field] / M)} (${s[field] >= 0 ? "+" : "−"}${g.fmt(Math.abs(100 * s[field] / base.npc), 2)} %)`)}));
    return g.chart({kind: "bars", horizontal: true, valueLabels: true, title: "Tornado: NPC sensitivity (ranked by swing)", filename: "tornado_npc_sensitivity",
      subtitle: cl(`${scenario}: change in net present cost versus the base case (${g.fmt(base.npc / M, 2)} $ million). Bars to the left lower the NPC; to the right raise it.`),
      xTitle: cl("Change in NPC vs base ($ million)"), unit: cl("$ M"), currencyScaled: true, catTitle: "Parameter", height: 170 + 46 * n,
      categories: swings.map(s => ({key: s.id, label: s.label + (s.mix_changes ? " *" : ""),
        notes: [`Tested range: ${text(s, "low")} to ${text(s, "high")}`, s.mix_changes ? "The best mix changes inside this range" : ""].filter(Boolean)})),
      series, barLabel: (v, s, i) => `${text(swings[i], s.key)} → ${signedM(v)}`, vFmt: v => g.fmt(v, 2),
      refLines: [{value: 0, color: "#173441"}], legendItems: [{label: cl(`Base NPC ${g.fmt(base.npc / M, 2)} $M`), color: "#173441", line: true, dash: "6 4"}],
      footnote: mix ? "* The optimal mix of equipment changes within this parameter's range." : ""});
  }

  function riskChart(report) {
    const g = G(), M = 1e6 / currencyUi.fx(), r = report.risk, base = report.base.npc;
    const rows = report.table.map(t => ({...t, d: (t.npc - base) / M})).sort((a, b) => a.d - b.d);
    if (rows.length < 2) return null;
    const lines = [r.p10, r.p90].filter(v => v != null && isFinite(v)).map(v => ({value: (v - r.p50) / M, color: "#7A6BC4"}));
    return g.chart({kind: "bars", horizontal: true, valueLabels: true, title: "NPC risk: every tested case versus the base", filename: "npc_risk_cases",
      subtitle: cl(`Cases ranked by NPC change vs base (P50 ${g.fmt(r.p50 / M, 2)} $M, estimated P10 ${g.fmt(r.p10 / M, 2)} $M, P90 ${g.fmt(r.p90 / M, 2)} $M).`),
      xTitle: cl("Change in NPC vs base ($ million)"), unit: cl("$ M"), currencyScaled: true, catTitle: "Case", height: 170 + 32 * rows.length,
      categories: rows.map(t => ({key: t.label, label: t.label + (t.mix_changed ? " *" : ""), color: t.d <= 0 ? "#2A9D8F" : "#C8553D",
        notes: [cl(`NPC ${g.fmt(t.npc / M, 2)} $M`), `Best mix: ${t.mix}`, t.unserved_mwh > 0.05 ? `Unserved ${g.fmt(t.unserved_mwh, 1)} MWh` : ""].filter(Boolean)})),
      series: [{key: "d", label: "Change in NPC", color: "#2F6DB5", values: rows.map(t => t.d)}], vFmt: v => g.fmt(v, 2),
      barLabel: (v, s, i) => `${signedM(v)} (${rows[i].delta_pct >= 0 ? "+" : "−"}${g.fmt(Math.abs(rows[i].delta_pct), 1)} %)`,
      refLines: lines, legendItems: [{label: "Lower NPC than base", color: "#2A9D8F"}, {label: "Higher NPC than base", color: "#C8553D"},
        {label: "Estimated P10 / P90", color: "#7A6BC4", line: true, dash: "6 4"}],
      footnote: rows.some(t => t.mix_changed) ? "* The optimal mix of equipment changes in this case." : ""});
  }

  function mixChart(report) {
    const g = G(), rows = report.table, techs = [...new Set(rows.flatMap(r => Object.keys(r.generators || {})))];
    const series = [{key: "pv", label: "Solar (DC)", color: g.techColor("pv"), values: rows.map(r => r.pv_mw || 0)},
      {key: "bess", label: "BESS power", color: g.techColor("bess"), values: rows.map(r => r.bess_mw || 0)},
      ...techs.map(t => ({key: t, label: g.TECH_NAMES[t] || t, color: g.techColor(t), values: rows.map(r => r.generators?.[t] || 0)}))]
      .filter(s => s.values.some(v => v > 1e-9));
    if (!series.length || rows.length < 2) return null;
    return g.chart({kind: "bars", horizontal: true, stack: true, totals: true, title: "Best mix in every tested case", filename: "sensitivity_best_mix",
      subtitle: "Installed capacity chosen by the re-optimization. Rows marked * build a different mix than the base case.",
      xTitle: "Capacity (MW)", unit: "MW", catTitle: "Case", height: 170 + 32 * rows.length, vFmt: v => g.fmt(v, 2), series,
      categories: rows.map(r => ({key: r.label, label: r.label + (r.mix_changed ? " *" : ""), notes: [r.mix_changed ? "Different mix than the base case" : ""].filter(Boolean)}))});
  }

  function render(report) {
    const out = byId("sens-results"), r = report.risk;
    out.replaceChildren(el("h3", `Results for ${report.scenario}`));
    const cards = el("div", undefined, "kpis");
    for (const [label, value] of [["Base NPC (P50)", money(r.p50)], ["P10 NPC (est.)", money(r.p10)],
        ["P90 NPC (est.)", money(r.p90)], ["Lowest / highest case", `${money(r.minimum)} / ${money(r.maximum)}`],
        ["Combined adverse", r.adverse == null ? "n/a" : money(r.adverse)],
        ["Combined favourable", r.favourable == null ? "n/a" : money(r.favourable)]]) {
      const card = el("div", undefined, "kpi"); card.append(el("span", label), el("strong", value)); cards.append(card);
    }
    out.append(cards, el("p", `Risk method: ${report.method}`, "hint"));
    const bc = report.base_check;
    if (bc) out.append(el("p", `Base case check: the re-solved base NPC is ${money(bc.resolved_npc)} against ${money(bc.saved_npc)} in the saved solve ` +
      `(${bc.difference_pct >= 0 ? "+" : "−"}${G().fmt(Math.abs(bc.difference_pct), 4)} %). ` +
      (bc.consistent ? "The sensitivity cases start from the same optimum as the saved results." :
        "The difference exceeds 0.5 %: the saved solve was produced with other inputs or an older engine version. Re-run SOLVE before relying on this analysis."),
      bc.consistent ? "hint" : "callout"));
    if (report.swings.length) out.append(el("h3", "Tornado (ranked by NPC swing)"), tornado(report.swings, report.base, report.scenario).el);
    for (const c of [riskChart(report), mixChart(report)]) if (c) out.append(c.el);
    const mixed = report.swings.filter(s => s.mix_changes).map(s => s.label);
    out.append(el("p", mixed.length ? `The best mix changes when varying: ${mixed.join(", ")}.` :
      "The best mix is unchanged across all one-at-a-time cases: the design is robust to these ranges.", "callout"));
    const table = el("table", undefined, "sens-table");
    const head = el("thead"), hr = el("tr");
    for (const t of ["Case", "NPC", "vs base", "Best mix", "Unserved MWh"]) hr.append(el("th", t));
    head.append(hr); table.append(head);
    const body = el("tbody");
    for (const row of report.table) {
      const tr = el("tr", undefined, row.mix_changed ? "changed" : "");
      for (const text of [row.label, money(row.npc), `${row.delta_pct >= 0 ? "+" : "−"}${G().fmt(Math.abs(row.delta_pct), 2)} %`,
          row.mix, G().fmt(row.unserved_mwh, 2)]) tr.append(el("td", text));
      body.append(tr);
    }
    table.append(body);
    out.append(table);
    if (report.failed.length) out.append(el("p", "Cases that failed: " + report.failed.map(f =>
      `${f.label} (${f.error})`).join("; "), "error"));
  }

  async function show() {
    if (!catalog) {
      try { catalog = await fetchJson("/api/x/sensitivity_catalog"); } catch (error) { showError(error.message); return; }
    }
    if (!built) build();
    fillScenarios();
    await refreshAvailability();
    poll();
  }

  window.addEventListener("load", () => analysisTabs.onShow("sensitivity", show));
  return {show};
})();
