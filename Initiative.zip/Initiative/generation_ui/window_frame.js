/* Makes a <dialog> user-resizable (native corner handle), movable by its header, maximizable, with size/position
   persisted in localStorage. All geometry is applied via CSSOM (element.style.*), which the CSP allows. */
(() => {
  const MARGIN = 8;
  function load(key) {
    try { return JSON.parse(localStorage.getItem("genstudio_window_" + key) || "null"); } catch (_) { return null; }
  }
  function save(key, value) {
    try { localStorage.setItem("genstudio_window_" + key, JSON.stringify(value)); } catch (_) { /* optional */ }
  }
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

  function attach(dialog, {key, handle, onResize, minWidth = 520, minHeight = 360}) {
    dialog.classList.add("win-frame");
    dialog.style.minWidth = Math.min(minWidth, window.innerWidth - 2 * MARGIN) + "px";
    dialog.style.minHeight = Math.min(minHeight, window.innerHeight - 2 * MARGIN) + "px";
    let maximized = false, restore = null, observer = null;
    const button = document.createElement("button");
    button.type = "button"; button.className = "secondary win-max"; button.textContent = "Maximize";
    button.title = "Maximize or restore this window"; button.setAttribute("aria-label", "Maximize window");
    handle.append(button);
    handle.classList.add("win-handle");

    const geometry = () => {
      const r = dialog.getBoundingClientRect();
      return {width: Math.round(r.width), height: Math.round(r.height), left: Math.round(r.left), top: Math.round(r.top)};
    };
    function apply(g) {
      const width = clamp(g.width, parseInt(dialog.style.minWidth) || 0, window.innerWidth - 2 * MARGIN);
      const height = clamp(g.height, parseInt(dialog.style.minHeight) || 0, window.innerHeight - 2 * MARGIN);
      dialog.style.width = width + "px"; dialog.style.height = height + "px"; dialog.style.maxHeight = "none"; dialog.style.maxWidth = "none";
      if (g.left != null) {
        dialog.style.margin = "0"; dialog.style.right = "auto"; dialog.style.bottom = "auto";
        dialog.style.left = clamp(g.left, MARGIN, Math.max(MARGIN, window.innerWidth - width - MARGIN)) + "px";
        dialog.style.top = clamp(g.top, MARGIN, Math.max(MARGIN, window.innerHeight - height - MARGIN)) + "px";
      }
    }
    function centre() {
      for (const p of ["margin", "right", "bottom", "left", "top"]) dialog.style.removeProperty(p);
    }
    const notify = () => { if (onResize) onResize(); };

    button.addEventListener("click", () => {
      if (!maximized) {
        restore = geometry();
        maximized = true; dialog.classList.add("win-maximized");
        apply({width: window.innerWidth - 2 * MARGIN, height: window.innerHeight - 2 * MARGIN, left: MARGIN, top: MARGIN});
        button.textContent = "Restore";
      } else {
        maximized = false; dialog.classList.remove("win-maximized");
        apply(restore || {width: 1000, height: 700}); button.textContent = "Maximize";
      }
      notify();
    });
    handle.addEventListener("dblclick", e => { if (e.target === handle || e.target.tagName === "H3") button.click(); });

    handle.addEventListener("pointerdown", e => {
      if (e.button !== 0 || e.target.closest("button, input, select, a") || maximized) return;
      const start = geometry(), x0 = e.clientX, y0 = e.clientY;
      handle.setPointerCapture(e.pointerId);
      const move = ev => apply({...start, left: start.left + ev.clientX - x0, top: start.top + ev.clientY - y0});
      const up = () => {
        handle.removeEventListener("pointermove", move); handle.removeEventListener("pointerup", up);
        handle.removeEventListener("pointercancel", up); persist();
      };
      handle.addEventListener("pointermove", move); handle.addEventListener("pointerup", up); handle.addEventListener("pointercancel", up);
    });

    function persist() {
      if (!maximized && dialog.open) save(key, geometry());
    }
    // Call after dialog.showModal(): restores the saved geometry and starts watching native-resize changes.
    function opened() {
      maximized = false; dialog.classList.remove("win-maximized"); button.textContent = "Maximize";
      centre();
      const saved = load(key);
      if (saved && saved.width) apply({width: saved.width, height: saved.height, left: saved.left, top: saved.top});
      if (observer) observer.disconnect();
      let first = true;
      observer = new ResizeObserver(() => {
        if (first) { first = false; return; }
        notify();
        if (!maximized) clearTimeout(opened.timer), opened.timer = setTimeout(persist, 200);
      });
      observer.observe(dialog);
      notify();
    }
    dialog.addEventListener("close", () => { if (observer) observer.disconnect(); });
    window.addEventListener("resize", () => {
      if (dialog.open && !maximized && dialog.style.width) apply(geometry());
      else if (dialog.open && maximized) apply({width: window.innerWidth - 2 * MARGIN, height: window.innerHeight - 2 * MARGIN, left: MARGIN, top: MARGIN});
    });
    return {opened, reset: () => { save(key, null); centre(); dialog.style.removeProperty("width"); dialog.style.removeProperty("height"); }};
  }
  window.windowFrame = {attach};
})();
