"use strict";
// Power-flow check: animated AC power-flow overlay on the single-line diagram, screening and manual operating point.
(() => {
  const NS = "http://www.w3.org/2000/svg";
  const GEN_KINDS = ["pv", "bess", "wind", "ng", "ng_chp", "h2", "h2_chp", "diesel", "biogas", "biomass"];
  const GEN_LABEL = {pv: "Solar PV", bess: "BESS (+discharge)", wind: "Wind", ng: "Gas genset", ng_chp: "Gas CHP", h2: "H2 genset",
    h2_chp: "H2 CHP", diesel: "Diesel genset", biogas: "Biogas", biomass: "Biomass"};
  const st = {on: false, mode: "run", series: null, frame: 0, playing: false, speed: 1, last: 0, manual: null, overrides: {nodes: {}, lines: {}},
    described: null, raf: null, token: 0};
  const $ = id => document.getElementById(id);
  const svgEl = (tag, attrs) => {
    const e = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs || {})) e.setAttribute(k, v);
    return e;
  };
  const h = (tag, text, cls) => {
    const e = document.createElement(tag);
    if (text !== undefined) e.textContent = text;
    if (cls) e.className = cls;
    return e;
  };
  const fmt = (v, d = 2) => (v === null || v === undefined || Number.isNaN(v)) ? "-" : Number(v).toFixed(Math.min(d, 4));
  const loadColour = pct => pct >= 100 ? "#d62839" : pct >= 80 ? "#f0a202" : "#2a9d4b";
  const voltColour = vm => (vm < 0.95 || vm > 1.05) ? "#d62839" : (vm < 0.97 || vm > 1.03) ? "#f0a202" : "#2a9d4b";
  const statusClass = s => "pf-status pf-" + String(s || "none").toLowerCase();

  async function post(body) {
    const response = await fetch("/api/x/powerflow", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)});
    const data = await response.json();
    if (!response.ok || data.error) throw new Error(data.error || "Power-flow request failed.");
    return data;
  }

  function topology() {
    const value = topologyEditor.value();
    return value;
  }
  function scenarioCode() {
    const sel = $("pf-scenario");
    return sel && sel.value ? sel.value : topologyEditor.geometry()?.code;
  }
  function overrides() {
    const out = {nodes: {}, lines: {}};
    for (const [id, row] of Object.entries(st.overrides.nodes)) if (Object.keys(row).length) out.nodes[id] = row;
    for (const [id, row] of Object.entries(st.overrides.lines)) if (Object.keys(row).length) out.lines[id] = row;
    return out;
  }
  function runResults() {
    return (typeof solveSnapshot !== "undefined" && solveSnapshot?.summary?.results) || [];
  }
  const hasRun = () => typeof solveRun !== "undefined" && !!solveRun && runResults().length > 0;

  // ---------------------------------------------------------------- overlay
  function frameData() {
    if (st.mode === "manual") return st.manual;
    const s = st.series;
    if (!s) return null;
    const i = Math.min(st.frame, s.vm.length - 1);
    const vm = {}, flow = {};
    s.bus_ids.forEach((id, k) => { vm[id] = s.vm[i][k]; });
    s.branch_ids.forEach((id, k) => { flow[id] = {p: s.p_from[i][k], q: s.q_from[i][k], loading: s.loading[i][k]}; });
    const node = {};
    for (const [id, v] of Object.entries(s.node_pq?.[i] || {})) node[id] = v;
    return {vm, flow, node, converged: s.converged[i], label: s.timestamps[i]};
  }

  function drawOverlay() {
    const svg = $("topology-svg");
    svg.querySelector("#powerflow-overlay")?.remove();
    if (!st.on) return;
    const geo = topologyEditor.geometry();
    const data = frameData();
    const g = svgEl("g", {id: "powerflow-overlay", class: "pf-overlay", "pointer-events": "none"});
    svg.append(g);
    if (!geo || !data) return;
    for (const line of geo.lines) {
      const f = data.flow[line.id];
      if (!f || line.route.length < 2) continue;
      const d = line.route.map((p, i) => `${i ? "L" : "M"}${p.x},${p.y}`).join(" ");
      const colour = loadColour(f.loading || 0);
      const mag = Math.abs(f.p);
      g.append(svgEl("path", {d, class: "pf-wire", stroke: colour, "stroke-width": 5, fill: "none", opacity: 0.35}));
      if (mag > 1e-4 || Math.abs(f.q) > 1e-4) {
        const dash = svgEl("path", {d, class: "pf-flow", "data-sign": mag > 1e-4 ? Math.sign(f.p) : Math.sign(f.q), "data-mag": Math.max(mag, 0.05),
          stroke: colour, "stroke-width": 3, fill: "none", "stroke-dasharray": "9 9", "stroke-linecap": "round"});
        g.append(dash);
      }
      let mid = line.route[0], best = 0;
      for (let i = 1; i < line.route.length; i++) {
        const a = line.route[i - 1], b = line.route[i], len = Math.hypot(b.x - a.x, b.y - a.y);
        if (len > best) { best = len; mid = {x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, ang: Math.atan2(b.y - a.y, b.x - a.x)}; }
      }
      const dir = f.p >= 0 ? 1 : -1;
      if (mid.ang !== undefined && mag > 1e-4) {
        const ang = (mid.ang + (dir < 0 ? Math.PI : 0)) * 180 / Math.PI;
        g.append(svgEl("polygon", {points: "9,0 -6,6 -6,-6", fill: colour, class: "pf-arrow", transform: `translate(${mid.x},${mid.y}) rotate(${ang})`}));
      }
      const label = svgEl("text", {x: mid.x, y: mid.y - 12, class: "pf-label", "text-anchor": "middle"});
      label.textContent = `${fmt(Math.abs(f.p), 2)} MW ${fmt(f.q, 2)} Mvar · ${fmt(f.loading, 0)}%`;
      g.append(label);
    }
    for (const n of geo.nodes) {
      const vm = data.vm[n.id];
      if (vm === undefined || vm === null) continue;
      const tag = svgEl("g", {transform: `translate(${n.x},${n.y - 42})`});
      const text = `${fmt(vm, 3)} pu`;
      tag.append(svgEl("rect", {x: -29, y: -11, width: 58, height: 17, rx: 4, fill: voltColour(vm), class: "pf-volt-box"}));
      const t = svgEl("text", {x: 0, y: 2, "text-anchor": "middle", class: "pf-volt"});
      t.textContent = text;
      tag.append(t);
      const pq = data.node?.[n.id];
      if (pq && (Math.abs(pq[0]) + Math.abs(pq[1]) + Math.abs(pq[2]) + Math.abs(pq[3]) > 1e-6)) {
        const p = pq[2] > 0 ? -pq[2] : pq[0], q = pq[2] > 0 ? -pq[3] : pq[1];
        const s = svgEl("text", {x: 0, y: -15, "text-anchor": "middle", class: "pf-label"});
        s.textContent = `${fmt(p, 2)} MW ${fmt(q, 2)} Mvar`;
        tag.append(s);
      }
      g.append(tag);
    }
    if (data.converged === false) {
      const t = svgEl("text", {x: 800, y: 30, "text-anchor": "middle", class: "pf-warning"});
      t.textContent = "Power flow did not converge for this hour";
      g.append(t);
    }
    animate(true);
  }

  function animate(restart) {
    if (restart && st.raf) { cancelAnimationFrame(st.raf); st.raf = null; }
    if (st.raf || !st.on) return;
    const tick = () => {
      st.raf = null;
      if (!st.on) return;
      const t = performance.now() / 1000;
      for (const p of document.querySelectorAll("#powerflow-overlay .pf-flow")) {
        const sign = Number(p.getAttribute("data-sign")) || 1, mag = Number(p.getAttribute("data-mag"));
        const speed = 12 + 22 * Math.min(1, Math.log10(1 + mag * 3) / 1.5);
        p.setAttribute("stroke-dashoffset", String(-sign * t * speed * st.speed));
      }
      st.raf = requestAnimationFrame(tick);
    };
    st.raf = requestAnimationFrame(tick);
  }

  // ---------------------------------------------------------------- panel
  function field(label, input) {
    const wrap = h("label", label + " ", "pf-field");
    wrap.append(input);
    return wrap;
  }
  function numInput(id, value, step = "any") {
    const i = h("input");
    i.type = "number"; i.id = id; i.value = value; i.step = step;
    return i;
  }

  function buildPanel() {
    const panel = h("section", undefined, "pf-panel");
    panel.id = "powerflow-panel";
    panel.hidden = true;
    panel.append(h("h3", "Power-flow check"),
      h("p", "Balanced positive-sequence AC power flow (Newton-Raphson) on this scenario's single-line diagram. Screening only; defaults are typical values - override them in the Assumptions table.", "muted"));

    const modeRow = h("div", undefined, "pf-row");
    const mode = h("select"); mode.id = "pf-mode";
    for (const [v, t] of [["run", "Saved solve - dispatch hours"], ["manual", "Manual operating point"]]) { const o = h("option", t); o.value = v; mode.append(o); }
    const scenario = h("select"); scenario.id = "pf-scenario";
    modeRow.append(field("Mode", mode), field("Scenario", scenario));
    panel.append(modeRow);

    const run = h("div", undefined, "pf-run"); run.id = "pf-run-controls";
    const row1 = h("div", undefined, "pf-row");
    const start = numInput("pf-start", 0, "1"); start.min = 0;
    const hours = numInput("pf-hours", 48, "1"); hours.min = 1; hours.max = 168;
    const sample = h("select"); sample.id = "pf-sample";
    for (const [v, t] of [["", "Consecutive hours"], ["year", "Sampled year (168 hours)"]]) { const o = h("option", t); o.value = v; sample.append(o); }
    const load = h("button", "Load hours", "secondary"); load.id = "pf-load";
    row1.append(field("Start hour", start), field("Hours (max 168)", hours), field("Range", sample), load);
    const row2 = h("div", undefined, "pf-row");
    const play = h("button", "Play", "secondary"); play.id = "pf-play";
    const slider = h("input"); slider.type = "range"; slider.id = "pf-slider"; slider.min = 0; slider.max = 0; slider.value = 0;
    const speed = h("select"); speed.id = "pf-speed";
    for (const s of [0.5, 1, 2, 4]) { const o = h("option", `${s}x`); o.value = s; if (s === 1) o.selected = true; speed.append(o); }
    const stamp = h("span", "", "pf-stamp"); stamp.id = "pf-stamp";
    row2.append(play, slider, field("Speed", speed), stamp);
    run.append(row1, row2);

    const manual = h("div", undefined, "pf-manual"); manual.id = "pf-manual-controls"; manual.hidden = true;
    panel.append(run, manual);

    const info = h("p", "", "muted pf-info"); info.id = "pf-info";
    const buttons = h("div", undefined, "pf-row");
    const screen = h("button", "Run screening", "secondary"); screen.id = "pf-screen";
    const raw = h("button", "Export PSS/E RAW", "secondary"); raw.id = "pf-raw";
    const assume = h("button", "Load assumptions", "secondary"); assume.id = "pf-assume";
    buttons.append(screen, raw, assume);
    const result = h("div", undefined, "pf-result"); result.id = "pf-result";
    const table = h("div", undefined, "pf-assumptions"); table.id = "pf-assumptions";
    panel.append(info, buttons, result, table);

    $("topology-message").after(panel);
    mode.onchange = () => { st.mode = mode.value; syncMode(); drawOverlay(); if (st.mode === "manual") solveManual(); };
    scenario.onchange = () => { st.series = null; st.described = null; drawOverlay(); };
    load.onclick = () => guarded(loadSeries);
    play.onclick = () => togglePlay();
    slider.oninput = () => { st.frame = Number(slider.value); showFrame(); };
    speed.onchange = () => { st.speed = Number(speed.value); };
    screen.onclick = () => guarded(screenRun);
    raw.onclick = () => guarded(exportRaw);
    assume.onclick = () => guarded(loadAssumptions);
  }

  function syncPanelChoices() {
    const sel = $("pf-scenario");
    const results = runResults().map(r => r.code);
    const active = topologyEditor.geometry()?.code;
    const previous = sel.value;
    sel.replaceChildren();
    const list = results.length ? results : (active ? [active] : []);
    for (const code of list) { const o = h("option", code); o.value = code; sel.append(o); }
    sel.value = list.includes(previous) ? previous : (list.includes(active) ? active : (list[0] || ""));
    const run = hasRun();
    $("pf-mode").querySelector("option[value=run]").disabled = !run;
    if (!run && st.mode === "run") { st.mode = "manual"; $("pf-mode").value = "manual"; syncMode(); }
    $("pf-info").textContent = run ? `Saved solve ${solveRun}.` : "No saved solve in this session - use the manual operating point, or run a solve first.";
  }

  function syncMode() {
    $("pf-run-controls").hidden = st.mode !== "run";
    $("pf-manual-controls").hidden = st.mode !== "manual";
    $("pf-scenario").disabled = st.mode !== "run";
    if (st.mode === "manual") buildManual();
  }

  function buildManual() {
    const box = $("pf-manual-controls");
    const geo = topologyEditor.geometry();
    const kinds = geo ? [...new Set(geo.nodes.map(n => n.kind).filter(k => GEN_KINDS.includes(k)))] : [];
    const prior = st.manualValues || {load: 5, gens: {}};
    box.replaceChildren();
    const row = h("div", undefined, "pf-row");
    row.append(field("Load MW", numInput("pf-load-mw", prior.load, "0.1")));
    const island = h("input"); island.type = "checkbox"; island.id = "pf-islanded"; island.checked = !!prior.islanded;
    row.append(field("Islanded (no grid support)", island));
    box.append(row);
    for (const kind of kinds) {
      const old = prior.gens[kind] || {};
      const r = h("div", undefined, "pf-row");
      r.append(h("strong", GEN_LABEL[kind] || kind, "pf-kind"));
      const p = numInput(`pf-p-${kind}`, old.p ?? 0, "0.1"), c = numInput(`pf-cap-${kind}`, old.cap ?? 5, "0.1"), q = numInput(`pf-q-${kind}`, old.q ?? "", "0.1");
      q.placeholder = "auto";
      r.append(field("MW", p), field("Capacity MW", c), field("Mvar (blank = control)", q));
      box.append(r);
    }
    const go = h("button", "Solve operating point", "secondary"); go.id = "pf-solve-manual";
    go.onclick = () => guarded(solveManual);
    box.append(go);
  }

  function readManual() {
    const gens = {}, vals = {load: Number($("pf-load-mw").value) || 0, gens: {}, islanded: $("pf-islanded").checked};
    for (const input of $("pf-manual-controls").querySelectorAll("input[id^='pf-p-']")) {
      const kind = input.id.slice(5);
      const q = $(`pf-q-${kind}`).value;
      gens[kind] = {p_mw: Number(input.value) || 0, cap_mw: Number($(`pf-cap-${kind}`).value) || 0};
      vals.gens[kind] = {p: Number(input.value) || 0, cap: Number($(`pf-cap-${kind}`).value) || 0, q: q};
      if (q !== "") gens[kind].q_mvar = Number(q);
    }
    st.manualValues = vals;
    return {load_mw: vals.load, gens, islanded: vals.islanded};
  }

  function frameFromCase(c) {
    const vm = {}, flow = {}, node = {};
    for (const b of c.buses) { vm[b.id] = b.energized === false ? null : b.vm; node[b.id] = [b.gen_mw, b.gen_mvar, b.load_mw, b.load_mvar]; }
    for (const br of c.branches) flow[br.id] = {p: br.p_from_mw, q: br.q_from_mvar, loading: br.loading_pct || 0};
    return {vm, flow, node, converged: c.converged, label: "Manual operating point"};
  }

  async function guarded(fn) {
    try { showError(""); await fn(); } catch (e) { showError(e.message || String(e)); }
  }

  async function solveManual() {
    const token = ++st.token;
    const data = await post({action: "solve", topology: topology(), scenario: scenarioCode(), operating: readManual(), assumptions: overrides()});
    if (token !== st.token) return;
    st.manual = frameFromCase(data.case);
    st.described = data.assumptions;
    renderResult(data.violations, data.status, data.case, data.warnings);
    drawOverlay();
  }

  async function loadSeries() {
    if (!hasRun()) throw new Error("Solve a scenario first.");
    const token = ++st.token;
    const sampled = $("pf-sample").value;
    const body = {action: "series", run_id: solveRun, scenario: scenarioCode(), topology: topology(), assumptions: overrides(),
      start: Number($("pf-start").value) || 0, hours: Math.min(168, Math.max(1, Number($("pf-hours").value) || 48))};
    if (sampled) body.sample = sampled;
    const data = await post(body);
    if (token !== st.token) return;
    st.series = data; st.frame = 0;
    const slider = $("pf-slider");
    slider.max = Math.max(0, data.vm.length - 1); slider.value = 0;
    const bad = data.converged.filter(ok => !ok).length;
    $("pf-info").textContent = `${data.vm.length} hours loaded of ${data.total_hours}` + (bad ? `; ${bad} did not converge.` : ".") +
      (data.warnings?.length ? " " + data.warnings.join(" ") : "");
    showFrame();
  }

  function showFrame() {
    const s = st.series;
    if (!s) return;
    $("pf-slider").value = st.frame;
    const status = s.status?.[st.frame];
    $("pf-stamp").textContent = `${s.timestamps[st.frame]} | load ${fmt(s.load_mw[st.frame], 2)} MW | losses ${fmt(s.losses_mw[st.frame], 3)} MW` +
      (status ? ` | ${status}` : "");
    drawOverlay();
  }

  function togglePlay() {
    if (st.playing) { st.playing = false; $("pf-play").textContent = "Play"; return; }
    if (!st.series) { guarded(async () => { await loadSeries(); startPlay(); }); return; }
    startPlay();
  }
  function startPlay() {
    st.playing = true; $("pf-play").textContent = "Pause"; st.last = performance.now();
    const step = now => {
      if (!st.playing || !st.on) { st.playing = false; const b = $("pf-play"); if (b) b.textContent = "Play"; return; }
      if (now - st.last >= 1000 / st.speed) {
        st.last = now;
        st.frame = (st.frame + 1) % st.series.vm.length;
        showFrame();
      }
      requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  // ---------------------------------------------------------------- results
  function violationList(items) {
    const ul = h("ul", undefined, "pf-violations");
    for (const v of items) {
      const li = h("li", undefined, "pf-" + v.severity);
      li.append(h("strong", `${v.severity.toUpperCase()}: `), document.createTextNode(v.message + " "));
      if (v.mitigation) li.append(h("em", "Suggested: " + v.mitigation));
      ul.append(li);
    }
    return ul;
  }

  function renderResult(violations, status, c, warnings) {
    const box = $("pf-result");
    box.replaceChildren();
    box.append(h("div", `Operating point: ${status || "-"}`, statusClass(status)));
    if (c) box.append(h("p", `${c.converged ? "Converged" : "Did NOT converge"} | Vmin ${fmt(c.vmin, 3)} pu | Vmax ${fmt(c.vmax, 3)} pu | ` +
      `worst loading ${fmt(c.max_loading_pct, 0)}% | losses ${fmt(c.losses_mw, 3)} MW`, "muted"));
    for (const w of warnings || []) box.append(h("p", w, "muted"));
    box.append(violations.length ? violationList(violations) : h("p", "No violations.", "muted"));
  }

  async function screenRun() {
    if (!hasRun()) throw new Error("Screening needs a solved run. Solve first, or use the manual operating point.");
    $("pf-result").textContent = "Screening...";
    const report = await post({action: "screen", run_id: solveRun, scenario: scenarioCode(), topology: topology(), assumptions: overrides()});
    const box = $("pf-result");
    box.replaceChildren();
    box.append(h("div", `Technical status ${report.scenario}: ${report.status} (normal ${report.normal_status}, N-1 ${report.n1_status})`, statusClass(report.status)));
    const table = h("table", undefined, "pf-cases");
    const head = h("tr");
    for (const t of ["Case", "Hour", "Converged", "Vmin pu", "Vmax pu", "Worst loading %", "Losses MW", "Violations"]) head.append(h("th", t));
    table.append(head);
    for (const c of report.cases) {
      const tr = h("tr", undefined, c.emergency ? "pf-n1" : "");
      const bad = (c.violations || []).length;
      for (const v of [c.label, c.timestamp ?? c.hour_index ?? "", c.converged ? "yes" : "NO", fmt(c.vmin, 3), fmt(c.vmax, 3), fmt(c.max_loading_pct, 0), fmt(c.losses_mw, 3), bad]) tr.append(h("td", String(v)));
      table.append(tr);
    }
    box.append(table);
    const all = report.cases.flatMap(c => (c.violations || []).map(v => ({...v, message: `[${c.label}] ${v.message}`})));
    box.append(all.length ? violationList(all) : h("p", "No violations in any screened case.", "muted"));
    if (report.cuts?.length) {
      box.append(h("h4", "Suggested technical cuts for the optimizer"));
      const ul = h("ul", undefined, "pf-cuts");
      for (const c of report.cuts) ul.append(h("li", `${c.type} - ${c.component}: ${c.limit} ${c.unit || ""} (${c.reason})`));
      box.append(ul);
    }
    box.append(h("p", (report.limitations || []).join(" "), "muted"));
  }

  async function exportRaw() {
    const body = {action: "raw", scenario: scenarioCode(), topology: topology(), assumptions: overrides()};
    if (st.mode === "run" && hasRun()) { body.run_id = solveRun; body.hour_index = st.series?.hour_index?.[st.frame]; }
    else body.operating = readManual();
    const data = await post(body);
    const url = URL.createObjectURL(new Blob([data.text], {type: "text/plain"}));
    const a = h("a"); a.href = url; a.download = data.filename;
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  // ---------------------------------------------------------------- assumptions table
  async function loadAssumptions() {
    let data;
    if (st.mode === "run" && hasRun())
      data = await post({action: "solve", run_id: solveRun, scenario: scenarioCode(), topology: topology(), assumptions: overrides()});
    else data = await post({action: "solve", topology: topology(), scenario: scenarioCode(), operating: readManual(), assumptions: overrides()});
    st.described = data.assumptions;
    const defaults = await post({action: "defaults"});
    renderAssumptions(data.assumptions, defaults);
  }

  function editable(kind, id, key, value, step) {
    const i = numInput(`pf-ov-${kind}-${id}-${key}`, value === undefined || value === null ? "" : Number(Number(value).toPrecision(5)), step);
    i.className = "pf-cell";
    const existing = st.overrides[kind][id]?.[key];
    if (existing !== undefined) i.classList.add("pf-overridden");
    i.onchange = () => {
      const row = st.overrides[kind][id] ||= {};
      if (i.value === "") delete row[key]; else row[key] = Number(i.value);
      i.classList.toggle("pf-overridden", i.value !== "");
    };
    return i;
  }

  function renderAssumptions(desc, defaults) {
    const box = $("pf-assumptions");
    box.replaceChildren();
    box.append(h("h4", "Assumptions (edit a value to override; blank = default)"));
    const b = desc.base;
    box.append(h("p", `Voltage limits ${b.voltage_limits.join("-")} pu (N-1 ${b.n1_voltage_limits.join("-")}), thermal ${b.thermal_limit_pct}%, load power factor ${b.load_pf}. Double-click a component on the diagram for full PSS/E-style parameters.`, "muted"));
    const nodes = h("table", undefined, "pf-cases");
    const nh = h("tr");
    for (const t of ["Bus / component", "Kind", "kV", "Vset pu", "Short-circuit MVA", "X/R"]) nh.append(h("th", t));
    nodes.append(nh);
    for (const n of desc.nodes) {
      const tr = h("tr");
      tr.append(h("td", n.display || n.label || n.id), h("td", n.kind));
      const cell = (key, step) => { const td = h("td"); td.append(editable("nodes", n.id, key, n[key], step)); return td; };
      tr.append(cell("kv", "any"), n.vset !== undefined ? cell("vset", "0.01") : h("td"),
        n.sc_mva !== undefined ? cell("sc_mva", "any") : h("td"), n.xr !== undefined ? cell("xr", "any") : h("td"));
      nodes.append(tr);
    }
    const br = h("table", undefined, "pf-cases");
    const bh = h("tr");
    for (const t of ["Branch", "Kind", "km", "R ohm/km", "X ohm/km", "Rating MVA", "Transformer MVA", "%Z", "Tap"]) bh.append(h("th", t));
    br.append(bh);
    for (const l of desc.branches) {
      const tr = h("tr");
      tr.append(h("td", `${l.name || ""} ${(desc.names || {})[l.from_id] || l.from_id} - ${(desc.names || {})[l.to_id] || l.to_id}`.trim()), h("td", `${l.kind}${l.type ? " (" + l.type + ")" : ""}`), h("td", fmt(l.length_km, 2)));
      const cell = (key, ok) => { const td = h("td"); if (ok) td.append(editable("lines", l.id, key, l[key], "any")); return td; };
      const isT = l.kind === "transformer", isL = l.kind === "line";
      tr.append(cell("r_ohm_km", isL), cell("x_ohm_km", isL), cell("rating_mva", isL), cell("mva", isT), cell("z_pct", isT), cell("tap", isT));
      br.append(tr);
    }
    const apply = h("button", "Apply overrides and re-solve", "secondary"); apply.id = "pf-apply";
    apply.onclick = () => guarded(async () => { if (st.mode === "manual") await solveManual(); else if (st.series) await loadSeries(); await loadAssumptions(); });
    const details = h("details");
    details.append(h("summary", "Default values and sources"));
    const dt = h("table", undefined, "pf-cases");
    const dh = h("tr");
    for (const t of ["Item", "Value", "Source"]) dh.append(h("th", t));
    dt.append(dh);
    for (const row of defaults.defaults || []) {
      const tr = h("tr");
      tr.append(h("td", row.name || ""), h("td", String(row.value ?? "")), h("td", row.source || ""));
      dt.append(tr);
    }
    details.append(dt);
    box.append(h("h5", "Buses and sources"), nodes, h("h5", "Lines and transformers"), br, apply, details);
  }

  // ---------------------------------------------------------------- toggle
  function setOn(on) {
    st.on = on;
    const btn = $("pf-toggle");
    btn.textContent = on ? "Hide power flow" : "Show power flow";
    btn.classList.toggle("tool-active", on);
    btn.setAttribute("aria-pressed", String(on));
    $("powerflow-panel").hidden = !on;
    if (on) {
      syncPanelChoices(); syncMode();
      if (st.mode === "manual") guarded(solveManual);
      drawOverlay();
    } else {
      st.playing = false;
      if (st.raf) { cancelAnimationFrame(st.raf); st.raf = null; }
      $("topology-svg").querySelector("#powerflow-overlay")?.remove();
    }
  }

  window.addEventListener("load", () => {
    const bar = document.querySelector("#topology-panel .diagram-toolbar");
    if (!bar || typeof topologyEditor === "undefined" || !topologyEditor.geometry) return;
    const btn = h("button", "Show power flow", "secondary");
    btn.id = "pf-toggle"; btn.type = "button"; btn.setAttribute("aria-pressed", "false");
    bar.append(btn);
    buildPanel();
    btn.onclick = () => setOn(!st.on);
    document.addEventListener("topology-render", () => { if (st.on) drawOverlay(); });
  });
})();
