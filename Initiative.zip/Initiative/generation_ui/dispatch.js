"use strict";
const dispatchExplorer=(()=>{
  let run=null, data=null, requestId=0, initialized=false;
  const $=id=>document.getElementById(id),NS="http://www.w3.org/2000/svg";
  function setPeriod() {
    if(!data)return;
    const period=$("dispatch-period").value;
    if(period==="custom")return;
    const year=Number($("dispatch-year").value),month=Number($("dispatch-month").value);
    let start=$("dispatch-start").value,end;
    if(period==="all"){start=data.first;end=data.last;}
    else if(period==="year"){start=`${year}-01-01T00:00`;end=`${year}-12-31T23:00`;}
    else if(period==="month"){
      start=`${year}-${String(month).padStart(2,"0")}-01T00:00`;
      end=new Date(Date.UTC(year,month,1)-3600000).toISOString().slice(0,16);
    } else {
      const date=new Date(start+"Z");date.setUTCHours(date.getUTCHours()+(period==="day"?23:167));
      end=date.toISOString().slice(0,16);
    }
    $("dispatch-start").value=start<data.first?data.first:start;
    $("dispatch-end").value=end>data.last?data.last:end;
    load();
  }
  function svgItem(tag,attributes={},text) {
    const item=document.createElementNS(NS,tag);
    for(const [key,value]of Object.entries(attributes))item.setAttribute(key,value);
    if(text!==undefined)item.textContent=text;
    return item;
  }
  let zoomTimer=0;
  // A long overview is bin-averaged; zooming reloads the visible window so short windows show true hourly values.
  function onZoom(domain) {
    clearTimeout(zoomTimer);
    if(!domain||!data||data.bin_hours<=1)return;
    zoomTimer=setTimeout(()=>{
      const hour=3600000,lo=Date.parse(data.start+"Z"),hi=Date.parse(data.end+"Z");
      const iso=t=>new Date(t).toISOString().slice(0,16);
      const start=Math.max(lo,Math.floor(domain[0]/hour)*hour),end=Math.min(hi,Math.max(start,Math.ceil(domain[1]/hour)*hour));
      load(false,{start:iso(start),end:iso(end)});
    },400);
  }
  function plot(id,which) {
    const host=$(id);host.replaceChildren();
    const afterGrid=which==="micro"&&$("dispatch-boundary").value==="grid";
    const traces=data.traces.filter(t=>t[which]||(afterGrid&&t.key==="planned")).map(t=>
      afterGrid&&t.key==="extra"?{...t,label:"Demand remaining after grid"}:
      afterGrid&&t.key==="microgrid_net"?{...t,label:"Net local contribution (planned + microgrid)"}:t);
    const series={...data.series};
    if(afterGrid)for(const key of ["extra","microgrid_net"])
      series[key]=data.series[key].map((value,i)=>value+(data.series.planned?.[i]||0));
    const times=data.timestamps.map(t=>Date.parse(t+"Z"));
    const widths={demand:2.4,extra:3.4,built:3.2,built_high:1,built_low:1,built_peak:1.4,demand_high:1,demand_low:1};
    // Stacked supply areas are drawn first so the built-load line and its envelope stay on top.
    const ordered=[...traces.filter(t=>t.area&&which==="full"),...traces.filter(t=>!(t.area&&which==="full"))];
    const chart=GS.chart({kind:"time",xKind:"time",x:times,markers:false,height:440,unit:"MW",yTitle:"Power (MW)",xTitle:"Date and time (local planning clock)",onDomain:onZoom,
      title:which==="full"?"Whole system: how the built load is met":"Local generation and residual demand",
      subtitle:`${data.scenario}: ${data.name}. Drag to zoom, wheel to zoom at cursor, Shift+drag to pan, click legend entries to hide series.`+
        (which==="full"&&data.bin_hours>1?" Envelope view: areas and the built line are bin means; thin lines are the highest and lowest hourly values per bin.":""),
      filename:`dispatch_${which}_${data.scenario}`,vFmt:v=>GS.fmt(v,3),
      tipExtra:i=>data.counts[i]>1?`${data.counts[i]}-hour mean`:"",
      series:ordered.map(t=>({key:t.key,label:t.label,color:t.color,values:series[t.key],width:widths[t.key]||2,area:Boolean(t.area&&which==="full"),
        dash:t.key==="microgrid_net"?"7 4":t.key==="demand"?"6 3":t.envelope?"3 3":undefined}))});
    host.append(chart.el);
  }
  function socPlot() {
    const host=$("dispatch-soc"),audit=data.bess_audit,has=audit&&audit.total_charge_mwh+audit.total_discharge_mwh>1e-6;
    host.replaceChildren();host.previousElementSibling.hidden=host.hidden=!has;$("dispatch-bess-audit").hidden=!has;
    if(!has)return;
    const soc=GS.chart({kind:"time",xKind:"time",x:data.timestamps.map(t=>Date.parse(t+"Z")),markers:false,height:300,unit:"MWh",yTitle:"Energy (MWh)",
      xTitle:"Date and time",title:"Battery state of charge",subtitle:`${data.scenario}: ${data.name}`,filename:`soc_${data.scenario}`,vFmt:v=>GS.fmt(v,3),
      series:[{key:"soc",label:"State of charge",color:"#7c3aed",values:data.soc_mwh,width:2}]});
    host.append(soc.el);
    const fixed=(v,n)=>v===null||v===undefined?"-":v.toLocaleString(undefined,{minimumFractionDigits:n,maximumFractionDigits:n});
    const E=v=>v===null||v===undefined?v:unitsUi.scaleEnergy(v),eu=unitsUi.label.energy();
    $("bess-audit-summary").textContent=`Total charged ${fixed(E(audit.total_charge_mwh),1)} ${eu}, discharged ${fixed(E(audit.total_discharge_mwh),1)} ${eu} `+
      `(realized ${fixed(audit.total_discharge_mwh/Math.max(audit.total_charge_mwh,1e-9),3)} vs round-trip efficiency ${fixed(audit.round_trip_efficiency,3)}). `+
      `Simultaneous charge/discharge hours: ${audit.simultaneous_hours}. Pooled committed + optimized storage; equivalent cycles use optimized usable ${eu} (${fixed(E(audit.usable_mwh),2)}).`;
    const table=document.createElement("table"),head=unitsUi.adaptColumns(["Month","Charged MWh","Discharged MWh","Realized efficiency","Equivalent cycles","Charge hours","Discharge hours","SOC start MWh","SOC end MWh","SOC min MWh","SOC max MWh"]).columns;
    table.innerHTML="<thead><tr>"+head.map(h=>`<th>${h}</th>`).join("")+"</tr></thead>";
    const body=document.createElement("tbody");
    for(const r of audit.rows){const tr=document.createElement("tr");
      for(const v of [r.month,fixed(E(r.charge_mwh),2),fixed(E(r.discharge_mwh),2),fixed(r.efficiency_realized,3),fixed(r.cycles,1),r.charge_hours,r.discharge_hours,
        fixed(E(r.soc_start_mwh),2),fixed(E(r.soc_end_mwh),2),fixed(E(r.soc_min_mwh),2),fixed(E(r.soc_max_mwh),2)]){const td=document.createElement("td");td.textContent=v;tr.append(td);}
      body.append(tr);}
    table.append(body);$("bess-audit-table").replaceChildren(table);
  }
  async function load(defaults=false,win=null) {
    const token=++requestId,query=new URLSearchParams({run,scenario:$("dispatch-scenario").value,resolution:$("dispatch-resolution").value});
    if(win){query.set("start",win.start);query.set("end",win.end);}
    else if(!defaults){query.set("start",$("dispatch-start").value);query.set("end",$("dispatch-end").value);}
    $("dispatch-error").hidden=true;$("dispatch-status").textContent=win?"Loading hourly values for the zoomed window...":"Reading saved hourly dispatch...";
    if(!win){$("dispatch-full").replaceChildren();$("dispatch-micro").replaceChildren();}
    try {
      const response=await fetch("/api/dispatch?"+query),answer=await response.json();
      if(token!==requestId)return;
      if(!response.ok)throw new Error(answer.error||"Dispatch could not be loaded.");
      data=answer;
      const csv=$("dispatch-csv");csv.hidden=!data.export_csv;
      if(data.export_csv)csv.href=`/files/${run}/${data.export_csv}`;
      if(!win){
      const yearOptions=[];
      for(let year=Number(data.first.slice(0,4));year<=Number(data.last.slice(0,4));year++)
        yearOptions.push(new Option(String(year),String(year)));
      $("dispatch-year").replaceChildren(...yearOptions);
      $("dispatch-year").value=data.start.slice(0,4);
      $("dispatch-month").value=String(Number(data.start.slice(5,7)));
      for(const id of ["dispatch-start","dispatch-end"]) {$(id).min=data.first;$(id).max=data.last;}
      $("dispatch-start").value=data.start;$("dispatch-end").value=data.end;
      }
      const resolutionText=data.bin_hours===1?"hourly resolution":data.resolution==="day"?"daily mean MW bins":
        data.resolution==="month"?"monthly mean MW bins":`${data.bin_hours}-hour mean MW bins`;
      $("dispatch-status").textContent=`${data.scenario}: ${data.name}${data.best_fully_supplied?" - recommended case":""}. `+
        `${data.hours.toLocaleString()} saved hours; ${resolutionText}`+(data.bin_hours>1?" with the highest and lowest hourly demand of each bin; zoom in (drag, wheel) to load true hourly values":"")+". "+
        (win?"Zoomed window; press Apply period to return to the selected period. ":"")+
        `Hourly energy balance verified: largest residual ${data.balance_error_mw.toExponential(2)} MW.`+
        (data.stacked?` Whole-system stack equals the built load; largest hourly gap ${data.stack_balance_error_mw.toExponential(2)} MW.`:"");
      $("dispatch-method").textContent=data.note;
      plot("dispatch-full","full");plot("dispatch-micro","micro");socPlot();
    }catch(error) {
      if(token!==requestId)return;
      $("dispatch-status").textContent="No dispatch shown for this selection.";
      $("dispatch-error").textContent=error.message;$("dispatch-error").hidden=false;
      $("dispatch-method").textContent="";
    }
  }
  function init() {
    if(initialized)return;initialized=true;
    $("dispatch-boundary").onchange=()=>{if(data)plot("dispatch-micro","micro");};
    for(let month=1;month<=12;month++)$("dispatch-month").add(new Option(
      new Date(Date.UTC(2000,month-1,1)).toLocaleString(undefined,{month:"long",timeZone:"UTC"}),String(month)));
    $("dispatch-period").onchange=setPeriod;
    for(const id of ["dispatch-year","dispatch-month"])$(id).onchange=()=>{
      if(["week","day","custom"].includes($("dispatch-period").value))$("dispatch-period").value="month";
      setPeriod();
    };
    for(const id of ["dispatch-start","dispatch-end"])$(id).oninput=()=>{$("dispatch-period").value="custom";};
    $("dispatch-apply").onclick=()=>{
      if(!$("dispatch-start").reportValidity()||!$("dispatch-end").reportValidity())return;
      load();
    };
    $("dispatch-resolution").onchange=()=>{if(data)load();};
    $("dispatch-scenario").onchange=()=>load(!data);
    $("dispatch-all").onclick=()=>{if(!data)return;$("dispatch-period").value="all";setPeriod();};
    $("dispatch-week").onclick=()=>{
      if(!data||!$("dispatch-start").reportValidity())return;
      $("dispatch-period").value="week";
      // UTC arithmetic preserves the study's timezone-free local-clock timestamps across DST.
      const end=new Date($("dispatch-start").value+"Z");end.setUTCHours(end.getUTCHours()+167);
      $("dispatch-end").value=[end.toISOString().slice(0,16),data.last].sort()[0];load();
    };
  }
  return {show:(nextRun,results)=>{
    init();$("dispatch-explorer").hidden=!results.length;if(run===nextRun)return;
    run=nextRun;data=null;$("dispatch-scenario").replaceChildren(new Option("Recommended case","best"),
      ...results.map(r=>new Option(`${r.code}: ${r.name}`,r.code)));
    const adequate=results.some(r=>!r.adequacy.unserved_hours&&r.adequacy.stress_unserved_mwh<=.00005);
    if(!adequate)$("dispatch-scenario").value=results[0]?.code||"best";
    if(results.length)load(true);
  }};
})();
