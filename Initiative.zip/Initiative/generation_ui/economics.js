"use strict";
// Economic Analysis pane: headline KPIs, incremental NPV/IRR/payback against a selectable reference, cost and CO2e tables.
const economicsUi = (() => {
  const el = (tag, text, cls) => node(tag, text, cls);
  const num = (v, d = 4) => v == null ? "-" : Number(v).toLocaleString(undefined, {maximumFractionDigits: d});
  const usd = v => v == null ? "-" : `${Math.round(v * currencyUi.fx()) < 0 ? "-" : ""}${currencyUi.prefix()}${Math.abs(Math.round(v * currencyUi.fx())).toLocaleString(undefined, {maximumFractionDigits: 0})}`;
  const pct = v => v == null ? "-" : `${num(100 * v, 4)}%`;
  const usdm = v => v == null ? "-" : `${v < 0 ? "-" : ""}${currencyUi.prefix()}${num(Math.abs(v) * currencyUi.fx() / 1e6, 2)} M`;
  const tonnes = v => v == null ? "n/a" : `${num(v, 0)} t`;
  let panel = null, data = null;

  function kpi(label, value, note) {
    const card = el("div", undefined, "kpi"), big = el("div", value);
    big.style.fontWeight = "600"; big.style.fontSize = "1.15rem";
    card.append(el("span", label), big);
    if (note) { const small = el("div", note, "muted"); small.style.fontSize = ".8rem"; card.append(small); }
    return card;
  }

  function headline(basis) {
    const cand = data.scenarios.filter(s => s.status !== "reference" && s[basis]);
    const ref = data.scenarios.find(s => s.status === "reference");
    const equal = cand.filter(s => s.adequate);
    const top = [...(equal.length ? equal : cand)].sort((a, b) => b[basis].npv - a[basis].npv)[0];
    const recommended = cand.find(s => s.code === data.recommended_code);
    const best = recommended || top;
    const box = el("div");
    box.id = "econ-kpis";
    if (!best) { box.append(el("p", "No other scenario is available to compare with the reference.", "muted")); return box; }
    const m = best[basis], cards = el("div", undefined, "kpis");
    const irrNote = m.irr == null ? returnReason(best, m, "irr") : "";
    const pbNote = returnReason(best, m, "payback");
    cards.append(
      kpi(recommended ? "Recommended scenario" : `Highest NPV vs ${data.reference}`, `${best.code}${best.name ? ": " + best.name : ""}`,
        recommended ? `Same choice as the Solve and Summary pages; compared with ${data.reference}` :
          best.adequate ? `The recommended scenario (${data.recommended_code}) is the reference case` : "No scenario gives equivalent service"),
      kpi("NPV", usdm(m.npv), `PV at ${data.calendar_years[0]}, ${num(100 * data.discount, 4)}% nominal`),
      kpi("IRR", m.irr == null ? returnLabel(best, m) : pct(m.irr), irrNote),
      kpi("Simple payback", pbValue(best, m, "simple_payback"), pbNote),
      kpi("Discounted payback", pbValue(best, m, "discounted_payback"), ""),
      kpi("LCOE", `$${num(best.lcoe, 2)} /MWh`, ref ? `${data.reference}: $${num(ref.lcoe, 2)} /MWh (nominal, levelized)` : "nominal, levelized"),
      kpi("CO2e avoided", best.co2e_avoided_t == null ? "n/a" : tonnes(best.co2e_avoided_t),
        best.co2e_avoided_t == null ? "Emission factors not confirmed" : `over ${data.horizon_years} years vs ${data.reference}${best.co2e_avoided_t < 0 ? " (negative = higher emissions)" : ""}`));
    box.append(cards);
    if (recommended && top && top.code !== recommended.code)
      box.append(el("p", `Note: ${top.code}${top.name ? " (" + top.name + ")" : ""} has a higher NPV versus ${data.reference} (${usdm(top[basis].npv)} against ${usdm(m.npv)}) ` +
        "but is not the recommended scenario: the recommendation is the lowest total net present cost among fully supplied scenarios, with equal-cost options resolved to the simpler one.", "notice"));
    return box;
  }

  // The reference costs more up front than the scenario: there is nothing to repay, so IRR and payback are not meaningful.
  const savesUpfront = (s, m) => m === s.net && s.upfront_saving > 0;
  const returnLabel = (s, m) => savesUpfront(s, m) ? "No additional investment" : "n/a";
  function returnReason(s, m, kind) {
    if (savesUpfront(s, m)) return kind === "irr" ? `Saves ${usd(s.upfront_saving)} up front versus ${data.reference}` : "";
    return kind === "irr" ? (m.irr_note || "").split(/[.;:]/)[0] : "";
  }
  function pbValue(s, m, key) {
    if (savesUpfront(s, m) && (m[key + "_years"] == null || m[key + "_years"] <= 0)) return "No additional investment";
    return m[key + "_years"] == null ? "beyond horizon" : m[key + "_years"] <= 0 ? "No net outlay" : `${num(m[key + "_years"], 2)} years`;
  }

  function table(headers, rows) {
    const t = el("table", undefined, "xl"), head = el("tr");
    for (const h of headers) head.append(el("th", h));
    t.append(head);
    for (const row of rows) {
      const tr = el("tr");
      for (const [i, v] of row.entries()) {
        const td = el("td", v);
        if (i) td.style.textAlign = "right";
        tr.append(td);
      }
      t.append(tr);
    }
    const wrap = el("div", undefined, "table-scroll");
    wrap.append(t);
    return wrap;
  }

  const irrText = (s, m) => s.status === "reference" ? "- (reference case)" : m.irr == null ? (savesUpfront(s, m) ? "Not applicable: no additional investment" : "- (no IRR)") : pct(m.irr);
  const pbText = (s, m, key) => s.status === "reference" ? "- (reference case)" :
    savesUpfront(s, m) && (m[key + "_years"] == null || m[key + "_years"] <= 0) ? "Not applicable: no additional investment" :
    m[key + "_years"] == null ? "not within horizon" : m[key + "_years"] <= 0 ? "0 (no net outlay)" : num(m[key + "_years"], 2);

  function ensure() {
    if (panel) return;
    panel = el("section", undefined, "explain-panel"); panel.id = "economics-panel";
    const bar = el("div", undefined, "sens-controls");
    const ref = el("select"); ref.id = "econ-reference"; ref.title = "Reference case";
    const basis = el("select"); basis.id = "econ-basis";
    for (const [v, t] of [["net", "Cash flows: net of avoided reference capex"], ["operating", "Cash flows: operating savings only"]]) {
      const o = el("option", t); o.value = v; basis.append(o);
    }
    const label = el("label", " Include residual value", "check-option"), box = document.createElement("input");
    box.type = "checkbox"; box.id = "econ-residual"; label.prepend(box);
    const go = el("button", "Refresh", "secondary"); go.type = "button"; go.onclick = load;
    bar.append(el("span", "Reference: "), ref, basis, label, go);
    const out = el("div"); out.id = "econ-out";
    panel.append(el("h2", "Economic analysis: NPV, IRR, payback, LCOE and CO2"), bar, out);
    analysisTabs.pane("economic").prepend(panel);
    ref.onchange = load; box.onchange = load; basis.onchange = render;
  }

  const moneyScale = max => max >= 1e6 ? {div: 1e6, unit: "$ million"} : max >= 1e3 ? {div: 1e3, unit: "$ thousand"} : {div: 1, unit: "$"};

  function charts(shown, basis) {
    const g = window.GS, label = basis === "net" ? "net of avoided reference capex" : "operating savings only";
    g.registerScenarios(data.scenarios.map(s => s.code));
    const years = data.calendar_years.map((y, i) => i), yrCat = i => `${i} (${data.calendar_years[i]})`;
    const all = shown.flatMap(s => [...s[basis].cashflows, ...s[basis].cumulative_discounted]).filter(v => v != null);
    const sc = moneyScale(Math.max(1, ...all.map(Math.abs)));
    const line = (title, filename, subtitle, key, extra) => g.chart({kind: "time", xKind: "number", title, filename, subtitle, xTitle: "Year (0 = investment)", yTitle: `${currencyUi.label(sc.unit)} (${currencyUi.code()})`,
      unit: sc.unit, x: years, height: 380, vFmt: v => g.fmt(v, 3), zeroLine: true, ...extra,
      series: shown.map(s => ({key: s.code, label: `${s.code} ${s.name || ""}`.trim(), color: g.scenarioColor(s.code), values: s[basis][key].map(v => v == null ? null : v / sc.div)}))});
    const pb = shown.filter(s => s[basis].discounted_payback_years != null && s[basis].discounted_payback_years > 0);
    const notes = shown.map(s => `${s.code}: ${s[basis].discounted_payback_years == null ? "no discounted payback within horizon" : "discounted payback " + g.fmt(s[basis].discounted_payback_years, 2) + " y"}`);
    const cum = line(`Cumulative discounted cash flow vs ${data.reference}`, "economics_cumulative_discounted_cash_flow",
      `${label}. The line crosses zero at the discounted payback (diamond).`, "cumulative_discounted",
      {points: pb.map(s => ({x: s[basis].discounted_payback_years, y: 0, color: g.scenarioColor(s.code), key: s.code})), footnote: notes.join("  ·  ")});
    const ann = line(`Annual cash flow vs ${data.reference}`, "economics_annual_cash_flow", `${label}; year 0 is the incremental investment.`, "cashflows", {});
    const cand = shown.filter(s => s.status !== "reference");
    const cats = cand.map(s => ({key: s.code, label: s.code, color: g.scenarioColor(s.code), faded: !s.adequate, notes: [s.name, s.adequate ? "" : "Not equivalent service (unserved energy)"].filter(Boolean)}));
    const nsc = moneyScale(Math.max(1, ...cand.map(s => Math.abs(s[basis].npv || 0))));
    const bar = (title, filename, subtitle, yTitle, unit, values, fmt, extra) => g.chart({kind: "bars", valueLabels: true, title, filename, subtitle, yTitle, unit, catTitle: "Scenario",
      categories: cats, height: 340, vFmt: fmt, ...extra, series: [{key: filename, label: title, color: "#2F6DB5", values}]});
    const out = el("div", undefined, "gs-grid");
    out.append(cum.el, ann.el);
    if (cand.length) {
      out.append(bar(`NPV vs ${data.reference}`, "economics_npv", `${label}, discounted at ${num(100 * data.discount, 4)} %. Faded bars do not give equivalent service.`,
        `NPV (${currencyUi.label(nsc.unit)})`, nsc.unit, cand.map(s => (s[basis].npv || 0) / nsc.div), v => g.fmt(v, 3), {}).el);
      const irr = cand.filter(s => s[basis].irr != null);
      if (irr.length) out.append(g.chart({kind: "bars", valueLabels: true, title: `IRR vs ${data.reference}`, filename: "economics_irr", subtitle: `${label}. Scenarios without an IRR are omitted.`,
        yTitle: "IRR (%)", unit: "%", catTitle: "Scenario", height: 340, vFmt: v => g.fmt(v, 3),
        categories: irr.map(s => ({key: s.code, label: s.code, color: g.scenarioColor(s.code), faded: !s.adequate, notes: [s.name].filter(Boolean)})),
        series: [{key: "irr", label: "IRR (%)", color: "#2F6DB5", values: irr.map(s => 100 * s[basis].irr)}]}).el);
    }
    return out;
  }

  function render() {
    if (!data) return;
    const out = byId("econ-out"), basis = byId("econ-basis").value, parts = [];
    const ref = byId("econ-reference");
    ref.replaceChildren(...data.reference_options.map(o => { const e = el("option", `${o.code}: ${o.name}`); e.value = o.code; return e; }));
    ref.value = data.reference;
    const basisLabel = basis === "net" ? "net of avoided reference capex" : "operating savings only";
    parts.push(headline(basis));
    parts.push(el("p", `Basis: nominal ${currencyUi.code()}${currencyUi.isUsd() ? "" : ` (converted from the USD model at ${currencyUi.rate()} ${currencyUi.code()} per USD)`}; ${num(100 * data.discount, 4)}% nominal discount rate; ${num(100 * data.inflation, 4)}% cost inflation; ` +
      `${data.horizon_years}-year horizon (${data.calendar_years[1]}-${data.calendar_years[data.calendar_years.length - 1]}), year-end cash flows; ` +
      `residual value ${data.include_residual ? "included" : "excluded"}; cash flows ${basisLabel}. Measured against ${data.reference} (${data.reference_name}). ` +
      (data.grid_emissions_t_mwh == null ? "" : `Grid emission factor ${num(data.grid_emissions_t_mwh, 4)} t CO2e/MWh, held constant. `) +
      "Use the selectors above to change the reference, cash-flow basis and residual value.", "notice"));
    for (const w of data.warnings) parts.push(el("p", w, "notice"));

    const dash = "-";
    const returns = data.scenarios.map(s => {
      const m = s[basis], service = s.adequate ? "yes" : "NO - unserved energy";
      if (!m) return [s.code, service, "reference case", dash, dash, dash, dash];
      return [s.code, service, usd(basis === "net" ? s.investment : s.capex), usd(m.npv), irrText(s, m),
        pbText(s, m, "simple_payback"), pbText(s, m, "discounted_payback")];
    });
    parts.push(el("h3", `Return versus ${data.reference} (${basisLabel})`), table(["Scenario", "Equivalent service",
      basis === "net" ? "Incremental investment, $ (capex vs reference)" : "Investment, $ (own capex incl. upgrade)",
      "NPV, $", "IRR", "Simple payback, years", "Discounted payback, years"].map(currencyUi.label), returns));
    const standalone = data.scenarios.map(s => [s.code, usd(s.capex), usd(s.npc), num(currencyUi.scaled(s.lcoe), 2), tonnes(s.co2e_t),
      s.status === "reference" ? "reference case" : tonnes(s.co2e_avoided_t)]);
    parts.push(el("h3", "Standalone cost and emissions (independent of the reference)"), table(["Scenario", "Capex incl. grid upgrade, $",
      "NPC, $", "LCOE, $/MWh (nominal, levelized)", `Net CO2e, t (${data.horizon_years} years)`, `CO2e avoided vs ${data.reference}, t`].map(currencyUi.label), standalone));
    if (!data.carbon_available) parts.push(el("p", "CO2e is shown only when emission factors are confirmed in the solve inputs.", "muted"));
    const reasons = [];
    for (const s of data.scenarios) {
      for (const [label, m] of [["net", s.net], ["operating", s.operating]]) if (m) {
        for (const t of [m.irr_note, m.simple_payback_note, m.discounted_payback_note]) if (t) reasons.push(`${s.code} (${label} basis): ${t}`);
      }
      for (const w of s.warnings) reasons.push(`${s.code}: ${w}`);
    }
    if (reasons.length) { const ul = el("ul"); for (const r of [...new Set(reasons)]) ul.append(el("li", r)); parts.push(el("h3", "Reasons and flags"), ul); }

    const shown = data.scenarios.filter(s => s[basis]);
    if (shown.length) {
      const yrs = data.calendar_years.map((y, i) => `${i} (${y})`);
      parts.push(el("h3", `Annual cash flow vs ${data.reference}, USD (year 0 = investment; ${basis === "net" ? "net of avoided reference capex" : "operating savings only"})`),
        table(["Year", ...shown.map(s => s.code)], yrs.map((y, i) => [y, ...shown.map(s => usd(s[basis].cashflows[i]))])));
      parts.push(el("h3", "Cumulative discounted cash flow, USD"),
        table(["Year", ...shown.map(s => s.code)], yrs.map((y, i) => [y, ...shown.map(s => usd(s[basis].cumulative_discounted[i]))])));
    }
    if (shown.length) parts.push(el("h3", "Charts"), charts(shown, basis));
    const how = el("details"); how.open = true;
    how.append(el("summary", "How this is computed"));
    const ul = el("ul"); for (const line of data.how) ul.append(el("li", line));
    how.append(ul);
    parts.push(how);
    out.replaceChildren(...parts);
  }

  async function load() {
    if (!solveRun) return;
    showError("");
    try {
      const reference = byId("econ-reference").value || "", residual = byId("econ-residual").checked ? 1 : 0;
      data = await fetchJson(`/api/x/economics?run_id=${solveRun}&reference=${encodeURIComponent(reference)}&residual=${residual}`);
      render();
    } catch (error) { byId("econ-out").replaceChildren(el("p", error.message, "muted")); }
  }

  window.addEventListener("load", () => {
    ensure();
    analysisTabs.onShow("economic", () => { panel.hidden = !solveSnapshot?.summary?.results?.length; if (!panel.hidden) load(); });
  });
  return {};
})();
