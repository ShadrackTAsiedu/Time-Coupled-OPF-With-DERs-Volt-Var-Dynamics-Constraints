"use strict";
// Design page: construction-oriented technical design of ONE selected option (basis, SLD, equipment schedule, checks, RAW/SLD export).
(() => {
  const $ = id => document.getElementById(id);
  const h = (tag, text, cls) => {
    const e = document.createElement(tag);
    if (text !== undefined && text !== null) e.textContent = text;
    if (cls) e.className = cls;
    return e;
  };
  const results = () => (typeof solveSnapshot !== "undefined" && solveSnapshot?.summary?.results) || [];
  const runId = () => (typeof solveRun !== "undefined" ? solveRun : null);
  const st = {code: null, design: null, busy: false, built: false, run: null, case: null, recommended: null, token: 0, ctrl: null, detail: "equivalent"};
  const TIMEOUT_MS = 150000;
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const fmt = v => (typeof v === "number" && Number.isFinite(v) ? v.toLocaleString("en-US", {maximumFractionDigits: 4}) : v);

  // Every request has a timeout and an external abort signal so a hung or superseded call can never lock the page.
  async function request(url, signal, kind) {
    const ctrl = new AbortController();
    const onAbort = () => ctrl.abort();
    if (signal) signal.addEventListener("abort", onAbort);
    const timer = setTimeout(() => { ctrl.timedOut = true; ctrl.abort(); }, TIMEOUT_MS);
    try {
      const response = await fetch(url, {signal: ctrl.signal, cache: "no-store"});
      if (!response.ok) {
        let m = `Request failed (HTTP ${response.status}).`;
        try { m = (await response.json()).error || m; } catch { /* keep */ }
        const err = new Error(m); err.http = true; throw err;
      }
      return kind === "blob" ? await response.blob() : kind === "text" ? await response.text() : await response.json();
    } catch (e) {
      if (ctrl.timedOut) throw new Error("The design is taking too long (timeout). Try again.");
      throw e;
    } finally { clearTimeout(timer); if (signal) signal.removeEventListener("abort", onAbort); }
  }
  const getJson = (url, signal) => request(url, signal, "json");
  async function postJson(url, body) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
    try {
      const response = await fetch(url, {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body), signal: ctrl.signal});
      let data = null;
      try { data = await response.json(); } catch { /* not JSON */ }
      if (!response.ok) throw new Error((data && data.error) || `Request failed (HTTP ${response.status}).`);
      return data;
    } finally { clearTimeout(timer); }
  }
  async function download(url, name) {
    if (!st.code || !st.design) throw new Error("Select a design option and wait for it to finish loading before exporting.");
    save(await request(url, null, "blob"), name);
  }
  function save(blob, name) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = name;
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  const query = () => `run_id=${encodeURIComponent(runId())}&scenario=${encodeURIComponent(st.code || "")}&detail=${encodeURIComponent(st.detail)}`;
  const message = text => { const b = $("dsg-message"); if (b) { b.textContent = text || ""; b.hidden = !text; } };
  const paramText = p => Object.entries(p || {}).filter(([, v]) => v !== null && v !== undefined && typeof v !== "object")
    .map(([k, v]) => `${k.replace(/_/g, " ")}: ${fmt(v)}`).join("; ");

  function table(headers, rows, cls) {
    const t = h("table", undefined, "dsg-table" + (cls ? " " + cls : ""));
    const head = h("tr");
    headers.forEach(x => head.append(h("th", x)));
    const thead = h("thead"); thead.append(head); t.append(thead);
    const body = h("tbody");
    rows.forEach(r => { const tr = h("tr"); r.forEach(c => tr.append(c instanceof Node ? c : h("td", c === null || c === undefined ? "-" : fmt(c)))); body.append(tr); });
    t.append(body);
    const wrap = h("div", undefined, "dsg-scroll");
    wrap.append(t);
    return wrap;
  }
  const tag = source => { const td = h("td"); td.append(h("span", source, "dsg-tag dsg-" + String(source).replace(/[^a-z]/gi, "").toLowerCase())); return td; };
  function section(title, ...children) {
    const s = h("section", undefined, "dsg-section");
    s.append(h("h3", title), ...children);
    return s;
  }

  function build(host) {
    host.textContent = "";
    const root = h("div", undefined, "dsg-root");
    const bar = h("div", undefined, "dsg-bar");
    const label = h("label", "Option "); const sel = h("select"); sel.id = "dsg-scenario"; label.append(sel);
    sel.onchange = () => { st.code = sel.value; load(); };
    bar.append(label);
    const dlabel = h("label", "Design detail "); const dsel = h("select"); dsel.id = "dsg-detail";
    [["equivalent", "Equivalent (PSS/E study)"], ["detailed", "Detailed (per-block, for construction)"]].forEach(([value, text]) => { const o = h("option", text); o.value = value; dsel.append(o); });
    dsel.value = st.detail;
    dsel.onchange = () => { st.detail = dsel.value; if (st.code) load(); };
    dlabel.append(dsel); bar.append(dlabel);
    const back = h("button", "Back to recommended", "secondary"); back.id = "dsg-back"; back.type = "button"; back.hidden = true;
    back.onclick = () => { if (st.recommended) { st.code = st.recommended; sel.value = st.code; load(); } };
    bar.append(back);
    const btn = (id, text, fn) => { const b = h("button", text, "secondary"); b.id = id; b.type = "button"; b.onclick = () => Promise.resolve(fn()).catch(e => message(e.message || String(e))); bar.append(b); return b; };
    btn("dsg-raw", "Export RAW", () => download(`/api/x/design_raw?${query()}`, `design_${st.code}.raw`));
    btn("dsg-sld", "Export SLD (SVG)", () => download(`/api/x/design_sld?${query()}`, `design_${st.code}_sld.svg`));
    btn("dsg-json", "Export design JSON", () => download(`/api/x/design_json?${query()}`, `design_${st.code}.json`));
    btn("dsg-csv", "Export equipment CSV", () => download(`/api/x/design_csv?${query()}`, `design_${st.code}_equipment.csv`));
    btn("dsg-report", "Technical design report", () => download(`/api/x/design_report?${query()}`, `technical_design_${st.code}.html`));
    btn("dsg-print", "Print design basis", () => {
      document.body.classList.add("design-printing");
      const done = () => { document.body.classList.remove("design-printing"); window.removeEventListener("afterprint", done); };
      window.addEventListener("afterprint", done);
      window.print();
    });
    const note = h("p", "Screening-level design for the selected option only. Items tagged 'assumed' are typical values, not engineered data.", "dsg-note");
    const msg = h("div", undefined, "notice"); msg.id = "dsg-message"; msg.hidden = true;
    const body = h("div"); body.id = "dsg-body";
    root.append(h("h2", "Final technical design"), note, bar, msg, body);
    host.append(root);
    st.built = true;
  }

  const edState = {};

  // Editable assumptions: only values that are assumed (not optimizer results) can be changed; saved per run and scenario on the server.
  function editor() {
    const box = h("div", undefined, "dsg-editor"); box.id = "dsg-editor";
    box.append(h("p", "Loading editable values...", "dsg-note"));
    loadParams(box);
    return section("1a. Edit assumed design values", h("p", "Change any assumed value and save: the design, the single-line diagram, the equipment schedule, the bill of quantities and the reports update, and the values are written into the stored network (power-flow inputs). Optimizer capacities are read-only: change them in the scenario setup and re-run the optimization.", "dsg-note"), box);
  }

  async function loadParams(box, given) {
    const token = st.token;
    let p = given;
    try { p = p || await getJson(`/api/x/design_params?${query()}`, st.ctrl && st.ctrl.signal); }
    catch (e) { if (token === st.token && e.name !== "AbortError") box.textContent = `Editable values could not be loaded: ${e.message}`; return; }
    if (token !== st.token) return;
    box.textContent = "";
    const inputs = new Map();
    const status = h("div", undefined, "notice"); status.id = "dsg-edit-status"; status.hidden = true;
    const say = (text, kind) => { status.textContent = text || ""; status.hidden = !text; status.className = "notice" + (kind ? " dsg-" + kind : ""); };
    if (p.model && p.model.length) {
      box.append(h("h4", "Model-derived (read-only)"), table(["Item", "Value", "Unit", "Note"], p.model.map(m => [m.label, fmt(m.value), m.unit, m.note])));
    }
    const cell = n => { const td = h("td"); td.append(n); return td; };
    const groups = [...new Set(p.fields.map(f => f.group))];
    const reload = async (fn, okText) => {
      say("Working...");
      try {
        const next = await fn();
        edState.msg = okText;
        await refreshDesign();
        return next;
      } catch (e) { say(e.message || String(e), "bad"); }
    };
    const pending = () => {
      const v = {...p.overrides};
      p.fields.forEach(f => {
        const raw = inputs.get(f.key).value.trim();
        if (raw === "" || raw === String(f.value)) return;
        v[f.key] = f.choices ? raw : Number(raw);
      });
      return v;
    };
    groups.forEach(g => {
      const rows = p.fields.filter(f => f.group === g).map(f => {
        let input;
        if (f.choices) {
          input = h("select"); f.choices.forEach(c => { const o = h("option", String(c)); o.value = String(c); input.append(o); });
        } else {
          input = h("input"); input.type = "number"; input.step = f.integer ? "1" : "any";
          if (f.min !== null && f.min !== undefined) input.min = f.min;
          if (f.max !== null && f.max !== undefined) input.max = f.max;
        }
        input.value = String(f.value); input.id = "dsg-in-" + f.key.replace(/[^a-z0-9]/gi, "_"); input.className = "dsg-input";
        input.setAttribute("aria-label", f.label);
        inputs.set(f.key, input);
        const reset = h("button", "Reset", "secondary dsg-reset"); reset.type = "button"; reset.hidden = !f.user_set;
        reset.onclick = () => reload(() => postJson("/api/x/design_reset", {run_id: runId(), scenario: st.code, keys: [f.key]}), `${f.label} reset to its default.`);
        const lim = (f.min !== null && f.min !== undefined) || (f.max !== null && f.max !== undefined) ? ` (${f.min ?? ""}..${f.max ?? ""})` : "";
        return [f.label + lim, cell(input), f.unit || "", String(f.default ?? "-"), tag(f.user_set ? "user-set" : "assumed"), cell(reset)];
      });
      box.append(h("h4", g), table(["Parameter", "Value", "Unit", "Default", "Source", ""], rows, "dsg-edit"));
    });
    const bar = h("div", undefined, "dsg-bar");
    const b = (id, text, fn) => { const x = h("button", text, id === "dsg-save" ? "" : "secondary"); x.id = id; x.type = "button"; x.onclick = fn; bar.append(x); return x; };
    b("dsg-save", "Save changes", () => reload(() => postJson("/api/x/design_save", {run_id: runId(), scenario: st.code, values: pending()}), "Saved. The design was rebuilt with your values."));
    b("dsg-reset-all", "Reset all to defaults", () => reload(() => postJson("/api/x/design_reset", {run_id: runId(), scenario: st.code}), "All values reset to their defaults."));
    const pfBox = h("div", undefined, "dsg-pf"); pfBox.id = "dsg-pf-result";
    b("dsg-run-pf", "Run power flow with these changes", async () => {
      say("Running the power-flow screening...");
      try {
        const r = await postJson("/api/x/design_pf", {run_id: runId(), scenario: st.code, values: pending()});
        say("");
        showPf(pfBox, r);
        await refreshDesign(pfBox);
      } catch (e) { say(e.message || String(e), "bad"); }
    });
    box.append(h("div", p.updated ? `User-set values last saved ${p.updated}${p.mapped_to_topology ? "; mapped into the stored single-line diagram." : "."}` : "No user-set values: every assumed value is the design default.", "dsg-note"), bar, status, pfBox);
    if (p.power_flow) showPf(pfBox, p.power_flow);
    if (edState.msg) { say(edState.msg); edState.msg = ""; }
  }

  function showPf(host, r) {
    host.textContent = "";
    const head = h("div", undefined, "dsg-head");
    head.append(h("strong", "Power flow on the edited design"), h("span", r.status, "dsg-pill dsg-st-" + String(r.status).toLowerCase()),
      h("span", `normal ${r.normal_status || "-"}, N-1 ${r.n1_status || "-"}`, "dsg-pill"), h("span", `${r.n_violations ?? (r.violations || []).length} violation(s)`, "dsg-pill"));
    host.append(head);
    if ((r.violations || []).length) host.append(table(["Case", "Severity", "Component", "Message"], r.violations.map(v => [v.case || "-", v.severity, v.component_name || v.component || "-", v.message])));
    else host.append(h("p", "No violations found.", "dsg-note"));
  }

  // Rebuild the page from the server after a save/reset, keeping the power-flow result that was just produced.
  async function refreshDesign() {
    const ctrl = st.ctrl = new AbortController();
    const token = ++st.token;
    st.busy = true;
    try {
      const d = await getJson(`/api/x/design?${query()}`, ctrl.signal);
      if (token !== st.token) return;
      st.design = d;
      render(d);
    } finally { if (token === st.token) { st.busy = false; if (st.ctrl === ctrl) st.ctrl = null; } }
  }

  function render(d) {
    const body = $("dsg-body");
    body.textContent = "";
    const m = d.meta;
    const head = h("div", undefined, "dsg-head");
    head.append(h("strong", `${m.scenario_name || m.scenario} (${m.scenario})`), h("span", m.scenario === st.recommended ? "Recommended" : `Not the recommended option (recommended is ${st.recommended || m.best_scenario})`, "dsg-pill" + (m.scenario === st.recommended ? " dsg-reco" : "")),
      h("span", `Design check: ${m.status}`, "dsg-pill dsg-st-" + m.status.toLowerCase()), h("span", `Drawing ${m.drawing_no} rev ${m.revision}`, "dsg-pill"));
    body.append(head);
    const notBuilt = ((d.effective_technologies || {}).notes || []);
    if (notBuilt.length) { const nb = h("p", notBuilt.join(". ") + ".", "dsg-callout"); nb.id = "dsg-not-built"; body.append(nb); }
    const modelNote = h("p", `Design detail: ${m.detail_label || m.detail}.`, "dsg-note"); modelNote.id = "dsg-detail-note"; body.append(modelNote);
    const v = d.voltages, sc = d.short_circuit;
    const kpi = h("div", undefined, "dsg-kpis");
    [["Grid", v.hv_kv ? fmt(v.hv_kv) + " kV" : "islanded"], ["MV bus", fmt(v.mv_kv) + " kV"], ["MV fault duty", fmt(sc.mv_ka) + " kA"], ["Peak load", fmt(d.totals.peak_load_mw) + " MW"],
      ["Equipment items", d.equipment.length], ["Assumed inputs", d.assumed_count]].forEach(([k, val]) => {
      const c = h("div", undefined, "dsg-kpi"); c.append(h("span", k), h("b", String(val))); kpi.append(c);
    });
    body.append(kpi);

    body.append(section("1. Design basis and criteria", h("p", d.shunt_note || "", "dsg-callout"), table(["Group", "Parameter", "Value", "Unit", "Source", "Note"],
      d.basis.map(r => [r.group, r.name, fmt(r.value ?? "-"), r.unit, tag(r.source), r.note || ""]))));
    body.append(editor());

    const sldBox = h("div", undefined, "dsg-sld"); sldBox.id = "dsg-sld-box";
    body.append(section("2. Single-line diagram (final design)", sldBox));
    const token = st.token;
    request(`/api/x/design_sld?${query()}`, st.ctrl && st.ctrl.signal, "text").then(text => {
      if (token !== st.token) return;
      const doc = new DOMParser().parseFromString(text, "image/svg+xml");
      const svg = doc.documentElement;
      if (svg.nodeName !== "svg") { sldBox.textContent = "SLD could not be loaded."; return; }
      svg.removeAttribute("width"); svg.removeAttribute("height");
      sldBox.append(document.importNode(svg, true));
    }).catch(e => { if (token === st.token && e.name !== "AbortError") sldBox.textContent = `SLD could not be loaded: ${e.message}`; });

    const eqRows = d.equipment.map(e => [e.id, e.category, e.type + (e.status === "existing" ? " (existing)" : ""), e.description, e.rating, fmt(e.voltage), fmt(e.quantity),
      paramText(e.params), tag(e.basis)]);
    body.append(section("3. Equipment schedule", table(["ID", "Category", "Type", "Description", "Rating", "Voltage kV", "Qty", "Key parameters", "Basis"], eqRows, "dsg-eq")));

    const c = d.checks, s = c.summary;
    const checkSummary = h("p", `Status ${c.status}. ${s.cases} operating cases solved with the power-flow solver; voltage ${s.vmin ?? "-"} to ${s.vmax ?? "-"} pu; highest equipment loading ${s.max_loading_pct ?? "-"} %; Q/P criterion at POI ${c.power_factor_ok ? "met" : "NOT met"} (target ${c.pf_target}).`);
    const cases = table(["Case", "Time", "Load MW", "Grid MW", "Grid Mvar", "Vmin pu", "Vmax pu", "Max loading %", "OLTC pos", "Cap stages", "Violations"],
      c.cases.map(x => [x.label, x.timestamp, x.load_mw, x.grid_mw, x.grid_mvar, x.vmin, x.vmax, x.max_loading_pct, x.tap_pos, x.cap_stages_in, x.violations.map(q => q.message).join(" | ") || "none"]));
    const cab = table(["Run", "Size", "Length km", "I per circuit A", "Derated A", "Loading %", "Voltage drop %", "OK"],
      c.cables.map(x => [x.id, x.size, x.length_km, x.i_per_circuit_a, x.derated_ampacity_a, x.loading_pct, x.voltage_drop_pct, x.vd_ok && x.ampacity_ok && x.sc_ok ? "yes" : "CHECK"]));
    const n1 = c.n1.length ? table(["Contingency", "Result", "Note"], c.n1.map(x => [x.label, x.status, x.note || `loading ${x.max_loading_pct ?? "-"} %, V ${x.vmin ?? "-"}-${x.vmax ?? "-"} pu`])) : h("p", "No N-1 case applicable.");
    const iters = h("ul"); d.iterations.forEach(t => iters.append(h("li", t)));
    body.append(section("4. Feasibility check (power-flow solver)", checkSummary, h("h4", "Sizing iterations"), iters, h("h4", "Operating cases"), cases,
      h("h4", "Cable checks"), cab, h("h4", "N-1"), n1));

    body.append(section("5. Protection and control summary", table(["Zone", "Device", "Functions", "Qty", "Note"], d.protection.map(r => [r.zone, r.device, r.functions, fmt(r.quantity), r.note]))));
    body.append(section("6. Land and footprint (indicative)", table(["Item", "Quantity", "Unit", "Basis"], d.land.map(r => [r.item, fmt(r.quantity), r.unit, r.basis]))));
    body.append(section("7. Bill of materials (indicative quantities)", h("h4", "Estimated unit counts"),
      table(["Item", "Count", "Unit size", "Unit", "Basis", "Note"], (d.unit_counts || []).map(u => [u.item, fmt(u.count), fmt(u.unit_size ?? "-"), u.unit, tag(u.basis), u.note || ""]), "dsg-units"),
      h("p", "Unit sizes are assumptions (editable in section 1a) and give an order-of-magnitude count, not a procurement quantity.", "dsg-note"),
      h("h4", "Bill of materials"), table(["Item", "Quantity", "Unit", "Note"], d.bom.map(r => [r.item, fmt(r.quantity), r.unit, r.note]))));
    const fl = h("ul"); d.flags.forEach(f => fl.append(h("li", `${f.id} - ${f.item}: ${f.note}`)));
    body.append(section("8. Items needing engineering confirmation", fl));
    const lim = h("ul"); d.limitations.forEach(t => lim.append(h("li", t)));
    body.append(section("9. Limitations", lim));
  }

  function syncControls() {
    const back = $("dsg-back"), sel = $("dsg-scenario");
    if (back) back.hidden = !st.recommended || st.code === st.recommended;
    if (sel && st.code) sel.value = st.code;
  }

  async function recommendedCode(codes) {
    let rec = null;
    try { rec = window.workflowUi?.recommendedCode?.() || null; } catch { rec = null; }
    if (!rec || !codes.includes(rec)) {
      try { rec = (await getJson(`/api/x/design_options?run_id=${encodeURIComponent(runId())}`)).recommended; } catch { rec = null; }
    }
    return rec && codes.includes(rec) ? rec : codes[0] || null;
  }

  // One load at a time: a newer selection aborts the older request, and stale responses are ignored by token.
  async function load() {
    const run = runId();
    if (st.ctrl) st.ctrl.abort();
    const ctrl = st.ctrl = new AbortController();
    const token = ++st.token;
    st.busy = true; st.design = null;
    syncControls();
    $("dsg-body").textContent = "";
    const started = Date.now();
    const tick = setInterval(() => { if (token === st.token) message(`Designing and checking option ${st.code}... ${Math.round((Date.now() - started) / 1000)} s`); }, 1000);
    message(`Designing and checking option ${st.code}...`);
    try {
      let d = null;
      for (let attempt = 0; ; attempt++) {
        try { d = await getJson(`/api/x/design?${query()}`, ctrl.signal); break; }
        catch (e) {
          if (e.name === "AbortError" || e.http || attempt >= 2 || token !== st.token) throw e;
          message(`Connection problem, retrying (${attempt + 1}/2)...`);
          await wait(800 * (attempt + 1));
          if (token !== st.token) return;
        }
      }
      if (token !== st.token) return;
      st.design = d; st.code = d.meta.scenario; st.run = run;
      message("");
      syncControls();
      render(d);
    } catch (e) {
      if (token !== st.token || e.name === "AbortError") return;
      st.design = null;
      const text = e instanceof TypeError ? "Could not reach the server (Failed to fetch). Check that the app is running, then retry." : (e.message || String(e));
      message(text);
      const retry = h("button", "Retry", "secondary"); retry.id = "dsg-retry"; retry.type = "button";
      retry.onclick = () => load();
      $("dsg-message").append(" ", retry);
    } finally {
      clearInterval(tick);
      if (token === st.token) { st.busy = false; if (st.ctrl === ctrl) st.ctrl = null; }
    }
  }

  async function show() {
    const host = $("view-design");
    if (!st.built) build(host);
    if (!runId() || !results().length) { message("Solve scenarios first (SOLVE tab); the design is built from a saved run."); return; }
    const sel = $("dsg-scenario");
    if (st.run !== runId() || !sel.options.length) {
      const codes = results().map(r => r.code);
      const run = runId();
      st.run = run; st.design = null;
      const rec = await recommendedCode(codes);
      if (run !== runId()) return;
      st.recommended = rec;
      sel.textContent = "";
      results().forEach(r => {
        const o = h("option", `${r.code} - ${r.name || ""}${r.code === rec ? " ★ Recommended" : ""}`); o.value = r.code; sel.append(o);
      });
      st.code = rec;
      load();
      return;
    }
    if (!st.design && !st.busy) load();
  }

  window.designPage = {show, state: st};
})();
