"use strict";
// Power Flow page: PSS/E-style results on the SLD, RAW export, failure suggestions that are applied to the scenario inputs and re-run.
// Also publishes window.powerFlowStatus (PASS/WARN/FAIL per scenario) and the "powerflow-status" document event.
(() => {
  const NS = "http://www.w3.org/2000/svg";
  const $ = id => document.getElementById(id);
  const svgEl = (tag, attrs, text) => {
    const e = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs || {})) e.setAttribute(k, v);
    if (text !== undefined) e.textContent = text;
    return e;
  };
  const h = (tag, text, cls) => {
    const e = document.createElement(tag);
    if (text !== undefined) e.textContent = text;
    if (cls) e.className = cls;
    return e;
  };
  // Fixed decimals (capped at 4) with thousands separators; never prints "-0.00".
  const fmt = (v, d = 2) => {
    if (v === null || v === undefined || v === "" || !Number.isFinite(Number(v))) return "-";
    const dd = Math.min(d, 4), n = Math.abs(Number(v)) < 0.5 * 10 ** -dd ? 0 : Number(v);
    return n.toLocaleString("en-US", {minimumFractionDigits: dd, maximumFractionDigits: dd});
  };
  // Plain number rounded to 4 decimals: for input values and compact text.
  const r4 = v => (v === null || v === undefined || v === "" || !Number.isFinite(Number(v))) ? "-" : String(Math.round(Number(v) * 10000) / 10000);
  const shown4 = v => (v === null || v === undefined || v === "" || !Number.isFinite(Number(v))) ? "-" : Number(v).toLocaleString("en-US", {maximumFractionDigits: 4});
  const COLOUR = {ok: "#2a9d4b", warn: "#f0a202", bad: "#d62839", none: "#5b6c8f"};
  // Limits come from the scenario's own power-flow settings so colours agree with the violation list.
  const limitsOf = (id) => {
    const a = st.snap?.assumptions || {}, base = a.base || {};
    const node = (a.nodes || []).find(n => n.id === id) || {};
    const [lo, hi] = base.voltage_limits || [0.95, 1.05];
    return {lo: node.vmin_pu ?? lo, hi: node.vmax_pu ?? hi};
  };
  const thermal = () => { const b = st.snap?.assumptions?.base || {}; return {limit: b.thermal_limit_pct ?? 100, high: b.high_loading_pct ?? 90}; };
  const MARGIN_PU = 0.02;
  const voltClass = (vm, lim) => (vm < lim.lo || vm > lim.hi) ? "bad" : (vm < lim.lo + MARGIN_PU || vm > lim.hi - MARGIN_PU) ? "warn" : "ok";
  const voltColour = (vm, lim) => COLOUR[voltClass(vm, lim)];
  const loadClass = (pct, rated) => { if (!rated) return "none"; const t = thermal(); return pct >= t.limit ? "bad" : pct >= t.high ? "warn" : "ok"; };
  const loadColour = (pct, rated) => COLOUR[loadClass(pct, rated)];
  const statusClass = s => "pf-status pf-" + String(s || "none").toLowerCase().replace("_", "-");
  const KIND_COLOUR = {grid: "#5b6c8f", load: "#8c6d3f", bus: "#222", substation: "#6a5acd", pv: "#d99200", bess: "#2a9d8f", wind: "#3b8fd0"};
  const KIND_SHORT = {grid: "GRID", load: "LOAD", pv: "PV", bess: "BESS", wind: "WIND", substation: "SUB", ng: "NG", ng_chp: "NG CHP", h2: "H2",
    h2_chp: "H2 CHP", diesel: "DSL", biogas: "BIO", biomass: "BMS"};
  const HISTORY_KEY = "genstudio-pf-history";

  const st = {code: null, picks: [], hours: 0, snap: null, report: null, suggestions: [], busy: 0, anim: false, speed: 1, raf: null, built: false, seq: 0,
    screened: {}, history: [], show: {volt: true, angle: true, flow: true, loading: true, gen: true, load: true, viol: true}, runFor: null};
  try { st.history = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]"); } catch { st.history = []; }

  async function post(body) {
    const response = await fetch("/api/x/powerflow", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)});
    const data = await response.json();
    if (!response.ok || data.error) throw new Error(data.error || "Power-flow request failed.");
    return data;
  }
  const results = () => (typeof solveSnapshot !== "undefined" && solveSnapshot?.summary?.results) || [];
  const runId = () => (typeof solveRun !== "undefined" ? solveRun : null);
  const hasRun = () => !!runId() && results().length > 0;
  const message = (text, link) => {
    const box = $("pfp-message");
    if (!box) return;
    box.textContent = text || ""; box.hidden = !text;
    if (text && link) {
      const b = h("button", `Go to ${link} inputs`, "secondary"); b.type = "button"; b.id = "pfp-goto-inputs";
      b.onclick = () => { try { switchView("load"); inputWorkspace.openGroup(link); } catch (e) { box.textContent = String(e.message || e); } };
      box.append(" ", b);
    }
  };
  const fail = error => { message(error.message || String(error), error.link); };
  function checkMicrogridPair(writes) {
    if (!("microgrid_min_mw" in writes) && !("microgrid_max_mw" in writes)) return;
    const get = key => key in writes ? writes[key] : Number($(key)?.value);
    const lo = get("microgrid_min_mw"), hi = get("microgrid_max_mw");
    if (Number.isFinite(lo) && Number.isFinite(hi) && lo > hi) {
      const e = new Error(`Nothing was applied: the Microgrid minimum (${lo} MW) would exceed the maximum (${hi} MW). ` +
        "Tick or edit both rows so that minimum <= maximum, or adjust them on the Microgrid input page.");
      e.link = "Microgrid";
      throw e;
    }
  }

  // ------------------------------------------------------------ status API
  function statusOf(code) {
    const page = st.screened[code];
    if (page && page.run === runId()) return {code, status: page.status, normal_status: page.normal_status, n1_status: page.n1_status,
      violations: page.violations, source: "page"};
    const result = results().find(r => r.code === code);
    const t = result?.technical_status;
    if (!t) return {code, status: "NOT_RUN", source: "none"};
    return {code, status: t.status, normal_status: t.normal_status, n1_status: t.n1_status, violations: (t.violations || []).length,
      message: t.message, source: "solve"};
  }
  let lastStatusKey = "";
  function refreshStatus() {
    const all = Object.fromEntries(results().map(r => [r.code, statusOf(r.code)]));
    const key = JSON.stringify([runId(), all]);
    if (key === lastStatusKey) return;
    lastStatusKey = key;
    document.dispatchEvent(new CustomEvent("powerflow-status", {detail: {run: runId(), statuses: all}}));
    renderBadges();
  }
  function badge(code) {
    const s = statusOf(code);
    const e = h("span", s.status === "NOT_RUN" ? "PF n/a" : "PF " + s.status, statusClass(s.status));
    e.dataset.code = code;
    e.title = `Power-flow technical status for ${code}` + (s.normal_status ? ` (normal ${s.normal_status}, N-1 ${s.n1_status})` : "");
    return e;
  }
  window.powerFlowStatus = {
    get: statusOf,
    all: () => Object.fromEntries(results().map(r => [r.code, statusOf(r.code)])),
    badge,
    refresh: refreshStatus,
    open: code => { if (code) st.code = code; switchView("powerflow"); },
  };

  function renderBadges() {
    const box = $("pfp-badges");
    if (!box) return;
    box.replaceChildren();
    for (const r of results()) {
      const b = h("button", undefined, "pfp-chip secondary");
      b.type = "button";
      b.append(h("span", r.code + " "), badge(r.code));
      b.onclick = () => { st.code = r.code; syncScenario(); guarded(runCase); };
      if (r.code === st.code) b.classList.add("active");
      box.append(b);
    }
    if (!results().length) box.append(h("span", "No saved solve yet - run SOLVE first.", "muted"));
  }

  // ------------------------------------------------------------ page construction
  function build() {
    if (st.built) return;
    st.built = true;
    const view = $("view-powerflow");
    view.append(h("h2", "Power Flow"),
      h("p", "AC power-flow check of each solved scenario on its single-line diagram, with PSS/E-style results, a PSS/E v33 RAW export and " +
        "suggested corrections you can approve, edit, feed into the scenario inputs and re-run.", "muted"));
    const err = h("p", undefined, "notice"); err.id = "pfp-message"; err.hidden = true; err.setAttribute("role", "alert");
    const badges = h("div", undefined, "pfp-badges"); badges.id = "pfp-badges";
    const verify = h("section", undefined, "panel pfp-verifycard"); verify.id = "pfp-verifycard";
    verify.setAttribute("aria-label", "Technical verification");
    view.append(err, badges, verify);

    const controls = h("div", undefined, "panel pfp-controls");
    const scenario = h("select"); scenario.id = "pfp-scenario";
    const kase = h("select"); kase.id = "pfp-case";
    const hour = h("input"); hour.type = "number"; hour.id = "pfp-hour"; hour.min = 0; hour.value = 0; hour.step = 1;
    hour.setAttribute("aria-label", "Hour of appraisal (0 = first dispatch hour)");
    const when = h("input"); when.type = "datetime-local"; when.id = "pfp-datetime"; when.step = 3600;
    when.setAttribute("aria-label", "Date and time of the dispatch hour");
    const label = (text, input) => { const l = h("label", text + " ", "pfp-field"); l.append(input); return l; };
    const run = h("button", "Run power flow"); run.id = "pfp-run"; run.type = "button";
    const screen = h("button", "Screen all cases + N-1", "secondary"); screen.id = "pfp-screen"; screen.type = "button";
    const raw = h("button", "Export PSS/E RAW", "secondary"); raw.id = "pfp-raw"; raw.type = "button";
    const anim = h("button", "Animate power flow: off", "secondary"); anim.id = "pfp-animate"; anim.type = "button";
    anim.setAttribute("aria-pressed", "false");
    const speed = h("select"); speed.id = "pfp-speed"; speed.setAttribute("aria-label", "Animation speed");
    for (const [v, text] of [[0.5, "Slow"], [1, "Normal"], [2, "Fast"]]) speed.append(new Option(text, String(v)));
    speed.value = "1";
    speed.onchange = () => { st.speed = Number(speed.value) || 1; };
    const settings = h("button", "Power-flow settings...", "secondary"); settings.id = "pfp-settings"; settings.type = "button";
    settings.onclick = () => openProps("settings");
    controls.append(label("Scenario", scenario), label("Case", kase), run, screen, raw, anim, label("Speed", speed), settings);
    const hourbox = h("div", undefined, "pfp-hourbox"); hourbox.id = "pfp-hourbox";
    const current = h("strong", "", "pfp-hour-current"); current.id = "pfp-hour-current";
    const help = h("p", "", "muted pfp-hour-help"); help.id = "pfp-hour-help";
    hourbox.append(current, label("Date and time", when), label("or hour of appraisal", hour), help);
    controls.append(hourbox);
    controls.append(h("p", "Double-click a bus, generator, load, grid or transformer on the diagram to edit its PSS/E-style power-flow parameters.", "muted"));
    const toggles = h("div", undefined, "pfp-toggles");
    for (const [key, text] of [["volt", "Voltage (pu)"], ["angle", "Angle (deg)"], ["flow", "Branch MW / Mvar"], ["loading", "Loading colours"],
      ["gen", "Generation"], ["load", "Loads"], ["viol", "Violations"]]) {
      const input = h("input"); input.type = "checkbox"; input.checked = st.show[key]; input.id = "pfp-show-" + key;
      input.onchange = () => { st.show[key] = input.checked; applyToggles(); };
      const l = h("label", undefined, "pfp-toggle"); l.append(input, document.createTextNode(" " + text));
      toggles.append(l);
    }
    controls.append(toggles);
    view.append(controls);

    const summary = h("div", undefined, "pfp-summary"); summary.id = "pfp-summary";
    const holder = h("div", undefined, "pfp-sld"); holder.id = "pfp-sld";
    const legend = h("div", undefined, "pfp-legend"); legend.id = "pfp-legend";
    const charts = h("div", undefined, "pfp-charts"); charts.id = "pfp-charts";
    const tables = h("div", undefined, "pfp-tables"); tables.id = "pfp-tables";
    const sugg = h("section", undefined, "panel pfp-suggestions"); sugg.id = "pfp-suggestions";
    const hist = h("section", undefined, "panel pfp-history"); hist.id = "pfp-history";
    view.append(summary, holder, legend, charts, tables, sugg, hist);

    scenario.onchange = () => { st.code = scenario.value; st.snap = null; st.report = null; st.suggestions = []; guarded(loadHours); };
    kase.onchange = () => { syncHourBox(); if (kase.value !== "user") guarded(runCase); };
    run.onclick = () => guarded(runCase);
    // Editing either hour control switches the Case to the user-chosen hour.
    const useHour = () => { kase.value = "user"; syncHourBox(); guarded(runCase); };
    hour.onchange = () => { hour.value = clampHour(hour.value); useHour(); };
    when.onchange = () => {
      const i = indexOfStamp(when.value);
      if (i === null) { syncHourBox(); return; }
      hour.value = clampHour(i);
      useHour();
    };
    screen.onclick = () => guarded(screenAll);
    raw.onclick = () => guarded(exportRaw);
    anim.onclick = () => setAnimation(!st.anim);
    renderHistory();
  }

  function syncScenario() {
    const sel = $("pfp-scenario");
    const codes = results().map(r => r.code);
    sel.replaceChildren(...codes.map(c => new Option(c, c)));
    if (!codes.includes(st.code)) st.code = codes[0] || null;
    if (st.code) sel.value = st.code;
    for (const id of ["pfp-run", "pfp-screen", "pfp-raw"]) $(id).disabled = !st.code;
    renderBadges();
  }

  async function loadHours() {
    if (!hasRun() || !st.code) { renderBadges(); return; }
    const data = await post({action: "hours", run_id: runId(), scenario: st.code});
    st.picks = data.picks; st.hours = data.hours;
    Object.assign(st, {start: data.start, end: data.end, peakIndex: data.peak_index, peakStamp: data.peak_timestamp, hourly: data.hourly !== false});
    const kase = $("pfp-case"), previous = kase.value;
    kase.replaceChildren();
    const names = {peak: "Peak load", min_load: "Minimum load", high_pv: "High PV (maximum solar/wind output)"};
    const order = ["peak", "min_load", "high_pv"];
    const sorted = [...data.picks].sort((a, b) => (order.indexOf(a.kind) + 1 || 99) - (order.indexOf(b.kind) + 1 || 99));
    for (const p of sorted) {
      if (p.kind === "islanded") kase.append(new Option(`${p.label} - ${p.timestamp} (informational)`, "i:" + p.index));
      else kase.append(new Option(`${names[p.kind] || p.label} - ${p.timestamp}`, "p:" + p.index));
    }
    kase.append(new Option("User-chosen hour", "user"));
    kase.value = [...kase.options].some(o => o.value === previous) ? previous : "p:" + data.peak_index;
    st.islandNote = data.island_note || null; st.islandAssessed = data.islanded_assessed === true;
    $("pfp-hour").max = Math.max(0, data.hours - 1);
    const when = $("pfp-datetime");
    when.min = isoLocal(data.start); when.max = isoLocal(data.end);
    when.disabled = !st.hourly;
    syncHourBox();
    await runCase();
  }

  // ---- hour selector: date/time <-> hour of appraisal (hour 0 = first dispatch timestamp)
  const isoLocal = s => String(s || "").trim().replace(" ", "T").slice(0, 16);
  const stampMs = s => Date.parse(String(s).trim().replace(" ", "T").slice(0, 16) + ":00Z");
  const clampHour = v => Math.max(0, Math.min(Math.max(0, st.hours - 1), Math.round(Number(v)) || 0));
  const indexOfStamp = value => (st.hourly && value && st.start) ? Math.round((stampMs(value) - stampMs(st.start)) / 3600000) : null;
  const stampOfIndex = i => {
    const p = st.picks.find(x => x.index === i);
    if (p) return p.timestamp;
    if (st.snap && st.snap.hour_index === i && st.snap.timestamp) return st.snap.timestamp;
    if (st.hourly && st.start) return new Date(stampMs(st.start) + i * 3600000).toISOString().slice(0, 16).replace("T", " ");
    return null;
  };

  function syncHourBox() {
    if (!$("pfp-hour") || !st.hours) return;
    const i = selectedHour(), stamp = stampOfIndex(i);
    $("pfp-hour").value = i;
    $("pfp-datetime").value = stamp ? isoLocal(stamp) : "";
    const pick = st.picks.find(x => x.index === i);
    $("pfp-hour-current").textContent = `${pick ? pick.label : "User-chosen hour"}: ${stamp ? isoLocal(stamp).replace("T", " ") : "hour " + i} (hour ${i})`;
    const first = isoLocal(st.start).replace("T", " "), last = isoLocal(st.end).replace("T", " ");
    $("pfp-hour-help").textContent = `Hour 0 = ${first}; hour ${st.hours - 1} = ${last}; peak hour is ${st.peakIndex} (${isoLocal(st.peakStamp).replace("T", " ")}). ` +
      (st.hourly ? "Pick a date/time or type the hour number - either one selects that dispatch hour."
                 : "The dispatch timestamps are not regular hours, so choose by hour number.");
  }

  const topology = () => {
    const root = topologyEditor.value();
    return (root.diagrams?.[st.code]?.nodes?.length || root.nodes?.length) ? root : undefined;
  };

  // A saved run can be opened without the drawing loaded in the editor: adopt the run's own saved topology so edits and applies work.
  async function ensureTopology(code) {
    if (topologyEditor.hasDrawing(code)) return true;
    if (!hasRun()) return false;
    const data = await post({action: "topology", run_id: runId(), scenario: code});
    const saved = data.topology;
    const editorEmpty = !(topologyEditor.value().nodes || []).length && !Object.values(topologyEditor.value().diagrams || {}).some(g => g.nodes?.length);
    if (!saved || !editorEmpty) return topologyEditor.hasDrawing(code);
    topologyEditor.restore(saved);
    return topologyEditor.hasDrawing(code);
  }
  window.pfPageEnsure = ensureTopology;

  function selectedHour() {
    const v = $("pfp-case").value;
    if (v === "user") return Math.max(0, Math.min(st.hours - 1, Number($("pfp-hour").value) || 0));
    return Number(v.slice(2));
  }

  async function runCase(extra) {
    if (!hasRun() || !st.code) throw new Error("Solve a scenario first (SOLVE tab); the power flow runs on its saved dispatch.");
    message("");
    const seq = ++st.seq;
    const islanded = $("pfp-case").value.startsWith("i:");
    const body = {action: "snapshot", run_id: runId(), scenario: st.code, topology: topology(), hour_index: selectedHour(), ...(islanded ? {kind: "islanded"} : {}), ...(extra || {})};
    const data = await post(body);
    if (seq !== st.seq) return;
    st.snap = data;
    st.suggestions = data.suggestions || [];
    st.runFor = runId();
    syncHourBox();
    renderAll();
  }

  // One click: load a failing case (a screened hour, or an N-1 outage at the peak hour) into the SLD.
  const showCase = row => guarded(() => runCase({hour_index: row.hour_index, outages: row.outages || [], gens_out: row.gens_out || [], kind: undefined}));

  async function screenAll() {
    if (!hasRun() || !st.code) throw new Error("Solve a scenario first.");
    message("");
    $("pfp-summary").textContent = "Screening all cases and N-1 outages...";
    const report = await post({action: "screen", run_id: runId(), scenario: st.code, topology: topology()});
    recordScreen(report);
    st.report = report;
    st.suggestions = report.suggestions || [];
    if (!st.snap) await runCase(); else renderAll();
  }

  function recordScreen(report) {
    st.screened[report.scenario] = {run: runId(), status: report.status, normal_status: report.normal_status, n1_status: report.n1_status,
      violations: report.summary.violations, failing: report.failing_cases || [], screened: report.screened || null, notes: report.warnings || [],
      islanded: report.islanded || null};
    refreshStatus();
  }

  async function exportRaw() {
    const data = await post({action: "raw", run_id: runId(), scenario: st.code, topology: topology(), hour_index: selectedHour()});
    const url = URL.createObjectURL(new Blob([data.text], {type: "text/plain"}));
    const a = h("a"); a.href = url; a.download = data.filename;
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    message(`Exported ${data.filename}: PSS/E v33 RAW at the selected hour (solved voltages, angles and dispatch included).` +
      ((data.notes || []).length ? " Left out of the file: " + data.notes.join(" ") : "") +
      ((data.problems || []).length ? " WARNING - topology check: " + data.problems.join("; ") : ""));
  }

  async function guarded(fn) {
    st.busy++;
    const controls = ["pfp-run", "pfp-screen", "pfp-raw"].map($).filter(Boolean);
    controls.forEach(b => { b.disabled = true; });
    $("view-powerflow")?.setAttribute("aria-busy", "true");
    try { await fn(); } catch (e) { fail(e); }
    finally {
      if (--st.busy === 0) {
        controls.forEach(b => { b.disabled = !st.code; });
        $("view-powerflow")?.removeAttribute("aria-busy");
      }
    }
  }

  function openProps(kind, id) {
    guarded(async () => {
      if (!st.code) return;
      await ensureTopology(st.code);
      await pfProps.open({kind, id, scenario: st.code});
    });
  }
  document.addEventListener("pfprops-changed", () => {
    const view = $("view-powerflow");
    if (!view || view.hidden || !st.built || !hasRun()) return;
    guarded(async () => { await inputWorkspace.saveNow(); st.snap = null; st.report = null; await runCase(); });
  });

  // ------------------------------------------------------------ SLD
  function port(node, side) {
    const vectors = {top: [0, -38], bottom: [0, 38], left: [-70, 0], right: [70, 0]};
    const v = [...(vectors[side] || [0, 0])], s = node.scale || 0.8, a = (node.rotation || 0) * Math.PI / 180;
    v[0] *= s; v[1] *= s;
    return {x: Math.round(node.x + v[0] * Math.cos(a) - v[1] * Math.sin(a)), y: Math.round(node.y + v[0] * Math.sin(a) + v[1] * Math.cos(a))};
  }
  function orthogonal(points) {
    const out = [];
    for (const p of points) {
      const prev = out[out.length - 1];
      if (prev && prev.x !== p.x && prev.y !== p.y) out.push({x: prev.x, y: p.y});
      if (!prev || prev.x !== p.x || prev.y !== p.y) out.push({...p});
    }
    return out;
  }
  function diagramFor(code) {
    const root = topologyEditor.value();
    const graph = root.diagrams?.[code] || (root.nodes?.length ? root : null) || st.snap?.diagram;
    if (!graph) return null;
    const nodes = graph.nodes, byId = new Map(nodes.map(n => [n.id, n]));
    const lines = graph.lines.filter(l => byId.has(l.source) && byId.has(l.target)).map(l => ({
      ...l, route: orthogonal([port(byId.get(l.source), l.source_port), ...(l.points || []), port(byId.get(l.target), l.target_port)])}));
    return {nodes, lines};
  }

  function longestSegment(route) {
    let mid = route[0], best = -1;
    for (let i = 1; i < route.length; i++) {
      const a = route[i - 1], b = route[i], len = Math.hypot(b.x - a.x, b.y - a.y);
      if (len > best) { best = len; mid = {x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, ang: Math.atan2(b.y - a.y, b.x - a.x), horizontal: Math.abs(b.x - a.x) >= Math.abs(b.y - a.y)}; }
    }
    return mid;
  }

  function violationSets(violations) {
    const nodes = new Set(), lines = new Set();
    for (const v of violations || []) {
      if (!v.component) continue;
      if (["thermal", "high_loading"].includes(v.type)) lines.add(v.component); else nodes.add(v.component);
    }
    return {nodes, lines};
  }

  function drawSld() {
    const holder = $("pfp-sld");
    holder.replaceChildren();
    const c = st.snap?.case;
    if (!c) return;
    const graph = diagramFor(st.code);
    if (!graph || !graph.nodes.length) {
      holder.append(h("p", "This scenario has no single-line diagram. Draw it under Model inputs > Microgrid > Topology.", "notice"));
      return;
    }
    const buses = new Map(c.buses.map(b => [b.id, b])), flows = new Map(c.branches.map(b => [b.id, b])), gens = new Map(c.gens.map(g => [g.id, g]));
    const byId = new Map(graph.nodes.map(n => [n.id, n]));
    const tapOf = new Map((st.snap.assumptions?.branches || []).map(b => [b.id, b.tap]));
    // Shunt nodes are folded into their bus by the solver (drawn here as a capacitor/reactor symbol); Load nodes the solver dropped as
    // unwired duplicates have no result and are not drawn.
    const shuntAt = new Map();
    for (const l of graph.lines) for (const [a, o] of [[l.source, l.target], [l.target, l.source]]) if (byId.get(a)?.kind === "shunt") shuntAt.set(o, byId.get(a));
    const shown = n => n.kind !== "shunt" && buses.has(n.id);
    graph.nodes = graph.nodes.filter(shown);
    graph.lines = graph.lines.filter(l => shown(byId.get(l.source) || {}) && shown(byId.get(l.target) || {}));
    if (!graph.nodes.length) {
      holder.append(h("p", "None of the drawn components is part of the solved network.", "notice"));
      return;
    }
    const xs = graph.nodes.map(n => n.x), ys = graph.nodes.map(n => n.y);
    const x0 = Math.min(...xs) - 130, x1 = Math.max(...xs) + 250, y0 = Math.min(...ys) - 90, y1 = Math.max(...ys) + 110;
    const svg = svgEl("svg", {id: "pfp-svg", viewBox: `${x0} ${y0} ${x1 - x0} ${y1 - y0}`, role: "group", "aria-label": "Single-line diagram with power-flow results", class: "pfp-svg"});
    const bad = violationSets(st.snap.violations);
    const portsAt = new Map();
    for (const l of graph.lines) {
      for (const [id, side] of [[l.source, l.source_port], [l.target, l.target_port]]) (portsAt.get(id) || portsAt.set(id, new Set()).get(id)).add(side);
    }
    for (const line of graph.lines) {
      const f = flows.get(line.id);
      const d = line.route.map((p, i) => `${i ? "L" : "M"}${p.x},${p.y}`).join(" ");
      const g = svgEl("g", {class: "pfp-branch", "data-id": line.id});
      g.append(svgEl("path", {d, class: "pfp-wire", fill: "none"}));
      if (!f || !f.energized) { g.querySelector("path").classList.add("pfp-dead"); svg.append(g); continue; }
      const rated = !!f.rating_mva, loading = f.loading_pct || 0;
      const colour = loadColour(loading, rated);
      g.append(svgEl("title", {}, `${f.name || line.id}: ${fmt(f.p_from_mw, 4)} MW, ${fmt(f.q_from_mvar, 4)} Mvar from ${f.from_name || ""}; loss ${fmt(f.loss_mw, 4)} MW` +
        (rated ? `; ${fmt(loading, 1)} % of ${fmt(f.rating_mva, 2)} MVA` : "")));
      g.append(svgEl("path", {d, class: "pfp-halo pfp-g-loading", fill: "none", stroke: colour}));
      // Results are reported at the engine's from-end; the drawn route starts at the line's source node.
      const dir = (f.from_id !== undefined && f.from_id === line.target ? -1 : 1) * (f.p_from_mw >= 0 ? 1 : -1);
      const mag = Math.max(Math.abs(f.p_from_mw), Math.abs(f.q_from_mvar));
      if (mag > 1e-4) g.append(svgEl("path", {d, class: "pfp-flow pfp-g-flow", fill: "none", stroke: colour, "data-sign": dir, "data-mag": Math.max(mag, 0.05)}));
      const mid = longestSegment(line.route), xf = f.kind === "transformer";
      if (xf) {
        g.append(svgEl("circle", {cx: mid.x - 6, cy: mid.y, r: 11, class: "pfp-xfmr", stroke: colour}), svgEl("circle", {cx: mid.x + 6, cy: mid.y, r: 11, class: "pfp-xfmr", stroke: colour}));
      }
      if (mag > 1e-4) {
        const ang = Math.atan2(Math.sin(mid.ang) * dir, Math.cos(mid.ang) * dir) * 180 / Math.PI;
        const off = xf ? 30 : 0, ax = mid.x + Math.cos(mid.ang) * off, ay = mid.y + Math.sin(mid.ang) * off;
        g.append(svgEl("polygon", {points: "11,0 -7,7 -7,-7", fill: colour, class: "pfp-arrow pfp-g-flow", transform: `translate(${ax},${ay}) rotate(${ang})`}));
      }
      // Labels sit beside a vertical run and above/below a horizontal one so they never cover the wire or the symbol.
      const vert = !mid.horizontal, lx = vert ? mid.x + (xf ? 24 : 12) : mid.x, anchor = vert ? "start" : "middle";
      const ly = vert ? mid.y - 4 : mid.y - (xf ? 20 : 10);
      g.append(svgEl("text", {x: lx, y: ly, "text-anchor": anchor, class: "pfp-label pfp-g-flow"}, `${fmt(f.p_from_mw, 2)} MW ${fmt(f.q_from_mvar, 2)} Mvar`));
      const extra = [];
      if (rated) extra.push([`${fmt(loading, 1)} % of ${fmt(f.rating_mva, 1)} MVA`, "pfp-g-loading", colour]);
      if (xf) {
        const kvs = [byId.get(line.source), byId.get(line.target)].map(x => buses.get(x?.id)?.kv).filter(v => v), tap = tapOf.get(line.id);
        if (kvs.length === 2) extra.push([`${shown4(kvs[0])}/${shown4(kvs[1])} kV` + (tap && Math.abs(tap - 1) > 1e-9 ? `, tap ${fmt(tap, 4)}` : ""), "pfp-xfmr-kv", null]);
      }
      extra.forEach(([text, cls, fill], i) => {
        const y = vert ? ly + 14 * (i + 1) : mid.y + (xf ? 34 : 22) + 14 * i;
        const t = svgEl("text", {x: lx, y, "text-anchor": anchor, class: "pfp-label " + cls}, text);
        if (fill) t.setAttribute("fill", fill);
        g.append(t);
      });
      if (bad.lines.has(line.id)) g.classList.add("pfp-violation");
      svg.append(g);
    }
    for (const n of graph.nodes) {
      const b = buses.get(n.id), gen = gens.get(n.id);
      const s = n.scale || 0.8, w = 140 * s, hgt = 76 * s;
      const g = svgEl("g", {class: "pfp-node", "data-id": n.id, "data-kind": n.kind});
      const colour = KIND_COLOUR[n.kind] || "#8a4b2a";
      if (n.kind === "bus") g.append(svgEl("rect", {x: n.x - w / 2, y: n.y - 4, width: w, height: 8, rx: 2, fill: colour, transform: `rotate(${n.rotation || 0} ${n.x} ${n.y})`}));
      else {
        g.append(svgEl("rect", {x: n.x - w / 2, y: n.y - hgt / 2, width: w, height: hgt, rx: 8, class: "pfp-box", stroke: colour, transform: `rotate(${n.rotation || 0} ${n.x} ${n.y})`}));
        g.append(svgEl("text", {x: n.x, y: n.y + 4, "text-anchor": "middle", class: "pfp-kind", fill: colour}, KIND_SHORT[n.kind] || n.kind));
      }
      const rot = Math.abs(((n.rotation || 0) % 180)) === 90, halfW = (rot ? (n.kind === "bus" ? 4 : hgt) : w) / 2;
      const used = portsAt.get(n.id) || new Set(), left = used.has("right") && !used.has("left");
      const tx = n.x + (left ? -halfW - 8 : halfW + 8), ta = left ? "end" : "start";
      const rows = [];
      if (b && b.energized) rows.push(["volt", `${fmt(b.vm, 4)} pu  ${fmt(b.va_deg, 2)}°`]);
      else if (b) rows.push(["offline", "de-energized"]);
      rows.push(["name", n.label || n.id]);
      if (b && b.num !== undefined) rows.push(["tag", `${b.num} ${b.name || ""} · ${shown4(b.kv)} kV`]);
      if (gen) {
        const pct = gen.pct_mva ?? gen.pct_mw;
        const text = gen.tech === "grid" ? `${gen.p_mw >= 0 ? "Import" : "Export"} ${fmt(Math.abs(gen.p_mw), 2)} MW ${fmt(gen.q_mvar, 2)} Mvar` :
          `${fmt(gen.p_mw, 2)} MW ${fmt(gen.q_mvar, 2)} Mvar` + (pct !== null && pct !== undefined ? ` (${fmt(pct, 0)} %)` : "");
        rows.push([gen.q_limited ? "gen limited" : "gen", text]);
      } else if (b && b.load_mw > 0) rows.push(["load", `Load ${fmt(b.load_mw, 2)} MW ${fmt(b.load_mvar, 2)} Mvar`]);
      const top = n.y - (rows.length - 1) * 7;
      rows.forEach(([kind, text], i) => {
        const y = top + i * 14 + 4;
        if (kind === "volt") {
          const vg = svgEl("g", {class: "pfp-g-volt"});
          const wd = text.length * 6.2 + 10;
          vg.append(svgEl("rect", {x: left ? tx - wd : tx - 4, y: y - 12, width: wd, height: 16, rx: 4, fill: voltColour(b.vm, limitsOf(n.id))}),
            svgEl("text", {x: left ? tx - 5 : tx + 1, y, "text-anchor": ta, class: "pfp-volt"}, text));
          g.append(vg);
        } else {
          const cls = {name: "pfp-name", tag: "pfp-bus-tag", offline: "pfp-label pfp-offline", gen: "pfp-label pfp-g-gen", "gen limited": "pfp-label pfp-g-gen pfp-limited", load: "pfp-label pfp-g-load"}[kind];
          g.append(svgEl("text", {x: tx, y, "text-anchor": ta, class: cls}, text));
        }
      });
      g.append(svgEl("title", {}, b ? `${n.label || n.id} (${b.num} ${b.name || ""}): ${fmt(b.vm, 4)} pu, ${fmt(b.vm * b.kv, 4)} kV, ${fmt(b.va_deg, 4)}°` : (n.label || n.id)));
      if (b && b.shunt_mvar) {
        const sn = shuntAt.get(n.id);
        const sx = sn ? sn.x : n.x + 110, sy = sn ? sn.y : n.y + 60, cap = b.shunt_mvar > 0;
        const sg = svgEl("g", {class: "pfp-shunt pfp-g-gen", "data-shunt": n.id});
        sg.append(svgEl("path", {d: `M${n.x + (n.kind === "bus" ? 40 : 0)},${n.y} L${sx},${n.y} L${sx},${sy - 8}`, class: "pfp-wire", fill: "none"}));
        if (cap) sg.append(svgEl("path", {d: `M${sx - 12},${sy - 8} H${sx + 12} M${sx - 12},${sy + 2} H${sx + 12}`, class: "pfp-shunt-sym", fill: "none"}),
          svgEl("path", {d: `M${sx},${sy + 2} V${sy + 16} M${sx - 10},${sy + 16} H${sx + 10} M${sx - 6},${sy + 20} H${sx + 6} M${sx - 2},${sy + 24} H${sx + 2}`, class: "pfp-shunt-sym", fill: "none"}));
        else sg.append(svgEl("path", {d: `M${sx},${sy - 8} v4 a5,5 0 0 1 0,10 a5,5 0 0 1 0,10 a5,5 0 0 1 0,10 v4 M${sx - 10},${sy + 36} H${sx + 10}`, class: "pfp-shunt-sym", fill: "none"}));
        sg.append(svgEl("text", {x: sx + 16, y: sy + 4, class: "pfp-label"}, `${cap ? "Cap" : "Reactor"} ${fmt(Math.abs(b.shunt_mvar), 4)} Mvar`),
          svgEl("text", {x: sx + 16, y: sy + 18, class: "pfp-label"}, `${fmt(b.shunt_q_mvar, 4)} Mvar at ${fmt(b.vm, 4)} pu`));
        g.append(sg);
      }
      if (bad.nodes.has(n.id)) g.classList.add("pfp-violation");
      g.setAttribute("tabindex", "0"); g.setAttribute("role", "button");
      g.setAttribute("aria-label", `${n.label || n.id}: double-click or press Enter to edit power-flow properties`);
      g.addEventListener("dblclick", () => openProps("node", n.id));
      g.addEventListener("keydown", e => { if (e.key === "Enter") openProps("node", n.id); });
      svg.append(g);
    }
    for (const el of svg.querySelectorAll(".pfp-branch")) {
      const id = el.getAttribute("data-id");
      el.addEventListener("dblclick", () => openProps("line", id));
    }
    holder.append(svg);
    installZoom(holder, svg, {x: x0, y: y0, w: x1 - x0, h: y1 - y0});
    applyToggles();
  }

  // Wheel zoom (centred on the cursor), drag to pan, buttons for +/-/fit.  The wheel handler is non-passive so the page does not scroll.
  function installZoom(holder, svg, base) {
    const key = `${runId()}|${st.code}`;
    if (!st.view || st.view.key !== key || st.view.bw !== base.w || st.view.bh !== base.h) st.view = {key, bw: base.w, bh: base.h, ...base};
    const v = st.view;
    const apply = () => svg.setAttribute("viewBox", `${v.x} ${v.y} ${v.w} ${v.h}`);
    const zoomAt = (factor, fx, fy) => {
      const nw = Math.min(base.w * 4, Math.max(base.w / 25, v.w * factor)), k = nw / v.w, nh = v.h * k;
      v.x += (v.w - nw) * fx; v.y += (v.h - nh) * fy; v.w = nw; v.h = nh;
      apply();
    };
    apply();
    svg.addEventListener("wheel", e => {
      e.preventDefault();
      const r = svg.getBoundingClientRect();
      zoomAt(Math.exp(Math.max(-300, Math.min(300, e.deltaY)) * 0.0015), (e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height);
    }, {passive: false});
    // Pointer capture is taken only once a real drag starts: capturing on pointerdown retargets click/dblclick to the svg and
    // components would never receive a double-click.
    let drag = null;
    svg.addEventListener("pointerdown", e => {
      if (e.button !== 0) return;
      drag = {sx: e.clientX, sy: e.clientY, x: v.x, y: v.y, moved: false, id: e.pointerId};
    });
    svg.addEventListener("pointermove", e => {
      if (!drag) return;
      const r = svg.getBoundingClientRect();
      if (!drag.moved) {
        if (Math.abs(e.clientX - drag.sx) + Math.abs(e.clientY - drag.sy) <= 4) return;
        drag.moved = true;
        svg.setPointerCapture?.(drag.id);
      }
      v.x = drag.x - (e.clientX - drag.sx) / r.width * v.w;
      v.y = drag.y - (e.clientY - drag.sy) / r.height * v.h;
      apply();
    });
    const end = e => { if (drag?.moved) svg.releasePointerCapture?.(e.pointerId); drag = null; };
    svg.addEventListener("pointerup", end);
    svg.addEventListener("pointercancel", end);
    const bar = h("div", undefined, "pfp-zoombar");
    const btn = (text, title, fn) => { const b = h("button", text, "pfp-zoombtn"); b.type = "button"; b.title = title; b.addEventListener("click", fn); return b; };
    bar.append(btn("+", "Zoom in", () => zoomAt(0.8, 0.5, 0.5)), btn("-", "Zoom out", () => zoomAt(1.25, 0.5, 0.5)),
      btn("Fit", "Reset zoom and pan", () => { Object.assign(v, base); apply(); }), h("span", "Mouse wheel zooms at the cursor; drag to pan.", "muted"));
    holder.prepend(bar);
  }

  function applyToggles() {
    const svg = $("pfp-svg");
    if (!svg) return;
    for (const [key, on] of Object.entries(st.show)) svg.classList.toggle("pfp-hide-" + key, !on);
  }

  function setAnimation(on) {
    st.anim = on;
    const b = $("pfp-animate");
    b.textContent = "Animate power flow: " + (on ? "on" : "off");
    b.setAttribute("aria-pressed", String(on));
    b.classList.toggle("tool-active", on);
    if (st.raf) { cancelAnimationFrame(st.raf); st.raf = null; }
    if (!on) return;
    const tick = () => {
      st.raf = null;
      if (!st.anim || $("view-powerflow").hidden) return;
      const t = performance.now() / 1000;
      for (const p of document.querySelectorAll("#pfp-svg .pfp-flow")) {
        const sign = Number(p.getAttribute("data-sign")) || 1, mag = Number(p.getAttribute("data-mag"));
        p.setAttribute("stroke-dashoffset", String(-sign * t * st.speed * (12 + 22 * Math.min(1, Math.log10(1 + mag * 3) / 1.5))));
      }
      st.raf = requestAnimationFrame(tick);
    };
    st.raf = requestAnimationFrame(tick);
  }

  // ------------------------------------------------------------ tables and summary
  function table(head, rows, cls, caption) {
    const t = h("table", undefined, "pf-cases " + (cls || ""));
    if (caption) t.append(h("caption", caption, "pfp-sr"));
    const tr = h("tr");
    for (const x of head) { const th = h("th", x); th.scope = "col"; tr.append(th); }
    t.append(tr);
    for (const r of rows) {
      const row = h("tr", undefined, r.cls || "");
      for (const cell of r.cells) row.append(h("td", String(cell), /^-?[\d,]*\.?\d+$/.test(String(cell)) ? "num" : ""));
      t.append(row);
    }
    return t;
  }

  function renderSummary() {
    const box = $("pfp-summary");
    box.replaceChildren();
    const s = st.snap;
    if (!s) return;
    const c = s.case, label = st.picks.find(p => p.index === s.hour_index)?.label || "User-chosen hour";
    const outage = (c.outages?.length || c.gens_out?.length);
    const line = h("div", undefined, "pfp-row");
    line.append(h("span", `${st.code} - ${outage ? c.label : label} (${s.timestamp || "hour " + s.hour_index})`, "pfp-title"),
      s.informational ? h("span", "Informational - not used for the recommendation: " + s.status, "pfp-informational")
                      : h("span", "Selected operating point: " + s.status, statusClass(s.status)));
    box.append(line);
    if (s.informational && s.note) box.append(h("p", s.note, "muted pfp-island-note"));
    const isl = st.screened[st.code]?.islanded;
    if (isl) box.append(h("p", `${isl.chip} (informational, not used for the recommendation)`, "muted pfp-island-chip"));
    else if (!s.informational && st.islandAssessed === false) box.append(h("p", "Complete grid disconnection: not assessed (enable it in the Solve-page technical-check options).", "muted pfp-island-chip"));
    const rep = st.screened[st.code];
    const all = h("div", undefined, "pfp-screen-line");
    if (rep && rep.run === runId()) {
      all.append(h("span", "Overall screening (all cases + N-1): " + rep.status, statusClass(rep.status)));
      if (rep.screened?.text) all.append(h("span", rep.screened.text, "muted"));
      box.append(all);
      if (rep.failing.length) {
        if (s.status !== rep.status) box.append(h("p", `The selected operating point is ${s.status} but ${rep.failing.length} other screened case(s) are not: the tab badge shows the overall result.`, "muted"));
        const ul = h("ul", undefined, "pfp-failing");
        for (const f of rep.failing.slice(0, 12)) {
          const li = h("li", undefined, "pf-" + f.severity);
          const open = h("button", "Show this case", "pfp-show-case"); open.type = "button";
          open.addEventListener("click", () => showCase(f));
          li.append(h("strong", `${f.severity.toUpperCase()} ${f.label}`), document.createTextNode(` (${f.timestamp || "hour " + f.hour_index}): ${f.violations[0] || ""} `), open);
          ul.append(li);
        }
        const worst = h("button", "Show the failing case (worst)", "pfp-show-worst"); worst.type = "button";
        worst.addEventListener("click", () => showCase(rep.failing[0]));
        box.append(worst, ul);
      }
    } else {
      all.append(h("span", "Overall screening (all cases + N-1): not run for this scenario yet - press Screen all cases.", "muted"));
      box.append(all);
    }
    const gen = Object.entries(c.gen_mw || {}).map(([k, v]) => `${k} ${fmt(v, 2)}`).join(", ") || "none";
    box.append(h("p", `${c.converged ? "Converged" : "DID NOT CONVERGE"} in ${c.iterations} iterations | load ${fmt(c.load_mw, 2)} MW | grid ${c.slack_mw >= 0 ? "import" : "export"} ${fmt(Math.abs(c.slack_mw), 2)} MW | ` +
      `generation (MW): ${gen} | losses ${fmt(c.losses_mw, 4)} MW`, "muted"));
    for (const w of s.warnings || []) box.append(h("p", w, "muted"));
    const bad = s.violations || [];
    if (bad.length) {
      const ul = h("ul", undefined, "pf-violations");
      for (const v of bad) {
        const li = h("li", undefined, "pf-" + v.severity);
        li.append(h("strong", v.severity.toUpperCase() + ": "), document.createTextNode(v.message));
        ul.append(li);
      }
      box.append(ul);
    } else box.append(h("p", "No violations at this operating point.", "muted"));
  }

  function renderVerification() {
    const box = $("pfp-verifycard");
    if (!box) return;
    box.replaceChildren();
    const s = st.snap, c = s?.case;
    if (!c) { box.hidden = true; return; }
    box.hidden = false;
    box.append(h("h3", "Technical verification"));
    if (!c.converged) box.append(h("p", `The AC power flow did not converge after ${c.iterations} iterations: the voltages and flows below are not valid results.`, "pfp-nonconv"));
    const grid = h("div", undefined, "pfp-tiles");
    const tile = (title, value, sub, cls) => {
      const t = h("div", undefined, "pfp-tile" + (cls ? " " + cls : ""));
      t.append(h("span", title, "pfp-tile-title"), h("strong", value, "pfp-tile-value"), h("span", sub || "", "pfp-tile-sub"));
      grid.append(t);
    };
    const rep = st.screened[st.code], overall = rep && rep.run === runId() ? rep : null;
    tile("Selected point", s.status, c.converged ? `converged, ${c.iterations} iterations` : "not converged", "pf-" + String(s.status).toLowerCase());
    const live = c.buses.filter(b => b.energized);
    const vOf = b => voltClass(b.vm, limitsOf(b.id));
    const lo = live.reduce((m, b) => (m && m.vm <= b.vm ? m : b), null), hi = live.reduce((m, b) => (m && m.vm >= b.vm ? m : b), null);
    if (lo) tile("Lowest voltage", `${fmt(lo.vm, 4)} pu`, `${lo.name || lo.label || lo.id} (${fmt(lo.vm * lo.kv, 4)} kV)`, "pfp-t-" + vOf(lo));
    if (hi) tile("Highest voltage", `${fmt(hi.vm, 4)} pu`, `${hi.name || hi.label || hi.id} (${fmt(hi.vm * hi.kv, 4)} kV)`, "pfp-t-" + vOf(hi));
    const rated = c.branches.filter(b => b.energized && b.rating_mva);
    const worst = rated.reduce((m, b) => (m && m.loading_pct >= b.loading_pct ? m : b), null);
    if (worst) tile("Highest loading", `${fmt(worst.loading_pct, 1)} %`, `${worst.name || worst.id}, rating ${fmt(worst.rating_mva, 2)} MVA`, "pfp-t-" + loadClass(worst.loading_pct, true));
    else tile("Highest loading", "-", "no rated branch is energized");
    const gen = c.buses.reduce((a, b) => a + (b.gen_mw || 0), 0);
    tile("Total losses", `${fmt(c.losses_mw, 4)} MW`, gen > 0 ? `${fmt(100 * c.losses_mw / gen, 2)} % of ${fmt(gen, 2)} MW generation` : "no generation");
    const qGen = c.buses.reduce((a, b) => a + (b.gen_mvar || 0) + (b.shunt_q_mvar || 0), 0), qLoad = c.buses.reduce((a, b) => a + (b.load_mvar || 0), 0);
    const qLoss = c.branches.reduce((a, b) => a + (b.energized ? (b.q_from_mvar || 0) + (b.q_to_mvar || 0) : 0), 0);
    tile("Reactive balance", `${fmt(qGen, 3)} Mvar supplied`, `load ${fmt(qLoad, 3)} + network ${fmt(qLoss, 3)} Mvar; mismatch ${fmt(qGen - qLoad - qLoss, 4)} Mvar`);
    const n1 = overall ? overall.n1_status : null;
    const nOut = overall ? overall.failing.filter(f => /outage|N-1/i.test(f.label || "")).length : 0;
    tile("N-1 security", n1 || "not run", overall ? (nOut ? `${nOut} outage case(s) fail` : "no failing outage case") : "press Screen all cases", n1 ? "pf-" + String(n1).toLowerCase() : "");
    tile("Overall screening", overall ? overall.status : "not run", overall ? "all hours and outages" : "press Screen all cases", overall ? "pf-" + String(overall.status).toLowerCase() : "");
    box.append(grid);
    box.append(h("p", "Selected point = the single operating point shown in the diagram; overall screening = every screened hour plus N-1 outages. " +
      "The tab badge always shows the overall result, so the two can differ.", "muted"));
  }

  function renderLegend() {
    const box = $("pfp-legend");
    if (!box) return;
    box.replaceChildren();
    if (!st.snap?.case) return;
    const t = thermal();
    const item = (cls, text) => { const s = h("span", undefined, "pfp-leg"); s.append(h("i", undefined, "pfp-sw " + cls), document.createTextNode(text)); box.append(s); };
    item("pfp-sw-ok", "Voltage within limits (> 0.02 pu from a limit) / loading below " + fmt(t.high, 0) + " %");
    item("pfp-sw-warn", "Within 0.02 pu of a limit / loading " + fmt(t.high, 0) + "-" + fmt(t.limit, 0) + " %");
    item("pfp-sw-bad", "Outside limits / loading at or above " + fmt(t.limit, 0) + " %");
    item("pfp-sw-none", "Unrated tie (no loading %)");
    item("pfp-sw-dead", "De-energized");
    box.append(h("span", "Arrows point in the direction of active power flow; the dashed animation follows the same sign. Red outline = violation.", "muted"));
  }

  function renderCharts() {
    const box = $("pfp-charts");
    if (!box) return;
    box.replaceChildren();
    const c = st.snap?.case;
    if (!c || typeof GS === "undefined" || !GS.chart) return;
    const live = c.buses.filter(b => b.energized).sort((a, b) => (a.num ?? 0) - (b.num ?? 0));
    if (live.length > 1) {
      const lim = live.map(b => limitsOf(b.id));
      const spec = {kind: "time", xKind: "index", x: live.map((_, i) => i + 1), height: 240, zeroBase: false, title: "Voltage profile", yTitle: "Voltage (pu)", xTitle: "Bus (ordered by number)",
        xInteger: true, xFmt: i => { const b = live[Math.round(i) - 1]; return b ? String(b.num ?? b.name ?? "") : ""; }, vFmt: v => fmt(v, 4), yFmt: v => fmt(v, 3), filename: "voltage-profile",
        series: [{key: "v", label: "Bus voltage (pu)", color: "#1f6feb", values: live.map(b => b.vm), width: 2, markers: true},
          {key: "lo", label: "Lower limit", color: "#d62839", values: lim.map(l => l.lo), dash: "6 4"},
          {key: "hi", label: "Upper limit", color: "#d62839", values: lim.map(l => l.hi), dash: "6 4"}]};
      box.append(GS.chart(spec).el);
    }
    const rated = c.branches.filter(b => b.energized && b.rating_mva).sort((a, b) => b.loading_pct - a.loading_pct);
    if (rated.length) {
      const t = thermal();
      const spec = {kind: "bar", horizontal: true, height: Math.max(180, 34 * rated.length + 70), title: "Branch loading", filename: "branch-loading", vFmt: v => fmt(v, 1) + " %",
        categories: rated.map(b => ({label: b.name || b.id, color: COLOUR[loadClass(b.loading_pct, true)]})), series: [{key: "l", label: "Loading (% of rating)", values: rated.map(b => b.loading_pct)}],
        valueLabels: true, refLines: [{value: t.high, label: `${fmt(t.high, 0)} % high`, color: COLOUR.warn}, {value: t.limit, label: `${fmt(t.limit, 0)} % limit`, color: COLOUR.bad}]};
      box.append(GS.chart(spec).el);
    }
  }

  function renderTables() {
    const box = $("pfp-tables");
    box.replaceChildren();
    const c = st.snap?.case;
    if (!c) return;
    const d = box.appendChild(h("details")); d.open = true;
    d.append(h("summary", "Bus results"), table(["Bus no.", "Bus name", "Component", "Kind", "Base kV", "V (pu)", "V (kV)", "Angle (deg)", "Gen MW", "Gen Mvar", "Load MW", "Load Mvar", "Shunt Mvar (nominal / at V)", "Flags"],
      c.buses.map(b => ({cls: b.energized ? (voltClass(b.vm, limitsOf(b.id)) === "bad" ? "pfp-bad-row" : "") : "pfp-dead-row", cells: [b.num ?? "", b.name || "", b.label || b.id, b.kind, fmt(b.kv, 4), b.energized ? fmt(b.vm, 4) : "-",
        b.energized ? fmt(b.vm * b.kv, 4) : "-", b.energized ? fmt(b.va_deg, 4) : "-",
        fmt(b.gen_mw, 4), fmt(b.gen_mvar, 4), fmt(b.load_mw, 4), fmt(b.load_mvar, 4), b.shunt_mvar ? `${b.shunt_kind} ${fmt(b.shunt_mvar, 4)} / ${fmt(b.shunt_q_mvar, 4)}` : "",
        [b.energized ? "" : "de-energized", b.slack ? "swing" : "", b.q_limited ? "Q-limit" : ""].filter(Boolean).join(", ")]})), "", "Bus voltages, injections and shunts"));
    const e = box.appendChild(h("details")); e.open = true;
    const br = new Map((st.snap.assumptions?.branches || []).map(b => [b.id, b]));
    e.append(h("summary", "Branch and transformer flows (from-end / to-end)"), table(["Branch", "From", "To", "Kind", "P from MW", "Q from Mvar", "P to MW", "Q to Mvar", "S from MVA", "Loss MW", "Loading %", "Rating MVA", "Tap (pu)", "Z %"],
      c.branches.map(b => { const a = br.get(b.id) || {}, tx = b.kind === "transformer";
        return {cls: loadClass(b.loading_pct, b.rating_mva) === "bad" ? "pfp-bad-row" : "", cells: [b.name || "", b.from_name || b.from_id, b.to_name || b.to_id, b.kind, fmt(b.p_from_mw, 4), fmt(b.q_from_mvar, 4), fmt(b.p_to_mw, 4),
          fmt(b.q_to_mvar, 4), fmt(Math.hypot(b.p_from_mw, b.q_from_mvar), 4), fmt(b.loss_mw, 4), b.rating_mva ? fmt(b.loading_pct, 1) : "-", b.rating_mva ? fmt(b.rating_mva, 2) : "-",
          tx && a.tap ? fmt(a.tap, 4) : "-", tx && a.z_pct ? fmt(a.z_pct, 4) : "-"]}; }), "", "Branch and transformer power flows"));
    const f = box.appendChild(h("details")); f.open = true;
    f.append(h("summary", "Generator dispatch"), table(["Unit", "Type", "P MW", "Q Mvar", "Capacity MW", "Rated MVA", "% of MW", "% of MVA", "Qmin", "Qmax", "Flags"],
      c.gens.map(g => ({cells: [g.name || g.id, g.tech, fmt(g.p_mw, 4), fmt(g.q_mvar, 4), fmt(g.cap_mw, 4), g.rated_mva ? fmt(g.rated_mva, 3) : "-", g.pct_mw === null ? "-" : fmt(g.pct_mw, 1),
        g.pct_mva === null ? "-" : fmt(g.pct_mva, 1), g.q_min === null ? "-" : fmt(g.q_min, 4), g.q_max === null ? "-" : fmt(g.q_max, 4),
        [g.slack ? "swing" : "", g.q_limited ? "at Q limit" : ""].filter(Boolean).join(", ")]})), "", "Generator dispatch"));
    f.append(h("p", "MW capacity is at the stated operating power factor; rated MVA = MW / pf. Q limits follow the pf (Qmax = MW x tan(acos(pf))).", "muted"));
    const shunts = c.buses.filter(b => b.shunt_mvar);
    if (shunts.length) {
      const s = box.appendChild(h("details")); s.open = true;
      s.append(h("summary", "Shunt capacitors and reactors"), table(["Bus", "Type", "Nominal Mvar", "Delivered Mvar at V", "V (pu)"],
        shunts.map(b => ({cells: [`${b.num ?? ""} ${b.name || b.label || b.id}`.trim(), b.shunt_kind, fmt(b.shunt_mvar, 4), fmt(b.shunt_q_mvar, 4), fmt(b.vm, 4)]})), "", "Shunt devices"));
    }
  }

  // ------------------------------------------------------------ suggestions
  const FIELD_LABEL = key => {
    const input = $(key);
    return input?.closest("label")?.firstChild?.textContent?.trim() || key;
  };
  function liveCurrent(row) {
    if (row.target.kind === "field") {
      const input = $(row.target.key);
      const v = input ? Number(input.value) : NaN;
      return Number.isFinite(v) ? v : row.current;
    }
    return row.current;
  }

  function renderSuggestions() {
    const box = $("pfp-suggestions");
    box.replaceChildren();
    box.append(h("h3", "Corrective actions"));
    const rows = st.suggestions;
    const failing = (st.snap?.status === "FAIL" || st.snap?.status === "WARN") || (st.report && st.report.status !== "PASS");
    if (!rows.length) {
      box.append(h("p", failing ? "No numeric suggestions are available for these violations." : "No violations - nothing to correct. " +
        "You can still re-run the screening after changing the inputs.", "muted"));
      renderRerunControls(box);
      return;
    }
    box.append(h("p", "Each electrical change was verified by applying it to the network model and re-solving the screened cases. Edit any value, tick the ones to adopt, then apply them to the scenario inputs. " +
      "Microgrid minimum / maximum is your allowed range: it is only ever widened, never lowered. Electrical ratings are stored on this scenario's single-line diagram.", "muted"));
    const ver = st.report?.verification || st.snap?.verification;
    if (ver && ver.text) {
      const p = h("p", ver.text, "pfp-verify"); p.id = "pfp-verification";
      box.append(p);
      for (const rem of (ver.remaining || []).slice(0, 4)) box.append(h("p", "Still open: " + (rem.message || rem), "muted"));
    }
    const wrap = h("div", undefined, "pfp-sugg-scroll");
    const t = h("table", undefined, "pf-cases pfp-sugg-table");
    const head = h("tr");
    for (const x of ["Apply", "Severity", "Parameter", "Applies to", "Unit", "Current", "Suggested (editable)", "Check", "Est. cost (USD)", "Why"]) head.append(h("th", x));
    t.append(head);
    rows.forEach((r, i) => {
      const advice = r.target.kind === "advice";
      const tr = h("tr", undefined, r.severity === "fail" ? "pfp-bad-row" : "");
      const check = h("input"); check.type = "checkbox"; check.checked = !!(r.recommended && r.applicable); check.disabled = !r.applicable;
      check.id = `pfp-ap-${i}`; check.setAttribute("aria-label", "Approve " + r.label);
      if (r.group) check.onchange = () => rows.forEach((o, j) => { if (o.group === r.group && $(`pfp-ap-${j}`) && !$(`pfp-ap-${j}`).disabled) $(`pfp-ap-${j}`).checked = check.checked; });
      const value = h("input"); value.type = "number"; value.step = "any"; value.value = advice ? "" : r4(r.suggested); value.id = `pfp-val-${i}`; value.className = "pf-cell";
      value.disabled = !r.applicable || advice;
      const cell = child => { const td = h("td"); td.append(child); return td; };
      const shown = (st.snap?.case?.names || st.report?.names || {})[r.target.id] || r.target.id;
      const where = r.target.kind === "field" ? "Input: " + FIELD_LABEL(r.target.key) : advice ? "Advisory (no input change)" :
        `${r.target.kind === "node" ? "Component" : "Wire"} ${shown}`;
      const badge = r.verified === true ? "Verified" : r.verified === "partial" ? "Partly verified" : r.verified === false ? "Not verified" : "Estimate";
      tr.append(cell(check), h("td", r.severity.toUpperCase()), h("td", r.label), h("td", where), h("td", r.unit),
        h("td", advice ? "-" : r4(liveCurrent(r))), cell(value), h("td", badge), h("td", r.cost_usd ? Math.round(r.cost_usd).toLocaleString("en-US") : "-"),
        h("td", (r.reason || "") + (r.verification ? " " + r.verification : "") + (r.recommended || advice ? "" : " (alternative)"), "pfp-why"));
      t.append(tr);
    });
    wrap.append(t);
    box.append(wrap);
    const costNote = h("p", undefined, "muted"); costNote.id = "pfp-cost";
    const updateCost = () => {
      const on = rows.filter((r, i) => $(`pfp-ap-${i}`)?.checked && r.cost_usd);
      const total = on.reduce((s, r) => s + r.cost_usd, 0);
      costNote.textContent = `Estimated cost of the ticked corrections: USD ${Math.round(total).toLocaleString("en-US")}` +
        (on.length ? ` (${on.map(r => r.cost_basis).filter(Boolean).join("; ")}).` : ".") + " Indicative planning-level unit costs, not a quotation.";
    };
    rows.forEach((r, i) => { const c = $(`pfp-ap-${i}`); if (c) c.addEventListener("change", updateCost); });
    box.append(costNote);
    updateCost();
    renderRerunControls(box);
  }

  function renderRerunControls(box) {
    const row = h("div", undefined, "pfp-row");
    const apply = h("button", "Apply to scenario setup", "secondary"); apply.id = "pfp-apply"; apply.type = "button";
    const rescreen = h("button", "Apply and re-screen (same dispatch)", "secondary"); rescreen.id = "pfp-rescreen"; rescreen.type = "button";
    const rerun = h("button", "Apply and re-run scenario(s)"); rerun.id = "pfp-rerun"; rerun.type = "button";
    const scope = h("select"); scope.id = "pfp-scope";
    scope.append(new Option("this scenario", "one"), new Option("all solved scenarios", "all"));
    const save = h("button", "Save and go to Solve page", "secondary"); save.id = "pfp-save"; save.type = "button";
    const saveResolve = h("button", "Save and re-solve all scenarios"); saveResolve.id = "pfp-save-resolve"; saveResolve.type = "button";
    const l = h("label", "Re-run: ", "pfp-field"); l.append(scope);
    row.append(apply, rescreen, l, rerun, saveResolve, save);
    box.append(row);
    const status = h("p", st.status, "muted"); status.id = "pfp-rerun-status"; status.setAttribute("role", "status");
    box.append(status);
    apply.onclick = () => guarded(async () => {
      await prepare();
      const n = applySelected(); await inputWorkspace.saveNow();
      setStatus(`${n} value(s) written to the scenario inputs and saved to the local draft.`); st.snap = null; await runCase(); setStatus(st.status);
    });
    rescreen.onclick = () => guarded(async () => { await prepare(); const e = applySelected(true); await inputWorkspace.saveNow(); await rescreenAfter(e); });
    rerun.onclick = () => guarded(() => rerunScenarios(scope.value));
    saveResolve.onclick = () => guarded(() => rerunScenarios("all", true));
    save.onclick = () => guarded(async () => { await prepare(); applySelected(); await inputWorkspace.saveNow(); switchView("solve"); });
  }
  st.status = "";
  const setStatus = text => { st.status = text || ""; const e = $("pfp-rerun-status"); if (e) e.textContent = st.status; };
  async function prepare() {
    for (const code of new Set([st.code, ...st.suggestions.map(r => r.scenario).filter(Boolean)])) await ensureTopology(code);
  }

  function applySelected(track) {
    const applied = [];
    const patches = {};
    const fieldWrites = {};
    st.suggestions.forEach((r, i) => {
      const box = $(`pfp-ap-${i}`);
      if (!box || !box.checked || !r.applicable) return;
      const value = Number($(`pfp-val-${i}`).value);
      if (!Number.isFinite(value)) throw new Error(`Suggested value for "${r.label}" is not a number.`);
      const t = r.target;
      const from = liveCurrent(r);
      if (t.kind === "field") {
        const input = $(t.key);
        if (!input) throw new Error(`Input field ${t.key} does not exist.`);
        fieldWrites[t.key] = value;
        const was = Number($(t.key).value);
        if (t.key === "microgrid_max_mw" && Number.isFinite(was) && value < was) throw new Error(`Nothing was applied: the Maximum microgrid size is your allowed range and is never lowered (${was} -> ${value} MW).`);
      } else {
        const rg = typeof pfProps !== "undefined" && pfProps.range ? pfProps.range(t.key) : null;
        if (rg && (value < rg[0] || value > rg[1])) throw new Error(`Suggested value for "${r.label}" (${value}) must be between ${rg[0]} and ${rg[1]}.`);
        const set = ((patches[r.scenario] ||= {nodes: {}, lines: {}})[t.kind === "node" ? "nodes" : "lines"][t.id] ||= {});
        set[t.key] = value;
        for (const [k, v] of Object.entries(t.also || {})) if (v !== null && v !== undefined && !(k in set)) set[k] = v;
      }
      applied.push({label: r.label, where: t.id || t.key, unit: r.unit, from, to: value, violation: r.violation, cost_usd: r.cost_usd || 0,
        scenario: t.kind === "field" ? st.code : r.scenario || st.code});
    });
    if (!applied.length) throw new Error("Tick at least one suggestion to apply.");
    checkMicrogridPair(fieldWrites);
    for (const [code, patch] of Object.entries(patches))
      if (!topologyEditor.setElectrical(code, patch)) throw new Error(`Scenario ${code} has no drawing in the topology editor; open Inputs > Microgrid > Topology first.`);
    for (const [key, value] of Object.entries(fieldWrites)) $(key).value = String(value);
    for (const key of Object.keys(fieldWrites)) {
      $(key).dispatchEvent(new Event("input", {bubbles: true}));
      $(key).dispatchEvent(new Event("change", {bubbles: true}));
    }
    if (applied.length && typeof edited === "function") edited();
    if ("microgrid_min_mw" in fieldWrites || "microgrid_max_mw" in fieldWrites) {
      const changed = Object.keys(fieldWrites).map(k => `${FIELD_LABEL(k)} -> ${fieldWrites[k]} MW`).join(" and ");
      message(`Changed input field(s): ${changed}. These widen your allowed microgrid range because the network needs it; the limits are never lowered automatically. ` +
        `Now: minimum ${$("microgrid_min_mw").value} MW, maximum ${$("microgrid_max_mw").value} MW. Review them on the Microgrid input page, then use "Apply and re-run scenario(s)" to re-optimise with the new range.`, "Microgrid");
    }
    const entry = {n: st.history.length + 1, scenario: st.code, at: new Date().toLocaleTimeString(), run: runId(),
      before: {status: st.report?.status || st.snap?.status, failures: (st.snap?.violations || []).slice(0, 4).map(v => v.message)}, applied, after: null};
    st.history.push(entry);
    persistHistory();
    renderHistory();
    return track ? entry : applied.length;
  }

  function persistHistory() {
    try { localStorage.setItem(HISTORY_KEY, JSON.stringify(st.history.slice(-30))); } catch { /* storage full: history stays in memory */ }
  }

  async function rescreenAfter(entry) {
    setStatus("Re-screening with the applied values...");
    st.snap = null;
    await screenAll();
    finishEntry(entry);
    setStatus("Re-screen finished. Note: capacity inputs only change the dispatch after a re-run.");
  }

  function finishEntry(entry) {
    if (!entry) return;
    const s = st.screened[st.code];
    entry.after = {status: s?.status || st.snap?.status, violations: s?.violations ?? (st.snap?.violations || []).length, run: runId()};
    persistHistory();
    renderHistory();
  }

  async function rerunScenarios(scope, optional) {
    if (typeof busy !== "undefined" && busy) throw new Error("A solve is already running. Wait for it to finish.");
    await prepare();
    const anyTicked = st.suggestions.some((r, i) => $(`pfp-ap-${i}`)?.checked && r.applicable);
    const entry = optional && !anyTicked ? null : applySelected(true);
    await inputWorkspace.saveNow();
    const codes = scope === "all" ? results().map(r => r.code) : [st.code];
    const boxes = [...document.querySelectorAll("#scenarios input")];
    const previous = boxes.map(b => b.checked);
    const startedFrom = currentRun;
    const costs = {};
    for (const a of entry?.applied || []) if (a.cost_usd > 0) ((costs[a.scenario || st.code] ||= {items: []}).items).push({label: a.label, cost_usd: a.cost_usd});
    let started;
    boxes.forEach(b => { b.checked = codes.includes(b.value); });
    mergeFrom = codes.length < results().length ? solveRun : null;
    const full = codes.length >= results().length;
    if (full) window.workflowUi?.expectReSolve("powerflow");
    else for (const [code, c] of Object.entries(costs)) for (const i of c.items) window.workflowUi?.noteApplied(code, i.label, i.cost_usd);
    try {
      started = start(true, full ? {base: solveRun, iteration: 0, scenarios: codes, changes: {}, mode: "powerflow", applied_costs: costs} : undefined);
    } finally { mergeFrom = null; boxes.forEach((b, i) => { b.checked = previous[i]; }); }
    await started;
    if (currentRun === startedFrom) {
      window.workflowUi?.cancelReSolve();
      const why = $("error")?.textContent?.trim();
      const e = new Error(`The corrections were applied and saved, but the solve did not start${why ? `: ${why}` : ". Check the highlighted input error on the Inputs pages."}` +
        (/forecast|combined|csv|demand/i.test(why || "") ? " Re-select the demand file (uploaded files are not kept after a reload), then press Solve, or use 'Apply and re-screen' which needs no re-upload." : ""));
      if (/forecast|combined|csv|demand/i.test(why || "")) e.link = "Demand";
      setStatus("");
      throw e;
    }
    // Hand over to the Solve page: it tracks the re-solve, re-runs the technical check and re-ranks; this page refreshes when reopened.
    st.pendingEntry = entry;
    setStatus(`Re-solving after power-flow edits (run ${currentRun})... the Solve page continues automatically.`);
    switchView("solve");
  }

  function renderHistory() {
    const box = $("pfp-history");
    if (!box) return;
    box.replaceChildren(h("h3", "Iteration history"));
    if (!st.history.length) { box.append(h("p", "Iterations appear here: failures -> applied values -> result.", "muted")); return; }
    const t = h("table", undefined, "pf-cases");
    const head = h("tr");
    for (const x of ["Iteration", "Scenario", "Failures before", "Applied values", "Result"]) head.append(h("th", x));
    t.append(head);
    for (const e of st.history) {
      const tr = h("tr");
      tr.append(h("td", `${e.n} (${e.at})`), h("td", e.scenario),
        h("td", `${e.before.status || "-"}: ${(e.before.failures || []).join(" | ") || "none recorded"}`),
        h("td", e.applied.map(a => `${a.label} [${a.where}]: ${fmt(a.from, 3)} -> ${fmt(a.to, 3)} ${a.unit}`).join("; ")),
        h("td", e.after ? `${e.after.status} (${e.after.violations} violation(s))` : "pending"));
      t.append(tr);
    }
    box.append(t);
    const clear = h("button", "Clear history", "secondary"); clear.type = "button";
    clear.onclick = () => { st.history = []; persistHistory(); renderHistory(); };
    box.append(clear);
  }

  function renderAll() {
    renderBadges();
    renderVerification();
    renderSummary();
    drawSld();
    renderLegend();
    renderCharts();
    renderTables();
    renderSuggestions();
    if (st.anim) setAnimation(true);
  }

  async function show() {
    build();
    syncScenario();
    refreshStatus();
    if (st.anim) setAnimation(true);
    if (!hasRun()) {
      const empty = h("p", "No saved solve in this session. Run SOLVE (or open a saved run) to power-flow its scenarios. ", "notice");
      const go = h("button", "Go to Solve", "secondary"); go.type = "button"; go.id = "pfp-goto-solve";
      go.addEventListener("click", () => switchView("solve"));
      empty.append(go);
      $("pfp-summary").replaceChildren(empty);
      for (const id of ["pfp-verifycard", "pfp-sld", "pfp-legend", "pfp-charts", "pfp-tables", "pfp-suggestions"]) { const e = $(id); if (e) e.replaceChildren(); }
      if ($("pfp-verifycard")) $("pfp-verifycard").hidden = true;
      return;
    }
    if (!st.snap || st.runFor !== runId()) {
      if (st.runFor && st.runFor !== runId()) { st.report = null; st.screened = {}; st.suggestions = []; }
      st.snap = null; await guarded(loadHours);
      if (st.pendingEntry && st.runFor === runId()) { const entry = st.pendingEntry; st.pendingEntry = null; await guarded(screenAll); finishEntry(entry); setStatus(`Cases refreshed from run ${runId()}.`); }
    }
  }

  window.powerFlowPage = {show, state: st};
  window.addEventListener("load", () => { build(); setInterval(() => { try { refreshStatus(); } catch (e) { console.error(e); } }, 1500); });
})();
