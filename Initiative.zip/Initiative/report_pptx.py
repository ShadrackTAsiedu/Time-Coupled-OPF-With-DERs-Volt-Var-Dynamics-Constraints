"""Executive PowerPoint presentation generated from a saved run.

The deck is built only from native PowerPoint objects (placeholders, text boxes, tables, charts, shapes) on a custom
16:9 master/theme, so users can edit every element and add new slides in the same style.  All numbers come from the same
sources as the project report (summary_data, report, report_doc, report_exec, report_charts); analyses that were not run
are summarised on a single "not run" slide instead of showing empty charts.
"""
import base64
import io
import re
from xml.sax.saxutils import escape

from lxml import etree
from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION, XL_MARKER_STYLE, XL_TICK_LABEL_POSITION
from pptx.enum.dml import MSO_LINE
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.opc.constants import RELATIONSHIP_TYPE as RT
from pptx.oxml import parse_xml
from pptx.oxml.ns import nsdecls, qn
from pptx.util import Emu, Inches, Pt

import report
import currency
import report_charts
import report_doc
import report_exec

MIME = "application/vnd.openxmlformats-officedocument.presentationml.presentation"

NAVY, TEAL, BLUE, AMBER, GREEN, RED, PURPLE = "0B2545", "0E8A82", "2F6FB3", "E0A030", "4F8F5B", "C0504D", "7A5EA8"
GREY, LIGHT, INK, GRID, WHITE, DARK_AMBER = "6B7785", "F2F5F8", "1F2933", "D9DEE4", "FFFFFF", "B7791F"
STATUS_COLOR = {"PASS": GREEN, "WARN": DARK_AMBER, "FAIL": RED}
SOURCE_COLORS = {"Grid import": BLUE, "New solar PV": AMBER, "Wind": "3AA6A6", "Generators": RED, "Planned renewables": "8A8F98", "BESS discharge": GREEN}

SLIDE_W, SLIDE_H = 13.333, 7.5
MARGIN, CONTENT_W = 0.5, 12.333
TOP, BOTTOM = 1.4, 6.05
BODY_MIN, TITLE_MIN = 12, 20
FONT = "Calibri"
EQ_FONT = "Cambria Math"


def rgb(hex_color):
    return RGBColor.from_string(hex_color)


# --------------------------------------------------------------------------- text measurement

_FONTS = {}


def _font(size, bold):
    key = (round(size * 4), bold)
    if key not in _FONTS:
        try:
            from PIL import ImageFont
            _FONTS[key] = ImageFont.truetype(rf"C:\Windows\Fonts\{'calibrib' if bold else 'calibri'}.ttf", max(int(size * 4), 4))
        except Exception:
            _FONTS[key] = None
    return _FONTS[key]


def text_width(text, size, bold=False):
    """Width of a text in points (Calibri metrics when available, otherwise a conservative estimate)."""
    f = _font(size, bold)
    return f.getlength(text) / 4 if f else len(text) * size * (0.54 if bold else 0.5)


def count_lines(text, width_pt, size, bold=False):
    total = 0
    for paragraph in str(text).split("\n"):
        line, lines = "", 1
        for word in paragraph.split(" "):
            trial = f"{line} {word}".strip()
            if line and text_width(trial, size, bold) > width_pt:
                lines, line = lines + 1, word
            else:
                line = trial
        total += lines
    return total


def _runs(item):
    """Normalise a paragraph spec (str | (str, opts) | [run, ...]) to a list of (text, opts)."""
    if isinstance(item, str):
        return [(item, {})]
    if isinstance(item, tuple):
        return [item]
    return [(r, {}) if isinstance(r, str) else r for r in item]


def estimate_height(paras, width_in, size, bold=False, bullet=False, space=4):
    """Estimated text height in inches for the given paragraphs at a base font size."""
    width_pt = (width_in - 0.2 - (0.25 if bullet else 0)) * 72
    total = 0.0
    for item in paras:
        runs = _runs(item)
        text = "".join(t for t, _ in runs)
        sizes = [o["size"] for _, o in runs if o.get("size")]
        s = max(sizes) if sizes else size
        b = bool(runs[0][1].get("bold", bold)) if runs else bold
        total += count_lines(text, width_pt, s, b) * s * 1.2 + space
    return total / 72 + 0.1


def fit_size(paras, width_in, height_in, start, minimum, bold=False, bullet=False, space=4):
    size = start
    while size > minimum and estimate_height(paras, width_in, size, bold, bullet, space) > height_in:
        size -= 1
    return size, estimate_height(paras, width_in, size, bold, bullet, space) <= height_in + 0.02


# --------------------------------------------------------------------------- template (master, layouts, theme)

def _scale_layouts(prs, factor):
    shapes = list(prs.slide_master.shapes) + [s for layout in prs.slide_layouts for s in layout.shapes]
    for shape in shapes:
        xfrm = shape._element.find(".//" + qn("a:xfrm"))
        if xfrm is None:
            continue
        off, ext = xfrm.find(qn("a:off")), xfrm.find(qn("a:ext"))
        off.set("x", str(int(int(off.get("x")) * factor)))
        ext.set("cx", str(int(int(ext.get("cx")) * factor)))


def _set_theme(master):
    part = master.part.part_related_by(RT.THEME)
    root = etree.fromstring(part.blob)
    ns = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
    root.set("name", "GenStudio Executive")
    colors = dict(dk1=INK, lt1=WHITE, dk2=NAVY, lt2=LIGHT, accent1=NAVY, accent2=TEAL, accent3=BLUE, accent4=AMBER, accent5=GREEN, accent6=RED,
                  hlink=BLUE, folHlink=PURPLE)
    scheme = root.find(".//a:clrScheme", ns)
    scheme.set("name", "GenStudio")
    for name, value in colors.items():
        node = scheme.find(f"a:{name}", ns)
        for child in list(node):
            node.remove(child)
        etree.SubElement(node, qn("a:srgbClr")).set("val", value)
    for kind in ("majorFont", "minorFont"):
        root.find(f".//a:{kind}/a:latin", ns).set("typeface", FONT)
    part._blob = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)


def _emu(inches):
    return int(inches * 914400)


def _raw_shape(sid, name, x, y, w, h, fill=None, text_xml="", anchor="ctr", box=False):
    fill_xml = f'<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill>' if fill else "<a:noFill/>"
    body = text_xml or '<a:p><a:endParaRPr lang="en-US"/></a:p>'
    return parse_xml(
        f'<p:sp {nsdecls("p", "a")}><p:nvSpPr><p:cNvPr id="{sid}" name="{name}"/><p:cNvSpPr{" txBox=\"1\"" if box else ""}/><p:nvPr userDrawn="1"/></p:nvSpPr>'
        f'<p:spPr><a:xfrm><a:off x="{_emu(x)}" y="{_emu(y)}"/><a:ext cx="{_emu(w)}" cy="{_emu(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>'
        f'{fill_xml}<a:ln><a:noFill/></a:ln></p:spPr><p:txBody><a:bodyPr wrap="square" lIns="0" rIns="0" anchor="{anchor}"/><a:lstStyle/>{body}</p:txBody></p:sp>')


def _style_lst(shape, size, color, bold=True, align="l"):
    """Set the default text style of a layout placeholder so slides created from it inherit it."""
    tx = shape._element.find(qn("p:txBody"))
    old = tx.find(qn("a:lstStyle"))
    new = parse_xml(f'<a:lstStyle {nsdecls("a")}><a:lvl1pPr marL="0" indent="0" algn="{align}"><a:buNone/>'
                    f'<a:defRPr sz="{size * 100}" b="{int(bold)}"><a:solidFill><a:srgbClr val="{color}"/></a:solidFill></a:defRPr></a:lvl1pPr></a:lstStyle>')
    tx.replace(old, new)


def _place(shape, x, y, w, h):
    shape.left, shape.top, shape.width, shape.height = Inches(x), Inches(y), Inches(w), Inches(h)


def prepare_template(prs, footer):
    """16:9 master with theme colours/fonts, accent bar, footer and slide number; layouts scaled from the 4:3 default."""
    prs.slide_width, prs.slide_height = Inches(SLIDE_W), Inches(SLIDE_H)
    _scale_layouts(prs, SLIDE_W / 10)
    master = prs.slide_master
    _set_theme(master)
    for shape in master.placeholders:
        kind = shape.placeholder_format.type
        if "TITLE" in str(kind):
            _place(shape, MARGIN, 0.3, CONTENT_W, 0.95)
            shape.text_frame.vertical_anchor = MSO_ANCHOR.MIDDLE
        elif "BODY" in str(kind) or "OBJECT" in str(kind):
            _place(shape, MARGIN, TOP, CONTENT_W, 4.9)
    styles = master._element.find(qn("p:txStyles"))
    lvl = styles.find(qn("p:titleStyle")).find(qn("a:lvl1pPr"))
    lvl.set("algn", "l")
    rpr = lvl.find(qn("a:defRPr"))
    rpr.set("sz", "2600")
    rpr.set("b", "1")
    for child in list(rpr):
        if child.tag == qn("a:solidFill"):
            rpr.remove(child)
    rpr.insert(0, parse_xml(f'<a:solidFill {nsdecls("a")}><a:srgbClr val="{NAVY}"/></a:solidFill>'))
    for level, size in zip(range(1, 6), (2000, 1800, 1600, 1400, 1400)):
        node = styles.find(qn("p:bodyStyle")).find(qn(f"a:lvl{level}pPr"))
        if node is not None:
            node.find(qn("a:defRPr")).set("sz", str(size))
    tree = master.shapes._spTree
    furniture = [
        _raw_shape(101, "Accent bar", 0, 0, SLIDE_W, 0.12, NAVY),
        _raw_shape(102, "Accent stripe", 0, 0.12, 2.2, 0.05, TEAL),
        _raw_shape(103, "Footer text", MARGIN, 7.05, 9.5, 0.3, text_xml=(
            f'<a:p><a:pPr algn="l"/><a:r><a:rPr lang="en-US" sz="1100"><a:solidFill><a:srgbClr val="{GREY}"/></a:solidFill></a:rPr>'
            f'<a:t>{escape(footer)}</a:t></a:r></a:p>'), box=True),
        _raw_shape(104, "Slide number", SLIDE_W - MARGIN - 1.0, 7.05, 1.0, 0.3, text_xml=(
            f'<a:p><a:pPr algn="r"/><a:fld id="{{B6F15528-21DE-4FAA-801E-634DDDAF4B2B}}" type="slidenum"><a:rPr lang="en-US" sz="1100">'
            f'<a:solidFill><a:srgbClr val="{GREY}"/></a:solidFill></a:rPr><a:t>&#8249;#&#8250;</a:t></a:fld></a:p>'), box=True),
    ]
    for i, element in enumerate(furniture):
        tree.insert(2 + i, element)
    title_layout, title_only = prs.slide_layouts[0], prs.slide_layouts[5]
    for shape in title_only.placeholders:
        xfrm = shape._element.find(".//" + qn("a:xfrm"))
        if xfrm is not None:
            xfrm.getparent().remove(xfrm)
    title_layout._element.set("showMasterSp", "0")
    title_layout.background.fill.solid()
    title_layout.background.fill.fore_color.rgb = rgb(NAVY)
    layout_tree = title_layout.shapes._spTree
    layout_tree.insert(2, _raw_shape(111, "Accent bar", 0.8, 4.0, 1.8, 0.07, TEAL))
    for shape in title_layout.placeholders:
        if shape.placeholder_format.idx == 0:
            _place(shape, 0.8, 1.6, 11.7, 2.2)
            shape.text_frame.vertical_anchor = MSO_ANCHOR.BOTTOM
            _style_lst(shape, 40, WHITE)
        elif shape.placeholder_format.idx == 1:
            _place(shape, 0.8, 4.3, 11.7, 2.4)
            _style_lst(shape, 20, "DCE6F0", bold=False)


# --------------------------------------------------------------------------- deck builder

class Deck:
    def __init__(self, footer):
        self.prs = Presentation()
        prepare_template(self.prs, footer)
        self.layout_title, self.layout_only = self.prs.slide_layouts[0], self.prs.slide_layouts[5]
        self.problems = []

    # ---- slides
    def slide(self, title, notes):
        s = self.prs.slides.add_slide(self.layout_only)
        frame = s.shapes.title.text_frame
        frame.text = title
        size, ok = fit_size([title], CONTENT_W, 0.95, 26, TITLE_MIN, bold=True, space=0)
        for run in frame.paragraphs[0].runs:
            run.font.size = Pt(size)
        if not ok:
            self.problems.append(f"title too long: {title[:60]}")
        self.notes(s, notes)
        return s

    @staticmethod
    def notes(s, text):
        s.notes_slide.notes_text_frame.text = text

    def drop_last(self):
        ids = self.prs.slides._sldIdLst
        self.prs.part.drop_rel(ids[-1].rId)
        ids.remove(ids[-1])

    # ---- text
    def _fill(self, frame, paras, size, color, bold, align, font, bullet, space):
        frame.word_wrap = True
        frame.auto_size = MSO_AUTO_SIZE.NONE
        frame.margin_left = frame.margin_right = Inches(0.1)
        frame.margin_top = frame.margin_bottom = Inches(0.05)
        for i, item in enumerate(paras):
            p = frame.paragraphs[0] if i == 0 else frame.add_paragraph()
            runs = _runs(item)
            for text, opts in runs:
                r = p.add_run()
                r.text = text
                f = r.font
                f.size = Pt(opts.get("size", size))
                f.bold = opts.get("bold", bold)
                f.italic = opts.get("italic", False)
                f.name = opts.get("font", font)
                f.color.rgb = rgb(opts.get("color", color))
            p.alignment = align
            p.space_after = Pt(space)
            if bullet and not runs[0][1].get("nobullet"):
                ppr = p._p.get_or_add_pPr()
                ppr.set("marL", "228600")
                ppr.set("indent", "-228600")
                ppr.append(parse_xml(f'<a:buFont {nsdecls("a")} typeface="Arial"/>'))
                ppr.append(parse_xml(f'<a:buChar {nsdecls("a")} char="&#8226;"/>'))

    def text(self, s, x, y, w, h, paras, size=16, color=INK, bold=False, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, font=FONT,
             bullet=False, minimum=BODY_MIN, space=4, name=None):
        paras = [paras] if isinstance(paras, (str, tuple)) else list(paras)
        shape = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        return self._finish(shape, paras, x, y, w, h, size, color, bold, align, anchor, font, bullet, minimum, space, name)

    def shape(self, s, kind, x, y, w, h, fill, paras=None, size=14, color=WHITE, bold=False, align=PP_ALIGN.CENTER,
              anchor=MSO_ANCHOR.MIDDLE, line=None, minimum=BODY_MIN, space=2, rounded=0.08, name=None, bullet=False):
        shape = s.shapes.add_shape(kind, Inches(x), Inches(y), Inches(w), Inches(h))
        shape.shadow.inherit = False
        if fill:
            shape.fill.solid()
            shape.fill.fore_color.rgb = rgb(fill)
        else:
            shape.fill.background()
        if line:
            shape.line.color.rgb = rgb(line)
            shape.line.width = Pt(1)
        else:
            shape.line.fill.background()
        if kind == MSO_SHAPE.ROUNDED_RECTANGLE:
            shape.adjustments[0] = rounded
        if paras is None:
            return shape
        paras = [paras] if isinstance(paras, (str, tuple)) else list(paras)
        return self._finish(shape, paras, x, y, w, h, size, color, bold, align, anchor, FONT, bullet, minimum, space, name)

    def _finish(self, shape, paras, x, y, w, h, size, color, bold, align, anchor, font, bullet, minimum, space, name):
        chosen, ok = fit_size(paras, w, h, size, minimum, bold, bullet, space)
        if not ok:
            self.problems.append(f"text overflow ({chosen}pt): {_runs(paras[0])[0][0][:50]}")
        self._fill(shape.text_frame, paras, chosen, color, bold, align, font, bullet, space)
        shape.text_frame.vertical_anchor = anchor
        if name:
            shape.name = name
        return shape

    def so_what(self, s, meaning, action=None):
        """Implication band (and recommended action) at the bottom of a results slide."""
        paras = [[("So what: ", {"bold": True, "color": TEAL}), meaning]]
        if action:
            paras.append([("Recommended action: ", {"bold": True, "color": DARK_AMBER}), action])
        self.shape(s, MSO_SHAPE.RECTANGLE, MARGIN, 6.15, 0.08, 0.85, TEAL)
        self.shape(s, MSO_SHAPE.RECTANGLE, MARGIN + 0.08, 6.15, CONTENT_W - 0.08, 0.85, LIGHT, paras, size=14, color=INK, align=PP_ALIGN.LEFT,
                   space=2, name="So what")

    def tile(self, s, x, y, w, h, value, label, note=None, color=NAVY):
        paras = [(value, {"size": 26, "bold": True, "color": color}), (label, {"size": 13, "bold": True, "color": INK})]
        if note:
            paras.append((note, {"size": 12, "color": GREY}))
        return self.shape(s, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h, LIGHT, paras, size=13, color=INK, align=PP_ALIGN.LEFT, line=GRID, space=1,
                          name=f"KPI {label}")

    def pill(self, s, x, y, w, label, status):
        color = STATUS_COLOR.get(str(status).upper(), GREY if status in (None, "Not run") else NAVY)
        return self.shape(s, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, 0.42, color, f"{label}: {status or 'Not run'}", size=13, bold=True, rounded=0.5,
                          name=f"Status {label}")

    # ---- tables
    def table(self, s, x, y, w, fracs, header, rows, size=12, highlight=None, right=(), min_row=0.34, max_bottom=BOTTOM, name="Table"):
        ncols = len(header)
        widths = [w * f / sum(fracs) for f in fracs]

        def row_height(cells, bold):
            lines = max(count_lines(str(c), (cw - 0.2) * 72, size, bold) for c, cw in zip(cells, widths))
            return max(min_row, lines * size * 1.2 / 72 + 0.12)

        heights = [row_height(header, True)] + [row_height(r, i == highlight) for i, r in enumerate(rows)]
        total = sum(heights)
        if y + total > max_bottom + 0.02:
            self.problems.append(f"table taller than space ({y + total:.2f} > {max_bottom}): {name}")
        frame = s.shapes.add_table(len(rows) + 1, ncols, Inches(x), Inches(y), Inches(w), Inches(total))
        frame.name = name
        tbl = frame.table
        tbl.first_row, tbl.horz_banding = True, False
        for i, cw in enumerate(widths):
            tbl.columns[i].width = Inches(cw)
        for r, height in enumerate(heights):
            tbl.rows[r].height = Inches(height)
            cells = header if r == 0 else rows[r - 1]
            for c in range(ncols):
                cell = tbl.cell(r, c)
                cell.margin_left = cell.margin_right = Inches(0.1)
                cell.margin_top = cell.margin_bottom = Inches(0.04)
                cell.vertical_anchor = MSO_ANCHOR.MIDDLE
                cell.fill.solid()
                is_hl = r > 0 and highlight == r - 1
                cell.fill.fore_color.rgb = rgb(NAVY if r == 0 else "DDF1EF" if is_hl else WHITE if r % 2 else LIGHT)
                p = cell.text_frame.paragraphs[0]
                p.alignment = PP_ALIGN.RIGHT if c in right else PP_ALIGN.LEFT
                run = p.add_run()
                run.text = "" if cells[c] is None else str(cells[c])
                run.font.size = Pt(size)
                run.font.name = FONT
                run.font.bold = r == 0 or is_hl
                run.font.color.rgb = rgb(WHITE if r == 0 else INK)
        return total

    # ---- charts
    def chart(self, s, kind, x, y, w, h, cats, series, title=None, colors=None, fmt="#,##0.0", legend=True, labels=False, stacked=False,
              point_colors=None, axis_title=None, tornado=False, label_fmt=None, dashed=()):
        data = CategoryChartData()
        data.categories = list(cats)
        for name, values, *_ in series:
            data.add_series(name, [None if v is None else round(float(v), 4) for v in values])
        ctype = {"col": XL_CHART_TYPE.COLUMN_STACKED if stacked else XL_CHART_TYPE.COLUMN_CLUSTERED,
                 "bar": XL_CHART_TYPE.BAR_STACKED if stacked else XL_CHART_TYPE.BAR_CLUSTERED,
                 "line": XL_CHART_TYPE.LINE, "doughnut": XL_CHART_TYPE.DOUGHNUT}[kind]
        frame = s.shapes.add_chart(ctype, Inches(x), Inches(y), Inches(w), Inches(h), data)
        frame.name = f"Chart {title or kind}"
        frame._element.nvGraphicFramePr.cNvPr.set("descr", title or "Chart")
        chart = frame.chart
        chart.font.size = Pt(12)
        chart.font.name = FONT
        chart.font.color.rgb = rgb(INK)
        if title:
            chart.has_title = True
            chart.chart_title.include_in_layout = False
            chart.chart_title.text_frame.text = title
            run = chart.chart_title.text_frame.paragraphs[0].runs[0]
            run.font.size, run.font.bold = Pt(14), True
        else:
            chart.has_title = False
        chart.has_legend = legend
        if legend:
            chart.legend.position = XL_LEGEND_POSITION.BOTTOM
            chart.legend.include_in_layout = False
            chart.legend.font.size = Pt(12)
        plot = chart.plots[0]
        palette = colors or [BLUE, AMBER, GREEN, RED, PURPLE, TEAL]
        if kind == "doughnut":
            plot.vary_by_categories = True
            for i, point_color in enumerate(point_colors or palette):
                if i < len(cats):
                    fill = plot.series[0].points[i].format.fill
                    fill.solid()
                    fill.fore_color.rgb = rgb(point_color)
            plot.has_data_labels = True
            plot.data_labels.show_percentage, plot.data_labels.show_value = True, False
            plot.data_labels.number_format, plot.data_labels.number_format_is_linked = "0%", False
            plot.data_labels.font.size = Pt(12)
            plot.data_labels.font.color.rgb = rgb(WHITE)
            plot.data_labels.font.bold = True
            return chart
        for i, ser in enumerate(plot.series):
            color = palette[i % len(palette)]
            if kind == "line":
                ser.smooth = False
                ser.format.line.color.rgb = rgb(color)
                ser.format.line.width = Pt(2.5)
                ser.marker.style = XL_MARKER_STYLE.NONE
                if i in dashed:
                    ser.format.line.dash_style = MSO_LINE.DASH
            elif color is None:
                ser.format.fill.background()
            else:
                ser.format.fill.solid()
                ser.format.fill.fore_color.rgb = rgb(color)
            ser.invert_if_negative = False if kind != "line" else None
        if kind != "line":
            plot.gap_width = 40 if tornado else 60
            if tornado or stacked:
                plot.overlap = 100
            plot.vary_by_categories = False
        if point_colors and kind in ("col", "bar"):
            for i, point_color in enumerate(point_colors):
                fill = plot.series[0].points[i].format.fill
                fill.solid()
                fill.fore_color.rgb = rgb(point_color)
        if labels:
            plot.has_data_labels = True
            dl = plot.data_labels
            dl.number_format, dl.number_format_is_linked = label_fmt or fmt, False
            dl.font.size = Pt(12)
            if not stacked and not tornado and kind != "line":
                dl.position = XL_LABEL_POSITION.OUTSIDE_END
        value_axis, cat_axis = chart.value_axis, chart.category_axis
        value_axis.has_major_gridlines = True
        value_axis.major_gridlines.format.line.color.rgb = rgb(GRID)
        value_axis.format.line.fill.background()
        value_axis.tick_labels.number_format, value_axis.tick_labels.number_format_is_linked = fmt, False
        value_axis.tick_labels.font.size = cat_axis.tick_labels.font.size = Pt(12)
        cat_axis.format.line.color.rgb = rgb(GREY)
        if tornado:
            cat_axis.tick_label_position = XL_TICK_LABEL_POSITION.LOW
        if axis_title:
            value_axis.has_title = True
            value_axis.axis_title.text_frame.text = axis_title
            value_axis.axis_title.text_frame.paragraphs[0].runs[0].font.size = Pt(12)
            value_axis.axis_title.text_frame.paragraphs[0].runs[0].font.bold = False
        return chart

    def hide_legend_entry(self, chart, index):
        legend = chart._chartSpace.find(".//" + qn("c:legend"))
        pos = legend.find(qn("c:legendPos"))
        entry = parse_xml(f'<c:legendEntry {nsdecls("c")}><c:idx val="{index}"/><c:delete val="1"/></c:legendEntry>')
        pos.addnext(entry)


# --------------------------------------------------------------------------- data context

def _usd_m(value, dp=1):
    return report.mil(value, dp)


def _fin(v):
    return report.finite(v)


class Ctx:
    """Everything the slides need, derived from the saved run exactly as the report derives it."""

    def __init__(self, run_id, meta_raw):
        self.run_id = run_id
        self.run = run = report.load_run(run_id)
        self.meta = report_doc.clean_meta(meta_raw if isinstance(meta_raw, dict) else {})
        self.results = run["results"]
        self.code, self.feasible = report.pick_best(self.results, run["folder"])
        self.best = self.results[self.code]
        self.d = report_exec._summary(run)
        self.rec = self.d["recommended"]
        self.rel = report.reliability_for(run["folder"], self.code)
        self.sens = report.sensitivity_for(run["folder"])
        self.tech = report.technical(self.best)
        self.ecos = report.economic_rows(run)
        self.em = self.ecos.get(self.code) or {}
        self.ref_code = run.get("reference")
        self.ref = self.results.get(self.ref_code)
        self.is_ref = self.code == self.ref_code
        self.risks = report_doc.risk_register(run, self.code, self.rel, self.feasible)
        plan = run["config"].get("planning") or {}
        self.years = plan.get("appraisal_years") or plan.get("horizon_years") or len(self.annual(self.code))
        self.start, self.end = plan.get("start_year"), plan.get("end_year")
        self.used = report.effective_techs(run, self.code)[0]
        self.npc = report.total_npc(self.best)
        self.ref_npc = report.total_npc(self.ref) if self.ref else None
        self.saving_pct = 100 * (self.npc - self.ref_npc) / self.ref_npc if self.ref_npc and not self.is_ref else None
        self.rel_verdict = report.reliability_verdict(self.rel)
        self.design = None
        self.design_reason = ""

    def annual(self, code):
        return report_charts.annual_of(self.run, code)

    def name(self, code):
        """Option name using only the technologies that are built and dispatched."""
        result = self.results[code]
        if code == self.ref_code:
            return result["name"]
        used = report.effective_techs(self.run, code)[0]
        parts = [short for key, short, _ in report.TECH_GROUPS if key in used]
        return "Grid + " + " + ".join(parts) if parts else result["name"]

    def tech_names(self):
        return [short for key, short, _ in report.TECH_GROUPS if key in self.used]

    def caps_text(self, code=None):
        code = code or self.code
        return report.caps_text(self.results[code]["caps"], report.effective_techs(self.run, code)[0])

    def period(self):
        return f"{self.years} years"

    def horizon(self):
        return f"{self.years}-year"

    def pf_status(self):
        return (self.tech or {}).get("status")


def _ordered_unique(seq):
    seen, out = set(), []
    for item in seq:
        if item not in seen:
            seen.add(item)
            out.append(item)
    return out


# --------------------------------------------------------------------------- slide builders

def s_title(deck, c):
    m = c.meta
    s = deck.prs.slides.add_slide(deck.layout_title)
    title = m["project_name"] or "Energy supply options study"
    s.shapes.title.text_frame.text = title
    size, _ = fit_size([title], 11.7, 2.2, 40, 28, bold=True, space=0)
    for run in s.shapes.title.text_frame.paragraphs[0].runs:
        run.font.size = Pt(size)
    lines = ["Executive presentation: recommended supply option, results and decisions"]
    for label, key in (("Client", "client_name"), ("Prepared by", "prepared_by"), ("Consultant", "consulting_company"), ("Site", "site"),
                       ("Project number", "project_number"), ("Document", "document_number")):
        if m.get(key):
            lines.append(f"{label}: {m[key]}")
    lines.append(" | ".join(x for x in (m["date"], f"Revision {m['revision']}" if m.get("revision") else "") if x))
    if m.get("confidentiality") and m["confidentiality"] != report_doc.DEFAULT_CONFIDENTIALITY:
        lines.append(m["confidentiality"])
    sub = s.placeholders[1]
    sub.text_frame.text = lines[0]
    for line in lines[1:]:
        sub.text_frame.add_paragraph().text = line
    for i, p in enumerate(sub.text_frame.paragraphs):
        p.space_after = Pt(4)
        for run in p.runs:
            run.font.size = Pt(22 if i == 0 else 16)
    logo = m.get("logo") or ""
    match = re.match(r"data:image/(png|jpe?g);base64,(.+)$", logo, re.S)
    if match:
        try:
            from PIL import Image
            raw = base64.b64decode(match.group(2))
            img = Image.open(io.BytesIO(raw))
            ratio = img.width / img.height
            height = min(1.0, 3.0 / ratio)
            s.shapes.add_picture(io.BytesIO(raw), Inches(0.8), Inches(0.6), height=Inches(height)).name = "Logo"
        except Exception:
            pass
    deck.notes(s, "Opening slide. Purpose of this briefing: present the recommended supply option for the study, what it means for the client and the "
                  "decisions we need today. The deck is generated from the saved study run; every chart and table is editable.")


def s_executive(deck, c):
    rec, d = c.rec, c.d
    if not c.feasible:
        title = f"No option serves all demand; {c.code} leaves the least unserved energy"
    elif c.is_ref:
        title = f"No new equipment beats the reference over {c.period()}: {c.name(c.code)} at {_usd_m(c.npc)}"
    else:
        title = f"{c.name(c.code)} minimises {c.horizon()} cost at {_usd_m(c.npc)}"
        if c.saving_pct is not None:
            title += f", {abs(c.saving_pct):.0f}% {'below' if c.saving_pct < 0 else 'above'} the reference"
    s = deck.slide(title, "Decision at a glance. The recommended option is the lowest total net present cost (NPC) among options that serve all demand. "
                          "Technical checks (power flow, reliability) are remarks on the option; indicative correction costs are not included in the NPC. "
                          "Source: optimisation results, economic analysis and the analyses listed in the status row.")
    bullets = [[("Recommended: ", {"bold": True}), f"{c.name(c.code)} ({c.caps_text() or 'no new equipment'})"]]
    for why in (rec.get("why") or [])[:2]:
        bullets.append(why)
    if c.tech:
        bullets.append(f"Network screening: {c.pf_status()} with {c.tech.get('summary', {}).get('violations', 0)} finding(s); findings are remarks and "
                       "corrections are not in the NPC.")
    deck.text(s, MARGIN, TOP, 6.2, 3.45, bullets, size=16, bullet=True, space=6, name="Decision at a glance")
    keys = {k["key"]: k for k in d["kpis"]}
    tiles = [k for k in ("npc", "upfront", "npv", "lcoe", "renewable", "co2") if k in keys]
    tx, ty, tw, th = 6.95, TOP, 2.85, 1.2
    for i, key in enumerate(tiles):
        k = keys[key]
        note = k.get("note") or ""
        level = {"good": GREEN, "warn": DARK_AMBER, "bad": RED, "fail": RED}.get(k.get("level"), NAVY)
        deck.tile(s, tx + (i % 2) * (tw + 0.15), ty + (i // 2) * (th + 0.1), tw, th, k["value"], k["label"], note if len(note) <= 40 else None, level)
    pills = [("Demand", "Fully served" if c.feasible else "Unserved energy"), ("Power flow", c.pf_status()), ("Reliability", c.rel_verdict),
             ("Sensitivity", "Run" if c.sens else None)]
    x = MARGIN
    for label, status in pills:
        deck.pill(s, x, 5.4, 2.95, label, status if status else "Not run")
        x += 3.126
    deck.so_what(s, "The study identifies a clear lowest-cost supply option; the status row shows which verification analyses support it.",
                 "Approve this option as the basis for detailed design, subject to the conditions on the recommendations slide.")


def s_context(deck, c):
    annual = c.annual(c.code)
    if not annual:
        raise ValueError("no annual data")
    p0, p1 = annual[0].get("forecast_peak_mw"), annual[-1].get("forecast_peak_mw")
    limit = report_charts.grid_limit_for(c.run, c.code)
    title = f"Peak demand {'grows' if p1 > p0 else 'moves'} from {p0:.1f} to {p1:.1f} MW by {annual[-1]['year']}" if _fin(p0) and _fin(p1) else "The client needs a supply plan for the forecast demand"
    if limit and _fin(p1):
        title += f" against a {limit:.0f} MW grid limit"
    s = deck.slide(title, "The client challenge: serve forecast demand reliably and at lowest lifecycle cost while respecting the grid connection limit. "
                          "Figures come from the demand forecast and the saved study configuration.")
    objectives = [f"Serve all forecast demand over {c.period()} ({c.start}-{c.end})" if c.start and c.end else f"Serve all forecast demand over {c.period()}",
                  "Minimise total net present cost (NPC) of grid supply, on-site equipment, fuel, O&M and carbon"]
    checks = [n for n, ok in (("network (power flow) feasibility", c.tech), ("reliability and resilience", c.rel), ("cost sensitivity and risk", c.sens)) if ok]
    if checks:
        objectives.append("Verify " + ", ".join(checks))
    objectives.append("Hand over a design basis the client can take to detailed design")
    deck.text(s, MARGIN, TOP, 6.0, 0.5, ("Objectives", {"bold": True, "size": 18, "color": NAVY}), size=18, name="Objectives heading")
    deck.text(s, MARGIN, TOP + 0.5, 6.0, 2.95, objectives, size=16, bullet=True, space=6, name="Objectives")
    if c.meta.get("notes"):
        deck.text(s, MARGIN, 4.6, 6.0, 1.4, [("Client notes", {"bold": True, "color": NAVY}), c.meta["notes"][:400]], size=14, name="Client notes")
    e0, e1 = annual[0].get("demand_mwh"), annual[-1].get("demand_mwh")
    cards = []
    if _fin(p0) and _fin(p1) and p0:
        cards.append((f"{p1:.1f} MW", f"Peak demand in {annual[-1]['year']}", f"{100 * (p1 - p0) / p0:+.0f}% from {p0:.1f} MW in {annual[0]['year']}"))
    if _fin(e0) and _fin(e1):
        cards.append((f"{e1 / 1e3:,.0f} GWh", f"Energy demand in {annual[-1]['year']}", f"{e0 / 1e3:,.0f} GWh in {annual[0]['year']}"))
    if limit:
        cards.append((f"{limit:.0f} MW", "Grid import limit", "Binding constraint on the grid-only option"))
    upgrade = (c.ref["economics"].get("upgrade_pv") if c.ref else None) or 0
    if upgrade > 1e5:
        cards.append((_usd_m(upgrade), "Substation upgrade in the reference", "Cost avoided if on-site supply is enough"))
    for i, (value, label, note) in enumerate(cards[:4]):
        deck.tile(s, 6.95 + (i % 2) * 3.0, TOP + (i // 2) * 1.75, 2.85, 1.6, value, label, note)
    deck.so_what(s, "Growth in demand and a fixed grid limit are what make on-site supply worth evaluating against the grid-only reference.")


def s_approach(deck, c):
    n = len(c.results)
    ran = [bool(c.tech), bool(c.rel), bool(c.sens)]
    steps = [("1 Data", "Hourly demand history, tariffs and cost assumptions", True),
             ("2 Forecast", f"Demand projected over {c.period()} with growth and efficiency", True),
             ("3 Scenarios", f"{n} supply options defined, including a reference", True),
             ("4 Optimise", "Equipment sizes and hourly dispatch chosen to minimise NPC", True),
             ("5 Network checks", "Power flow in normal and N-1 cases (PASS/WARN/FAIL remarks)", bool(c.tech)),
             ("6 Economics & risk", "NPV, IRR, LCOE, sensitivity" + (", reliability" if c.rel else ""), True),
             ("7 Design", "Single-line diagram and equipment basis", c.design is not None)]
    s = deck.slide("Seven steps turn the client's data into a costed, checked design",
                   "Process overview. Options are ranked by total net present cost; technical checks are remarks and do not change the ranking. "
                   "Steps marked 'not run' are optional analyses that can be added in GenStudio.")
    w = CONTENT_W / 7
    for i, (name, desc, done) in enumerate(steps):
        x = MARGIN + i * w
        deck.shape(s, MSO_SHAPE.PENTAGON, x, 1.7, w - 0.02, 0.9, NAVY if done else GREY, name, size=14, bold=True, name=f"Step {i + 1}")
        deck.text(s, x, 2.75, w - 0.06, 2.0, desc, size=14, name=f"Step {i + 1} detail")
        deck.shape(s, MSO_SHAPE.ROUNDED_RECTANGLE, x + 0.1, 4.85, w - 0.25, 0.36, GREEN if done else "9AA5B1", "Done" if done else "Not run", size=12,
                   bold=True, rounded=0.5, name=f"Step {i + 1} status")
    deck.so_what(s, "Cost is optimised first, then every shortlisted option is stress-tested; nothing is recommended on cost alone.")


def s_demand(deck, c):
    annual = c.annual(c.code)
    years = [str(a["year"]) for a in annual]
    energy = [(a.get("demand_mwh") or 0) / 1e3 for a in annual]
    peak = [a.get("forecast_peak_mw") for a in annual]
    if len(annual) < 2:
        raise ValueError("no forecast")
    growth = 100 * (energy[-1] - energy[0]) / energy[0] if energy[0] else 0
    title = f"Energy demand {'grows' if growth >= 0 else 'falls'} {abs(growth):.0f}% to {energy[-1]:,.0f} GWh and the peak reaches {peak[-1]:.1f} MW by {annual[-1]['year']}"
    s = deck.slide(title, "Demand forecast used for every option. Left: annual energy served. Right: forecast peak demand against the grid import limit. "
                          "Source: saved demand forecast in the study run.")
    deck.chart(s, "col", MARGIN, TOP, 6.0, 4.6, years, [("Energy demand (GWh)", energy)], title="Annual energy demand (GWh)", colors=[BLUE], fmt="#,##0",
               legend=False)
    limit = report_charts.grid_limit_for(c.run, c.code)
    series = [("Forecast peak demand (MW)", peak)] + ([("Grid import limit (MW)", [limit] * len(years))] if limit else [])
    deck.chart(s, "line", 6.8, TOP, 6.03, 4.6, years, series, title="Forecast peak demand (MW)", colors=[NAVY, RED], fmt="#,##0", dashed=(1,))
    over = next((a["year"] for a in annual if limit and (a.get("forecast_peak_mw") or 0) > limit), None)
    meaning = f"Forecast peak demand exceeds the {limit:.0f} MW grid limit from {over}, so growth cannot be met by grid import alone." if over else \
        "Demand growth is the main driver of future cost; the forecast stays within the grid limit."
    deck.so_what(s, meaning, "Validate the demand growth assumptions with the client before final design." )


def s_options(deck, c):
    rows = sorted(c.d["table"], key=lambda r: r["rank"] if isinstance(r.get("rank"), (int, float)) else 99)[:9]
    body = []
    for r in rows:
        body.append([r["code"], c.name(r["code"]) if r["code"] in c.results else r["name"], r["mix"] or "No new equipment", r["npc"],
                     r.get("versus") or "reference", r["upfront"], r["unserved"], r.get("technical") or "Not run"])
    best_row = next((i for i, r in enumerate(rows) if r["code"] == c.code), None)
    s = deck.slide(f"{len(c.results)} supply options were compared on a like-for-like basis over {c.period()}",
                   "All options use the same demand, tariffs and constraints. NPC is the discounted lifecycle cost; ranking is by total NPC among options that "
                   "serve all demand. Power-flow status is a remark and any correction cost is not included in NPC.")
    deck.table(s, MARGIN, TOP, CONTENT_W, [0.6, 2.8, 3.6, 1.2, 1.0, 1.1, 1.2, 1.1], ["ID", "Option", "Equipment", "NPC", "vs ref.", "Upfront", "Unserved", "Power flow"],
               body, highlight=best_row, right=(3, 4, 5), name="Options table")
    deck.so_what(s, "Options differ in equipment, upfront capital and unserved energy; only options that serve all demand are ranked.",
                 None)


def s_optimisation(deck, c):
    rows = sorted(c.results.values(), key=lambda r: -report.total_npc(r))
    cats = [f"{r['code']}: {c.name(r['code'])}" for r in rows]
    vals = [currency.mega(report.total_npc(r)) for r in rows]
    cols = [TEAL if r["code"] == c.code else RED if not report.is_feasible(r) else NAVY if r["code"] == c.ref_code else BLUE for r in rows]
    ranked = sorted((r for r in c.results.values() if report.is_feasible(r) and r["code"] != c.code), key=report.total_npc)
    runner = ranked[0] if ranked else None
    gap = (report.total_npc(runner) - c.npc) / c.npc * 100 if runner else None
    title = f"{c.code} ranks first on total NPC" + (f", {abs(c.saving_pct):.0f}% below the reference" if c.saving_pct is not None else "")
    s = deck.slide(title, "Net present cost by option. The recommended option is highlighted; options coloured red leave demand unserved and are not equivalent in "
                          "service, so they are not ranked on cost.")
    deck.chart(s, "bar", MARGIN, TOP, 7.6, 4.6, cats, [(currency.label("NPC ($M)"), vals)], title=currency.label("Net present cost ($M, lower is better)"), colors=[BLUE], fmt=f"{currency.xl()}#,##0",
               labels=True, label_fmt=f'{currency.xl()}#,##0.0"M"', point_colors=cols, legend=False)
    points = [f"Recommended {c.code} costs {_usd_m(c.npc)}."]
    if c.ref_npc and not c.is_ref:
        points.append(f"That is {_usd_m(c.ref_npc - c.npc)} less than the reference {c.ref_code} ({_usd_m(c.ref_npc)}).")
    if runner:
        points.append(f"Runner-up {runner['code']} is only {_usd_m(runner['economics']['npc'] - c.npc, 2)} ({gap:.1f}%) behind.")
    for r in c.results.values():
        if not report.is_feasible(r):
            points.append(f"{r['code']} is cheaper on paper but leaves {(r.get('adequacy') or {}).get('unserved_mwh', 0):,.0f} MWh unserved.")
    deck.text(s, 8.3, TOP, 4.53, 4.6, points, size=16, bullet=True, space=8, name="Reading the chart")
    close = gap is not None and gap < 2
    deck.so_what(s, "The top options are close in cost, so verification results and non-cost factors can reasonably decide between them." if close
                 else "The recommended option is clearly the cheapest option that serves all demand.",
                 "Treat the runner-up as a fallback if verification finds the recommended option cannot be corrected economically." if close else None)


def _equipment(c):
    import unit_pf
    caps, eco, used = c.best["caps"], c.best["economics"], c.used
    vals = (c.run.get("request") or {}).get("values") or {}
    mva = lambda tech, mw: (f" ({unit_pf.rated_mva(mw, unit_pf.for_tech(vals, tech)['pf']):.1f} MVA)" if mw else "")
    rows, chart = [], []
    if (caps.get("pv_dc_mw") or 0) > 1e-6 and "pv" in used:
        rows.append(["Solar PV", f"{caps['pv_dc_mw']:.1f} MW DC{mva('pv', caps['pv_dc_mw'])}", _usd_m(eco.get("pv_capex"), 2)])
        chart.append(("Solar PV", caps["pv_dc_mw"], AMBER))
    if (caps.get("bess_mw") or 0) > 1e-6 and "bess" in used:
        hours = (caps.get("bess_mwh") or 0) / max(caps["bess_mw"], 1e-9)
        rows.append(["Battery storage", f"{caps['bess_mw']:.1f} MW{mva('bess', caps['bess_mw'])} / {caps.get('bess_mwh') or 0:.1f} MWh ({hours:.1f} h)", _usd_m(eco.get("bess_capex"), 2)])
        chart.append(("Battery power", caps["bess_mw"], GREEN))
    for key, mw in (caps.get("generators_mw") or {}).items():
        if mw > 1e-6 and key in used:
            rows.append([report.GEN_NAMES.get(key, key), f"{mw:.1f} MW{mva(key, mw)}", "in generator capex"])
            chart.append((report.GEN_NAMES.get(key, key), mw, RED))
    if (caps.get("wind_mw") or 0) > 1e-6 and "wind" in used:
        rows.append(["Wind", f"{caps['wind_mw']:.1f} MW{mva('wind', caps['wind_mw'])}", "n/a"])
        chart.append(("Wind", caps["wind_mw"], "3AA6A6"))
    if rows:
        if (eco.get("gen_capex") or 0) > 0:
            rows.append(["Generators (total)", "", _usd_m(eco["gen_capex"], 2)])
        rows.append(["Total upfront capital", "", _usd_m(eco["capex"], 2)])
    return rows, chart


def s_build(deck, c):
    rows, chart = _equipment(c)
    if not rows:
        raise ValueError("no new equipment")
    s = deck.slide(f"We would build {' + '.join(c.tech_names())} for {_usd_m(c.best['economics']['capex'])} upfront",
                   "Installed capacities of the recommended option. Only technologies that are built and dispatched are shown. Capex from the optimisation result.")
    deck.chart(s, "col", MARGIN, TOP, 5.6, 4.6, [x[0] for x in chart], [("Installed capacity (MW)", [x[1] for x in chart])], title="Installed capacity (MW)",
               colors=[BLUE], fmt="#,##0.0", labels=True, point_colors=[x[2] for x in chart], legend=False)
    deck.table(s, 6.4, TOP, 6.43, [2.0, 3.2, 1.6], ["Technology", "Capacity", "Capex"], rows, highlight=len(rows) - 1, right=(2,), name="Equipment table")
    caps = c.best["caps"]
    import unit_pf
    note = unit_pf.statement((c.run.get("request") or {}).get("values") or {})
    deck.so_what(s, f"A {caps.get('microgrid_total_ac_mw') or 0:.1f} MW on-site system supplies part of the demand; the rest is imported from the grid. {note}",
                 "Confirm land, grid-connection and supplier availability for these capacities.")


def s_mix(deck, c):
    annual = c.annual(c.code)
    series = report_charts.energy_series(annual)
    if len(annual) < 2 or not series:
        raise ValueError("no energy")
    years = [str(a["year"]) for a in annual]
    totals = [sum(s[1][i] for s in series) for i in range(len(years))]
    grid = next((sr[1] for sr in series if sr[0] == "Grid import"), [0] * len(years))
    g0, g1 = (100 * grid[0] / totals[0] if totals[0] else 0), (100 * grid[-1] / totals[-1] if totals[-1] else 0)
    title = f"The grid still supplies {g1:.0f}% of energy in {years[-1]}" + (f", down from {g0:.0f}% in {years[0]}" if g0 - g1 > 1 else "")
    s = deck.slide(title, "Energy supplied by source each year (GWh) and the horizon total as shares. Battery discharge is energy shifted in time, not a new source. "
                          "Source: annual dispatch results of the recommended option.")
    deck.chart(s, "col", MARGIN, TOP, 7.8, 4.6, years, [(name, [v / 1e3 for v in vals]) for name, vals, _ in series], title="Energy by source (GWh)", stacked=True,
               colors=[SOURCE_COLORS.get(n, GREY) for n, _, _ in series], fmt="#,##0")
    deck.chart(s, "doughnut", 8.5, TOP, 4.33, 4.6, [n for n, _, _ in series], [("Share", [sum(v) / 1e3 for _, v, _ in series])],
               title=f"Mix over {c.period()}", point_colors=[SOURCE_COLORS.get(n, GREY) for n, _, _ in series])
    deck.so_what(s, "On-site supply reduces but does not remove grid dependence, so grid tariffs remain the largest cost line.",
                 "Include tariff and grid-reliability risk in the commercial discussion.")


def s_day(deck, c):
    years = report_charts._years_for(c.run, c.code)
    data = report_charts.dispatch_summary(c.run, c.code, tuple(years)).get(years[-1])
    if not data or min(h["n"] for h in data["hour"]) < 300:
        raise ValueError("no dispatch")
    mean = lambda k: [h.get(k, 0) / h["n"] for h in data["hour"]]
    wind = mean("wind")
    series = [("Grid import", mean("grid")), ("New solar PV", mean("solar")), ("Wind", wind),
              ("Generators", [max(a - b, 0) for a, b in zip(mean("gen"), wind)]), ("Planned renewables", mean("planned")), ("BESS discharge", mean("discharge"))]
    series = [x for x in series if sum(x[1]) > 1e-6]
    grid = mean("grid")
    gh = max(range(24), key=lambda h: grid[h])
    s = deck.slide(f"On an average {years[-1]} day grid import peaks at {gh:02d}:00 ({grid[gh]:.1f} MW)",
                   f"Average hourly dispatch in {years[-1]} (MW). Shows how on-site sources and the battery displace grid import during the day.")
    deck.chart(s, "col", MARGIN, TOP, CONTENT_W, 4.6, [f"{h:02d}" for h in range(24)], [(n, v) for n, v in series], title=f"Average day dispatch {years[-1]} (MW)",
               stacked=True, colors=[SOURCE_COLORS.get(n, GREY) for n, _ in series], fmt="#,##0.0")
    deck.so_what(s, "The daily shape shows when the grid carries the load; that timing drives demand charges and the value of storage.")


def s_waterfall(deck, c):
    import explain
    if c.is_ref or not c.ref:
        raise ValueError("reference is best")
    ex = explain.explain({"run_id": [c.run_id], "scenario": [c.code]})
    steps = [x for x in ex.get("steps") or [] if _fin(x.get("delta"))]
    start, end = c.ref_npc, c.npc
    steps.sort(key=lambda x: -abs(x["delta"]))
    shown = steps[:6]
    other = (end - start) - sum(x["delta"] for x in shown)
    labels = [x["label"] for x in shown] + (["Other items"] if abs(other) > 5e4 else [])
    deltas = [x["delta"] for x in shown] + ([other] if abs(other) > 5e4 else [])
    cats = [f"Reference {c.ref_code}"] + labels + [f"{c.code}"]
    base, inc, dec, tot = [None], [None], [None], [currency.mega(start)]
    cur = start
    for dlt in deltas:
        tot.append(None)
        if dlt >= 0:
            base.append(currency.mega(cur)), inc.append(currency.mega(dlt)), dec.append(None)
            cur += dlt
        else:
            cur += dlt
            base.append(currency.mega(cur)), inc.append(None), dec.append(currency.mega(-dlt))
    base.append(None), inc.append(None), dec.append(None), tot.append(currency.mega(end))
    top = min(shown, key=lambda x: x["delta"]) if shown else None
    title = f"{top['label']} is the largest part of the {_usd_m(start - end)} saving versus the reference" if top and top["delta"] < 0 and start > end else \
        f"The option is {_usd_m(start - end)} cheaper than the reference over {c.period()}"
    s = deck.slide(title, "Bridge from the reference NPC to the recommended NPC. Red bars add cost, green bars save cost, in present value (" + currency.label("$M") + "). "
                          "Items are the NPC components from the optimisation result; small items are grouped.")
    chart = deck.chart(s, "col", MARGIN, TOP, CONTENT_W, 4.6, cats, [("Base", base), ("Cost increase", inc), ("Cost saving", dec), ("NPC", tot)], stacked=True,
                       colors=[None, RED, GREEN, NAVY], fmt=f'{currency.xl()}#,##0', title=currency.label("NPC bridge ($M)"))
    deck.hide_legend_entry(chart, 0)
    deck.so_what(s, "The saving comes from avoided or reduced cost lines, not from a cheaper like-for-like supply.",
                 "Confirm the avoided cost items (for example the grid upgrade) with the client, since the case depends on them.")


def s_economics(deck, c):
    if c.is_ref or not c.em or c.em.get("status") == "reference":
        raise ValueError("no economics")
    curves = (report_charts.cashflow_curves(c.run).get("net") or [])
    em = c.em
    npv = em.get("npv")
    title = (f"Net present value is {_usd_m(npv)} versus the reference; payback is {report.fmt_pb(em, 'simple_payback')}" if _fin(npv) and npv >= 0
             else f"The option has a net present value of {_usd_m(npv)} versus the reference")
    s = deck.slide(title, "Economics versus the reference case: NPV, IRR, payback and levelised cost. IRR can be undefined when the option costs less than the "
                          "reference from the start (no net investment to return). Operating-basis metrics are in the economic analysis of the report.")
    if curves:
        ordered = sorted(curves, key=lambda x: (x[0] != c.code, -x[1][-1][1]))[:4]
        deck.chart(s, "line", MARGIN, TOP, 7.3, 4.6, [f"Y{i}" for i, _ in ordered[0][1]], [(f"{code}", [v for _, v in pts]) for code, pts in ordered],
                   title=currency.label("Cumulative discounted saving vs reference ($M)"), fmt=f"{currency.xl()}#,##0", colors=[TEAL, BLUE, AMBER, PURPLE])
    tiles = [(_usd_m(npv), "Net present value", "vs reference"), (report.fmt_irr(em, "irr").replace(" (see note)", ""), "IRR", "net basis"),
             (report.fmt_pb(em, "simple_payback"), "Simple payback", None), (currency.money(em['lcoe'], 1, 1, '/MWh') if _fin(em.get("lcoe")) else "n/a", "LCOE", "supply cost per MWh")]
    for i, (value, label, note) in enumerate(tiles):
        deck.tile(s, 8.05 + (i % 2) * 2.45, TOP + (i // 2) * 1.6, 2.35, 1.5, value, label, note, TEAL if i == 0 else NAVY)
    if em.get("irr") is None and em.get("irr_note"):
        deck.text(s, 8.05, TOP + 3.3, 4.8, 1.3, str(em["irr_note"])[:220], size=12, color=GREY, name="IRR note")
    deck.so_what(s, "The investment case rests on the savings against the reference over the whole horizon." if _fin(npv) and npv >= 0
                 else "The option does not beat the reference on net present value.",
                 "Test the case against tariff and capital-cost changes (see sensitivity) before committing funds." if c.sens else
                 "Run the sensitivity analysis to test the case against tariff and cost changes before committing funds.")


def s_emissions(deck, c):
    annual = c.annual(c.code)
    key = "net_co2e_after_heat_credit_t"
    if len(annual) < 2 or not any(a.get(key) for a in annual):
        raise ValueError("no emissions")
    years = [str(a["year"]) for a in annual]
    mine = [(a.get(key) or 0) / 1e3 for a in annual]
    series = [(f"{c.code} (recommended)", mine)]
    ref_annual = c.annual(c.ref_code) if c.ref and not c.is_ref else []
    if ref_annual:
        series.append((f"{c.ref_code} (reference)", [(a.get(key) or 0) / 1e3 for a in ref_annual]))
    share = report_charts.renewable_fraction(annual)
    avoided = (c.em.get("co2e_avoided_t") or 0) / 1e3 if c.em else 0
    title = f"Emissions fall {avoided:,.1f} kt CO2e over {c.period()} and renewables reach {share[-1]:.0f}% of demand by {years[-1]}" if avoided > 0 and _fin(share[-1]) \
        else f"Renewables supply {share[-1]:.0f}% of demand by {years[-1]}" if _fin(share[-1]) and share[-1] > 0 else "Emissions follow grid supply over the horizon"
    s = deck.slide(title, "Net CO2e emissions by year for the recommended option and the reference, and the renewable share of demand. Source: annual dispatch "
                          "results and the grid emission factor in the study configuration.")
    deck.chart(s, "col", MARGIN, TOP, 6.5, 4.6, years, series, title="Net CO2e emissions (kt per year)", colors=[TEAL, GREY], fmt="#,##0.0")
    if any(v and v > 0 for v in share):
        deck.chart(s, "line", 7.2, TOP, 5.63, 4.6, years, [("Renewable share of demand (%)", share)], title="Renewable share of demand (%)", colors=[GREEN],
                   fmt="0", legend=False)
    deck.so_what(s, "Lower emissions follow directly from displacing grid energy with on-site generation." if avoided > 0 else
                 "The option does not materially change emissions versus the reference.",
                 "Agree whether an emissions or renewable-share target should be added as a design constraint." if avoided > 0 else None)


def s_sensitivity(deck, c):
    rep = c.sens["report"]
    swings = sorted(rep["swings"], key=lambda x: -x.get("swing", 0))[:8]
    base = (rep.get("base") or {}).get("npc") or c.npc
    cats = [f"{x['label']} ({x['low']:g} to {x['high']:g}{' ' + x['unit'] if x.get('unit') else ''})" for x in swings][::-1]
    low = [currency.mega(x["delta_low"]) for x in swings][::-1]
    high = [currency.mega(x["delta_high"]) for x in swings][::-1]
    top = swings[0]
    other = c.sens.get("scenario_id") and c.sens["scenario_id"] != c.code
    s = deck.slide(f"{top['label']} is the biggest cost driver, moving NPC by {_usd_m(top['swing'])} across the tested range",
                   "Tornado chart: change in NPC when one input moves from its low to its high value, all else equal. Bars are sorted by effect. "
                   + (f"The saved sensitivity analysis was run for scenario {c.sens['scenario_id']}, not {c.code}. " if other else "")
                   + "Source: sensitivity analysis of the study run.")
    deck.chart(s, "bar", MARGIN, TOP, 8.0, 4.6, cats, [("Input at low value", low), ("Input at high value", high)],     title=currency.label("Change in NPC vs base ($M)"), tornado=True,
                   colors=[BLUE, AMBER], fmt=f'+{currency.xl()}#,##0;-{currency.xl()}#,##0', labels=True, label_fmt=f'+{currency.xl()}#,##0.0;-{currency.xl()}#,##0.0')
    bullets = [f"{x['label']}: {_usd_m(x['swing'])} swing" + (" - changes the best mix" if x.get("mix_changes") else "") for x in swings[:3]]
    if other:
        bullets.append(f"Run for {c.sens['scenario_id']}.")
    deck.text(s, 8.7, TOP, 4.13, 4.6, [("What drives the answer", {"bold": True, "color": NAVY, "nobullet": True})] + bullets, size=15, bullet=True, space=6,
              name="Drivers")
    deck.so_what(s, "A few inputs explain most of the uncertainty in cost; the rest barely matter.",
                 f"Firm up {top['label'].lower()} (contracts, quotes or hedging) before the investment decision.")


def s_risk_range(deck, c):
    risk = c.sens["report"]["risk"]
    labels = [("Minimum", "minimum"), ("P10", "p10"), ("P50", "p50"), ("P90", "p90"), ("Maximum", "maximum")]
    labels = [(a, b) for a, b in labels if _fin(risk.get(b))]
    if len(labels) < 3:
        raise ValueError("no risk range")
    vals = [currency.mega(risk[b]) for _, b in labels]
    title = f"NPC is most likely between {_usd_m(risk['p10'] * 1.0)} and {_usd_m(risk['p90'])} (P10 to P90)"
    s = deck.slide(title, "Range of NPC when all tested inputs vary together (Monte Carlo style combination of the sensitivity ranges). P10, P50 and P90 are values not "
                          "exceeded with 10%, 50% and 90% probability.")
    deck.chart(s, "col", MARGIN, TOP, 7.2, 4.6, [a for a, _ in labels],     [(currency.label("NPC ($M)"), vals)], title=currency.label("NPC range ($M)"), colors=[BLUE], fmt=f"{currency.xl()}#,##0", labels=True,
                   label_fmt=f'{currency.xl()}#,##0.0"M"', point_colors=[TEAL if a == "P50" else BLUE for a, _ in labels], legend=False)
    pts = [f"Median (P50): {_usd_m(risk['p50'])}.", f"P10 to P90 spread: {_usd_m(risk['p90'] - risk['p10'])}."]
    if c.ref_npc and not c.is_ref:
        pts.append(f"The reference NPC of {_usd_m(c.ref_npc)} is {'above' if c.ref_npc > risk['p90'] else 'within'} the P10-P90 range"
                   + (" of the option." if c.ref_npc > risk['p90'] else "; the advantage is not guaranteed in every case."))
    deck.text(s, 8.0, TOP, 4.83, 4.6, pts, size=16, bullet=True, space=8, name="Risk reading")
    robust = c.ref_npc and c.ref_npc > risk["p90"] and not c.is_ref
    deck.so_what(s, "Even in the unfavourable P90 case the option stays cheaper than the reference." if robust else
                 "Cost uncertainty is material and should be reflected in the budget contingency.",
                 "Hold a contingency at the P90 value for budgeting." if robust else "Set the budget contingency using the P90 value.")


def s_reliability(deck, c):
    rel = c.rel
    summ, verdict = rel["summary"], c.rel_verdict
    det = rel.get("verdict_detail") or {}
    title = f"Reliability is {verdict}: about {summ['lole_h_yr']:.0f} h of downtime and {summ['eue_mwh_yr']:,.0f} MWh unserved per year"
    s = deck.slide(title, "Reliability screening under random outages of the grid connection and on-site units (N-1). EENS is expected energy not served, LOLE is expected "
                          "hours with unserved load, and outage cost uses the value of lost load entered in the study. Wording: results are remarks, not NPC items.")
    color = STATUS_COLOR.get(verdict, NAVY)
    tiles = [(verdict, "Verdict", color), (f"{summ['eue_mwh_yr']:,.0f} MWh", "Expected unserved energy per year", NAVY),
             (f"{summ['lole_h_yr']:.1f} h", "Expected downtime per year", NAVY), (_usd_m(summ.get("cost_yr"), 2), "Outage cost per year", NAVY)]
    for i, (value, label, col) in enumerate(tiles):
        deck.tile(s, MARGIN + i * 3.1, TOP, 2.95, 1.25, value, label, None, col)
    cont = sorted(rel.get("contingencies") or [], key=lambda x: -(x.get("eue_mwh_yr") or 0))[:5][::-1]
    if cont:
        deck.chart(s, "bar", MARGIN, 2.8, 6.2, 3.25, [x["name"] for x in cont], [("EENS (MWh per year)", [x["eue_mwh_yr"] for x in cont])],
                   title="Unserved energy by event (MWh per year)", colors=[RED], fmt="#,##0", labels=True, legend=False)
    measures = sorted(rel.get("measures") or [], key=lambda x: x.get("rank", 99))[:3]
    if measures:
        deck.table(s, 6.95, 2.8, 5.88, [3.0, 1.2, 1.2], ["Mitigation (ranked)", "Cost PV", "Benefit/cost"],
                   [[m["name"], _usd_m(m.get("cost_pv"), 2), f"{m['benefit_cost_ratio']:.1f}" if _fin(m.get("benefit_cost_ratio")) else "n/a"] for m in measures],
                   right=(1, 2), max_bottom=BOTTOM, name="Mitigation table")
    best = summ.get("best_measure")
    secure = []
    if "local_n1_secure" in det:
        secure.append(f"local N-1 {'secure' if det['local_n1_secure'] else 'not secure'}")
    if "grid_n1_secure" in det:
        secure.append(f"grid N-1 {'secure' if det['grid_n1_secure'] else 'not secure'}")
    deck.so_what(s, "Loss of the grid connection drives most of the unserved energy" + (f" ({', '.join(secure)})." if secure else "."),
                 f"Adopt the top-ranked measure ({best}) and re-run the reliability analysis." if best else "Define a mitigation plan and re-run the analysis.")


def s_powerflow(deck, c):
    t, summ = c.tech, c.tech.get("summary") or {}
    viol = t.get("violations") or []
    status = c.pf_status()
    n = summ.get("violations", len(viol))
    title = (f"Network screening is {status}: {n} finding(s) to correct before detailed design" if n else f"Network screening is {status}: no violations in normal and N-1 cases")
    island = t.get("islanded") if isinstance(t.get("islanded"), dict) else None
    s = deck.slide(title, "Power-flow screening of the recommended option in normal operation and N-1 outages. Findings are remarks (PASS/WARN/FAIL) and do not change "
                          "the NPC ranking; indicative correction costs are not included in the NPC." +
                          (f" {island['chip']} (informational, not used for the recommendation)." if island and island.get("chip") else ""))
    tiles = [(status, "Overall", STATUS_COLOR.get(status, NAVY)), (t.get("normal_status") or "n/a", "Normal operation", STATUS_COLOR.get(t.get("normal_status"), NAVY)),
             (t.get("n1_status") or "n/a", "N-1 outages", STATUS_COLOR.get(t.get("n1_status"), NAVY)),
             (f"{summ['vmin']:.3f}-{summ['vmax']:.3f} pu" if _fin(summ.get("vmin")) and _fin(summ.get("vmax")) else "n/a", "Voltage range", NAVY),
             (f"{summ['max_loading_pct']:.0f}%" if _fin(summ.get("max_loading_pct")) else "n/a", "Highest branch loading", NAVY)]
    for i, (value, label, col) in enumerate(tiles):
        deck.tile(s, MARGIN + i * 2.5, TOP, 2.33, 1.25, value, label, None, col)
    counts = {}
    for v in viol:
        key = str(v.get("type") or "other").replace("_", " ").capitalize()
        counts[key] = counts.get(key, 0) + 1
    if counts:
        items = sorted(counts.items(), key=lambda x: x[1])[-6:]
        deck.chart(s, "bar", MARGIN, 2.8, 5.6, 3.25, [k for k, _ in items], [("Findings", [v for _, v in items])], title="Findings by type", colors=[RED], fmt="0",
                   labels=True, legend=False)
    sugg = [x for x in (t.get("suggestions") or []) if x.get("recommended", True) and _fin(x.get("suggested"))][:5]
    if sugg:
        deck.table(s, 6.4, 2.8, 6.43, [4.3, 1.4], ["Indicative reinforcement", "Size"], [[x["label"], f"{x['suggested']:.2f} {x.get('unit') or ''}".strip()] for x in sugg],
                   right=(1,), name="Reinforcement table")
    elif not counts:
        deck.text(s, MARGIN, 3.0, CONTENT_W, 1.0, "No violations were found; no reinforcement is indicated.", size=18)
    deck.so_what(s, "The option is not yet technically compliant; these are remarks to resolve, and their cost is not in the NPC." if n else
                 "The option passes the screening; no network reinforcement is indicated.",
                 "Apply the indicated reinforcements, re-run the power flow and add their cost to the business case." if n else None)


def s_design(deck, c):
    data = c.design
    meta = data.get("meta") or {}
    volts, totals, sc, shunt = data.get("voltages") or {}, data.get("totals") or {}, data.get("short_circuit") or {}, data.get("shunt") or {}
    rows = [["Design status", meta.get("status")],
            ["Grid connection voltage", None if meta.get("islanded") else (f"{volts['hv_kv']} kV" if volts.get("hv_kv") else None)],
            ["Plant medium-voltage bus", f"{volts['mv_kv']} kV" if volts.get("mv_kv") else None],
            ["Inverter / LV terminals", f"{volts['lv_kv']} kV" if volts.get("lv_kv") else None],
            ["Main transformer (total)", f"{totals['main_transformer_mva']} MVA" if totals.get("main_transformer_mva") else None],
            ["Fault level at MV bus", f"{sc['mv_ka']} kA" if sc.get("mv_ka") else None],
            ["Capacitor bank", f"{shunt['stages']} x {shunt.get('stage_mvar', 0)} Mvar" if shunt.get("stages") else None]]
    rows = [[a, str(b)] for a, b in rows if b not in (None, "")]
    parts = [x for x in (f"{volts['hv_kv']} kV connection" if volts.get("hv_kv") and not meta.get("islanded") else "",
                         f"{totals['main_transformer_mva']} MVA main transformer" if totals.get("main_transformer_mva") else "") if x]
    s = deck.slide("Design basis: " + ", ".join(parts) if parts else "The proposed single-line design", "Single-line diagram and key design parameters of the recommended "
                   "option, from the technical design document. The diagram is a picture; see the design document for the editable source and full detail.")
    png = _sld_png(data)
    if png:
        from PIL import Image
        img = Image.open(io.BytesIO(png))
        scale = min(7.4 / img.width, 4.6 / img.height)
        pic = s.shapes.add_picture(io.BytesIO(png), Inches(MARGIN), Inches(TOP), Inches(img.width * scale), Inches(img.height * scale))
        pic.name = "Single-line diagram"
        pic._element.nvPicPr.cNvPr.set("descr", "Single-line diagram of the recommended design")
    else:
        deck.text(s, MARGIN, TOP, 7.4, 1.0, "The single-line diagram could not be rendered here; see the technical design document.", size=16, color=GREY)
    deck.table(s, 8.2, TOP, 4.63, [2.5, 1.7], ["Parameter", "Value"], rows, name="Design parameters")
    deck.so_what(s, "The design basis is concrete enough to start detailed engineering.", "Proceed to detailed design once the open verification items are closed.")


def _sld_png(data):
    try:
        import design
        import pymupdf
        svg = report_doc.clean_svg(design.sld_svg(data))
        doc = pymupdf.open(stream=svg.encode("utf-8"), filetype="svg")
        return doc[0].get_pixmap(dpi=110).tobytes("png")
    except Exception:
        return None


def s_roadmap(deck, c):
    steps = report_doc.next_steps(c.run, c.code, c.rel, c.sens)
    phases = ["Decide", "Verify", "Detailed design", "Procure & permit", "Build & operate"]
    s = deck.slide("Next steps: decide, verify, then move into detailed design",
                   "Indicative sequence from this study to operation. The actions come from the study's verification status; durations are not estimated here.")
    w = CONTENT_W / len(phases)
    for i, p in enumerate(phases):
        deck.shape(s, MSO_SHAPE.PENTAGON, MARGIN + i * w, TOP, w - 0.03, 0.8, NAVY if i < 2 else BLUE, p, size=16, bold=True, name=f"Phase {i + 1}")
    deck.text(s, MARGIN, 2.45, CONTENT_W, 3.6, steps[:7], size=16, bullet=True, space=6, name="Next steps")
    deck.so_what(s, "The study ends with a short list of verification actions rather than open-ended work.", "Assign an owner and a date to each action at this meeting.")


def s_risks(deck, c):
    order = {"High": 0, "Medium": 1, "Low": 2}
    risks = sorted(c.risks, key=lambda r: (order.get(r["rating"], 3), -(r.get("score") or 0)))[:6]
    high = sum(1 for r in c.risks if r["rating"] == "High")
    s = deck.slide(f"{high} high-rated risk(s) need an owner and a mitigation plan" if high else "No high-rated risks were identified; the register needs routine review",
                   "Risk register summarised from the study results (likelihood x impact). Mitigations are proposed actions, not commitments.")
    deck.table(s, MARGIN, TOP, CONTENT_W, [0.6, 3.6, 0.9, 0.9, 0.9, 5.0], ["ID", "Risk", "Likelihood", "Impact", "Rating", "Mitigation"],
               [[r["id"], r["risk"], r["lik"], r["imp"], r["rating"], r["mit"]] for r in risks], size=12, name="Risk table")
    deck.so_what(s, "Most risks are manageable with actions the client controls.", "Review the register at each design milestone.")


def s_recommendations(deck, c):
    items = []
    if not c.feasible:
        items.append(["Do not proceed with any option as modelled", f"No option serves all demand; {c.code} leaves the least unserved energy. Relax constraints and re-run."])
    else:
        why = f"Lowest NPC at {_usd_m(c.npc)}" + (f", {_usd_m(c.ref_npc - c.npc)} below the reference" if c.ref_npc and not c.is_ref else "")
        items.append([f"Approve {c.name(c.code)} ({c.caps_text() or 'no new equipment'}) as the design basis", why])
    if c.sens:
        top = max(c.sens["report"]["swings"], key=lambda x: x.get("swing", 0))
        items.append([f"Confirm {top['label'].lower()} and other key assumptions", f"Largest NPC driver: {_usd_m(top['swing'])} swing across the tested range"])
    else:
        items.append(["Confirm demand, tariff and cost assumptions", "Listed in the appendix; run the sensitivity analysis to see their effect"])
    if c.tech and c.pf_status() in ("WARN", "FAIL"):
        items.append(["Authorise network reinforcement studies and re-run power flow", f"Status {c.pf_status()}; corrections are not yet in the NPC"])
    if c.rel and c.rel_verdict in ("WARN", "FAIL"):
        best = c.rel["summary"].get("best_measure")
        items.append([f"Decide on a resilience measure{f': {best}' if best else ''}", f"Reliability {c.rel_verdict}: {c.rel['summary']['eue_mwh_yr']:,.0f} MWh per year unserved"])
    missing = [n for n, ok in (("sensitivity", c.sens), ("reliability", c.rel), ("power-flow", c.tech)) if not ok]
    if missing:
        items.append([f"Complete the {', '.join(missing)} analyses before the investment decision", "These checks were not run for this study"])
    items.append(["Commission detailed design and procurement planning", "Once the conditions above are met"])
    items = items[:6]
    s = deck.slide(f"We recommend proceeding with {c.name(c.code)} subject to {len(items) - 1} condition(s)" if c.feasible else "Decisions required: resolve the unserved demand first",
                   "Decisions and actions requested from the executive audience. Each action traces to a result in this deck.")
    deck.table(s, MARGIN, TOP, CONTENT_W, [0.5, 6.4, 5.4], ["#", "Decision / action", "Why"], [[str(i + 1)] + it for i, it in enumerate(items)], size=14, min_row=0.6,
               max_bottom=6.9, name="Decisions")


def s_not_run(deck, c):
    rows = []
    if not c.sens:
        rows.append(["Sensitivity and risk range", "Which inputs drive cost, and the P10-P50-P90 range", "ANALYZE > Sensitivity"])
    if not c.rel:
        rows.append(["Reliability and resilience", "Unserved energy, downtime and mitigation options", "ANALYZE > Reliability"])
    if not c.tech:
        rows.append(["Network (power-flow) check", "PASS/WARN/FAIL remarks and indicative reinforcements", "Tick 'Run technical check' when solving"])
    s = deck.slide("Analyses not yet run: each adds evidence for the investment decision",
                   "These analyses are optional and were not run for this study, so no results are shown. Run them in GenStudio and regenerate the presentation.")
    deck.table(s, MARGIN, TOP, CONTENT_W, [3.0, 5.4, 3.9], ["Analysis", "What it would show", "How to run"], rows, size=14, min_row=0.6, name="Analyses not run")
    deck.so_what(s, "The recommendation currently rests on cost optimisation only.", "Run the missing analyses, then regenerate this presentation.")


def s_equations(deck, c):
    used = c.used
    terms = ["P_grid(h)"] + (["P_PV(h)"] if "pv" in used else []) + (["P_wind(h)"] if "wind" in used else []) + \
        (["P_gen(h)"] if any(k not in ("pv", "bess", "wind") for k in used) else []) + (["P_BESS,dis(h) - P_BESS,ch(h)"] if "bess" in used else [])
    eqs = [("Objective: net present cost (minimised)", "NPC = I₀ + Σₜ Cₜ / (1 + r)ᵗ",
            "I₀ upfront capital; Cₜ grid, fuel, O&M, carbon and replacement cost in year t; r discount rate"),
           ("Levelised cost of energy", "LCOE = NPC / Σₜ [ Eₜ / (1 + r)ᵗ ]", "Eₜ energy served in year t"),
           ("Net present value and IRR versus the reference", "NPV = Σₜ ΔCFₜ / (1 + r)ᵗ ,  IRR: NPV = 0",
            "ΔCFₜ = reference cost − option cost in year t, upfront capital at t = 0"),
           ("Hourly power balance", " + ".join(terms) + " + Unserved(h) = Load(h)", "Holds in every hour h; unserved load is penalised")]
    if c.rel:
        eqs.append(("Reliability", "EENS = Σₖ (events per year)ₖ × (energy not served per event)ₖ", "LOLE = expected hours per year with unserved load"))
    s = deck.slide("Appendix: the key equations behind the results",
                   "Only the equations needed to interpret the results are shown, as editable text. They summarise the optimisation and the economic and reliability "
                   "metrics; the full formulation is in the mathematical model documentation.")
    step = 5.55 / len(eqs)
    for i, (name, eq, note) in enumerate(eqs):
        deck.text(s, MARGIN, 1.4 + i * step, CONTENT_W, step - 0.08, [(name, {"bold": True, "size": 14, "color": NAVY}), (eq, {"size": 20, "font": EQ_FONT}),
                  (note, {"size": 12, "color": GREY})], size=14, space=1, name=f"Equation {i + 1}")


def s_assumptions(deck, c):
    rows = [[a, str(b)] for a, b in (c.d.get("assumptions") or [])][:18]
    if not rows:
        raise ValueError("no assumptions")
    half = (len(rows) + 1) // 2
    s = deck.slide("Appendix: key assumptions behind the results", "Study assumptions as saved with the run. Changing any of them can change the ranking; see the sensitivity analysis.")
    deck.table(s, MARGIN, TOP, 6.05, [2.4, 3.2], ["Assumption", "Value"], rows[:half], max_bottom=6.95, name="Assumptions 1")
    if rows[half:]:
        deck.table(s, 6.78, TOP, 6.05, [2.4, 3.2], ["Assumption", "Value"], rows[half:], max_bottom=6.95, name="Assumptions 2")


def s_glossary(deck, c):
    always = {"NPC", "LCOE", "NPV", "IRR", "SLD", "POI"}
    optional = {"BESS": "bess" in c.used, "P50 / P90": bool(c.sens), "EUE": bool(c.rel), "LOLE": bool(c.rel), "N-1": bool(c.rel or c.tech), "VOLL": bool(c.rel),
                "O&M": True, "PV": "pv" in c.used}
    rows = [g for g in report_doc.GLOSSARY if g[0] in always or optional.get(g[0])]
    half = (len(rows) + 1) // 2
    s = deck.slide("Appendix: glossary", "Terms used in this presentation.")
    deck.table(s, MARGIN, TOP, 6.05, [1.2, 4.6], ["Term", "Meaning"], rows[:half], max_bottom=6.95, name="Glossary 1")
    if rows[half:]:
        deck.table(s, 6.78, TOP, 6.05, [1.2, 4.6], ["Term", "Meaning"], rows[half:], max_bottom=6.95, name="Glossary 2")


# --------------------------------------------------------------------------- entry points

def _guard(deck, name, fn, *args):
    """Build one slide; a slide whose data is missing is skipped, and any other failure is recorded."""
    before = len(deck.prs.slides)
    try:
        fn(deck, *args)
    except ValueError:
        while len(deck.prs.slides) > before:
            deck.drop_last()
    except Exception as exc:
        while len(deck.prs.slides) > before:
            deck.drop_last()
        deck.problems.append(f"slide '{name}' failed: {type(exc).__name__}: {exc}")


def build_deck(run_id, meta_raw=None):
    c = Ctx(run_id, meta_raw)
    footer = " | ".join(x for x in (c.meta["project_name"], c.meta["client_name"], "Executive presentation") if x)
    deck = Deck(footer)
    try:
        c.design, c.design_reason = report_doc.design_data(c.run, c.code, c.meta.get("detail") or "equivalent")
    except Exception as exc:
        c.design, c.design_reason = None, str(exc)
    plan = [("title", s_title), ("executive", s_executive), ("context", s_context), ("approach", s_approach), ("demand", s_demand), ("options", s_options),
            ("optimisation", s_optimisation), ("build", s_build), ("mix", s_mix), ("day", s_day), ("waterfall", s_waterfall), ("economics", s_economics),
            ("emissions", s_emissions)]
    if c.sens:
        plan += [("sensitivity", s_sensitivity), ("risk range", s_risk_range)]
    if c.rel:
        plan.append(("reliability", s_reliability))
    if c.tech:
        plan.append(("power flow", s_powerflow))
    if not (c.sens and c.rel and c.tech):
        plan.append(("not run", s_not_run))
    if c.design:
        plan.append(("design", s_design))
    plan += [("roadmap", s_roadmap), ("risks", s_risks), ("recommendations", s_recommendations), ("equations", s_equations), ("assumptions", s_assumptions),
             ("glossary", s_glossary)]
    for name, fn in plan:
        _guard(deck, name, fn, c)
    out = io.BytesIO()
    deck.prs.core_properties.title = c.meta["project_name"] or "Executive presentation"
    deck.prs.core_properties.author = c.meta["prepared_by"] or c.meta["consulting_company"] or "GenStudio"
    deck.prs.save(out)
    return out.getvalue(), deck.problems


def build(run_id, meta_raw=None):
    """Return the .pptx bytes for a saved run."""
    return build_deck(run_id, meta_raw)[0]


def file_name(meta_raw):
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", report_doc.clean_meta(meta_raw if isinstance(meta_raw, dict) else {})["project_name"]).strip("_")
    return f"{name or 'GenStudio'}_Executive_Presentation.pptx"
