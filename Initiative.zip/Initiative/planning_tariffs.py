"""All-inclusive energy rates; only separately selected reactive demand is added."""

import numpy as np


def _within(value, start, end):
    """Half-open window [start, end) that may wrap past the end of the cycle (e.g. 22 to 6 h)."""
    return (start <= value) & (value < end) if start <= end else (value >= start) | (value < end)


def tariffs(dates, values):
    v = values
    months = np.array([d.month for d in dates])
    hours = np.array([d.hour for d in dates])
    summer = (v["summer_start_month"] <= months) & (months <= v["summer_end_month"]) \
        if v["summer_start_month"] <= v["summer_end_month"] else \
        (months >= v["summer_start_month"]) | (months <= v["summer_end_month"])
    peak = _within(hours, v["peak_start_hour"], v["peak_end_hour"])
    mid = _within(hours, v["mid_start_hour"], v["mid_end_hour"])
    weekend = np.array([d.weekday() >= 5 for d in dates])
    if v["weekend_mid_peak"]:
        mid = mid | (peak & weekend)
        peak = peak & ~weekend
    bands = np.where(peak, "peak", np.where(mid, "mid", "off"))
    if v["tariff_mode"] == "blended":
        energy = np.full(len(dates), v["blended_kwh"] * 1000)
    else:
        energy = np.empty(len(dates))
        for season, mask in (("summer", summer), ("winter", ~summer)):
            for band in ("off", "mid", "peak"):
                key = season + ("_off_kwh" if v[season + "_same"] else "_" + band + "_kwh")
                energy[mask & (bands == band)] = v[key] * 1000
    nmonths = 12 * (dates[-1].year - dates[0].year + 1)
    reactive = v["reactive_rate"] * v["reactive_ratio"] * 1000 if v["reactive_enabled"] else 0
    return dict(grid_energy=energy, facility=np.full(nmonths, reactive), tou=np.zeros(nmonths),
                fixed=np.zeros(nmonths), tariff_band=bands, peak_window=peak)
