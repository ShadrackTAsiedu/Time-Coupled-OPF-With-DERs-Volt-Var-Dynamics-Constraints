"""Indicative installed cost of power-flow corrective actions (transformers, shunt banks, line upgrades, reactive capability).

Planning-grade (AACE class 5, about -30 % / +50 %) budgetary costs in 2024 USD for MV/HV equipment, calibrated against the public
unit-cost ranges of the MISO Transmission Cost Estimation Guide (MTEP23), the CAISO PTO Per Unit Cost Guides (2023), PJM RTEP project
costs and EPRI/NREL utility cost studies.  They are not quotes: replace them with utility or vendor prices for any real project.

Every cost is  direct x (1 + engineering% + contingency%) x regional factor  where
  direct = equipment (size-dependent power law, voltage-class factor) x (1 + installation%) + fixed scope (protection, bay, commissioning).
Equipment follows cost = k x MVA^0.72 (economies of scale: the cost per MVA falls with size); fixed scopes scale with voltage class.
All scalar parameters in DEFAULT_COSTS are user-editable overrides (`overrides` argument, or diagram pf_settings keys `cost_<name>`).

Public API: effective_costs, row_cost_detail, cost_basis, context_for, reference_unit_costs."""
import math

COST_YEAR = 2024
CURRENCY = "USD"
ACCURACY = "AACE class 5 budgetary estimate (about -30 % / +50 %)"
SETTING_PREFIX = "cost_"

# name: (default, unit, label)
PARAMETERS = {
    "regional_factor": (1.0, "x", "Regional / labour multiplier on every cost"),
    "engineering_pct": (8.0, "% of direct", "Engineering, procurement and project management"),
    "contingency_pct": (20.0, "% of direct", "Contingency (planning-grade scope uncertainty)"),
    "transformer_k_usd": (37700.0, "USD / MVA^exp", "Transformer equipment coefficient k (33 kV class: cost = k x MVA^exponent)"),
    "transformer_exponent": (0.72, "-", "Transformer size exponent (economy of scale)"),
    "transformer_install_pct": (30.0, "% of equipment", "Transformer installation: rigging, oil, foundation, removal of old unit, tests"),
    "transformer_fixed_usd": (100000.0, "USD (33 kV class, >= 10 MVA)", "Transformer protection, SCADA, bay modification, commissioning"),
    "oltc_fixed_usd": (60000.0, "USD", "On-load tap-changer retrofit: fixed part"),
    "oltc_usd_per_mva": (3000.0, "USD / MVA", "On-load tap-changer retrofit: size-dependent part"),
    "capacitor_fixed_usd": (40000.0, "USD (11 kV class)", "Capacitor bank fixed scope: switching device, protection, controller, pad, fence"),
    "capacitor_variable_usd_per_kvar": (9.0, "USD / kvar", "Capacitor bank variable cost (units, racks, installation)"),
    "reactor_fixed_usd": (60000.0, "USD (11 kV class)", "Shunt reactor fixed scope: switching device, protection, pad"),
    "reactor_variable_usd_per_kvar": (14.0, "USD / kvar", "Shunt reactor variable cost"),
    "reactive_fixed_usd": (15000.0, "USD", "Reactive-capability upgrade: studies, grid-code re-certification, model validation"),
    "reactive_variable_usd_per_kvar": (45.0, "USD / kvar", "Larger inverter / machine reactive capability, per kvar of added Q range"),
    "overhead_reconductor_scale": (1.0, "x", "Multiplier on the overhead re-conductor $/km table"),
    "overhead_circuit_scale": (1.0, "x", "Multiplier on the new overhead circuit $/km table"),
    "cable_scale": (1.0, "x", "Multiplier on the underground cable circuit $/km table"),
}
DEFAULT_COSTS = {k: v[0] for k, v in PARAMETERS.items()}
SETTING_KEYS = {SETTING_PREFIX + k for k in PARAMETERS}

CLASSES = (11, 22, 33, 66, 132, 220)  # nominal kV classes of the tables below (limits: <=15, 24, 36, 72.5, 145, 245 kV)
_LIMITS = (15.0, 24.0, 36.0, 72.5, 145.0, 245.0)
TRANSFORMER_CLASS = dict(zip(CLASSES, (0.85, 0.95, 1.0, 1.2, 1.5, 2.0)))       # equipment, relative to 33 kV
TRANSFORMER_FIXED_CLASS = dict(zip(CLASSES, (0.6, 0.8, 1.0, 1.5, 2.5, 4.0)))   # bay / protection scope
SHUNT_FIXED_CLASS = dict(zip(CLASSES, (1.0, 1.1, 1.2, 1.7, 2.4, 3.4)))
SHUNT_VARIABLE_CLASS = dict(zip(CLASSES, (1.0, 1.0, 1.05, 1.2, 1.35, 1.6)))
LINE_REFERENCE_MVA = dict(zip(CLASSES, (8.0, 20.0, 30.0, 70.0, 180.0, 380.0)))  # typical rating the $/km tables refer to
RECONDUCTOR_USD_PER_KM = dict(zip(CLASSES, (70e3, 90e3, 120e3, 200e3, 340e3, 520e3)))
OVERHEAD_CIRCUIT_USD_PER_KM = dict(zip(CLASSES, (140e3, 190e3, 260e3, 420e3, 750e3, 1.1e6)))
CABLE_CIRCUIT_USD_PER_KM = dict(zip(CLASSES, (350e3, 450e3, 600e3, 1.0e6, 2.2e6, 3.5e6)))
LINE_BAY_USD = dict(zip(CLASSES, (120e3, 180e3, 250e3, 450e3, 900e3, 1.5e6)))   # feeder bay incl. breaker and protection
RECONDUCTOR_MAX_RATIO = 2.0   # above this rating ratio an overhead upgrade is a new parallel circuit, not a re-conductor
OLTC_FREE_TAP = 0.05          # off-load taps cover +-5 %; a larger shift needs an on-load tap changer
LEAD_TIME_MONTHS = {"Power transformer": "18-30", "Shunt capacitor bank": "6-9", "Shunt reactor": "10-16",
                    "Re-conductor / overhead circuit": "12-24", "Underground cable circuit": "18-30",
                    "Inverter / machine reactive capability": "6-12", "On-load tap-changer retrofit": "9-15"}
SOURCES = [
    "MISO Transmission Cost Estimation Guide for MTEP23 (2023 USD; substation and line unit costs, 5 % escalation).",
    "CAISO Participating Transmission Owner Per Unit Cost Guides 2023 (shunt capacitor, reactor, re-conductor, cable).",
    "PJM RTEP project cost data (Form A-3 estimates) for transformer and substation scopes.",
    "NREL Annual Technology Baseline and EPRI utility cost studies for inverter and reactive-power equipment.",
]


def effective_costs(overrides=None):
    """DEFAULT_COSTS merged with the user's overrides (keys with or without the 'cost_' prefix).  Raises ValueError on bad input."""
    out = dict(DEFAULT_COSTS)
    for key, value in (overrides or {}).items():
        name = key[len(SETTING_PREFIX):] if key.startswith(SETTING_PREFIX) else key
        if name not in PARAMETERS:
            raise ValueError(f"Unknown cost parameter '{key}'.")
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError(f"Cost parameter '{key}' must be a finite number >= 0.")
        out[name] = float(value)
    return out


def overrides_from_settings(settings):
    """The cost overrides stored in a diagram's pf_settings (flat 'cost_<name>' numbers); unusable entries are ignored."""
    found = {}
    for key, value in (settings or {}).items():
        if key in SETTING_KEYS and isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0:
            found[key[len(SETTING_PREFIX):]] = float(value)
    return found


def voltage_class(kv):
    """Nominal class (11/22/33/66/132/220 kV) for a bus voltage in kV; LV and unknown voltages use the 11 kV class."""
    if not kv or kv <= 0:
        return CLASSES[0]
    return next((c for c, limit in zip(CLASSES, _LIMITS) if kv <= limit), CLASSES[-1])


def _usd(value):
    return f"${value:,.0f}"


def _finish(direct, p, parts, what):
    eng, cont = direct * p["engineering_pct"] / 100.0, direct * p["contingency_pct"] / 100.0
    total = (direct + eng + cont) * p["regional_factor"]
    basis = (f"{what}: {parts}; engineering {p['engineering_pct']:g} % + contingency {p['contingency_pct']:g} %"
             + (f"; regional factor {p['regional_factor']:g}" if p["regional_factor"] != 1.0 else "") + f" ({COST_YEAR} {CURRENCY})")
    return dict(cost_usd=round(total, 0), direct_usd=round(direct * p["regional_factor"], 0), engineering_usd=round(eng * p["regional_factor"], 0),
                contingency_usd=round(cont * p["regional_factor"], 0), basis=basis)


def transformer_cost(mva, hv_kv, p, oltc=False):
    """Replacement power transformer of `mva` MVA and high-side voltage `hv_kv` (optionally with the on-load tap-changer retrofit)."""
    cls = voltage_class(hv_kv)
    equipment = p["transformer_k_usd"] * max(mva, 0.01) ** p["transformer_exponent"] * TRANSFORMER_CLASS[cls]
    install = equipment * p["transformer_install_pct"] / 100.0
    fixed = p["transformer_fixed_usd"] * TRANSFORMER_FIXED_CLASS[cls] * min(1.0, math.sqrt(max(mva, 0.01) / 10.0))
    direct = equipment + install + fixed
    parts = f"equipment {_usd(equipment)} + installation {_usd(install)} + protection/commissioning {_usd(fixed)}"
    if oltc:
        extra = p["oltc_fixed_usd"] + p["oltc_usd_per_mva"] * mva
        direct += extra
        parts += f" + OLTC {_usd(extra)}"
    return _finish(direct, p, parts, f"{mva:,.4g} MVA {voltage_class(hv_kv)} kV-class transformer (replacement)")


def oltc_cost(mva, p):
    extra = p["oltc_fixed_usd"] + p["oltc_usd_per_mva"] * mva
    return _finish(extra, p, f"tap-changer {_usd(extra)}", f"On-load tap-changer retrofit on a {mva:,.4g} MVA transformer")


def shunt_cost(mvar, kv, p, reactor=False, extension=False):
    """Switched capacitor bank (or reactor) of `mvar` Mvar at `kv`; extension=True adds steps to an existing bank (half the fixed scope)."""
    cls = voltage_class(kv)
    fixed = p["reactor_fixed_usd" if reactor else "capacitor_fixed_usd"] * SHUNT_FIXED_CLASS[cls] * (0.5 if extension else 1.0)
    variable = p["reactor_variable_usd_per_kvar" if reactor else "capacitor_variable_usd_per_kvar"] * SHUNT_VARIABLE_CLASS[cls] * mvar * 1000.0
    name = "shunt reactor" if reactor else "capacitor bank"
    return _finish(fixed + variable, p, f"fixed scope {_usd(fixed)} + {_usd(variable)} for {mvar * 1000:,.0f} kvar",
                   f"{mvar:,.4g} Mvar {cls} kV-class {name}")


def reactive_capability_cost(mvar, p):
    fixed, variable = p["reactive_fixed_usd"], p["reactive_variable_usd_per_kvar"] * mvar * 1000.0
    return _finish(fixed + variable, p, f"studies/certification {_usd(fixed)} + {_usd(variable)} for {mvar * 1000:,.0f} kvar",
                   f"{mvar:,.4g} Mvar of added reactive capability")


def line_cost(old_mva, new_mva, kv, length_km, line_type, p):
    """Upgrade of a line from old_mva to new_mva.  Overhead up to 2x: re-conductor on existing structures; beyond that, or for a cable,
    a new parallel circuit sized for the added MVA with two feeder bays.  $/km scales with (rating/class rating)^0.4 (0.6-2.0)."""
    cls = voltage_class(kv)
    length = max(float(length_km or 0.0), 0.1)
    added = max(new_mva - old_mva, 0.0)
    cable = line_type == "cable"
    if not cable and old_mva > 0 and new_mva <= RECONDUCTOR_MAX_RATIO * old_mva + 1e-9:
        size = min(max((new_mva / LINE_REFERENCE_MVA[cls]) ** 0.4, 0.6), 2.0)
        per_km = RECONDUCTOR_USD_PER_KM[cls] * p["overhead_reconductor_scale"] * size
        bays = 0.4 * LINE_BAY_USD[cls]
        what = f"{length:,.4g} km re-conductor to {new_mva:,.4g} MVA"
        parts = f"{_usd(per_km)}/km x {length:,.4g} km + relay/terminal rework {_usd(bays)}"
    else:
        size = min(max((added / LINE_REFERENCE_MVA[cls]) ** 0.4, 0.6), 2.0)
        table, scale = (CABLE_CIRCUIT_USD_PER_KM, p["cable_scale"]) if cable else (OVERHEAD_CIRCUIT_USD_PER_KM, p["overhead_circuit_scale"])
        per_km = table[cls] * scale * size
        bays = 2.0 * LINE_BAY_USD[cls]
        what = f"{length:,.4g} km new parallel {'cable' if cable else 'overhead'} circuit for +{added:,.4g} MVA"
        parts = f"{_usd(per_km)}/km x {length:,.4g} km + 2 feeder bays {_usd(bays)}"
    return _finish(per_km * length + bays, p, parts, f"{cls} kV-class {what}")


def context_for(net, row):
    """What the cost model needs to know about the network around a suggestion row (kv, branch kind, type, length), JSON-safe."""
    target = row.get("target") or {}
    kind, ident = target.get("kind"), target.get("id")
    try:
        if kind == "line":
            br = next(b for b in net.branches if b["id"] == ident)
            kv_f, kv_t = net.buses[br["f"]]["kv"], net.buses[br["t"]]["kv"]
            return dict(branch_kind=br["kind"], hv_kv=max(kv_f, kv_t), lv_kv=min(kv_f, kv_t), length_km=br.get("length_km") or 0.0,
                        line_type=br.get("type"), circuits=br.get("circuits", 1))
        if kind == "node":
            return dict(kv=net.bus(ident)["kv"])
    except (StopIteration, KeyError, IndexError, TypeError):
        pass
    return {}


def row_cost_detail(row, overrides=None):
    """dict(cost_usd, basis, direct_usd, engineering_usd, contingency_usd) for one suggestion row, or None when it has no equipment cost."""
    p = effective_costs(overrides)
    target, ctx = row.get("target") or {}, row.get("cost_inputs") or {}
    kind, key = target.get("kind"), target.get("key")
    cur = row.get("current") or 0.0
    suggested = float(row["suggested"])
    if kind == "node" and key == "shunt_mvar":
        added_cap, added_rea = max(suggested, 0.0) - max(cur, 0.0), min(suggested, 0.0) - min(cur, 0.0)
        kv = ctx.get("kv") or 11.0
        if added_rea < -1e-9 and added_cap <= 1e-9:
            return shunt_cost(-added_rea, kv, p, reactor=True, extension=cur < -1e-9)
        if added_cap > 1e-9:
            return shunt_cost(added_cap, kv, p, extension=cur > 1e-9)
        return None
    if kind == "node" and key in ("q_max_mvar", "q_min_mvar"):
        return reactive_capability_cost(abs(suggested - cur), p)
    if kind == "line" and key == "mva":
        return transformer_cost(suggested, ctx.get("hv_kv") or 33.0, p)
    if kind == "line" and key == "rating_mva":
        if suggested <= cur:
            return None
        return line_cost(cur, suggested, ctx.get("hv_kv") or 33.0, ctx.get("length_km"), ctx.get("line_type") or "overhead", p)
    if kind == "line" and key == "tap" and abs(suggested - 1.0) > OLTC_FREE_TAP + 1e-9 and ctx.get("mva"):
        return oltc_cost(ctx["mva"], p)
    return None


def reference_unit_costs(overrides=None):
    """Flat all-in reference unit costs at a typical size (for BOQs and one-line summaries); the real cost is size-dependent."""
    p = effective_costs(overrides)
    return dict(
        capacitor_usd_per_kvar=round(shunt_cost(10.0, 11.0, p)["cost_usd"] / 10000.0, 2),
        reactor_usd_per_kvar=round(shunt_cost(10.0, 11.0, p, reactor=True)["cost_usd"] / 10000.0, 2),
        transformer_usd_per_mva=round(transformer_cost(63.0, 33.0, p)["cost_usd"] / 63.0, 0),
        line_upgrade_usd_per_mva=round(line_cost(30.0, 40.0, 33.0, 10.0, "overhead", p)["cost_usd"] / 10.0, 0),
        reactive_capability_usd_per_kvar=round(reactive_capability_cost(2.0, p)["cost_usd"] / 2000.0, 2))


def cost_basis(overrides=None):
    """The visible 'Cost basis' note/table: year, currency, accuracy, method, sources, editable parameters, class tables, examples."""
    p = effective_costs(overrides)
    used = effective_costs(overrides)
    examples = [
        ("63 MVA 33/11 kV transformer swap", transformer_cost(63.0, 33.0, p)),
        ("25 MVA 33/11 kV transformer swap", transformer_cost(25.0, 33.0, p)),
        ("10 MVA 11/0.4 kV transformer swap", transformer_cost(10.0, 11.0, p)),
        ("100 MVA 132/33 kV transformer swap", transformer_cost(100.0, 132.0, p)),
        ("9.6 Mvar 11 kV capacitor bank", shunt_cost(9.6, 11.0, p)),
        ("30 Mvar 132 kV capacitor bank", shunt_cost(30.0, 132.0, p)),
        ("10 Mvar 11 kV shunt reactor", shunt_cost(10.0, 11.0, p, reactor=True)),
        ("10 km 33 kV overhead re-conductor 25 -> 40 MVA", line_cost(25.0, 40.0, 33.0, 10.0, "overhead", p)),
        ("5 km 33 kV cable circuit, +20 MVA", line_cost(30.0, 50.0, 33.0, 5.0, "cable", p))]
    return dict(
        year=COST_YEAR, currency=CURRENCY, accuracy=ACCURACY, sources=list(SOURCES),
        method=("cost = (equipment x (1 + installation) + fixed scope) x (1 + engineering + contingency) x regional factor; equipment cost "
                "follows k x MVA^exponent so the cost per MVA falls with size; fixed scopes and $/km depend on the voltage class."),
        scope=("Installed, in place of an existing unit/line where applicable: foundations, protection, SCADA and commissioning included; "
               "land, outage and financing costs, utility network-reinforcement charges and taxes are excluded."),
        note="Planning-grade estimates, not quotes: replace with utility or vendor prices (edit the parameters below).",
        parameters=[dict(key=k, setting_key=SETTING_PREFIX + k, label=v[2], unit=v[1], default=v[0], value=used[k], user_set=used[k] != v[0])
                    for k, v in PARAMETERS.items()],
        voltage_classes_kv=list(CLASSES),
        tables=dict(transformer_class_factor=dict(TRANSFORMER_CLASS), transformer_fixed_class_factor=dict(TRANSFORMER_FIXED_CLASS),
                    shunt_fixed_class_factor=dict(SHUNT_FIXED_CLASS), shunt_variable_class_factor=dict(SHUNT_VARIABLE_CLASS),
                    reconductor_usd_per_km=dict(RECONDUCTOR_USD_PER_KM), overhead_circuit_usd_per_km=dict(OVERHEAD_CIRCUIT_USD_PER_KM),
                    cable_circuit_usd_per_km=dict(CABLE_CIRCUIT_USD_PER_KM), line_bay_usd=dict(LINE_BAY_USD),
                    line_reference_mva=dict(LINE_REFERENCE_MVA)),
        lead_time_months=dict(LEAD_TIME_MONTHS),
        examples=[dict(item=name, cost_usd=d["cost_usd"], basis=d["basis"]) for name, d in examples],
        reference_unit_costs=reference_unit_costs(overrides))
