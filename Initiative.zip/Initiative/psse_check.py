"""Load RAW files in PSS/E, run every topology/consistency check and solve with FNSL; prints a JSON summary.

Usage: py -3 psse_check.py [--details] file.raw [...]

PSS/E 35 (Python 3.11) or PSS/E 36 (Python 3.14) is used, whichever matches the interpreter; from any other interpreter the
check is delegated to the PSS/E 35 Python 3.11 installation in a subprocess.  An entry is `ok` when the RAW read cleanly, PSS/E
found no swing-less island, the series-element/bus-type check passed, FNSL converged and PSS/E printed no message other than the
routine progress lines (so any ERROR, WARNING or inconsistency note makes the file not ok).  With details the solved bus
voltages, branch flows and machine outputs are returned for comparison with the GenStudio power flow."""
import contextlib
import io
import json
import os
import re
import subprocess
import sys

INSTALLS = (
    dict(home=r"C:\Program Files\PTI\PSSE35\35.6", pydir="PSSPY311", python=(3, 11),
         exe=r"C:\Users\SA6205\AppData\Local\Programs\Python\Python311\python.exe"),
    dict(home=r"C:\Program Files\PTI\PSSE36\36.5", pydir="PSSPY314", python=(3, 14), exe=None),
)
ROUTINE = re.compile(
    r"^(Starting|Finished) processing|^Converting RAW data|^Reading |^\*\* NON-TRANSFORMER BRANCH PERCENT LOADING|^SWING BUSES:|"
    r"^BUS#-SCT|^ISLAND:|^\*\* NONE \*\*|^Ordering network|^Diagonals =|^ITER |^\d|^Reached tolerance|^Largest mismatch|"
    r"^System total absolute mismatch|^SWING BUS SUMMARY")


def _install():
    for item in INSTALLS:
        if os.path.isdir(os.path.join(item["home"], item["pydir"])) and sys.version_info[:2] == item["python"]:
            return item
    return None


def available():
    """True when RAW files can be checked (in this interpreter or through the PSS/E 35 Python 3.11 subprocess)."""
    return _install() is not None or os.path.isfile(INSTALLS[0]["exe"]) and os.path.isdir(INSTALLS[0]["home"])


def check(paths, details=False):
    """List of dicts, one per RAW file (see module docstring)."""
    if _install() is None:
        command = [INSTALLS[0]["exe"], os.path.abspath(__file__)] + (["--details"] if details else []) + [os.path.abspath(p) for p in paths]
        done = subprocess.run(command, capture_output=True, text=True, timeout=1800)
        start = done.stdout.find("\n[")
        start = 0 if done.stdout.lstrip().startswith("[") else start
        if done.returncode or start < 0:
            raise RuntimeError(f"PSS/E check failed: {done.stderr[-2000:] or done.stdout[-2000:]}")
        return json.loads(done.stdout[start:])
    return _check_in_process(paths, details)


def _check_in_process(paths, details):
    install = _install()
    home, pydir = install["home"], os.path.join(install["home"], install["pydir"])
    sys.path[:0] = [pydir, os.path.join(home, "PSSBIN")]
    for folder in (os.path.join(home, "PSSBIN"), pydir):
        os.add_dll_directory(folder)
    os.environ["PATH"] = os.path.join(home, "PSSBIN") + os.pathsep + os.environ.get("PATH", "")
    banner = io.StringIO()
    with contextlib.redirect_stdout(banner):
        import psspy
        import redirect
        redirect.psse2py()
        psspy.psseinit(10000)
    out = []
    for path in paths:
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            entry = _check_one(psspy, path, details)
        entry["messages"] = [m.strip() for m in buffer.getvalue().splitlines() if m.strip() and not ROUTINE.match(m.strip())]
        entry["ok"] = (entry.get("read_ierr") == 0 and entry.get("buses", 0) > 0 and entry.get("swingless_buses") == 0 and
                       entry.get("fnsl_ierr") == 0 and entry.get("not_converged_code") == 0 and not entry["messages"])
        out.append(entry)
    return out


def _check_one(psspy, path, details):
    psspy.newcase_2([0, 1], 100.0, 60.0, "", "")
    entry = dict(file=os.path.basename(path), read_ierr=psspy.readrawversion(1, "33", path))
    if entry["read_ierr"]:
        return entry
    entry["buses"] = len(psspy.abusint(-1, 1, "NUMBER")[1][0])
    entry["machines"] = len(psspy.amachint(-1, 1, "NUMBER")[1][0])
    entry["loads"] = len(psspy.aloadint(-1, 1, "NUMBER")[1][0])
    entry["branches"] = len(psspy.abrnint(-1, 1, 1, 1, 1, "FROMNUMBER")[1][0])
    entry["swingless_buses"] = psspy.tree(1, 1)[1]
    if entry["swingless_buses"]:
        psspy.tree(2, 1)
    if entry["swingless_buses"] == 0:
        entry["fnsl_ierr"] = psspy.fnsl([0, 0, 0, 1, 1, 0, 0, 0])
        entry["not_converged_code"] = psspy.solved()
        entry["mismatch_mva"] = psspy.maxmsm()[1] if hasattr(psspy, "maxmsm") else None
    if details and entry.get("not_converged_code") == 0:
        entry.update(_details(psspy))
    return entry


def _details(psspy):
    num = psspy.abusint(-1, 1, "NUMBER")[1][0]
    vm = psspy.abusreal(-1, 1, "PU")[1][0]
    va = psspy.abusreal(-1, 1, "ANGLED")[1][0]
    kind = psspy.abusint(-1, 1, "TYPE")[1][0]
    frm = psspy.abrnint(-1, 1, 1, 1, 1, "FROMNUMBER")[1][0]
    to = psspy.abrnint(-1, 1, 1, 1, 1, "TONUMBER")[1][0]
    status = psspy.abrnint(-1, 1, 1, 1, 1, "STATUS")[1][0]
    ckt = psspy.abrnchar(-1, 1, 1, 1, 1, "ID")[1][0]
    flow = psspy.abrncplx(-1, 1, 1, 1, 1, "PQ")[1][0]
    loss = psspy.abrncplx(-1, 1, 1, 1, 1, "PQLOSS")[1][0]
    mbus = psspy.amachint(-1, 1, "NUMBER")[1][0]
    mp = psspy.amachreal(-1, 1, "PGEN")[1][0]
    mq = psspy.amachreal(-1, 1, "QGEN")[1][0]
    mqmax = psspy.amachreal(-1, 1, "QMAX")[1][0]
    mqmin = psspy.amachreal(-1, 1, "QMIN")[1][0]
    mbase = psspy.amachreal(-1, 1, "MBASE")[1][0]
    mpmax = psspy.amachreal(-1, 1, "PMAX")[1][0]
    branch = [dict(from_=f, to=t, ckt=c.strip(), status=s, p=z.real, q=z.imag, loss_p=l.real, loss_q=l.imag)
              for f, t, c, s, z, l in zip(frm, to, ckt, status, flow, loss)]
    tf = psspy.atrnint(-1, 1, 1, 1, 1, "WIND1NUMBER")[1][0]
    tt = psspy.atrnint(-1, 1, 1, 1, 1, "WIND2NUMBER")[1][0]
    tc = psspy.atrnchar(-1, 1, 1, 1, 1, "ID")[1][0]
    ts = psspy.atrnint(-1, 1, 1, 1, 1, "STATUS")[1][0]
    tflow = psspy.atrncplx(-1, 1, 1, 1, 1, "PQ")[1][0]
    tloss = psspy.atrncplx(-1, 1, 1, 1, 1, "PQLOSS")[1][0]
    # atrn* reports each transformer at its lower-numbered bus whatever the winding order, so label the ends that way.
    branch += [dict(from_=min(f, t), to=max(f, t), ckt=c.strip(), status=s, p=z.real, q=z.imag, loss_p=l.real, loss_q=l.imag,
                    transformer=True)
               for f, t, c, s, z, l in zip(tf, tt, tc, ts, tflow, tloss)]
    return dict(
        bus=[dict(number=n, vm=a, va=b, type=t) for n, a, b, t in zip(num, vm, va, kind)],
        branch=branch,
        machine=[dict(bus=b, p=p, q=q, qmax=a, qmin=c, mbase=m, pmax=x) for b, p, q, a, c, m, x in zip(mbus, mp, mq, mqmax, mqmin, mbase, mpmax)])


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--details"]
    print(json.dumps(check(args, "--details" in sys.argv), indent=1))
