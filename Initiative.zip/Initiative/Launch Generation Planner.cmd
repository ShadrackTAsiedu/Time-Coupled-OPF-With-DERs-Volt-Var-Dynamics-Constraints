@echo off
rem Kept for existing shortcuts; GenStudio.cmd is the launcher.
call "%~dp0GenStudio.cmd" %*
