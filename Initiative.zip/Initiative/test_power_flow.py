import csv
import json
import math
import shutil
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

import extensions
import power_flow as pf

HERE = Path(__file__).resolve().parent
SCRATCH = HERE / "test_power_flow_scratch"


def diagram(nodes, lines):
    return dict(enabled=False,
                nodes=[dict(id=i, kind=k, label=i, x=100 + 100 * n, y=100) for n, (i, k) in enumerate(nodes)],
                lines=[dict(id=i, source=a, target=b, owner="shared", length_km=km, cost_per_km=0) for i, a, b, km in lines])


def same_kv(ids, kv=11.0, **extra):
    return {i: dict(kv=kv, **extra.get(i, {})) for i in ids}


BIG_GRID = dict(sc_mva=1e7, xr=10)


def feeder(km=2.0, parallel=False, line_over=None, gen=None):
    nodes = [("g", "grid"), ("l", "load")] + ([("pv", "pv")] if gen else [])
    lines = [("w1", "g", "l", km)] + ([("w2", "g", "l", km)] if parallel else []) + ([("w3", "pv", "l", 0)] if gen else [])
    over = dict(r_ohm_km=0.5, x_ohm_km=0.0001)
    over.update(line_over or {})
    nodes_over = same_kv([n for n, _ in nodes])
    nodes_over["g"].update(BIG_GRID)
    return pf.build_network(diagram(nodes, lines), caps={"pv": gen} if gen else {}, assumptions=dict(
        nodes=nodes_over, lines={"w1": over, "w2": dict(over)}), peak_load_mw=5.0)


class NewtonTests(unittest.TestCase):
    def test_two_bus_analytic(self):
        x, p = 0.1, 1.0
        Y = np.array([[1 / (1j * x), -1 / (1j * x)], [-1 / (1j * x), 1 / (1j * x)]])
        V, ok, _, _ = pf.newton_solve(Y, np.ones(2, complex), np.array([0, -p], complex), np.array([2, 0]))
        self.assertTrue(ok)
        self.assertAlmostEqual(abs(V[1]) ** 2, 0.5 + math.sqrt(0.25 - (x * p) ** 2), places=8)
        current = (V[0] - V[1]) / (1j * x)
        self.assertAlmostEqual(abs(V[1] * np.conj(current) - p), 0, places=7)

    def test_overloaded_line_does_not_converge(self):
        x = 0.1  # maximum transferable power at unity pf is 1/(2x) = 5 pu
        Y = np.array([[1 / (1j * x), -1 / (1j * x)], [-1 / (1j * x), 1 / (1j * x)]])
        V, ok, _, _ = pf.newton_solve(Y, np.ones(2, complex), np.array([0, -6.0], complex), np.array([2, 0]))
        self.assertFalse(ok)


class NetworkTests(unittest.TestCase):
    def test_radial_feeder_voltage_drop(self):
        net = feeder(km=2.0)
        case = pf.solve_case(net, dict(load_mw=1.0, gens={}))
        self.assertTrue(case["converged"])
        r = 0.5 * 2.0 / (11.0 ** 2 / 100.0)
        # load pf 0.95 lagging: R*P + X*Q drop with X ~ 0
        expected = (1 + math.sqrt(1 - 4 * r * 0.01)) / 2
        v_load = next(b for b in case["buses"] if b["id"] == "l")["vm"]
        self.assertAlmostEqual(v_load, expected, delta=2e-4)
        self.assertLess(v_load, 1.0)

    def test_loss_balance(self):
        net = feeder(km=3.0, gen=1.5)
        case = pf.solve_case(net, dict(load_mw=3.0, gens={"pv": dict(p=1.5)}))
        self.assertTrue(case["converged"])
        self.assertAlmostEqual(case["slack_mw"], 3.0 - 1.5 + case["losses_mw"], places=3)
        expected_loss = sum(b["loss_mw"] for b in case["branches"])
        self.assertAlmostEqual(case["losses_mw"], expected_loss, places=4)
        self.assertGreater(case["losses_mw"], 0)

    def test_line_loading_is_current_based_and_transformer_loading_is_mva(self):
        net = feeder(km=6.0, line_over=dict(rating_mva=3.0))
        case = pf.solve_case(net, dict(load_mw=2.6, gens={}))
        self.assertTrue(case["converged"])
        w1 = next(b for b in case["branches"] if b["id"] == "w1")
        v_load = next(b for b in case["buses"] if b["id"] == "l")["vm"]
        self.assertLess(v_load, 0.98)
        sending = math.hypot(w1["p_from_mw"], w1["q_from_mvar"])
        receiving = math.hypot(w1["p_to_mw"], w1["q_to_mvar"])
        v_send = next(b for b in case["buses"] if b["id"] == "g")["vm"]
        expected = max(sending / v_send, receiving / v_load) / 3.0 * 100
        self.assertAlmostEqual(w1["loading_pct"], expected, delta=0.01)
        self.assertGreater(w1["loading_pct"], receiving / 3.0 * 100 + 1)
        diag = diagram([("g", "grid"), ("l", "load")], [("t", "g", "l", 0)])
        tnet = pf.build_network(diag, assumptions=dict(nodes=dict(g=dict(kv=33.0, **BIG_GRID), l=dict(kv=11.0)),
                                                       lines=dict(t=dict(mva=3.0))), peak_load_mw=2.6)
        tcase = pf.solve_case(tnet, dict(load_mw=2.6, gens={}))
        tr = next(b for b in tcase["branches"] if b["id"] == "t")
        self.assertAlmostEqual(tr["loading_pct"], max(math.hypot(tr["p_from_mw"], tr["q_from_mvar"]),
                                                      math.hypot(tr["p_to_mw"], tr["q_to_mvar"])) / 3.0 * 100, delta=0.01)

    def test_voltage_violation_message_prints_four_decimals(self):
        net = feeder(km=8.0, line_over=dict(rating_mva=50.0))
        case = pf.solve_case(net, dict(load_mw=4.0, gens={}))
        low = [v for v in pf.evaluate(net, case) if v["type"] == "voltage_low"]
        self.assertTrue(low)
        self.assertRegex(low[0]["message"], r"voltage \d\.\d{4} pu is below \d\.\d{4} pu")

    def test_reverse_flow_direction(self):
        net = feeder(km=2.0, gen=4.0)
        case = pf.solve_case(net, dict(load_mw=1.0, gens={"pv": dict(p=4.0)}))
        w1 = next(b for b in case["branches"] if b["id"] == "w1")
        self.assertLess(w1["p_from_mw"], 0)  # exports to the grid
        self.assertLess(case["slack_mw"], 0)

    def test_transformer_tap_effect(self):
        diag = diagram([("g", "grid"), ("l", "load")], [("t", "g", "l", 0)])

        def run(tap):
            net = pf.build_network(diag, assumptions=dict(nodes=dict(g=dict(kv=33.0, **BIG_GRID), l=dict(kv=11.0)),
                                                         lines=dict(t=dict(tap=tap, mva=20))), peak_load_mw=2.0)
            case = pf.solve_case(net, dict(load_mw=2.0, gens={}))
            self.assertTrue(case["converged"])
            return next(b for b in case["buses"] if b["id"] == "l")["vm"]
        v1, v2 = run(1.0), run(1.05)
        self.assertAlmostEqual(v2 / v1, 1 / 1.05, delta=0.004)
        self.assertEqual(net_kind(diag), "transformer")

    def test_n1_islanding_and_redundancy(self):
        radial = feeder()
        case = pf.solve_case(radial, dict(load_mw=1.0, gens={}), outages=["w1"])
        self.assertTrue(any(not i["energized"] for i in case["islands"]))
        self.assertAlmostEqual(case["unserved_mw"], 1.0, places=4)
        types = [v["type"] for v in pf.evaluate(radial, case, emergency=True)]
        self.assertIn("islanded", types)
        double = feeder(parallel=True)
        ok = pf.solve_case(double, dict(load_mw=1.0, gens={}), outages=["w1"])
        self.assertAlmostEqual(ok["unserved_mw"], 0.0, places=6)
        self.assertEqual(pf.evaluate(double, ok, emergency=True), [])

    def test_overloaded_network_reports_nonconvergence(self):
        net = feeder(km=5.0)
        case = pf.solve_case(net, dict(load_mw=200.0, gens={}))
        self.assertFalse(case["converged"])
        self.assertIn("non_convergence", [v["type"] for v in pf.evaluate(net, case)])

    def test_thermal_violation(self):
        net = feeder(km=0.5, line_over=dict(r_ohm_km=0.05, x_ohm_km=0.1, rating_mva=2.0))
        case = pf.solve_case(net, dict(load_mw=3.0, gens={}))
        self.assertIn("thermal", [v["type"] for v in pf.evaluate(net, case)])

    def test_islanded_microgrid_uses_bess_as_slack(self):
        diag = diagram([("b", "bess"), ("l", "load"), ("pv", "pv")], [("w1", "b", "l", 0.5), ("w2", "pv", "l", 0)])
        net = pf.build_network(diag, caps=dict(bess=5.0, pv=4.0), assumptions=dict(nodes=same_kv(["b", "l", "pv"])),
                               islanded=True, peak_load_mw=4.0)
        case = pf.solve_case(net, dict(load_mw=4.0, gens={"pv": dict(p=3.0), "bess": dict(p=0.0)}))
        self.assertTrue(case["converged"])
        bess = next(b for b in case["buses"] if b["id"] == "b")
        self.assertTrue(bess["slack"])
        self.assertAlmostEqual(bess["gen_mw"], 4.0 - 3.0 + case["losses_mw"], places=3)

    def test_unconnected_load_is_warned(self):
        diag = diagram([("pv", "pv"), ("l", "load"), ("g", "grid"), ("l2", "load")],
                       [("w1", "pv", "l", 0.2), ("w2", "g", "l2", 0.2)])
        net = pf.build_network(diag, caps=dict(pv=2.0), assumptions=dict(nodes=same_kv(["pv", "l", "g", "l2"])), peak_load_mw=2.0)
        self.assertTrue(any("not connected" in w for w in net.warnings))

    def test_user_errors(self):
        with self.assertRaises(ValueError):
            pf.build_network(diagram([("g", "grid"), ("b", "bus")], [("w", "g", "b", 1)]))  # no load
        with self.assertRaises(ValueError):
            pf.build_network(diagram([("g", "grid"), ("l", "load")], [("w", "g", "l", 1)]),
                             assumptions=dict(nodes=dict(g=dict(kv=33.0), l=dict(kv=11.0)), lines=dict(w=dict(kind="line"))))
        with self.assertRaises(ValueError):
            pf.build_network(diagram([("g", "grid"), ("l", "load")], [("w", "g", "l", 1)]),
                             assumptions=dict(nodes=dict(zzz=dict(kv=11.0))))
        with self.assertRaises(ValueError):
            pf.build_network(diagram([("pv", "pv"), ("l", "load")], [("w", "pv", "l", 1)]))  # no source at all

    def test_zero_length_ties_are_fine(self):
        diag = diagram([("g", "grid"), ("b", "bus"), ("l", "load")], [("w1", "g", "b", 0), ("w2", "b", "l", 0)])
        net = pf.build_network(diag, assumptions=dict(nodes=same_kv(["g", "b", "l"])), peak_load_mw=1.0)
        case = pf.solve_case(net, dict(load_mw=1.0, gens={}))
        self.assertTrue(case["converged"])
        self.assertAlmostEqual(case["slack_mw"], 1.0, places=2)

    def test_pv_voltage_control_respects_q_limit(self):
        diag = diagram([("g", "grid"), ("b", "bus"), ("ng", "ng"), ("l", "load")],
                       [("w1", "g", "b", 8), ("w2", "ng", "b", 0), ("w3", "b", "l", 0)])
        over = same_kv(["g", "b", "ng", "l"])
        over["ng"].update(vset=1.04, q_max_mvar=1.0, q_min_mvar=-1.0)
        net = pf.build_network(diag, caps=dict(ng=5.0), assumptions=dict(nodes=over), peak_load_mw=5.0)
        case = pf.solve_case(net, dict(load_mw=5.0, gens={"ng": dict(p=2.0)}))
        node = next(b for b in case["buses"] if b["id"] == "ng")
        self.assertTrue(case["converged"])
        self.assertLessEqual(node["gen_mvar"], 1.0 + 1e-6)

    def test_raw_export_sections(self):
        text = pf.export_raw(feeder(), dict(load_mw=1.0, gens={}))
        for marker in ("END OF BUS DATA", "END OF LOAD DATA", "END OF GENERATOR DATA", "END OF BRANCH DATA",
                       "END OF TRANSFORMER DATA"):
            self.assertIn(marker, text)


def net_kind(diag):
    net = pf.build_network(diag, assumptions=dict(nodes=dict(g=dict(kv=33.0), l=dict(kv=11.0))), peak_load_mw=1.0)
    return next(b["kind"] for b in net.branches if b["id"] == "t")


class ScreeningTests(unittest.TestCase):
    code = "S1"

    def setUp(self):
        shutil.rmtree(SCRATCH, ignore_errors=True)
        SCRATCH.mkdir()

    def tearDown(self):
        shutil.rmtree(SCRATCH, ignore_errors=True)

    def make_run(self, nodes, lines, caps=None):
        run = SCRATCH / ("a" * 32)
        run.mkdir()
        diag = diagram(nodes, lines)
        (run / "status.json").write_text(json.dumps(dict(state="complete", summary=dict(results=[dict(code=self.code)]))))
        (run / "request.json").write_text(json.dumps(dict(topology=dict(enabled=False, nodes=[], lines=[], diagrams={self.code: diag}))))
        (run / "run_configuration.json").write_text(json.dumps(dict(resolved={})))
        caps = caps or dict(pv_dc_mw=4.0, bess_mw=2.0, bess_mwh=8.0, generators_mw={})
        (run / f"result_{self.code}.json").write_text(
            json.dumps(dict(code=self.code, caps=caps, eligible_technologies=["grid", "pv", "bess"])))
        with (run / f"dispatch_{self.code}.csv").open("w", newline="", encoding="utf-8-sig") as stream:
            w = csv.writer(stream)
            w.writerow(["timestamp", "net_load_mw", "grid_peak_mw", "net_served_load_mw", "gross_load_mw", "total_served_load_mw",
                        "grid", "pv", "charge", "discharge", "soc", "gen", "shortfall", "solar_output", "planned_solar_used",
                        "planned_wind_used"])
            for h in range(48):
                load = 3 + 2 * math.sin(h / 24 * 2 * math.pi - 2)
                sun = max(0.0, 4.0 * math.sin((h % 24 - 6) / 12 * math.pi))
                charge = 1.0 if 10 <= h % 24 <= 13 else 0.0
                discharge = 1.5 if 19 <= h % 24 <= 21 else 0.0
                grid = load - sun - discharge + charge
                w.writerow([f"2030-01-{1 + h // 24:02d} {h % 24:02d}:00:00", load, load, load, load, load, grid, sun, charge,
                            discharge, 4.0, 0, 0, sun, 0, 0])
        return run

    def test_pass_status_and_series(self):
        run = self.make_run([("g", "grid"), ("b", "bus"), ("l", "load"), ("pv", "pv"), ("bs", "bess")],
                            [("w1", "g", "b", 0), ("w2", "b", "l", 0), ("w3", "pv", "b", 0), ("w4", "bs", "b", 0)])
        a = dict(nodes=same_kv(["g", "b", "l", "pv", "bs"]))
        report = pf.screen_run(run, self.code, assumptions=a, n1=False)
        self.assertEqual(report["status"], "PASS", [v for c in report["cases"] for v in c["violations"]])
        self.assertGreaterEqual(len(report["cases"]), 8)
        series = pf.series_run(run, self.code, start=0, hours=24, assumptions=a)
        self.assertEqual(len(series["vm"]), 24)
        self.assertEqual(len(series["vm"][0]), len(series["bus_ids"]))
        self.assertEqual(len(series["p_from"][0]), len(series["branch_ids"]))

    def test_fail_and_cuts_with_undersized_line(self):
        run = self.make_run([("g", "grid"), ("b", "bus"), ("l", "load"), ("pv", "pv")],
                            [("w1", "g", "b", 0), ("w2", "b", "l", 0), ("w3", "pv", "b", 3)])
        a = dict(nodes=same_kv(["g", "b", "l", "pv"]), lines=dict(w3=dict(rating_mva=1.0)))
        report = pf.screen_run(run, self.code, assumptions=a)
        self.assertEqual(report["status"], "FAIL")
        types = {c["type"] for c in pf.suggest_cuts(report)}
        self.assertIn("branch_upgrade", types)
        upgrade = next(c for c in report["cuts"] if c["type"] == "branch_upgrade")
        self.assertEqual(upgrade["component"], "w3")
        self.assertGreater(upgrade["limit"], 1.0)
        self.assertIn("max_injection_mw", {c["type"] for c in report["cuts"]})

    def test_n1_warn_for_radial_design(self):
        run = self.make_run([("g", "grid"), ("l", "load")], [("w1", "g", "l", 1.0)])
        report = pf.screen_run(run, self.code, assumptions=dict(nodes=same_kv(["g", "l"]), lines=dict(w1=dict(rating_mva=10.0))))
        self.assertEqual(report["n1_status"], "WARN")
        self.assertEqual(report["status"], "WARN")

    def test_unwired_grid_is_connected_for_the_check(self):
        run = self.make_run([("g", "grid"), ("b", "bus"), ("l", "load"), ("pv", "pv"), ("bs", "bess")],
                            [("w2", "b", "l", 0), ("w3", "pv", "b", 0), ("w4", "bs", "b", 0)])
        a = dict(nodes=same_kv(["g", "b", "l", "pv", "bs"]))
        report = pf.screen_run(run, self.code, assumptions=a, n1=False)
        peak = next(c for c in report["cases"] if "Peak" in c["label"])
        self.assertTrue(any("no wire" in w for w in report["warnings"]))
        self.assertGreater(peak["slack_mw"], 0.5)
        self.assertFalse(any(v["type"] == "forming_overload" for c in report["cases"] for v in c["violations"]))

    def test_islanded_study_is_opt_in_and_informational(self):
        run = self.make_run([("g", "grid"), ("b", "bus"), ("l", "load"), ("pv", "pv"), ("bs", "bess")],
                            [("w1", "g", "b", 0), ("w2", "b", "l", 0), ("w3", "pv", "b", 0), ("w4", "bs", "b", 0)])
        a = dict(nodes=same_kv(["g", "b", "l", "pv", "bs"]))
        off = pf.screen_run(run, self.code, assumptions=a, n1=False)
        on = pf.screen_run(run, self.code, assumptions=a, n1=False, islanded=True)
        self.assertIsNone(off["islanded"])
        study = on["islanded"]
        self.assertTrue(study["informational"])
        self.assertEqual(study["status"], "SUPPORTABLE")
        self.assertIn("self-supportable", study["chip"])
        self.assertEqual([c["label"] for c in on["cases"]], [c["label"] for c in off["cases"]])
        self.assertEqual((on["status"], on["summary"]["violations"]), (off["status"], off["summary"]["violations"]))
        self.assertFalse(any("Islanded" in c["label"] for c in on["cases"]))

    def test_islanded_hours_and_snapshot_kind(self):
        run = self.make_run([("g", "grid"), ("b", "bus"), ("l", "load"), ("pv", "pv"), ("bs", "bess")],
                            [("w1", "g", "b", 0), ("w2", "b", "l", 0), ("w3", "pv", "b", 0), ("w4", "bs", "b", 0)])
        a = dict(nodes=same_kv(["g", "b", "l", "pv", "bs"]))
        call = lambda **kw: extensions.POST["powerflow"](dict(run_id=run.name, scenario=self.code, assumptions=a, **kw))
        with mock.patch.object(extensions, "run_folder", return_value=run):
            plain = call(action="hours")
            listed = call(action="hours", islanded=True)
            snap = call(action="snapshot", islanded=True, kind="islanded")
        self.assertFalse(any(p["kind"] == "islanded" for p in plain["picks"]))
        self.assertTrue(any(p["kind"] == "islanded" and p["informational"] for p in listed["picks"]))
        self.assertTrue(snap["informational"])
        self.assertEqual(snap["suggestions"], [])

    def test_api_handlers(self):
        run = self.make_run([("g", "grid"), ("l", "load")], [("w1", "g", "l", 1.0)])
        manual = extensions.POST["powerflow"](dict(
            action="solve", topology=diagram([("g", "grid"), ("l", "load")], [("w1", "g", "l", 1.0)]),
            assumptions=dict(nodes=same_kv(["g", "l"])), operating=dict(load_mw=2.0, gens={})))
        self.assertTrue(manual["case"]["converged"])
        with self.assertRaises(ValueError):
            extensions.POST["powerflow"](dict(action="screen", run_id="x"))
        self.assertTrue(extensions.POST["powerflow"](dict(action="defaults"))["defaults"])
        self.assertEqual(pf.technical_status(run, "NOPE")["status"], "NOT_RUN")


if __name__ == "__main__":
    unittest.main()
