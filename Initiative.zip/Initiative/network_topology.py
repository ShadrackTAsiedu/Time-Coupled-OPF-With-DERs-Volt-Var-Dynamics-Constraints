"""Single-line connectivity and owned one-time connection costs; not power flow."""

import math

import pf_costs

TECHNOLOGIES = {"grid", "pv", "bess", "wind", "ng", "ng_chp", "h2", "h2_chp", "diesel", "biogas", "biomass"}
# Non-technology SLD equipment.  "shunt" is a capacitor bank (+Mvar) or reactor (-Mvar) wired to exactly one bus; its size is
# electrical.shunt_mvar (+ steps/step Mvar/kv).  power_flow.py must fold it into that bus's shunt (see pf_view()).
PASSIVE_KINDS = {"load", "bus", "substation", "shunt"}
BUS_NUMBER_MAX = 999997   # PSS/E v33: 1..999997
BUS_NAME_LENGTH = 12      # PSS/E v33 bus names: up to 12 characters, no quotes
BUS_NAME_CHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 _-.+/")


def valid_bus_number(value):
    """Integer PSS/E bus number in 1..999997, or None when the value is unusable."""
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value != int(value):
        return None
    return int(value) if 1 <= int(value) <= BUS_NUMBER_MAX else None


def sanitize_bus_name(value):
    """PSS/E-safe bus name: upper case, characters A-Z 0-9 space _-.+/ only, at most 12 characters; '' when nothing is left."""
    if not isinstance(value, str):
        return ""
    return "".join(c for c in value.upper() if c in BUS_NAME_CHARS).strip()[:BUS_NAME_LENGTH].strip()


def unique_bus_name(name, used):
    """name, or name with a _2/_3... suffix (still within 12 characters) that is not in `used` (case-insensitive)."""
    taken = {u.upper() for u in used}
    base, n = name, 1
    while name.upper() in taken:
        n += 1
        name = base[:BUS_NAME_LENGTH - len(str(n)) - 1] + "_" + str(n)
    return name


def number(value, label, maximum=1e12):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= maximum:
        raise ValueError(f"Topology {label} must be a finite nonnegative number up to {maximum:g}.")
    return value


# Optional electrical data used only by power_flow.py (PSS/E-grade bus/branch data); never affects costs or the LP.
NODE_ELECTRICAL = {"kv", "shunt_mvar", "cap_mw", "q_min_mvar", "q_max_mvar", "pf", "pf_mode", "rated_pf", "rated_pf_lead", "vset", "sc_mva", "xr", "weight",
                   "control", "in_service",
                   # PSS/E-style bus / machine / load / shunt data (documented in GENERATION_APP_README.md, "Power-flow parameters")
                   "bus_number", "bus_name", "bus_type", "area", "zone", "vmax_pu", "vmin_pu", "vmax_emerg_pu", "vmin_emerg_pu",
                   "pmin_mw", "pmax_mw", "mbase_mva", "xd2_pu", "load_mw", "load_mvar", "shunt_steps", "shunt_step_mvar", "shunt_auto", "shunt_user"}
LINE_ELECTRICAL = {"kind", "type", "circuits", "r_ohm_km", "x_ohm_km", "b_us_km", "rating_mva", "ampacity_a", "mva",
                   "z_pct", "xr", "tap", "in_service", "tap_min", "tap_max", "tap_steps", "hv_kv", "lv_kv", "vector_group", "cooling"}
ELECTRICAL_TEXT = {"pf_mode": {"lag", "lead"}, "control": {"pf", "voltage", "q"}, "kind": {"line", "transformer", "tie"},
                   "type": {"overhead", "cable"}, "bus_type": {"pq", "pv", "swing"}}
ELECTRICAL_FREE_TEXT = {"vector_group", "cooling"}
PF_SETTINGS = {"vmin_pu", "vmax_pu", "vmin_emerg_pu", "vmax_emerg_pu", "thermal_limit_pct", "high_loading_pct", "base_mva",
               "grid_sc_mva", "grid_xr", "load_pf"} | set(getattr(pf_costs, "SETTING_KEYS", ()))


def pf_settings(raw):
    """Diagram-level power-flow settings (numbers only); anything unknown or non-finite is dropped."""
    if not isinstance(raw, dict):
        return {}
    return {k: v for k, v in raw.items() if k in PF_SETTINGS and not isinstance(v, bool) and isinstance(v, (int, float))
            and math.isfinite(v) and 0 < abs(v) <= 1e9}


def electrical(row, allowed):
    raw = row.get("electrical")
    if not isinstance(raw, dict):
        return {}
    clean = {}
    for key, value in raw.items():
        if key not in allowed:
            continue
        if key in ELECTRICAL_TEXT:
            if value in ELECTRICAL_TEXT[key]:
                clean[key] = value
        elif key == "bus_name":
            if sanitize_bus_name(value):
                clean[key] = sanitize_bus_name(value)
        elif key == "bus_number":
            if valid_bus_number(value) is not None:
                clean[key] = valid_bus_number(value)
        elif key in ELECTRICAL_FREE_TEXT:
            if isinstance(value, str) and value.strip():
                clean[key] = "".join(c for c in value.strip() if c.isalnum() or c in " _-.,/'+()")[:24]
        elif key in ("in_service", "shunt_auto", "shunt_user"):
            if isinstance(value, bool):
                clean[key] = value
        elif not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value) and abs(value) <= 1e9:
            clean[key] = value
    return dict(electrical=clean) if clean else {}


def validate(raw, scenarios):
    out = validate_diagram(raw, scenarios if not isinstance(raw, dict) or not raw.get("diagrams") else [])
    if not isinstance(raw, dict) or "diagrams" not in raw:
        return out
    diagrams = raw["diagrams"]
    if not isinstance(diagrams, dict) or len(diagrams) > 100:
        raise ValueError("Topology scenario diagrams must be an object with at most 100 entries.")
    out["diagrams"] = {}
    for code, diagram in diagrams.items():
        if not isinstance(code, str) or not code or len(code) > 32 or not all(c.isalnum() or c in "_-" for c in code):
            raise ValueError("Topology scenario IDs must use letters, digits, hyphens or underscores.")
        out["diagrams"][code] = validate_diagram(diagram, [s for s in scenarios if s["id"] == code])
    for scenario in scenarios:
        if scenario["id"] not in diagrams:
            # Legacy/common diagrams remain the fallback for scenarios without their own drawing.
            validate_diagram(out, [scenario])
    active = raw.get("active_scenario")
    if active is not None and (not isinstance(active, str) or active not in diagrams):
        raise ValueError("Select an existing topology scenario diagram.")
    out["active_scenario"] = active
    return out


def validate_diagram(raw, scenarios):
    if raw is None:
        return dict(enabled=False, nodes=[], lines=[])
    if not isinstance(raw, dict) or type(raw.get("enabled")) is not bool:
        raise ValueError("Topology requires an enabled checkbox, nodes and lines.")
    nodes, lines = raw.get("nodes", []), raw.get("lines", [])
    if not isinstance(nodes, list) or not isinstance(lines, list) or len(nodes) > 100 or len(lines) > 200:
        raise ValueError("Topology supports up to 100 nodes and 200 lines.")
    ids, technologies, clean_nodes, clean_lines = set(), set(), [], []
    def identifier(value):
        if not isinstance(value, str) or not value or len(value) > 60 or not all(c.isalnum() or c in "_-" for c in value):
            raise ValueError("Topology IDs must use 1-60 letters, digits, hyphens or underscores.")
        return value
    for row in nodes:
        if not isinstance(row, dict):
            raise ValueError("Each topology node must be an object.")
        key = identifier(row.get("id"))
        kind = row.get("kind")
        if key in ids or kind not in TECHNOLOGIES | PASSIVE_KINDS:
            raise ValueError("Topology nodes need unique IDs and valid equipment types.")
        if kind in TECHNOLOGIES:
            if kind in technologies:
                raise ValueError(f"Use one aggregate topology node for {kind}; capacities remain aggregated by technology.")
            technologies.add(kind)
        ids.add(key)
        owner = row.get("owner", "shared")
        if owner not in TECHNOLOGIES | {"shared"}:
            raise ValueError("Choose a valid substation cost owner.")
        if kind != "substation" and row.get("capital_cost", 0) != 0:
            raise ValueError("Enter node investment only for substations; enter generation costs under its technology.")
        rotation = row.get("rotation", 0)
        if rotation not in (0, 90, 180, 270):
            raise ValueError("Component rotation must be 0, 90, 180 or 270 degrees.")
        clean_nodes.append(dict(id=key, kind=kind, label=str(row.get("label", kind))[:120], rotation=rotation,
                                scale=min(3.0, max(0.3, number(row.get("scale", 0.8), "symbol size"))),
                                x=number(row.get("x", 100), "node x", 1600),
                                y=number(row.get("y", 100), "node y", 900),
                                owner=owner, capital_cost=number(row.get("capital_cost", 0), "substation cost"),
                                **electrical(row, NODE_ELECTRICAL)))
    line_ids = set()
    for row in lines:
        if not isinstance(row, dict):
            raise ValueError("Each topology line must be an object.")
        key = identifier(row.get("id"))
        source, target = row.get("source"), row.get("target")
        if source not in ids or target not in ids or source == target or key in line_ids:
            continue  # dangling or duplicate wires are discarded, not fatal
        owner = row.get("owner")
        if owner not in TECHNOLOGIES | {"shared"}:
            raise ValueError("Assign each line cost to a technology or Shared.")
        line_ids.add(key)
        points = row.get("points", [])
        if not isinstance(points, list) or len(points) > 100 or any(not isinstance(p, dict) for p in points):
            raise ValueError("A wire route supports up to 100 editable bend points.")
        route = [dict(x=number(p.get("x"), "bend x", 1600), y=number(p.get("y"), "bend y", 900)) for p in points]
        ports = {key: row.get(key, "center") for key in ("source_port", "target_port")}
        if any(value not in ("center", "top", "bottom", "left", "right") for value in ports.values()):
            raise ValueError("Select a valid component connection port.")
        clean_lines.append(dict(id=key, source=source, target=target, owner=owner, points=route,
                                **ports,
                                length_km=number(row.get("length_km", 0), "line length", 10000),
                                cost_per_km=number(row.get("cost_per_km", 0), "installed line cost/km"),
                                **electrical(row, LINE_ELECTRICAL)))
    out = dict(enabled=raw["enabled"], nodes=clean_nodes, lines=clean_lines)
    kinds_by_id = {n["id"]: n["kind"] for n in clean_nodes}
    for node in clean_nodes:
        if node["kind"] == "shunt":
            wires = [e for e in clean_lines if node["id"] in (e["source"], e["target"])]
            if len(wires) > 1:
                raise ValueError(f"Shunt '{node['label']}' connects to exactly one bus; remove its extra wires.")
            if wires and kinds_by_id[wires[0]["source"]] == kinds_by_id[wires[0]["target"]]:
                raise ValueError("A shunt must be wired to a bus, not to another shunt.")
    warnings = []
    seen_numbers, seen_names = {}, {}
    for node in clean_nodes:
        values = node.get("electrical")
        if not values:
            continue
        for field, seen in (("bus_number", seen_numbers), ("bus_name", seen_names)):
            if field not in values:
                continue
            marker = values[field] if field == "bus_number" else values[field].upper()
            if marker in seen and seen[marker] != node["id"]:
                warnings.append(f"Duplicate {field.replace('_', ' ')} {values[field]} on '{node['label']}' "
                                f"(already used by '{seen[marker]}'); it was reset to automatic.")
                del values[field]
                if not values:
                    del node["electrical"]
            else:
                seen[marker] = node["id"]
    if len(clean_nodes) > 1:
        wired = {key for e in clean_lines for key in (e["source"], e["target"])}
        for node in clean_nodes:
            if node["id"] not in wired:
                warnings.append(f"'{node['label']}' is not connected to any wire.")
        pairs = set()
        for edge in clean_lines:
            pair = frozenset((edge["source"], edge["target"]))
            if pair in pairs:
                warnings.append("Parallel wires join the same two components; use Circuits on one wire for a double circuit.")
            pairs.add(pair)
    if warnings:
        out["warnings"] = warnings
    kept = [t for t in raw.get("autodraw_technologies", []) if t in TECHNOLOGIES] if isinstance(raw.get("autodraw_technologies"), list) else []
    if kept:
        out["autodraw_technologies"] = sorted(set(kept))
    if pf_settings(raw.get("pf_settings")):
        out["pf_settings"] = pf_settings(raw["pf_settings"])
    if out["enabled"] and scenarios:
        loads = {n["id"] for n in clean_nodes if n["kind"] == "load"}
        if not loads:
            raise ValueError("Add a Load node before enabling topology costs.")
        for scenario in scenarios:
            eligible = set(scenario["technologies"])
            # Generators are terminal equipment, not implicit interconnection buses.
            kinds = {n["id"]: n["kind"] for n in clean_nodes}
            for technology in eligible:
                available = {n["id"] for n in clean_nodes
                             if (n["kind"] not in TECHNOLOGIES or n["kind"] in eligible)
                             and (n["kind"] != "substation" or n["owner"] in {"shared", technology})}
                graph = {key: set() for key in available}
                for edge in clean_lines:
                    if edge["owner"] in {technology, "shared"} and edge["source"] in graph and edge["target"] in graph:
                        graph[edge["source"]].add(edge["target"])
                        graph[edge["target"]].add(edge["source"])
                starts = [n["id"] for n in clean_nodes if n["kind"] == technology]
                visited, stack = set(), list(starts)
                while stack:
                    current = stack.pop()
                    if current in visited:
                        continue
                    visited.add(current)
                    if kinds[current] in {"bus", "substation", "load", technology}:
                        stack.extend(graph[current] - visited)
                if not loads & visited:
                    raise ValueError(f"{scenario['id']}: connect {technology} to Load using available buses/lines. "
                                     "Allocate common routes and substations to Shared, not another technology.")
    return out


def pf_view(diagram):
    """Copy of a validated diagram where each 'shunt' node is folded into the bus it is wired to (its electrical.shunt_mvar is
    added to that bus's electrical.shunt_mvar) and the shunt node and its wire are removed.  For power_flow.py, which models
    every remaining node as a bus.  A shunt wired to nothing, or marked in_service False, contributes nothing."""
    shunts = {n["id"]: n for n in diagram["nodes"] if n["kind"] == "shunt"}
    if not shunts:
        return diagram
    nodes = {n["id"]: dict(n, electrical=dict(n.get("electrical") or {})) for n in diagram["nodes"] if n["kind"] != "shunt"}
    lines = []
    for edge in diagram["lines"]:
        ends = {edge["source"], edge["target"]}
        hit = ends & set(shunts)
        if not hit:
            lines.append(edge)
            continue
        shunt = shunts[next(iter(hit))]
        bus = nodes.get(next(iter(ends - hit), None))
        values = shunt.get("electrical") or {}
        if bus is None or values.get("in_service") is False:
            continue
        e = bus["electrical"]
        e["shunt_mvar"] = e.get("shunt_mvar", 0.0) + values.get("shunt_mvar", 0.0)
        for key in ("shunt_steps", "shunt_step_mvar"):
            if key in values and key not in e:
                e[key] = values[key]
    for node in nodes.values():
        if not node["electrical"]:
            del node["electrical"]
    return dict(diagram, nodes=list(nodes.values()), lines=lines)


def autodraw(technologies, existing=None, shunt_mvar=None, enabled=None):
    """Regenerate the connected single-line diagram for a scenario: Load - main Bus - one terminal per technology.

    technologies: iterable of technology keys.  existing: optional diagram whose component/wire IDs, line costs and extra
    equipment (buses, substations, loads, shunts) are kept.  shunt_mvar: None draws no shunt (an already stored one is kept);
    a nonzero number (+ capacitor / - reactor, |x| <= 1000) draws or resizes ONE shunt on the main bus; 0 removes the shunts
    attached to the main bus.  Returns {enabled, nodes, lines} (same schema as validate_diagram input)."""
    if shunt_mvar is not None and (isinstance(shunt_mvar, bool) or not isinstance(shunt_mvar, (int, float)) or
                                   not math.isfinite(shunt_mvar) or abs(shunt_mvar) > 1000):
        raise ValueError("Shunt Mvar must be a finite number between -1000 and 1000.")
    kinds = [k for k in dict.fromkeys(technologies) if k in TECHNOLOGIES]
    old = existing or {"nodes": [], "lines": []}
    by_kind = {}
    for n in old.get("nodes", []):
        by_kind.setdefault(n["kind"], n)

    def node(kind, x, y, ident=None):
        prior = by_kind.get(kind)
        row = dict(prior) if prior else dict(id=ident or kind, kind=kind, label=kind.upper() if kind in TECHNOLOGIES else kind.title(),
                                             rotation=0, scale=0.7, owner=kind if kind in TECHNOLOGIES else "shared", capital_cost=0)
        row.update(x=x, y=y)
        return row
    bus, load = node("bus", 800, 400), node("load", 800, 620)
    # Same layout as topology.js autoDraw; floor(v/20+.5) is JavaScript's Math.round, unlike Python's banker's round().
    step = min(240, 1300 / max(1, len(kinds) - 1))
    snap = lambda v: math.floor(v / 20 + 0.5) * 20
    terminals = [node(k, 800 if len(kinds) == 1 else snap(800 + (i - (len(kinds) - 1) / 2) * step), 140) for i, k in enumerate(kinds)]
    core = [load, bus] + terminals
    lines = []

    def connect(a, b, owner):
        prior = next((e for e in old.get("lines", []) if {_kind(old, e["source"]), _kind(old, e["target"])} == {a["kind"], b["kind"]}), None)
        lines.append(dict(id=prior["id"] if prior else f"l_{a['id']}_{b['id']}", source=a["id"], target=b["id"],
                          source_port="bottom", target_port="top", owner=prior["owner"] if prior else owner,
                          length_km=prior.get("length_km", 0) if prior else 0, cost_per_km=prior.get("cost_per_km", 0) if prior else 0,
                          points=[]))
    connect(bus, load, "shared")
    for t in terminals:
        connect(t, bus, t["kind"])
    core_ids = {n["id"] for n in core}
    extra = [n for n in old.get("nodes", []) if n["id"] not in core_ids and n["kind"] in PASSIVE_KINDS]
    extra_ids = {n["id"] for n in extra}
    all_ids = core_ids | extra_ids
    lines += [e for e in old.get("lines", []) if (e["source"] in extra_ids or e["target"] in extra_ids)
              and e["source"] in all_ids and e["target"] in all_ids]
    if shunt_mvar is not None:
        attached = [n for n in extra if n["kind"] == "shunt" and any(
            {e["source"], e["target"]} == {n["id"], bus["id"]} for e in lines)]
        if shunt_mvar == 0:
            drop = {n["id"] for n in attached}
            extra = [n for n in extra if n["id"] not in drop]
            lines = [e for e in lines if e["source"] not in drop and e["target"] not in drop]
        else:
            if attached:
                shunt = attached[0]
            else:
                shunt = dict(id="shunt_main", kind="shunt", label="Shunt capacitor", rotation=0, scale=0.7, x=960, y=560,
                             owner="shared", capital_cost=0)
                while shunt["id"] in all_ids:
                    shunt["id"] += "_"
                extra.append(shunt)
                lines.append(dict(id=f"l_{bus['id']}_{shunt['id']}", source=bus["id"], target=shunt["id"], source_port="bottom",
                                  target_port="top", owner="shared", length_km=0, cost_per_km=0, points=[]))
            values = dict(shunt.get("electrical") or {}, shunt_mvar=float(shunt_mvar))
            if "kv" in (bus.get("electrical") or {}):
                values.setdefault("kv", bus["electrical"]["kv"])
            shunt["electrical"] = values
            shunt["label"] = "Shunt reactor" if shunt_mvar < 0 else "Shunt capacitor"
    out = dict(enabled=bool(old.get("enabled", False) if enabled is None else enabled), nodes=core + extra, lines=lines)
    return out


def _kind(diagram, ident):
    return next((n["kind"] for n in diagram.get("nodes", []) if n["id"] == ident), None)


def costs(topology, eligible, scenario_id=None):
    topology = topology.get("diagrams", {}).get(scenario_id, topology)
    amounts = {key: 0.0 for key in TECHNOLOGIES | {"shared"}}
    if not topology.get("enabled"):
        return amounts
    nodes = {n["id"]: n for n in topology["nodes"]}
    def active(node):
        return node["kind"] not in TECHNOLOGIES or node["kind"] in eligible
    for edge in topology["lines"]:
        if edge["owner"] in set(eligible) | {"shared"} and active(nodes[edge["source"]]) and active(nodes[edge["target"]]):
            amounts[edge["owner"]] += edge["length_km"] * edge["cost_per_km"]
    for node in nodes.values():
        if node["kind"] == "substation" and node["owner"] in set(eligible) | {"shared"}:
            amounts[node["owner"]] += node["capital_cost"]
    return amounts


def installed_costs(cfg, caps, reference=False):
    amounts = cfg.get("connection_costs", {})
    ratings = {"pv": caps["pv_dc_mw"], "bess": caps["bess_mw"], **caps.get("generators_mw", {})}
    return {owner: cost for owner, cost in amounts.items()
            if owner == "shared" or (owner == "grid" and not cfg.get("islanded")) or
            (not reference and ratings.get(owner, 0) > 1e-7)}
