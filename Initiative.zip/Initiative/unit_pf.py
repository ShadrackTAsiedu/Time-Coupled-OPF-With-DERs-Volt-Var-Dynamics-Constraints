"""Operating power factor of generation units: rated MVA, reactive capability and the MW / MVA cost basis.

A unit's MW capacity in GenStudio is its ACTIVE-power rating at the stated operating power factor.  The equipment is built and
sized in MVA:  S = P / pf,  Qmax (lagging, exporting Mvar) = P * tan(acos(pf_lag)),  Qmin (leading, absorbing) = -P * tan(acos(pf_lead)).

Cost basis (global input `cost_basis`):
  per_mw_at_pf  entered $/MW is already per MW at the stated power factor (default; no uplift, nothing counted twice);
  per_mva       entered $/MW is really $ per MVA of rating, so the effective $/MW = entered / pf (capex, fixed O&M, replacement).
Variable cost stays per MWh.  Runs saved before this feature have no pf fields: they read pf 0.9 for reactive capability and
the default basis (per MW at stated pf), so their optimizer costs and results are unchanged.
"""
import math

DEFAULT_PF = 0.9
PF_MIN, PF_MAX = 0.8, 1.0
TECHS = ("pv", "bess", "wind", "ng", "ng_chp", "h2", "h2_chp", "diesel", "biogas", "biomass")
LABELS = dict(pv="Solar PV", bess="BESS", wind="Wind", ng="Natural gas turbine", ng_chp="Natural gas CHP", h2="Hydrogen turbine",
              h2_chp="Hydrogen CHP", diesel="Diesel generator", biogas="Biogas generator", biomass="Biomass generator")
COST_BASES = [("per_mw_at_pf", "Per MW at the stated power factor (default, no uplift)"),
              ("per_mva", "Per MVA of rating (effective $/MW = entered / power factor)")]
DEFAULT_BASIS = COST_BASES[0][0]
NOTE = ("MW capacity is the active-power rating at the stated operating power factor; the unit is built and sized in MVA "
        "(MVA = MW / pf, Qmax = MW x tan(acos(pf))).")
BASIS_NOTE = ("Entered capex and fixed O&M are interpreted per MW at the stated power factor (no hidden MVA uplift). "
              "Choose 'per MVA' to scale them by 1/pf instead; variable cost stays per MWh.")


def check_pf(value, label="Power factor"):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{label} must be a number between {PF_MIN:g} and {PF_MAX:g}.")
    if not PF_MIN - 1e-12 <= value <= PF_MAX + 1e-12:
        raise ValueError(f"{label} must be between {PF_MIN:g} and {PF_MAX:g}.")
    return float(value)


def tan_phi(pf):
    return math.tan(math.acos(min(max(float(pf), 1e-6), 1.0)))


def rated_mva(mw, pf):
    return float(mw) / float(pf)


def q_limits(mw, pf_lag, pf_lead=None):
    """(Qmin, Qmax) in Mvar at the rated MW: lagging (export) and leading (absorb) capability."""
    pf_lead = pf_lag if pf_lead is None else pf_lead
    return -float(mw) * tan_phi(pf_lead), float(mw) * tan_phi(pf_lag)


def q_capability(mw, p, pf_lag, pf_lead=None):
    """(Qmin, Qmax) when the unit actually produces p MW: capped by the MVA circle S = mw / pf, sqrt(S^2 - p^2)."""
    pf_lead = pf_lag if pf_lead is None else pf_lead
    out = []
    for pf in (pf_lead, pf_lag):
        s = float(mw) / pf
        out.append(math.sqrt(max(s * s - float(p) ** 2, 0.0)))
    return -out[0], out[1]


def cost_factor(basis, pf):
    """Multiplier applied to entered capex / fixed O&M ($/MW) to get the effective $/MW."""
    return 1.0 / float(pf) if basis == "per_mva" else 1.0


def pf_key(tech):
    return tech + "_pf"


def lead_key(tech):
    return tech + "_pf_lead"


def for_tech(values, tech):
    """dict(pf, pf_lead) of one technology from request values; missing keys (old runs) read the 0.9 default."""
    values = values or {}
    pf = values.get(pf_key(tech), DEFAULT_PF)
    lead = values.get(lead_key(tech), DEFAULT_PF)
    return dict(pf=float(pf if isinstance(pf, (int, float)) and not isinstance(pf, bool) else DEFAULT_PF),
                pf_lead=float(lead if isinstance(lead, (int, float)) and not isinstance(lead, bool) else DEFAULT_PF))


def from_values(values):
    return {tech: for_tech(values, tech) for tech in TECHS}


def basis_of(values):
    basis = (values or {}).get("cost_basis", DEFAULT_BASIS)
    return basis if basis in dict(COST_BASES) else DEFAULT_BASIS


def statement(values):
    """One-line statement for the UI, reports, decks and design: pf basis of the MW capacities and the cost basis."""
    pfs = {t: for_tech(values, t)["pf"] for t in ("pv", "bess", "wind", "ng")}
    pf_text = f"{pfs['pv']:g}" if len(set(pfs.values())) == 1 else ", ".join(f"{LABELS[t]} {p:g}" for t, p in pfs.items())
    basis = ("costs are per MW at stated pf" if basis_of(values) == "per_mw_at_pf"
             else "costs are per MVA of rating (effective $/MW = entered / pf)")
    return f"MW capacity is at the stated power factor ({pf_text}); rated MVA = MW / pf; {basis}."


def mva_text(tech, mw, values):
    """'11.11 MVA (pf 0.9)' for a technology's MW capacity, '' when there is none."""
    if not isinstance(mw, (int, float)) or mw <= 1e-9:
        return ""
    pf = for_tech(values, tech)["pf"]
    return f"{rated_mva(mw, pf):.2f} MVA (pf {pf:g})"


def ratings(caps_mw, values):
    """Rows (tech, label, mw, pf, pf_lead, mva, q_max_mvar, q_min_mvar) for every technology with capacity > 0."""
    pfs = from_values(values)
    rows = []
    for tech in TECHS:
        mw = caps_mw.get(tech)
        if not isinstance(mw, (int, float)) or mw <= 1e-9:
            continue
        spec = pfs[tech]
        qmin, qmax = q_limits(mw, spec["pf"], spec["pf_lead"])
        rows.append(dict(tech=tech, label=LABELS[tech], mw=float(mw), pf=spec["pf"], pf_lead=spec["pf_lead"],
                         mva=rated_mva(mw, spec["pf"]), q_max_mvar=qmax, q_min_mvar=qmin))
    return rows
