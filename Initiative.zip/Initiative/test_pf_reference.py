"""Independent validation of the power-flow engine.

The reference below is written separately from power_flow.py: it works in physical units (ohm, siemens, kV, MVA; no per-unit
system), builds its own admittance matrix from the user-level data (ohm/km, %Z, X/R, tap, short-circuit MVA) and solves the
nodal power equations in rectangular coordinates with scipy's hybrid Powell solver instead of polar Newton-Raphson.
"""
import cmath
import math
import unittest
from pathlib import Path

import numpy as np
from scipy.optimize import fsolve

import power_flow as pf

RUN = Path(__file__).resolve().parent / "Application Runs" / "7791be18470745f8af5ef34fa3d208f8"


def diagram(nodes, lines):
    return dict(enabled=False,
                nodes=[dict(id=i, kind=k, label=i, x=100 + 100 * n, y=100) for n, (i, k) in enumerate(nodes)],
                lines=[dict(id=i, source=a, target=b, owner="shared", length_km=km, cost_per_km=0) for i, a, b, km in lines])


def meshed_network():
    """66 kV grid -> 25 MVA transformer (tap 1.025) -> 11 kV ring of a cable and two overhead lines, a 22 kV spur through a
    transformer whose tap sits on the 22 kV side, PV at pf 0.95 lead, a voltage-controlling genset, wind and a capacitor."""
    nodes = [("g", "grid"), ("b1", "bus"), ("b2", "bus"), ("b3", "bus"), ("b4", "bus"), ("l1", "load"), ("l2", "load"),
             ("l3", "load"), ("pv", "pv"), ("ng", "ng"), ("wd", "wind")]
    lines = [("t1", "g", "b1", 0), ("c12", "b1", "b2", 4.0), ("o23", "b2", "b3", 3.0), ("o13", "b1", "b3", 6.0),
             ("t2", "b2", "b4", 0), ("e1", "b2", "l1", 0), ("e2", "b3", "l2", 0), ("e3", "b4", "l3", 0),
             ("e4", "b3", "pv", 0), ("e5", "b2", "ng", 0), ("e6", "b4", "wd", 0)]
    kv = dict(g=66.0, b1=11.0, b2=11.0, b3=11.0, b4=22.0, l1=11.0, l2=11.0, l3=22.0, pv=11.0, ng=11.0, wd=22.0)
    nodes_over = {k: dict(kv=v) for k, v in kv.items()}
    nodes_over["g"].update(sc_mva=900.0, xr=8.0)
    nodes_over["b3"]["shunt_mvar"] = 1.2
    nodes_over["pv"].update(pf=0.95, pf_mode="lead", control="pf")
    nodes_over["wd"].update(control="pf")
    nodes_over["ng"].update(control="voltage", vset=1.02)
    nodes_over["l1"]["weight"], nodes_over["l2"]["weight"], nodes_over["l3"]["weight"] = 2.0, 1.0, 1.0
    lines_over = dict(t1=dict(mva=25, tap=1.025, z_pct=9.0, xr=15), t2=dict(mva=10, tap=0.975, z_pct=7.0, xr=10),
                      c12=dict(type="cable", circuits=2), o23=dict(type="overhead"), o13=dict(type="overhead", r_ohm_km=0.3, x_ohm_km=0.35, b_us_km=3.0))
    return pf.build_network(diagram(nodes, lines), caps=dict(pv=5.0, ng=40.0, wind=3.0),
                            assumptions=dict(nodes=nodes_over, lines=lines_over), peak_load_mw=20.0)


def reference(net, inj):
    """Solve the case in physical units.  Returns {bus id: complex kV}, {branch id: (S_from, S_to) in MVA}."""
    n = len(net.buses)
    kv = np.array([b["kv"] for b in net.buses])
    Y = np.zeros((n, n), complex)
    two_port = {}
    for br in net.branches:
        if not br.get("on", True):
            continue
        f, t = br["f"], br["t"]
        if br["kind"] == "source":
            gen = next(g for g in net.gens if g["tech"] == "grid" and g["node"] + "__eq" == br["id"])
            z = kv[t] ** 2 / gen["sc_mva"] * cmath.rect(1.0, math.atan(gen["xr"]))
            yff, yft, ytf, ytt = 1 / z, -1 / z, -1 / z, 1 / z
        elif br["kind"] == "tie":
            z = complex(pf.TIE_R_PU, pf.TIE_X_PU) * kv[f] ** 2 / 100.0
            yff, yft, ytf, ytt = 1 / z, -1 / z, -1 / z, 1 / z
        elif br["kind"] == "line":
            c = br["circuits"]
            z = complex(br["r_ohm_km"], br["x_ohm_km"]) * br["length_km"] / c
            half = 1j * br["b_us_km"] * 1e-6 * br["length_km"] * c / 2
            yff, yft, ytf, ytt = 1 / z + half, -1 / z, -1 / z, 1 / z + half
        else:
            ang = cmath.rect(1.0, math.atan(br["xr"]))
            if br["tap_side"] == "f":
                z = br["z_pct"] / 100.0 * kv[t] ** 2 / br["mva"] * ang
                ratio = kv[f] * br["tap"] / kv[t]
                yff, yft, ytf, ytt = 1 / (z * ratio ** 2), -1 / (z * ratio), -1 / (z * ratio), 1 / z
            else:
                z = br["z_pct"] / 100.0 * kv[f] ** 2 / br["mva"] * ang
                ratio = kv[t] * br["tap"] / kv[f]
                yff, yft, ytf, ytt = 1 / z, -1 / (z * ratio), -1 / (z * ratio), 1 / (z * ratio ** 2)
        Y[f, f] += yff
        Y[f, t] += yft
        Y[t, f] += ytf
        Y[t, t] += ytt
        two_port[br["id"]] = (f, t, yff, yft, ytf, ytt)
    for i, b in enumerate(net.buses):
        Y[i, i] += 1j * b["shunt_mvar"] / kv[i] ** 2
    weight = sum(l["weight"] for l in net.loads if l["on"]) or 1.0
    s_spec = np.zeros(n, complex)
    for l in net.loads:
        p = inj["load_mw"] * l["weight"] / weight
        s_spec[l["idx"]] -= complex(p, p * math.tan(math.acos(l["pf"])))
    pv_bus, slack = {}, None
    for g in net.gens:
        if g["tech"] == "grid":
            slack = g["src_idx"]
            v_slack = g["vset"] * kv[slack]
            continue
        p = inj["gens"].get(g["tech"], {}).get("p", 0.0)
        if g["control"] == "voltage":
            s_spec[g["idx"]] += p
            pv_bus[g["idx"]] = g["vset"] * kv[g["idx"]]
        else:
            q = abs(p) * math.tan(math.acos(g["pf"])) * (1 if g["pf_mode"] == "lag" else -1)
            s_spec[g["idx"]] += complex(p, q)
    free = [i for i in range(n) if i != slack]

    def residual(x):
        v = np.zeros(n, complex)
        v[slack] = v_slack
        v[free] = x[:len(free)] + 1j * x[len(free):]
        s = v * np.conj(Y @ v)
        out = []
        for i in free:
            out.append(s[i].real - s_spec[i].real)
        for i in free:
            out.append(abs(v[i]) ** 2 - pv_bus[i] ** 2 if i in pv_bus else s[i].imag - s_spec[i].imag)
        return out

    x0 = np.r_[kv[free], np.zeros(len(free))]
    sol, info, ier, msg = fsolve(residual, x0, xtol=1e-13, full_output=True)
    assert ier == 1, msg
    v = np.zeros(n, complex)
    v[slack] = v_slack
    v[free] = sol[:len(free)] + 1j * sol[len(free):]
    flows = {}
    for bid, (f, t, yff, yft, ytf, ytt) in two_port.items():
        flows[bid] = (v[f] * np.conj(yff * v[f] + yft * v[t]), v[t] * np.conj(ytf * v[f] + ytt * v[t]))
    return {b["id"]: v[i] for i, b in enumerate(net.buses)}, flows, kv


class ReferenceAgreement(unittest.TestCase):
    TOL = 1e-4

    def compare(self, net, inj, **kwargs):
        case = pf.solve_case(net, inj, **kwargs)
        self.assertTrue(case["converged"])
        volts, flows, kv = reference(net, inj)
        index = {b["id"]: i for i, b in enumerate(net.buses)}
        worst_v = worst_a = worst_s = 0.0
        for bus in case["buses"] + case["internal"]:
            ref = volts[bus["id"]] / kv[index[bus["id"]]]
            worst_v = max(worst_v, abs(abs(ref) - bus["vm"]))
            worst_a = max(worst_a, abs(math.degrees(cmath.phase(ref)) - bus["va_deg"]))
        for row in case["branches"]:
            s_from, s_to = flows[row["id"]]
            worst_s = max(worst_s, abs(s_from.real - row["p_from_mw"]), abs(s_from.imag - row["q_from_mvar"]),
                          abs(s_to.real - row["p_to_mw"]), abs(s_to.imag - row["q_to_mvar"]))
        self.assertLess(worst_v, self.TOL)
        self.assertLess(worst_a, 1e-3)
        self.assertLess(worst_s, 1e-3)
        return case

    def test_meshed_network_all_loading_levels(self):
        net = meshed_network()
        for load, pv, ng, wind in ((20.0, 5.0, 6.0, 3.0), (8.0, 0.0, 0.5, 0.0), (6.0, 5.0, 0.5, 3.0), (30.0, 2.0, 6.0, 0.0)):
            with self.subTest(load=load):
                inj = dict(load_mw=load, gens=dict(pv=dict(p=pv), ng=dict(p=ng), wind=dict(p=wind)))
                case = self.compare(net, inj)
                self.assertFalse(any(g["q_limited"] for g in case["gens"]), "reference assumes no Q limit is binding")

    def test_losses_equal_generation_minus_load(self):
        net = meshed_network()
        inj = dict(load_mw=14.0, gens=dict(pv=dict(p=5.0), ng=dict(p=2.0), wind=dict(p=3.0)))
        case = pf.solve_case(net, inj)
        generated = sum(case["gen_mw"].values()) + case["slack_mw"]
        self.assertAlmostEqual(generated - case["served_load_mw"], case["losses_mw"], places=3)

    def test_reactive_power_balance(self):
        net = meshed_network()
        case = pf.solve_case(net, dict(load_mw=20.0, gens=dict(pv=dict(p=5.0), ng=dict(p=6.0), wind=dict(p=3.0))))
        supplied = sum(b["gen_mvar"] + b.get("shunt_q_mvar", 0.0) for b in case["buses"])
        absorbed = sum(b["load_mvar"] for b in case["buses"])
        network = sum(r["q_from_mvar"] + r["q_to_mvar"] for r in case["branches"])
        self.assertAlmostEqual(supplied - absorbed - network, 0.0, places=3)

    def test_outage_matches_reference_after_removal(self):
        net = meshed_network()
        inj = dict(load_mw=20.0, gens=dict(pv=dict(p=5.0), ng=dict(p=6.0), wind=dict(p=3.0)))
        case = pf.solve_case(net, inj, outages=["o13"])
        self.assertTrue(case["converged"])
        for b in net.branches:
            if b["id"] == "o13":
                b["on"] = False
        try:
            volts, _, kv = reference(net, inj)
        finally:
            for b in net.branches:
                if b["id"] == "o13":
                    b["on"] = True
        index = {b["id"]: i for i, b in enumerate(net.buses)}
        for bus in case["buses"]:
            self.assertAlmostEqual(abs(volts[bus["id"]]) / kv[index[bus["id"]]], bus["vm"], delta=1e-4)


@unittest.skipUnless(RUN.is_dir(), "reference run folder not present")
class UserRunAgreement(ReferenceAgreement):
    def test_every_scenario_screening_hour(self):
        checked = 0
        for code in ("P1", "R0", "S1", "S2", "H2", "NG"):
            ctx = pf._run_context(RUN, code)
            data = pf._read_dispatch(ctx["path"])
            net = pf._prepare(ctx, code, None, None, data)
            for label, hour in pf._hour_selection(data)[0]:
                inj = pf._hour_inputs(data, hour)
                pf._assign_genset_total(net, data, inj, hour)
                with self.subTest(scenario=code, case=label):
                    case = pf.solve_case(net, inj)
                    if any(g["q_limited"] for g in case["gens"]):
                        continue
                    self.compare(net, inj)
                    checked += 1
        # idle or Q-limited units are excluded (the reference has unlimited voltage control), so fewer hours qualify
        self.assertGreater(checked, 10)


@unittest.skipUnless(RUN.is_dir(), "reference run folder not present")
class ScreeningDedupe(unittest.TestCase):
    def test_coincident_hour_picks_are_one_case(self):
        report = pf.screen_run(RUN, "P1", n1=False, suggest=False)
        hours = [h["hour_index"] for h in report["screened"]["hours"]]
        self.assertEqual(len(hours), len(set(hours)))
        self.assertEqual(len([c for c in report["cases"] if not c["emergency"]]), len(hours))


if __name__ == "__main__":
    unittest.main()
