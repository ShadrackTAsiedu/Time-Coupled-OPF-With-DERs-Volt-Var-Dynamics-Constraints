import unittest

import plot_style


class TickFormatterTest(unittest.TestCase):
    def setUp(self):
        self.fmt = plot_style.apply()

    def test_no_negative_zero_and_separators(self):
        self.assertEqual(self.fmt(-1e-5, 0), "0")
        self.assertEqual(self.fmt(1234.5, 0), "1,234.5")
        self.assertEqual(self.fmt(-1e6, 0), "-1,000,000")
        self.assertEqual(self.fmt(0.1 + 0.2, 0), "0.3")


if __name__ == "__main__":
    unittest.main()
