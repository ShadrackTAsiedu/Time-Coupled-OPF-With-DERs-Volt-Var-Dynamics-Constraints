"""Load RAW files in PSS/E 35 (Python 3.11) and solve them; prints one line per file. Run with the PSS/E Python."""
import os
import sys

PSSE = r"C:\Program Files\PTI\PSSE35\35.6"
sys.path[:0] = [PSSE + r"\PSSPY311", PSSE + r"\PSSBIN"]
os.environ["PATH"] = PSSE + r"\PSSBIN;" + os.environ["PATH"]
if __name__ != "__main__":
    import unittest

    raise unittest.SkipTest("helper script: run with the PSS/E Python 3.11 interpreter")
import psse35  # noqa: F401,E402
import psspy  # noqa: E402

psspy.psseinit(10000)
for path in sys.argv[1:]:
    psspy.newcase_2([0, 1], 100.0, 60.0, "", "")
    ierr = psspy.readrawversion(1, "33", path)
    if ierr:
        print(os.path.basename(path), "READ ERROR", ierr)
        continue
    ierr = psspy.fnsl([0, 0, 0, 1, 1, 0, 99, 0])
    ok = psspy.solved()
    ierr_b, buses = psspy.abusint(-1, 1, ["NUMBER"])
    ierr_v, volts = psspy.abusreal(-1, 1, ["PU"])
    ierr_l, loads = psspy.aloadcplx(-1, 1, ["TOTALACT"])
    ierr_g, gens = psspy.amachcplx(-1, 1, ["PQGEN"])
    ierr_s, sl = psspy.abuscplx(-1, 1, ["PQLOAD"]) if False else (0, [[]])
    load = sum(x.real for x in loads[0])
    gen = sum(x.real for x in gens[0])
    print(os.path.basename(path), "fnsl_err", ierr, "solved_code", ok, "buses", len(buses[0]),
          "vmin %.4f vmax %.4f" % (min(volts[0]), max(volts[0])), "load %.4f gen %.4f loss %.4f MW" % (load, gen, gen - load))
psspy.pssehalt_2()
