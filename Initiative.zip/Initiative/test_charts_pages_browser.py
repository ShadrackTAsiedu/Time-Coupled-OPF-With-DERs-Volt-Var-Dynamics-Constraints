import json
import shutil
import socket
import subprocess
import sys
import time
import unittest
import uuid
from pathlib import Path
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

from test_charts_browser import RUNS, ROOT, source_run

FAKE_REPORT = {
    "state": "complete", "message": "done",
    "report": {
        "scenario": "S1", "method": "stub", "failed": [],
        "base": {"npc": 50e6},
        "risk": {"p50": 50e6, "p10": 47e6, "p90": 56e6, "minimum": 44e6, "maximum": 61e6, "adverse": 61e6, "favourable": 44e6},
        "swings": [
            {"id": "fuel", "label": "Fuel price", "unit": "% change", "low": -20, "high": 20, "delta_low": -2.9e6, "delta_high": 3.1e6, "swing": 6e6, "mix_changes": True},
            {"id": "pv", "label": "PV capex", "unit": "% change", "low": -20, "high": 20, "delta_low": -1.2e6, "delta_high": 1.3e6, "swing": 2.5e6, "mix_changes": False},
            {"id": "disc", "label": "Discount rate", "unit": "fraction", "low": 0.05, "high": 0.11, "delta_low": 4.0e6, "delta_high": -3.0e6, "swing": 7e6, "mix_changes": False},
        ],
        "table": [
            {"label": "Base", "npc": 50e6, "delta_pct": 0, "mix": "PV 10 MW", "unserved_mwh": 0, "mix_changed": False, "pv_mw": 10, "bess_mw": 5, "bess_mwh": 10, "generators": {"diesel": 4}},
            {"label": "Fuel price +20 %", "npc": 53.1e6, "delta_pct": 6.2, "mix": "PV 12 MW", "unserved_mwh": 0, "mix_changed": True, "pv_mw": 12, "bess_mw": 5, "bess_mwh": 10, "generators": {"diesel": 3}},
            {"label": "Fuel price -20 %", "npc": 47.1e6, "delta_pct": -5.8, "mix": "PV 9 MW", "unserved_mwh": 0, "mix_changed": False, "pv_mw": 9, "bess_mw": 5, "bess_mwh": 10, "generators": {"diesel": 4}},
        ],
    },
}

TEXT_CHECK = """svg => {
  const vb = svg.viewBox.baseVal, boxes = [...svg.querySelectorAll('text')].filter(t => t.textContent.trim() && t.getClientRects().length)
    .map(t => { const r = t.getBoundingClientRect(); return {t: t.textContent, l: r.left, r: r.right, top: r.top, b: r.bottom}; });
  const s = svg.getBoundingClientRect(), k = vb.width ? s.width / vb.width : 1, out = [];
  for (const a of boxes) if (a.l < s.left - 1 || a.r > s.right + 1 || a.top < s.top - 1 || a.b > s.bottom + 1) out.push('outside: ' + a.t);
  for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
    const a = boxes[i], c = boxes[j], tol = 1.5 * k;
    if (a.l < c.r - tol && c.l < a.r - tol && a.top < c.b - tol && c.top < a.b - tol) out.push('overlap: ' + a.t + ' | ' + c.t);
  }
  return out;
}"""


class PageChartsTest(unittest.TestCase):
    def test_sensitivity_reliability_economics_charts(self):
        source = source_run()
        if source is None:
            self.skipTest("no finished run available")
        run_id = uuid.uuid4().hex
        target = RUNS / run_id
        shutil.copytree(source, target)
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        self.assertNotEqual(port, 8765)
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)], cwd=ROOT,
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(60):
                try:
                    urlopen(base + "/", timeout=2).read()
                    break
                except Exception:
                    time.sleep(0.5)
            with sync_playwright() as p:
                browser = p.chromium.launch(channel="msedge", headless=True)
                context = browser.new_context(viewport={"width": 1500, "height": 1000}, accept_downloads=True)
                page = context.new_page()
                errors = []
                page.on("pageerror", lambda e: errors.append(str(e)))
                page.route("**/api/x/sensitivity_status*", lambda route: route.fulfill(
                    status=200, content_type="application/json", body=json.dumps(FAKE_REPORT)))
                page.goto(f"{base}/?run={run_id}")
                page.wait_for_timeout(3000)
                page.get_by_role("button", name="SOLVE", exact=True).click()
                page.wait_for_function("() => document.querySelectorAll('#result-charts .gs-chart svg').length >= 4", timeout=60000)
                page.locator("#tab-analyze").click()

                def check(selector, minimum, label):
                    page.wait_for_function(f"() => document.querySelectorAll({json.dumps(selector)}).length >= {minimum}", timeout=60000)
                    charts = page.locator(selector)
                    for i in range(charts.count()):
                        chart = charts.nth(i)
                        chart.scroll_into_view_if_needed()
                        for action in ["png", "svg", "csv", "fullscreen"]:
                            self.assertGreater(chart.locator(f"[data-gs-action='{action}']").count(), 0, f"{label} {i} {action}")
                        problems = chart.locator("svg").first.evaluate(TEXT_CHECK)
                        self.assertEqual(problems, [], f"{label} chart {i}: {problems}")
                    return charts

                page.locator("#analysis-tabs [data-pane='sensitivity']").click()
                charts = check("#sens-results .gs-chart", 2, "sensitivity")
                with page.expect_download() as info:
                    charts.first.locator("[data-gs-action='png']").click()
                data = Path(info.value.path()).read_bytes()
                self.assertEqual(data[:8], b"\x89PNG\r\n\x1a\n")
                self.assertGreater(len(data), 5000)
                self.assertGreaterEqual(int.from_bytes(data[16:20], "big"), 3000)

                page.locator("#analysis-tabs [data-pane='reliability']").click()
                charts = check("#rel-results .gs-chart", 2, "reliability")
                with page.expect_download() as info:
                    charts.first.locator("[data-gs-action='png']").click()
                self.assertGreater(len(Path(info.value.path()).read_bytes()), 5000)

                page.locator("#analysis-tabs [data-pane='economic']").click()
                charts = check("#econ-out .gs-chart", 2, "economics")
                with page.expect_download() as info:
                    charts.first.locator("[data-gs-action='png']").click()
                self.assertGreater(len(Path(info.value.path()).read_bytes()), 5000)
                self.assertEqual(errors, [])
                browser.close()
        finally:
            server.terminate()
            server.wait(timeout=10)
            shutil.rmtree(target, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
