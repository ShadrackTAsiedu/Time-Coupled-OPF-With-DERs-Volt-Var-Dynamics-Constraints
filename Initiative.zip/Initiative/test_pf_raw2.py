"""RAW export topology consistency (Python rule check + guarded PSS/E), 0 MW units, autoshunt and the hour selector."""
import json
import re
import shutil
import tempfile
import unittest
from pathlib import Path

import extensions
import power_flow as pf
from test_power_flow import diagram, SCRATCH
from test_pf_fixes import FixtureMixin, NODES, LINES

HERE = Path(__file__).resolve().parent
UI = HERE / "generation_ui"

MESSY_NODES = [("g", "grid"), ("b", "bus"), ("l", "load"), ("pv", "pv"), ("bess", "bess"),
               ("l2", "load"), ("l3", "load"),                      # orphan Loads, no wire
               ("b2", "bus"), ("l4", "load"), ("ng", "ng"),         # island 2, tied by an out-of-service line
               ("b3", "bus"), ("sh", "shunt"),                      # island 3 (shunt-only bus), and a shunt on the main bus
               ("sh2", "shunt")]
MESSY_LINES = [("w1", "g", "b", 0), ("w2", "b", "l", 0), ("w3", "pv", "b", 0), ("w4", "bess", "b", 0),
               ("w5", "b", "b2", 1.0), ("w6", "b2", "l4", 0), ("w7", "ng", "b2", 0),
               ("w8", "b3", "sh", 0), ("w9", "b", "sh2", 0)]


def messy_network(tie_in_service=False):
    diag = diagram(MESSY_NODES, MESSY_LINES)
    for n in diag["nodes"]:
        if n["id"] == "sh":
            n["electrical"] = dict(shunt_mvar=3.0)
        if n["id"] == "sh2":
            n["electrical"] = dict(shunt_mvar=1.2)
    if not tie_in_service:
        next(e for e in diag["lines"] if e["id"] == "w5")["electrical"] = dict(in_service=False)
    import network_topology
    diag = network_topology.pf_view(diag)
    return pf.build_network(diag, caps=dict(pv=2.0, bess=1.0, ng=1.5), peak_load_mw=3.0)


class ConsistencyCheckTests(unittest.TestCase):
    def test_checker_flags_the_reported_errors(self):
        raw = pf.export_raw(pf.build_network(diagram(NODES, LINES), caps=dict(pv=2.0), peak_load_mw=2.0),
                            dict(load_mw=2.0, gens={}))
        self.assertEqual(pf.raw_consistency_problems(raw), [])
        bad = raw.replace("0 / END OF BUS DATA", "4003, 'LOAD_11_3', 11.0, 1, 1, 1, 1, 1.0, 0.0, 1.05, 0.95, 1.1, 0.9\r\n0 / END OF BUS DATA")
        self.assertTrue(any("0 in-service branches connected to type 1 bus 4003" in p for p in pf.raw_consistency_problems(bad)))

    def test_messy_topology_is_consistent(self):
        net = messy_network()
        text, notes = pf.export_raw_notes(net, dict(load_mw=3.0, gens=dict(pv=dict(p=1.0), ng=dict(p=0.5))))
        self.assertEqual(pf.raw_consistency_problems(text), [])
        names = " ".join(re.findall(r"'([^']*)'", "\n".join(text.split("END OF BUS DATA")[0].splitlines()[3:])))
        self.assertNotIn("LOAD_11_2", names)
        self.assertTrue(notes, "dropped equipment must be reported")
        self.assertIn("1.2000", text.split("END OF LOAD DATA")[1].split("END OF FIXED SHUNT DATA")[0], "shunt on the main bus is kept")

    def test_messy_with_tie_in_service_keeps_second_island_connected(self):
        net = messy_network(tie_in_service=True)
        text, notes = pf.export_raw_notes(net, dict(load_mw=3.0, gens=dict(pv=dict(p=1.0))))
        self.assertEqual(pf.raw_consistency_problems(text), [])
        self.assertIn("4001", text)
        self.assertEqual(len(re.findall(r"^4\d\d\d, '1'", text, re.M)), 2)  # wired Load + island-2 Load, no orphans

    def test_island_with_its_own_forming_unit_gets_its_own_swing(self):
        net = messy_network()
        text, _ = pf.export_raw_notes(net, dict(load_mw=3.0, gens={}))
        buses = [l for l in text.split("END OF BUS DATA")[0].splitlines()[3:] if "'" in l]
        self.assertEqual(sum(1 for l in buses if l.split(",")[3].strip() == "3"), 2)  # grid island + genset island
        self.assertEqual(pf.raw_consistency_problems(text), [])

    def test_island_without_a_source_is_dropped(self):
        diag = diagram(MESSY_NODES[:5] + MESSY_NODES[7:10], MESSY_LINES[:7])
        next(e for e in diag["lines"] if e["id"] == "w5")["electrical"] = dict(in_service=False)
        net = pf.build_network(diag, caps=dict(pv=2.0, bess=1.0, ng=0.0), peak_load_mw=3.0)
        text, notes = pf.export_raw_notes(net, dict(load_mw=3.0, gens={}))
        self.assertEqual(pf.raw_consistency_problems(text), [])
        self.assertEqual(len([l for l in text.split("END OF BUS DATA")[0].splitlines()[3:] if "'" in l]), 6)
        self.assertTrue(any("no in-service path" in n for n in notes), notes)

    def test_out_of_service_generator_branch_and_zero_mw_unit(self):
        diag = diagram(NODES + [("ng", "ng")], LINES + [("w4", "ng", "b", 0)])
        net = pf.build_network(diag, caps=dict(pv=2.0, ng=0.0), peak_load_mw=2.0)
        text, notes = pf.export_raw_notes(net, dict(load_mw=2.0, gens={}))
        self.assertEqual(pf.raw_consistency_problems(text), [])
        self.assertTrue(any("0 MW" in n for n in notes))

    def test_drop_unbuilt_removes_unbuilt_generator_and_wire_only_from_the_model(self):
        diag = diagram(NODES + [("h2", "h2")], LINES + [("w4", "h2", "b", 0)])
        out = pf._drop_unbuilt(dict(diag, _notes=[]), {"pv", "grid"})
        self.assertNotIn("h2", [n["id"] for n in out["nodes"]])
        self.assertNotIn("w4", [e["id"] for e in out["lines"]])
        self.assertIn("h2", [n["id"] for n in diag["nodes"]], "input drawing untouched")
        self.assertTrue(any("0 MW" in n for n in out["_notes"]))


class RunFixture(FixtureMixin):
    def test_zero_capacity_technology_is_left_out_of_the_electrical_model(self):
        self.edit_request(lambda t: [t["diagrams"][self.code]["nodes"].append(dict(id="h2", kind="h2", label="H2", x=900, y=100)),
                                     t["diagrams"][self.code]["lines"].append(dict(id="w9", source="h2", target="b", owner="shared", length_km=0, cost_per_km=0))])
        result = self.run_dir / f"result_{self.code}.json"
        data = json.loads(result.read_text())
        data["eligible_technologies"].append("h2")
        result.write_text(json.dumps(data))
        res = pf._handle(dict(action="raw", run_id="a" * 32, scenario=self.code))
        self.assertEqual(res["problems"], [])
        self.assertNotIn("H2_GEN", res["text"])
        self.assertTrue(any("0 MW was built" in n for n in res["notes"]), res["notes"])
        stored = json.loads((self.run_dir / "request.json").read_text())["topology"]["diagrams"][self.code]
        self.assertIn("h2", [n["id"] for n in stored["nodes"]])

    def test_raw_export_with_orphan_loads_reports_notes(self):
        self.edit_request(lambda t: t["diagrams"][self.code]["nodes"].extend(
            dict(id=f"x{i}", kind="load", label=f"X{i}", x=100 * i, y=900) for i in (1, 2)))
        res = pf._handle(dict(action="raw", run_id="a" * 32, scenario=self.code))
        self.assertEqual(res["problems"], [])
        self.assertIn("Exported.", res["message"])
        self.assertIn("no wire were ignored", res["message"])

    def weak_grid(self, stack=False):
        def edit(t):
            d = t["diagrams"][self.code]
            for n in d["nodes"]:
                if n["id"] == "g":
                    n["electrical"] = dict(sc_mva=40, xr=5)
                if stack and n["id"] in ("b", "pv", "l"):
                    n["electrical"] = dict(n.get("electrical") or {}, shunt_mvar=9.6)
        self.edit_request(edit)

    def drawing(self):
        return json.loads((self.run_dir / "request.json").read_text())["topology"]["diagrams"][self.code]

    def test_autoshunt_sizes_once_replaces_stacks_and_prices_once(self):
        self.weak_grid(stack=True)
        before = (self.run_dir / "request.json").read_text()
        dry = pf.autoshunt("a" * 32, self.code, apply=False)
        self.assertFalse(dry["applied"])
        self.assertEqual((self.run_dir / "request.json").read_text(), before, "apply=False must not write")
        self.assertAlmostEqual(dry["existing_mvar"], 0.0, places=4)  # unmarked stored bus-level caps are stale auto values, ignored on load
        first = pf.autoshunt("a" * 32, self.code)
        self.assertTrue(first["applied"])
        self.assertLess(first["total_mvar"], 28.8, "the over-compensating stack is replaced")
        second = pf.autoshunt("a" * 32, self.code)
        self.assertEqual(second["total_mvar"], first["total_mvar"])
        self.assertEqual(second["existing_mvar"], first["total_mvar"])
        self.assertEqual(second["cost_usd"], first["cost_usd"])
        d = self.drawing()
        shunts = [n for n in d["nodes"] if n["kind"] == "shunt"]
        self.assertEqual(len(shunts), 1 if first["total_mvar"] else 0)
        self.assertFalse([n for n in d["nodes"] if n["kind"] != "shunt" and (n.get("electrical") or {}).get("shunt_mvar")])
        net = pf._prepare(pf._run_context(self.run_dir, self.code), self.code, None, None, pf._read_dispatch(self.run_dir / f"dispatch_{self.code}.csv"))
        self.assertAlmostEqual(sum(b["shunt_mvar"] for b in net.buses), first["total_mvar"], places=4)
        cost = pf.compliance_cost("a" * 32, self.code, [second["suggestion"]])
        self.assertEqual(cost["total_usd"], first["cost_usd"], "bank priced once")
        self.assertEqual(pf.compliance_cost("a" * 32, self.code, [])["total_usd"], first["cost_usd"])
        raw = pf._handle(dict(action="raw", run_id="a" * 32, scenario=self.code))
        self.assertEqual(raw["problems"], [])
        if first["total_mvar"]:
            self.assertIn(f"{first['total_mvar']:.4f}", raw["text"].split("FIXED SHUNT DATA")[0].split("END OF LOAD DATA")[-1] +
                          raw["text"].split("END OF LOAD DATA, BEGIN FIXED SHUNT DATA")[1])

    def test_autoshunt_without_stored_drawing_stores_only_on_apply(self):
        self.edit_request(lambda t: t["diagrams"].clear())
        dry = pf.autoshunt("a" * 32, self.code, apply=False)
        self.assertTrue(any("No single-line diagram" in n for n in dry["notes"]))
        self.assertFalse(json.loads((self.run_dir / "request.json").read_text())["topology"]["diagrams"])
        pf.autoshunt("a" * 32, self.code, apply=True)
        self.assertTrue(json.loads((self.run_dir / "request.json").read_text())["topology"]["diagrams"][self.code]["nodes"])

    def test_hours_action_describes_the_hour_selector(self):
        info = pf._handle(dict(action="hours", run_id="a" * 32, scenario=self.code))
        self.assertTrue(info["hourly"])
        self.assertEqual(info["start"], "2030-01-01 00:00:00")
        self.assertIn("peak_timestamp", info)

    def test_page_has_hour_selector_and_no_overlap_css(self):
        js = (UI / "pfpage.js").read_text(encoding="utf-8")
        css = (UI / "pfpage.css").read_text(encoding="utf-8")
        self.assertNotIn("Hour index", js)
        for needle in ("pfp-datetime", "pfp-hour-help", "Hour 0 =", "peak hour is"):
            self.assertIn(needle, js)
        self.assertIn(".pfp-hourbox{flex:1 0 100%", css)
        self.assertNotIn("style=", js.replace('"style="', ""))


try:
    import psse_check
    PSSE = psse_check.available()
except Exception:  # pragma: no cover
    PSSE = False


@unittest.skipUnless(PSSE, "psspy (PSS/E 36.5, Python 3.14) is not available")
class PsseTests(unittest.TestCase):
    def test_messy_and_normal_exports_solve_in_psse(self):
        folder = Path(tempfile.mkdtemp(dir=HERE))
        try:
            cases = {"normal": pf.build_network(diagram(NODES, LINES), caps=dict(pv=2.0), peak_load_mw=2.0),
                     "messy": messy_network(), "messy_tied": messy_network(True)}
            paths = []
            for name, net in cases.items():
                path = folder / f"{name}.raw"
                path.write_text(pf.export_raw(net, dict(load_mw=3.0, gens=dict(pv=dict(p=1.0)))), encoding="utf-8", newline="")
                paths.append(str(path))
            for entry in psse_check.check(paths):
                self.assertTrue(entry["ok"], entry)
        finally:
            shutil.rmtree(folder, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
