"""Executive decision dashboard data for the Result Summary page and the quick Summary PDF.

Route: GET /api/x/summary_dashboard?run_id=
Everything is computed from the saved run (results, workflow, economic metrics, sensitivity and reliability files)
so the page never depends on other pages having been opened. All display strings are formatted here once, so the
web dashboard and the PDF show identical numbers.

Definitions used throughout:
  * Ranking is by total NPC (net present cost, including any applied technical corrections). Technical status
    is a remark; corrections are applied afterwards.
  * Upfront investment = new equipment capex + grid upgrade (both are year-0 outlays).
  * Annual saving = average over the horizon of (reference cash cost - option cash cost), nominal dollars.
  * Renewable share = (optimized solar + wind + planned renewables) / demand served, averaged over the horizon.
  * Net basis NPV/IRR include the reference's avoided upgrade; the operating basis counts operating savings
    against the option's own capex only.
"""

import currency
import extensions
import report
import workflow
from explain import explain, upfront

SHORT_HISTORY_HOURS = 2 * 8000


def num(value, decimals=2):
    if value is None:
        return "n/a"
    text = f"{float(value):,.{decimals}f}"
    return "0" if float(text.replace(",", "")) == 0 and text.startswith("-") else text


def usd(value, decimals=2):
    """Millions of dollars, e.g. $149.67M; sub-million values are shown in thousands."""
    if value is None:
        return "n/a"
    v = float(value) * currency.fx()
    sign = "-" if v < 0 else ""
    if abs(v) >= 1e6:
        return f"{sign}{currency.prefix()}{num(abs(v) / 1e6, decimals)}M"
    return f"{sign}{currency.prefix()}{num(abs(v) / 1e3, decimals)}k"


def pct(value, decimals=1):
    return "n/a" if value is None else f"{num(float(value) * 100, decimals)}%"


def years(value):
    return "n/a" if value is None else f"{num(value, 1)} yr"


def annual_rows(result):
    return result["economics"].get("annual") or []


def renewable_share(result):
    rows = annual_rows(result)
    demand = sum(float(r.get("demand_mwh") or 0) for r in rows)
    if demand <= 0:
        return None
    renewable = sum(float(r.get("optimized_solar_mwh") or 0) + float(r.get("wind_generation_mwh") or 0)
                    + float(r.get("planned_renewable_mwh") or 0) for r in rows)
    return renewable / demand


def peak_grid_import(result):
    """Highest grid import (MW): the 15-minute check if available, else the highest hourly peak."""
    q = (result.get("validation") or {}).get("max_quarter_hour_grid_mw")
    hourly = max([float(r.get("grid_peak_mw") or 0) for r in annual_rows(result)] + [0])
    return max(hourly, float(q)) if q is not None else hourly


def grid_limit(run, result):
    adequacy = result.get("adequacy") or {}
    ref_limit = adequacy.get("reference_grid_limit_mw")
    value = ref_limit if ref_limit else run["values"].get("grid_limit")
    return float(value) if value not in (None, "") else None


def avg_annual_saving(result, ref):
    a, b = annual_rows(ref), annual_rows(result)
    n = min(len(a), len(b))
    if not n:
        return None
    return sum(float(a[i].get("total_cash_cost") or 0) - float(b[i].get("total_cash_cost") or 0) for i in range(n)) / n


def history_hours(run):
    audit = (run["config"].get("forecast_audit") or {}).get("historical") or {}
    value = audit.get("hourly_records") or audit.get("raw_records")
    if not value:
        value = ((run["config"].get("planning") or {}).get("data_period") or {}).get("hours")
    return int(value) if value else None


def technical_line(entry):
    status = entry.get("technical_status")
    if status in (None, "NOT_RUN"):
        return None
    count = int(entry.get("violation_count") or 0)
    items = int(entry.get("applied_items") or 0)
    cost = float(entry.get("applied_cost_usd") or 0)
    text = f"{count:,} finding{'s' if count != 1 else ''}"
    if items:
        text += f"; {items:,} correction{'s' if items != 1 else ''} applied (+{usd(cost)} in total NPC)"
    text += "; corrections are applied afterwards and are not in the NPC" if not items else ""
    island = entry.get("islanded")
    if isinstance(island, dict) and island.get("chip"):
        text += f"; {island['chip']} (informational)"
    return text


def level_of(status):
    return {"PASS": "pass", "WARN": "warn", "FAIL": "fail"}.get(str(status or "").upper(), "info")


def build(run_id, run=None):
    run = run or report.load_run(run_id)
    folder, results, values = run["folder"], run["results"], run["values"]
    flow = workflow.get(run_id)
    entries = {e["code"]: e for e in flow["scenarios"]}
    metrics = report.economic_rows(run)
    ref_code = run["reference"] if run["reference"] in results else None
    ref = results.get(ref_code)
    rec = flow.get("recommended") or {}
    code = rec.get("code") or report.pick_best(results)[0]
    result, entry, metric = results[code], entries.get(code, {}), metrics.get(code) or {}
    econ = result["economics"]
    is_reference = code == ref_code
    ranked = [e for e in entries.values() if e.get("rank")]
    used, _ = report.effective_techs(run, code)
    mix = report.caps_text(result["caps"], used)

    saving = None if is_reference or not ref else avg_annual_saving(result, ref)
    share, ref_share = renewable_share(result), (renewable_share(ref) if ref else None)
    peak, limit = peak_grid_import(result), grid_limit(run, result)
    unserved = float((result.get("adequacy") or {}).get("unserved_mwh") or econ.get("unserved_mwh") or 0)
    outlay = upfront(econ)
    ref_name = ref["name"] if ref else None
    versus = f"vs {ref_name}" if ref_name else ""

    def irr_text(irr, note):
        return pct(irr, 2) if irr is not None else "undefined" + (" (no additional investment)" if note else "")

    def payback(simple, note, discounted):
        if simple is None:
            return "not within horizon"
        return "no net outlay" if simple == 0 else f"{years(simple)} (discounted {years(discounted) if discounted is not None else 'beyond horizon'})"

    ref_npc = ref["economics"]["npc"] if ref else None
    npc_note = ("Reference case" if is_reference or not ref_npc else
                f"{pct((econ['npc'] - ref_npc) / ref_npc)} {versus}")
    kpis = [
        dict(key="npc", label="Net present cost", value=usd(econ["npc"]), note=npc_note),
        dict(key="lcoe",         label="LCOE", value=currency.money(metric['lcoe'], 1, 2, '/MWh') if metric.get("lcoe") is not None else "n/a",
                     note="Levelized cost of energy: discounted lifetime cost / discounted energy served"),
        dict(key="upfront", label="Upfront investment", value=usd(outlay),
             note="Equipment + grid upgrade at year 0" + (f"; reference upgrade of {usd(float(ref['economics'].get('upgrade_pv') or 0))} avoided"
                                                             if ref and not is_reference and float(ref["economics"].get("upgrade_pv") or 0) > 0
                                                             and float(econ.get("upgrade_pv") or 0) == 0 else "")),
        dict(key="saving", label="Avg annual saving", value=usd(saving) if saving is not None else "n/a",
             note=f"Nominal cash cost {versus}" if saving is not None else "No reference to compare"),
        dict(key="npv", label="NPV (net basis)", value=usd(metric.get("npv")) if metric.get("status") == "ok" else "n/a",
             note=(f"IRR {irr_text(metric.get('irr'), metric.get('irr_note'))}; payback "
                   f"{payback(metric.get('simple_payback_years'), metric.get('simple_payback_note'), metric.get('discounted_payback_years'))}"
                   if metric.get("status") == "ok" else "Reference case")),
        dict(key="npv_op", label="NPV (operating)", value=usd(metric.get("op_npv")) if metric.get("status") == "ok" else "n/a",
             note=(f"IRR {irr_text(metric.get('op_irr'), metric.get('op_irr_note'))}; payback "
                   f"{payback(metric.get('op_simple_payback_years'), '', metric.get('op_discounted_payback_years'))}"
                   if metric.get("status") == "ok" else "Reference case")),
        dict(key="renewable", label="Renewable share", value=pct(share),
             note=(f"Reference {pct(ref_share)}; " if ref_share is not None and not is_reference else "") + "solar + wind + planned, of demand"),
        dict(key="co2", label="CO2e avoided" if (metric.get("co2e_avoided_t") or 0) >= 0 else "CO2e increase",
             value=f"{num(abs(metric.get('co2e_avoided_t')), 0)} t" if metric.get("co2e_avoided_t") is not None else "n/a",
             note=(f"Over the horizon {versus}" if metric.get("co2e_avoided_t") is not None
                   else "Emission factors not confirmed in inputs")),
        dict(key="peak", label="Peak grid import", value=f"{num(peak, 2)} MW",
             note=(f"Limit {num(limit, 2)} MW ({pct(peak / limit, 0)} used)" if limit else "No limit set"),
             level="warn" if limit and peak > limit * 1.0001 else "pass"),
        dict(key="unserved", label="Unserved energy", value=f"{num(unserved, 2)} MWh",
             note="All demand served" if unserved < 1e-3 else "Demand not fully served", level="pass" if unserved < 1e-3 else "fail"),
    ]

    tech = technical_line(entry)
    tech_status = entry.get("technical_status")
    sens = report.sensitivity_for(folder)
    rel = report.reliability_for(folder, code)
    analyses = [dict(key="economic", label="Economic", pane="economic", level="info", state="done",
                     headline=f"{len(ranked)} options ranked by total NPC"
                              + (f"; {rec.get('name') or result['name']} ranks 1" if entry.get("rank") == 1 else ""),
                     detail="NPC, LCOE, NPV, IRR and payback against the reference; investment, savings and CO2e.")]
    analyses.append(dict(key="technical", label="Technical power flow", pane="technical", state="done" if tech else "not_run",
                         level=level_of(tech_status) if tech else "none",
                         headline=tech or "Not run", detail="AC power-flow screening (normal and N-1) of the network with the option's equipment; remark only.",
                         action="Run power flow"))
    if sens:
        report_data = sens["report"]
        swings = sorted(report_data["swings"], key=lambda s: -abs(float(s.get("swing") or 0)))[:3]
        risk = report_data.get("risk") or {}
        other = f" (run for {sens['scenario_id']})" if sens["scenario_id"] and sens["scenario_id"] != code else ""
        analyses.append(dict(key="sensitivity", label="Sensitivity", pane="sensitivity", state="done", level="info",
                             headline=("Top drivers: " + ", ".join(f"{s['label']} ({usd(s['swing'])})" for s in swings)
                                       + (f"; NPC P50 {usd(risk.get('p50'))}, P10-P90 {usd(risk.get('p10'))} to {usd(risk.get('p90'))}"
                                          if risk.get("p50") is not None else "") + other),
                             detail="One-at-a-time NPC swings and a probabilistic NPC range."))
    else:
        analyses.append(dict(key="sensitivity", label="Sensitivity", pane="sensitivity", state="not_run", level="none",
                             headline="Not run", detail="One-at-a-time NPC swings and a probabilistic NPC range.", action="Run sensitivity"))
    if rel:
        summary = rel.get("summary") or {}
        analyses.append(dict(key="reliability", label="Reliability", pane="reliability", state="done",
                             level=level_of(report.reliability_verdict(rel)),
                             headline=(f"LOLE {num(summary.get('lole_h_yr'), 2)} h/yr, "
                                       f"EENS {num(summary.get('eue_mwh_yr'), 1)} MWh/yr, outage cost {usd(summary.get('cost_yr'))}/yr"
                                       + (f"; best measure: {summary['best_measure']}" if summary.get("best_measure") else "")),
                             detail="Loss-of-load hours and expected unserved energy (EENS) under random outages; cost at the value of lost load.",
                             action="Run reliability"))
    else:
        analyses.append(dict(key="reliability", label="Reliability", pane="reliability", state="not_run", level="none",
                             headline="Not run", detail="Loss-of-load hours and expected unserved energy under random outages.",
                             action="Run reliability"))

    show_adjusted = any(float(e.get("fix_cost_usd") or 0) > 0 or float(e.get("applied_cost_usd") or 0) > 0 for e in entries.values())
    table = []
    for code_, r in results.items():
        e, m = entries.get(code_, {}), metrics.get(code_) or {}
        res_ref_npc = ref["economics"]["npc"] if ref else None
        if code_ == ref_code:
            status = "Reference"
        elif e.get("is_recommended"):
            status = "Recommended"
        elif not e.get("rank"):
            status = "Excluded: demand not fully served"
        elif e.get("same_mix_as"):
            status = "Same equipment as " + ", ".join(e["same_mix_as"])
        else:
            status = "Ranked"
        table.append(dict(
            code=code_, name=r["name"], rank=e.get("rank"), status=status, recommended=bool(e.get("is_recommended")),
            mix=report.caps_text(r["caps"], report.effective_techs(run, code_)[0]),
            npc=usd(e.get("total_npc", r["economics"]["npc"])),
            adjusted=usd(e.get("adjusted_npc")) if show_adjusted else None,
            versus=pct((r["economics"]["npc"] - res_ref_npc) / res_ref_npc) if res_ref_npc and code_ != ref_code else "-",
            upfront=usd(upfront(r["economics"])), unserved=f"{num(e.get('unserved_mwh', 0), 2)} MWh",
            technical=e.get("technical_status") if e.get("technical_status") not in (None, "NOT_RUN") else "Not run",
            technical_level=level_of(e.get("technical_status")), npv=usd(m.get("npv")) if m.get("status") == "ok" else "-"))
    table.sort(key=lambda row: (row["rank"] is None, row["rank"] or 0))

    warnings = []
    if unserved >= 1e-3:
        warnings.append(dict(level="fail", text=f"{result['name']} leaves {num(unserved, 2)} MWh of demand unserved."))
    excluded = [e["code"] for e in entries.values() if not e.get("rank") and e["code"] != ref_code]
    if excluded:
        warnings.append(dict(level="warn", text="Excluded from the ranking because demand is not fully served: "
                                                + ", ".join(f"{c} ({num(entries[c].get('unserved_mwh', 0), 1)} MWh)" for c in excluded) + "."))
    if tech_status == "FAIL":
        warnings.append(dict(level="fail", text=f"Technical power flow still fails for {result['name']} "
                                                f"({num(entry.get('violation_count') or 0, 0)} findings); apply the suggested corrections before committing to this option."))
    elif tech_status == "WARN":
        warnings.append(dict(level="warn", text=f"Technical power flow shows warnings for {result['name']}."))
    elif not tech:
        warnings.append(dict(level="info", text="Technical power flow has not been run; the network feasibility of the recommended option is unverified."))
    hours = history_hours(run)
    if hours and hours < SHORT_HISTORY_HOURS:
        warnings.append(dict(level="warn", text=f"Only {num(hours / 8760, 1)} year of historical demand was available; seasonal "
                                                "and year-to-year variation is not represented."))
    if entry.get("same_mix_as"):
        warnings.append(dict(level="info", text=f"{result['name']} builds the same equipment as {', '.join(entry['same_mix_as'])}; the NPC is identical."))
    for note in rec.get("notes") or []:
        warnings.append(dict(level="info", text=str(note)))
    if metric.get("co2e_avoided_t") is None and metric.get("status") == "ok":
        warnings.append(dict(level="warn", text="CO2e is not reported because the emission factors are not confirmed in the inputs."))
    for text in metric.get("warnings") or []:
        warnings.append(dict(level="warn", text=str(text)))
    if rel and report.reliability_verdict(rel) in ("WARN", "FAIL"):
        warnings.append(dict(level="warn", text="Reliability screening is " + report.reliability_verdict(rel)
                                                + f": expected {num((rel.get('summary') or {}).get('eue_mwh_yr'), 1)} MWh/yr unserved under outages."))
    total = result["caps"].get("microgrid_total_ac_mw") or 0
    if total and values.get("microgrid_max_mw") and total >= float(values["microgrid_max_mw"]) - .01:
        warnings.append(dict(level="info", text=f"On-site capacity ({num(total, 1)} MW) is at the maximum you set; a higher limit could change the result."))

    assumptions = [
        ("Study horizon", f"{values.get('horizon_years', 'n/a')} year{'' if str(values.get('horizon_years')) == '1' else 's'} from {values.get('start_year', 'n/a')}"),
        ("Discount rate / inflation", f"{pct(values.get('discount'))} / {pct(values.get('inflation'))}"),
        ("Carbon price", f"{currency.money(values.get('carbon_price'), 1, 2)}/t CO2e"),
        ("Grid import limit", f"{num(values.get('grid_limit'), 2)} MW" + (f" (reference {num(values.get('reference_grid_limit'), 2)} MW)"
                                                                          if values.get("reference_grid_limit") else "")),
        ("On-site capacity range", f"{num(values.get('microgrid_min_mw'), 2)} to {num(values.get('microgrid_max_mw'), 2)} MW AC"),
        ("Grid tariff structure", str(values.get("tariff_mode") or "n/a").replace("_", " ")),
        ("Historical demand data", f"{num(hours / 8760, 2)} years of hourly records" if hours else "n/a"),
        ("Reference case", f"{ref['name']} ({ref_code})" if ref else "None"),
        ("Ranking", "Total NPC (lowest is best); technical status is a remark, corrections are applied afterwards"),
    ]
    if rel:
        assumptions.append(("Value of lost load", f"{currency.money((rel.get('params') or {}).get('voll'), 1, 0)}/MWh"))

    rel_rows = []
    for code_, r in results.items():
        data = report.reliability_for(folder, code_)
        s = (data or {}).get("summary") or {}
        if s:
            rel_rows.append(dict(code=code_, name=r["name"], lole=float(s.get("lole_h_yr") or 0), eens=float(s.get("eue_mwh_yr") or 0),
                                 cost=float(currency.mega(s.get("cost_yr") or 0)), verdict=report.reliability_verdict(data) or "",
                                 best_measure=s.get("best_measure") or ""))
    econ_rows = []
    for row in table:
        m = metrics.get(row["code"]) or {}
        econ_rows.append(dict(code=row["code"], name=row["name"], npc=float(currency.mega(results[row["code"]]["economics"]["npc"])),
                              upfront=float(currency.mega(upfront(results[row["code"]]["economics"]))),
                              npv=(float(currency.mega(m["npv"])) if m.get("status") == "ok" and m.get("npv") is not None else None),
                              lcoe=currency.scaled(m.get("lcoe")), recommended=row["recommended"]))
    sens_detail = None
    if sens:
        sr = sens["report"]
        sens_detail = dict(
            scenario=sens["scenario_id"] or code, base_npc=float(currency.mega((sr.get("base") or {}).get("npc") or 0)),
            risk={k: (currency.scaled(v) if k in ("p10", "p50", "p90", "minimum", "maximum", "mean", "std", "stdev") and isinstance(v, (int, float)) else v)
                  for k, v in (sr.get("risk") or {}).items()},
            swings=[dict(label=s["label"] + (" *" if s.get("mix_changes") else ""), low=float(currency.mega(s["delta_low"])), high=float(currency.mega(s["delta_high"])),
                         unit=s.get("unit", ""), range=f"{num(s.get('low'), 2)} to {num(s.get('high'), 2)} {s.get('unit', '')}".strip())
                    for s in sorted(sr["swings"], key=lambda s: -abs(float(s.get("swing") or 0)))[:8]])
    detail = dict(economic=dict(rows=econ_rows, basis=ref_name or "", discount=values.get("discount")),
                  sensitivity=sens_detail, reliability=rel_rows)

    why = explain({"run_id": [run_id], "scenario": [code]})["summary"]
    return dict(
        run_id=run_id, currency=currency.prefix().strip(), reference=dict(code=ref_code, name=ref_name, npc=usd(ref["economics"]["npc"]) if ref else None),
        recommended=dict(code=code, name=result["name"], effective_name=rec.get("effective_name") or entry.get("effective_name") or result["name"],
                         rank=entry.get("rank"), count=len(ranked), mix=mix, npc=usd(econ["npc"]), why=why,
                         is_reference=is_reference, fully_supplied=unserved < 1e-3),
        kpis=kpis, analyses=analyses, detail=detail, table=table, show_adjusted=show_adjusted, assumptions=assumptions, warnings=warnings)


def route(query):
    return build((query.get("run_id") or [""])[0])


extensions.GET["summary_dashboard"] = route
