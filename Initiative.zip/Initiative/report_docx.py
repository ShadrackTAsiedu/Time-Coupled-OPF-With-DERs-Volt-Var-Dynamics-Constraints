"""Editable Word (.docx) edition of the report documents.

The HTML report (report_doc.build / build_design_doc) is the single source of content. This module converts it to a native
Word file: real Heading styles (navigation pane), SEQ-numbered figure and table captions, bookmarks and internal hyperlinks,
editable tables with repeating header rows, charts and the single-line diagram as pictures, and a header and footer with
PAGE and NUMPAGES fields. The table of contents and the lists of figures and tables are genuine Word TOC fields.

Page numbers: when Word is installed the file is laid out once in a hidden Word instance to read the page of every
bookmark, and those numbers are stored in the fields, so the contents are correct on first open. Without Word the
document is flagged to refresh its fields on open instead.
"""
import base64
import io
import json
import os
import re
import subprocess
import tempfile

import lxml.html
from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

import report_doc

MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
NAVY, GOLD, GREY, INK = "12355B", "B8860B", "5B6773", "111A24"
GOOD, WARN, BAD = "1B7F3B", "9A6B00", "B42318"
BLOCKS = {"div", "p", "ul", "ol", "table", "figure", "section", "h1", "h2", "h3", "h4", "svgph", "hr", "pre", "caption", "figcaption"}
CALLOUTS = {"decision": ("E4EEF8", NAVY), "takeaways": ("F1F5F9", NAVY), "conf": ("F2F2F2", "8A94A0"),
            "warning": ("FFF0B3", "E0A800"), "notrun": ("FFF0B3", "E0A800")}
SVG = re.compile(r"<svg\b.*?</svg>", re.S | re.I)
CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def file_name(meta, suffix=""):
    name = re.sub(r"[^\w.-]+", "_", (meta or {}).get("project_name") or "GenStudio").strip("_") or "GenStudio"
    return f"{name}{suffix}.docx"


def svg_to_png(svg, target_px=2200):
    """Rasterise an inline report SVG; the page CSS that styles axes and text is applied as attributes first."""
    import pymupdf
    svg = re.sub(r"<title>.*?</title>", "", svg, flags=re.S)
    svg = re.sub(r'(<(?:line|path|polyline)\b[^>]*\bclass="grid")', r'\1 stroke="#c9d1d9" stroke-width="1"', svg)
    svg = re.sub(r'(<(?:line|path|polyline)\b[^>]*\bclass="axis")', r'\1 stroke="#111a24" stroke-width="1.2"', svg)

    def text_tag(match):
        tag = match.group(0)
        if "fill=" not in tag and "fill:" not in tag:
            tag = tag.replace("<text", f'<text fill="#{INK.lower()}"', 1)
        if "font-size" not in tag:
            tag = tag.replace("<text", '<text font-size="11" font-family="Arial"', 1)
        return tag
    svg = re.sub(r"<text\b[^>]*>", text_tag, svg)
    head = re.match(r"<svg\b[^>]*>", svg).group(0)
    view = re.search(r'viewBox="([\d.\s-]+)"', head)
    if view and not re.search(r'\swidth="[\d.]+(?:mm|px)?"', head):
        w, h = [float(v) for v in view.group(1).split()[2:4]]
        fixed = re.sub(r'\s(?:width|height)="[^"]*"', "", head)
        svg = svg.replace(head, fixed.replace("<svg", f'<svg width="{w:g}" height="{h:g}"', 1), 1)
    with pymupdf.open(stream=svg.encode("utf-8"), filetype="svg") as doc:
        page = doc[0]
        scale = max(0.5, min(4.0, target_px / max(page.rect.width, 1)))
        pixmap = page.get_pixmap(matrix=pymupdf.Matrix(scale, scale), alpha=False)
        return pixmap.tobytes("png"), pixmap.width, pixmap.height


def shade(cell, fill):
    props = cell._tc.get_or_add_tcPr()
    for old in props.findall(qn("w:shd")):
        props.remove(old)
    node = OxmlElement("w:shd")
    node.set(qn("w:val"), "clear"); node.set(qn("w:color"), "auto"); node.set(qn("w:fill"), fill)
    props.append(node)


def borders(table, color="C9D1D9", vertical=False, left=None):
    props = table._tbl.tblPr
    for old in props.findall(qn("w:tblBorders")):
        props.remove(old)
    node = OxmlElement("w:tblBorders")
    for side in ("top", "left", "bottom", "right", "insideH", "insideV"):
        edge = OxmlElement(f"w:{side}")
        on = side in ("top", "bottom", "insideH") or (vertical and side in ("insideV", "left", "right"))
        edge.set(qn("w:val"), "single" if on else "nil")
        edge.set(qn("w:sz"), "4"); edge.set(qn("w:space"), "0"); edge.set(qn("w:color"), color)
        node.append(edge)
    props.append(node)
    if left:
        for row in table.rows:
            tcb = OxmlElement("w:tcBorders")
            edge = OxmlElement("w:left")
            edge.set(qn("w:val"), "single"); edge.set(qn("w:sz"), "24"); edge.set(qn("w:space"), "0"); edge.set(qn("w:color"), left)
            tcb.append(edge)
            row.cells[0]._tc.get_or_add_tcPr().append(tcb)


def cell_margins(table, top=40, bottom=40, side=80):
    node = OxmlElement("w:tblCellMar")
    for name, value in (("top", top), ("left", side), ("bottom", bottom), ("right", side)):
        edge = OxmlElement(f"w:{name}")
        edge.set(qn("w:w"), str(value)); edge.set(qn("w:type"), "dxa")
        node.append(edge)
    table._tbl.tblPr.append(node)


def row_flags(row, header=False):
    props = row._tr.get_or_add_trPr()
    split = OxmlElement("w:cantSplit")
    props.append(split)
    if header:
        props.append(OxmlElement("w:tblHeader"))


def bookmark_name(anchor):
    return "b_" + re.sub(r"\W", "_", anchor)[:36]


def ptab(par, alignment="right"):
    run = par.add_run()
    node = OxmlElement("w:ptab")
    node.set(qn("w:relativeTo"), "margin"); node.set(qn("w:alignment"), alignment); node.set(qn("w:leader"), "none")
    run._r.append(node)
    return run


def mark_run(kind, instruction=None):
    run = OxmlElement("w:r")
    if instruction is None:
        node = OxmlElement("w:fldChar"); node.set(qn("w:fldCharType"), kind)
    else:
        node = OxmlElement("w:instrText"); node.set(qn("xml:space"), "preserve"); node.text = f" {instruction} "
    run.append(node)
    return run


def text_run(text, bold=False):
    run = OxmlElement("w:r")
    if bold:
        props = OxmlElement("w:rPr"); props.append(OxmlElement("w:b")); run.append(props)
    node = OxmlElement("w:t"); node.set(qn("xml:space"), "preserve"); node.text = text
    run.append(node)
    return run


def tab_run():
    run = OxmlElement("w:r")
    run.append(OxmlElement("w:tab"))
    return run


def field(par, instruction, text=""):
    for kind in ("begin", None, "separate", "text", "end"):
        run = par.add_run()
        if kind == "text":
            run.text = text
            continue
        if kind is None:
            node = OxmlElement("w:instrText"); node.set(qn("xml:space"), "preserve"); node.text = f" {instruction} "
            run._r.append(node)
            continue
        node = OxmlElement("w:fldChar"); node.set(qn("w:fldCharType"), kind)
        run._r.append(node)


def font_name(style, name="Calibri"):
    props = style.element.get_or_add_rPr()
    fonts = props.find(qn("w:rFonts"))
    if fonts is None:
        fonts = OxmlElement("w:rFonts"); props.append(fonts)
    for key in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
        fonts.set(qn(key), name)
    for key in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
        if fonts.get(qn(key)) is not None:
            del fonts.attrib[qn(key)]


def hex_color(value):
    return RGBColor.from_string(value)


class Converter:
    def __init__(self, meta=None, pages=None, total=None):
        self.doc = Document()
        self.meta = meta or {}
        self.pages = pages
        self.total = total
        self.pictures = 0
        self.fresh = set()
        self.front = False
        self.landscape = False
        self.anchor = None
        self.marks = []
        self.mark_id = 0
        self.setup()

    def setup(self):
        doc = self.doc
        section = doc.sections[0]
        section.page_width, section.page_height = Cm(21.0), Cm(29.7)
        section.left_margin = section.right_margin = Cm(2.0)
        section.top_margin, section.bottom_margin = Cm(2.2), Cm(2.0)
        section.header_distance = section.footer_distance = Cm(1.0)
        self.width = Cm(17.0)
        styles = doc.styles
        normal = styles["Normal"]
        normal.font.size = Pt(10.5); normal.font.color.rgb = hex_color(INK)
        font_name(normal)
        normal.paragraph_format.space_after = Pt(6)
        normal.paragraph_format.line_spacing = 1.12
        for name, size, before, after, brk in (("Heading 1", 20, 0, 10, True), ("Heading 2", 14, 14, 5, False), ("Heading 3", 11.5, 10, 4, False)):
            style = styles[name]
            style.font.size = Pt(size); style.font.bold = True; style.font.italic = False; style.font.color.rgb = hex_color(NAVY)
            font_name(style)
            style.paragraph_format.space_before, style.paragraph_format.space_after = Pt(before), Pt(after)
            style.paragraph_format.page_break_before = brk
            style.paragraph_format.keep_with_next = True
        for name, base, size, brk in (("Front heading", "Normal", 20, True), ("Front subheading", "Normal", 13, False)):
            style = styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
            style.base_style = styles[base]
            style.font.size = Pt(size); style.font.bold = True; style.font.color.rgb = hex_color(NAVY)
            style.paragraph_format.space_before, style.paragraph_format.space_after = Pt(0 if brk else 12), Pt(8)
            style.paragraph_format.page_break_before = brk
            style.paragraph_format.keep_with_next = True
        for name in ("Figure caption", "Table caption"):
            style = styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
            style.base_style = styles["Caption"]
            style.font.size = Pt(9); style.font.bold = False; style.font.italic = False; style.font.color.rgb = hex_color(GREY)
            style.paragraph_format.space_before, style.paragraph_format.space_after = Pt(4), Pt(8)
        styles["Table caption"].paragraph_format.keep_with_next = True
        styles["Table caption"].paragraph_format.space_before = Pt(10)
        styles["Table caption"].paragraph_format.space_after = Pt(3)
        title = styles["Title"]
        title.font.size = Pt(32); title.font.bold = True; title.font.color.rgb = hex_color(NAVY)
        font_name(title)
        for name in ("List Bullet",):
            styles[name].paragraph_format.space_after = Pt(3)
        for name, indent, bold, size in (("toc 1", 0, True, 10.5), ("toc 2", 1.2, False, 10), ("table of figures", 0, False, 9.5)):
            style = styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
            style.base_style = styles["Normal"]
            style.font.bold = bold; style.font.size = Pt(size)
            style.paragraph_format.left_indent = Cm(indent)
            style.paragraph_format.space_before = Pt(5 if name == "toc 1" else 0)
            style.paragraph_format.space_after = Pt(2)
            style.paragraph_format.keep_together = True
            tabs = style.paragraph_format.tab_stops
            if name != "table of figures":
                tabs.add_tab_stop(Cm(indent + 1.2 + (0.4 if indent else 0)), WD_TAB_ALIGNMENT.LEFT)
            tabs.add_tab_stop(Cm(17.0), WD_TAB_ALIGNMENT.RIGHT, WD_TAB_LEADER.DOTS)
        self.page_known = self.pages is not None
        if not self.page_known:
            settings = doc.settings.element
            update = OxmlElement("w:updateFields"); update.set(qn("w:val"), "true")
            later = next((settings.find(qn(tag)) for tag in ("w:hdrShapeDefaults", "w:footnotePr", "w:endnotePr", "w:compat", "w:docVars", "w:rsids", "w:mathPr")
                          if settings.find(qn(tag)) is not None), None)
            if later is not None:
                later.addprevious(update)
            else:
                settings.append(update)

    def chrome(self, title, ident):
        section = self.doc.sections[0]
        section.different_first_page_header_footer = True
        header = section.header.paragraphs[0]
        header.text = ""
        header.add_run(title)
        if ident:
            ptab(header)
            header.add_run(ident)
        for run in header.runs:
            run.font.size = Pt(8.5); run.font.color.rgb = hex_color(GREY)
        props = header._p.get_or_add_pPr()
        border = OxmlElement("w:pBdr"); bottom = OxmlElement("w:bottom")
        for key, value in (("val", "single"), ("sz", "6"), ("space", "4"), ("color", GOLD)):
            bottom.set(qn(f"w:{key}"), value)
        border.append(bottom); props.append(border)
        footer = section.footer.paragraphs[0]
        footer.add_run(self.meta.get("consulting_company") or "GenStudio report")
        ptab(footer)
        footer.add_run("Page ")
        field(footer, "PAGE", "1")
        footer.add_run(" of ")
        field(footer, "NUMPAGES", str(self.total or 1))
        for run in footer.runs:
            run.font.size = Pt(8.5); run.font.color.rgb = hex_color(GREY)

    def orient(self, landscape):
        if landscape == self.landscape:
            return
        section = self.doc.add_section(WD_SECTION.NEW_PAGE)
        section.different_first_page_header_footer = False
        width, height = (Cm(29.7), Cm(21.0)) if landscape else (Cm(21.0), Cm(29.7))
        section.orientation = WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
        section.page_width, section.page_height = width, height
        section.left_margin = section.right_margin = Cm(1.5 if landscape else 2.0)
        section.top_margin, section.bottom_margin = Cm(2.0), Cm(1.8)
        self.landscape = landscape
        self.width = Cm(26.7 if landscape else 17.0)

    def new_par(self, container, style=None):
        cell = getattr(container, "_tc", None)
        if cell is not None and cell in self.fresh:
            self.fresh.discard(cell)
            par = container.paragraphs[0]
            if style:
                par.style = style
            return par
        return container.add_paragraph(style=style)

    def run(self, par, text, fmt):
        text = CONTROL.sub("", re.sub(r"\s+", " ", text))
        if not text:
            return None
        if par.text.endswith(" ") or not par.text:
            text = text.lstrip(" ")
        if not text:
            return None
        run = par.add_run(text)
        run.bold = fmt.get("bold") or None
        run.italic = fmt.get("italic") or None
        run.font.subscript = fmt.get("sub") or None
        run.font.superscript = fmt.get("sup") or None
        if fmt.get("size"):
            run.font.size = Pt(fmt["size"])
        if fmt.get("color"):
            run.font.color.rgb = hex_color(fmt["color"])
        return run

    def inline(self, par, el, fmt):
        if el.text:
            self.run(par, el.text, fmt)
        for child in el:
            self.inline_child(par, child, fmt)
            if child.tail:
                self.run(par, child.tail, fmt)

    def inline_child(self, par, child, fmt):
        tag = child.tag if isinstance(child.tag, str) else ""
        classes = (child.get("class") or "").split()
        sub = dict(fmt)
        if tag == "br":
            par.add_run().add_break(WD_BREAK.LINE)
            return
        if tag == "img":
            self.logo(par, child, 1.6)
            return
        if tag == "a":
            href = child.get("href") or ""
            if href.startswith("#"):
                before = len(par._p)
                self.inline(par, child, dict(sub, color=NAVY))
                moved = list(par._p)[before:]
                if moved:
                    link = OxmlElement("w:hyperlink")
                    link.set(qn("w:anchor"), bookmark_name(href[1:])); link.set(qn("w:history"), "1")
                    moved[0].addprevious(link)
                    for node in moved:
                        link.append(node)
                return
        if tag in ("strong", "b"):
            sub["bold"] = True
        elif tag in ("em", "i"):
            sub["italic"] = True
        elif tag == "sub":
            sub["sub"] = True
        elif tag == "sup":
            sub["sup"] = True
        elif tag in ("svgph", "script", "style") or "pg" in classes:
            return
        elif "badge" in classes:
            sub.update(bold=True, color=GOOD if "pass" in classes or "good" in classes else BAD if "bad" in classes else WARN if "warn" in classes else GREY)
        elif "muted" in classes or "small" in classes:
            sub.update(color=GREY, size=min(fmt.get("size") or 10.5, 9))
        if "num" in classes:
            self.run(par, (child.text or "") + "  ", sub)
            return
        self.inline(par, child, sub)

    def flow(self, container, el, fmt):
        pending = None
        if el.text and el.text.strip():
            pending = self.new_par(container)
            self.run(pending, el.text, fmt)
        for child in el:
            tag = child.tag if isinstance(child.tag, str) else ""
            if tag in BLOCKS:
                pending = None
                self.block(container, child, fmt)
            elif tag:
                visible = bool("".join(child.itertext()).strip()) or tag == "br"
                if visible:
                    if pending is None:
                        pending = self.new_par(container)
                    self.inline_child(pending, child, fmt)
            if child.tail and child.tail.strip():
                if pending is None:
                    pending = self.new_par(container)
                self.run(pending, child.tail, fmt)

    def finish(self, cell, size=None, align=None):
        for par in cell.paragraphs:
            par.paragraph_format.space_before = Pt(1)
            par.paragraph_format.space_after = Pt(1)
            par.paragraph_format.line_spacing = 1.0
            if align is not None:
                par.alignment = align
        last = cell._tc[-1] if len(cell._tc) else None
        if last is None or last.tag != qn("w:p"):
            cell.add_paragraph()
        self.fresh.discard(cell._tc)

    def logo(self, par, node, height_cm):
        match = re.match(r"data:image/(?:png|jpe?g|gif|webp);base64,(.+)$", node.get("src") or "", re.S)
        if not match:
            return
        try:
            data = base64.b64decode(match.group(1))
            par.add_run().add_picture(io.BytesIO(data), height=Cm(height_cm))
        except Exception:
            return

    def bookmark(self, par, *anchors):
        for anchor in dict.fromkeys(a for a in anchors if a):
            self.mark_id += 1
            name = bookmark_name(anchor)
            start, end = OxmlElement("w:bookmarkStart"), OxmlElement("w:bookmarkEnd")
            start.set(qn("w:id"), str(self.mark_id)); start.set(qn("w:name"), name)
            end.set(qn("w:id"), str(self.mark_id))
            props = par._p.pPr
            par._p.insert(1 if props is not None else 0, start)
            par._p.append(end)
            self.marks.append(name)

    def heading(self, container, el, fmt):
        tag = el.tag
        if self.front:
            style = "Front heading" if tag == "h2" else "Front subheading"
        else:
            style = {"h1": "Title", "h2": "Heading 1", "h3": "Heading 2", "h4": "Heading 3"}[tag]
        par = self.new_par(container, style)
        number = el.find("span[@class='num']")
        if number is not None and not self.front:
            hang = Cm(1.2 if tag == "h2" else 1.5)
            par.paragraph_format.left_indent = hang
            par.paragraph_format.first_line_indent = -hang
            par.paragraph_format.tab_stops.add_tab_stop(hang)
            self.run(par, "".join(number.itertext()).strip(), {})
            par.add_run().add_tab()
            self.run(par, number.tail or "", {})
            for child in el.iterchildren():
                if child is not number:
                    self.inline_child(par, child, {})
                    if child.tail:
                        self.run(par, child.tail, {})
        else:
            self.inline(par, el, {})
        if not self.front:
            self.bookmark(par, el.get("id"), self.anchor if tag == "h2" else None)
        if tag == "h2":
            self.anchor = None
        if tag == "h2" and not self.front and self.landscape:
            self.orient(False)

    def caption(self, container, el, style):
        par = self.new_par(container, style)
        anchor = next(iter(el.xpath(".//a/@id")), None)
        text = re.sub(r"\s+", " ", "".join(el.itertext())).strip()
        match = re.match(r"(Figure|Table) ([A-Za-z0-9]+)-(\d+)\s*(.*)$", text)
        if match:
            kind, chapter, number, rest = match.groups()
            self.run(par, f"{kind} {chapter}-", {"bold": True})
            run = par.add_run()
            run.bold = True
            reset = "\\r 1 " if number == "1" else ""
            field(par, f"SEQ {kind} {reset}\\* ARABIC", number)
            for item in par.runs[-5:]:
                item.bold = True
            par.add_run(" " + rest)
        else:
            self.inline(par, el, {})
        self.bookmark(par, anchor)
        return par

    def picture(self, container, svg, wide=False):
        png, width, height = svg_to_png(svg, 2600 if wide else 2200)
        par = self.new_par(container)
        par.alignment = WD_ALIGN_PARAGRAPH.CENTER
        par.paragraph_format.keep_with_next = True
        par.paragraph_format.space_after = Pt(2)
        limit_w, limit_h = (self.width, Cm(17.5 if self.landscape else 21.0))
        w = min(limit_w, int(limit_h * width / height))
        par.add_run().add_picture(io.BytesIO(png), width=w)
        self.pictures += 1

    def block(self, container, el, fmt):
        tag = el.tag
        classes = (el.get("class") or "").split()
        if tag in ("h1", "h2", "h3", "h4"):
            self.heading(container, el, fmt)
        elif tag == "p":
            par = self.new_par(container)
            sub = dict(fmt)
            if "take" in classes:
                sub.update(italic=True, color=GREY)
            elif "small" in classes or "muted" in classes:
                sub.update(color=GREY, size=9)
            self.inline(par, el, sub)
        elif tag in ("ul", "ol"):
            self.list(container, el, fmt)
        elif tag == "table":
            self.table(container, el, fmt)
        elif tag == "figure":
            wide = "sld" in classes
            if wide:
                self.orient(True)
            for child in el:
                self.block(container, child, fmt) if isinstance(child.tag, str) and child.tag in BLOCKS else None
            if wide:
                self.orient(False)
        elif tag == "svgph":
            self.picture(container, self.svgs[int(el.get("data-i"))], wide=self.landscape)
        elif tag == "figcaption":
            self.caption(container, el, "Figure caption")
        elif tag == "caption":
            self.caption(container, el, "Table caption")
        elif tag == "pre":
            par = self.new_par(container)
            run = par.add_run("".join(el.itertext()))
            run.font.name = "Consolas"; run.font.size = Pt(8.5)
        elif tag == "hr":
            return
        elif tag == "section" and el.get("id") == "contents":
            self.contents(el)
        elif tag == "section":
            was = self.front
            self.front = "frontmatter" in classes
            self.anchor = el.get("id")
            self.flow(container, el, fmt)
            self.front = was
        elif tag == "div":
            self.div(container, el, classes, fmt)
        else:
            self.flow(container, el, fmt)

    def div(self, container, el, classes, fmt):
        callout = next((c for c in classes if c in CALLOUTS), None)
        if "cover" in classes:
            self.cover(el)
        elif "tiles" in classes or "chips" in classes:
            self.cards(container, el, "tiles" in classes)
        elif callout:
            fill, edge = CALLOUTS[callout]
            table = container.add_table(rows=1, cols=1)
            table.alignment = WD_TABLE_ALIGNMENT.CENTER
            borders(table, color=fill, left=edge)
            cell_margins(table, 80, 80, 140)
            cell = table.cell(0, 0)
            shade(cell, fill)
            self.fresh.add(cell._tc)
            self.flow(cell, el, dict(fmt, size=10))
            self.finish(cell)
            self.spacer(container)
        elif "eyebrow" in classes or "tk-title" in classes or "dtitle" in classes:
            par = self.new_par(container)
            style = {"eyebrow": dict(bold=True, color=GOLD, size=9), "tk-title": dict(bold=True, color=NAVY, size=11),
                     "dtitle": dict(bold=True, color=NAVY, size=14)}[next(c for c in classes if c in ("eyebrow", "tk-title", "dtitle"))]
            self.inline(par, el, dict(fmt, **style))
            par.paragraph_format.space_after = Pt(3)
        elif "toc-row" in classes or "lof-row" in classes:
            return
        else:
            self.flow(container, el, fmt)

    def spacer(self, container, points=4):
        par = container.add_paragraph()
        par.paragraph_format.space_after = Pt(0)
        par.paragraph_format.line_spacing = 1.0
        run = par.add_run("")
        run.font.size = Pt(points)

    def list(self, container, el, fmt):
        ordered = el.tag == "ol"
        for number, item in enumerate(el.findall("li"), 1):
            par = self.new_par(container, None if ordered else "List Bullet")
            if ordered:
                par.paragraph_format.left_indent = Cm(0.7)
                par.paragraph_format.first_line_indent = Cm(-0.7)
                par.paragraph_format.space_after = Pt(3)
                self.run(par, f"{number}.", fmt)
                par.add_run().add_tab()
                par.paragraph_format.tab_stops.add_tab_stop(Cm(0.7))
            if item.text:
                self.run(par, item.text, fmt)
            for child in item:
                if isinstance(child.tag, str) and child.tag in ("ul", "ol"):
                    self.list(container, child, fmt)
                elif isinstance(child.tag, str) and child.tag in BLOCKS:
                    self.block(container, child, fmt)
                else:
                    self.inline_child(par, child, fmt)
                if child.tail:
                    self.run(par, child.tail, fmt)

    def cards(self, container, el, tiles):
        items = [c for c in el if isinstance(c.tag, str)]
        columns = 4
        rows = (len(items) + columns - 1) // columns
        table = container.add_table(rows=rows, cols=columns)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        borders(table, color="FFFFFF", vertical=True)
        cell_margins(table, 70, 70, 100)
        for index, item in enumerate(items):
            cell = table.cell(index // columns, index % columns)
            shade(cell, "F1F5F9")
            self.fresh.add(cell._tc)
            classes = (item.get("class") or "").split()
            parts = [(p.get("class") or "", p) for p in item]
            if tiles:
                label = next((p for c, p in parts if c == "tl"), None)
                value = next((p for c, p in parts if p.tag == "b"), None)
                note = next((p for c, p in parts if c == "tn"), None)
                accent = GOOD if "pass" in classes else BAD if "fail" in classes or "bad" in classes else WARN if "warn" in classes else NAVY
                for node, fmt in ((label, dict(color=GREY, size=8, bold=True)), (value, dict(bold=True, size=14, color=accent)), (note, dict(color=GREY, size=8))):
                    if node is not None:
                        self.inline(self.new_par(cell), node, fmt)
            else:
                for c, node in parts:
                    fmt = dict(bold=True, size=10, color=NAVY) if c == "cn" else dict(color=GREY, size=8) if c == "cd" else {}
                    self.inline(self.new_par(cell), node, fmt)
            self.finish(cell)
        for blank in range(len(items), rows * columns):
            cell = table.cell(blank // columns, blank % columns)
            self.finish(cell)
        self.spacer(container)

    def table(self, container, el, fmt):
        caption = el.find("caption")
        if caption is not None:
            self.caption(container, caption, "Table caption")
        trs = [tr for tr in el.iter("tr")]
        if not trs:
            return
        columns = max(len(tr.xpath("./th|./td")) for tr in trs)
        wide = "wide" in (el.get("class") or "").split()
        size = 7.5 if columns >= 10 else 8 if (wide or columns >= 7) else 9
        table = container.add_table(rows=len(trs), cols=columns)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        borders(table)
        cell_margins(table)
        heads = {id(tr) for tr in el.xpath("./thead/tr")}
        if not heads and trs[0].xpath("./th") and not trs[0].xpath("./td"):
            heads = {id(trs[0])}
        lengths = [[] for _ in range(columns)]
        body_index = 0
        for i, tr in enumerate(trs):
            header = id(tr) in heads
            row_flags(table.rows[i], header)
            if not header:
                body_index += 1
            for j, node in enumerate(tr.xpath("./th|./td")):
                cell = table.cell(i, j)
                self.fresh.add(cell._tc)
                classes = (node.get("class") or "").split()
                numeric = "n" in classes
                sub = dict(size=size)
                if header:
                    sub.update(bold=True, color="FFFFFF")
                    shade(cell, NAVY)
                elif node.tag == "th":
                    sub.update(bold=True, color=NAVY)
                    shade(cell, "EEF2F7")
                elif body_index % 2 == 0:
                    shade(cell, "F7F9FB")
                self.flow(cell, node, sub)
                self.finish(cell, align=WD_ALIGN_PARAGRAPH.RIGHT if numeric else None)
                text = "".join(node.itertext()).strip()
                words = max((len(w) for w in text.split()), default=1)
                lengths[j].append((len(text), words))
        weights = []
        for column in lengths:
            longest = max((w for _, w in column), default=4)
            total = max((t for t, _ in column), default=4)
            weights.append(min(40.0, max(5.0, longest, min(total, 28))))
        scale = self.width / sum(weights)
        table.autofit = False
        for j, weight in enumerate(weights):
            width = int(weight * scale)
            table.columns[j].width = width
            for row in table.rows:
                row.cells[j].width = width
        self.spacer(container)

    def toc_entries(self, instruction, rows):
        """rows: (anchor, number, text, level, style). Emits the field result paragraphs the way Word writes them."""
        if not rows:
            par = self.doc.add_paragraph()
            field(par, instruction, "Right-click and choose Update Field to build this list.")
            return
        for index, (anchor, number, text, level, style) in enumerate(rows):
            par = self.doc.add_paragraph(style=style)
            if index == 0:
                for node in (mark_run("begin"), mark_run(None, instruction), mark_run("separate")):
                    par._p.append(node)
            name = bookmark_name(anchor)
            link = OxmlElement("w:hyperlink")
            link.set(qn("w:anchor"), name); link.set(qn("w:history"), "1")
            if number:
                link.append(text_run(number))
                link.append(tab_run())
            link.append(text_run(text))
            link.append(tab_run())
            page = str((self.pages or {}).get(name, "1"))
            for node in (mark_run("begin"), mark_run(None, f"PAGEREF {name} \\h"), mark_run("separate"), text_run(page), mark_run("end")):
                link.append(node)
            par._p.append(link)
            if index == len(rows) - 1:
                par._p.append(mark_run("end"))

    def contents(self, el):
        toc, lists, current = [], {}, None
        for child in el:
            classes = (child.get("class") or "").split()
            if child.tag == "h3":
                current = "".join(child.itertext()).strip()
                lists[current] = []
                continue
            link = child.find("a")
            anchor = (link.get("href") or "#")[1:] if link is not None else ""
            text = child.find(".//span[@class='tx']")
            label = re.sub(r"\s+", " ", "".join(text.itertext())).strip() if text is not None else ""
            if "toc-row" in classes:
                number = child.find(".//span[@class='num']")
                number = (number.text or "").strip() if number is not None else ""
                level = 2 if "l2" in classes else 1
                if number.startswith("Appendix"):
                    label, number = f"{number} \u2013 {label}", ""
                toc.append((anchor, number, label, level, f"toc {level}"))
            elif "lof-row" in classes and current:
                lists[current].append((anchor, "", label, 1, "table of figures"))
        self.doc.add_paragraph("Table of contents", style="Front heading")
        self.toc_entries('TOC \\o "1-2" \\h \\z \\u', toc)
        for title, rows in lists.items():
            if not rows:
                continue
            self.doc.add_paragraph(title, style="Front subheading")
            kind = "Figure" if "figure" in title.lower() else "Table"
            self.toc_entries(f'TOC \\h \\z \\c "{kind}"', rows)

    def cover(self, el):
        doc = self.doc
        pad = doc.add_paragraph()
        pad.paragraph_format.space_before = Pt(60)
        for child in el:
            classes = (child.get("class") or "").split()
            if child.tag == "img":
                self.logo(doc.add_paragraph(), child, 2.2)
            elif "company" in classes:
                par = doc.add_paragraph()
                self.run(par, "".join(child.itertext()), dict(bold=True, color=NAVY, size=14))
            elif "eyebrow" in classes:
                par = doc.add_paragraph()
                self.run(par, "".join(child.itertext()).upper(), dict(bold=True, color=GOLD, size=11))
                par.paragraph_format.space_before = Pt(50)
            elif child.tag == "h1":
                par = doc.add_paragraph(style="Title")
                self.inline(par, child, {})
                par.paragraph_format.space_after = Pt(10)
            elif "subtitle" in classes:
                par = doc.add_paragraph()
                self.inline(par, child, dict(size=13, color=GREY))
                par.paragraph_format.space_after = Pt(30)
            elif child.tag == "table":
                self.table(doc, child, {})
            elif "conf" in classes:
                spacer = doc.add_paragraph()
                spacer.paragraph_format.space_before = Pt(60)
                self.div(doc, child, classes, {})
            elif isinstance(child.tag, str):
                self.block(doc, child, {})

    def convert(self, html, title="", ident=""):
        self.svgs = []

        def keep(match):
            self.svgs.append(match.group(0))
            return f'<svgph data-i="{len(self.svgs) - 1}"></svgph>'
        html = SVG.sub(keep, html)
        tree = lxml.html.fromstring(html)
        for node in tree.xpath("//style|//script"):
            node.getparent().remove(node)
        main = tree.find(".//main")
        main = main if main is not None else tree
        footer = main.xpath(".//footer")
        closing = "".join(footer[0].itertext()).strip() if footer else ""
        for node in footer:
            node.getparent().remove(node)
        self.chrome(title, ident)
        self.flow(self.doc, main, {})
        if self.landscape:
            self.orient(False)
        if closing:
            par = self.doc.add_paragraph()
            self.run(par, closing, dict(color=GREY, size=8.5, italic=True))
        return self


WORD_SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$path = $env:GENSTUDIO_DOCX
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
$doc = $null
try {
  $doc = $word.Documents.Open($path, $false, $true)
  $doc.Repaginate()
  $out = @{}
  foreach ($mark in $doc.Bookmarks) {
    if ($mark.Name -like 'b_*') {
      $range = $mark.Range
      $range.Collapse(1)
      $out[$mark.Name] = [int]$range.Information(3)
    }
  }
  $out['__pages'] = [int]$doc.ComputeStatistics(2)
  $out | ConvertTo-Json -Compress
} finally {
  if ($doc -ne $null) { $doc.Close(0) }
  if ($word.Documents.Count -eq 0) { $word.Quit() }
}
"""


def _word_pids():
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", "(Get-Process WINWORD -ErrorAction SilentlyContinue).Id"],
                             capture_output=True, text=True, timeout=20).stdout
        return {int(x) for x in out.split()}
    except Exception:
        return set()


def word_pages(data, timeout=150):
    """Lay the document out in a hidden Word instance and return ({bookmark: page}, page count), or (None, None)."""
    if os.name != "nt" or os.environ.get("GENSTUDIO_NO_WORD"):
        return None, None
    before = _word_pids()
    handle, path = tempfile.mkstemp(suffix=".docx")
    try:
        with os.fdopen(handle, "wb") as fh:
            fh.write(data)
        encoded = base64.b64encode(WORD_SCRIPT.encode("utf-16-le")).decode()
        try:
            done = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-EncodedCommand", encoded], capture_output=True, text=True,
                                  timeout=timeout, env=dict(os.environ, GENSTUDIO_DOCX=path))
            found = json.loads(done.stdout.strip().splitlines()[-1])
        except Exception:
            for pid in _word_pids() - before:
                subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True)
            return None, None
        total = found.pop("__pages", None)
        return found, total
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def to_docx(html, meta=None, title="", ident="", use_word=False):
    """Convert a report HTML string to .docx bytes; with use_word the contents are completed with real page numbers."""
    def make(pages=None, total=None):
        converter = Converter(meta, pages, total).convert(html, title, ident)
        properties = converter.doc.core_properties
        properties.title = title or "Generation planning study"
        properties.author = (meta or {}).get("consulting_company") or "GenStudio"
        properties.subject = ident
        out = io.BytesIO()
        converter.doc.save(out)
        return out.getvalue()
    if not use_word:
        return make()
    pages, total = word_pages(make({}))
    return make(pages, total) if pages else make()


def _identity(meta_raw):
    meta = report_doc.clean_meta(meta_raw)
    title = meta["project_name"] or "Generation planning study"
    ident = " - ".join(x for x in (meta["document_number"], report_doc.rev_label(meta), meta["issue_purpose"]) if x)
    return meta, title, ident


def build(run_id, meta_raw=None):
    meta, title, ident = _identity(meta_raw)
    return to_docx(report_doc.build(run_id, meta_raw), meta, title, ident, use_word=True)


def build_design(run_id, meta_raw=None):
    meta, title, ident = _identity(meta_raw)
    return to_docx(report_doc.build_design_doc(run_id, meta_raw), meta, f"{title} - technical design", ident, use_word=True)
