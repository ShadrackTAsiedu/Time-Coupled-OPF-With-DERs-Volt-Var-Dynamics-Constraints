"""AC power-flow screening for GenStudio single-line diagrams (SLD).

DESIGN NOTE - where power flow belongs in a least-cost sizing study
--------------------------------------------------------------------
Running an AC power flow INSIDE the LP optimisation is not practical:
  * AC power flow is nonlinear and non-convex (voltage angles/magnitudes, trigonometric
    terms); it cannot be written as LP rows, and a nonlinear/MINLP model would lose the
    guaranteed global optimum and the dual information the optimiser relies on.
  * A sizing run has 8,760 x horizon-years of hourly states.  The optimiser avoids a single
    monolithic problem by monthly LP decomposition with dual (Benders-style) cuts; an AC
    solve per hour per iteration would multiply run time by orders of magnitude.
  * The capacity decisions (MW of PV, BESS, gensets) change every iteration, so network
    impedances/ratings and Q capability would also have to be decision-dependent.
Recommended architecture (what this module supports):
  (a) OPTIONAL pre-solve linear limits: per-branch MVA ratings expressed as simple
      capacity-per-branch caps (|flow| <= rating) or a loss-free DC approximation on the
      radial SLD.  These are linear and can be added to the LP by the optimiser owner.
  (b) POST-SOLVE AC screening on critical hours (implemented here: screen_run): peak load,
      minimum load, maximum solar, BESS charge/discharge extremes, maximum grid import,
      maximum genset output, maximum reverse flow, plus N-1 outages.  Each case is a full
      Newton-Raphson AC power flow; results carry voltages, loadings, losses, violations and
      plain-language mitigations, and an overall PASS / WARN / FAIL status per scenario.
  (c) Iterate loop: if screening fails, suggest_cuts(report) returns structured "technical
      cuts" (cap on a generator/BESS/inverter MW at a bus, minimum reactive support,
      upgrade of a failing branch, redundancy) that the optimiser owner can feed back as
      extra constraints/costs and re-solve until the screening passes.

MODEL AND LIMITS (be honest about them)
  * Balanced, positive-sequence, steady-state AC power flow, 100 MVA system base.  No
    harmonics, unbalance, dynamics, protection, fault levels, flicker or start-up transients.
  * Screening tool.  It does not replace a PSS/E (or equivalent) interconnection study.
    export_raw() writes a PSS/E v33 RAW text file for cross-checking.
  * Technologies are aggregated, one symbol each (as in the SLD); capacities come from the
    solved result or from user entries.
  * Every default below is a typical, representative value from the cited reference class,
    not a project-specific design value.  Override per component in the Power-flow panel.

SLD -> network mapping
  * Every SLD node is a bus; its nominal kV is the user value or DEFAULTS["kv_by_kind"].
  * A wire joining buses of different kV is a transformer; same-kV wires with length > 0 are
    lines; same-kV zero-length wires are ideal-ish bus ties (tiny impedance, no rating).
    A wire can be forced to "transformer" in the overrides.
  * Grid: slack at 1.0 pu behind a Thevenin equivalent (short-circuit MVA, X/R).
  * Missing grid (islanded microgrid): the slack is the grid-forming BESS, else the largest
    genset (documented choice: those are the units that can hold voltage/frequency).  If an
    island has no grid-forming source it is reported as de-energised (inverter PV/wind trip).
  * Loads: dispatch load split over Load nodes (weights, default equal), pf 0.95 lagging.
  * PV/wind/BESS: inverter PQ sources (pf default 1.0) with optional voltage control within
    Q limits (S = P_rated/0.95); gensets: PV buses with Q limits (0.8 pf lag, 0.5 P lead).
"""

import csv
import io
import json
import math
import os
import re
from datetime import datetime
from pathlib import Path
import numpy as np

import extensions
import network_topology
import pf_costs
import unit_pf as unitpf

BASE_MVA = 100.0
TIE_R_PU, TIE_X_PU = 1e-4, 1e-3
TECH_GEN = {"pv", "bess", "wind", "ng", "ng_chp", "h2", "h2_chp", "diesel", "biogas", "biomass"}
GENSETS = TECH_GEN - {"pv", "bess", "wind"}
STD_MVA = [0.5, 0.63, 1, 1.25, 1.6, 2, 2.5, 3.15, 4, 5, 6.3, 8, 10, 12.5, 16, 20, 25, 31.5, 40, 50, 63, 80,
           100, 125, 160, 200, 250, 315, 400]

# (kV class, type) -> r ohm/km, x ohm/km, b uS/km, ampacity A.  Values are typical for the conductor
# class named in "basis"; they are screening defaults, not a substitute for the manufacturer's data.
LINE_DEFAULTS = [
    dict(kv=0.4, type="overhead", r=0.32, x=0.08, b=0.0, amps=250, basis="LV aerial bundled/ACSR ~95 mm2"),
    dict(kv=0.4, type="cable", r=0.164, x=0.075, b=0.0, amps=300, basis="LV 4-core Al XLPE 185 mm2"),
    dict(kv=11, type="overhead", r=0.27, x=0.38, b=3.0, amps=350, basis="ACSR ~120 mm2 (Dog/Raccoon class)"),
    dict(kv=11, type="cable", r=0.125, x=0.10, b=94.0, amps=300, basis="3-core Al XLPE 240 mm2"),
    dict(kv=22, type="overhead", r=0.22, x=0.39, b=3.0, amps=400, basis="ACSR ~150 mm2"),
    dict(kv=22, type="cable", r=0.10, x=0.11, b=75.0, amps=350, basis="3-core Al XLPE 300 mm2"),
    dict(kv=33, type="overhead", r=0.20, x=0.40, b=2.9, amps=450, basis="ACSR ~150-200 mm2 (Wolf class)"),
    dict(kv=33, type="cable", r=0.10, x=0.12, b=63.0, amps=380, basis="3-core Al XLPE 300 mm2"),
    dict(kv=66, type="overhead", r=0.12, x=0.40, b=2.9, amps=600, basis="ACSR ~300 mm2"),
    dict(kv=66, type="cable", r=0.07, x=0.13, b=57.0, amps=600, basis="1-core Al XLPE 630 mm2"),
    dict(kv=110, type="overhead", r=0.09, x=0.40, b=2.9, amps=700, basis="ACSR ~400 mm2 (Zebra class)"),
    dict(kv=110, type="cable", r=0.05, x=0.15, b=60.0, amps=700, basis="1-core Cu XLPE 800 mm2"),
    dict(kv=132, type="overhead", r=0.07, x=0.39, b=2.9, amps=800, basis="ACSR 400 mm2 (Zebra) single"),
    dict(kv=132, type="cable", r=0.04, x=0.15, b=62.0, amps=800, basis="1-core Cu XLPE 1000 mm2"),
    dict(kv=220, type="overhead", r=0.05, x=0.40, b=2.8, amps=1000, basis="Twin ACSR 400 mm2"),
    dict(kv=220, type="cable", r=0.03, x=0.14, b=70.0, amps=1000, basis="1-core Cu XLPE 1600 mm2"),
]

DEFAULTS = {
    "base_mva": dict(value=BASE_MVA, unit="MVA", source="Common utility study base (PSS/E default 100 MVA)."),
    "voltage_limits_pu": dict(value=[0.95, 1.05], unit="pu",
                              source="ANSI C84.1 Range A (0.95-1.05 pu) normal service voltage."),
    "n1_voltage_limits_pu": dict(value=[0.90, 1.10], unit="pu",
                                 source="ANSI C84.1 Range B (emergency) used for N-1 cases."),
    "thermal_limit_pct": dict(value=100.0, unit="%", source="Continuous branch rating (ampacity / nameplate MVA)."),
    "high_loading_pct": dict(value=90.0, unit="%", source="Planning practice: warn above 90 % of continuous rating."),
    "load_pf": dict(value=0.95, unit="lag", source="Typical distribution-feeder demand power factor."),
    "kv_by_kind": dict(value=dict(grid=33.0, substation=33.0, bus=11.0, load=11.0, pv=11.0, bess=11.0, wind=11.0,
                                  ng=11.0, ng_chp=11.0, h2=11.0, h2_chp=11.0, diesel=11.0, biogas=11.0, biomass=11.0),
                       unit="kV", source="IEC 60038 standard MV levels (11 kV and 33 kV, commonly used for microgrids)."),
    "line_type_default": dict(value="cable if length <= 1 km else overhead", unit="",
                              source="Engineering convention: short MV connections are usually buried cable."),
    "lines": dict(value=LINE_DEFAULTS, unit="ohm/km, uS/km, A",
                  source="Kersting, Distribution System Modeling and Analysis; Grainger & Stevenson, Power System "
                         "Analysis (typical ACSR data); manufacturer XLPE cable catalogues; IEC 60287 ampacity."),
    "tie": dict(value=dict(r_pu=TIE_R_PU, x_pu=TIE_X_PU), unit="pu on 100 MVA",
                source="Numerical choice: near-ideal connection so flows through a bus/junction are visible."),
    "transformer_z_pct": dict(value=[[2.5, 6.0, 5], [10, 7.5, 8], [40, 10.0, 15], [1e9, 12.0, 20]],
                              unit="[max MVA, %Z, X/R]",
                              source="IEC 60076-5 / IEEE C57.12.00 typical impedance; X/R per IEEE C57.12.00 "
                                     "guidance (rises with MVA)."),
    "transformer_sizing": dict(value="smallest standard MVA >= max(peak load, installed generation) behind it / 0.95",
                               unit="MVA", source="IEC 60076-1 preferred ratings (R10 series); sized on the larger of "
                                                  "peak load or installed generation on the low-voltage side."),
    "transformer_tap": dict(value=1.0, unit="pu ratio on HV side",
                            source="Nominal tap; raising the ratio lowers the LV voltage (MATPOWER convention)."),
    "grid_short_circuit": dict(value=dict(mva_le_33kv=750.0, mva_gt_33kv=2500.0, xr=10.0), unit="MVA, X/R",
                               source="IEC 60909; ~13 kA at 33 kV (750 MVA) matches common 13.1/25 kA MV switchgear classes; replace "
                                      "with the utility's stated value."),
    "per_unit_basis": dict(value="Zpu = Z_ohm x MVAbase / kV^2 (system base 100 MVA); line Zpu = (ohm/km x km / circuits) / (kV^2/100); "
                                 "Ypu = B_S x kV^2/100; transformer Zpu = (%Z/100) x 100 / MVA_rating on its own rating", unit="",
                           source="Standard per-unit conversion (Grainger & Stevenson ch.3; IEEE Std 399 ch.3). An 11 kV, 1.5 km, 185 mm2 Al "
                                  "cable (0.211+j0.102 ohm/km) is 0.26+j0.13 pu on 100 MVA but only 1.3% on its own 4.8 MVA rating: large pu "
                                  "values on a 100 MVA base are not an error."),
    "impedance_calibration": dict(value="Cable r 0.08-0.41, x 0.09-0.11 ohm/km (IEC 60287 / manufacturer 3-core XLPE, 95-630 mm2 Al)", unit="ohm/km",
                                  source="Cross-checked against the supplied utility feeder schedule data.xlsx (397 MV cable sections, Al 1/0 AWG-1500 kcmil): "
                                         "R1 0.09-0.59 ohm/km agrees with our r for the same copper area (4/0 AWG 0.30 vs 95 mm2 0.41, 500 kcmil 0.13 vs 240 mm2 0.16); "
                                         "that schedule's X1 (0.15-0.18 ohm/km, single-core concentric-neutral) is ~1.5x our 3-core XLPE x, so the defaults are not "
                                         "over-impedant; use the cable's own x when it is single-core in flat formation. Transformer Z%/X-R per IEC 60076-5, "
                                         "IEEE C57.12.10 and IEEE Std 141; grid fault level per IEC 60909."),
    "inverter_pf": dict(value=dict(pv=0.9, bess=0.9, wind=0.9, capability=0.95), unit="pf",
                        source="Default unit operating pf 0.9 (rated MVA = MW / 0.9, editable per technology); a set-point pf used only when "
                               "Reactive control = pf defaults to it. IEEE 1547-2018 Cat. B / IEEE 2800-2022 require at least 0.95 at the POI."),
    "genset_q_limits": dict(value=dict(q_max_pu_p=0.75, q_min_pu_p=-0.5, vset=1.0), unit="x rated MW",
                            source="Synchronous machine 0.8 pf lagging / ~0.9 leading (IEC 60034-3 / manufacturer D-curves)."),
    "grid_forming": dict(value="BESS first, then largest genset", unit="",
                         source="Islanded operation needs a voltage/frequency-forming source (IEEE 2030.7)."),
    "pv_wind_rating": dict(value="installed MW from the solved result (pv_dc_mw, wind MW)", unit="MW",
                           source="Aggregate technology capacity from result_<code>.json."),
}


def defaults_table():
    """Flat rows for the UI 'Assumptions' table."""
    rows = []
    for key, item in DEFAULTS.items():
        if key == "lines":
            for row in LINE_DEFAULTS:
                rows.append(dict(group="Line", name=f"{row['kv']:g} kV {row['type']}",
                                 value=f"r={row['r']} x={row['x']} ohm/km, b={row['b']} uS/km, {row['amps']} A ({row['basis']})",
                                 source=item["source"]))
        else:
            value = item["value"]
            rows.append(dict(group="General", name=key, value=json.dumps(value) if not isinstance(value, str) else value,
                             source=item["source"]))
    return rows


def _num(value, label, low=None, high=None):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{label} must be a finite number.")
    if (low is not None and value < low) or (high is not None and value > high):
        raise ValueError(f"{label} must be between {low} and {high}.")
    return float(value)


def line_class(kv, kind):
    rows = [r for r in LINE_DEFAULTS if r["type"] == kind]
    return min(rows, key=lambda r: abs(math.log(max(kv, 0.1) / r["kv"])))


def standard_mva(required):
    return next((s for s in STD_MVA if s >= required), math.ceil(required / 100.0) * 100.0)


def transformer_defaults(mva):
    for limit, z, xr in DEFAULTS["transformer_z_pct"]["value"]:
        if mva <= limit:
            return z, xr
    return 12.0, 20.0


class Network:
    """Buses, branches and generator/load descriptors resolved from an SLD."""

    def __init__(self):
        self.buses, self.branches, self.gens, self.loads = [], [], [], []
        self.index, self.base = {}, {}
        self.warnings = []
        self.limits = {}
        self.settings, self.tags, self.names = {}, {}, {}

    def bus(self, ident):
        return self.buses[self.index[ident]]


# Bus numbering convention (PSS/E-style blocks); unique integers, keeps user-entered numbers when they are free.
BUS_BLOCKS = dict(utility=1001, mv=2001, generation=3001, load=4001, bess=5001)
BUS_PREFIX = dict(grid="GRID", pv="SOLAR_PV", wind="WIND", ng="NG_GEN", ng_chp="NG_CHP", h2="H2_GEN", h2_chp="H2_CHP",
                  diesel="DIESEL", biogas="BIOGAS", biomass="BIOMASS", load="LOAD", bess="BESS", substation="SUBSTN")


def _kv_text(kv):
    text = f"{kv:g}".replace(".", "K")
    return text


def _bus_block(kind, kv):
    if kind == "grid" or (kind in ("bus", "substation") and kv >= 60):
        return "utility"
    if kind in ("bus", "substation"):
        return "mv"
    return "load" if kind == "load" else "bess" if kind == "bess" else "generation"


def _number_buses(net):
    """Assign unique bus numbers and PSS/E 12-character names to every bus (user values win)."""
    used_nums, used_names = set(), set()
    for b in net.buses:
        n = b["user"].get("bus_number")
        if n is not None and float(n) == int(n) and 1 <= int(n) <= 999997 and int(n) not in used_nums:
            b["num"] = int(n)
            used_nums.add(int(n))
    counters = dict(BUS_BLOCKS)
    for b in net.buses:
        if "num" in b:
            continue
        block = _bus_block(b["kind"], b["kv"])
        while counters[block] in used_nums:
            counters[block] += 1
        b["num"] = counters[block]
        used_nums.add(b["num"])
        counters[block] += 1
    for b in net.buses:
        custom = b["user"].get("bus_name")
        if custom:
            name = str(custom).upper()[:12]
        else:
            prefix = BUS_PREFIX.get(b["kind"]) or ("HV_BUS" if _bus_block(b["kind"], b["kv"]) == "utility" else "LV_BUS" if b["kv"] < 1 else "MV_BUS")
            name = f"{prefix}_{_kv_text(b['kv'])}"[:12]
        base, n = name, 1
        while name in used_names:
            n += 1
            name = base[:12 - len(str(n)) - 1] + "_" + str(n)
        used_names.add(name)
        b["name"] = name
        b["display"] = f"{b['label']} ({b['num']})"
        net.names[b["id"]] = b["display"]


def _name_branches(net):
    for br in net.branches:
        a, b = net.buses[br["f"]], net.buses[br["t"]]
        tag = "TR" if br["kind"] == "transformer" else "TIE" if br["kind"] == "tie" else "LN"
        br["name"] = f"{tag} {a['num']}-{b['num']}"
        br["from_num"], br["to_num"] = a["num"], b["num"]
        net.names[br["id"]] = br["name"]


def _diagram(topology, code=None, techs=None):
    """Validated SLD for one scenario.  With no stored drawing the default autodraw topology for `techs` is used (never saved);
    'shunt' nodes are folded into their bus; unwired duplicate Load nodes are dropped (the notes land in net.warnings)."""
    notes = []
    stored = topology.get("diagrams", {}).get(code) if isinstance(topology, dict) and code else None
    if isinstance(topology, dict) and topology.get("diagrams") is not None and code:
        has_drawing = bool(stored and stored.get("nodes") and stored.get("lines"))
    else:
        has_drawing = isinstance(topology, dict) and bool(topology.get("nodes") and topology.get("lines") or
                                                          topology.get("diagrams") and not code)
    if not has_drawing and techs is not None:
        raw = network_topology.autodraw(sorted(techs, key=lambda k: (k != "grid", k)), enabled=True)
        notes.append("No single-line diagram is stored for this scenario: the default autodraw topology (Load - Bus - "
                     "one terminal per technology, grid via one transformer) was generated for this check; your drawing was not changed.")
        topology = dict(enabled=True, nodes=raw["nodes"], lines=raw["lines"])
        code = None
    if not isinstance(topology, dict):
        raise ValueError("No single-line diagram is available. Draw the SLD (Load, sources, buses and wires) first.")
    diagram = topology.get("diagrams", {}).get(code) if code else None
    if diagram is None and topology.get("diagrams") and not topology.get("nodes"):
        code = topology.get("active_scenario") or next(iter(topology["diagrams"]), None)
        diagram = topology["diagrams"].get(code)
    if diagram is None:
        diagram = topology
    diagram = network_topology.validate_diagram(
        dict(enabled=bool(diagram.get("enabled", False)), nodes=diagram.get("nodes", []), lines=diagram.get("lines", []),
             pf_settings=diagram.get("pf_settings") or topology.get("pf_settings")), [])
    if not diagram["nodes"] or not diagram["lines"]:
        raise ValueError("The single-line diagram needs nodes connected by wires before a power flow can run.")
    diagram = network_topology.pf_view(diagram)
    wired = {e[k] for e in diagram["lines"] for k in ("source", "target")}
    loads = [n for n in diagram["nodes"] if n["kind"] == "load"]
    if any(n["id"] in wired for n in loads):
        dropped = [n for n in loads if n["id"] not in wired]
        if dropped:
            diagram = dict(diagram, nodes=[n for n in diagram["nodes"] if n not in dropped])
            notes.append(f"{len(dropped)} extra Load node(s) with no wire were ignored (a scenario has one wired Load; "
                         f"delete the unwired one(s) on the Topology page).")
    diagram = _connect_dangling_grid(dict(diagram), notes)
    diagram = dict(diagram, _notes=notes)
    return diagram


def _connect_dangling_grid(diagram, notes):
    """A Grid node with no wire would silently turn a grid-connected study into an islanded one.  For the electrical model only, wire it
    to the busiest bus (the stored drawing is not touched) and say so; a deliberate disconnection is the separate islanded study."""
    degree = {}
    for edge in diagram["lines"]:
        for end in (edge["source"], edge["target"]):
            degree[end] = degree.get(end, 0) + 1
    buses = [n for n in diagram["nodes"] if n["kind"] == "bus"]
    if not buses:
        return diagram
    hub = max(buses, key=lambda n: degree.get(n["id"], 0))
    lines = list(diagram["lines"])
    for node in diagram["nodes"]:
        if node["kind"] == "grid" and not degree.get(node["id"]) and (node.get("electrical") or {}).get("in_service") is not False:
            lines.append(dict(id=f"auto_grid_{node['id']}", source=node["id"], target=hub["id"], owner="grid", length_km=0, cost_per_km=0,
                              points=[], source_port="bottom", target_port="top"))
            notes.append(f"The Grid '{node['label']}' has no wire in the drawing. It was connected to '{hub['label']}' for this check so the study "
                         "stays grid-connected (the stored drawing is unchanged; draw the wire on the Topology page to keep it).")
    return dict(diagram, lines=lines)


def build_network(diagram, caps=None, assumptions=None, eligible=None, islanded=False, peak_load_mw=None, unit_pf=None):
    """Resolve an SLD diagram into a Network.  caps: {tech: MW}.  assumptions: see module docstring."""
    assumptions = assumptions or {}
    base = assumptions.get("base") or {}
    node_over = {n["id"]: dict(n["electrical"]) for n in diagram["nodes"] if n.get("electrical")}
    line_over = {e["id"]: dict(e["electrical"]) for e in diagram["lines"] if e.get("electrical")}
    for ident, row in (assumptions.get("nodes") or {}).items():
        node_over[ident] = {**node_over.get(ident, {}), **(row or {})}
    for ident, row in (assumptions.get("lines") or {}).items():
        line_over[ident] = {**line_over.get(ident, {}), **(row or {})}
    caps = {k: float(v) for k, v in (caps or {}).items() if isinstance(v, (int, float))}
    net = Network()
    net.warnings.extend(diagram.get("_notes") or [])
    settings = dict(diagram.get("pf_settings") or {})
    net.settings = settings
    limits = DEFAULTS["voltage_limits_pu"]["value"]
    dv, de = DEFAULTS["voltage_limits_pu"]["value"], DEFAULTS["n1_voltage_limits_pu"]["value"]
    user_v = [settings.get("vmin_pu", dv[0]), settings.get("vmax_pu", dv[1])] if "vmin_pu" in settings or "vmax_pu" in settings else None
    user_e = [settings.get("vmin_emerg_pu", de[0]), settings.get("vmax_emerg_pu", de[1])] if "vmin_emerg_pu" in settings or "vmax_emerg_pu" in settings else None
    net.limits = dict(
        voltage=[_num(v, "Voltage limit", 0.5, 1.5) for v in (base.get("voltage_limits") or user_v or limits)],
        n1_voltage=[_num(v, "N-1 voltage limit", 0.5, 1.5) for v in (base.get("n1_voltage_limits") or user_e or DEFAULTS["n1_voltage_limits_pu"]["value"])],
        thermal=_num(base.get("thermal_limit_pct", settings.get("thermal_limit_pct", 100.0)), "Thermal limit %", 10, 500),
        high=_num(base.get("high_loading_pct", settings.get("high_loading_pct", 90.0)), "High-loading %", 10, 500))
    if len(net.limits["voltage"]) != 2 or net.limits["voltage"][0] >= net.limits["voltage"][1]:
        raise ValueError("Voltage limits must be [low, high] with low < high.")
    if len(net.limits["n1_voltage"]) != 2 or net.limits["n1_voltage"][0] >= net.limits["n1_voltage"][1]:
        raise ValueError("Emergency voltage limits must be [low, high] with low < high.")
    load_pf = _num(base.get("load_pf", settings.get("load_pf", 0.95)), "Load power factor", 0.5, 1.0)
    base_mva = _num(settings.get("base_mva", BASE_MVA), "Base MVA", 1, 10000)
    net.base = dict(load_pf=load_pf, islanded=bool(islanded), base_mva=base_mva)
    net.tags = dict(
        voltage_limits="user-set" if base.get("voltage_limits") or user_v else "assumed",
        n1_voltage_limits="user-set" if base.get("n1_voltage_limits") or user_e else "assumed",
        **{k: "user-set" if k in settings else "assumed" for k in ("vmin_pu", "vmax_pu", "vmin_emerg_pu", "vmax_emerg_pu")},
        thermal_limit_pct="user-set" if "thermal_limit_pct" in base or "thermal_limit_pct" in settings else "assumed",
        high_loading_pct="user-set" if "high_loading_pct" in base or "high_loading_pct" in settings else "assumed",
        load_pf="user-set" if "load_pf" in base or "load_pf" in settings else "assumed",
        base_mva="user-set" if "base_mva" in settings else "assumed",
        grid_sc_mva="user-set" if "grid_sc_mva" in settings else "assumed",
        grid_xr="user-set" if "grid_xr" in settings else "assumed")
    nodes = {n["id"]: n for n in diagram["nodes"]}
    for ident, over in node_over.items():
        if ident not in nodes:
            raise ValueError(f"Override refers to unknown component '{ident}'.")
    kv_default = DEFAULTS["kv_by_kind"]["value"]
    for node in diagram["nodes"]:
        over = node_over.get(node["id"]) or {}
        on = over.get("in_service", True) is not False
        if node["kind"] in TECH_GEN | {"grid"} and eligible is not None and node["kind"] not in eligible:
            on = False
        if node["kind"] == "grid" and islanded:
            on = False
        kv = _num(over.get("kv", kv_default[node["kind"]]), f"{node['label']} kV", 0.1, 1000)
        net.index[node["id"]] = len(net.buses)
        vlim = [_num(over.get("vmin_pu", net.limits["voltage"][0]), "Bus Vmin", 0.5, 1.5),
                _num(over.get("vmax_pu", net.limits["voltage"][1]), "Bus Vmax", 0.5, 1.5)]
        elim = [_num(over.get("vmin_emerg_pu", net.limits["n1_voltage"][0]), "Bus emergency Vmin", 0.5, 1.5),
                _num(over.get("vmax_emerg_pu", net.limits["n1_voltage"][1]), "Bus emergency Vmax", 0.5, 1.5)]
        if vlim[0] >= vlim[1] or elim[0] >= elim[1]:
            raise ValueError(f"{node['label']}: Vmin must be below Vmax.")
        net.buses.append(dict(id=node["id"], label=node["label"], kind=node["kind"], kv=kv, on=on,
                              shunt_mvar=_num(over.get("shunt_mvar", 0.0), "Shunt Mvar", -1000, 1000), overridden=sorted(over),
                              vlim=vlim, elim=elim, user=dict(over)))
    _number_buses(net)
    # Branches (wires)
    for edge in diagram["lines"]:
        f, t = net.index[edge["source"]], net.index[edge["target"]]
        over = line_over.get(edge["id"]) or {}
        kv_f, kv_t = net.buses[f]["kv"], net.buses[t]["kv"]
        length = _num(over.get("length_km", edge["length_km"]), "Line length", 0, 10000)
        kind = over.get("kind") or ("transformer" if abs(kv_f - kv_t) > 1e-9 else ("tie" if length <= 0 else "line"))
        if kind not in ("line", "transformer", "tie"):
            raise ValueError("Branch kind must be line, transformer or tie.")
        if kind in ("line", "tie") and abs(kv_f - kv_t) > 1e-9:
            raise ValueError(f"Wire {edge['id']} joins {kv_f:g} kV and {kv_t:g} kV buses; it must be a transformer "
                             "(or set both buses to the same kV).")
        branch = dict(id=edge["id"], f=f, t=t, kind=kind, on=over.get("in_service", True) is not False,
                      from_id=edge["source"], to_id=edge["target"], owner=edge["owner"], overridden=sorted(over), user=dict(over))
        if kind == "tie":
            branch.update(r=TIE_R_PU, x=TIE_X_PU, b=0.0, tap=1.0, tap_side="f", rating=None, length_km=length)
        elif kind == "line":
            circuits = _num(over.get("circuits", 1), "Circuits", 1, 10)
            ltype = over.get("type") or ("cable" if length <= 1.0 else "overhead")
            if ltype not in ("overhead", "cable"):
                raise ValueError("Line type must be overhead or cable.")
            row = line_class(kv_f, ltype)
            r = _num(over.get("r_ohm_km", row["r"]), "r ohm/km", 0, 100)
            x = _num(over.get("x_ohm_km", row["x"]), "x ohm/km", 0, 100)
            b = _num(over.get("b_us_km", row["b"]), "b uS/km", 0, 10000)
            if r == 0 and x == 0:
                raise ValueError(f"Line {edge['id']} has zero impedance; enter r and x or use a bus tie (length 0).")
            if "rating_mva" in over:
                rating = _num(over["rating_mva"], "Rating MVA", 0.001, 1e5)
            else:
                amps = _num(over.get("ampacity_a", row["amps"]), "Ampacity A", 1, 1e5)
                rating = math.sqrt(3) * kv_f * amps / 1000.0 * circuits
            zbase = kv_f ** 2 / BASE_MVA
            branch.update(r=r * length / circuits / zbase, x=x * length / circuits / zbase,
                          b=b * 1e-6 * length * circuits * zbase, tap=1.0, tap_side="f", rating=rating,
                          length_km=length, type=ltype, circuits=circuits, r_ohm_km=r, x_ohm_km=x, b_us_km=b)
        else:
            branch.update(kind="transformer", length_km=length, tap_side="f" if kv_f >= kv_t else "t")
            branch["auto_mva"] = "mva" not in over
            branch["mva"] = _num(over["mva"], "Transformer MVA", 0.01, 5000) if "mva" in over else None
            branch["over_z"], branch["over_xr"] = over.get("z_pct"), over.get("xr")
            branch["tap"] = _num(over.get("tap", 1.0), "Transformer tap", 0.8, 1.2)
            branch.update(r=0, x=0, b=0.0, rating=None)
        net.branches.append(branch)
    # Generators and loads
    for node in diagram["nodes"]:
        over, bus = node_over.get(node["id"]) or {}, net.bus(node["id"])
        if node["kind"] == "load":
            net.loads.append(dict(node=node["id"], idx=net.index[node["id"]], weight=_num(over.get("weight", 1.0), "Load weight", 0, 1e6),
                                  pf=_num(over.get("pf", load_pf), "Load pf", 0.5, 1.0), on=bus["on"],
                                  fixed_mw=_num(over["load_mw"], "Load MW", 0, 1e5) if "load_mw" in over else None,
                                  fixed_mvar=_num(over["load_mvar"], "Load Mvar", -1e5, 1e5) if "load_mvar" in over else None))
        elif node["kind"] in TECH_GEN | {"grid"}:
            tech = node["kind"]
            cap = over.get("cap_mw", caps.get(tech))
            gen = dict(node=node["id"], idx=net.index[node["id"]], tech=tech, on=bus["on"],
                       cap=_num(cap, "Capacity MW", 0, 1e6) if cap is not None else None, cap_user="cap_mw" in over,
                       pmin=over.get("pmin_mw"), pmax=over.get("pmax_mw"), mbase=over.get("mbase_mva"), xd2=over.get("xd2_pu"))
            if tech == "grid":
                sc_default = DEFAULTS["grid_short_circuit"]["value"]
                sc_fallback = settings.get("grid_sc_mva", sc_default["mva_le_33kv"] if bus["kv"] <= 33 else sc_default["mva_gt_33kv"])
                gen.update(sc_mva=_num(over.get("sc_mva", sc_fallback), "Short-circuit MVA", 1, 1e7),
                           xr=_num(over.get("xr", settings.get("grid_xr", sc_default["xr"])), "Grid X/R", 0.1, 200),
                           vset=_num(over.get("vset", 1.0), "Grid voltage pu", 0.8, 1.2))
            else:
                pf_defaults = DEFAULTS["inverter_pf"]["value"]
                inverter = tech in ("pv", "bess", "wind")
                rated = (unit_pf or {}).get(tech) or unitpf.for_tech({}, tech)
                gen.update(control=over.get("control", "voltage"),
                           pf=_num(over.get("pf", rated["pf"]), "Generator pf", 0.5, 1.0),
                           pf_mode=over.get("pf_mode", "lag"), vset=_num(over.get("vset", 1.0), "Voltage setpoint pu", 0.8, 1.2),
                           q_mvar=_num(over.get("q_mvar", 0.0), "Q Mvar", -1e5, 1e5), inverter=inverter,
                           q_min=over.get("q_min_mvar"), q_max=over.get("q_max_mvar"),
                           rated_pf=_num(over.get("rated_pf", rated["pf"]), "Operating power factor", unitpf.PF_MIN, unitpf.PF_MAX),
                           rated_pf_lead=_num(over.get("rated_pf_lead", rated["pf_lead"]), "Leading power factor limit",
                                              unitpf.PF_MIN, unitpf.PF_MAX))
                if gen["control"] not in ("pf", "voltage", "q") or gen["pf_mode"] not in ("lag", "lead"):
                    raise ValueError("Generator control must be pf, voltage or q and pf_mode lag or lead.")
            net.gens.append(gen)
    for gen in net.gens:
        if gen["tech"] == "grid":
            # Internal slack bus behind the Thevenin impedance.
            net.index[gen["node"] + "__src"] = len(net.buses)
            src_num = 9001 + sum(1 for b in net.buses if b["kind"] == "source")
            net.buses.append(dict(id=gen["node"] + "__src", label="Grid source", kind="source", kv=net.bus(gen["node"])["kv"],
                                  on=gen["on"], shunt_mvar=0.0, overridden=[], vlim=net.limits["voltage"], elim=net.limits["n1_voltage"],
                                  user={}, num=src_num, name=f"GRID_SRC_{src_num - 9000}", display=f"Grid source ({src_num})"))
            z = BASE_MVA / gen["sc_mva"]
            r = z / math.sqrt(1 + gen["xr"] ** 2)
            net.branches.append(dict(id=gen["node"] + "__eq", f=net.index[gen["node"] + "__src"], t=gen["idx"], kind="source",
                                     on=gen["on"], r=r, x=r * gen["xr"], b=0.0, tap=1.0, tap_side="f", rating=None,
                                     length_km=0, from_id=gen["node"] + "__src", to_id=gen["node"], owner="grid", overridden=[]))
            gen["src_idx"] = net.index[gen["node"] + "__src"]
    if not net.loads:
        raise ValueError("Add at least one Load node to the single-line diagram.")
    _mark_orphan_loads(net)
    _size_transformers(net, peak_load_mw, caps)
    _name_branches(net)
    return net


def _mark_orphan_loads(net):
    """Loads with no path to any source in the intact network are ignored (with a warning), not served."""
    graph = _adjacency(net)
    sources = [g["src_idx"] if g["tech"] == "grid" else g["idx"] for g in net.gens
               if g["on"] and (g["tech"] == "grid" or (g["tech"] in {"bess"} | GENSETS and (g["cap"] or 0) > 0))]
    energized = set()
    for s in sources:
        energized |= _reach(graph, s)
    for load in net.loads:
        if load["on"] and load["idx"] not in energized:
            load["on"] = False
            net.warnings.append(f"Load '{net.buses[load['idx']]['display']}' is not connected to the grid or a "
                                "grid-forming source and was ignored; draw wires to it.")
    if not any(l["on"] for l in net.loads):
        raise ValueError("No Load node is connected to a source. Connect the Load through wires/buses to the Grid or a "
                         "grid-forming BESS/genset.")


def _adjacency(net, skip=None):
    graph = {i: [] for i in range(len(net.buses))}
    for k, br in enumerate(net.branches):
        if br["on"] and k != skip and net.buses[br["f"]]["on"] and net.buses[br["t"]]["on"]:
            graph[br["f"]].append(br["t"])
            graph[br["t"]].append(br["f"])
    return graph


def _reach(graph, start):
    seen, stack = {start}, [start]
    while stack:
        for nxt in graph[stack.pop()]:
            if nxt not in seen:
                seen.add(nxt)
                stack.append(nxt)
    return seen


def _size_transformers(net, peak_load_mw, caps):
    weights = sum(l["weight"] for l in net.loads if l["on"]) or 1.0
    peak = peak_load_mw if peak_load_mw is not None else 0.0
    for k, br in enumerate(net.branches):
        if br["kind"] != "transformer":
            continue
        graph = _adjacency(net, skip=k)
        lv = br["t"] if br["tap_side"] == "f" else br["f"]
        side = _reach(graph, lv)
        bridge = br["f"] not in side or br["t"] not in side
        if bridge:
            load = sum(peak * l["weight"] / weights for l in net.loads if l["idx"] in side and l["on"])
            gen = sum(g["cap"] or 0 for g in net.gens if g["idx"] in side and g["tech"] != "grid" and g["on"])
        else:
            load = peak
            gen = sum(g["cap"] or 0 for g in net.gens if g["tech"] != "grid" and g["on"])
        basis = max(load, gen)
        mva = br["mva"] if br["mva"] is not None else standard_mva(max(basis / 0.95, 0.5))
        z_pct, xr = transformer_defaults(mva)
        z_pct = float(br["over_z"]) if br["over_z"] is not None else z_pct
        xr = float(br["over_xr"]) if br["over_xr"] is not None else xr
        if not 0.5 <= z_pct <= 30 or xr <= 0:
            raise ValueError(f"Transformer {br['id']}: %Z must be 0.5-30 and X/R positive.")
        z = z_pct / 100.0 * BASE_MVA / mva
        r = z / math.sqrt(1 + xr ** 2)
        br.update(mva=mva, rating=mva, z_pct=z_pct, xr=xr, r=r, x=r * xr, basis_mw=basis,
                  sized="user" if not br["auto_mva"] else ("auto: " + ("radial" if bridge else "network") + " basis"))


def _ybus(net, active, shunt=True):
    n = len(net.buses)
    Y = np.zeros((n, n), dtype=complex)
    for k, br in enumerate(net.branches):
        if not active[k]:
            continue
        f, t = br["f"], br["t"]
        ys = 1.0 / complex(br["r"], br["x"])
        half = 1j * br["b"] / 2
        tap = br["tap"]
        if br["tap_side"] == "f":
            Y[f, f] += (ys + half) / tap ** 2
            Y[t, t] += ys + half
        else:
            Y[f, f] += ys + half
            Y[t, t] += (ys + half) / tap ** 2
        Y[f, t] += -ys / tap
        Y[t, f] += -ys / tap
    if shunt:
        for i, bus in enumerate(net.buses):
            if bus["shunt_mvar"]:
                Y[i, i] += 1j * bus["shunt_mvar"] / BASE_MVA
    return Y


def newton_solve(Y, V0, Sspec, kinds, tol=1e-8, maxit=30):
    """Polar Newton-Raphson.  kinds: 0=PQ, 1=PV, 2=slack.  Sspec = scheduled injection (pu).
    Returns (V, converged, iterations, max_mismatch)."""
    V = V0.astype(complex).copy()
    pv, pq = np.where(kinds == 1)[0], np.where(kinds == 0)[0]
    pvpq = np.r_[pv, pq]
    err = 0.0
    for it in range(maxit + 1):
        S = V * np.conj(Y @ V)
        mis = S - Sspec
        F = np.r_[mis[pvpq].real, mis[pq].imag]
        err = float(np.max(np.abs(F))) if F.size else 0.0
        if not math.isfinite(err):
            return V, False, it, err
        if err < tol:
            return V, True, it, err
        if it == maxit or err > 1e8:
            break
        Ibus = Y @ V
        diagV, diagI = np.diag(V), np.diag(Ibus)
        diagVn = np.diag(V / np.abs(V))
        dVm = diagV @ np.conj(Y @ diagVn) + np.conj(diagI) @ diagVn
        dVa = 1j * diagV @ np.conj(diagI - Y @ diagV)
        J = np.block([[dVa.real[np.ix_(pvpq, pvpq)], dVm.real[np.ix_(pvpq, pq)]],
                      [dVa.imag[np.ix_(pq, pvpq)], dVm.imag[np.ix_(pq, pq)]]])
        try:
            dx = np.linalg.solve(J, -F)
        except np.linalg.LinAlgError:
            return V, False, it, err
        Va, Vm = np.angle(V), np.abs(V)
        Va[pvpq] += dx[:len(pvpq)]
        Vm[pq] += dx[len(pvpq):]
        if np.min(Vm[pq]) < 0.05 if len(pq) else False:
            return V, False, it, err
        V = Vm * np.exp(1j * Va)
    return V, False, maxit, err


def _q_limits(gen, p):
    if gen.get("q_min") is not None and gen.get("q_max") is not None:
        return float(gen["q_min"]), float(gen["q_max"])
    cap = gen["cap"] if gen["cap"] is not None else abs(p)
    cap = max(cap, abs(p))
    if abs(p) < 1e-6 and not gen.get("inverter") and gen["tech"] != "bess":
        return 0.0, 0.0  # an idle synchronous genset is offline and offers no reactive support
    # Inverter-based resources (PV, BESS, wind) keep their converter apparent power S = MW / pf at zero MW (IEEE 2800 / 1547
    # reactive capability at any active-power level), so Q range at P is +-sqrt(S^2 - P^2).
    lag, lead = gen.get("rated_pf", unitpf.DEFAULT_PF), gen.get("rated_pf_lead", unitpf.DEFAULT_PF)
    return unitpf.q_capability(cap, p, lag, lead)


def _gen_pq(gen, p):
    """Scheduled (P, Q, controlled) in MW/MVAr for a non-slack source."""
    if gen["control"] == "pf":
        q = abs(p) * math.tan(math.acos(gen["pf"])) * (1 if gen["pf_mode"] == "lag" else -1)
        return p, q, False
    if gen["control"] == "q":
        return p, gen["q_mvar"], False
    return p, 0.0, True


def solve_case(net, inj, outages=(), gens_out=(), label=""):
    """Solve one operating point.
    inj = dict(load_mw=total MW, gens={tech: dict(p=MW)})  (grid/slack output is computed).
    outages: branch ids removed; gens_out: technologies (e.g. 'grid') disconnected."""
    outages, gens_out = set(outages), set(gens_out)
    nb = len(net.buses)
    bus_on = [b["on"] for b in net.buses]
    gen_on = [g["on"] and g["tech"] not in gens_out for g in net.gens]
    for g, on in zip(net.gens, gen_on):
        if g["tech"] == "grid" and not on:
            bus_on[g["src_idx"]] = False
    active = [br["on"] and br["id"] not in outages and bus_on[br["f"]] and bus_on[br["t"]] and
              not (br["kind"] == "source" and not gen_on[next(i for i, g in enumerate(net.gens) if g["node"] + "__eq" == br["id"])])
              for br in net.branches]
    graph = {i: [] for i in range(nb)}
    for k, br in enumerate(net.branches):
        if active[k]:
            graph[br["f"]].append(br["t"])
            graph[br["t"]].append(br["f"])
    load_total = float(inj.get("load_mw", 0.0))
    fixed_total = sum(l["fixed_mw"] for l in net.loads if l["on"] and l["fixed_mw"] is not None)
    weight = sum(l["weight"] for l in net.loads if l["on"] and l["fixed_mw"] is None) or 1.0
    load_p, load_q = np.zeros(nb), np.zeros(nb)
    for l in net.loads:
        if l["on"]:
            p = l["fixed_mw"] if l["fixed_mw"] is not None else max(load_total - fixed_total, 0.0) * l["weight"] / weight
            load_p[l["idx"]] += p
            load_q[l["idx"]] += l["fixed_mvar"] if l["fixed_mvar"] is not None else p * math.tan(math.acos(l["pf"]))
    Y = _ybus(net, active)
    V = np.zeros(nb, dtype=complex)
    components, seen = [], set()
    for start in range(nb):
        if start in seen or not bus_on[start]:
            continue
        comp = _reach(graph, start)
        seen |= comp
        components.append(sorted(comp))
    gen_result = {}
    islands, converged, iterations, mismatch = [], True, 0, 0.0
    served_load = 0.0
    for comp in components:
        cset = set(comp)
        gens_here = [(i, g) for i, g in enumerate(net.gens) if gen_on[i] and g["idx"] in cset and g["tech"] != "grid"
                     or (g["tech"] == "grid" and gen_on[i] and g["src_idx"] in cset)]
        load_here = float(sum(load_p[j] for j in comp))
        slack = None
        grid = next(((i, g) for i, g in gens_here if g["tech"] == "grid"), None)
        if grid:
            slack = (grid[0], grid[1]["src_idx"], grid[1]["vset"])
        else:
            forming = sorted((x for x in gens_here if x[1]["tech"] == "bess" and (x[1]["cap"] or 0) > 0),
                             key=lambda x: -(x[1]["cap"] or 0))
            forming += sorted((x for x in gens_here if x[1]["tech"] in GENSETS and (x[1]["cap"] or 0) > 0),
                              key=lambda x: -(x[1]["cap"] or 0))
            if forming:
                slack = (forming[0][0], forming[0][1]["idx"], forming[0][1].get("vset", 1.0))
        names = [net.buses[j]["id"] for j in comp if not net.buses[j]["id"].endswith("__src")]
        if len(comp) == 1 and net.buses[comp[0]]["kind"] == "source":
            continue
        island = dict(buses=names, load_mw=round(load_here, 4), energized=slack is not None,
                      slack=net.buses[slack[1]]["id"] if slack else None)
        if slack is None:
            gens_lost = sum(max(inj.get("gens", {}).get(g["tech"], {}).get("p", 0.0), 0.0) for _, g in gens_here)
            island.update(unserved_mw=round(load_here, 4), lost_generation_mw=round(gens_lost, 4),
                          reason="no grid or grid-forming BESS/genset in this part of the network")
            islands.append(island)
            continue
        islands.append(island)
        local = {j: k for k, j in enumerate(comp)}
        sub_active = list(active)
        Ysub = Y[np.ix_(comp, comp)]
        n = len(comp)
        kinds = np.zeros(n, dtype=int)
        vset = np.ones(n)
        Sspec = np.zeros(n, dtype=complex)
        controlled = {}
        for j in comp:
            Sspec[local[j]] -= complex(load_p[j], load_q[j]) / BASE_MVA
        for i, g in gens_here:
            if g["tech"] == "grid" or i == slack[0]:
                continue
            p, q, ctrl = _gen_pq(g, float(inj.get("gens", {}).get(g["tech"], {}).get("p", 0.0)))
            k = local[g["idx"]]
            Sspec[k] += complex(p, q) / BASE_MVA
            if ctrl:
                lo, hi = _q_limits(g, p)
                controlled[k] = dict(gen=i, p=p, qmin=lo, qmax=hi, vset=g["vset"], state="pv")
                if hi - lo < 1e-9:
                    # no reactive capability (idle unit): a plain PQ injection that never switches back to voltage control
                    controlled[k].update(state="limit", q_fixed=hi, pinned=True)
                    Sspec[k] += complex(0.0, hi - q) / BASE_MVA
        kinds[local[slack[1]]] = 2
        vset[local[slack[1]]] = slack[2]
        for k, c in controlled.items():
            kinds[k] = 0 if c.get("pinned") else 1
            vset[k] = c["vset"]
        V0 = vset.astype(complex)
        Vs, ok, it = V0, False, 0
        for _round in range(15):
            Vs, ok, it, err = newton_solve(Ysub, V0, Sspec, kinds)
            if not ok and any(kinds[k] == 1 for k in controlled) and not island.get("voltage_control_disabled"):
                # A stiff voltage-controlled bus next to a very low-impedance tie can make the Jacobian singular: retry the
                # island with every unit at zero Q (plain PQ) rather than reporting a false collapse.
                for k, c in controlled.items():
                    c["state"] = "fixed"
                    kinds[k] = 0
                    Sspec[k] = complex(c["p"], 0.0) / BASE_MVA - complex(load_p[comp[k]], load_q[comp[k]]) / BASE_MVA
                island["voltage_control_disabled"] = True
                V0 = vset.astype(complex)
                Vs, ok, it, err = newton_solve(Ysub, V0, Sspec, kinds)
            if not ok:
                break
            S = Vs * np.conj(Ysub @ Vs)
            changed = False
            for k, c in controlled.items():
                qgen = S[k].imag * BASE_MVA + load_q[comp[k]]
                if c["state"] == "fixed" or c.get("pinned"):
                    continue
                if c["state"] == "pv":
                    lim = c["qmax"] if qgen > c["qmax"] + 1e-6 else c["qmin"] if qgen < c["qmin"] - 1e-6 else None
                    if lim is not None:
                        c["state"] = "limit"
                        kinds[k] = 0
                        Sspec[k] = complex(c["p"], lim) / BASE_MVA - complex(load_p[comp[k]], load_q[comp[k]]) / BASE_MVA
                        c["q_fixed"] = lim
                        changed = True
                else:
                    lim = c["q_fixed"]
                    if (lim == c["qmax"] and abs(Vs[k]) > c["vset"] + 1e-6) or (lim == c["qmin"] and abs(Vs[k]) < c["vset"] - 1e-6):
                        c["state"] = "pv"
                        kinds[k] = 1
                        changed = True
            if not changed:
                break
            V0 = Vs.copy()
            for k, c in controlled.items():
                if kinds[k] == 1:
                    V0[k] = c["vset"] * V0[k] / abs(V0[k])
        else:
            # PV/PQ switching chattered (e.g. a stiff unit tied by a near-zero impedance): hold every unit still outside its
            # limits at that limit and solve once more.
            S = Vs * np.conj(Ysub @ Vs)
            for k, c in controlled.items():
                qgen = S[k].imag * BASE_MVA + load_q[comp[k]]
                if c["state"] == "pv" and not c["qmin"] - 1e-3 <= qgen <= c["qmax"] + 1e-3:
                    lim = min(max(qgen, c["qmin"]), c["qmax"])
                    c["state"], c["q_fixed"], kinds[k] = "limit", lim, 0
                    Sspec[k] = complex(c["p"], lim) / BASE_MVA - complex(load_p[comp[k]], load_q[comp[k]]) / BASE_MVA
            Vs, ok, it, err = newton_solve(Ysub, Vs, Sspec, kinds)
        converged &= ok
        iterations = max(iterations, it)
        island["converged"] = bool(ok)
        if not ok:
            island["failure"] = "Newton-Raphson did not converge (voltage collapse or an overloaded/unsupported network)."
            continue
        S = Vs * np.conj(Ysub @ Vs) * BASE_MVA
        for j in comp:
            V[j] = Vs[local[j]]
        for i, g in gens_here:
            k = local[g["src_idx"] if g["tech"] == "grid" else g["idx"]]
            if g["tech"] == "grid":
                gen_result[i] = dict(p=float(S[k].real), q=float(S[k].imag), slack=True)
            elif i == slack[0]:
                p_slack, q_slack = float(S[k].real + load_p[g["idx"]]), float(S[k].imag + load_q[g["idx"]])
                cap = g["cap"]
                gen_result[i] = dict(p=p_slack, q=q_slack, slack=True, forming=True)
                if cap is not None and abs(p_slack) > cap * 1.0 + 1e-6:
                    island["forming_overload_mw"] = round(abs(p_slack), 3)
                    island["forming_capacity_mw"] = cap
            elif k in controlled:
                c = controlled[k]
                gen_result[i] = dict(p=c["p"], q=float(S[k].imag + load_q[g["idx"]]), limited=c["state"] == "limit")
            else:
                p, q, _ = _gen_pq(g, float(inj.get("gens", {}).get(g["tech"], {}).get("p", 0.0)))
                gen_result[i] = dict(p=p, q=q)
        served_load += load_here
    return _collect(net, inj, V, active, gen_result, islands, converged, iterations, load_p, load_q, gens_out, outages, label)


def _collect(net, inj, V, active, gen_result, islands, converged, iterations, load_p, load_q, gens_out, outages, label):
    buses = []
    nodes_result = {}
    for i, bus in enumerate(net.buses):
        if bus["kind"] == "source":
            continue
        energized = abs(V[i]) > 0
        entry = dict(id=bus["id"], label=bus["label"], num=bus["num"], name=bus["name"], display=bus["display"], kind=bus["kind"],
                     kv=bus["kv"], energized=bool(energized),
                     vm=round(float(abs(V[i])), 5), va_deg=round(float(np.degrees(np.angle(V[i]))), 3) if energized else 0.0,
                     load_mw=round(float(load_p[i]), 4), load_mvar=round(float(load_q[i]), 4),
                     gen_mw=0.0, gen_mvar=0.0, in_service=bus["on"])
        if bus["shunt_mvar"]:
            # nominal rating at 1 pu; delivered Mvar scales with V^2
            entry.update(shunt_mvar=round(bus["shunt_mvar"], 4), shunt_kind="capacitor" if bus["shunt_mvar"] > 0 else "reactor",
                         shunt_q_mvar=round(float(bus["shunt_mvar"] * abs(V[i]) ** 2), 4))
        buses.append(entry)
        nodes_result[bus["id"]] = entry
    for i, g in enumerate(net.gens):
        r = gen_result.get(i)
        if r:
            e = nodes_result[g["node"]]
            if g["tech"] == "grid":
                e["gen_mw"], e["gen_mvar"] = 0.0, 0.0
            else:
                e["gen_mw"], e["gen_mvar"] = round(r["p"], 4), round(r["q"], 4)
            e["slack"] = bool(r.get("slack"))
            e["q_limited"] = bool(r.get("limited"))
    branches, losses, eq_loss, eq_flow = [], 0.0, 0.0, {}
    for k, br in enumerate(net.branches):
        f, t = br["f"], br["t"]
        row = dict(id=br["id"], kind=br["kind"], name=br.get("name", br["id"]), from_id=br["from_id"], to_id=br["to_id"],
                   from_name=net.names.get(br["from_id"], br["from_id"]), to_name=net.names.get(br["to_id"], br["to_id"]),
                   in_service=bool(active[k]),
                   p_from_mw=0.0, q_from_mvar=0.0, p_to_mw=0.0, q_to_mvar=0.0, loading_pct=0.0, loss_mw=0.0,
                   rating_mva=br["rating"], energized=False)
        if active[k] and abs(V[f]) > 0 and abs(V[t]) > 0:
            ys = 1.0 / complex(br["r"], br["x"])
            half = 1j * br["b"] / 2
            tap = br["tap"]
            if br["tap_side"] == "f":
                yff, ytt = (ys + half) / tap ** 2, ys + half
            else:
                yff, ytt = ys + half, (ys + half) / tap ** 2
            yft = ytf = -ys / tap
            sf = V[f] * np.conj(yff * V[f] + yft * V[t]) * BASE_MVA
            st = V[t] * np.conj(ytf * V[f] + ytt * V[t]) * BASE_MVA
            row.update(p_from_mw=float(sf.real), q_from_mvar=float(sf.imag), p_to_mw=float(st.real), q_to_mvar=float(st.imag),
                       loss_mw=float(sf.real + st.real), energized=True)
            if br["rating"]:
                if br["kind"] == "line":
                    # Line and cable ratings are current limits: I = S/V (per unit of the rating at nominal voltage).
                    apparent = max(abs(sf) / abs(V[f]), abs(st) / abs(V[t]))
                else:
                    apparent = max(abs(sf), abs(st))
                row["loading_pct"] = float(apparent / br["rating"] * 100.0)
            if br["kind"] == "source":
                eq_loss += row["loss_mw"]
                eq_flow[br["to_id"]] = (-row["p_to_mw"], -row["q_to_mvar"])
            else:
                losses += row["loss_mw"]
        if br["kind"] != "source":
            branches.append({k: (round(v, 4) if isinstance(v, float) else v) for k, v in row.items()})
    live = [b for b in buses if b["energized"]]
    total_gen = {}
    for i, g in enumerate(net.gens):
        if i in gen_result and g["tech"] != "grid":
            total_gen[g["tech"]] = round(gen_result[i]["p"], 4)
    grid_mw = None
    for g in net.gens:
        if g["tech"] == "grid" and g["node"] in eq_flow:
            grid_mw = round(eq_flow[g["node"]][0], 4)
            nodes_result[g["node"]].update(gen_mw=round(eq_flow[g["node"]][0], 4), gen_mvar=round(eq_flow[g["node"]][1], 4))
    served = sum(b["load_mw"] for b in buses if b["energized"])
    case = dict(label=label, converged=bool(converged), iterations=int(iterations), islands=islands, buses=buses, branches=branches,
                load_mw=round(float(sum(load_p)), 4), served_load_mw=round(served, 4), gen_mw=total_gen,
                slack_mw=grid_mw, losses_mw=round(losses, 5), grid_equivalent_loss_mw=round(eq_loss, 5),
                outages=sorted(outages), gens_out=sorted(gens_out))
    case["unserved_mw"] = round(case["load_mw"] - case["served_load_mw"], 4)
    case["internal"] = [dict(id=b["id"], vm=round(float(abs(V[i])), 5), va_deg=round(float(np.degrees(np.angle(V[i]))), 3)
                             if abs(V[i]) > 0 else 0.0) for i, b in enumerate(net.buses) if b["kind"] == "source"]
    rows = []
    for i, g in enumerate(net.gens):
        r = gen_result.get(i)
        if not r:
            continue
        p, q = float(r["p"]), float(r["q"])
        src_p, src_q = p, q
        if g["tech"] == "grid":
            if g["node"] in eq_flow:
                p, q = eq_flow[g["node"]]
            cap = None
        else:
            cap = g["cap"]
        qlo, qhi = (None, None) if g["tech"] == "grid" else _q_limits(g, p)
        rated = (float(g["mbase"]) if g.get("mbase") else cap / g.get("rated_pf", unitpf.DEFAULT_PF)) if cap else None
        rows.append(dict(id=g["node"], name=net.names.get(g["node"], g["node"]), tech=g["tech"], p_mw=round(p, 4), q_mvar=round(q, 4), cap_mw=cap, q_min=qlo, q_max=qhi,
                         rated_mva=round(rated, 4) if rated else None,
                         pct_mw=round(abs(p) / cap * 100.0, 2) if cap else None,
                         pct_mva=round(math.hypot(p, q) / rated * 100.0, 2) if rated else None,
                         slack=bool(r.get("slack")), q_limited=bool(r.get("limited")), src_p_mw=round(src_p, 4),
                         src_q_mvar=round(src_q, 4)))
    case["gens"] = rows
    if live:
        low = min(live, key=lambda b: b["vm"])
        high = max(live, key=lambda b: b["vm"])
        case.update(vmin=low["vm"], vmin_bus=low["id"], vmax=high["vm"], vmax_bus=high["id"],
                    vmin_name=low["display"], vmax_name=high["display"])
    else:
        case.update(vmin=0.0, vmin_bus=None, vmax=0.0, vmax_bus=None, vmin_name=None, vmax_name=None)
    case["names"] = dict(net.names)
    loaded = [b for b in branches if b["rating_mva"] and b["energized"]]
    worst = max(loaded, key=lambda b: b["loading_pct"]) if loaded else None
    case.update(max_loading_pct=worst["loading_pct"] if worst else 0.0, max_loading_branch=worst["id"] if worst else None)
    return case


def evaluate(net, case, emergency=False):
    """Violations with plain-language mitigations.  emergency=True (N-1) relaxes limits and downgrades severity."""
    thermal = net.limits["thermal"]
    sev = "warn" if emergency else "fail"
    nm = lambda ident: net.names.get(ident, ident)
    found = []
    if not case["converged"]:
        found.append(dict(type="non_convergence", severity=sev, component=None, value=None, limit=None,
                          message="Power flow did not converge: the case is beyond the network's transfer capability.",
                          mitigation="Reduce the load or generator MW at the weakest point, upsize the feeder/transformer, "
                                     "add reactive support, or strengthen the grid connection."))
    for island in case["islands"]:
        if not island["energized"] and (island["load_mw"] > 1e-6 or island.get("lost_generation_mw", 0) > 1e-6):
            found.append(dict(type="islanded", severity=sev if not emergency else "warn", component=island["buses"][0],
                              value=island["load_mw"], limit=0.0,
                              message=f"{len(island['buses'])} bus(es) ({', '.join(nm(b) for b in island['buses'][:4])}) are islanded with no "
                                      f"source: {island['load_mw']:.2f} MW load unserved, {island.get('lost_generation_mw', 0):.2f} MW "
                                      "generation disconnected.",
                              mitigation="Add a second (redundant) line or transformer, or a grid-forming BESS/genset in this section."))
        if island.get("forming_overload_mw"):
            found.append(dict(type="forming_overload", severity=sev, component=island["slack"], value=island["forming_overload_mw"],
                              limit=island["forming_capacity_mw"],
                              message=f"The grid-forming unit would have to supply {island['forming_overload_mw']:.2f} MW "
                                      f"(rating {island['forming_capacity_mw']:.2f} MW).",
                              mitigation="Increase grid-forming BESS/genset capacity or reduce generation/load imbalance in the island."))
    for bus in case["buses"]:
        if not bus["energized"] or bus["kind"] == "source":
            continue
        blim = net.bus(bus["id"])["elim" if emergency else "vlim"]
        low, high = blim
        sh = (f" (shunt {'capacitor' if bus['shunt_mvar'] > 0 else 'reactor'} {abs(bus['shunt_mvar']):.4g} Mvar at this bus delivers "
              f"{bus['shunt_q_mvar']:.4g} Mvar at this voltage)") if bus.get("shunt_mvar") else ""
        if bus["vm"] < low:
            found.append(dict(type="voltage_low", severity=sev, component=bus["id"], value=bus["vm"], limit=low,
                              message=f"{bus['display']} voltage {bus['vm']:.4f} pu is below {low:.4f} pu{sh}.",
                              mitigation="Add reactive support (capacitor/STATCOM) at this bus, change the transformer tap "
                                         "(lower HV-side ratio), upsize the feeder, or put generators on voltage control."))
        elif bus["vm"] > high:
            found.append(dict(type="voltage_high", severity=sev, component=bus["id"], value=bus["vm"], limit=high,
                              message=f"{bus['display']} voltage {bus['vm']:.4f} pu is above {high:.4f} pu{sh}.",
                              mitigation="Reduce generator output, let inverters absorb reactive power (pf 0.95 lead), raise the "
                                         "transformer tap ratio, or add a shunt reactor."))
        if bus.get("q_limited") and not low <= bus["vm"] <= high:
            # Running at a Q limit is normal; it is reported only when the voltage it could not hold is out of band.
            found.append(dict(type="reactive_limit", severity="warn", component=bus["id"], value=bus["gen_mvar"], limit=None,
                              message=f"{bus['display']} reached its reactive-power limit and cannot hold its voltage setpoint.",
                              mitigation="Add reactive support nearby or use a larger inverter/machine."))
    for br in case["branches"]:
        if not br["rating_mva"] or not br["energized"]:
            continue
        if br["loading_pct"] > thermal:
            kind = "transformer" if br["kind"] == "transformer" else "line"
            found.append(dict(type="thermal", severity=sev, component=br["id"], value=br["loading_pct"], limit=thermal,
                              message=f"{kind.capitalize()} {nm(br['id'])} is loaded to {br['loading_pct']:.1f} % of its "
                                      f"{br['rating_mva']:.2f} MVA rating.",
                              mitigation=("Add a second transformer in parallel or replace it with a larger unit." if kind == "transformer"
                                          else "Upsize the conductor/cable, add a parallel circuit, or reduce generator output behind it.")))
        elif br["loading_pct"] > net.limits["high"] and not emergency:
            found.append(dict(type="high_loading", severity="warn", component=br["id"], value=br["loading_pct"],
                              limit=net.limits["high"],
                              message=f"{nm(br['id'])} is loaded to {br['loading_pct']:.1f} % (above {net.limits['high']:.4g} % planning margin).",
                              mitigation="Little margin for load growth; consider the next conductor/transformer size."))
    for v in found:
        v["component_name"] = nm(v["component"]) if v["component"] else None
    return found


# --------------------------------------------------------------------------- dispatch handling

_CACHE = {}


def _read_dispatch(path):
    key = (str(path), Path(path).stat().st_mtime_ns)
    if key in _CACHE:
        return _CACHE[key]
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.reader(stream)
        header = next(reader)
        rows = list(reader)
    data = {"timestamp": [r[0] for r in rows]}
    for j, name in enumerate(header[1:], 1):
        data[name] = np.array([float(r[j]) if r[j] not in ("", None) else 0.0 for r in rows])
    if len(_CACHE) > 3:
        _CACHE.pop(next(iter(_CACHE)))
    _CACHE[key] = data
    return data


def _series(data, name):
    return data.get(name, np.zeros(len(data["timestamp"])))


def _hour_inputs(data, i):
    """Injection description for dispatch hour i (MW)."""
    load = float(_series(data, "net_served_load_mw")[i]) if "net_served_load_mw" in data else float(_series(data, "net_load_mw")[i])
    if "solar_output" in data:
        pv = float(data["solar_output"][i] + _series(data, "planned_solar_used")[i])
        wind = float(_series(data, "planned_wind_used")[i])
    else:
        pv, wind = float(_series(data, "pv")[i]), 0.0
    gens = {"pv": dict(p=max(pv, 0.0)), "wind": dict(p=max(wind, 0.0)),
            "bess": dict(p=float(_series(data, "discharge")[i] - _series(data, "charge")[i]))}
    for name, values in data.items():
        if name.startswith("gen_") and name[4:] in GENSETS:
            gens[name[4:]] = dict(p=float(values[i]))
    return dict(load_mw=load, gens=gens, grid_mw=float(_series(data, "grid")[i]), timestamp=data["timestamp"][i])


def _assign_genset_total(net, data, inj, i):
    """Older CSVs only carry aggregate 'gen'; assign it to the single genset node."""
    if any(t in inj["gens"] for t in GENSETS):
        return
    total = float(_series(data, "gen")[i])
    techs = [g["tech"] for g in net.gens if g["tech"] in GENSETS and g["on"]]
    if total > 1e-9 and techs:
        inj["gens"][techs[0]] = dict(p=total)


def _hour_selection(data):
    n = len(data["timestamp"])
    load = _series(data, "net_served_load_mw") if "net_served_load_mw" in data else _series(data, "net_load_mw")
    solar = (data["solar_output"] + _series(data, "planned_solar_used") + _series(data, "planned_wind_used")) \
        if "solar_output" in data else _series(data, "pv")
    gen = sum((v for k, v in data.items() if k.startswith("gen_") and k[4:] in GENSETS), np.zeros(n)) if any(
        k.startswith("gen_") for k in data) else _series(data, "gen")
    grid = _series(data, "grid")
    picks = [("Peak load", int(np.argmax(load))), ("Minimum load", int(np.argmin(load))),
             ("Maximum solar/wind output", int(np.argmax(solar))),
             ("Maximum BESS charging", int(np.argmax(_series(data, "charge")))),
             ("Maximum BESS discharging", int(np.argmax(_series(data, "discharge")))),
             ("Maximum grid import", int(np.argmax(grid))), ("Maximum genset output", int(np.argmax(gen)))]
    if float(grid.min()) < -1e-6:
        picks.append(("Maximum reverse flow (export)", int(np.argmin(grid))))
    else:
        surplus = solar - load
        picks.append(("Maximum reverse-flow risk (renewable surplus; no export in dispatch)", int(np.argmax(surplus))))
    return picks, int(np.argmax(load))


def _hourly_regular(stamps):
    """True when the dispatch timestamps are consecutive whole hours (so a date/time maps to an hour index by arithmetic)."""
    try:
        times = [datetime.fromisoformat(s.strip().replace("/", "-")) for s in stamps]
    except ValueError:
        return False
    return all((b - a).total_seconds() == 3600 for a, b in zip(times, times[1:]))


def _run_context(folder, code):
    folder = Path(folder)
    status = json.loads((folder / "status.json").read_text(encoding="utf-8"))
    request = json.loads((folder / "request.json").read_text(encoding="utf-8"))
    results = (status.get("summary") or {}).get("results") or []
    codes = [r["code"] for r in results]
    if not code:
        raise ValueError("Select a solved scenario.")
    if code not in codes and not (folder / f"result_{code}.json").is_file():
        raise ValueError("That scenario was not solved in this saved run.")
    path = folder / f"dispatch_{code}.csv"
    if not path.is_file():
        raise ValueError("This saved run has no hourly dispatch file for that scenario; solve it again.")
    result = json.loads((folder / f"result_{code}.json").read_text(encoding="utf-8")) if (folder / f"result_{code}.json").is_file() \
        else next(r for r in results if r["code"] == code)
    config = {}
    if (folder / "run_configuration.json").is_file():
        config = json.loads((folder / "run_configuration.json").read_text(encoding="utf-8"))
    caps = result.get("caps") or {}
    tech_caps = {"pv": caps.get("pv_dc_mw"), "bess": caps.get("bess_mw")}
    for key, value in (caps.get("generators_mw") or {}).items():
        tech_caps[key] = value
    if caps.get("wind_mw") is not None:
        tech_caps["wind"] = caps["wind_mw"]
    eligible = result.get("eligible_technologies")
    resolved = config.get("resolved") or {}
    return dict(folder=folder, request=request, path=path, caps=tech_caps, eligible=eligible,
                islanded=bool(resolved.get("islanded")) or (eligible is not None and "grid" not in eligible),
                topology=request.get("topology"), unit_pf=unitpf.from_values(request.get("values")))


def _default_techs(ctx):
    techs = {k for k, v in ctx["caps"].items() if v}
    if ctx["eligible"]:
        techs |= set(ctx["eligible"])
    if not ctx["islanded"]:
        techs.add("grid")
    return {k for k in techs if k in network_topology.TECHNOLOGIES}


def _drop_unbuilt(diagram, built, assumptions=None):
    """Electrical model only: remove generator nodes whose built capacity is 0 MW (eligible but not built) and their wires.
    The stored drawing is not touched."""
    over = (assumptions or {}).get("nodes") or {}
    drop = {}
    for n in diagram["nodes"]:
        if n["kind"] in TECH_GEN and n["kind"] not in built:
            cap = {**(n.get("electrical") or {}), **(over.get(n["id"]) or {})}.get("cap_mw")
            if not (isinstance(cap, (int, float)) and cap > 0):
                drop[n["id"]] = n
    if not drop:
        return diagram
    notes = list(diagram.get("_notes") or [])
    for n in drop.values():
        notes.append(f"{n['label']} ({n['kind']}) is eligible but 0 MW was built in this scenario: left out of the electrical model "
                     "(your stored drawing keeps it).")
    return dict(diagram, nodes=[n for n in diagram["nodes"] if n["id"] not in drop],
                lines=[e for e in diagram["lines"] if e["source"] not in drop and e["target"] not in drop], _notes=notes)


def _migrate_stale_auto_shunts(diagram):
    """In-memory clean-up on load (stored drawings and run folders are not rewritten): a capacitive bus-level electrical.shunt_mvar
    that the user never marked (shunt_user) is a leftover of an earlier automatic sizing, not a user entry, so it is dropped and
    reported.  Auto banks written now are separate 'shunt' nodes flagged shunt_auto and are re-sized by every technical check."""
    stale = []
    nodes = []
    for n in diagram["nodes"]:
        values = n.get("electrical") or {}
        if n["kind"] != "shunt" and values.get("shunt_mvar", 0.0) > 0 and not values.get("shunt_user"):
            values = {k: v for k, v in values.items() if k not in ("shunt_mvar", "shunt_steps", "shunt_step_mvar")}
            stale.append(f"{n['label']}: stored shunt {n['electrical']['shunt_mvar']:.4g} Mvar was an old automatic sizing, not a user entry; ignored.")
            n = dict(n, electrical=values)
            if not values:
                del n["electrical"]
        nodes.append(n)
    if not stale:
        return diagram
    return dict(diagram, nodes=nodes, _notes=list(diagram.get("_notes") or []) + stale)


def _prepare(ctx, code, assumptions, topology, data):
    stored_topology = topology if topology else ctx["topology"]
    if not topology and isinstance(stored_topology, dict) and (stored_topology.get("diagrams") or {}).get(code):
        stored_topology = dict(stored_topology, diagrams=dict(stored_topology["diagrams"]))
        stored_topology["diagrams"][code] = _migrate_stale_auto_shunts(stored_topology["diagrams"][code])
    diagram = _diagram(stored_topology, code, _default_techs(ctx))
    caps = {k: v for k, v in ctx["caps"].items() if v is not None}
    for tech, col in (("pv", None), ("wind", "planned_wind_used")):
        if tech not in caps or not caps[tech]:
            series = _hour_series_max(data, tech)
            if series > 0:
                caps[tech] = series
    if ctx["caps"]:
        diagram = _drop_unbuilt(diagram, {k for k, v in caps.items() if v and v > 0}, assumptions)
    load = _series(data, "net_served_load_mw") if "net_served_load_mw" in data else _series(data, "net_load_mw")
    return build_network(diagram, caps, assumptions, eligible=ctx["eligible"], islanded=ctx["islanded"],
                         peak_load_mw=float(load.max()), unit_pf=ctx.get("unit_pf"))


def _hour_series_max(data, tech):
    if tech == "pv":
        return float(((data["solar_output"] + _series(data, "planned_solar_used")) if "solar_output" in data else _series(data, "pv")).max())
    return float(_series(data, "planned_wind_used").max())


def _case_for_hour(net, data, i, label, **kwargs):
    inj = _hour_inputs(data, i)
    _assign_genset_total(net, data, inj, i)
    case = solve_case(net, inj, label=label, **kwargs)
    case.update(timestamp=inj["timestamp"], hour_index=i, dispatch_grid_mw=round(inj["grid_mw"], 4))
    return case


def _summary(net, case, emergency=False):
    violations = evaluate(net, case, emergency)
    out = {k: case.get(k) for k in ("label", "timestamp", "hour_index", "converged", "vmin", "vmin_bus", "vmax", "vmax_bus",
                                    "max_loading_pct", "max_loading_branch", "losses_mw", "load_mw", "unserved_mw", "slack_mw",
                                    "gen_mw", "outages", "gens_out", "dispatch_grid_mw")}
    out.update(violations=violations, detail=case, emergency=emergency)
    return out


def _status(cases):
    severities = {v["severity"] for c in cases for v in c["violations"]}
    return "FAIL" if "fail" in severities else "WARN" if "warn" in severities else "PASS"


ISLANDED_NOTE = ("Informational - not used for the recommendation. This shows what to expect if the grid were completely disconnected, "
                 "with the BESS / gensets forming the grid. It does not change the PASS/WARN/FAIL status, corrections, iterations or ranking.")


def islanded_study(net, data, peak_hour):
    """Informational complete-grid-disconnection study (grid out of service, BESS/gensets grid-forming) at the peak-load and
    minimum-load hours.  Returns None when the scenario has no grid; the result never feeds the decision."""
    if not any(g["tech"] == "grid" and g["on"] for g in net.gens):
        return None
    load = _series(data, "net_served_load_mw") if "net_served_load_mw" in data else _series(data, "net_load_mw")
    hours = [("Islanded - grid disconnected: peak load", peak_hour)]
    low = int(np.argmin(load))
    if low != peak_hour:
        hours.append(("Islanded - grid disconnected: minimum load", low))
    cases = []
    for label, i in hours:
        case = _case_for_hour(net, data, i, label, gens_out=["grid"])
        summary = _summary(net, case, emergency=True)
        summary["informational"] = True
        cases.append(summary)
    problems = [v for c in cases for v in c["violations"] if v["type"] in ("forming_overload", "islanded")]
    unconverged = any(not c["converged"] for c in cases)
    need = max((v["value"] for v in problems if v["type"] == "forming_overload"), default=None)
    rating = next((v["limit"] for v in problems if v["type"] == "forming_overload" and v["value"] == need), None)
    if problems or unconverged:
        status = "NOT_SUPPORTABLE"
        if need is not None:
            chip = f"Islanded: would not be self-supportable (needs {need:.2f} MW grid-forming vs {rating:.2f} MW)"
        else:
            chip = "Islanded: would not be self-supportable (no grid-forming source can carry the load)"
    elif any(c["violations"] for c in cases):
        status, chip = "LIMITED", "Islanded: self-supportable, with voltage or loading remarks"
    else:
        status, chip = "SUPPORTABLE", "Islanded: self-supportable at the screened hours"
    return dict(enabled=True, informational=True, status=status, chip=chip, note=ISLANDED_NOTE, cases=cases,
                needed_mw=need, rating_mw=rating)


def compact_islanded(study):
    """Islanded study without the heavy per-case solution, for stored results and reports."""
    if not study or not study.get("enabled"):
        return study
    keep = ("label", "timestamp", "hour_index", "converged", "vmin", "max_loading_pct", "load_mw", "slack_mw")
    cases = [dict({k: c.get(k) for k in keep}, violations=[v["message"] for v in c["violations"][:4]], count=len(c["violations"]))
             for c in study["cases"]]
    return dict({k: v for k, v in study.items() if k != "cases"}, cases=cases)


def screen_run(folder, scenario_code, assumptions=None, topology=None, n1=True, suggest=True, islanded=False):
    """Screening report for one solved scenario: PASS / WARN / FAIL plus per-case results.  islanded=True adds the informational
    report["islanded"] study (never part of status, violations, suggestions or cuts)."""
    ctx = _run_context(folder, scenario_code)
    data = _read_dispatch(ctx["path"])
    net = _prepare(ctx, scenario_code, assumptions, topology, data)
    picks, peak_hour = _hour_selection(data)
    merged = {}
    for label, i in picks:
        merged.setdefault(i, []).append(label)
    picks = [(" / ".join(labels), i) for i, labels in merged.items()]
    cases = []
    for label, i in picks:
        case = _case_for_hour(net, data, i, label)
        cases.append(_summary(net, case))
    if n1:
        base_inj = _hour_inputs(data, peak_hour)
        _assign_genset_total(net, data, base_inj, peak_hour)
        candidates = [b["id"] for b in net.branches if b["kind"] in ("line", "transformer") and b["on"]]
        for branch_id in candidates:
            case = solve_case(net, base_inj, outages=[branch_id], label=f"N-1: {branch_id} out (peak load)")
            case.update(timestamp=base_inj["timestamp"], hour_index=peak_hour)
            cases.append(_summary(net, case, emergency=True))
        gens = [(g["tech"], base_inj["gens"].get(g["tech"], {}).get("p", 0.0)) for g in net.gens
                if g["tech"] != "grid" and g["on"]]
        if gens:
            tech = max(gens, key=lambda x: abs(x[1]))[0]
            if abs(dict(gens)[tech]) > 1e-6:
                case = solve_case(net, base_inj, gens_out=[tech], label=f"N-1: largest generator ({tech}) out (peak load)")
                case.update(timestamp=base_inj["timestamp"], hour_index=peak_hour)
                cases.append(_summary(net, case, emergency=True))
    normal = [c for c in cases if not c["emergency"]]
    worst = max(normal, key=lambda c: c["max_loading_pct"])
    report = dict(scenario=scenario_code, status=_status(cases), normal_status=_status(normal),
                  n1_status=_status([c for c in cases if c["emergency"]]) if n1 else None,
                  cases=cases, hours=len(data["timestamp"]),
                  summary=dict(vmin=min(c["vmin"] for c in normal if c["converged"]) if any(c["converged"] for c in normal) else None,
                               vmax=max(c["vmax"] for c in normal if c["converged"]) if any(c["converged"] for c in normal) else None,
                               max_loading_pct=worst["max_loading_pct"], max_loading_branch=worst["max_loading_branch"],
                               max_losses_mw=max(c["losses_mw"] for c in normal),
                               violations=sum(len(c["violations"]) for c in cases)),
                  assumptions=describe(net), limitations=LIMITATIONS, warnings=net.warnings)
    report["cuts"] = suggest_cuts(report, net)
    report["screened"] = dict(
        hours=[dict(label=label, hour_index=i, timestamp=str(data["timestamp"][i])) for label, i in picks],
        n1=bool(n1), n1_hour_index=peak_hour if n1 else None, total_hours=len(data["timestamp"]),
        text=("Screened " + "; ".join(f"{label} (hour {i})" for label, i in picks) +
              (f"; plus N-1 of every line/transformer and the largest generator at the peak-load hour (hour {peak_hour})." if n1 else ".") +
              f" That is {len(cases)} cases out of {len(data['timestamp'])} dispatch hours."))
    report["failing_cases"] = failing_cases(cases)
    report["worst_case"] = report["failing_cases"][0] if report["failing_cases"] else None
    report["islanded"] = islanded_study(net, data, peak_hour) if islanded else None
    report["suggestions"], patch = ([], {})
    if suggest:
        import pf_suggest
        verifier = pf_suggest.Verifier(ctx, scenario_code, data, assumptions, topology, report)
        report["suggestions"], patch = pf_suggest.suggest(report, net, (ctx["request"] or {}).get("values"), verifier)
        report["verification"] = _verification(folder, scenario_code, assumptions, topology, n1, report, patch)
    return report


def _verification(folder, scenario_code, assumptions, topology, n1, report, patch):
    """Re-screen the whole scenario with every recommended electrical suggestion applied (full case set)."""
    import pf_suggest
    count = lambda rep: sum(len(c["violations"]) for c in rep["cases"])
    if not (patch.get("nodes") or patch.get("lines")):
        return dict(applied=False, status_before=report["status"], status_after=report["status"], violations_before=count(report),
                    violations_after=count(report), remaining=[], patch=patch,
                    text="No verified electrical change is recommended; see the advisories.")
    after = screen_run(folder, scenario_code, pf_suggest._merge(assumptions, patch), topology, n1=n1, suggest=False)
    remaining = [f"{c['label']}: {v['message']}" for c in after["cases"] for v in c["violations"]][:12]
    return dict(applied=True, status_before=report["status"], status_after=after["status"], violations_before=count(report),
                violations_after=count(after), remaining=remaining, patch=patch,
                summary_after=after["summary"],
                text=(f"Re-screening with all recommended electrical changes applied: {report['status']} -> {after['status']} "
                      f"({count(report)} -> {count(after)} violation(s) over {len(after['cases'])} cases)."))


def failing_cases(cases):
    """Cases with violations, worst first (fail before warn; normal before N-1).  Each row carries what the UI needs to load
    it into the SLD: hour_index, outages, gens_out (snapshot action parameters)."""
    rows = []
    for c in cases:
        sev = "fail" if any(v["severity"] == "fail" for v in c["violations"]) else "warn" if c["violations"] else None
        if sev:
            rows.append(dict(label=c["label"], severity=sev, emergency=bool(c["emergency"]), hour_index=c.get("hour_index"),
                             timestamp=c.get("timestamp"), outages=list(c.get("outages") or []), gens_out=list(c.get("gens_out") or []),
                             violations=[v["message"] for v in c["violations"][:4]], count=len(c["violations"])))
    rows.sort(key=lambda r: (r["severity"] != "fail", r["emergency"], -r["count"]))
    return rows


def technical_status(folder, scenario_code, **kwargs):
    """Never raises: for the solve worker.  Returns dict(status, summary, ...) or status 'NOT_RUN'."""
    try:
        report = screen_run(folder, scenario_code, **kwargs)
    except (ValueError, KeyError, OSError) as exc:
        return dict(scenario=scenario_code, status="NOT_RUN", message=str(exc))
    return dict(scenario=scenario_code, status=report["status"], normal_status=report["normal_status"],
                n1_status=report["n1_status"], summary=report["summary"],
                violations=[dict(case=c["label"], **v) for c in report["cases"] for v in c["violations"]][:50],
                cuts=report["cuts"], suggestions=report["suggestions"][:40], screened=report["screened"],
                failing_cases=report["failing_cases"][:10], warnings=report["warnings"], islanded=compact_islanded(report["islanded"]))


LIMITATIONS = ["Balanced positive-sequence steady-state AC power flow (Newton-Raphson); no harmonics, unbalance, "
               "dynamics, protection or short-circuit duty.",
               "Screening only: confirm with a PSS/E (or equivalent) study; defaults are typical values, not design data.",
               "Technologies are aggregated; the dispatch hour is applied to the SLD as a snapshot, with the grid or "
               "a grid-forming unit absorbing losses and mismatch.",
               "N-1 is evaluated at the peak-load hour; radial designs show islanding rather than redundancy."]


def describe(net):
    """Resolved (default or user) component data for the UI Assumptions / properties tables.

    Every node/branch carries num, name (PSS/E 12-char) and display; `tags` says whether each global setting is
    'assumed' (power_flow default) or 'user-set' (topology pf_settings / assumptions)."""
    def node_row(b):
        row = dict(id=b["id"], label=b["label"], num=b["num"], name=b["name"], display=b["display"], kind=b["kind"], kv=b["kv"],
                   in_service=b["on"], shunt_mvar=b["shunt_mvar"], overridden=b["overridden"], vmin_pu=b["vlim"][0], vmax_pu=b["vlim"][1],
                   vmin_emerg_pu=b["elim"][0], vmax_emerg_pu=b["elim"][1])
        for g in net.gens:
            if g["node"] == b["id"]:
                row.update({k: v for k, v in g.items() if k in ("cap", "control", "pf", "pf_mode", "vset", "sc_mva", "xr", "q_min", "q_max",
                                                                "pmin", "pmax", "mbase", "xd2", "rated_pf", "rated_pf_lead")})
                if g["tech"] != "grid" and g["cap"]:
                    row["rated_mva"] = round(g["mbase"] if g.get("mbase") else g["cap"] / g["rated_pf"], 4)
                    qlo, qhi = unitpf.q_limits(g["cap"], g["rated_pf"], g["rated_pf_lead"])
                    row["q_cap_min"], row["q_cap_max"] = round(qlo, 4), round(qhi, 4)
                row["cap_source"] = "user-set" if g.get("cap_user") else "from model" if g["cap"] is not None else "assumed"
                if g["tech"] == "grid":
                    row["sc_source"] = "user-set" if "sc_mva" in b["user"] or "grid_sc_mva" in net.settings else "assumed"
        for l in net.loads:
            if l["node"] == b["id"]:
                row.update({k: v for k, v in l.items() if k in ("weight", "pf")}, load_mw=l["fixed_mw"], load_mvar=l["fixed_mvar"])
        return row

    return dict(
        base=dict(voltage_limits=net.limits["voltage"], n1_voltage_limits=net.limits["n1_voltage"],
                  thermal_limit_pct=net.limits["thermal"], high_loading_pct=net.limits["high"], load_pf=net.base["load_pf"],
                  base_mva=net.base["base_mva"], islanded=net.base["islanded"],
                  grid_sc_mva=next((g["sc_mva"] for g in net.gens if g["tech"] == "grid"), None),
                  grid_xr=next((g["xr"] for g in net.gens if g["tech"] == "grid"), None)),
        tags=net.tags, names=dict(net.names),
        nodes=[node_row(b) for b in net.buses if b["kind"] != "source"],
        branches=[dict(id=br["id"], name=br["name"], kind=br["kind"], from_id=br["from_id"], to_id=br["to_id"], length_km=br["length_km"],
                       rating_mva=br["rating"], overridden=br["overridden"],
                       **{k: br["user"][k] for k in ("tap_min", "tap_max", "tap_steps", "vector_group", "cooling") if k in br["user"]},
                       **{k: br[k] for k in ("type", "circuits", "r_ohm_km", "x_ohm_km", "b_us_km", "mva", "z_pct", "xr", "tap",
                                             "sized") if k in br})
                  for br in net.branches if br["kind"] != "source"])


# --------------------------------------------------------------------------- technical cuts

def _behind(net, branch_id):
    """Technologies on the side of a bridge branch that holds no grid source (or the smaller side)."""
    k = next(i for i, b in enumerate(net.branches) if b["id"] == branch_id)
    br = net.branches[k]
    graph = _adjacency(net, skip=k)
    side_f, side_t = _reach(graph, br["f"]), _reach(graph, br["t"])
    if br["f"] in side_t:
        return []
    grid_idx = {g["idx"] for g in net.gens if g["tech"] == "grid"}
    far = side_t if grid_idx & side_f else side_f if grid_idx & side_t else (side_t if len(side_t) <= len(side_f) else side_f)
    return [g["tech"] for g in net.gens if g["idx"] in far and g["tech"] != "grid" and g["on"]]


def suggest_cuts(report, net=None):
    """Structured technical cuts for the optimiser owner.

    Each cut: dict(type, component, limit, unit, case, reason, severity).  Types:
      max_injection_mw          cap on a technology's MW at its bus (feed back as an upper bound/constraint)
      branch_upgrade            required MVA for a failing line/transformer (price as an upgrade cost)
      min_reactive_support_mvar minimum Mvar capacitor/STATCOM at a bus
      redundancy                add a parallel branch / second transformer for N-1
      min_forming_capacity_mw   grid-forming BESS/genset capacity needed in an island
      review_case               non-convergence: no safe numerical limit; reduce the named case's loading
    Limits are first-order estimates (sensitivities of the linearised network), to be validated by re-screening."""
    cuts, seen = [], set()
    def add(cut):
        key = (cut["type"], cut["component"])
        if key not in seen:
            seen.add(key)
            cuts.append(cut)
    for case in report["cases"]:
        detail = case["detail"]
        by_branch = {b["id"]: b for b in detail["branches"]}
        by_bus = {b["id"]: b for b in detail["buses"]}
        for v in case["violations"]:
            base = dict(case=case["label"], severity=v["severity"], reason=v["message"])
            t = v["type"]
            if t == "thermal":
                branch = by_branch[v["component"]]
                needed = round(branch["rating_mva"] * v["value"] / 100.0 / 0.95, 2)
                add(dict(type="branch_upgrade", component=v["component"], limit=needed, unit="MVA", **base))
                if net is not None and not case["emergency"]:
                    techs = [t_ for t_ in _behind(net, v["component"]) if detail["gen_mw"].get(t_, 0) > 1e-6]
                    if techs:
                        tech = max(techs, key=lambda x: detail["gen_mw"][x])
                        scale = 100.0 / v["value"] * 0.98
                        add(dict(type="max_injection_mw", component=tech, limit=round(detail["gen_mw"][tech] * scale, 3),
                                 unit="MW", **base))
            elif t == "voltage_low":
                dv = v["limit"] - v["value"] + 0.005
                xth = _thevenin_x(net, v["component"]) if net is not None else None
                q = round(dv * BASE_MVA / xth, 2) if xth else None
                add(dict(type="min_reactive_support_mvar", component=v["component"], limit=q, unit="Mvar", **base))
            elif t == "voltage_high":
                techs = [g["tech"] for g in (net.gens if net else []) if g["tech"] != "grid" and detail["gen_mw"].get(g["tech"], 0) > 1e-6]
                if techs:
                    tech = max(techs, key=lambda x: detail["gen_mw"][x])
                    rth = _thevenin_x(net, v["component"], real=True) if net is not None else None
                    dv = v["value"] - v["limit"] + 0.005
                    limit = max(detail["gen_mw"][tech] - dv * BASE_MVA / rth, 0.0) if rth else detail["gen_mw"][tech] * 0.8
                    if limit >= 0.05 * detail["gen_mw"][tech]:
                        add(dict(type="max_injection_mw", component=tech, limit=round(limit, 3), unit="MW", **base))
            elif t == "islanded":
                branch = case["detail"]["outages"][0] if case["detail"]["outages"] else None
                add(dict(type="redundancy", component=branch or v["component"], limit=v["value"], unit="MW to keep served", **base))
            elif t == "forming_overload":
                add(dict(type="min_forming_capacity_mw", component=v["component"], limit=round(v["value"], 3), unit="MW", **base))
            elif t == "non_convergence" and not case["emergency"]:
                add(dict(type="review_case", component=None, limit=None, unit="", **base))
    return cuts


# --------------------------------------------------------------------------- numeric suggestions mapped to scenario inputs

def _number(value):
    if isinstance(value, bool):
        return None
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    return out if math.isfinite(out) else None


def suggest_actions(report, net, values=None, verifier=None):
    """Concrete, editable corrections for every violation in a screening report (see pf_suggest).

    Each row: dict(id, scenario, case, violation, severity, component, label, unit, current, suggested, direction, reason,
                   applicable, recommended, alternative, verified, verification, predicted, cost_usd, target=dict(kind, key, id, also)).
    target.kind is 'field' (a GenStudio input such as microgrid_max_mw; shared by all scenarios), 'node' or 'line' (electrical
    data stored on the scenario's SLD component), or 'advice' (plain-language advisory with no input to change).
    With a verifier every electrical row was applied to the model and re-screened (verified True / "partial"); without one the
    rows are linear estimates (verified None).  The microgrid maximum is never lowered and the minimum never exceeds it."""
    import pf_suggest
    return pf_suggest.suggest(report, net, values, verifier)[0]
# Reference all-in unit costs at a typical size (BOQ summaries, legacy consumers); every price actually charged comes from the
# size- and voltage-dependent model in pf_costs (cost basis: pf_costs.cost_basis()).
UNIT_COSTS = pf_costs.reference_unit_costs()


def cost_overrides(settings=None, explicit=None):
    """Effective user cost overrides: diagram pf_settings 'cost_<name>' numbers, then an explicit dict (which wins)."""
    return {**pf_costs.overrides_from_settings(settings), **(explicit or {})}


def row_cost(row, overrides=None):
    """(cost_usd, basis) for one suggestion row from pf_costs; 0 for set-point changes and items the optimiser prices (microgrid limits)."""
    detail = pf_costs.row_cost_detail(row, overrides)
    if detail is not None:
        return detail["cost_usd"], detail["basis"]
    target = row.get("target") or {}
    kind, key = target.get("kind"), target.get("key")
    if kind == "node" and key == "shunt_mvar":
        return 0.0, "reduces an existing bank: no new equipment"
    if kind == "line" and key == "tap":
        return 0.0, "tap setting within the off-load range: no equipment cost"
    if kind == "line" and key in ("mva", "rating_mva"):
        return 0.0, "no upgrade needed"
    if kind == "node" and key in ("vset", "pf"):
        return 0.0, "controller set-point change: no equipment cost"
    if kind == "node" and key == "sc_mva":
        return 0.0, "grid reinforcement: needs a utility quote (not priced)"
    return 0.0, "no direct equipment cost (priced by the optimiser or needs a utility quote)"


def _zbus(net):
    """(indices, Z) of the energised network with the grid source buses eliminated, or (None, None)."""
    try:
        Y = _ybus(net, [b["on"] and net.buses[b["f"]]["on"] and net.buses[b["t"]]["on"] for b in net.branches])
        slacks = [g["src_idx"] for g in net.gens if g["tech"] == "grid" and g["on"]]
        slacks = slacks or [g["idx"] for g in net.gens if g["tech"] in ("bess",) | GENSETS and g["on"]][:1]
        reach = set()
        for s in slacks:
            reach |= _reach(_adjacency(net), s)
        keep = [i for i in range(len(net.buses)) if i not in slacks and net.buses[i]["on"] and i in reach]
        return keep, np.linalg.inv(Y[np.ix_(keep, keep)])
    except (np.linalg.LinAlgError, ValueError):
        return None, None


def _thevenin_x(net, bus_id, real=False):
    if net is None:
        return None
    try:
        n = len(net.buses)
        Y = _ybus(net, [b["on"] and net.buses[b["f"]]["on"] and net.buses[b["t"]]["on"] for b in net.branches])
        slacks = [g["src_idx"] for g in net.gens if g["tech"] == "grid" and g["on"]]
        slacks = slacks or [g["idx"] for g in net.gens if g["tech"] in ("bess",) | GENSETS and g["on"]][:1]
        reach = set()
        for s in slacks:
            reach |= _reach(_adjacency(net), s)
        keep = [i for i in range(n) if i not in slacks and net.buses[i]["on"] and i in reach]
        i = net.index[bus_id]
        if i not in keep:
            return None
        Z = np.linalg.inv(Y[np.ix_(keep, keep)])
        z = Z[keep.index(i), keep.index(i)]
        return float(abs(z.real if real else z.imag)) or None
    except (np.linalg.LinAlgError, KeyError, ValueError):
        return None


# --------------------------------------------------------------------------- time series

def series_run(folder, scenario_code, start=None, hours=48, stride=1, sample=None, assumptions=None, topology=None):
    """Compact hourly arrays for animation: up to 168 dispatch hours of a solved run."""
    ctx = _run_context(folder, scenario_code)
    data = _read_dispatch(ctx["path"])
    net = _prepare(ctx, scenario_code, assumptions, topology, data)
    total = len(data["timestamp"])
    hours = int(_num(hours, "Hours", 1, 168))
    stride = int(_num(stride, "Stride", 1, 8760))
    if sample == "year":
        indices = sorted({int(round(k * (total - 1) / max(hours - 1, 1))) for k in range(hours)})
    else:
        if isinstance(start, str) and start:
            matches = [k for k, t in enumerate(data["timestamp"]) if t.startswith(start)]
            if not matches:
                raise ValueError("Start time not found in the dispatch file (use e.g. 2027-03-24 11).")
            start = matches[0]
        if start is None:
            start = max(0, _hour_selection(data)[1] - 12)
        start = int(_num(start, "Start hour", 0, total - 1))
        indices = list(range(start, min(total, start + hours * stride), stride))
    return _series_out(net, data, indices, ctx)


def _series_out(net, data, indices, ctx=None):
    out = dict(timestamps=[], hour_index=indices, converged=[], vm=[], p_from=[], q_from=[], loading=[], load_mw=[],
               gen_mw=[], losses_mw=[], violations=[], status=[], bus_ids=[b["id"] for b in net.buses if b["kind"] != "source"],
               branch_ids=[b["id"] for b in net.branches if b["kind"] != "source"], total_hours=len(data["timestamp"]), warnings=net.warnings,
               gen_p_node={})
    for i in indices:
        case = _case_for_hour(net, data, i, "hour")
        violations = evaluate(net, case)
        out["timestamps"].append(case["timestamp"])
        out["converged"].append(case["converged"])
        out["vm"].append([b["vm"] for b in case["buses"]])
        out["p_from"].append([round(b["p_from_mw"], 3) for b in case["branches"]])
        out["q_from"].append([round(b["q_from_mvar"], 3) for b in case["branches"]])
        out["loading"].append([round(b["loading_pct"], 1) for b in case["branches"]])
        out["load_mw"].append(case["load_mw"])
        out["gen_mw"].append(case["gen_mw"])
        out["losses_mw"].append(case["losses_mw"])
        out["violations"].append(len(violations))
        out["status"].append("FAIL" if any(v["severity"] == "fail" for v in violations) else
                             "WARN" if violations else "PASS")
        out["gen_p_node"][case["timestamp"]] = {b["id"]: [b["gen_mw"], b["gen_mvar"], b["load_mw"], b["load_mvar"]]
                                                for b in case["buses"] if b["gen_mw"] or b["load_mw"] or b["gen_mvar"]}
    out["node_pq"] = [out["gen_p_node"][t] for t in out["timestamps"]]
    del out["gen_p_node"]
    return out


# --------------------------------------------------------------------------- manual operating point

def _manual_network(payload):
    operating = payload.get("operating") or {}
    caps = {}
    inj = dict(load_mw=_num(operating.get("load_mw", 0.0), "Load MW", 0, 1e6), gens={})
    for tech, row in (operating.get("gens") or {}).items():
        if tech not in TECH_GEN:
            raise ValueError(f"Unknown generator type '{tech}'.")
        p = _num(row.get("p_mw", 0.0), f"{tech} MW", -1e6, 1e6)
        inj["gens"][tech] = dict(p=p)
        caps[tech] = _num(row.get("cap_mw", abs(p)), f"{tech} capacity MW", 0, 1e6)
        if row.get("q_mvar") is not None:
            inj["gens"][tech]["q"] = _num(row["q_mvar"], f"{tech} Mvar", -1e6, 1e6)
    assumptions = dict(payload.get("assumptions") or {})
    nodes = dict(assumptions.get("nodes") or {})
    diagram = _diagram(payload.get("topology"), payload.get("scenario"))
    for node in diagram["nodes"]:
        row = (operating.get("gens") or {}).get(node["kind"])
        if row and row.get("q_mvar") is not None:
            nodes[node["id"]] = dict(nodes.get(node["id"], {}), control="q", q_mvar=row["q_mvar"])
    assumptions["nodes"] = nodes
    net = build_network(diagram, caps, assumptions, eligible=None, islanded=bool(operating.get("islanded")),
                        peak_load_mw=inj["load_mw"])
    return net, inj


def run_manual(payload):
    net, inj = _manual_network(payload)
    outages = payload.get("outages") or []
    known = {b["id"] for b in net.branches}
    if any(o not in known for o in outages):
        raise ValueError("Unknown branch in outage list.")
    case = solve_case(net, inj, outages=outages, label="Manual operating point")
    violations = evaluate(net, case, emergency=bool(outages))
    return dict(case=case, violations=violations, status=_status([dict(violations=violations)]), assumptions=describe(net), warnings=net.warnings)


# --------------------------------------------------------------------------- PSS/E RAW export

RAW_SECTIONS = ["BUS", "LOAD", "FIXED SHUNT", "GENERATOR", "BRANCH", "TRANSFORMER", "AREA", "TWO-TERMINAL DC", "VSC DC LINE",
                "IMPEDANCE CORRECTION", "MULTI-TERMINAL DC", "MULTI-SECTION LINE", "ZONE", "INTER-AREA TRANSFER", "OWNER",
                "FACTS DEVICE", "SWITCHED SHUNT", "GNE", "INDUCTION MACHINE"]


def raw_terminator(index):
    """Terminator line closing RAW_SECTIONS[index] (PSS/E v33 wording)."""
    nxt = f", BEGIN {RAW_SECTIONS[index + 1]} DATA" if index + 1 < len(RAW_SECTIONS) else ""
    return f"0 / END OF {RAW_SECTIONS[index]} DATA{nxt}"


def export_raw(net, inj=None, case=None, meta=None):
    """PSS/E v33 RAW text (see export_raw_notes for the dropped-equipment notes and `meta`)."""
    return export_raw_notes(net, inj, case, meta)[0]


def raw_consistency_problems(text):
    """Python check of the PSS/E topology rules on RAW text (no PSS/E needed).  Returns a list of problems:
    type 1/2 bus with no in-service branch, type 4 bus with in-service equipment/branches, equipment on a missing bus,
    type 1/2 bus with no in-service path to a swing (type 3) bus, swing with no in-service generator, type 2 with none."""
    lines = text.splitlines()
    pos, sections = 3, {}
    for k, section in enumerate(RAW_SECTIONS):
        rows = []
        while not lines[pos].startswith("0 /"):
            rows.append(lines[pos])
            pos += 1
        pos += 1
        sections[section] = rows

    def cells(row):
        body = row.split("/")[0]
        return [c.strip().strip("'") for c in next(csv.reader(io.StringIO(body), skipinitialspace=True, quotechar="'"))]

    bus = {int(c[0]): int(c[3]) for c in map(cells, sections["BUS"])}
    problems, graph, in_service_branch = [], {n: set() for n in bus}, {n: 0 for n in bus}
    gen_on = {n: 0 for n in bus}
    for c in map(cells, sections["LOAD"]):
        if int(c[0]) not in bus:
            problems.append(f"load on missing bus {c[0]}")
        elif bus[int(c[0])] == 4 and int(c[2]):
            problems.append(f"in-service load on type 4 bus {c[0]}")
    for c in map(cells, sections["FIXED SHUNT"]):
        if int(c[0]) not in bus:
            problems.append(f"shunt on missing bus {c[0]}")
        elif bus[int(c[0])] == 4 and int(c[2]):
            problems.append(f"in-service shunt on type 4 bus {c[0]}")
    for c in map(cells, sections["GENERATOR"]):
        n = int(c[0])
        if n not in bus:
            problems.append(f"generator on missing bus {n}")
            continue
        if int(c[14]):
            gen_on[n] += 1
            if bus[n] == 4:
                problems.append(f"in-service generator on type 4 bus {n}")
    branch_rows = [(int(c[0]), int(c[1]), int(c[13])) for c in map(cells, sections["BRANCH"])]
    records = sections["TRANSFORMER"]
    for k in range(0, len(records), 4):
        c = cells(records[k])
        branch_rows.append((int(c[0]), int(c[1]), int(c[11])))
    for a, b, status in branch_rows:
        if a not in bus or b not in bus:
            problems.append(f"branch {a}-{b} on missing bus")
        elif status:
            graph[a].add(b)
            graph[b].add(a)
            in_service_branch[a] += 1
            in_service_branch[b] += 1
            for end in (a, b):
                if bus[end] == 4:
                    problems.append(f"in-service branch {a}-{b} on type 4 bus {end}")
    swings = [n for n, t in bus.items() if t == 3]
    seen = set()
    stack = list(swings)
    while stack:
        n = stack.pop()
        if n not in seen:
            seen.add(n)
            stack.extend(graph[n])
    for n, t in bus.items():
        if t in (1, 2) and in_service_branch[n] == 0:
            problems.append(f"0 in-service branches connected to type {t} bus {n}")
        if t in (1, 2, 3) and n not in seen:
            problems.append(f"bus {n} (type {t}) has no in-service path to a swing bus")
        if t in (2, 3) and gen_on[n] == 0:
            problems.append(f"type {t} bus {n} has no in-service generator")
    if bus and not swings:
        problems.append("no swing bus")
    return problems


def export_raw_notes(net, inj=None, case=None, meta=None):
    """(RAW text, notes) for the network at the given operating point.

    With a converged operating point the bus voltages/angles, generator P/Q and loads are the solved values, so PSS/E should
    reproduce the GenStudio result.  The grid is a swing generator on an internal source bus behind its Thevenin branch.
    Equipment that is not energised is DROPPED from the file (a bus with no in-service path to a swing bus makes PSS/E stop with
    'bus type code and series element status inconsistencies'): orphan Load/other nodes, buses cut off by out-of-service
    branches, islands without a swing source or without any in-service branch, bus-to-itself wires, shunt-only buses, and
    generators built at 0 MW.  `notes` lists what was dropped.  `meta` (project, scenario, timestamp, generated) only fills the
    case-title records; the text is otherwise a pure function of the inputs."""
    inj = inj or dict(load_mw=0.0, gens={})
    notes = []
    if case is None:
        try:
            case = solve_case(net, inj, label="RAW export")
        except (ValueError, np.linalg.LinAlgError):
            case = None
    solved = case if case and case.get("converged") else None
    bus_res = {b["id"]: b for b in (solved["buses"] + solved["internal"])} if solved else {}
    gen_res = {(g["id"], g["tech"]): g for g in solved["gens"]} if solved else {}
    swing = set()
    for g in net.gens:
        key = (g["node"], g["tech"])
        if solved:
            if gen_res.get(key, {}).get("slack"):
                swing.add(g["src_idx"] if g["tech"] == "grid" else g["idx"])
        elif g["tech"] == "grid" and g["on"]:
            swing.add(g["src_idx"])
    if not swing and not solved:
        forming = [g for g in net.gens if g["tech"] in {"bess"} | GENSETS and g["on"] and (g["cap"] or 0) > 0]
        if forming:
            swing.add(forming[0]["idx"])
    if not swing:
        swing = {i for i, b in enumerate(net.buses) if b["on"] and any(
            g["on"] and (g["src_idx"] if g["tech"] == "grid" else g["idx"]) == i for g in net.gens)}
        swing = {min(swing)} if swing else set()
    if not swing:
        raise ValueError("No in-service source (grid or grid-forming generator) is available to act as the PSS/E swing bus.")
    skipped = {id(g) for g in net.gens if g["tech"] != "grid" and g["cap"] is not None and g["cap"] <= 0}
    for g in net.gens:
        if id(g) in skipped:
            notes.append(f"{net.buses[g['idx']]['display']}: unit built at 0 MW left out of the RAW file.")
    gen_list = [g for g in net.gens if id(g) not in skipped]
    graph = {i: [j for j in nbrs if j != i] for i, nbrs in _adjacency(net).items()}
    for s in sorted(swing):
        if not graph[s]:
            swing.discard(s)
            notes.append(f"{net.buses[s]['display']} is an isolated source with no in-service branch: dropped from the RAW file.")
    if not swing:
        raise ValueError("No in-service source is connected to the network through an in-service branch, so there is nothing to export.")
    live = set()
    for s in swing:
        live |= _reach(graph, s)
    def _idle_set(g):
        if g["tech"] == "grid" or g["control"] != "voltage" or g.get("inverter") or g["tech"] == "bess" or (g.get("q_min") is not None and g.get("q_max") is not None):
            return False
        row = gen_res.get((g["node"], g["tech"]))
        p = row["p_mw"] if row else max(inj["gens"].get(g["tech"], {}).get("p", 0.0), 0.0)
        return abs(p) < 1e-6

    gen_buses = {(g["src_idx"] if g["tech"] == "grid" else g["idx"]) for g in gen_list if g["on"] and not _idle_set(g)}
    order = [i for i in range(len(net.buses)) if i in live]
    for i, b in enumerate(net.buses):
        if i not in live and b["kind"] != "source":
            what = "has no in-service path to a swing source" if b["on"] else "is out of service"
            notes.append(f"{b['display']} {what}: dropped from the RAW file with its equipment.")
    for k, br in enumerate(net.branches):
        if br["on"] and br["f"] == br["t"]:
            notes.append(f"{br['name']} joins a bus to itself: dropped from the RAW file.")
        elif br["on"] and not (br["f"] in live and br["t"] in live):
            notes.append(f"{br['name']} is disconnected from the swing source: dropped from the RAW file.")

    def num(i):
        return net.buses[i]["num"]

    raw_names, used = [], set()
    for b in net.buses:
        base = re.sub(r"[^A-Z0-9_\-\.]", "_", str(b["name"]).upper().replace(" ", "_"))[:12] or "BUS"
        cand, n = base, 1
        while cand in used:
            n += 1
            cand = base[:12 - len(str(n)) - 1] + "_" + str(n)
        used.add(cand)
        raw_names.append(cand)

    def name(i):
        return raw_names[i]

    def area_zone(i):
        user = net.buses[i]["user"]
        return int(user.get("area", 1) or 1), int(user.get("zone", 1) or 1)

    sbase = net.base["base_mva"]
    zs, ys = sbase / BASE_MVA, BASE_MVA / sbase
    meta = meta or {}
    title = f"GenStudio {meta['project']} - {meta['scenario']}" if meta.get("project") and meta.get("scenario") else \
        f"GenStudio {meta.get('scenario') or meta.get('project') or 'power-flow'} export"
    detail = " | ".join([str(meta["timestamp"])] if meta.get("timestamp") else []) + \
        (f" | generated {meta['generated']}" if meta.get("generated") else "")
    lines = [f"0, {sbase:.2f}, 33, 0, 0, 60.00     / GenStudio positive-sequence power-flow export; MW, Mvar, kV, pu on {sbase:g} MVA",
             title[:60], (detail.strip(" |") or f"MW, Mvar, kV; pu on {sbase:g} MVA; verify all data before use")[:60]]
    low, high = net.limits["voltage"]
    elow, ehigh = net.limits["n1_voltage"]
    for i in order:
        b = net.buses[i]
        res = bus_res.get(b["id"])
        ide = 3 if i in swing else 2 if i in gen_buses else 1
        vm = res["vm"] if res and res["vm"] > 0 else 1.0
        va = res["va_deg"] if res and res["vm"] > 0 else 0.0
        area, zone = area_zone(i)
        lines.append(f"{num(i)}, '{name(i)}', {b['kv']:.4f}, {ide}, {area}, {zone}, 1, {vm:.5f}, {va:.4f}, {b['vlim'][1]:.4f}, {b['vlim'][0]:.4f}, "
                     f"{b['elim'][1]:.4f}, {b['elim'][0]:.4f}")
    lines.append(raw_terminator(0))
    weight = sum(l["weight"] for l in net.loads if l["on"] and l["fixed_mw"] is None) or 1.0
    for l in net.loads:
        if l["idx"] not in live:
            continue
        res = bus_res.get(net.buses[l["idx"]]["id"])
        if res and solved:
            p, q = res["load_mw"], res["load_mvar"]
        else:
            p = l["fixed_mw"] if l["fixed_mw"] is not None else inj["load_mw"] * l["weight"] / weight
            q = l["fixed_mvar"] if l["fixed_mvar"] is not None else p * math.tan(math.acos(l["pf"]))
        area, zone = area_zone(l["idx"])
        lines.append(f"{num(l['idx'])}, '1', {1 if l['on'] else 0}, {area}, {zone}, {p:.4f}, {q:.4f}, 0.0, 0.0, 0.0, 0.0, 1, 1, 0")
    lines.append(raw_terminator(1))
    for i in order:
        if net.buses[i]["shunt_mvar"]:
            lines.append(f"{num(i)}, '1', 1, 0.0, {net.buses[i]['shunt_mvar']:.4f}")
    lines.append(raw_terminator(2))
    for g in gen_list:
        idx = g["src_idx"] if g["tech"] == "grid" else g["idx"]
        if idx not in live:
            continue
        row = gen_res.get((g["node"], g["tech"]))
        if g["tech"] == "grid":
            p = row["src_p_mw"] if row else 0.0
            q = row["src_q_mvar"] if row else 0.0
            mbase = max(g["sc_mva"], 1.0)
            lines.append(f"{num(idx)}, '1', {p:.4f}, {q:.4f}, 9999.0, -9999.0, {g['vset']:.5f}, 0, {mbase:.1f}, 0.0, 1.0, 0.0, 0.0, 1.0, "
                         f"{1 if g['on'] else 0}, 100.0, 9999.0, -9999.0, 1, 1.0")
            continue
        sched = max(inj["gens"].get(g["tech"], {}).get("p", 0.0), -(g["cap"] or 0.0)) if g["tech"] == "bess" else \
            max(inj["gens"].get(g["tech"], {}).get("p", 0.0), 0.0)
        p = row["p_mw"] if row else sched
        pq = _gen_pq(g, p)
        qmin, qmax = _q_limits(g, p)
        q = row["q_mvar"] if row else pq[1]
        cap = g["cap"] if g["cap"] else max(abs(p), 1.0)
        mbase = float(g["mbase"]) if g.get("mbase") else max(cap / g["rated_pf"], 0.1)
        if (g.get("q_min") is None or g.get("q_max") is None) and not row:
            qmin, qmax = unitpf.q_limits(cap, g["rated_pf"], g["rated_pf_lead"])  # no solved case: plant capability at rated MW
        slack = idx in swing
        fixed_q = not slack and g["control"] != "voltage"
        if fixed_q:
            qmin = qmax = q
        # An idle synchronous genset is offline in the solved case: machine out of service, nameplate capability kept in the record.
        idle_set = not slack and g["control"] == "voltage" and not g.get("inverter") and g["tech"] != "bess" and abs(p) < 1e-6 and not (g.get("q_min") is not None and g.get("q_max") is not None)
        if idle_set:
            qmin, qmax = unitpf.q_limits(cap, g["rated_pf"], g["rated_pf_lead"])
            q = 0.0
        pt = float(g["pmax"]) if g.get("pmax") is not None else max(cap, p)
        pb = float(g["pmin"]) if g.get("pmin") is not None else (-cap if g["tech"] == "bess" else min(0.0, p))
        zx = float(g["xd2"]) if g.get("xd2") else 1.0
        vs = g["vset"] if g["control"] == "voltage" or slack else (bus_res.get(net.buses[idx]["id"]) or {}).get("vm", 1.0) or 1.0
        lines.append(f"{num(idx)}, '1', {p:.4f}, {q:.4f}, {qmax:.4f}, {qmin:.4f}, {vs:.5f}, 0, {mbase:.3f}, 0.0, {zx:.4f}, 0.0, 0.0, 1.0, "
                     f"{0 if idle_set else 1 if g['on'] else 0}, 100.0, {pt:.4f}, {pb:.4f}, 1, 1.0")
    lines.append(raw_terminator(3))
    circuits = {}

    def ckt(a, b):
        key = tuple(sorted((a, b)))
        circuits[key] = circuits.get(key, 0) + 1
        return circuits[key]

    for br in net.branches:
        if br["kind"] == "transformer" or br["f"] not in live or br["t"] not in live or br["f"] == br["t"]:
            continue
        rate = br["rating"] or 0.0
        lines.append(f"{num(br['f'])}, {num(br['t'])}, '{ckt(br['f'], br['t'])}', {br['r'] * zs:.7f}, {br['x'] * zs:.7f}, {br['b'] * ys:.7f}, "
                     f"{rate:.2f}, {rate:.2f}, {rate:.2f}, 0.0, 0.0, 0.0, 0.0, {1 if br['on'] else 0}, 1, {br['length_km']:.3f}, 1, 1.0")
    lines.append(raw_terminator(4))
    tr_names = set()
    for br in net.branches:
        if br["kind"] != "transformer" or br["f"] not in live or br["t"] not in live or br["f"] == br["t"]:
            continue
        hv, lv = (br["f"], br["t"]) if br["tap_side"] == "f" else (br["t"], br["f"])
        user = br["user"]
        ntp = int(user.get("tap_steps", 33)) or 33
        rma, rmi = float(user.get("tap_max", 1.1)), float(user.get("tap_min", 0.9))
        nomv1, nomv2 = net.buses[hv]["kv"], net.buses[lv]["kv"]
        tname = f"T{num(hv)}-{num(lv)}"[:12]
        cand, n = tname, 1
        while cand in tr_names:
            n += 1
            cand = tname[:12 - len(str(n)) - 1] + "_" + str(n)
        tr_names.add(cand)
        lines.append(f"{num(hv)}, {num(lv)}, 0, '{ckt(hv, lv)}', 1, 1, 1, 0.0, 0.0, 2, '{cand}', "
                     f"{1 if br['on'] else 0}, 1, 1.0")
        lines.append(f"{br['r'] * zs:.7f}, {br['x'] * zs:.7f}, {sbase:.2f}")
        lines.append(f"{br['tap']:.5f}, {nomv1:.4f}, 0.0, {br['mva']:.2f}, {br['mva']:.2f}, {br['mva']:.2f}, 0, 0, "
                     f"{rma:.4f}, {rmi:.4f}, 1.1, 0.9, {ntp}, 0, 0.0, 0.0, 0.0")
        lines.append(f"1.0, {nomv2:.4f}")
    lines.append(raw_terminator(5))
    areas = sorted({area_zone(i)[0] for i in order})
    zones = sorted({area_zone(i)[1] for i in order})
    for a in areas:
        in_area = [i for i in swing if area_zone(i)[0] == a]
        lines.append(f"{a}, {num(in_area[0]) if len(in_area) == 1 else 0}, 0.0, 10.0, 'GENSTUDIO{'' if a == 1 else '_' + str(a)}'")
    for k in range(6, len(RAW_SECTIONS)):
        if RAW_SECTIONS[k] == "ZONE":
            lines.extend(f"{z}, 'GENSTUDIO{'' if z == 1 else '_' + str(z)}'" for z in zones)
        elif RAW_SECTIONS[k] == "OWNER":
            lines.append("1, 'GENSTUDIO'")
        lines.append(raw_terminator(k))
    lines.append("Q")
    return "\r\n".join(lines) + "\r\n", notes


def _round4(obj):
    """Round every float in a JSON-like structure to at most 4 decimal places (UI contract)."""
    if isinstance(obj, float):
        return round(obj, 4) if math.isfinite(obj) else obj
    if isinstance(obj, dict):
        return {k: _round4(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_round4(v) for v in obj]
    return obj


_SETTING_KEYS = {"vmin_pu", "vmax_pu", "vmin_emerg_pu", "vmax_emerg_pu", "thermal_limit_pct", "high_loading_pct", "base_mva",
                 "grid_sc_mva", "grid_xr", "load_pf"} | pf_costs.SETTING_KEYS


def _topology_with(topology, scenario, settings=None, nodes=None, lines=None):
    """Copy of a saved topology with pf_settings merged and per-component `electrical` patches applied to one scenario."""
    topo = json.loads(json.dumps(topology or {}))
    diagram = (topo.get("diagrams") or {}).get(scenario) if topo.get("diagrams") else None
    if diagram is None:
        diagram = topo
    if settings:
        diagram["pf_settings"] = {**(diagram.get("pf_settings") or {}), **settings}
    for rows, key in ((nodes, "nodes"), (lines, "lines")):
        for ident, patch in (rows or {}).items():
            for item in diagram.get(key, []):
                if item.get("id") == ident:
                    item["electrical"] = {**(item.get("electrical") or {}), **patch}
    return topo


def screen_scenario(run_id, scenario, overrides=None):
    """Stable entry point for the workflow agent: screen one solved scenario of a saved run.

    overrides (all optional): dict(pf_settings={vmin_pu, vmax_pu, vmin_emerg_pu, vmax_emerg_pu, thermal_limit_pct,
    high_loading_pct, base_mva, grid_sc_mva, grid_xr, load_pf}, nodes={node_id: electrical-patch}, lines={line_id: electrical-patch},
    topology=full topology JSON replacing the saved one, n1=bool, costs={pf_costs parameter: value} user cost overrides for the suggestion prices).
    Returns dict(scenario, status 'PASS'|'WARN'|'FAIL'|'NOT_RUN', normal_status, n1_status, summary, violations[], suggestions[],
    cuts[], names{id: 'Label (bus number)'}, cost_basis); each suggestion carries cost_usd and cost_basis (a text).  Raises ValueError for bad input."""
    overrides = dict(overrides or {})
    unknown = set(overrides) - {"pf_settings", "nodes", "lines", "topology", "n1", "assumptions", "costs", "islanded"}
    if unknown:
        raise ValueError(f"Unknown override(s): {', '.join(sorted(unknown))}.")
    folder = extensions.run_folder(run_id)
    topology = overrides.get("topology")
    settings = {k: v for k, v in (overrides.get("pf_settings") or {}).items() if k in _SETTING_KEYS}
    if settings or overrides.get("nodes") or overrides.get("lines"):
        topology = _topology_with(topology or _run_context(folder, scenario)["topology"], scenario, settings,
                                  overrides.get("nodes"), overrides.get("lines"))
    report = screen_run(folder, scenario, overrides.get("assumptions"), topology, n1=overrides.get("n1", True) is not False,
                        islanded=bool(overrides.get("islanded")))
    merged = {**_stored_costs(folder, scenario, topology), **dict(overrides.get("costs") or {})}
    if merged:
        for row in report["suggestions"]:
            row["cost_usd"], row["cost_basis"] = row_cost(row, merged)
    return _round4(dict(
        scenario=scenario, status=report["status"], normal_status=report["normal_status"], n1_status=report["n1_status"],
        summary=report["summary"],
        violations=[dict(case=c["label"], **v) for c in report["cases"] for v in c["violations"]],
        suggestions=report["suggestions"], cuts=report["cuts"], warnings=report["warnings"], screened=report["screened"],
        failing_cases=report["failing_cases"], worst_case=report["worst_case"], verification=report.get("verification"),
        islanded=compact_islanded(report["islanded"]),
        cost_basis=pf_costs.cost_basis(merged),
        names=report["cases"][0]["detail"]["names"] if report["cases"] else {}))


def _stored_costs(folder, scenario, topology=None):
    """User cost overrides saved in the scenario drawing's pf_settings (keys 'cost_<name>'); {} when none or no drawing."""
    try:
        topo = topology or _run_context(folder, scenario)["topology"]
    except (ValueError, KeyError, OSError):
        return {}
    diagram = ((topo.get("diagrams") or {}).get(scenario) if isinstance(topo, dict) else None) or topo
    return cost_overrides(diagram.get("pf_settings") if isinstance(diagram, dict) else None)


STANDARD_STEP_MVAR = ((3.0, 0.3), (6.0, 0.6), (12.0, 1.2), (24.0, 2.4), (float("inf"), 5.0))


def _standard_step(q):
    """Standard switched-bank step size (Mvar) for a total of q Mvar: banks are built from 0.3/0.6/1.2/2.4/5 Mvar steps."""
    return next(step for limit, step in STANDARD_STEP_MVAR if q <= limit)


def size_shunt(run_id, scenario, target_pf=0.95, margin_pu=0.005, topology=None):
    """Quick shunt-capacitor sizing for one solved scenario (the technical check's 'compliance' step).

    Runs the PEAK-LOAD hour (the weakest-voltage case) on the stored drawing (or the default autodraw when none is stored),
    finds the smallest additional Mvar at the main MV bus that (a) lifts every bus to at least Vmin + margin_pu and (b) brings the
    grid power factor to target_pf, caps it so no bus exceeds Vmax at peak or at minimum load, and rounds UP to a whole
    number of standard steps (0.3/0.6/1.2/2.4/5 Mvar by size).
    Returns dict(scenario, bus_id, bus_name, existing_mvar, needed_mvar, shunt_mvar (additional, rounded), total_mvar, steps, step_mvar,
    vmin_before, vmin_after, vmax_after, grid_pf_before, grid_pf_after, cost_usd (capacitor $/kvar from UNIT_COSTS), suggestion
    (a row for compliance_cost), notes[]).  shunt_mvar == 0 means no capacitor is needed.  Nothing is written; add the bank with
    apply_shunt(run_id, scenario, total_mvar).  Cost: compliance_cost() prices the row, and the workflow adds it to the
    indicative-corrections NPC; it is an extra, not part of any technology cost."""
    folder = extensions.run_folder(run_id)
    ctx = _run_context(folder, scenario)
    data = _read_dispatch(ctx["path"])
    net = _prepare(ctx, scenario, None, topology, data)
    picks, peak = _hour_selection(data)
    low, high = net.limits["voltage"]
    bus = next((b for b in net.buses if b["kind"] == "bus" and b["on"]), None) or \
        next((b for b in net.buses if b["on"] and b["kind"] not in ("source", "grid")), None)
    if bus is None:
        raise ValueError("No bus is available for a shunt capacitor.")
    existing = bus["shunt_mvar"]
    min_hour = next((i for label, i in picks if label == "Minimum load"), peak)

    def probe(q):
        bus["shunt_mvar"] = existing + q
        out = {}
        for key, hour in (("peak", peak), ("min", min_hour)):
            case = _case_for_hour(net, data, hour, key)
            live = [b for b in case["buses"] if b["energized"]]
            out[key] = dict(ok=case["converged"], vmin=min((b["vm"] for b in live), default=0.0),
                            vmax=max((b["vm"] for b in live), default=0.0))
            if key == "peak":
                out[key]["gen_q"] = sum(g["q_mvar"] for g in case.get("gens", []) if g["tech"] != "grid")
                out[key]["gen_qmax"] = sum(g["q_max"] or 0.0 for g in case.get("gens", []) if g["tech"] != "grid")
                grid = next((b for b in case["buses"] if b["kind"] == "grid"), None)
                p, qq = (grid["gen_mw"], grid["gen_mvar"]) if grid else (0.0, 0.0)
                out[key]["pf"] = abs(p) / math.hypot(p, qq) if math.hypot(p, qq) > 1e-9 else 1.0
                out[key]["q_import"] = qq if p > 0 else 0.0
                out[key]["p"] = p
        return out

    def satisfied(r):
        pk = r["peak"]
        return pk["ok"] and pk["vmin"] >= low + margin_pu and (pk["p"] <= 0 or pk["pf"] >= target_pf)

    before = probe(0.0)
    notes, needed = [], 0.0
    if not before["peak"]["ok"]:
        notes.append("The peak-load case does not converge, so a shunt bank cannot be sized; fix the thermal/transfer limits first.")
    elif not satisfied(before):
        hi = max(5.0, 0.6 * _hour_inputs(data, peak)["load_mw"])
        top = probe(hi)
        if not satisfied(top):
            notes.append(f"Even {hi:.4g} Mvar does not meet the voltage/power-factor target; the limit is thermal or network strength.")
            needed = hi
        else:
            lo_q, hi_q = 0.0, hi
            for _ in range(24):
                mid = (lo_q + hi_q) / 2
                lo_q, hi_q = (lo_q, mid) if satisfied(probe(mid)) else (mid, hi_q)
            needed = hi_q
    step = _standard_step(needed) if needed > 0 else 0.0
    gq = before["peak"].get("gen_q", 0.0)
    if needed > 0:
        notes.append(f"Reason: at the peak-load hour the generators already supply {gq:.3g} Mvar of reactive support (capability "
                     f"{before['peak'].get('gen_qmax', 0.0):.3g} Mvar from their operating power factors, voltage-controlled); the bank covers only the "
                     f"remaining deficit ({needed:.3g} Mvar needed, rounded up to {step:g} Mvar standard steps).")
    elif before["peak"]["ok"]:
        notes.append(f"No shunt capacitor needed: the generators' own reactive capability ({before['peak'].get('gen_qmax', 0.0):.3g} Mvar at peak) "
                     "keeps voltage and grid power factor within target.")
    total = math.ceil(needed / step - 1e-9) * step if step else 0.0
    after = probe(total) if total else before
    while total > 0 and (after["peak"]["vmax"] > high or after["min"]["vmax"] > high) and total > step - 1e-9:
        total -= step
        after = probe(total)
        notes.append("Reduced one step so no bus exceeds Vmax at peak or minimum load.")
    bus["shunt_mvar"] = existing
    steps = int(round(total / step)) if step and total else 0
    if existing > 0 and max(after["peak"]["vmax"], after["min"]["vmax"]) > high:
        notes.append(f"The existing {existing:.4g} Mvar of shunt capacitors already pushes a bus above Vmax ({high:.4g} pu) "
                     "at peak or minimum load: reduce or switch them (a negative applied value removes capacitance).")
    total = total + 0.0 if total else 0.0
    row = dict(id=f"size_shunt:{bus['id']}", label=f"Shunt capacitor bank at {bus['display']}", target=dict(kind="node", key="shunt_mvar", id=bus["id"]),
               current=existing, suggested=round(existing + total, 4), unit="Mvar", cost_inputs=dict(kv=bus["kv"]))
    cost, basis = row_cost(row, _stored_costs(folder, scenario, topology)) if total else (0.0, "no shunt needed")
    notes.append("Cost is an extra compliance cost (not in any technology cost); it is shown in the 'NPC incl. indicative corrections' column (informational) until applied.")
    return _round4(dict(scenario=scenario, bus_id=bus["id"], bus_name=bus["display"], existing_mvar=existing, needed_mvar=needed,
                        shunt_mvar=total, total_mvar=existing + total, steps=steps, step_mvar=step,
                        vmin_before=before["peak"]["vmin"], vmin_after=after["peak"]["vmin"], vmax_after=max(after["peak"]["vmax"], after["min"]["vmax"]),
                        grid_pf_before=before["peak"].get("pf"), grid_pf_after=after["peak"].get("pf"),
                        cost_usd=cost, cost_basis=basis, suggestion=row, notes=notes + list(net.warnings)))


def apply_shunt(run_id, scenario, total_mvar, steps=None, step_mvar=None, replace_all=False):
    """Write a 'shunt' node (kind 'shunt', one wire to the main MV bus, electrical.shunt_mvar/shunt_steps/shunt_step_mvar) into the
    scenario's stored drawing (request.json topology.diagrams[scenario]); 0 removes it.  If the run has no drawing for the scenario
    the default autodraw is stored first.  replace_all=True (autoshunt) also removes every other capacitor (shunt nodes and bus
    shunt_mvar > 0) so banks never stack.  Returns the updated diagram."""
    folder = extensions.run_folder(run_id)
    path = folder / "request.json"
    request = json.loads(path.read_text(encoding="utf-8"))
    ctx = _run_context(folder, scenario)
    topo = request.setdefault("topology", {})
    diagrams = topo.setdefault("diagrams", {})
    diagram = diagrams.get(scenario)
    if not diagram or not diagram.get("nodes") or not diagram.get("lines"):
        diagram = network_topology.autodraw(sorted(_default_techs(ctx), key=lambda k: (k != "grid", k)), enabled=True)
    bus = next((n for n in diagram["nodes"] if n["kind"] == "bus"), None)
    if bus is None:
        raise ValueError("The drawing has no bus to attach a shunt to.")
    if replace_all:
        keep_id = next((n["id"] for n in diagram["nodes"] if n["kind"] == "shunt" and any(
            {e["source"], e["target"]} == {n["id"], bus["id"]} for e in diagram["lines"])
            and (n.get("electrical") or {}).get("shunt_mvar", 0.0) > 0), None)
        stripped = _strip_capacitors(diagram)
        if keep_id:
            # Keep the existing bank node (and its position) when it sits on the main bus; it is re-sized below.
            node = next(n for n in diagram["nodes"] if n["id"] == keep_id)
            wire = next(e for e in diagram["lines"] if keep_id in (e["source"], e["target"]))
            stripped["nodes"].append(node)
            stripped["lines"].append(wire)
        diagram = stripped
    shunts = [n for n in diagram["nodes"] if n["kind"] == "shunt" and any(
        {e["source"], e["target"]} == {n["id"], bus["id"]} for e in diagram["lines"])]
    total = float(total_mvar)
    if total == 0:
        drop = {n["id"] for n in shunts}
        diagram["nodes"] = [n for n in diagram["nodes"] if n["id"] not in drop]
        diagram["lines"] = [e for e in diagram["lines"] if e["source"] not in drop and e["target"] not in drop]
    else:
        if shunts:
            shunt = shunts[0]
        else:
            ids = {n["id"] for n in diagram["nodes"]}
            ident = "shunt_main"
            while ident in ids:
                ident += "_"
            shunt = dict(id=ident, kind="shunt", label="Shunt capacitor", rotation=0, scale=0.7, x=int(bus["x"]) + 200, y=int(bus["y"]) + 160,
                         owner="shared", capital_cost=0)
            diagram["nodes"].append(shunt)
            diagram["lines"].append(dict(id=f"l_{bus['id']}_{ident}", source=bus["id"], target=ident, source_port="right", target_port="top",
                                         owner="shared", length_km=0, cost_per_km=0, points=[dict(x=shunt["x"], y=int(bus["y"]))]))
        values = dict(shunt.get("electrical") or {}, shunt_mvar=total, shunt_auto=True)
        if steps and step_mvar:
            values.update(shunt_steps=int(steps), shunt_step_mvar=float(step_mvar))
        shunt["electrical"] = values
        shunt["label"] = "Shunt reactor (auto-sized)" if total < 0 else "Shunt capacitor (auto-sized)"
    diagrams[scenario] = diagram
    _write_json(path, request)
    return diagram


def _strip_capacitors(diagram):
    """Copy of a drawing with every capacitive shunt (shunt nodes and bus-level electrical.shunt_mvar > 0) removed; reactors stay."""
    diagram = json.loads(json.dumps(diagram))
    drop = {n["id"] for n in diagram["nodes"] if n["kind"] == "shunt" and (n.get("electrical") or {}).get("shunt_mvar", 0.0) > 0}
    diagram["nodes"] = [n for n in diagram["nodes"] if n["id"] not in drop]
    diagram["lines"] = [e for e in diagram["lines"] if e["source"] not in drop and e["target"] not in drop]
    for n in diagram["nodes"]:
        values = n.get("electrical")
        if values and values.get("shunt_mvar", 0.0) > 0:
            for key in ("shunt_mvar", "shunt_steps", "shunt_step_mvar"):
                values.pop(key, None)
            if not values:
                del n["electrical"]
    return diagram


def _write_json(path, data):
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(data), encoding="utf-8")
    os.replace(temp, path)


def _autoshunt_state(folder):
    try:
        return json.loads((folder / "autoshunt.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def autoshunt(run_id, scenario, apply=True):
    """Size the scenario's shunt capacitor bank and (apply=True) write it into the scenario's stored drawing.

    Signature: autoshunt(run_id, scenario, apply=True) -> dict(existing_mvar, needed_mvar, total_mvar, cost_usd, applied, ...).
    The bank is sized from scratch (all capacitors already in the drawing are ignored while sizing, so repeated calls never stack
    and an over-compensating stack such as 9.6 Mvar is replaced) at the peak-load hour: the smallest whole number of standard steps
    that lifts every bus to Vmin + margin and the grid power factor to 0.95 without any bus exceeding Vmax at peak/minimum load.
      existing_mvar  capacitors found in the drawing before the call (all are replaced when applied)
      needed_mvar    continuous requirement; total_mvar the standard-step bank that is written (0 = none needed; any stack removed)
      cost_usd       cost of the WHOLE bank total_mvar (idempotent, not an increment); applied is True when the drawing was written
    On apply the drawing gets one shunt node on the main MV bus (the SLD/topology/power-flow pages and export_raw show it),
    other capacitors are removed, and <run>\\autoshunt.json records the bank so compliance_cost() adds its cost exactly once.
    Nothing else in the drawing changes.  With no stored drawing the default autodraw is sized/stored (apply=True only);
    the note says so.  Raises ValueError when the scenario cannot be screened."""
    folder = extensions.run_folder(run_id)
    ctx = _run_context(folder, scenario)
    stored = (ctx["topology"].get("diagrams") or {}).get(scenario) if isinstance(ctx["topology"], dict) else None
    has_drawing = bool(stored and stored.get("nodes") and stored.get("lines"))
    data = _read_dispatch(ctx["path"])
    before = _prepare(ctx, scenario, None, None, data)
    existing = round(sum(b["shunt_mvar"] for b in before.buses if b["shunt_mvar"] > 0), 4)
    topology = None
    if has_drawing:
        topology = json.loads(json.dumps(ctx["topology"]))
        topology["diagrams"][scenario] = _strip_capacitors(stored)
    res = size_shunt(run_id, scenario, topology=topology)
    total = res["shunt_mvar"]
    row = dict(res["suggestion"], id=f"autoshunt:{res['bus_id']}", current=0.0, suggested=total)
    cost, basis = row_cost(row, _stored_costs(folder, scenario)) if total else (0.0, "no shunt needed")
    notes = [n for n in res["notes"] if not n.startswith("Cost is an extra")]
    if not has_drawing:
        notes.append("No single-line diagram is stored for this scenario: the default autodraw topology was sized"
                     + (" and is stored now with the shunt." if apply else "; nothing was stored (apply=False)."))
    notes.append(f"Existing capacitors in the drawing: {existing:g} Mvar (replaced by the sized bank when applied).")
    applied = False
    if apply:
        apply_shunt(run_id, scenario, total, res["steps"] or None, res["step_mvar"] or None, replace_all=True)
        state = _autoshunt_state(folder)
        if total:
            state[scenario] = dict(total_mvar=total, cost_usd=cost, cost_basis=basis, bus_id=res["bus_id"], steps=res["steps"], step_mvar=res["step_mvar"])
        else:
            state.pop(scenario, None)
        _write_json(folder / "autoshunt.json", state)
        applied = True
    return _round4(dict(scenario=scenario, bus_id=res["bus_id"], bus_name=res["bus_name"], existing_mvar=existing,
                        needed_mvar=res["needed_mvar"], total_mvar=total, steps=res["steps"], step_mvar=res["step_mvar"],
                        cost_usd=cost, cost_basis=basis, applied=applied, vmin_after=res["vmin_after"], vmax_after=res["vmax_after"],
                        grid_pf_after=res["grid_pf_after"], suggestion=row, notes=notes))


def compliance_cost(run_id, scenario, applied_suggestions, overrides=None):
    """Price the corrections a workflow applies.  applied_suggestions: list of suggestion ids (from screen_scenario) or of
    suggestion dicts; overrides: optional {pf_costs parameter: value} that wins over the costs saved in the drawing's pf_settings.
    Returns dict(total_usd, items=[dict(id, label, cost_usd, basis)], unit_costs=reference unit costs, cost_basis=pf_costs.cost_basis()).
    The shunt bank written by autoshunt() is always included, exactly once (the autoshunt suggestion row, if passed, is skipped;
    other shunt rows are increments on top of the bank, so nothing is counted twice)."""
    if not isinstance(applied_suggestions, (list, tuple)):
        raise ValueError("applied_suggestions must be a list of suggestion ids or suggestion rows.")
    folder = extensions.run_folder(run_id)
    merged = {**_stored_costs(folder, scenario), **dict(overrides or {})}
    known = None
    items = []
    bank = _autoshunt_state(folder).get(scenario)
    if bank and bank.get("total_mvar"):
        items.append(dict(id=f"autoshunt:{bank.get('bus_id')}", label=f"Shunt capacitor bank {bank['total_mvar']:g} Mvar (auto-sized)",
                          cost_usd=bank["cost_usd"], basis=bank.get("cost_basis") or f"{bank['total_mvar']:.4g} Mvar capacitor bank"))
    for entry in applied_suggestions:
        if str(entry.get("id") if isinstance(entry, dict) else entry).startswith("autoshunt:"):
            continue
        if isinstance(entry, dict) and "suggested" in entry and entry.get("target"):
            row = entry
        else:
            ident = entry.get("id") if isinstance(entry, dict) else entry
            if known is None:
                known = {s["id"]: s for s in screen_scenario(run_id, scenario)["suggestions"]}
            row = known.get(ident)
            if row is None:
                items.append(dict(id=ident, label=str(ident), cost_usd=0.0, basis="not among the current suggestions"))
                continue
        cost, basis = row_cost(row, merged)
        items.append(dict(id=row.get("id"), label=row.get("label"), cost_usd=cost, basis=basis))
    return _round4(dict(total_usd=round(sum(i["cost_usd"] for i in items), 2), items=items, unit_costs=pf_costs.reference_unit_costs(merged),
                        cost_basis=pf_costs.cost_basis(merged)))


# --------------------------------------------------------------------------- API handlers

def _run_folder(payload):
    return extensions.run_folder(payload.get("run_id"))


def _handle(payload):
    result = _dispatch(payload)
    return result if isinstance(result, dict) and "text" in result else _round4(result)


def _islanded_wanted(payload, ctx):
    """Explicit payload flag, else the run's saved 'technical_islanded' option."""
    if "islanded" in payload:
        return bool(payload["islanded"])
    return (ctx["request"] or {}).get("technical_islanded") is True


def _dispatch(payload):
    if not isinstance(payload, dict):
        raise ValueError("Send a JSON object.")
    action = payload.get("action", "solve")
    scenario = payload.get("scenario")
    if action == "defaults":
        return dict(defaults=defaults_table(), voltage_limits=DEFAULTS["voltage_limits_pu"]["value"])
    if action == "solve" and not payload.get("run_id"):
        return run_manual(payload)
    if action == "topology":
        ctx = _run_context(_run_folder(payload), scenario)
        data = _read_dispatch(ctx["path"])
        net = _prepare(ctx, scenario, payload.get("assumptions"), payload.get("topology"), data)
        return dict(topology=ctx["topology"], diagram=_diagram(payload.get("topology") or ctx["topology"], scenario, _default_techs(ctx)),
                    assumptions=describe(net))
    if action == "raw":
        if payload.get("run_id"):
            ctx = _run_context(_run_folder(payload), scenario)
            data = _read_dispatch(ctx["path"])
            net = _prepare(ctx, scenario, payload.get("assumptions"), payload.get("topology"), data)
            index = int(_num(payload.get("hour_index", _hour_selection(data)[1]), "Hour", 0, len(data["timestamp"]) - 1))
            inj = _hour_inputs(data, index)
            _assign_genset_total(net, data, inj, index)
        else:
            net, inj = _manual_network(payload)
        meta = dict(scenario=scenario or "manual", generated=datetime.now().strftime("%Y-%m-%d %H:%M"))
        if payload.get("run_id"):
            meta.update(project=Path(str(payload.get("run_id"))).name[:8], timestamp=str(data["timestamp"][index]))
        text, notes = export_raw_notes(net, inj, meta=meta)
        notes = list(dict.fromkeys(list(net.warnings) + notes))
        message = ("Exported. " + " ".join(notes)) if notes else "Exported."
        return dict(filename=f"genstudio_{scenario or 'manual'}.raw", text=text, notes=notes, message=message,
                    problems=raw_consistency_problems(text))
    folder = _run_folder(payload)
    if not scenario:
        raise ValueError("Select a solved scenario.")
    if action == "size_shunt":
        return size_shunt(payload.get("run_id"), scenario)
    if action == "autoshunt":
        return autoshunt(payload.get("run_id"), scenario, apply=payload.get("apply", True) is not False)
    if action == "apply_shunt":
        apply_shunt(payload.get("run_id"), scenario, _num(payload.get("total_mvar"), "Shunt Mvar", -1000, 1000),
                    payload.get("steps"), payload.get("step_mvar"))
        return dict(ok=True)
    if action == "screen":
        wanted = _islanded_wanted(payload, _run_context(folder, scenario))
        return screen_run(folder, scenario, payload.get("assumptions"), payload.get("topology"), n1=payload.get("n1", True) is not False,
                          islanded=wanted)
    if action in ("snapshot", "hours"):
        ctx = _run_context(folder, scenario)
        wanted = _islanded_wanted(payload, ctx)
        data = _read_dispatch(ctx["path"])
        picks, peak = _hour_selection(data)
        kinds = {"Peak load": "peak", "Minimum load": "min_load", "Maximum solar/wind output": "high_pv"}
        listing = [dict(label=l, index=i, timestamp=str(data["timestamp"][i]), kind=kinds.get(l, "other")) for l, i in picks]
        island_hours = []
        if wanted and not ctx["islanded"] and "grid" in _default_techs(ctx):
            load = _series(data, "net_served_load_mw") if "net_served_load_mw" in data else _series(data, "net_load_mw")
            for label, i in (("Islanded - grid disconnected: peak load", peak), ("Islanded - grid disconnected: minimum load", int(np.argmin(load)))):
                if not island_hours or i != peak:
                    island_hours.append(dict(label=label, index=i, timestamp=str(data["timestamp"][i]), kind="islanded", informational=True))
        if action == "hours":
            return dict(picks=listing + island_hours, island_note=ISLANDED_NOTE if island_hours else None,
                        islanded_assessed=wanted, hours=len(data["timestamp"]), peak_index=peak, start=str(data["timestamp"][0]),
                        end=str(data["timestamp"][-1]), peak_timestamp=str(data["timestamp"][peak]),
                        hourly=_hourly_regular(data["timestamp"]))
        net = _prepare(ctx, scenario, payload.get("assumptions"), payload.get("topology"), data)
        index = payload.get("hour_index")
        if index is None:
            index = next((i for l, i in picks if kinds.get(l) == payload.get("kind")), peak) if payload.get("kind") else peak
        index = int(_num(index, "Hour", 0, len(data["timestamp"]) - 1))
        outages = payload.get("outages") or []
        gens_out = payload.get("gens_out") or []
        island_case = payload.get("kind") == "islanded" and bool(island_hours)
        label = None
        if island_case:
            gens_out = ["grid"]
            pick = next((h for h in island_hours if h["index"] == payload.get("hour_index")), island_hours[0])
            index, label = pick["index"], pick["label"]
        label = label or next((l for l, i in picks if i == index), "User-selected hour")
        case = _case_for_hour(net, data, index, label, outages=outages, gens_out=gens_out)
        violations = evaluate(net, case, emergency=bool(outages or gens_out))
        status = _status([dict(violations=violations)])
        probe = dict(scenario=scenario, cases=[dict(label=label, detail=case, violations=violations, emergency=bool(outages or gens_out),
                                                    hour_index=index, outages=list(outages), gens_out=list(gens_out))])
        import pf_suggest
        verifier = pf_suggest.Verifier(ctx, scenario, data, payload.get("assumptions"), payload.get("topology"), probe)
        sld = _diagram(payload.get("topology") or ctx["topology"], scenario, _default_techs(ctx))
        keep = lambda row, keys: {k: row[k] for k in keys if k in row}
        sld = dict(nodes=[keep(n, ("id", "kind", "label", "x", "y", "rotation", "scale")) for n in sld["nodes"]],
                   lines=[keep(l, ("id", "source", "target", "source_port", "target_port", "points")) for l in sld["lines"]])
        return dict(case=case, violations=violations, status=status, picks=listing + island_hours, hours=len(data["timestamp"]),
                    hour_index=index, timestamp=case.get("timestamp"), assumptions=describe(net), warnings=net.warnings, diagram=sld,
                    informational=island_case, note=ISLANDED_NOTE if island_case else None,
                    suggestions=[] if island_case else suggest_actions(probe, net, (ctx["request"] or {}).get("values"), verifier))
    if action == "series":
        return series_run(folder, scenario, payload.get("start"), payload.get("hours", 48), payload.get("stride", 1),
                          payload.get("sample"), payload.get("assumptions"), payload.get("topology"))
    if action == "solve":
        ctx = _run_context(folder, scenario)
        data = _read_dispatch(ctx["path"])
        net = _prepare(ctx, scenario, payload.get("assumptions"), payload.get("topology"), data)
        index = payload.get("hour_index")
        index = _hour_selection(data)[1] if index is None else int(_num(index, "Hour", 0, len(data["timestamp"]) - 1))
        case = _case_for_hour(net, data, index, "Dispatch hour", outages=payload.get("outages") or [])
        violations = evaluate(net, case, emergency=bool(payload.get("outages")))
        return dict(case=case, violations=violations, assumptions=describe(net), status=_status([dict(violations=violations)]), warnings=net.warnings)
    raise ValueError("Unknown power-flow action.")


def _get(query):
    action = (query.get("action") or ["defaults"])[0]
    if action != "defaults":
        raise ValueError("Unknown power-flow query.")
    return _handle(dict(action="defaults"))


extensions.POST["powerflow"] = _handle
extensions.GET["powerflow"] = _get
