"""Explicit eligible technologies: no technology-specific forced investments."""

TECHNOLOGIES = [
    ("grid", "Grid"), ("pv", "Solar PV"), ("bess", "BESS"), ("wind", "Wind"),
    ("h2", "Hydrogen turbine"), ("h2_chp", "Hydrogen CHP"),
    ("ng", "Natural gas turbine"), ("ng_chp", "Natural gas CHP"),
    ("diesel", "Diesel generator"), ("biogas", "Biogas generator"), ("biomass", "Biomass generator"),
]
GENERATORS = {"wind", "h2", "h2_chp", "ng", "ng_chp", "diesel", "biogas", "biomass"}
DEFAULTS = [
    dict(id="R0", name="Grid with substation upgrade", technologies=["grid"], reference=True),
    dict(id="P1", name="Grid + PV + BESS", technologies=["grid", "pv", "bess"]),
    dict(id="H2", name="Grid + PV + BESS + Hydrogen", technologies=["grid", "pv", "bess", "h2"]),
    dict(id="NG", name="Grid + PV + BESS + Natural Gas", technologies=["grid", "pv", "bess", "ng"]),
    dict(id="CHP", name="Grid + PV + BESS + Natural Gas CHP", technologies=["grid", "pv", "bess", "ng_chp"]),
    dict(id="ALL", name="Grid + PV + BESS + Hydrogen + Hydrogen CHP + Natural Gas + Natural Gas CHP",
         technologies=["grid", "pv", "bess", "h2", "h2_chp", "ng", "ng_chp"]),
    dict(id="ISLAND", name="PV + BESS (no grid)", technologies=["pv", "bess"]),
]


def selected_generators(results):
    eligible = set()
    for result in results:
        if "eligible_technologies" in result:
            eligible.update(result["eligible_technologies"])
        else:
            names = result.get("tech", [])
            eligible.update([names] if isinstance(names, str) else names)
    return [(key, name) for key, name in TECHNOLOGIES
            if key in eligible and key in GENERATORS]


def validate(rows):
    if not isinstance(rows, list) or not rows:
        raise ValueError("Define at least one scenario.")
    allowed = {key for key, _ in TECHNOLOGIES}
    result, identifiers = [], set()
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("Each scenario must contain an ID, name and eligible technologies.")
        code = row.get("id", "")
        if not isinstance(code, str) or not code or len(code) > 32 or not all(
                c in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in code):
            raise ValueError("Scenario IDs must use 1-32 letters, numbers, hyphens or underscores.")
        if code in identifiers:
            raise ValueError("Scenario IDs must be unique.")
        identifiers.add(code)
        technologies = row.get("technologies", [])
        if not isinstance(technologies, list) or not technologies or any(t not in allowed for t in technologies):
            raise ValueError(f"{code}: select at least one eligible technology.")
        reference = row.get("reference", False)
        if type(reference) is not bool or (reference and set(technologies) != {"grid"}):
            raise ValueError("An upgraded-grid reference must contain only Grid.")
        if (code == "R0") != reference:
            raise ValueError("Use ID R0 only for the upgraded-grid reference.")
        entry = dict(id=code, name=str(row.get("name", code))[:200],
                     technologies=list(dict.fromkeys(technologies)), reference=reference)
        overrides = row.get("overrides")
        if overrides:
            if not isinstance(overrides, dict):
                raise ValueError(f"{code}: scenario overrides must be an object of input values.")
            entry["overrides"] = dict(overrides)  # field keys and bounds are checked by generation_app
        result.append(entry)
    return result


def settings(base, scenario):
    import network_topology
    cfg = dict(base)
    eligible = scenario["technologies"]
    cfg["connection_costs"] = network_topology.costs(base.get("topology", {}), eligible, scenario.get("id"))
    if "grid" not in eligible:
        cfg["grid_limit"] = 0
        cfg["islanded"] = True
    elif cfg.get("grid_limit", 1) <= 0 and not scenario.get("reference"):
        # A zero import limit cannot cover within-hour peaks from the grid; treat it as islanded.
        cfg["islanded"] = True
    if "pv" not in eligible:
        cfg["pv_min"] = cfg["pv_max"] = 0
    if "bess" not in eligible:
        cfg["bess_power_max"] = cfg["bess_energy_max"] = 0
    generators = [name for name in eligible if name in GENERATORS]
    return cfg, generators or ["none"]
