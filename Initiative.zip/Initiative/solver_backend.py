"""Optional Gurobi backend for the monthly dispatch LPs, with HiGHS as the default and fallback.

settings["solver"] = "highs" (default) | "gurobi".  resolve(settings) never raises: when Gurobi is requested but
gurobipy is missing, unlicensed or only has the size-limited (restricted) licence, HiGHS is used and the reason is
returned in `note`.  GurobiLP mimics the small subset of the highspy.Highs API used by
optimize_generation_mix.MonthlyDispatch, so the Benders cut duals (reduced costs of the fixed capacity columns,
col_dual) are the Gurobi RC attribute, which has the same sign convention for a minimisation.  Gurobi keeps its
basis between solves after bound changes, which replaces the HiGHS warm start.  The capacity master LP/MIP is small
and stays on HiGHS/scipy.

GET /api/x/solvers -> {available, gurobi: {installed, licensed, restricted, version, message}}
"""

import os
import threading
import types

import numpy as np

import extensions

RESTRICTED_LIMIT = 2000   # variables / linear constraints of the pip-bundled licence
_PROBE = {}
_LOCK = threading.Lock()


def _environment(gp):
    """Gurobi Env: WLS credentials from WLSACCESSID/WLSSECRET/LICENSEID when all are set, else the default licence lookup."""
    keys = ("WLSACCESSID", "WLSSECRET", "LICENSEID")
    if all(os.environ.get(k) for k in keys):
        env = gp.Env(empty=True)
        env.setParam("OutputFlag", 0)
        env.setParam("WLSACCESSID", os.environ["WLSACCESSID"])
        env.setParam("WLSSECRET", os.environ["WLSSECRET"])
        env.setParam("LICENSEID", int(os.environ["LICENSEID"]))
        env.start()
        return env
    env = gp.Env(empty=True)
    env.setParam("OutputFlag", 0)
    env.start()
    return env


def gurobi_status(refresh=False):
    """Detect gurobipy and whether a full-size licence is available (cached; probes a model larger than the restricted limit)."""
    with _LOCK:
        if _PROBE and not refresh:
            return dict(_PROBE)
        info = dict(installed=False, licensed=False, restricted=False, version=None, message="")
        try:
            import gurobipy as gp
            info["installed"] = True
            info["version"] = ".".join(str(v) for v in gp.gurobi.version())
        except ImportError:
            info["message"] = "gurobipy is not installed (pip install gurobipy). HiGHS will be used."
        except Exception as exc:
            info["message"] = f"gurobipy failed to import: {type(exc).__name__}: {exc}"
        if info["installed"]:
            try:
                env = _environment(gp)
                model = gp.Model(env=env)
                model.setParam("OutputFlag", 0)
                x = model.addMVar(RESTRICTED_LIMIT + 1, lb=0, ub=1)
                model.addConstr(x.sum() >= 1)
                model.setObjective(x.sum(), gp.GRB.MINIMIZE)
                model.optimize()
                info["licensed"] = model.Status == gp.GRB.OPTIMAL
                info["message"] = "Full-size Gurobi licence detected." if info["licensed"] else f"Gurobi probe status {model.Status}."
                model.dispose()
                env.dispose()
            except Exception as exc:
                text = str(exc)
                info["restricted"] = "too large" in text.lower() or "size-limited" in text.lower()
                info["message"] = ("Only the size-limited (restricted) Gurobi licence is available (2000 variables / 2000 "
                                   "constraints); this model is far larger. Install an academic, WLS or commercial licence. "
                                   if info["restricted"] else "Gurobi is installed but no usable licence was found. ") + f"({text})"
        _PROBE.clear()
        _PROBE.update(info)
        return dict(info)


def available():
    return ["highs"] + (["gurobi"] if gurobi_status().get("licensed") else [])


def resolve(settings):
    """(used, note) for settings["solver"]; falls back to HiGHS with an explanatory note."""
    requested = str((settings or {}).get("solver") or "highs").lower()
    if requested == "highs":
        return "highs", ""
    if requested != "gurobi":
        return "highs", f"Unknown solver '{requested}'; HiGHS was used."
    status = gurobi_status()
    if status["licensed"]:
        return "gurobi", f"Gurobi {status['version']} used for the monthly dispatch LPs; the capacity master remains HiGHS."
    return "highs", "Gurobi was requested but is unavailable; HiGHS was used instead. " + status["message"]


def solver_info(settings):
    requested = str((settings or {}).get("solver") or "highs").lower()
    used, note = resolve(settings)
    return dict(requested=requested, used=used, note=note)


class GurobiLP:
    """highspy.Highs-compatible subset backed by gurobipy."""

    def __init__(self, threads=4):
        import gurobipy as gp
        import highspy
        self.gp, self.hs = gp, highspy
        self.env = _environment(gp)
        self.m = gp.Model(env=self.env)
        self.m.setParam("OutputFlag", 0)
        self.m.setParam("Threads", threads)
        self.m.setParam("Method", 1)           # dual simplex: re-optimises from the previous basis
        self.m.setParam("FeasibilityTol", 1e-9)
        self.m.setParam("OptimalityTol", 1e-9)
        self.m.setParam("InfUnbdInfo", 1)
        self.x = None
        self.vars = []
        self.status = highspy.HighsModelStatus.kNotset
        self.solution = types.SimpleNamespace(col_value=[], col_dual=[])

    def setOptionValue(self, key, value):
        if key == "presolve":
            self.m.setParam("Presolve", 0 if value == "off" else -1)
        elif key == "solver":
            self.m.setParam("Method", {"simplex": 1, "ipm": 2, "choose": -1}.get(value, -1))
        elif key == "threads":
            self.m.setParam("Threads", int(value))

    def addCols(self, k, costs, lower, upper, *_):
        self.x = self.m.addMVar(k, lb=np.asarray(lower, float), ub=np.asarray(upper, float), obj=np.asarray(costs, float))
        self.m.update()
        self.vars = self.m.getVars()

    def addRows(self, n, lo, hi, nnz, indptr, indices, data):
        from scipy.sparse import csr_matrix
        A = csr_matrix((data, indices, indptr), shape=(n, len(self.vars)))
        lo, hi = np.asarray(lo, float), np.asarray(hi, float)
        gp = self.gp
        for mask, sense, rhs in ((lo == hi, gp.GRB.EQUAL, hi),
                                 (np.isfinite(hi) & (lo != hi), gp.GRB.LESS_EQUAL, hi),
                                 (np.isfinite(lo) & (lo != hi), gp.GRB.GREATER_EQUAL, lo)):
            rows = np.flatnonzero(mask)
            if len(rows):
                self.m.addMConstr(A[rows], self.x, sense, rhs[rows])
        self.m.update()

    def changeColsBounds(self, n, columns, lower, upper):
        for c, lo, hi in zip(columns, lower, upper):
            self.vars[int(c)].LB, self.vars[int(c)].UB = float(lo), float(hi)

    def changeColBounds(self, column, lower, upper):
        self.vars[int(column)].LB, self.vars[int(column)].UB = float(lower), float(upper)

    def changeColsCost(self, n, columns, costs):
        self.m.setAttr("Obj", [self.vars[int(c)] for c in columns], [float(v) for v in costs])

    def clearSolver(self):
        self.m.reset()

    def run(self):
        self.m.optimize()
        GRB, hs = self.gp.GRB, self.hs.HighsModelStatus
        if self.m.Status == GRB.OPTIMAL:
            self.status = hs.kOptimal
            self.solution = types.SimpleNamespace(col_value=np.array(self.x.X), col_dual=np.array(self.x.RC))
        elif self.m.Status in (GRB.INFEASIBLE, GRB.INF_OR_UNBD):
            self.status = hs.kInfeasible
        else:
            self.status = hs.kUnknown

    def getModelStatus(self):
        return self.status

    def modelStatusToString(self, status):
        return f"Gurobi status {self.m.Status} ({status})"

    def getSolution(self):
        return self.solution

    def getObjectiveValue(self):
        return float(self.m.ObjVal)

    def getInfo(self):
        return types.SimpleNamespace(simplex_iteration_count=int(self.m.IterCount),
                                     ipm_iteration_count=int(self.m.BarIterCount))


def make_lp(used, threads=4):
    """The LP object MonthlyDispatch drives: a highspy.Highs or a GurobiLP."""
    if used == "gurobi":
        return GurobiLP(threads)
    import highspy
    return highspy.Highs()


def _solvers(query):
    return dict(available=available(), gurobi=gurobi_status(bool(query.get("refresh"))),
                default="highs")


extensions.GET["solvers"] = _solvers
