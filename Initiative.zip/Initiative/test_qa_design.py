import json
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import unittest
import uuid
from pathlib import Path
from urllib.request import urlopen

import design

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / "Application Runs"
SOURCE = "7791be18470745f8af5ef34fa3d208f8"
HAS_SOURCE = (RUNS / SOURCE / "status.json").is_file()
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"


def copy_run():
    rid = uuid.uuid4().hex
    shutil.copytree(RUNS / SOURCE, RUNS / rid)
    return rid


@unittest.skipUnless(HAS_SOURCE, "reference run not available")
class DesignBackend(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rid = copy_run()
        cls.codes = [o["code"] for o in design.scenario_options(cls.rid)["options"]]

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(RUNS / cls.rid, ignore_errors=True)

    def test_options_flag_one_recommended(self):
        opts = design.scenario_options(self.rid)
        self.assertEqual(sum(o["recommended"] for o in opts["options"]), 1)
        self.assertIn(opts["recommended"], self.codes)

    def test_all_scenarios_json_safe_and_four_decimals(self):
        for code in self.codes:
            with self.subTest(code=code):
                d = design.build_design(self.rid, code)
                text = design.design_json(d)
                json.loads(text)
                self.assertEqual(re.findall(r"\d+\.\d{5,}", text), [])
                self.assertEqual(re.findall(r"\d+\.\d{5,}", design.equipment_csv(d)), [])

    def test_raw_and_sld_for_all_scenarios(self):
        for code in self.codes:
            with self.subTest(code=code):
                d = design.build_design(self.rid, code)
                raw = design.raw_text(d)
                self.assertIn("END OF BUS DATA", raw)
                nums = [int(l.split(",")[0]) for l in raw.splitlines()[3:] if re.match(r"^\d+, '", l)]
                self.assertTrue(nums)
                svg = design.sld_svg(d)
                self.assertTrue(svg.lstrip().startswith("<svg"))

    def test_bus_numbers_unique_and_named(self):
        for code in self.codes:
            d = design.build_design(self.rid, code)
            numbers = [b["number"] for b in d["buses"]]
            self.assertEqual(len(numbers), len(set(numbers)))
            self.assertTrue(all(len(b["name"]) <= 12 for b in d["buses"]))

    def test_sld_is_construction_grade(self):
        import xml.etree.ElementTree as ET
        for code in self.codes:
            for detail in design.DETAILS:
                with self.subTest(code=code, detail=detail):
                    d = design.build_design(self.rid, code, detail=detail)
                    svg = design.sld_svg(d)
                    ET.fromstring(svg)
                    self.assertNotIn("<style", svg)
                    self.assertNotIn("<script", svg)
                    for word in ("LEGEND", "NOTES", "DRAWN BY", "DRAWING NO.", "REV / DATE", "SCALE / SHEET"):
                        self.assertIn(word, svg)
                    self.assertIn(d["meta"]["drawing_no"], svg)
                    built = {str(b["number"]) for b in d["buses"]}
                    for num, name in d["sld_model"]["bus_names"].items():
                        if num not in built:
                            continue
                        self.assertIn(num, svg)
                        self.assertIn(name, svg)

    def test_raw_has_no_dead_expressions_and_zero_magnetising_loss(self):
        d = design.build_design(self.rid, self.codes[0])
        lines = design.raw_text(d).splitlines()
        trafo = [l for l in lines if re.match(r"^\d+, \d+, 0, '", l)]
        self.assertTrue(trafo)
        for l in trafo:
            self.assertEqual(l.split(",")[7].strip(), "0.0")

    def test_parallel_builds_are_consistent(self):
        results, errors = {}, []

        def work(i):
            try:
                results[i] = design.design_json(design.build_design(self.rid, self.codes[i % len(self.codes)]))
            except Exception as exc:  # noqa: BLE001
                errors.append(exc)
        threads = [threading.Thread(target=work, args=(i,)) for i in range(8)]
        [t.start() for t in threads]
        [t.join(120) for t in threads]
        self.assertEqual(errors, [])
        self.assertEqual(len(results), 8)

    def test_unknown_scenario_is_user_error(self):
        with self.assertRaises(ValueError):
            design.build_design(self.rid, "ZZ")

    def test_clean_handles_nan_and_numpy(self):
        import numpy as np
        out = design.clean({"a": float("nan"), "b": np.float64(1.234567891), "c": np.int64(3), "d": [float("inf")]})
        json.dumps(out, allow_nan=False)
        self.assertIsNone(out["a"])
        self.assertEqual(out["b"], 1.2346)


@unittest.skipUnless(HAS_SOURCE and Path(EDGE).is_file(), "reference run or Edge not available")
class DesignBrowser(unittest.TestCase):
    def test_switching_options_never_breaks_page(self):
        from playwright.sync_api import sync_playwright
        rid = copy_run()
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)], cwd=ROOT,
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try:
                    urlopen(base + "/api/defaults", timeout=.5).close()
                    break
                except OSError:
                    time.sleep(.1)
            with sync_playwright() as p:
                browser = p.chromium.launch(executable_path=EDGE, headless=True)
                page = browser.new_context(viewport={"width": 1600, "height": 1000}, accept_downloads=True).new_page()
                errors = []
                page.on("pageerror", lambda e: errors.append(str(e)))
                page.goto(base + "/")
                page.evaluate("r => localStorage.setItem('generation-run', r)", rid)
                page.reload()
                page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=120000)
                page.wait_for_timeout(2000)
                page.click("#tab-design")
                page.wait_for_selector(".dsg-head", timeout=60000)
                rec = page.evaluate("designPage.state.recommended")
                self.assertTrue(rec)
                self.assertEqual(page.input_value("#dsg-scenario"), rec)
                self.assertIn("Recommended", page.inner_text(".dsg-head"))
                self.assertTrue(page.locator("#dsg-back").is_hidden())
                codes = page.evaluate("[...document.querySelectorAll('#dsg-scenario option')].map(o => o.value)")
                for code in codes + [rec]:
                    page.select_option("#dsg-scenario", code)
                    page.wait_for_function("c => document.querySelector('.dsg-head')?.innerText.includes('(' + c + ')')", arg=code, timeout=60000)
                    self.assertEqual(page.locator(".dsg-head").count(), 1)
                    self.assertTrue(page.locator("#dsg-message").is_hidden())
                    self.assertEqual(page.locator("#dsg-back").is_visible(), code != rec)
                for code in (codes * 2)[:8]:
                    page.select_option("#dsg-scenario", code)
                    page.wait_for_timeout(60)
                last = codes[1]
                page.select_option("#dsg-scenario", last)
                page.wait_for_function("c => document.querySelector('.dsg-head')?.innerText.includes('(' + c + ')')", arg=last, timeout=60000)
                self.assertEqual(page.input_value("#dsg-scenario"), last)
                other = next(c for c in codes if c != rec)
                page.select_option("#dsg-scenario", other)
                page.wait_for_function("c => document.querySelector('.dsg-head')?.innerText.includes('(' + c + ')')", arg=other, timeout=60000)
                page.click("#dsg-back")
                page.wait_for_function("c => document.querySelector('.dsg-head')?.innerText.includes('(' + c + ')')", arg=rec, timeout=60000)
                self.assertEqual(page.input_value("#dsg-scenario"), rec)
                page.wait_for_selector("#dsg-sld-box svg", timeout=30000)
                for button in ("#dsg-raw", "#dsg-sld", "#dsg-json", "#dsg-csv"):
                    with page.expect_download(timeout=60000) as info:
                        page.click(button)
                    self.assertGreater(Path(info.value.path()).stat().st_size, 100)
                self.assertTrue(page.locator("#dsg-message").is_hidden())
                # A dropped connection shows an in-panel error with Retry, and a retry recovers.
                page.route("**/api/x/design?*", lambda route: route.abort())
                page.select_option("#dsg-scenario", other)
                page.wait_for_selector("#dsg-retry", timeout=30000)
                page.unroute("**/api/x/design?*")
                page.click("#dsg-retry")
                page.wait_for_function("c => document.querySelector('.dsg-head')?.innerText.includes('(' + c + ')')", arg=other, timeout=60000)
                self.assertEqual(errors, [])
                browser.close()
        finally:
            server.terminate()
            try:
                server.wait(10)
            except subprocess.TimeoutExpired:
                server.kill()
            shutil.rmtree(RUNS / rid, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
