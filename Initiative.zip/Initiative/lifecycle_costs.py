"""Linear present-value replacement costs and annual nominal cash expenditures."""


def replacements(capital, life, fraction, horizon, inflation, discount):
    events = {year: capital * fraction * (1 + inflation)**year
              for year in range(int(life), int(horizon), int(life))}
    return sum(value / (1 + discount)**year for year, value in events.items()), events


def coefficient(cost, life, cfg, horizon):
    if not cfg.get("include_replacements"):
        return cost
    pv, _ = replacements(cost, life, cfg["replacement_fraction"], horizon,
                         cfg["inflation"], cfg["discount"])
    return cost + pv


def _assets(caps, cfg):
    """(capital cost, life in years) for each purchased asset class; wind uses its own life."""
    return [
        (caps["pv_dc_mw"] * cfg["pv_capex"], cfg["pv_life"]),
        (caps["bess_mw"] * cfg["bess_power_capex"] +
         caps["bess_mwh"] * cfg["bess_energy_capex"], cfg["bess_life"]),
        *[(mw * cfg["technology_parameters"][key]["capex"], cfg.get("wind_life", 25) if key == "wind" else cfg["generator_life"])
          for key, mw in caps.get("generators_mw", {}).items()],
    ]


def residual_value(caps, cfg, horizon, upgrade_cost=0.0):
    """Straight-line value, in nominal end-of-horizon dollars, of the life remaining on every asset.

    The original build is valued at its capital cost; when replacements are included the last replacement
    (at the escalated, fractional replacement cost) is the asset that remains in service at the horizon."""
    total = 0.0
    for cost, life in _assets(caps, cfg) + [(upgrade_cost, cfg["grid_life"])]:
        if not cost or life <= 0:
            continue
        if cfg.get("include_replacements"):
            cycles = (int(horizon) - 1) // int(life) if int(life) > 0 else 0
            installed_year = cycles * int(life)
            basis = cost if cycles == 0 else cost * cfg["replacement_fraction"] * (1 + cfg["inflation"])**installed_year
        else:
            installed_year, basis = 0, cost
        total += basis * max(0.0, life - (horizon - installed_year)) / life
    return total


def schedule(caps, cfg, horizon, reference=False, upgrade_cost=None, upgrade_year=0):
    """Replacement events by year. The grid upgrade is charged only when its (required) cost is supplied."""
    events = {}
    if not cfg.get("include_replacements"):
        return events
    upgrade = (cfg["upgrade_cost"] if reference else 0) if upgrade_cost is None else upgrade_cost
    assets = _assets(caps, cfg)
    for cost, life in assets:
        _, rows = replacements(cost, life, cfg["replacement_fraction"], horizon,
                               cfg["inflation"], cfg["discount"])
        for year, value in rows.items():
            events[year] = events.get(year, 0) + value
    if upgrade:
        _, rows = replacements(upgrade, cfg["grid_life"], cfg["replacement_fraction"],
                               horizon - upgrade_year, cfg["inflation"], cfg["discount"])
        for year, value in rows.items():
            events[year + upgrade_year] = events.get(year + upgrade_year, 0) + (
                value * (1 + cfg["inflation"])**upgrade_year)
    return events
