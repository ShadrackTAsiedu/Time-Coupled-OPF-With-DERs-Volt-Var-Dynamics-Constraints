import csv
import json
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

import dispatch_view

HEADER = ["timestamp", "net_load_mw", "grid", "pv", "optimized_solar", "planned_renewable", "charge", "discharge",
          "soc", "shortfall", "gen"]


def make_run(folder, hours, results=None, end_year=2027):
    results = results or [dict(code="P1", name="P1", eligible_technologies=["grid"], caps={}, economics=dict(npc=2),
                               adequacy=dict(unserved_hours=0, stress_unserved_mwh=0))]
    (folder / "status.json").write_text(json.dumps(dict(state="complete", summary=dict(results=results), files=["dispatch_P1.csv"])))
    (folder / "run_configuration.json").write_text(json.dumps(dict(planning=dict(start_year=2027, end_year=end_year))))
    first = datetime(2027, 1, 1)
    for result in results:
        with (folder / f"dispatch_{result['code']}.csv").open("w", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(HEADER)
            for hour in range(hours):
                load = 1 + hour % 24
                writer.writerow([str(first + timedelta(hours=hour)), load, load, 0, 0, 0, 0, 0, 0, 0, 0])


class DispatchResolutionTests(unittest.TestCase):
    def test_daily_and_monthly_bins_follow_the_calendar_and_keep_energy(self):
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            make_run(folder, 24 * 40)
            end = "2027-02-09T23:00"
            daily = dispatch_view.read(folder, "P1", "2027-01-01T00:00", end, "day")
            self.assertEqual(daily["counts"], [24] * 40)
            self.assertEqual(daily["bin_hours"], 24)
            self.assertAlmostEqual(daily["series"]["demand"][0], 12.5)
            monthly = dispatch_view.read(folder, "P1", "2027-01-01T00:00", end, "month")
            self.assertEqual(monthly["counts"], [744, 216])
            self.assertEqual(monthly["timestamps"], ["2027-01-01T00:00", "2027-02-01T00:00"])
            energy = sum(power * hours for power, hours in zip(monthly["series"]["demand"], monthly["counts"]))
            self.assertAlmostEqual(energy, 40 * 300)

    def test_hourly_resolution_is_capped_and_unknown_resolution_rejected(self):
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            make_run(folder, 24)
            with self.assertRaisesRegex(ValueError, "Resolution"):
                dispatch_view.read(folder, "P1", resolution="week")
            hourly = dispatch_view.read(folder, "P1", "2027-01-01T00:00", "2027-01-01T23:00", "hour")
            self.assertEqual(hourly["counts"], [1] * 24)

    def test_long_hourly_request_is_downsampled_with_peaks_and_zoom_returns_true_hours(self):
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            hours = 24 * 365 * 4 + 24
            make_run(folder, hours, end_year=2030)
            full = dispatch_view.read(folder, "P1", "2027-01-01T00:00", "2030-12-31T23:00", "hour")
            self.assertEqual(full["hours"], hours)
            self.assertEqual(sum(full["counts"]), hours)
            self.assertLessEqual(len(full["timestamps"]), dispatch_view.MAX_POINTS)
            self.assertTrue(full["downsampled"])
            self.assertEqual(max(full["series"]["demand_high"]), 24)
            self.assertEqual(min(full["series"]["demand_low"]), 1)
            self.assertEqual(full["export_csv"], "dispatch_P1.csv")
            zoom = dispatch_view.read(folder, "P1", "2028-03-01T00:00", "2028-03-07T23:00", "hour")
            self.assertEqual(zoom["counts"], [1] * 168)
            self.assertFalse(zoom["downsampled"])

    def test_default_scenario_is_the_workflow_recommendation_not_the_numerically_cheapest(self):
        ties = [dict(code=code, name=code, eligible_technologies=["grid"], caps={}, economics=dict(npc=npc),
                     adequacy=dict(unserved_hours=0, stress_unserved_mwh=0)) for code, npc in (("H2", 100.0), ("P1", 100.0000001))]
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            make_run(folder, 24, ties)
            self.assertEqual(dispatch_view.recommended_code(folder, ties), "H2")
            (folder / "workflow.json").write_text(json.dumps(dict(recommended=dict(code="P1"))))
            view = dispatch_view.read(folder, "best", "2027-01-01T00:00", "2027-01-01T23:00")
            self.assertEqual(view["scenario"], "P1")
            self.assertTrue(view["best_fully_supplied"])

    def test_whole_system_stack_sums_to_the_built_load_and_envelope_keeps_the_peak(self):
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            make_run(folder, 24 * 3)
            with (folder / "dispatch_P1.csv").open(newline="") as stream:
                rows = list(csv.DictReader(stream))
            built = [10 + hour % 24 for hour in range(len(rows))]
            for row, load in zip(rows, built):
                row.update(gross_load_mw=load, net_load_mw=load - 3, planned_renewable=2.0, grid=load - 3, shortfall=0)
            with (folder / "dispatch_P1.csv").open("w", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
            (folder / "request.json").write_text(json.dumps(dict(planned_generation=[
                dict(name="Roof", technology="Solar", status="existing", start_year=2026, end_year=2026, capacity_mw=1, derate_factor=1, degradation=0),
                dict(name="Park", technology="Solar", status="planned", start_year=2027, end_year=2027, capacity_mw=3, derate_factor=1, degradation=0)])))
            view = dispatch_view.read(folder, "P1", "2027-01-01T00:00", "2027-01-03T23:00", "hour")
            self.assertLess(view["stack_balance_error_mw"], 1e-9)
            layers = [t["key"] for t in view["traces"] if t.get("area")]
            self.assertEqual(layers[:3], ["efficiency", "plant_0", "plant_1"])
            self.assertAlmostEqual(view["series"]["plant_0"][0], 0.5, 9)
            self.assertAlmostEqual(view["series"]["plant_1"][0], 1.5, 9)
            total = sum(view["series"][key][5] for key in layers)
            self.assertAlmostEqual(total, view["series"]["built"][5], 9)
            coarse = dispatch_view.read(folder, "P1", "2027-01-01T00:00", "2027-01-03T23:00", "day")
            self.assertEqual(max(coarse["series"]["built_high"]), max(built))
            self.assertEqual(min(coarse["series"]["built_low"]), min(built))


if __name__ == "__main__":
    unittest.main()
