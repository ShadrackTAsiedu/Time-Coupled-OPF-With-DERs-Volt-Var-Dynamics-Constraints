import re
import unittest
from pathlib import Path

import network_topology as nt
import power_flow as pf

HERE = Path(__file__).resolve().parent
RUN = "25253846a35d4d2583767b43da6bd098"


def diagram(nodes, lines, **extra):
    out = dict(enabled=False,
               nodes=[dict(id=i, kind=k, label=lbl, x=100 + 100 * n, y=100, owner=k, capital_cost=0, **ex)
                      for n, (i, k, lbl, ex) in enumerate(nodes)],
               lines=[dict(id=i, source=a, target=b, owner="shared", length_km=km, cost_per_km=0) for i, a, b, km in lines])
    out.update(extra)
    return out


def plant(**gen_over):
    nodes = [("g", "grid", "Grid", {}), ("b", "bus", "Main bus", {}), ("pv", "pv", "Solar PV", {}), ("ng", "ng", "Natural gas turbine", {}),
             ("bs", "bess", "BESS", {}), ("l", "load", "Plant load", {})]
    lines = [("w0", "g", "b", 1), ("w1", "b", "pv", 0.1), ("w2", "b", "ng", 0.1), ("w3", "b", "bs", 0.1), ("w4", "b", "l", 0.5)]
    return diagram(nodes, lines)


def net_for(diag, **kw):
    kv = {n["id"]: dict(kv=33.0 if n["kind"] == "grid" else 11.0) for n in diag["nodes"]}
    kv["g"].update(sc_mva=1e6, xr=10)
    assumptions = dict(nodes=kv)
    assumptions.update(kw.pop("assumptions", {}))
    return pf.build_network(diag, caps=dict(pv=4.0, ng=5.0, bess=3.0), assumptions=assumptions, peak_load_mw=6.0, **kw)


class ParameterStorageTests(unittest.TestCase):
    def test_pf_settings_sanitised(self):
        clean = nt.pf_settings(dict(vmin_pu=0.93, vmax_pu=1.06, junk=5, base_mva=True, grid_xr="x", thermal_limit_pct=float("nan")))
        self.assertEqual(clean, dict(vmin_pu=0.93, vmax_pu=1.06))

    def test_electrical_keys_whitelisted(self):
        row = dict(electrical=dict(bus_number=3100, bus_name="ng<script>", bus_type="pv", area=2, evil=1, vmax_pu=1.07, in_service=False))
        out = nt.electrical(row, nt.NODE_ELECTRICAL)["electrical"]
        self.assertEqual(out["bus_number"], 3100)
        self.assertNotIn("evil", out)
        self.assertNotIn("<", out["bus_name"])
        self.assertIs(out["in_service"], False)

    def test_validate_diagram_keeps_pf_settings(self):
        raw = dict(enabled=True, nodes=[], lines=[], pf_settings=dict(vmin_pu=0.94, bogus=1))
        out = nt.validate_diagram(raw, [])
        self.assertEqual(out.get("pf_settings"), dict(vmin_pu=0.94))


class NumberingTests(unittest.TestCase):
    def test_convention_blocks_and_names(self):
        net = net_for(plant())
        by_label = {b["label"]: b for b in net.buses if b["kind"] != "source"}
        self.assertTrue(1000 < by_label["Grid"]["num"] < 2000)
        self.assertTrue(2000 < by_label["Main bus"]["num"] < 3000)
        self.assertTrue(3000 < by_label["Solar PV"]["num"] < 4000)
        self.assertTrue(3000 < by_label["Natural gas turbine"]["num"] < 4000)
        self.assertTrue(4000 < by_label["Plant load"]["num"] < 5000)
        self.assertTrue(5000 < by_label["BESS"]["num"] < 6000)
        nums = [b["num"] for b in net.buses]
        self.assertEqual(len(nums), len(set(nums)))
        for b in net.buses:
            self.assertLessEqual(len(b["name"]), 12)
            self.assertNotRegex(b["name"], r"\s")
        self.assertTrue(by_label["Grid"]["name"].startswith("GRID_"))
        self.assertEqual(by_label["Solar PV"]["display"], f"Solar PV ({by_label['Solar PV']['num']})")

    def test_user_number_and_name_win_and_duplicates_fall_back(self):
        diag = plant()
        for n in diag["nodes"]:
            if n["id"] == "pv":
                n["electrical"] = dict(bus_number=3555, bus_name="PV_FARM_A")
            if n["id"] == "ng":
                n["electrical"] = dict(bus_number=3555)
        net = net_for(diag, assumptions=dict())
        by_id = {b["id"]: b for b in net.buses}
        self.assertEqual(by_id["pv"]["num"], 3555)
        self.assertEqual(by_id["pv"]["name"], "PV_FARM_A")
        self.assertNotEqual(by_id["ng"]["num"], 3555)
        self.assertEqual(len({b["num"] for b in net.buses}), len(net.buses))

    def test_no_internal_ids_in_display(self):
        net = net_for(plant())
        d = pf.describe(net)
        for n in d["nodes"]:
            self.assertNotEqual(n["display"], n["id"])


class SettingsTests(unittest.TestCase):
    def test_defaults_are_assumed(self):
        net = net_for(plant())
        self.assertEqual(net.limits["voltage"], [0.95, 1.05])
        self.assertEqual(net.limits["n1_voltage"], [0.90, 1.10])
        self.assertTrue(all(v == "assumed" for v in net.tags.values()))

    def test_user_settings_override_and_tag(self):
        diag = plant()
        diag["pf_settings"] = dict(vmin_pu=0.93, vmax_emerg_pu=1.12, thermal_limit_pct=90, base_mva=50)
        net = net_for(diag)
        self.assertEqual(net.limits["voltage"][0], 0.93)
        self.assertEqual(net.limits["n1_voltage"][1], 1.12)
        self.assertEqual(net.limits["thermal"], 90)
        self.assertEqual(net.tags["vmin_pu"], "user-set")
        self.assertEqual(net.tags["vmax_pu"], "assumed")
        base = pf.describe(net)["base"]
        self.assertEqual(base["base_mva"], 50)

    def test_bus_limit_override(self):
        diag = plant()
        for n in diag["nodes"]:
            if n["id"] == "l":
                n["electrical"] = dict(vmin_pu=0.80)
        net = net_for(diag)
        row = next(b for b in pf.describe(net)["nodes"] if b["id"] == "l")
        self.assertEqual(row["vmin_pu"], 0.80)

    def test_fixed_load_honoured(self):
        diag = plant()
        for n in diag["nodes"]:
            if n["id"] == "l":
                n["electrical"] = dict(load_mw=2.0, load_mvar=0.5)
        net = net_for(diag)
        case = pf.solve_case(net, dict(load_mw=6.0, gens={}))
        load = next(b for b in case["buses"] if b["id"] == "l")
        self.assertAlmostEqual(load["load_mw"], 2.0, places=3)
        self.assertAlmostEqual(load["load_mvar"], 0.5, places=3)

    def test_raw_uses_numbers_names_and_sbase(self):
        diag = plant()
        diag["pf_settings"] = dict(base_mva=50)
        net = net_for(diag)
        raw = pf.export_raw(net, dict(load_mw=3.0, gens=dict(pv=dict(p=2.0))))
        lines = raw.replace("\r\n", "\n").split("\n")
        self.assertIn("50", lines[0].split(",")[1])
        text = "\n".join(lines)
        for b in net.buses:
            self.assertRegex(text, rf"\n\s*{b['num']}\s*,\s*'{re.escape(b['name'])}\s*'")


class RoundingTests(unittest.TestCase):
    def test_round4(self):
        out = pf._round4(dict(a=0.683273914104297, b=[1.23456789, dict(c=2)], d="x"))
        self.assertEqual(out, dict(a=0.6833, b=[1.2346, dict(c=2)], d="x"))


class ScreeningApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not (HERE / "Application Runs" / RUN).is_dir():
            raise unittest.SkipTest("reference run not available")
        cls.code = pf._saved_codes(RUN)[0] if hasattr(pf, "_saved_codes") else None

    def screen(self, **kw):
        code = self.code or "NG"
        return pf.screen_scenario(RUN, code, **kw)

    def test_screen_scenario_contract(self):
        try:
            out = self.screen()
        except Exception as error:  # scenario code differs on this machine
            self.skipTest(str(error))
        for key in ("scenario", "status", "violations", "suggestions"):
            self.assertIn(key, out)
        for s in out["suggestions"]:
            self.assertIn("cost_usd", s)
        banks = [s for s in out["suggestions"] if s.get("target", {}).get("key") == "shunt_mvar"]
        self.assertLessEqual(len(banks), 1, "reactive support is consolidated into one bank")
        self.assertNotRegex(repr(out), r"\d\.\d{5,}")

    def test_compliance_cost(self):
        rows = [dict(id="a", label="Capacitor bank", unit="Mvar", target=dict(kind="node", key="shunt_mvar", id="x"), suggested=2.0,
                     current=0.0)]
        try:
            out = pf.compliance_cost(RUN, self.code or "NG", rows)
        except Exception as error:
            self.skipTest(str(error))
        self.assertEqual(set(out) & {"total_usd", "items"}, {"total_usd", "items"})
        self.assertAlmostEqual(out["total_usd"], sum(i["cost_usd"] for i in out["items"]), places=2)

    def test_unit_costs(self):
        self.assertTrue(10 <= pf.UNIT_COSTS["capacitor_usd_per_kvar"] <= 30)
        self.assertTrue(10000 <= pf.UNIT_COSTS["transformer_usd_per_mva"] <= 40000)


if __name__ == "__main__":
    unittest.main()
