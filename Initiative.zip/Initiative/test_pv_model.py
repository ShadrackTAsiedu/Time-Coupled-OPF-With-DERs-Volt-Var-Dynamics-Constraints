import csv
import io
from pathlib import Path
import unittest

import numpy as np

import demand_forecasting as forecasting
import generation_app as app
import pv_model
import resource_profiles

LA_CSV = Path(__file__).resolve().parent / "Solar Profile Inputs" / "los_angeles_solar_hourly_2025_2026.csv"
DATES = forecasting.planning_dates(2027, 1)


def la_file(columns=None):
    text = LA_CSV.read_text(encoding="utf-8-sig")
    if columns is None:
        return dict(name="la.csv", content=text)
    rows = list(csv.DictReader(io.StringIO(text)))
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["timestamp", *columns])
    for row in rows:
        writer.writerow([row["timestamp"], *(row[c] for c in columns)])
    return dict(name="subset.csv", content=output.getvalue())


class ConversionMaths(unittest.TestCase):
    def test_stc_and_noct_reference_points(self):
        stc = pv_model.unit_dc(np.array([1000.0]), np.array([25.0 - 1000 / 31.84]), np.array([1.0]), {})
        self.assertAlmostEqual(float(stc[0]), 1.0, places=6)
        hot = pv_model.unit_dc(np.array([800.0]), np.array([20.0]), None, dict(pv_temp_model="noct", pv_noct=45))
        self.assertAlmostEqual(float(hot[0]), 0.8 * (1 - 0.0035 * 20), places=6)
        self.assertAlmostEqual(float(pv_model.unit_dc(np.array([500.0]))[0]), 0.5, places=6)

    def test_losses_degradation_and_inverter_clip(self):
        dc = np.array([0.5, 1.0, 1.1])
        ac = pv_model.unit_ac(dc, 0.85, 0.99, 1.3)
        np.testing.assert_allclose(ac, [0.5 * .85 * .99 * 1.3, 1.0, 1.0][:1] + [min(.85 * .99 * 1.3, 1), 1.0])
        self.assertTrue(np.all(pv_model.unit_ac(dc, 1.0, 1.0, 1.0) <= 1.0))

    def test_invalid_parameters_are_rejected(self):
        with self.assertRaises(ValueError):
            pv_model.parameters(dict(pv_temp_model="x"))
        with self.assertRaises(ValueError):
            pv_model.parameters(dict(pv_dc_ac_ratio=0))


class LosAngelesBenchmark(unittest.TestCase):
    def summary(self, columns=None, **values):
        resource, audit, converted = resource_profiles.read_solar(la_file(columns), DATES, values)
        self.assertTrue(converted)
        return pv_model.summary(DATES, resource, values.get("solar_derate", .85), values.get("pv_dc_ac_ratio", 1.0)), audit

    def test_bundled_file_is_irradiance_with_weather(self):
        header = LA_CSV.read_text(encoding="utf-8-sig").splitlines()[0].split(",")
        for column in ("poa_irradiance_w_m2", "ghi_w_m2", "temperature_c", "wind_speed_ms"):
            self.assertIn(column, header)
        self.assertNotIn("solar_per_mw", header)

    def test_yield_and_capacity_factor_match_los_angeles_benchmark(self):
        result, audit = self.summary()
        self.assertTrue(audit["temperature_used"] and audit["wind_used"])
        self.assertTrue(1850 <= result["annual_yield_kwh_per_kwdc"] <= 2250, result)
        self.assertTrue(.20 <= result["annual_capacity_factor_ac"] <= .26, result)
        gross, _ = self.summary(solar_derate=1.0)
        self.assertTrue(2100 <= gross["annual_yield_kwh_per_kwdc"] <= 2300, gross)
        self.assertTrue(all(.12 <= cf <= .35 for cf in result["monthly_capacity_factor"]), result)
        self.assertIn(int(np.argmax(result["diurnal_capacity_factor"])), (11, 12, 13))

    def test_temperature_lowers_output_and_models_agree(self):
        with_temp, _ = self.summary(solar_derate=1.0)
        without, audit = self.summary(["poa_irradiance_w_m2"], solar_derate=1.0)
        self.assertFalse(audit["temperature_used"])
        self.assertLess(with_temp["annual_yield_kwh_per_kwdc"], without["annual_yield_kwh_per_kwdc"] * 0.97)
        noct, _ = self.summary(solar_derate=1.0, pv_temp_model="noct")
        self.assertAlmostEqual(noct["annual_yield_kwh_per_kwdc"], with_temp["annual_yield_kwh_per_kwdc"], delta=75)

    def test_dc_ac_ratio_clips_and_raises_ac_capacity_factor(self):
        base, _ = self.summary()
        loaded, _ = self.summary(pv_dc_ac_ratio=1.3)
        self.assertGreater(loaded["annual_capacity_factor_ac"], base["annual_capacity_factor_ac"] * 1.25)
        self.assertGreater(loaded["clipped_energy_fraction"], 0)
        self.assertLessEqual(max(loaded["diurnal_capacity_factor"]), 1.0)

    def test_ghi_upload_is_transposed_to_the_same_yield(self):
        poa, _ = self.summary(solar_derate=1.0)
        full, audit = self.summary(["ghi_w_m2", "dni_w_m2", "dhi_w_m2", "temperature_c"], solar_derate=1.0)
        self.assertIn("transposed", audit["basis"])
        self.assertAlmostEqual(full["annual_yield_kwh_per_kwdc"], poa["annual_yield_kwh_per_kwdc"], delta=0.03 * poa["annual_yield_kwh_per_kwdc"])
        split, _ = self.summary(["ghi_w_m2", "temperature_c"], solar_derate=1.0)
        self.assertAlmostEqual(split["annual_yield_kwh_per_kwdc"], poa["annual_yield_kwh_per_kwdc"], delta=0.08 * poa["annual_yield_kwh_per_kwdc"])


class UnitProfileAlternative(unittest.TestCase):
    def test_unit_profile_is_used_as_uploaded(self):
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["timestamp", "solar_per_mw"])
        for date in DATES:
            writer.writerow([date.isoformat(sep=" "), .5 if 8 <= date.hour <= 16 else 0])
        resource, audit, converted = resource_profiles.read_solar(dict(name="u.csv", content=output.getvalue()), DATES, {})
        self.assertFalse(converted)
        self.assertEqual(audit["basis"], "uploaded unit PV profile")
        self.assertEqual(resource.max(), .5)


class ModelIntegration(unittest.TestCase):
    def request(self, **values):
        request = app.validate_request({"values": dict(solar_profile_enabled=True, horizon_years=1, **values),
                                        "scenarios": ["R0", "P1"], "solar_file": la_file()})
        return request

    def test_optimizer_solar_is_computed_from_irradiance_with_all_parameters(self):
        data, _ = app.make_data(self.request(pv_dc_ac_ratio=1.3, solar_derate=.9))
        self.assertEqual(data["pv_dc_ac_ratio"], 1.3)
        self.assertLessEqual(data["solar"].max(), 1.0)
        audit = data["forecast_audit"]["resources"]["solar"]
        self.assertTrue(audit["pv_summary"]["annual_capacity_factor_ac"] > .25)
        self.assertEqual(audit["column"], "poa_irradiance_w_m2")

    def test_legacy_request_without_pv_fields_still_solves_inputs(self):
        request = app.validate_request({"values": dict(solar_profile_enabled=True, horizon_years=1), "scenarios": ["R0"],
                                        "solar_file": la_file()})
        for key in ("pv_dc_ac_ratio", "pv_temp_coefficient", "pv_tilt"):
            self.assertIn(key, request["values"])
        data, _ = app.make_data(request)
        self.assertEqual(len(data["solar"]), 8760)

    def test_preview_endpoint_logic_reports_curves(self):
        out = app.pv_preview(dict(solar_file=la_file(), values=dict(pv_dc_ac_ratio=1.2)))
        self.assertEqual(len(out["monthly_capacity_factor"]), 12)
        self.assertEqual(len(out["diurnal_capacity_factor"]), 24)
        with self.assertRaises(ValueError):
            app.pv_preview({})


if __name__ == "__main__":
    unittest.main()
