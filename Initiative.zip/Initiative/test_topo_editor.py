"""Topology (SLD) editor: PSS/E naming, shunts, autodraw (Python) and the browser editor (marquee, zoom, autodraw, shunt)."""

import re
import shutil
import socket
import subprocess
import sys
import time
import unittest
import uuid
from pathlib import Path
from urllib.request import urlopen

import network_topology as nt

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / "Application Runs"
SOURCE = "7791be18470745f8af5ef34fa3d208f8"
HAS_SOURCE = (RUNS / SOURCE / "status.json").is_file()
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"


def node(ident, kind, **electrical):
    row = dict(id=ident, kind=kind, label=kind, x=100, y=100, owner="shared")
    if electrical:
        row["electrical"] = electrical
    return row


def diagram(nodes, lines=()):
    return dict(enabled=False, nodes=nodes, lines=[dict(id=f"w{i}", source=a, target=b, owner="shared") for i, (a, b) in enumerate(lines)])


class NamingTests(unittest.TestCase):
    def test_bus_name_sanitised(self):
        self.assertEqual(nt.sanitize_bus_name("it's a 'very' long bus name"), "ITS A VERY L")
        self.assertEqual(nt.sanitize_bus_name('a"b,c<d>'), "ABCD")
        self.assertEqual(nt.sanitize_bus_name(5), "")
        self.assertLessEqual(len(nt.sanitize_bus_name("x" * 50)), 12)

    def test_bus_number_range(self):
        for bad in (0, -3, 999998, 1.5, True, "7", float("nan")):
            self.assertIsNone(nt.valid_bus_number(bad), bad)
        self.assertEqual(nt.valid_bus_number(999997), 999997)
        self.assertEqual(nt.valid_bus_number(12.0), 12)

    def test_unique_name_stays_within_twelve(self):
        self.assertEqual(nt.unique_bus_name("MV_BUS", ["MV_BUS"]), "MV_BUS_2")
        name = nt.unique_bus_name("ABCDEFGHIJKL", ["ABCDEFGHIJKL", "ABCDEFGHIJ_2"])
        self.assertEqual(len(name), 12)
        self.assertNotIn(name, ["ABCDEFGHIJKL", "ABCDEFGHIJ_2"])

    def test_validate_cleans_and_resolves_duplicates(self):
        raw = diagram([node("a", "bus", bus_number=10, bus_name="it's bus"), node("b", "bus", bus_number=10, bus_name="ITS BUS"),
                       node("c", "bus", bus_number=0, bus_name="'" * 3), node("d", "load", bus_number=11.0)], [("a", "b"), ("b", "d")])
        out = nt.validate_diagram(raw, [])
        by = {n["id"]: n.get("electrical", {}) for n in out["nodes"]}
        self.assertEqual(by["a"], {"bus_number": 10, "bus_name": "ITS BUS"})
        self.assertEqual(by["b"], {})
        self.assertEqual(by["c"], {})
        self.assertEqual(by["d"], {"bus_number": 11})
        self.assertEqual(len(out["warnings"]), 3)
        self.assertEqual(sum("not connected" in w for w in out["warnings"]), 1)


class ShuntTests(unittest.TestCase):
    def test_shunt_node_accepted_and_keys_kept(self):
        raw = diagram([node("b", "bus"), node("s", "shunt", shunt_mvar=-4.5, shunt_steps=3, shunt_step_mvar=1.5, kv=11, bogus=1)], [("b", "s")])
        out = nt.validate_diagram(raw, [])
        self.assertEqual(out["nodes"][1]["electrical"], dict(shunt_mvar=-4.5, shunt_steps=3, shunt_step_mvar=1.5, kv=11))

    def test_shunt_with_two_wires_rejected(self):
        raw = diagram([node("b", "bus"), node("c", "bus"), node("s", "shunt")], [("b", "s"), ("c", "s")])
        with self.assertRaises(ValueError):
            nt.validate_diagram(raw, [])

    def test_pf_view_folds_shunt_into_bus(self):
        raw = diagram([node("b", "bus", shunt_mvar=1.0, kv=11), node("l", "load"), node("s", "shunt", shunt_mvar=4.0), node("r", "shunt", shunt_mvar=-1.5)],
                      [("b", "l"), ("b", "s"), ("r", "b")])
        view = nt.pf_view(nt.validate_diagram(raw, []))
        self.assertEqual([n["id"] for n in view["nodes"]], ["b", "l"])
        self.assertEqual(len(view["lines"]), 1)
        self.assertAlmostEqual(view["nodes"][0]["electrical"]["shunt_mvar"], 3.5)

    def test_pf_view_without_shunts_is_identity(self):
        out = nt.validate_diagram(diagram([node("b", "bus"), node("l", "load")], [("b", "l")]), [])
        self.assertIs(nt.pf_view(out), out)


class AutodrawTests(unittest.TestCase):
    def test_full_topology_each_time(self):
        first = nt.autodraw(["grid", "pv", "bess"])
        self.assertEqual(sorted(n["kind"] for n in first["nodes"]), ["bess", "bus", "grid", "load", "pv"])
        self.assertEqual(len(first["lines"]), 4)
        nt.validate_diagram(dict(first, enabled=True), [dict(id="S", technologies=["grid", "pv", "bess"])])
        cleared = dict(first, nodes=[], lines=[])
        again = nt.autodraw(["grid", "pv", "bess"], existing=cleared)
        self.assertEqual(len(again["nodes"]), 5)
        self.assertEqual(len(again["lines"]), 4)

    def test_no_shunt_unless_requested_or_stored(self):
        self.assertFalse([n for n in nt.autodraw(["grid"])["nodes"] if n["kind"] == "shunt"])
        with_shunt = nt.autodraw(["grid", "pv"], shunt_mvar=6.0)
        shunts = [n for n in with_shunt["nodes"] if n["kind"] == "shunt"]
        self.assertEqual(len(shunts), 1)
        self.assertEqual(shunts[0]["electrical"]["shunt_mvar"], 6.0)
        kept = nt.autodraw(["grid", "pv"], existing=with_shunt)
        self.assertEqual([n["electrical"]["shunt_mvar"] for n in kept["nodes"] if n["kind"] == "shunt"], [6.0])
        resized = nt.autodraw(["grid", "pv"], existing=kept, shunt_mvar=9.0)
        self.assertEqual([n["electrical"]["shunt_mvar"] for n in resized["nodes"] if n["kind"] == "shunt"], [9.0])
        removed = nt.autodraw(["grid", "pv"], existing=resized, shunt_mvar=0)
        self.assertFalse([n for n in removed["nodes"] if n["kind"] == "shunt"])
        self.assertEqual(len(removed["lines"]), 3)
        out = nt.validate_diagram(with_shunt, [])
        self.assertEqual(len(out["lines"]), 4)

    def test_layout_is_centred_and_straight(self):
        for techs in (["grid"], ["grid", "pv"], ["grid", "pv", "bess", "h2", "ng", "ng_chp", "h2_chp"]):
            out = nt.autodraw(techs)
            row = [n for n in out["nodes"] if n["kind"] in techs]
            self.assertTrue(all(n["y"] == 140 and n["x"] % 20 == 0 for n in row))
            self.assertAlmostEqual(sum(n["x"] for n in row) / len(row), 800, delta=20)
            self.assertEqual(len({n["x"] for n in row}), len(row))
            self.assertTrue(all(e["points"] == [] and e["source_port"] == "bottom" and e["target_port"] == "top" for e in out["lines"]))
            self.assertEqual(nt.validate_diagram(out, [])["lines"].__len__(), len(techs) + 1)

    def test_orphan_and_parallel_warnings(self):
        raw = diagram([node("b", "bus"), node("c", "bus"), node("o", "bus")], [("b", "c"), ("c", "b")])
        warnings = nt.validate_diagram(raw, [])["warnings"]
        self.assertTrue(any("'bus' is not connected" in w for w in warnings))
        self.assertTrue(any("Parallel wires" in w for w in warnings))
        self.assertNotIn("warnings", nt.validate_diagram(nt.autodraw(["grid", "pv"]), []))

    def test_ui_default_kv_matches_power_flow(self):
        import power_flow
        source = (ROOT / "generation_ui" / "topology.js").read_text(encoding="utf-8")
        found = re.search(r"const KV_DEFAULT=\{(.*?)\}", source, re.S).group(1)
        parsed = {k: float(v) for k, v in re.findall(r"(\w+):\s*([\d.]+)", found)}
        for kind, kv in power_flow.DEFAULTS["kv_by_kind"]["value"].items():
            self.assertEqual(parsed.get(kind), kv, kind)

    def test_reactor_label_and_bad_input(self):
        reactor = nt.autodraw(["grid"], shunt_mvar=-3)
        self.assertEqual([n["label"] for n in reactor["nodes"] if n["kind"] == "shunt"], ["Shunt reactor"])
        for bad in (float("nan"), 5000, True, "5"):
            with self.assertRaises(ValueError):
                nt.autodraw(["grid"], shunt_mvar=bad)


@unittest.skipUnless(HAS_SOURCE and Path(EDGE).is_file(), "reference run or Edge not available")
class TopologyBrowser(unittest.TestCase):
    def test_editor_behaviour(self):
        from playwright.sync_api import sync_playwright
        rid = uuid.uuid4().hex
        shutil.copytree(RUNS / SOURCE, RUNS / rid)
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)], cwd=ROOT,
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(600):
                try:
                    urlopen(base + "/api/defaults", timeout=1).close()
                    break
                except OSError:
                    time.sleep(.2)
            else:
                self.fail("Test server failed readiness.")
            with sync_playwright() as p:
                browser = p.chromium.launch(executable_path=EDGE, headless=True)
                page = browser.new_context(viewport={"width": 1700, "height": 1100}).new_page()
                errors = []
                page.on("pageerror", lambda e: errors.append(str(e)))
                page.goto(base + "/")
                page.evaluate("r => localStorage.setItem('generation-run', r)", rid)
                page.reload()
                for attempt in range(3):
                    try:
                        page.wait_for_function("() => document.body.dataset.ready === 'true'", timeout=25000)
                        break
                    except Exception:
                        if attempt == 2:
                            raise
                        page.reload()
                page.wait_for_timeout(1500)
                group = page.locator("#input-navigation details").filter(
                    has=page.locator("summary").filter(has_text=re.compile("^Microgrid$")))
                if group.get_attribute("open") is None:
                    group.locator("summary").click()
                group.get_by_role("button", name="Topology / single-line diagram", exact=True).click()
                page.wait_for_selector("#topology-scenario option", state="attached", timeout=90000)
                codes = page.evaluate("[...document.querySelectorAll('#topology-scenario option')].map(o => o.value)")
                multi = next(c for c in codes if page.evaluate("c => (readScenarioRows().find(r => r.id === c).technologies || []).length > 2", c))
                other = next(c for c in codes if c != multi)
                techs = page.evaluate("c => readScenarioRows().find(r => r.id === c).technologies", multi)

                def switch(code):
                    page.select_option("#topology-scenario", code)
                    page.wait_for_timeout(200)

                def graph():
                    return page.evaluate("topologyEditor.geometry()")

                def to_screen(x, y):
                    return page.evaluate("""([x, y]) => {const s = document.getElementById('topology-svg'), p = s.createSVGPoint();
                        p.x = x; p.y = y; const q = p.matrixTransform(s.getScreenCTM()); return [q.x, q.y];}""", [x, y])

                # 1. Clear, switch away and back, autodraw regenerates the whole connected topology, every time.
                switch(multi)
                page.click("#topology-autodraw")
                self.assertEqual(len(graph()["nodes"]), len(techs) + 2)
                for attempt in range(3):
                    page.click("#topology-clear")
                    self.assertEqual(len(graph()["nodes"]), 0)
                    switch(other)
                    switch(multi)
                    page.click("#topology-autodraw")
                    g = graph()
                    self.assertEqual(sorted(n["kind"] for n in g["nodes"]), sorted(["bus", "load", *techs]), attempt)
                    self.assertEqual(len(g["lines"]), len(techs) + 1)
                page.click("#topology-undo")
                page.click("#topology-autodraw")
                self.assertEqual(len(graph()["nodes"]), len(techs) + 2)
                page.click("#topology-clear")
                page.click("#topology-undo")
                page.click("#topology-autodraw")
                self.assertEqual(len(graph()["nodes"]), len(techs) + 2)

                # 2. Marquee selection, group move, wheel zoom.
                def frame():
                    page.click("#topology-fit")
                    page.evaluate("""() => {const s = document.getElementById('topology-svg'), b = s.viewBox.baseVal;
                        s.setAttribute('viewBox', `${b.x - 150} ${b.y - 150} ${b.width + 300} ${b.height + 300}`); s.scrollIntoView();}""")
                    page.wait_for_timeout(100)
                g = graph()
                xs = [n["x"] for n in g["nodes"]]
                ys = [n["y"] for n in g["nodes"]]
                frame()
                x0, y0 = to_screen(min(xs) - 90, min(ys) - 70)
                x1, y1 = to_screen(max(xs) + 90, max(ys) + 70)
                page.mouse.move(x0, y0)
                page.mouse.down()
                page.mouse.move((x0 + x1) / 2, (y0 + y1) / 2, steps=4)
                page.mouse.move(x1, y1, steps=4)
                self.assertEqual(page.locator("#topology-svg .marquee").count(), 1)
                page.mouse.up()
                self.assertEqual(page.locator("#topology-svg .diagram-node.selected").count(), len(g["nodes"]))
                self.assertEqual(page.locator("#topology-svg .diagram-edge.selected").count(), len(g["lines"]))
                before = {n["id"]: (n["x"], n["y"]) for n in graph()["nodes"]}
                bus = next(n for n in g["nodes"] if n["kind"] == "bus")
                sx, sy = to_screen(bus["x"], bus["y"])
                page.mouse.move(sx, sy)
                page.mouse.down()
                page.mouse.move(sx - 60, sy + 40, steps=5)
                page.mouse.up()
                after = {n["id"]: (n["x"], n["y"]) for n in graph()["nodes"]}
                deltas = {(after[k][0] - before[k][0], after[k][1] - before[k][1]) for k in before}
                self.assertEqual(len(deltas), 1, deltas)
                self.assertNotEqual(deltas.pop(), (0, 0))
                # Partial overlap selects just the touched components.
                frame()
                lo = next(n for n in graph()["nodes"] if n["kind"] == "load")
                ax, ay = to_screen(lo["x"], lo["y"])
                page.mouse.move(ax - 110, ay + 50)
                page.mouse.down()
                page.mouse.move(ax - 10, ay + 5, steps=5)
                page.mouse.up()
                self.assertEqual(page.locator("#topology-svg .diagram-node.selected").count(), 1)
                # Pan mode keeps working and empty-canvas drags do not marquee there.
                page.click("#topology-pan")
                view = page.evaluate("document.getElementById('topology-svg').getAttribute('viewBox')")
                page.mouse.move(60, 600)
                page.evaluate("document.getElementById('topology-svg').scrollIntoView()")
                box = page.locator("#topology-svg").bounding_box()
                page.mouse.move(box["x"] + 20, box["y"] + 300)
                page.mouse.down()
                page.mouse.move(box["x"] + 120, box["y"] + 360, steps=4)
                page.mouse.up()
                self.assertNotEqual(view, page.evaluate("document.getElementById('topology-svg').getAttribute('viewBox')"))
                self.assertEqual(page.locator("#topology-svg .marquee").count(), 0)
                page.click("#topology-select")
                # Wheel zooms about the cursor.
                page.click("#topology-fit")
                page.evaluate("document.getElementById('topology-svg').scrollIntoView()")
                box = page.locator("#topology-svg").bounding_box()
                cx, cy = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2
                world = page.evaluate("""([x, y]) => {const s = document.getElementById('topology-svg'), p = s.createSVGPoint();
                    p.x = x; p.y = y; const q = p.matrixTransform(s.getScreenCTM().inverse()); return [q.x, q.y, s.viewBox.baseVal.width];}""", [cx, cy])
                page.mouse.move(cx, cy)
                page.mouse.wheel(0, -300)
                page.wait_for_timeout(100)
                zoomed = page.evaluate("""([x, y]) => {const s = document.getElementById('topology-svg'), p = s.createSVGPoint();
                    p.x = x; p.y = y; const q = p.matrixTransform(s.getScreenCTM().inverse()); return [q.x, q.y, s.viewBox.baseVal.width];}""", [cx, cy])
                self.assertLess(zoomed[2], world[2])
                self.assertAlmostEqual(zoomed[0], world[0], delta=1.5)
                self.assertAlmostEqual(zoomed[1], world[1], delta=1.5)
                page.mouse.wheel(0, 600)
                page.wait_for_timeout(100)
                self.assertGreater(page.evaluate("document.getElementById('topology-svg').viewBox.baseVal.width"), zoomed[2])

                # 4/5. Shunt component and autodraw shunt request.
                self.assertEqual(page.locator("#topology-palette button", has_text="+ Shunt").count(), 1)
                page.click("#topology-palette button:has-text('+ Shunt')")
                self.assertEqual(page.locator("#topology-svg [data-node]").count(), len(techs) + 3)
                self.assertGreater(page.locator("#topology-svg [data-node] .electrical-symbol").count(), 0)
                page.click("#topology-undo")
                self.assertTrue(page.evaluate("c => topologyEditor.autodraw(c, {shunt_mvar: 7.5})", multi))
                g = page.evaluate("c => topologyEditor.graph(c)", multi)
                shunts = [n for n in g["nodes"] if n["kind"] == "shunt"]
                self.assertEqual(len(shunts), 1)
                self.assertEqual(shunts[0]["electrical"]["shunt_mvar"], 7.5)
                bus_id = next(n["id"] for n in g["nodes"] if n["kind"] == "bus")
                self.assertTrue(any({e["source"], e["target"]} == {bus_id, shunts[0]["id"]} for e in g["lines"]))
                page.click("#topology-autodraw")  # a stored shunt survives a plain autodraw
                self.assertEqual(len([n for n in graph()["nodes"] if n["kind"] == "shunt"]), 1)
                # A second wire on a shunt is refused.
                page.evaluate("topologyEditor.autodraw(null, {shunt_mvar: 0})")
                self.assertEqual(len([n for n in graph()["nodes"] if n["kind"] == "shunt"]), 0)

                # 3. Bus naming edits are sanitised and duplicate numbers rejected.
                gnode = graph()["nodes"]
                a, b = gnode[0]["id"], gnode[1]["id"]
                self.assertTrue(page.evaluate("([c, a]) => topologyEditor.updateComponent(c, a, {electrical: {bus_number: 77, bus_name: \"it's a very long name\"}})", [multi, a]))
                self.assertFalse(page.evaluate("([c, b]) => topologyEditor.updateComponent(c, b, {electrical: {bus_number: 77}})", [multi, b]))
                self.assertFalse(page.evaluate("([c, b]) => topologyEditor.updateComponent(c, b, {electrical: {bus_number: 0}})", [multi, b]))
                self.assertTrue(page.evaluate("([c, b]) => topologyEditor.updateComponent(c, b, {electrical: {bus_name: \"ITS A VERY L\"}})", [multi, b]))
                element = page.evaluate("([c, a, b]) => [topologyEditor.component(c, a).electrical, topologyEditor.component(c, b).electrical]", [multi, a, b])
                self.assertEqual(element[0], {"bus_number": 77, "bus_name": "ITS A VERY L"})
                self.assertEqual(element[1]["bus_name"], "ITS A VERY_2")
                # 6. Autodraw layout matches the Python generator; standards-style presentation; checks panel; export.
                switch(multi)
                page.click("#topology-autodraw")
                drawn = page.evaluate("c => topologyEditor.graph(c)", multi)
                expected = nt.autodraw(techs)
                self.assertEqual({n["kind"]: (n["x"], n["y"]) for n in drawn["nodes"]},
                                 {n["kind"]: (n["x"], n["y"]) for n in expected["nodes"]})
                for line in graph()["lines"]:
                    route = line["route"]
                    self.assertTrue(all(a["x"] == b["x"] or a["y"] == b["y"] for a, b in zip(route, route[1:])))
                if "grid" in techs:
                    self.assertEqual(page.locator("#topology-svg .xf-symbol").count(), 1)
                self.assertEqual(page.locator("#topology-svg .connection-port").first.evaluate("e => getComputedStyle(e).opacity"), "0")
                self.assertEqual(page.locator("#topology-checks .topology-check.error").count(), 0)
                load_id = next(n["id"] for n in drawn["nodes"] if n["kind"] == "load")
                page.locator(f'#topology-svg [data-node="{load_id}"] .node-hit').click(force=True)
                page.click("#topology-delete")
                self.assertIn("Load", page.locator("#topology-checks .topology-check.error").first.inner_text())
                page.click("#topology-undo")
                self.assertEqual(page.locator("#topology-checks .topology-check").count(), 0)
                with page.expect_download() as download:
                    page.click("#topology-export-svg")
                svg_text = Path(download.value.path()).read_text(encoding="utf-8")
                self.assertIn("kv-legend", svg_text)
                self.assertNotIn("connection-port", svg_text)
                with page.expect_download() as download:
                    page.click("#topology-export-png")
                self.assertEqual(errors, [])
                browser.close()
        finally:
            server.terminate()
            try:
                server.wait(10)
            except subprocess.TimeoutExpired:
                server.kill()
            shutil.rmtree(RUNS / rid, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
