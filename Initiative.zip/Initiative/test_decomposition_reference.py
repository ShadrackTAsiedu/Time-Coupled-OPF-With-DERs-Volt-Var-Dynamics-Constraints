"""Benders decomposition versus an independently written monolithic LP (scipy HiGHS) on a 12-day instance."""

import math
import unittest

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import lil_matrix

import generation_app as app
import optimize_generation_mix as model
import scenario_inputs
from test_client_planning import short_data


def reference_npc(data, cfg, names, throughput, island=False):
    """Direct LP over capacities and every hour of year 1, with one SOC cycle and one demand-charge peak per `mi` block."""
    n = len(data["load"])
    w = (1 + cfg["inflation"]) / (1 + cfg["discount"])
    eta = math.sqrt(cfg["round_trip_efficiency"])
    gens = [g for g in names if g != "none"]
    tp = cfg["technology_parameters"]
    nc = 3 + len(gens)
    per = ["g", "pv", "c", "d", "s"] + ["z_" + g for g in gens] + (["r"] if island else [])
    col = {name: nc + i * n + np.arange(n) for i, name in enumerate(per)}
    k = nc + len(per) * n
    blocks = np.unique(data["mi"])
    m_col = {b: k + i for i, b in enumerate(blocks)}
    t_col = {b: k + len(blocks) + i for i, b in enumerate(blocks)}
    k += 2 * len(blocks)
    cost = np.zeros(k)
    cost[0] = cfg["pv_capex"] + cfg["pv_fom"] * w
    cost[1] = cfg["bess_power_capex"] * (1 + cfg["bess_fom_fraction"] * w)
    cost[2] = cfg["bess_energy_capex"] * (1 + cfg["bess_fom_fraction"] * w) + 0.5 / eta * data["grid_energy"][0]
    for i, g in enumerate(gens):
        cost[3 + i] = tp[g]["capex"] + tp[g]["fom"] * w
        cost[col["z_" + g]] = w * (tp[g]["fuel"] + tp[g]["vom"] + tp[g]["carbon"])
    cost[col["g"]] = w * data["grid_energy"]
    cost[col["d"]] = w * throughput
    for b in blocks:
        cost[m_col[b]], cost[t_col[b]] = w * data["facility"][b], w * data["tou"][b]
    lo, hi = np.zeros(k), np.full(k, np.inf)
    hi[0] = cfg["pv_max"]
    hi[1], hi[2] = cfg["bess_power_max"], cfg["bess_energy_max"]
    for i in range(len(gens)):
        hi[3 + i] = cfg["generator_max"]
    load, margin = data["load"], data["qmax"] - data["load"]
    reserve_margin = margin.copy()
    if island:
        margin = np.zeros(n)
        lo[col["g"]], hi[col["g"]] = 0, 0
    else:
        lo[col["g"]] = load - data["qmin"]
        hi[col["g"]] = cfg["grid_limit"] - margin
    eq, ub = [], []

    def row(terms, sense, rhs):
        (eq if sense == "=" else ub).append((terms, rhs))

    for t in range(n):
        row([(col["g"][t], 1), (col["pv"][t], 1), (col["d"][t], 1), (col["c"][t], -1)] +
            [(col["z_" + g][t], 1) for g in gens], "=", load[t])
        row([(col["pv"][t], 1), (0, -data["solar"][t])], "<", 0)
        row([(col["c"][t], 1), (1, -1)], "<", 0)
        row([(col["d"][t], 1), (1, -1)], "<", 0)
        row([(col["s"][t], 1), (2, -cfg["soc_max"])], "<", 0)
        row([(col["s"][t], -1), (2, cfg["soc_min"])], "<", 0)
        opening = t == 0 or data["mi"][t] != data["mi"][t - 1]
        previous = [(2, -0.5)] if opening else [(col["s"][t - 1], -1)]
        row([(col["s"][t], 1), (col["c"][t], -eta), (col["d"][t], 1 / eta)] + previous, "=", 0)
        row([(col["g"][t], 1), (m_col[data["mi"][t]], -1)], "<", -margin[t])
        if data["peak_window"][t]:
            row([(col["g"][t], 1), (t_col[data["mi"][t]], -1)], "<", -margin[t])
        for i, g in enumerate(gens):
            row([(col["z_" + g][t], 1), (3 + i, -1)], "<", 0)
        if island:
            row([(col["r"][t], 1), (col["d"][t], 1), (1, -1)], "<", 0)
            row([(col["r"][t], .25 / eta), (col["s"][t], -1), (2, cfg["soc_min"])], "<", 0)
            row([(col["r"][t], -1)] + [(col["z_" + g][t], 1) for g in gens] +
                [(3 + i, -1) for i in range(len(gens))], "<", -reserve_margin[t])
    for t in range(n):
        if t == n - 1 or data["mi"][t] != data["mi"][t + 1]:
            row([(col["s"][t], 1), (2, -0.5)], "=", 0)
    for day in np.unique(data["di"]):
        sel = np.flatnonzero(data["di"] == day)
        row([(col["d"][t], 1) for t in sel] + [(2, -(cfg["soc_max"] - cfg["soc_min"]) * eta * cfg["daily_cycles"])], "<", 0)
    row([(1, 2), (2, -1)], "<", 0)
    row([(2, 1), (1, -cfg["duration_max"])], "<", 0)

    def matrix(rows):
        a, b = lil_matrix((len(rows), k)), np.zeros(len(rows))
        for r, (terms, rhs) in enumerate(rows):
            for c, v in terms:
                a[r, c] += v
            b[r] = rhs
        return a.tocsr(), b

    a_ub, b_ub = matrix(ub)
    a_eq, b_eq = matrix(eq)
    result = linprog(cost, A_ub=a_ub, b_ub=b_ub, A_eq=a_eq, b_eq=b_eq, bounds=list(zip(lo, hi)), method="highs")
    assert result.success, result.message
    return result.fun + w * sum(data["fixed"][b] for b in blocks), result.x[:nc]


class DecompositionAgainstMonolithic(unittest.TestCase):
    def settings(self, eligible, cheap=False, **overrides):
        request = app.validate_request(dict(values=dict(horizon_years=1), scenarios=["R0", "ALL"]))
        cfg, names = scenario_inputs.settings(app.settings_for(request["values"]),
                                              dict(id="X", technologies=eligible))
        base = dict(allow_unserved=False, microgrid_min_mw=0, microgrid_max_mw=None, include_replacements=False)
        base.update(overrides)
        cfg.update(base)
        if cheap:
            cfg.update(pv_capex=1000.0, pv_fom=10.0, bess_power_capex=3000.0, bess_energy_capex=1500.0)
            cfg["technology_parameters"]["ng"].update(capex=60000.0, fom=1000.0, fuel=40.0, vom=2.0, carbon=5.0)
        return cfg, names

    def check(self, eligible, island=False, **overrides):
        data = short_data()
        cfg, names = self.settings(eligible, **overrides)
        result = model.solve_decomposed(data, "X", "Reference check", names, settings=cfg)
        self.assertTrue(model.bess_throughput_is_cash(cfg))
        expected, caps = reference_npc(data, cfg, names, model.bess_throughput_rate(cfg), island=island)
        self.assertAlmostEqual(result["economics"]["npc"], expected, delta=max(300, 3e-6 * abs(expected)))
        return result, caps

    def test_island_with_reserve_matches_monolithic_lp_and_is_clean(self):
        result, caps = self.check(["pv", "bess", "ng"], island=True, cheap=True, allow_unserved=True, pv_min=0,
                                  pv_max=30, bess_power_max=20, bess_energy_max=160, generator_max=30)
        self.assertEqual(result["adequacy"]["unserved_hours"], 0)
        self.assertGreater(result["caps"]["generators_mw"]["ng"], 1)
        self.assertAlmostEqual(result["caps"]["bess_mwh"], caps[2], delta=1e-3)
        for value in (*result["caps"].values(),):
            if isinstance(value, float):
                self.assertFalse(value < 0 or str(value) == "-0.0")
        for name, series in result["dispatch"].items():
            self.assertFalse(np.any(np.signbit(series) & (series == 0)), name)
            self.assertGreaterEqual(series.min(), 0, name)

    def test_clean_value_snaps_round_off(self):
        self.assertEqual(str(model.clean_value(-1.2e-12)), "0.0")
        self.assertEqual(str(model.clean_value(-0.0)), "0.0")
        self.assertEqual(model.clean_value(-0.5), -0.5)

    def test_default_costs_grid_dominates(self):
        self.check(["grid", "pv", "bess"])

    def test_cheap_pv_bess_are_built_and_match(self):
        result, caps = self.check(["grid", "pv", "bess"], cheap=True)
        self.assertGreater(result["caps"]["pv_dc_mw"], 1)
        self.assertGreater(result["caps"]["bess_mwh"], 1)
        self.assertAlmostEqual(result["caps"]["pv_dc_mw"], caps[0], delta=1e-3)

    def test_cheap_gas_competes_with_grid(self):
        result, _ = self.check(["grid", "pv", "bess", "ng"], cheap=True)
        self.assertGreater(result["caps"]["generators_mw"]["ng"], 1)

    def test_cash_throughput_wear_cost(self):
        self.check(["grid", "pv", "bess", "ng"], cheap=True, bess_throughput_cost=12.0)


if __name__ == "__main__":
    unittest.main()
