"""Solver backend selection/fallback (Gurobi optional) and effective-technology ranking rules."""

import json
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

import extensions
import optimize_generation_mix as model
import solver_backend
import workflow
from test_generation_optimization import small_inputs

RUN = Path(__file__).resolve().parent / "Application Runs" / "7791be18470745f8af5ef34fa3d208f8"
UNLICENSED = dict(installed=True, licensed=False, restricted=True, version="13.0.3", message="restricted licence")
LICENSED = dict(installed=True, licensed=True, restricted=False, version="13.0.3", message="ok")


def result(code, name, eligible, caps_extra=None, gen_mwh=0.0, npc=1.0e8, pv=1.0e4, bess=100.0):
    gens = {t: 0.0 for t in eligible if t not in ("grid", "pv", "bess")}
    gens.update(caps_extra or {})
    annual = [dict(year=2027 + i, gen_mwh=gen_mwh / 10, pv_mwh=pv, bess_discharge_mwh=bess, demand_mwh=2e5) for i in range(10)]
    return dict(code=code, name=name, case="A", eligible_technologies=eligible,
                caps=dict(pv_dc_mw=6.0 if "pv" in eligible else 0.0, bess_mw=3.0 if "bess" in eligible else 0.0,
                          bess_mwh=12.0 if "bess" in eligible else 0.0, generators_mw=gens or {"none": 0.0}),
                economics=dict(npc=npc, annual=annual), adequacy=dict(unserved_hours=0, unserved_mwh=0.0))


class SolverSelectionTests(unittest.TestCase):
    def test_default_is_highs(self):
        self.assertEqual(solver_backend.resolve({}), ("highs", ""))
        self.assertEqual(solver_backend.solver_info(dict(solver="highs"))["used"], "highs")

    def test_gurobi_falls_back_when_unlicensed(self):
        with mock.patch.object(solver_backend, "gurobi_status", return_value=dict(UNLICENSED)):
            info = solver_backend.solver_info(dict(solver="gurobi"))
            self.assertEqual((info["requested"], info["used"]), ("gurobi", "highs"))
            self.assertIn("restricted", info["note"])
            self.assertEqual(solver_backend.available(), ["highs"])
            sub = model.MonthlyDispatch(small_inputs(), 0, "none", False, small_inputs()["solar"], settings=dict(
                model.default_settings(), solver="gurobi"))
            self.assertEqual(sub.backend, "highs")

    def test_unknown_solver_falls_back(self):
        used, note = solver_backend.resolve(dict(solver="cplex"))
        self.assertEqual(used, "highs")
        self.assertIn("cplex", note)

    def test_route_registered(self):
        self.assertIn("solvers", extensions.GET)
        self.assertIn("solver_backend", extensions.MODULES)
        with mock.patch.object(solver_backend, "gurobi_status", return_value=dict(LICENSED)):
            out = extensions.GET["solvers"]({})
            self.assertEqual(out["available"], ["highs", "gurobi"])
            self.assertTrue(out["gurobi"]["licensed"])
            self.assertEqual(out["default"], "highs")

    def test_decomposed_result_records_solver(self):
        data = small_inputs()
        cfg = dict(model.default_settings(), solver="gurobi")
        with mock.patch.object(solver_backend, "gurobi_status", return_value=dict(UNLICENSED)):
            out = model.solve_decomposed(data, "TEST_S", "t", "none", settings=cfg)
        self.assertEqual(out["solver"]["used"], "highs")
        self.assertEqual(out["solver"]["requested"], "gurobi")
        self.assertTrue(out["solver"]["note"])


class GurobiParityTests(unittest.TestCase):
    """Run only with gurobipy installed; a restricted licence still handles this one-day block."""

    @classmethod
    def setUpClass(cls):
        try:
            import gurobipy  # noqa: F401
        except ImportError:
            raise unittest.SkipTest("gurobipy not installed")

    def test_dispatch_value_and_duals_match_highs(self):
        data = small_inputs()
        caps = np.array([10.0, 12.0, 60.0, 0.0])
        base = model.default_settings()
        highs = model.MonthlyDispatch(data, 0, "none", False, data["solar"], settings=base)
        with mock.patch.object(solver_backend, "gurobi_status", return_value=dict(LICENSED)):
            grb = model.MonthlyDispatch(data, 0, "none", False, data["solar"], settings=dict(base, solver="gurobi"))
        self.assertEqual(grb.backend, "gurobi")
        v1, g1 = highs.evaluate(caps)
        try:
            v2, g2 = grb.evaluate(caps)
        except Exception as exc:
            if "too large" in str(exc).lower():
                self.skipTest("Gurobi licence is size-limited")
            raise
        self.assertAlmostEqual(v1, v2, delta=1e-6 * max(1, abs(v1)))
        np.testing.assert_allclose(g1, g2, rtol=1e-4, atol=1e-6)
        trial = np.array([9.0, 10.0, 50.0, 0.0])
        a, _ = highs.evaluate(trial)
        b, _ = grb.evaluate(trial)
        self.assertAlmostEqual(a, b, delta=1e-6 * max(1, abs(a)))


class AutoShuntTests(unittest.TestCase):
    def test_autoshunt_used_once_and_noted(self):
        import types
        fake = types.SimpleNamespace(autoshunt=lambda run, code, apply=False: dict(
            existing_mvar=1.0, needed_mvar=3.0, total_mvar=4.0, cost_usd=50000.0, applied=bool(apply)))
        with mock.patch.dict("sys.modules", {"power_flow": fake}):
            shunt = workflow._shunt("r", "H2", dict(status="FAIL"))
            self.assertEqual((shunt["mvar"], shunt["cost_usd"], shunt["applied"]), (4.0, 50000.0, True))
            self.assertIsNone(workflow._shunt("r", "H2", dict(status="PASS")))
        r = result("H2", "x", ["grid", "pv", "bess"])
        r["shunt"] = {k: v for k, v in shunt.items() if k != "detail"}
        notes = workflow.entry_from(r)["notes"]
        self.assertTrue(any("Auto shunt" in n and "applied" in n for n in notes))


class EffectiveTechnologyTests(unittest.TestCase):
    def test_unbuilt_hydrogen_is_not_effective(self):
        eff = workflow.effective_technologies(result("H2", "Grid + PV + BESS + Hydrogen", ["grid", "pv", "bess", "h2"]))
        self.assertEqual(eff["effective_key"], frozenset({"pv", "bess"}))
        self.assertEqual(eff["unbuilt"], ["h2"])
        self.assertEqual(eff["effective_name"], "effective mix: Grid + Solar PV + BESS (Hydrogen not built)")

    def test_built_but_negligible_dispatch_is_unused(self):
        eff = workflow.effective_technologies(result("H2", "x", ["grid", "pv", "bess", "h2"], {"h2": 2.0}, gen_mwh=0.5))
        self.assertEqual(eff["built"], ["pv", "bess", "h2"])
        self.assertEqual(eff["unused"], ["h2"])
        self.assertEqual(eff["effective"], ["pv", "bess"])

    def test_small_but_real_dispatch_is_used(self):
        eff = workflow.effective_technologies(result("NG", "x", ["grid", "pv", "bess", "ng"], {"ng": 0.76}, gen_mwh=56.0))
        self.assertEqual(eff["effective_key"], frozenset({"pv", "bess", "ng"}))
        self.assertTrue(eff["is_simplest"])

    def test_simpler_scenario_wins_even_when_marginally_cheaper_complex_option_listed_first(self):
        h2 = result("H2", "Grid + PV + BESS + Hydrogen", ["grid", "pv", "bess", "h2"], npc=1.0e8 - 1)
        p1 = result("P1", "Grid + PV + BESS", ["grid", "pv", "bess"], npc=1.0e8)
        entries, rec = workflow.rank([workflow.entry_from(r, i) for i, r in enumerate([h2, p1])])
        self.assertEqual(rec["code"], "P1")
        h2_entry = next(e for e in entries if e["code"] == "H2")
        self.assertFalse(h2_entry["is_recommended"])
        self.assertEqual(h2_entry["effective_technologies"]["unbuilt"], ["h2"])

    def test_unused_option_loses_to_simpler_within_tolerance(self):
        ng = result("NG", "ng", ["grid", "pv", "bess", "ng"], {"ng": 1.0}, gen_mwh=0.2, npc=1.0e8 - 2e5)
        p1 = result("P1", "p1", ["grid", "pv", "bess"], npc=1.0e8)
        _, rec = workflow.rank([workflow.entry_from(r, i) for i, r in enumerate([ng, p1])])
        self.assertEqual(rec["code"], "P1")

    def test_dispatching_technology_keeps_its_advantage(self):
        ng = result("NG", "ng", ["grid", "pv", "bess", "ng"], {"ng": 0.76}, gen_mwh=56.0, npc=0.99e8)
        p1 = result("P1", "p1", ["grid", "pv", "bess"], npc=1.0e8)
        _, rec = workflow.rank([workflow.entry_from(r, i) for i, r in enumerate([p1, ng])])
        self.assertEqual(rec["code"], "NG")

    def test_label_kept_when_no_simpler_scenario_exists(self):
        h2 = result("H2", "Grid + PV + BESS + Hydrogen", ["grid", "pv", "bess", "h2"])
        entries, rec = workflow.rank([workflow.entry_from(h2)])
        self.assertEqual(rec["code"], "H2")
        self.assertEqual(rec["effective_name"], "effective mix: Grid + Solar PV + BESS (Hydrogen not built)")
        self.assertTrue(any("Hydrogen" in w for w in rec["warnings"]))

    def test_simpler_scenario_must_be_feasible_and_close_in_cost(self):
        h2 = result("H2", "h2", ["grid", "pv", "bess", "h2"], npc=1.0e8)
        p1 = result("P1", "p1", ["grid", "pv", "bess"], npc=1.2e8)
        _, rec = workflow.rank([workflow.entry_from(r, i) for i, r in enumerate([h2, p1])])
        self.assertEqual(rec["code"], "H2")

    @unittest.skipUnless((RUN / "result_H2.json").is_file(), "reference run not present")
    def test_real_run(self):
        load = lambda c: {k: v for k, v in json.loads((RUN / f"result_{c}.json").read_text(encoding="utf-8")).items()
                          if k != "technical_status"}
        h2, ng = workflow.effective_technologies(load("H2")), workflow.effective_technologies(load("NG"))
        self.assertEqual(h2["effective_key"], frozenset({"pv", "bess"}))
        self.assertIn("ng", ng["effective_key"])
        results = [load(c) for c in ("H2", "P1")]
        entries, rec = workflow.rank([workflow.entry_from(r, i) for i, r in enumerate(results)])
        self.assertEqual(rec["code"], "P1")
        self.assertEqual(workflow.rank([workflow.entry_from(results[0])])[1]["code"], "H2")


if __name__ == "__main__":
    unittest.main()
