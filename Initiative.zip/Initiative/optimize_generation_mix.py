"""Capacity-expansion and chronological dispatch model: Benders decomposition of a capacity master LP/MIP and hourly dispatch LPs.

Every cost is a present value at the valuation date (end of year 0): capital is spent upfront in nominal 2026-style dollars,
operating cash flows of operating year y are escalated by (1+inflation)^y and discounted by (1+discount)^y (year-end convention).
"""

from __future__ import annotations

import math
import time

import highspy
import matplotlib
import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog, milp, Bounds, LinearConstraint

import lifecycle_costs
import network_topology
import solver_backend

matplotlib.use("Agg")  # the application renders figures from worker threads; never open a GUI backend

B = 33.34421  # peak (MW) of the bundled sample demand profile
INFLATION = 0.03
DISCOUNT = 0.06


def bess_throughput_rate(cfg, reference=False):
    """Real $/MWh of discharged energy. Reference cases and zero entries keep only the 0.01 non-cash tie-break."""
    rate = float(cfg.get("bess_throughput_cost", 0) or 0)
    return rate if rate > 0 and not reference else 0.01


def bess_throughput_is_cash(cfg, reference=False):
    return float(cfg.get("bess_throughput_cost", 0) or 0) > 0 and not reference


def upgrade_decision(cfg, grid_peak, years, reference):
    """The grid upgrade is paid only if required import exceeds the existing limit.

    The quoted upgrade buys capacity up to the quoted upgraded limit; a larger need is priced pro rata.
    It is paid at the valuation date, as before, but only when the dispatch actually needs it."""
    existing = float(cfg["grid_limit"])
    grid_peak = np.asarray(grid_peak)
    needed = float(grid_peak.max()) if len(grid_peak) else 0.0
    exceeded = np.flatnonzero(grid_peak > existing + 1e-6)
    out = dict(required=False, cost=0.0, capacity_mw=existing, needed_mw=needed, existing_limit_mw=existing,
               first_year_index=None, note="")
    if not reference:
        return out
    if not len(exceeded):
        out["note"] = (f"Upgrade not required: peak grid import {needed:.3f} MW does not exceed the existing "
                       f"{existing:g} MW limit, so upgrade cost is zero and this case equals grid-only supply.")
        return out
    quoted = float(cfg.get("reference_grid_limit_input", cfg["reference_grid_limit"]))
    block = quoted - existing
    scale = 1.0 if block <= 1e-9 or needed <= quoted + 1e-9 else (needed - existing) / block
    out.update(required=True, cost=float(cfg["upgrade_cost"]) * scale, capacity_mw=max(needed, quoted),
               first_year_index=int(years[exceeded[0]]))
    out["note"] = (f"Upgrade required: peak grid import {needed:.3f} MW exceeds the existing {existing:g} MW limit "
                   f"(first needed in operating year {out['first_year_index'] + 1}).")
    return out
MMBTU_PER_MWH = 3.412142
CO2_PER_MMBTU = 0.05306
SOURCES = {
    "PV": "https://atb.nlr.gov/electricity/2024/commercial_pv",
    "BESS": "https://atb.nlr.gov/electricity/2024/utility-scale_battery_storage",
    "CHP": "https://www.epa.gov/sites/default/files/2015-07/documents/catalog_of_chp_technologies_section_3._technology_characterization_-_combustion_turbines.pdf",
    "Gas": "https://www.eia.gov/dnav/ng/ng_pri_sum_dcu_SCA_m.htm",
    "Emissions": "https://www.epa.gov/climateleadership/ghg-emission-factors-hub",
}
TECH = {
    **{name: dict(capex=0, fom=0, vom=0, fuel=0, carbon=0, ratio=0, life=25,
                   emissions_t_mwh=0) for name in ("diesel", "biogas", "biomass")},
    "wind": dict(capex=1800000, fom=45000, vom=0, fuel=0, carbon=0, ratio=0, life=25,
                 emissions_t_mwh=0),
    "none": dict(capex=0, fom=0, vom=0, fuel=0, carbon=0, ratio=0, life=25),
    "h2": dict(capex=3000000, fom=45000, vom=15, fuel=6 * 1000 / (33.33 * 0.35),
               carbon=0, ratio=0, life=25),
    "h2_chp": dict(capex=3800000, fom=55000, vom=18, fuel=6 * 1000 / (33.33 * 0.35),
                   carbon=0, ratio=0.40 / 0.35, life=25),
    "ng": dict(capex=2000000, fom=30000, vom=10, fuel=8 * MMBTU_PER_MWH / 0.30,
               carbon=100 * CO2_PER_MMBTU * MMBTU_PER_MWH / 0.30, ratio=0, life=25),
    "ng_chp": dict(capex=3100000, fom=45000, vom=12, fuel=8 * MMBTU_PER_MWH / 0.28,
                   carbon=100 * CO2_PER_MMBTU * MMBTU_PER_MWH / 0.28,
                   ratio=0.41 / 0.28, life=25),
}
PATHWAYS = [
    ("PV+BESS", "none"), ("Hydrogen turbine", "h2"), ("Hydrogen CHP", "h2_chp"),
    ("Natural gas turbine", "ng"), ("Natural gas CHP", "ng_chp"),
    ("Diesel generator", "diesel"), ("Biogas generator", "biogas"), ("Biomass generator", "biomass"),
]
BOILER_CREDIT = MMBTU_PER_MWH / 0.80 * (8 + 100 * CO2_PER_MMBTU)
SOLVERS = {
    "dual_simplex": ("HiGHS dual simplex", "simplex", "highs-ds"),
    "interior_point": ("HiGHS interior point + crossover", "ipm", "highs-ipm"),
    "automatic": ("HiGHS automatic", "choose", "highs"),
}


def solver_choice(settings):
    key = settings.get("solver_method", "dual_simplex")
    if key not in SOLVERS:
        raise ValueError(f"Unknown solver method: {key}")
    return SOLVERS[key]


def clean_value(value, tolerance=1e-7):
    """Snap solver round-off (tiny negatives, negative zero) to a positive zero."""
    return 0.0 if abs(value) < tolerance else value


def default_settings():
    """Numeric settings shared by the original study and the local application."""
    return dict(solver_method="dual_simplex", grid_limit=40.0, reference_grid_limit=50.0,
                pv_min=8.0, pv_max=10.0, reference_pv=8.0,
                bess_power_max=None, bess_energy_max=None, generator_max=None,
                bess_land_acres=None, bess_acres_per_mw=0.0, bess_acres_per_mwh=0.0,
                forced_generator_min=5.0, duration_min=2.0, duration_max=8.0,
                pv_capex=2500000.0, pv_fom=25000.0,
                bess_power_capex=400000.0, bess_energy_capex=250000.0,
                bess_fom_fraction=0.025, round_trip_efficiency=0.85,
                soc_min=0.1, soc_max=0.9, daily_cycles=1.0,
                inflation=INFLATION, discount=DISCOUNT,
                upgrade_cost=70000000.0, upgrade_fom_fraction=0.005,
                boiler_credit=BOILER_CREDIT, boiler_efficiency=0.8,
                ng_turbine_efficiency=0.30, ng_chp_efficiency=0.28,
                allow_unserved=False, grid_only_reference=False,
                shortfall_priority_usd_mwh=100000000.0,
                microgrid_min_mw=0.0, microgrid_max_mw=None, dc_ac=1.0,
                grid_emissions_t_mwh=0.0, h2_emissions_kgco2_kg=0.0,
                emission_factors_confirmed=True,
                emissions_limit_enabled=False, emissions_limit_t_year=0,
                ng_emissions_t_mmbtu=CO2_PER_MMBTU, pv_emissions_t_mwh=0.0,
                bess_emissions_t_mwh=0.0, wind_emissions_t_mwh=0.0,
                boiler_emissions_t_mwhth=MMBTU_PER_MWH / .8 * CO2_PER_MMBTU,
                include_replacements=False, replacement_fraction=1.0,
                pv_life=30, wind_life=25, bess_life=15, generator_life=25, grid_life=40,
                connection_costs={}, bess_fade_per_year=0.0, export_enabled=False, export_limit_mw=0.0, export_price=0.0,
                tech_constraints=dict(enabled=False, units={}),
                battery_regularization_cash=True, bess_throughput_cost=0.0,
                technology_parameters={key: dict(value) for key, value in TECH.items()})


class Matrix:
    def __init__(self, columns):
        self.columns = columns
        self.r, self.c, self.v, self.lo, self.hi = [], [], [], [], []
        self.rows = 0

    def add(self, terms, lower, upper):
        n = max(np.size(lower), np.size(upper), *(np.size(col) for col, _ in terms))
        ids = np.arange(self.rows, self.rows + n)
        for col, value in terms:
            self.r.append(ids)
            self.c.append(np.broadcast_to(col, (n,)).astype(np.int32))
            self.v.append(np.broadcast_to(value, (n,)))
        self.lo.append(np.broadcast_to(lower, (n,)))
        self.hi.append(np.broadcast_to(upper, (n,)))
        self.rows += n

    def csr(self):
        return coo_matrix((np.concatenate(self.v),
                           (np.concatenate(self.r), np.concatenate(self.c))),
                          shape=(self.rows, self.columns)).tocsr()


def dispatch_grid_peak(data, dispatch, settings):
    if settings.get("islanded"):
        return np.zeros_like(data["load"])
    margin = data["qmax"] - data["load"]
    if settings["allow_unserved"]:
        fraction = np.divide(dispatch.get("shortfall", np.zeros_like(data["load"])), data["load"],
                             out=np.zeros_like(data["load"]), where=data["load"] > 0)
        margin = margin * (1 - fraction)
    return np.maximum(dispatch["grid"] + margin - dispatch.get("peak_only_shortfall", 0), 0)


def economics(data, caps, dispatch, tech_name, reference, settings=None):
    cfg = default_settings() if settings is None else settings
    names = tech_name if isinstance(tech_name, list) else [tech_name]
    tech = cfg["technology_parameters"][names[0]]
    def generator_capacity(name):
        return caps.get("generators_mw", {}).get(name, caps["generator_mw"] if len(names) == 1 else 0)
    def generated(name, selection):
        return float(dispatch.get("gen_" + name, dispatch["gen"] if len(names) == 1 else
                                  np.zeros_like(data["load"]))[selection].sum())
    eta = math.sqrt(cfg["round_trip_efficiency"])
    inflation, discount = 1 + cfg["inflation"], 1 + cfg["discount"]
    pv_capex = caps["pv_dc_mw"] * cfg["pv_capex"]
    battery_capex = caps["bess_mw"] * cfg["bess_power_capex"] + caps["bess_mwh"] * cfg["bess_energy_capex"]
    gen_capex = sum(generator_capacity(name) * cfg["technology_parameters"][name]["capex"] for name in names)
    startup = caps["bess_mwh"] * 0.5 / eta * float(data["grid_energy"][0])
    capex = pv_capex + battery_capex + gen_capex + startup
    connections = network_topology.installed_costs(cfg, caps, reference)
    connection_capex = sum(connections.values())
    capex += connection_capex
    annual = []
    grid_peak = dispatch_grid_peak(data, dispatch, cfg)
    horizon = int(data["years"].max()) + 1
    decision = upgrade_decision(cfg, grid_peak, data["years"], reference)
    upgrade_cost = decision["cost"]
    replacement_events = lifecycle_costs.schedule(caps, cfg, horizon, reference, upgrade_cost=upgrade_cost)
    start_year = data["dates"][0].year
    for yi in range(horizon):
        s = data["years"] == yi
        escalator = inflation**(yi + 1)
        demand = 0
        fixed = 0
        for month in range(12):
            mi = yi * 12 + month
            sel = data["mi"] == mi
            if not sel.any():
                continue
            on = sel & data["peak_window"]
            monthly_peak = float(grid_peak[sel].max())
            tou_peak = float(grid_peak[on].max()) if np.any(on) else 0
            demand += monthly_peak * data["facility"][mi] + tou_peak * data["tou"][mi]
            fixed += data["fixed"][mi]
        grid = float(dispatch["grid"][s] @ data["grid_energy"][s]) + demand + fixed
        if "export" in dispatch:
            grid -= float(dispatch["export"][s].sum()) * cfg["export_price"]
        fom = caps["pv_dc_mw"] * cfg["pv_fom"] + cfg["bess_fom_fraction"] * battery_capex + sum(
            generator_capacity(name) * cfg["technology_parameters"][name]["fom"] for name in names)
        fuel = sum(generated(name, s) * cfg["technology_parameters"][name]["fuel"] for name in names)
        variable = sum(generated(name, s) * cfg["technology_parameters"][name]["vom"] for name in names)
        for name, spec in ((cfg.get("tech_constraints") or {}).get("units") or {}).items():
            if (cfg.get("tech_constraints") or {}).get("enabled") and "start_" + name in dispatch:
                variable += float(dispatch["start_" + name][s].sum()) * spec["startup"]
        if cfg["battery_regularization_cash"] or bess_throughput_is_cash(cfg, reference):
            variable += float(dispatch["discharge"][s].sum()) * bess_throughput_rate(cfg, reference)
        carbon = sum(generated(name, s) * cfg["technology_parameters"][name]["carbon"] for name in names)
        heat_credit = float(dispatch["heat"][s].sum()) * cfg["boiler_credit"]
        upgrade_om = upgrade_cost * cfg["upgrade_fom_fraction"]
        row = dict(year=start_year + yi, grid=grid * escalator, fom=fom * escalator,
                   fuel=fuel * escalator, variable=variable * escalator,
                   carbon=carbon * escalator, heat_credit=heat_credit * escalator,
                   upgrade_om=upgrade_om * escalator)
        row["net_opex"] = sum(row[key] for key in ["grid", "fom", "fuel", "variable", "carbon", "upgrade_om"]) - row["heat_credit"]
        row["replacement"] = replacement_events.get(yi + 1, 0)
        row["total_cash_cost"] = row["net_opex"] + row["replacement"]
        row["discounted_opex"] = row["net_opex"] / discount**(yi + 1)
        row["demand_mwh"] = float(data.get("service_load", data["load"])[s].sum())
        row["grid_mwh"] = float(dispatch["grid"][s].sum())
        row["pv_mwh"] = float(dispatch["pv"][s].sum())
        row["gen_mwh"] = float(dispatch["gen"][s].sum())
        row["bess_discharge_mwh"] = float(dispatch["discharge"][s].sum())
        row["bess_charge_mwh"] = float(dispatch.get("charge", np.zeros_like(data["load"]))[s].sum())
        row["heat_mwh"] = float(dispatch["heat"][s].sum())
        row["grid_peak_mw"] = float(grid_peak[s].max())
        row["forecast_peak_mw"] = float(data["qmax"][s].max())
        row["direct_gen_co2_t"] = sum(generated(name, s) * MMBTU_PER_MWH / cfg[
            "ng_chp_efficiency" if name == "ng_chp" else "ng_turbine_efficiency"] * CO2_PER_MMBTU
            for name in names if name.startswith("ng")) * cfg.get("ng_emissions_t_mmbtu", CO2_PER_MMBTU) / CO2_PER_MMBTU
        row["direct_gen_co2_t"] += sum(generated(name, s) * cfg["technology_parameters"][name]["emissions_t_mwh"]
                                       for name in names if name in ("diesel", "biogas", "biomass"))
        row["avoided_boiler_co2_t"] = row["heat_mwh"] * cfg["boiler_emissions_t_mwhth"]
        row["grid_co2_t"] = row["grid_mwh"] * cfg["grid_emissions_t_mwh"] if cfg["emission_factors_confirmed"] else None
        row["hydrogen_upstream_co2e_t"] = sum(
            generated(name, s) / (33.33 * cfg.get(
                "h2_chp_efficiency" if name == "h2_chp" else "h2_efficiency", .35)) *
            cfg["h2_emissions_kgco2_kg"] for name in names if name.startswith("h2"))
        for name in names:
            if name != "none":
                row[name + "_generation_mwh"] = generated(name, s)
        if cfg["emission_factors_confirmed"]:
            solar_energy = float(dispatch.get("solar_output", np.zeros_like(data["load"]))[s].sum())
            planned_solar = float((data.get("planned_solar_direct", np.zeros_like(data["load"]))[s] +
                                  dispatch.get("planned_solar_used", np.zeros_like(data["load"]))[s]).sum())
            planned_wind = float((data.get("planned_wind_direct", np.zeros_like(data["load"]))[s] +
                                 dispatch.get("planned_wind_used", np.zeros_like(data["load"]))[s]).sum())
            row["solar_operational_co2e_t"] = (solar_energy + planned_solar) * cfg["pv_emissions_t_mwh"]
            row["wind_operational_co2e_t"] = (planned_wind + float(
                dispatch.get("gen_wind", np.zeros_like(data["load"]))[s].sum())) * cfg["wind_emissions_t_mwh"]
            row["bess_operational_co2e_t"] = row["bess_discharge_mwh"] * cfg["bess_emissions_t_mwh"]
            row["supply_co2e_t"] = (row["grid_co2_t"] + row["direct_gen_co2_t"] +
                                   row["hydrogen_upstream_co2e_t"] + row["solar_operational_co2e_t"] +
                                   row["wind_operational_co2e_t"] + row["bess_operational_co2e_t"])
            row["net_co2e_after_heat_credit_t"] = row["supply_co2e_t"] - row["avoided_boiler_co2_t"]
        else:
            row["hydrogen_upstream_co2e_t"] = None
            row["supply_co2e_t"] = row["net_co2e_after_heat_credit_t"] = None
        shortfall = np.maximum(dispatch.get("shortfall", np.zeros_like(data["load"]))[s], 0)
        peak_only = np.maximum(dispatch.get("peak_only_shortfall", np.zeros_like(data["load"]))[s], 0)
        row["peak_only_unserved_mwh"] = float(peak_only.sum()) * .25
        row["unserved_mwh"] = float(shortfall.sum()) + row["peak_only_unserved_mwh"]
        row["unserved_hours"] = int(np.count_nonzero(np.maximum(shortfall, peak_only) > 5e-5))
        row["peak_unserved_mw"] = float(np.maximum(shortfall, peak_only).max())
        row["served_mwh"] = row["demand_mwh"] - row["unserved_mwh"]
        row["gross_demand_mwh"] = float(data.get("gross_load", data["load"])[s].sum())
        row["efficiency_saved_mwh"] = float(data.get("efficiency_reduction", np.zeros_like(data["load"]))[s].sum())
        annual.append(row)
    def present(key):
        return sum(row[key] / discount**(i + 1) for i, row in enumerate(annual))
    upgrade = upgrade_cost
    npc = capex + upgrade + present("total_cash_cost")
    residual = lifecycle_costs.residual_value(caps, cfg, horizon, upgrade) / discount**horizon
    energy_pv = sum(row["served_mwh"] / discount**(i + 1) for i, row in enumerate(annual))
    retail_exposure = sum(row["grid_mwh"] * inflation**(i + 1) / discount**(i + 1) for i, row in enumerate(annual))
    return dict(capex=capex, pv_capex=pv_capex, bess_capex=battery_capex,
                connection_capex=connection_capex, connection_cost_by_technology=connections,
                gen_capex=gen_capex, upgrade_pv=upgrade, upgrade_required=decision["required"],
                upgrade_capacity_mw=decision["capacity_mw"], upgrade_needed_import_mw=decision["needed_mw"],
                upgrade_first_year=(None if decision["first_year_index"] is None else
                                    start_year + decision["first_year_index"]),
                upgrade_note=decision["note"], grid_pv=present("grid"),
                fixed_om_pv=present("fom"), fuel_pv=present("fuel"),
                variable_om_pv=present("variable"), carbon_pv=present("carbon"),
                heat_credit_pv=present("heat_credit"), upgrade_om_pv=present("upgrade_om"),
                replacement_pv=present("replacement"),
                npc=npc, nominal_total=capex + upgrade + sum(row["total_cash_cost"] for row in annual),
                residual_value_pv=residual, npc_with_residual=npc - residual,
                npc_zero_heat_credit=npc + present("heat_credit"),
                npc_retail_40=npc - 40 * retail_exposure,
                npc_retail_120=npc + 40 * retail_exposure,
                unserved_mwh=sum(row["unserved_mwh"] for row in annual),
                unserved_hours=sum(row["unserved_hours"] for row in annual),
                peak_unserved_mw=max(row["peak_unserved_mw"] for row in annual),
                served_fraction=1 - sum(row["unserved_mwh"] for row in annual) /
                max(float(data.get("service_load", data["load"]).sum()), 1e-12),
                levelized_supply_cost_usd_mwh=npc / energy_pv if energy_pv > 1e-6 else None, annual=annual)


class InfeasibleRecourse(RuntimeError):
    def __init__(self, value, gradient):
        super().__init__("Trial capacities cannot meet the annual emissions constraint.")
        self.value, self.gradient = value, gradient


class MonthlyDispatch:
    """LP recourse with fixed capacities; dual prices generate exact master cuts."""

    def __init__(self, data, month, tech_name, reference, solar, feasibility_only=False,
                 settings=None, period_months=None):
        cfg = default_settings() if settings is None else settings
        self.cfg = cfg
        eta = math.sqrt(cfg["round_trip_efficiency"])
        period_months = [month] if period_months is None else period_months
        self.sel = np.flatnonzero(np.isin(data["mi"], period_months))
        if not len(self.sel):
            raise ValueError("Dispatch block contains no hours.")
        self.names = tech_name if isinstance(tech_name, list) else [tech_name]
        self.ncap = 3 + len(self.names)
        self.planned = np.array([0.0,
            float(data.get("planned_bess_mw", np.zeros(len(data["load"])))[self.sel[0]]),
            float(data.get("planned_bess_mwh", np.zeros(len(data["load"])))[self.sel[0]])] + [0.0] * len(self.names))
        self.generators = [name for name in self.names if name != "none"]
        self.heaters = [name for name in self.generators if cfg["technology_parameters"][name]["ratio"] > 0]
        tc = cfg.get("tech_constraints") or {}
        self.constrained = [g for g in self.generators if g != "wind" and tc.get("enabled") and g in tc.get("units", {})]
        self.export_on = bool(cfg.get("export_enabled"))
        n = len(self.sel)
        idx, k = {}, self.ncap
        split_resources = data.get("planned_netted", False)
        for field in ["grid", "pv", "charge", "discharge", "soc", "shortfall", "peak_only_shortfall"] + (
                ["solar_output", "planned_solar_used", "planned_wind_used"] if split_resources else []) + (
                ["gen_" + name for name in self.generators]) + (["heat_" + name for name in self.heaters]) + (
                ["commit_" + name for name in self.constrained]) + (
                ["start_" + name for name in self.constrained]) + (["export"] if self.export_on else []) + (
                ["battery_reserve"] if cfg.get("islanded") else []):
            idx[field] = np.arange(k, k + n)
            k += n
        self.idx = idx
        peaks = np.arange(k, k + len(period_months))
        tous = np.arange(k + len(period_months), k + 2 * len(period_months))
        k += 2 * len(period_months)
        self.emission_slack = k if cfg.get("emissions_limit_enabled") else None
        if self.emission_slack is not None:
            k += 1
        month_indices = np.array([period_months.index(int(mi)) for mi in data["mi"][self.sel]])
        peak, tou = peaks[month_indices], tous[month_indices]
        load = data["load"][self.sel]
        margin = data["qmax"][self.sel] - load
        reserve_margin = margin.copy()
        if cfg.get("islanded"):
            margin = np.zeros(n)
        costs = np.zeros(k)
        lower = np.zeros(k)
        upper = np.full(k, highspy.kHighsInf)
        if self.emission_slack is not None:
            upper[self.emission_slack] = 0
        lower[idx["grid"]] = load - data["qmin"][self.sel]
        upper[idx["grid"]] = cfg["reference_grid_limit" if reference else "grid_limit"] - margin
        if cfg["allow_unserved"]:
            lower[idx["grid"]] = 0
            upper[idx["grid"]] = highspy.kHighsInf
            upper[idx["shortfall"]] = 0 if reference else load
        yi = month // 12
        weight = (1 + cfg["inflation"])**(yi + 1) / (1 + cfg["discount"])**(yi + 1)
        costs[idx["grid"]] = weight * data["grid_energy"][self.sel] / 1e6
        costs[idx["discharge"]] = weight * bess_throughput_rate(cfg, reference) / 1e6
        # Penalized recourse exists at every trial capacity; final shortfall must be zero.
        costs[idx["shortfall"]] = cfg["shortfall_priority_usd_mwh"] / 1e6
        upper[idx["peak_only_shortfall"]] = np.where(
            (load == 0) & cfg["allow_unserved"] & (not reference), reserve_margin, 0)
        costs[idx["peak_only_shortfall"]] = cfg["shortfall_priority_usd_mwh"] * .25 / 1e6
        for name in self.generators:
            spec = cfg["technology_parameters"][name]
            costs[idx["gen_" + name]] = weight * (spec["fuel"] + spec["carbon"] + spec["vom"]) / 1e6
        for name in self.heaters:
            costs[idx["heat_" + name]] = -weight * cfg["boiler_credit"] / 1e6
            upper[idx["heat_" + name]] = data["heat"][self.sel]
        for name in self.constrained:
            costs[idx["start_" + name]] = weight * tc["units"][name]["startup"] / 1e6
        if self.export_on:
            upper[idx["export"]] = cfg["export_limit_mw"]
            costs[idx["export"]] = -weight * cfg["export_price"] / 1e6
        costs[peaks] = weight * data["facility"][period_months] / 1e6
        costs[tous] = weight * data["tou"][period_months] / 1e6
        if feasibility_only:
            costs[:] = 0
            costs[idx["shortfall"]] = cfg["shortfall_priority_usd_mwh"] / 1e6
            costs[idx["peak_only_shortfall"]] = cfg["shortfall_priority_usd_mwh"] * .25 / 1e6
        matrix = Matrix(k)
        terms = [(idx["grid"], 1), (idx["pv"], 1), (idx["discharge"], 1),
                 (idx["charge"], -1), (idx["shortfall"], 1)]
        for name in self.generators:
            terms.append((idx["gen_" + name], 1))
        if self.export_on:
            terms.append((idx["export"], -1))
        matrix.add(terms, load, load)
        fraction_margin = np.zeros(n)
        if cfg["allow_unserved"]:
            # Unserved demand is proportional to the observed within-hour shape.
            fraction_margin = np.divide(margin, load, out=np.zeros(n), where=load > 0)
            lower_margin = np.zeros(n) if cfg.get("islanded") else load - data["qmin"][self.sel]
            lower_ratio = np.divide(lower_margin, load, out=np.zeros(n), where=load > 0)
            limit = cfg["reference_grid_limit" if reference else "grid_limit"]
            matrix.add([(idx["grid"], 1), (idx["shortfall"], -fraction_margin),
                        (idx["peak_only_shortfall"], -1)],
                       -highspy.kHighsInf, limit - margin)
            matrix.add([(idx["grid"], 1), (idx["shortfall"], lower_ratio)],
                       lower_margin, highspy.kHighsInf)
        if data.get("planned_netted", False):
            planned_solar = np.zeros(n)
            planned_wind = data["planned_surplus"][self.sel]
        elif "planned_solar_available" in data:
            resource_ratio = np.divide(solar[self.sel], data["solar"][self.sel],
                                       out=np.zeros(n), where=data["solar"][self.sel] > 0)
            planned_solar = data["planned_solar_available"][self.sel] * resource_ratio
            planned_wind = data.get("planned_wind", np.zeros(len(data["load"])))[self.sel]
        else:
            planned_solar = data.get("planned_solar_mw", np.zeros(len(data["load"])))[self.sel] * solar[self.sel]
            planned_wind = data.get("planned_wind", np.zeros(len(data["load"])))[self.sel]
        if split_resources:
            matrix.add([(idx["solar_output"], 1), (0, -solar[self.sel])], -highspy.kHighsInf, 0)
            upper[idx["planned_solar_used"]] = data["planned_solar_surplus"][self.sel]
            upper[idx["planned_wind_used"]] = data["planned_wind_surplus"][self.sel]
            matrix.add([(idx["pv"], 1), (idx["solar_output"], -1),
                        (idx["planned_solar_used"], -1), (idx["planned_wind_used"], -1)], 0, 0)
        else:
            matrix.add([(idx["pv"], 1), (0, -solar[self.sel])], -highspy.kHighsInf, planned_solar + planned_wind)
        matrix.add([(idx["charge"], 1), (1, -1)], -highspy.kHighsInf, 0)
        matrix.add([(idx["discharge"], 1), (1, -1)], -highspy.kHighsInf, 0)
        age = yi % int(cfg["bess_life"]) if cfg.get("include_replacements") else yi
        health = max(1 - cfg.get("bess_fade_per_year", 0.0) * age, .5)
        matrix.add([(idx["soc"], 1), (2, -cfg["soc_max"] * health)], -highspy.kHighsInf, 0)
        matrix.add([(idx["soc"], -1), (2, cfg["soc_min"] * health)], -highspy.kHighsInf, 0)
        previous = np.roll(idx["soc"], 1)
        coeff = np.full(n, -1.0)
        openings = np.r_[True, np.diff(data["mi"][self.sel]) != 0]
        closings = np.r_[np.diff(data["mi"][self.sel]) != 0, True]
        previous[openings], coeff[openings] = 2, -0.5
        matrix.add([(idx["soc"], 1), (previous, coeff),
                    (idx["charge"], -eta), (idx["discharge"], 1 / eta)], 0, 0)
        matrix.add([(idx["soc"][closings], 1), (2, -0.5)], 0, 0)
        for name in self.generators:
            availability = data["wind"][self.sel] if name == "wind" else 1
            matrix.add([(idx["gen_" + name], 1), (3 + self.names.index(name), -availability)], -highspy.kHighsInf, 0)
        links = ~openings
        for name in self.constrained:
            spec, col = tc["units"][name], 3 + self.names.index(name)
            gen, u, st = idx["gen_" + name], idx["commit_" + name], idx["start_" + name]
            ramp = spec["ramp"]
            matrix.add([(u, 1), (col, -1)], -highspy.kHighsInf, 0)
            matrix.add([(gen, 1), (u, -1)], -highspy.kHighsInf, 0)
            matrix.add([(gen, 1), (u, -spec["min_load"])], 0, highspy.kHighsInf)
            if links.any():
                matrix.add([(st[links], 1), (u[links], -1), (u[np.flatnonzero(links) - 1], 1)], 0, highspy.kHighsInf)
                prev = np.flatnonzero(links) - 1
                if ramp < 1:
                    matrix.add([(gen[links], 1), (gen[prev], -1), (col, -ramp), (st[links], -1)], -highspy.kHighsInf, 0)
                    matrix.add([(gen[prev], 1), (gen[links], -1), (col, -ramp), (u[prev], -1), (u[links], 1),
                                (st[links], -1)], -highspy.kHighsInf, 0)
        if self.export_on:
            matrix.add([(idx["export"], 1), (idx["pv"], -1)] + [(idx["gen_" + name], -1) for name in self.generators],
                       -highspy.kHighsInf, 0)
        if cfg.get("islanded"):
            reserve = idx["battery_reserve"]
            matrix.add([(reserve, 1), (idx["discharge"], 1), (1, -1)], -highspy.kHighsInf, 0)
            matrix.add([(reserve, .25 / eta), (idx["soc"], -1), (2, cfg["soc_min"])],
                       -highspy.kHighsInf, 0)
            ratio = np.divide(reserve_margin, load, out=np.zeros(n), where=load > 0)
            terms = [(reserve, -1), (idx["shortfall"], -ratio), (idx["peak_only_shortfall"], -1)]
            for name in self.generators:
                if name != "wind":
                    terms.extend([(idx["gen_" + name], 1), (3 + self.names.index(name), -1)])
            matrix.add(terms, -highspy.kHighsInf, -reserve_margin)
        for name in self.heaters:
            matrix.add([(idx["heat_" + name], 1), (idx["gen_" + name],
                -cfg["technology_parameters"][name]["ratio"])], -highspy.kHighsInf, 0)
        if self.heaters:
            matrix.add([(idx["heat_" + name], 1) for name in self.heaters],
                       -highspy.kHighsInf, data["heat"][self.sel])
        matrix.add([(idx["grid"], 1), (idx["shortfall"], -fraction_margin),
                    (idx["peak_only_shortfall"], -1), (peak, -1)], -highspy.kHighsInf, -margin)
        on = data["peak_window"][self.sel]
        matrix.add([(idx["grid"][on], 1), (idx["shortfall"][on], -fraction_margin[on]),
                    (idx["peak_only_shortfall"][on], -1), (tou[on], -1)], -highspy.kHighsInf, -margin[on])
        if cfg.get("emissions_limit_enabled"):
            if len(set(data["years"][self.sel])) != 1 or len(period_months) != 12:
                raise ValueError("Annual emissions constraints require one complete annual dispatch block.")
            indices = list(idx["grid"])
            coefficients = [cfg["grid_emissions_t_mwh"]] * n
            for name in self.generators:
                indices.extend(idx["gen_" + name])
                coefficients.extend([cfg["technology_parameters"][name]["emissions_t_mwh"]] * n)
            for name in self.heaters:
                indices.extend(idx["heat_" + name])
                coefficients.extend([-cfg["boiler_emissions_t_mwhth"]] * n)
            for field, factor in (("discharge", cfg["bess_emissions_t_mwh"]),
                                  ("pv", cfg["pv_emissions_t_mwh"] if not split_resources else 0),
                                  ("solar_output", cfg["pv_emissions_t_mwh"]),
                                  ("planned_solar_used", cfg["pv_emissions_t_mwh"]),
                                  ("planned_wind_used", cfg["wind_emissions_t_mwh"])):
                if field in idx:
                    indices.extend(idx[field])
                    coefficients.extend([factor] * n)
            direct = float((data.get("planned_solar_direct", np.zeros(len(data["load"])))[self.sel] *
                            cfg["pv_emissions_t_mwh"] +
                            data.get("planned_wind_direct", np.zeros(len(data["load"])))[self.sel] *
                            cfg["wind_emissions_t_mwh"]).sum())
            indices.append(self.emission_slack)
            coefficients.append(-1)
            matrix.r.append(np.full(len(indices), matrix.rows))
            matrix.c.append(np.array(indices))
            matrix.v.append(np.array(coefficients))
            matrix.lo.append(np.array([-highspy.kHighsInf]))
            matrix.hi.append(np.array([cfg["emissions_limit_t_year"] - direct]))
            matrix.rows += 1
        day_ids = data["di"][self.sel] - data["di"][self.sel][0]
        day_count = int(day_ids.max() + 1)
        day_rows = np.arange(matrix.rows, matrix.rows + day_count)
        matrix.r.extend([day_rows[day_ids], day_rows])
        matrix.c.extend([idx["discharge"], np.full(day_count, 2)])
        matrix.v.extend([np.ones(n), np.full(day_count, -(cfg["soc_max"] - cfg["soc_min"]) * eta * cfg["daily_cycles"] * health)])
        matrix.lo.append(np.full(day_count, -highspy.kHighsInf))
        matrix.hi.append(np.zeros(day_count))
        matrix.rows += day_count
        csr = matrix.csr()
        self.matrix = csr
        self.row_lo, self.row_hi = np.concatenate(matrix.lo), np.concatenate(matrix.hi)
        self.lower, self.upper = lower, upper
        self.backend, _ = solver_backend.resolve(cfg)
        self.h = solver_backend.make_lp(self.backend)
        self.h.setOptionValue("output_flag", False)
        self.h.setOptionValue("threads", 4)
        _, dispatch_solver, _ = solver_choice(cfg)
        self.h.setOptionValue("solver", dispatch_solver)
        if dispatch_solver == "simplex":
            self.h.setOptionValue("simplex_strategy", 1)
        self.h.setOptionValue("run_crossover", "on")
        self.h.setOptionValue("ipm_optimality_tolerance", 1e-10)
        self.h.setOptionValue("dual_feasibility_tolerance", 1e-10)
        self.h.setOptionValue("primal_feasibility_tolerance", 1e-8)
        # Keep the cycling tie-break above solver tolerances, including at zero energy prices.
        self.cost_scale = 1000.0
        self.scaled_costs = costs * self.cost_scale
        self.h.addCols(k, costs * self.cost_scale, lower, upper, 0, np.zeros(k + 1, dtype=np.int32),
                       np.array([], dtype=np.int32), np.array([], dtype=float))
        self.h.addRows(csr.shape[0], self.row_lo, self.row_hi, csr.nnz,
                       csr.indptr.astype(np.int32), csr.indices.astype(np.int32), csr.data)

    def evaluate(self, capacities):
        effective = capacities + self.planned
        self.h.changeColsBounds(self.ncap, np.arange(self.ncap, dtype=np.int32), effective, effective)
        self.h.run()
        if self.h.getModelStatus() in (highspy.HighsModelStatus.kSolveError, highspy.HighsModelStatus.kUnknown,
                                       highspy.HighsModelStatus.kNotset):
            # A warm basis from the previous trial can be numerically unusable (the huge shortage priority
            # spans ~9 orders of magnitude); retry cold with progressively more conservative settings.
            _, dispatch_solver, _ = solver_choice(self.cfg)
            for options in (dict(solver=dispatch_solver), dict(solver="simplex", presolve="off"), dict(solver="ipm")):
                self.h.clearSolver()
                for key, value in options.items():
                    self.h.setOptionValue(key, value)
                self.h.run()
                if self.h.getModelStatus() == highspy.HighsModelStatus.kOptimal:
                    break
            self.h.setOptionValue("presolve", "choose")
            self.h.setOptionValue("solver", dispatch_solver)
        if self.h.getModelStatus() != highspy.HighsModelStatus.kOptimal:
            if (self.emission_slack is not None and
                    self.h.getModelStatus() == highspy.HighsModelStatus.kInfeasible):
                # Phase I is used only to derive a feasibility cut, never as accepted dispatch.
                columns = np.arange(len(self.scaled_costs), dtype=np.int32)
                phase_costs = np.zeros(len(columns))
                phase_costs[self.emission_slack] = 1
                self.h.changeColBounds(self.emission_slack, 0, highspy.kHighsInf)
                self.h.changeColsCost(len(columns), columns, phase_costs)
                self.h.run()
                if self.h.getModelStatus() == highspy.HighsModelStatus.kOptimal:
                    value = self.h.getObjectiveValue()
                    gradient = np.array(self.h.getSolution().col_dual[:self.ncap])
                    self.h.changeColsCost(len(columns), columns, self.scaled_costs)
                    self.h.changeColBounds(self.emission_slack, 0, 0)
                    raise InfeasibleRecourse(value, gradient)
                self.h.changeColsCost(len(columns), columns, self.scaled_costs)
                self.h.changeColBounds(self.emission_slack, 0, 0)
            raise RuntimeError(f"Monthly LP did not solve: {self.h.modelStatusToString(self.h.getModelStatus())}")
        solution = self.h.getSolution()
        self.values = np.array(solution.col_value)
        return (self.h.getObjectiveValue() / self.cost_scale,
                np.array(solution.col_dual[:self.ncap]) / self.cost_scale)

    def operation(self):
        result = {field: self.values[ids].copy() for field, ids in self.idx.items()}
        result["gen"] = sum((result["gen_" + name] for name in self.generators), np.zeros(len(self.sel)))
        result["heat"] = sum((result["heat_" + name] for name in self.heaters), np.zeros(len(self.sel)))
        return result


def solve_decomposed(data, code, name, tech_name, force=False, reference=False,
                     fixed_caps=None, solar_stress=False, require_stress=False,
                     settings=None):
    started = time.time()
    cfg = default_settings() if settings is None else dict(settings)
    solver_label, dispatch_solver, master_solver = solver_choice(cfg)
    solver_info = solver_backend.solver_info(cfg)
    if reference and cfg["grid_only_reference"]:
        cfg["reference_pv"] = 0.0
        cfg.setdefault("reference_grid_limit_input", cfg["reference_grid_limit"])
        cfg["reference_grid_limit"] = max(cfg["reference_grid_limit"], float(data["qmax"].max()))
    horizon = int(data["years"].max()) + 1
    month_count = horizon * 12
    names = tech_name if isinstance(tech_name, list) else [tech_name]
    if "wind" in names:
        if "wind" not in data or len(data["wind"]) != len(data["load"]) or not np.all(np.isfinite(data["wind"])) or np.any((data["wind"] < 0) | (data["wind"] > 1)):
            raise ValueError("Wind scenarios require a finite hourly wind_per_mw profile in [0,1].")
    ncap = 3 + len(names)
    factor = sum((1 + cfg["inflation"])**(y + 1) / (1 + cfg["discount"])**(y + 1) for y in range(horizon))
    cap_costs = np.array([lifecycle_costs.coefficient(cfg["pv_capex"], cfg["pv_life"], cfg, horizon) + cfg["pv_fom"] * factor,
                         lifecycle_costs.coefficient(cfg["bess_power_capex"], cfg["bess_life"], cfg, horizon) +
                         cfg["bess_power_capex"] * cfg["bess_fom_fraction"] * factor,
                         lifecycle_costs.coefficient(cfg["bess_energy_capex"], cfg["bess_life"], cfg, horizon) +
                         cfg["bess_energy_capex"] * cfg["bess_fom_fraction"] * factor +
                         0.5 / math.sqrt(cfg["round_trip_efficiency"]) * data["grid_energy"][0],
                         *[lifecycle_costs.coefficient(cfg["technology_parameters"][name]["capex"],
                                                      cfg["wind_life"] if name == "wind" else cfg["generator_life"], cfg, horizon) +
                           cfg["technology_parameters"][name]["fom"] * factor for name in names]]) / 1e6
    bounds = [(cfg["reference_pv"] if reference else cfg["pv_min"],
               cfg["reference_pv"] if reference else cfg["pv_max"]),
              (0, 0 if reference else cfg["bess_power_max"]),
              (0, 0 if reference else cfg["bess_energy_max"])] + [
              (cfg["forced_generator_min"] if force and name != "none" else 0,
               0 if name == "none" or reference else cfg.get("wind_max", cfg["generator_max"])
               if name == "wind" else cfg["generator_max"]) for name in names]
    if reference:
        bounds[3] = (0, 0)
    solar = data["solar"].copy()
    if solar_stress:
        sel = np.flatnonzero(data["years"] == horizon - 1)
        center = sel[np.argmax(data["qmax"][sel])]
        start = max(sel[0], center - 36)
        solar[start:start + 72] = 0
    if cfg.get("emissions_limit_enabled") and (require_stress or solar_stress):
        raise ValueError("Annual emissions limits cannot be combined with legacy solar-stress blocks.")
    present_months = set(np.unique(data["mi"]).tolist())
    blocks = ([[m for m in range(yi * 12, (yi + 1) * 12) if m in present_months] for yi in range(horizon)]
              if cfg.get("emissions_limit_enabled") else
              [[month] for month in range(month_count) if month in present_months])
    normal_count = len(blocks)
    subproblems = [MonthlyDispatch(data, months[0], tech_name, reference, solar,
                                   settings=cfg, period_months=months) for months in blocks]
    if require_stress:
        stressed_solar = solar.copy()
        last = np.flatnonzero(data["years"] == horizon - 1)
        center = last[np.argmax(data["qmax"][last])]
        start = max(last[0], center - 36)
        stressed_solar[start:start + 72] = 0
        for month in np.unique(data["mi"][start:start + 72]):
            subproblems.append(MonthlyDispatch(data, int(month), tech_name, reference,
                                              stressed_solar, feasibility_only=True, settings=cfg))
    owners = ["pv", "bess", "bess_energy"] + names
    connection_charges = np.array([cfg.get("connection_costs", {}).get(owner, 0) if owner != "bess_energy" and
                                   bounds[i][1] != 0 else 0 for i, owner in enumerate(owners)]) / 1e6
    connected = np.flatnonzero(connection_charges > 0)
    if len(connected) and (cfg["microgrid_max_mw"] is None or cfg["microgrid_max_mw"] <= 0):
        raise ValueError("Conditional connection costs require a positive finite maximum microgrid capacity.")
    nmaster = ncap + len(subproblems) + len(connected)
    recourse_bounds = [
        (-(float(data["heat"][sub.sel].sum()) * cfg["boiler_credit"] +
           (len(sub.sel) * cfg["export_limit_mw"] * max(cfg["export_price"], 0.0) if cfg.get("export_enabled") else 0.0)) *
         (1 + cfg["inflation"])**(month // 12 + 1) /
         (1 + cfg["discount"])**(month // 12 + 1) / 1e6, None)
        for month, sub in ((blocks[i][0], sub) for i, sub in enumerate(subproblems[:normal_count]))]
    recourse_bounds += [(0, None if cfg["allow_unserved"] else 0)] * (len(subproblems) - normal_count)
    cuts, rhs = [], []
    for coefficients in ([0, cfg["duration_min"], -1, 0], [0, -cfg["duration_max"], 1, 0]):
        row = np.zeros(nmaster)
        row[:4] = coefficients
        cuts.append(row)
        rhs.append(0.0)
    if not reference and cfg["bess_land_acres"] is not None:
        row = np.zeros(nmaster)
        row[1], row[2] = cfg["bess_acres_per_mw"], cfg["bess_acres_per_mwh"]
        cuts.append(row)
        rhs.append(cfg["bess_land_acres"])
    if not reference and (cfg["microgrid_max_mw"] is not None or cfg["microgrid_min_mw"] > 0):
        row = np.zeros(nmaster)
        row[:ncap] = [1 / cfg["dc_ac"], 1, 0] + [1] * len(names)
        if cfg["microgrid_max_mw"] is not None:
            cuts.append(row)
            rhs.append(cfg["microgrid_max_mw"])
        cuts.append(-row)
        rhs.append(-cfg["microgrid_min_mw"])
    for offset, index in enumerate(connected):
        # Capacity indicator: the PV column is DC MW and may reach dc_ac times the AC microgrid limit.
        big_m = cfg["microgrid_max_mw"] * (cfg["dc_ac"] if index == 0 else 1)
        row = np.zeros(nmaster)
        row[index], row[ncap + len(subproblems) + offset] = 1, -big_m
        cuts.append(row)
        rhs.append(0.0)
    caps = np.array([8 if reference else 10, 0 if reference else 12,
                     0 if reference else 72] + [5 if force else 0] * len(names), dtype=float)
    if settings is not None and fixed_caps is None:
        initial = linprog(cap_costs, A_ub=np.array(cuts[:-len(connected)] if len(connected) else cuts)[:, :ncap],
                          b_ub=np.array(rhs[:-len(connected)] if len(connected) else rhs), bounds=bounds, method=master_solver,
                          options={"dual_feasibility_tolerance": 1e-10, "ipm_optimality_tolerance": 1e-10})
        if not initial.success:
            raise ValueError(f"{code}: the capacity limits are inconsistent (microgrid minimum/maximum, BESS duration, land "
                             "or per-technology maxima); no design satisfies all of them.")
        caps = initial.x
    if fixed_caps is not None:
        caps = np.array([fixed_caps[k] for k in ["pv_dc_mw", "bess_mw", "bess_mwh", "generator_mw"]])
    best, best_cap, best_ops = math.inf, None, None
    best_noise = 0.0
    gap = math.inf
    iterations = 0
    for iteration in range(150):
        iterations = iteration + 1
        values = []
        operations = []
        trial_noise = 0.0
        feasible_trial = True
        for month, sub in enumerate(subproblems):
            try:
                value, gradient = sub.evaluate(caps)
            except InfeasibleRecourse as exc:
                row = np.zeros(nmaster)
                row[:ncap] = exc.gradient
                cuts.append(row)
                rhs.append(float(exc.gradient @ caps - exc.value))
                feasible_trial = False
                continue
            # Weaken each cut by the floating-point error bound of its own evaluation so that solver noise
            # on penalty-scale values cannot push the master bound above a feasible design.
            error = 1e-10 * abs(value) + 1e-11 * float(np.abs(gradient) @ np.abs(caps))
            trial_noise += error
            values.append(value)
            operations.append(sub.operation())
            row = np.zeros(nmaster)
            row[:ncap] = gradient
            row[ncap + month] = -1
            cuts.append(row)
            rhs.append(float(gradient @ caps - value) + error)
        if feasible_trial:
            upper_bound = float(cap_costs @ caps + sum(values) + connection_charges[caps > 1e-7].sum())
            if upper_bound < best:
                best, best_cap, best_ops = upper_bound, caps.copy(), operations
                best_noise = trial_noise
        if fixed_caps is not None:
            if not feasible_trial:
                raise ValueError("Fixed capacities cannot meet the enforced annual emissions limit.")
            gap = 0
            break
        objective = np.r_[cap_costs, np.ones(len(subproblems)), connection_charges[connected]]
        master_bounds = bounds + recourse_bounds + [(0, 1)] * len(connected)
        if len(connected):
            master = milp(objective, integrality=np.r_[np.zeros(ncap + len(subproblems)), np.ones(len(connected))],
                          bounds=Bounds([lo if lo is not None else -np.inf for lo, _ in master_bounds],
                                        [hi if hi is not None else np.inf for _, hi in master_bounds]),
                          constraints=LinearConstraint(np.array(cuts), -np.inf, np.array(rhs)),
                          options={"mip_rel_gap": 1e-9})
        else:
            master = linprog(objective, A_ub=np.array(cuts), b_ub=np.array(rhs),
                             bounds=master_bounds, method=master_solver,
                             options={"dual_feasibility_tolerance": 1e-10, "ipm_optimality_tolerance": 1e-10})
        if not master.success:
            raise RuntimeError(f"Capacity master failed: {master.message}")
        gap = best - master.fun
        noise = trial_noise + best_noise
        if gap < -(1e-5 + noise):
            raise RuntimeError("Invalid dual cut: master lower bound exceeds feasible upper bound")
        # With allowed shortfall, the penalty price makes a relative tolerance meaningless; use an absolute $200 gap
        # plus the numerical error allowance of the cuts.
        if gap <= (0.0002 if cfg["allow_unserved"] else max(0.0002, 2e-6 * abs(best))) + noise:
            break
        caps = master.x[:ncap]
    else:
        raise RuntimeError(f"{code}: capacity decomposition did not converge within 150 iterations (gap ${gap:,.4f}m).")
    dispatch = {field: np.zeros(len(data["load"])) for field in
                ["grid", "pv", "charge", "discharge", "soc", "gen", "heat", "shortfall"]}
    for sub, operation in zip(subproblems[:normal_count], best_ops[:normal_count]):
        for field, values in operation.items():
            if field not in dispatch:
                dispatch[field] = np.zeros(len(data["load"]))
            dispatch[field][sub.sel] = np.where(np.abs(values) < 1e-7, 0.0, values)
    max_shortfall = float(np.maximum(dispatch["shortfall"], dispatch.get("peak_only_shortfall", 0)).max())
    if max_shortfall > 5e-5 and (not cfg["allow_unserved"] or reference):
        if solar_stress:
            return {"status": f"Infeasible for monthly-cyclic dispatch: maximum shortfall {max_shortfall:,.4f} MW"}
        raise RuntimeError(f"{code}: no design within the capacity and grid limits can serve all load (a shortfall of "
                           f"{max_shortfall:,.4f} MW remains). Raise the capacity limits or the grid import limit, or allow unserved energy.")
    best_cap = np.where(np.abs(best_cap) < 1e-7, 0.0, best_cap)
    capacities = dict(zip(["pv_dc_mw", "bess_mw", "bess_mwh"], best_cap[:3].tolist()))
    capacities["generator_mw"] = float(sum(best_cap[3:]))
    capacities["generators_mw"] = dict(zip(names, best_cap[3:].tolist()))
    capacities["microgrid_total_ac_mw"] = best_cap[0] / cfg["dc_ac"] + best_cap[1] + capacities["generator_mw"]
    margin = data["qmax"] - data["load"]
    balance_error = float(np.abs(dispatch["grid"] + dispatch["pv"] + dispatch["gen"] +
                                 dispatch["discharge"] - dispatch["charge"] +
                                 dispatch["shortfall"] - dispatch.get("export", 0) - data["load"]).max())
    simultaneous = float(np.minimum(dispatch["charge"], dispatch["discharge"]).max())
    # Reevaluate the retained best design for an independent constraint residual check.
    violation = 0.0
    for sub in subproblems:
        sub.evaluate(best_cap)
        product = sub.matrix @ sub.values
        check_simultaneous = float(np.minimum(sub.operation()["charge"], sub.operation()["discharge"]).max())
        violation = max(violation, check_simultaneous, float(np.maximum(sub.row_lo - product, 0).max()),
                        float(np.maximum(product - sub.row_hi, 0).max()),
                        float(np.maximum(sub.lower[ncap:] - sub.values[ncap:], 0).max()),
                        float(np.maximum(sub.values[ncap:] - sub.upper[ncap:], 0).max()))
    if max(violation, simultaneous, balance_error) > 5e-5:
        raise RuntimeError(f"{code}: dispatch validation failed: constraint violation={violation:.9g} MW; "
                           f"simultaneous charge/discharge={simultaneous:.9g} MW; "
                           f"hourly balance error={balance_error:.9g} MW")
    stress_shortfall = sum(float(op["shortfall"].sum()) + .25 * float(op["peak_only_shortfall"].sum())
                           for op in best_ops[normal_count:])
    if require_stress and not cfg["allow_unserved"] and stress_shortfall > 5e-5:
        raise RuntimeError(f"{code}: stress event leaves unserved demand")
    economics_result = economics(data, capacities, dispatch, tech_name, reference, cfg)
    fixed_bill_pv = sum(data["fixed"] * np.array([
        (1 + cfg["inflation"])**(month // 12 + 1) / (1 + cfg["discount"])**(month // 12 + 1) for month in range(month_count)]))
    upgrade_replacement = (lifecycle_costs.coefficient(economics_result["upgrade_pv"], cfg["grid_life"], cfg, horizon)
                           - economics_result["upgrade_pv"]) if economics_result["upgrade_pv"] else 0
    reference_extra = economics_result["upgrade_pv"] + economics_result["upgrade_om_pv"] + upgrade_replacement
    reference_extra += sum(cfg.get("connection_costs", {}).get(key, 0) for key in ("shared", "grid"))
    priority_cost = cfg["shortfall_priority_usd_mwh"] * (
        float(dispatch["shortfall"].sum()) + .25 * float(dispatch["peak_only_shortfall"].sum()) + stress_shortfall)
    cycling_tiebreak = 0
    if not cfg["battery_regularization_cash"] and not bess_throughput_is_cash(cfg, reference):
        cycling_tiebreak = sum(float(op["discharge"].sum()) * bess_throughput_rate(cfg, reference) *
            (1 + cfg["inflation"])**(blocks[i][0] // 12 + 1) /
            (1 + cfg["discount"])**(blocks[i][0] // 12 + 1)
            for i, op in enumerate(best_ops[:normal_count]))
    if cfg.get("emissions_limit_enabled"):
        excess = max(a["net_co2e_after_heat_credit_t"] - cfg["emissions_limit_t_year"]
                     for a in economics_result["annual"])
        if excess > 1e-4:
            raise RuntimeError(f"{code}: annual net-emissions validation failed by {excess:.9g} tonnes.")
    accounting_gap = abs(economics_result["npc"] - (best * 1e6 - priority_cost - cycling_tiebreak + fixed_bill_pv + reference_extra))
    if accounting_gap > 200 + 1e6 * best_noise:
        raise RuntimeError(f"{code}: decomposed objective and cashflow accounting disagree")
    return dict(code=code, name=name, tech=tech_name,
                solver=dict(solver_info, method=cfg["solver_method"],
                            label=solver_label if solver_info["used"] == "highs" else
                            solver_label.replace("HiGHS", "Gurobi") + " (capacity master: HiGHS)",
                            engine="Gurobi" if solver_info["used"] == "gurobi" else "HiGHS",
                            connection_cost_master="HiGHS mixed-integer" if len(connected) else "continuous LP",
                            engine_version=highspy.Highs().version(), dispatch_solver=dispatch_solver,
                            capacity_solver="highs-mip" if len(connected) else master_solver, dispatch_objective_scale=1000,
                            dual_feasibility_tolerance=1e-10,
                            simplex_iterations=sum(sub.h.getInfo().simplex_iteration_count for sub in subproblems),
                            interior_point_iterations=sum(sub.h.getInfo().ipm_iteration_count for sub in subproblems)),
                case="Reference" if reference else ("Stress-sized" if require_stress else ("B" if force else "A")),
                caps=capacities, dispatch=dispatch, economics=economics_result,
                solver_seconds=time.time() - started,
                adequacy=dict(status=("UNSERVED LOAD" if max_shortfall > 5e-5 else
                                      ("NORMAL LOAD SERVED; STRESS UNSERVED" if stress_shortfall > 5e-5 else "ALL LOAD SERVED")),
                              unserved_mwh=economics_result["unserved_mwh"],
                              unserved_hours=economics_result["unserved_hours"],
                              peak_unserved_mw=max_shortfall,
                              stress_unserved_mwh=stress_shortfall,
                              reference_grid_limit_mw=cfg["reference_grid_limit"] if reference else None),
                validation=dict(status="Optimal within stated master gap; shortage reported" if max_shortfall > 5e-5 else "Optimal within stated master gap",
                                master_gap_usd=max(0, gap * 1e6), iterations=iterations,
                                max_constraint_violation_mw=violation,
                                max_simultaneous_charge_discharge_mw=simultaneous,
                                max_quarter_hour_grid_mw=0.0 if cfg.get("islanded") else float(dispatch_grid_peak(data, dispatch, cfg).max()),
                                hourly_balance_error_mw=balance_error,
                                max_unserved_load_mw=max_shortfall))

