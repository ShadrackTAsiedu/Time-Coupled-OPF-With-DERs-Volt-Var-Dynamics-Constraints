"""Executive PowerPoint: structure, editability, optional analyses and the HTTP route."""

import io
import json
import socket
import subprocess
import sys
import time
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from pptx import Presentation
from pptx.util import Emu

import report_pptx

ROOT = Path(__file__).resolve().parent
RICH_RUN = "7791be18470745f8af5ef34fa3d208f8"
BARE_RUN = "006ddbffe4e841cd92068dcf8c8cc734"
META = {"project_name": "Harbor Microgrid", "client_name": "ACME Ltd", "consulting_company": "VoltWorks", "date": "2026-03-05"}


def present(run_id):
    return (ROOT / "Application Runs" / run_id).exists()


def texts(prs):
    return [sh.text_frame.text for s in prs.slides for sh in s.shapes if sh.has_text_frame]


@unittest.skipUnless(present(RICH_RUN), "full example run not available")
class RichDeck(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data, cls.problems = report_pptx.build_deck(RICH_RUN, META)
        cls.prs = Presentation(io.BytesIO(cls.data))

    def test_no_slide_failed(self):
        self.assertEqual(self.problems, [])

    def test_widescreen_and_slide_count(self):
        self.assertAlmostEqual(self.prs.slide_width / self.prs.slide_height, 16 / 9, places=2)
        self.assertTrue(18 <= len(self.prs.slides) <= 26, len(self.prs.slides))

    def test_every_slide_has_title_and_notes(self):
        for i, slide in enumerate(self.prs.slides, 1):
            self.assertTrue(slide.shapes.title is not None and slide.shapes.title.text_frame.text.strip(), f"slide {i} title")
            self.assertTrue(slide.has_notes_slide and slide.notes_slide.notes_text_frame.text.strip(), f"slide {i} notes")

    def test_charts_are_native_and_tables_exist(self):
        charts = [sh for s in self.prs.slides for sh in s.shapes if sh.has_chart]
        self.assertGreaterEqual(len(charts), 5)
        self.assertTrue(any(sh.has_table for s in self.prs.slides for sh in s.shapes))
        for s in self.prs.slides:
            for sh in s.shapes:
                if sh.shape_type == 13:  # pictures only for the single-line diagram
                    self.assertIn("diagram", (sh.name + (sh._element.xpath("string(.//p:cNvPr/@descr)") or "")).lower())

    def test_no_empty_placeholders_and_shapes_inside_slide(self):
        for i, slide in enumerate(self.prs.slides, 1):
            for sh in slide.shapes:
                if sh.is_placeholder and sh.has_text_frame:
                    self.assertTrue(sh.text_frame.text.strip(), f"slide {i} empty placeholder {sh.name}")
                self.assertGreaterEqual(sh.left, -Emu(10), f"slide {i} {sh.name}")
                self.assertLessEqual(sh.left + sh.width, self.prs.slide_width + 10, f"slide {i} {sh.name}")
                self.assertLessEqual(sh.top + sh.height, self.prs.slide_height + 10, f"slide {i} {sh.name}")

    def test_equations_are_text(self):
        joined = "\n".join(texts(self.prs))
        self.assertIn("NPC", joined)
        self.assertIn("LCOE", joined)

    def test_metadata_shown(self):
        joined = "\n".join(texts(self.prs))
        for value in ("Harbor Microgrid", "ACME Ltd", "VoltWorks"):
            self.assertIn(value, joined)

    def test_file_name(self):
        self.assertEqual(report_pptx.file_name(META), "Harbor_Microgrid_Executive_Presentation.pptx")


@unittest.skipUnless(present(RICH_RUN), "full example run not available")
class OptionalMetadata(unittest.TestCase):
    def test_blank_metadata_is_omitted(self):
        prs = Presentation(io.BytesIO(report_pptx.build(RICH_RUN, {})))
        joined = "\n".join(texts(prs))
        for bad in ("Client:", "Prepared by", "None", "undefined"):
            self.assertNotIn(bad, joined)
        self.assertTrue(report_pptx.file_name({}).endswith("Executive_Presentation.pptx"))


@unittest.skipUnless(present(BARE_RUN), "bare example run not available")
class BareDeck(unittest.TestCase):
    def test_not_run_analyses_are_a_single_note(self):
        data, problems = report_pptx.build_deck(BARE_RUN, META)
        self.assertEqual(problems, [])
        prs = Presentation(io.BytesIO(data))
        titles = [s.shapes.title.text_frame.text for s in prs.slides]
        self.assertEqual(sum("not yet run" in t for t in titles), 1)
        for word in ("Sensitivity", "Reliability", "power flow"):
            self.assertFalse(any(t.startswith(word) for t in titles), word)
        for s in prs.slides:
            self.assertTrue(s.has_notes_slide and s.notes_slide.notes_text_frame.text.strip())
            for sh in s.shapes:
                if sh.has_chart:
                    self.assertTrue(any(len(list(ser.values)) for p in sh.chart.plots for ser in p.series))


@unittest.skipUnless(present(RICH_RUN), "full example run not available")
class PresentationRoute(unittest.TestCase):
    def test_post_returns_pptx(self):
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, str(ROOT / "generation_app.py"), "--port", str(port)], cwd=ROOT,
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try:
                    urlopen(base + "/api/defaults", timeout=.5).read()
                    break
                except OSError:
                    time.sleep(.1)
            request = Request(f"{base}/api/x/report_pptx", method="POST", headers={"Content-Type": "application/json"},
                              data=json.dumps({"run_id": RICH_RUN, "meta": META}).encode("utf-8"))
            with urlopen(request, timeout=120) as response:
                self.assertEqual(response.headers["Content-Type"], report_pptx.MIME)
                body = response.read()
            self.assertGreater(len(Presentation(io.BytesIO(body)).slides), 15)
            bad = Request(f"{base}/api/x/report_pptx", method="POST", headers={"Content-Type": "application/json"},
                          data=json.dumps({"run_id": "nothex"}).encode("utf-8"))
            with self.assertRaises(HTTPError) as ctx:
                urlopen(bad, timeout=30)
            ctx.exception.close()
        finally:
            server.terminate()
            server.wait(10)


if __name__ == "__main__":
    unittest.main()
